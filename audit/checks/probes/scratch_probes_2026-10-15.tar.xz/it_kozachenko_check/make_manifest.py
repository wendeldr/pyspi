import json
U = {"est": "infotheory.est.kozachenko", "je": "infotheory.je.kozachenko", "ce": "infotheory.ce.kozachenko",
     "xme1": "infotheory.xme.kozachenko_k1", "xme10": "infotheory.xme.kozachenko_k10", "cce": "infotheory.cce.kozachenko",
     "di": "infotheory.di.kozachenko", "si": "infotheory.si.kozachenko"}
ID = {"je": "je_kozachenko", "ce": "ce_kozachenko", "xme1": "xme_kozachenko_k1", "xme10": "xme_kozachenko_k10",
      "cce": "cce_kozachenko", "di": "di_kozachenko", "si": "si_kozachenko_k-1"}
PM = "probes/it_kozachenko_probes.py"
runs = []

def add(k, ds, T, path, tag, ident="default", processes=None, probe=None, R=None, ptag=None):
    u = U[k]
    rid = f"{u}|{ds}|{T}|{path}|{tag}"
    if ptag:
        rid = f"{u}|{ds}|{T}|{path}|{ptag}-{tag}"
    r = {"run_id": rid, "unit_id": u, "identifier": (ID.get(k) if ident == "default" else ident), "dataset": ds, "T": T,
         "path": path, "processes": processes, "seed": 42, "probe": ({"module": PM, "function": probe} if probe else None)}
    if R:
        r["_R"] = R
    runs.append(r)

# ---------------- estimator (kernel path)
add("est", "iid_gaussian", 1024, "kernel", "direct-noiseoff", None, probe="est_direct")
add("est", "var2_bivariate", 1024, "kernel", "direct-noiseoff", None, probe="est_direct")
add("est", "iid_gaussian", 1024, "kernel", "direct-jrand", None, probe="est_direct")
add("est", "bivariate_gaussian", 256, "kernel", "direct-jrand", None, probe="est_direct")
add("est", "iid_gaussian", 4096, "kernel", "direct-noiseoff", None, probe="est_direct")
add("est", "iid_gaussian", 4096, "kernel", "direct-naive-noiseoff", None, probe="est_direct")
for T in (256, 1024, 4096):
    add("est", "iid_gaussian", T, "kernel", "truth", None, probe="est_direct", R=200)
add("est", "iid_gaussian", 4096, "kernel", "nn-routines", None, probe="nn_routines")
add("est", "iid_gaussian", 4096, "kernel", "scale-law", None, probe="scale_law")
add("est", "iid_gaussian", 4096, "kernel", "scale-law-naive", None, probe="scale_law_naive")
add("est", "iid_gaussian", 1024, "kernel", "determinism", None, probe="determinism")
add("est", "iid_gaussian", 256, "kernel", "ties", None, probe="ties")
add("est", "iid_gaussian", 256, "kernel", "properties", None, probe="properties")
add("est", "var2_bivariate", 64, "kernel", "labels", None, probe="labels")

# ---------------- composed SPIs: kl + jrand on the proposed datasets, noiseoff on var2
COMP = {"je": [("iid_gaussian", 256), ("bivariate_gaussian", 1024), ("var2_bivariate", 1024), ("anm", 1024)],
        "ce": [("iid_gaussian", 256), ("bivariate_gaussian", 1024), ("var2_bivariate", 1024), ("anm", 1024)],
        "xme1": [("iid_gaussian", 256), ("var2_bivariate", 1024), ("delayed_noise", 1024), ("logistic_maps_bidir", 1024)],
        "xme10": [("iid_gaussian", 256), ("var2_bivariate", 1024), ("delayed_noise", 1024), ("logistic_maps_bidir", 1024)],
        "cce": [("iid_gaussian", 256), ("var2_bivariate", 1024), ("gauss_ar1_pair", 1024), ("delayed_noise", 256), ("bivariate_gaussian", 1024)],
        "di": [("iid_gaussian", 256), ("var2_bivariate", 1024), ("gauss_ar1_pair", 1024), ("delayed_noise", 256), ("bivariate_gaussian", 1024)],
        "si": [("iid_gaussian", 256), ("var2_bivariate", 1024), ("gauss_ar1_pair", 1024), ("logistic_maps_bidir", 1024)]}
for k, lst in COMP.items():
    for ds, T in lst:
        add(k, ds, T, "pipeline", "kl")
        add(k, ds, T, "pipeline", "jrand")
    add(k, "var2_bivariate", 1024, "pipeline", "noiseoff", probe="spi_noiseoff")
    # T = 4096 (every KL estimate > 2000 rows): kl (independent) + jidt (same-lineage mechanism)
    add(k, "var2_bivariate", 4096, "pipeline", "kl")
    add(k, "var2_bivariate", 4096, "pipeline", "jidt")
for k in ("cce", "di"):
    add(k, "iid_gaussian", 4096, "pipeline", "kl", processes=[0, 1])
    add(k, "iid_gaussian", 4096, "pipeline", "jidt", processes=[0, 1])

# ---------------- je
for T in (256, 1024, 4096):
    add("je", "bivariate_gaussian", T, "pipeline", "truth-p01", processes=[0, 1], R=300)
    add("je", "bivariate_gaussian", T, "pipeline", "truth-p23", processes=[2, 3], R=300)
add("je", "gauss_ar1_pair", 1024, "pipeline", "order", None, probe="order_check", ptag="je")
add("je", "shared_envelope", 1024, "pipeline", "ties", None, probe="noise_sensitivity")
add("je", "logistic_maps", 1024, "pipeline", "ties", None, probe="noise_sensitivity")
add("je", "scaled_offset", 1024, "kernel", "jrand")
add("je", "scaled_offset", 1024, "kernel", "shift-d2", None, probe="je_scaled_shift")
add("je", "trending", 1024, "pipeline-detrend", "jrand")
# ---------------- ce
for T in (256, 1024, 4096):
    add("ce", "bivariate_gaussian", T, "pipeline", "truth-p01", processes=[0, 1], R=300)
    add("ce", "bivariate_gaussian", T, "pipeline", "truth-p23", processes=[2, 3], R=300)
add("ce", "anm", 1024, "pipeline", "direction")
add("ce", "scaled_offset", 1024, "kernel", "jrand")
# ---------------- xme
for T in (256, 1024, 4096):
    add("xme1", "delayed_noise", T, "pipeline", "truth-p01", processes=[0, 1], R=200)
    add("xme1", "delayed_noise", T, "pipeline", "truth-p03", processes=[0, 3], R=200)
for T in (256, 1024):
    add("xme10", "delayed_noise", T, "pipeline", "truth-p01", processes=[0, 1], R=200)
    add("xme10", "delayed_noise", T, "pipeline", "truth-p03", processes=[0, 3], R=200)
for k in ("xme1", "xme10"):
    add(k, "var2_bivariate", 1024, "pipeline", "direction")
    add(k, "delayed_noise", 1024, "pipeline", "direction")
add("xme1", "var2_bivariate", 1024, "pipeline", "k2-jrand", None, probe="xme_k2")
add("xme1", "iid_gaussian", 1024, "pipeline", "shift-jrand", None, probe="xme_shift")
add("xme10", "iid_gaussian", 1024, "pipeline", "shift-pattern", None, probe="xme_shift")
add("xme10", "iid_gaussian", 4096, "pipeline", "threshold", None, probe="xme10_threshold")
# ---------------- cce
for T in (256, 1024, 4096):
    add("cce", "gauss_ar1_pair", T, "pipeline", "truth", R=(200 if T < 4096 else 100))
add("cce", "iid_gaussian", 1024, "pipeline", "truth-iid", processes=[0, 1], R=200)
for ds in ("var2_bivariate", "delayed_noise", "logistic_maps_bidir"):
    add("cce", ds, 1024, "pipeline", "direction")
add("cce", "var2_bivariate", 1024, "pipeline", "n10-jrand", None, probe="cce_n10")
add("cce", "var2_bivariate", 64, "pipeline", "configured-n", None, probe="configured_n")
# ---------------- di
for T in (256, 1024):
    add("di", "gauss_ar1_pair", T, "pipeline", "truth", R=200)
for ds in ("var2_bivariate", "delayed_noise", "logistic_maps_bidir"):
    add("di", ds, 1024, "pipeline", "direction")
add("di", "var2_bivariate", 1024, "pipeline", "massey")
add("di", "var2_bivariate", 1024, "pipeline", "massey-identity")
add("di", "cointegrated", 1024, "pipeline", "massey-identity", processes=[2, 3])
add("di", "var2_bivariate", 1024, "pipeline", "indep-jrand", None, probe="di_indep")
add("di", "var2_bivariate", 1024, "pipeline", "indep-truth", None, probe="di_indep", R=150)
add("di", "var2_bivariate", 1024, "pipeline", "n10-jrand", None, probe="di_n10")
# ---------------- si
for T in (256, 1024, 4096):
    add("si", "gauss_ar1_pair", T, "pipeline", "truth", R=(200 if T < 4096 else 100))
add("si", "bivariate_gaussian", 1024, "pipeline", "truth-p23", processes=[2, 3], R=200)
for T in (256, 1024):
    add("si", "iid_gaussian", T, "pipeline", "null", R=100)
add("si", "var2_bivariate", 1024, "pipeline", "order", None, probe="order_check", ptag="si")

ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids)), "duplicate run ids"
json.dump({"family": "it_kozachenko", "runs": runs}, open("/media/dan/Data/git/pyspi/audit/checks/manifest/it_kozachenko.json", "w"), indent=1)
print(len(runs), "runs")
