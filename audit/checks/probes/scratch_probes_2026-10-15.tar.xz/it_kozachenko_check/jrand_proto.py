import sys, math, time, numpy as np
from scipy.spatial import cKDTree
from scipy.special import digamma, gammaln
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import jpype as jp

class JavaRandom:
    MULT = 0x5DEECE66D; ADD = 0xB; MASK = (1 << 48) - 1
    def __init__(self, seed):
        self.seed = (seed ^ self.MULT) & self.MASK; self.have = False; self.nng = 0.0
    def next(self, bits):
        self.seed = (self.seed * self.MULT + self.ADD) & self.MASK
        r = self.seed >> (48 - bits)
        if r >= 1 << (bits - 1) and bits == 32: r -= 1 << 32
        return r
    def next_double(self):
        return ((self.next(26) << 27) + self.next(27)) * 2.0 ** -53
    def next_gaussian(self):
        if self.have:
            self.have = False; return self.nng
        while True:
            v1 = 2 * self.next_double() - 1; v2 = 2 * self.next_double() - 1; s = v1 * v1 + v2 * v2
            if s < 1 and s != 0: break
        mul = math.sqrt(-2 * math.log(s) / s)
        self.nng = v2 * mul; self.have = True
        return v1 * mul

def gauss_stream(n, seed=42):
    r = JavaRandom(seed); return np.array([r.next_gaussian() for _ in range(n)])

JR = jp.JClass('java.util.Random')(42)
g_java = np.array([JR.nextGaussian() for _ in range(20000)])
g_py = gauss_stream(20000)
print('gaussian stream max diff', np.max(np.abs(g_java - g_py)), 'n unequal', int(np.sum(g_java != g_py)))

def kl(X, noise=0.0, seed=42):
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    if noise: X = X + gauss_stream(X.size, seed).reshape(X.shape) * noise
    N, d = X.shape
    r = cKDTree(X).query(X, k=2)[0][:, 1]
    return d * np.mean(np.log(2 * r)) + digamma(N) - digamma(1) + 0.5 * d * math.log(math.pi / 4) - gammaln(d / 2 + 1)

K = jp.JClass('infodynamics.measures.continuous.kozachenko.EntropyCalculatorMultiVariateKozachenko')
rng = np.random.default_rng(5)
for d in (1, 2, 3, 5):
    for N in (256, 1024):
        X = rng.standard_normal((N, d))
        c = K(); c.setProperty('NOISE_SEED', '42'); c.initialise(d); c.setObservations(jp.JArray(jp.JDouble, 2)(X)); hj = c.computeAverageLocalOfObservations()
        print(d, N, 'jidt', hj, 'replica-diff', hj - kl(X, 1e-8), 'nojitter-diff', hj - kl(X))
