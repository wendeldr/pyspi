import sys, yaml
sys.path.insert(0, '/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/it_kozachenko_check')
from checks_run import checks_run

REC = '/media/dan/Data/git/pyspi/audit/records/{}.yaml'
REF = 'audit/checks/refs/it_kozachenko.py'
P = 'infotheory.'
JIT = ('jitter replica = canonical KL on the input plus 1e-8 * java.util.Random(42).nextGaussian() added row-major per JIDT call '
       '(' + REF + ':JavaRandom; EntropyCalculatorMultiVariateCommon.java a9b6b3e7 :200-211)')
AGREE = ('exact: rtol 1e-10, atol 1e-10 against the jitter replica, the noise-off probe and the JIDT-naive-routine port; tolerance: '
         'atol 5e-4 nat (rtol 0) against the canonical KL without jitter, 5e-4 = about 2x the largest jitter residual measured on the reference side at T <= 1024 '
         '(2.7e-4, si logistic_maps_bidir; ref_jitter_residual_maxabs); statistical: |pyspi - population| <= 2 SD of a Monte Carlo of the canonical estimator '
         '(MC mean and z vs MC mean stored); qualitative: rule stated in each run')
COMMON_CHECKREF = (f'{REF}:chk_comp (canonical KL via audit/checks/refs/_kernels_infotheory.py:entropy_kozachenko, cKDTree Euclidean, Kraskov 2004 eq. 20 k=1; '
                   f'{JIT}; mode jidt = port of JIDT EuclideanUtils naive routine, same-lineage, used only to explain T = 4096), {REF}:chk_noiseoff with '
                   'audit/checks/probes/it_kozachenko_probes.py:spi_noiseoff, ')

U = {}

U['est.kozachenko'] = dict(
    check_method='independent-impl',
    check_reference=(f'{REF}:chk_est_direct (canonical KL and jitter replica on design matrices of the raw rows), chk_nn (scipy cKDTree exact NN distances vs JIDT '
                     f'EuclideanUtils routines called directly), chk_scale (analytic H(cX) - H(X) = d ln c), chk_est_truth (analytic d * 0.5 ln(2 pi e), Monte Carlo SD), '
                     f'chk_properties / chk_labels / chk_determinism / chk_ties; same-lineage port {REF}:nn_naive_jidt for the > 2000-row mechanism; probes in '
                     'audit/checks/probes/it_kozachenko_probes.py (est_direct, nn_routines, scale_law, scale_law_naive, determinism, ties, properties, labels)'),
    check_data='iid_gaussian T256/T1024/T4096 (kernel path, design matrices with d in {1,2,3,5,6,10}); var2_bivariate T1024 and T64; bivariate_gaussian T256; scaled_offset T1024 (je runs)',
    agreement_criterion=('exact rtol/atol 1e-10 (noise-off JIDT vs canonical KL; default jitter vs replica; scale law); statistical |pyspi - d*H1| <= 2 MC SD (200 draws); '
                         'qualitative NN-routine, scale-law-naive, determinism, ties, properties and label rules'),
    closeness=('<= 2000 rows: noise-off JIDT vs canonical KL max_abs 7.1e-15 (iid_gaussian T1024) and 4.4e-15 (var2_bivariate); default jitter vs replica 6.2e-15 '
               '(iid T1024, bivariate T256); jitter effect itself (replica - canonical) d=1: 2.6e-5 (iid T1024), 1.1e-5 (bivariate T256), 4.4e-5 (iid T4096), d >= 2: <= 5.1e-8. '
               'Scale law H(cX) - H(X) = d ln c, c in {0.1, 10, 1000}, 2000 rows: max_abs 1.0e-13. > 2000 rows (iid T4096, noise off; |direct-noiseoff fails): pyspi - canonical '
               '= 1.8e-14 (d=1), -2.1e-4 (d=2), -9.0e-4 (d=3), -0.038 (d=5), -0.157 (d=6), -4.334 (d=10); the naive-routine port reproduces all six to 2.0e-14 (same-lineage). '
               'NN routines on 4087 raw iid rows (|nn-routines): wrong distances d=1 0, d=2 1, d=3 4, d=5 176, d=10 3981; d=2 at scale 10: 176; d=10 at scale 0.05: 0; every '
               'wrong value lies in (1, true distance); fast routine = cKDTree; dispatch = fast for N <= 2000 and naive for N > 2000. Scale law at 4087 rows (|scale-law-naive): '
               'd=1 exact, d=2 off by -0.033 (c=10) and -4.80 (c=1000), d=5 by -7.77 and -26.6. Population d*H1: T256 pass (max_z 1.07); T1024 fails at max_z 2.10 '
               '(d=10: 14.346 vs 14.189, MC SD 0.110; canonical KL on the same data equals pyspi, so this is the draw); T4096 fails at max_z 89.3 (d=10 9.819 vs 14.189, '
               'canonical MC mean 14.162). Ties (row rounded to 0.5, 12 values): -14.668 with jitter (replica identical), -inf with noise off.'),
    verdict='wrong',
    score_0_10=3,
    what_changed=('For estimates with <= 2000 rows JIDT computes the canonical Kozachenko-Leonenko estimate (Euclidean norm, k = 1, psi(N) - psi(1), nats) to fp precision; the '
                  'only convention is the seeded 1e-8 jitter (effect <= 2.7e-4 nat, from d = 1 terms). For > 2000 rows JIDT switches to '
                  'EuclideanUtils.computeMinEuclideanDistancesNaive, whose early exit compares a squared partial sum with the un-squared running minimum; in d >= 2 it '
                  'returns a distance shorter than the nearest-neighbour distance at points whose true NN distance exceeds 1, so the entropy is too low (iid N(0,1): '
                  '-0.038 nat at d=5, -4.33 nat at d=10, N=4096) and the scale law fails. NORMALISE reads true but is not applied; BIAS_CORRECTION is ignored. '
                  'The score is set by the > 2000-row regime; the <= 2000-row computation on its own would rate 9 (jitter convention).'),
    new_finding=True,
    check_cost='cheap: probes 0.03-17 s (nn-routines 17 s at N = 4087); references dominated by the 200-draw Monte Carlo of the three truth runs',
    symmetry_observed='n/a (estimator); column order changes only the jitter layout: fresh je bivariate(0,1) vs (1,0) differ by 4.2e-8, si by 3.1e-8 (|je-order, |si-order runs)',
    direction_observed='n/a (estimator)',
    resolutions=[
        ('JIDT computeMinEuclideanDistancesNaive (> 2000 rows) underestimates NN distances where the true distance exceeds 1, d >= 2', 'confirmed',
         'infotheory.est.kozachenko|iid_gaussian|4096|kernel|nn-routines (wrong only where truth > 1, value in (1, truth); d=1 never; d=10 3981/4087), |direct-noiseoff at T4096 (fails, d=10 -4.334), |direct-naive-noiseoff (port 2.0e-14), |scale-law-naive; infotheory.xme.kozachenko_k10|iid_gaussian|4096|pipeline|threshold'),
        ('shipped infodynamics.jar is a post-v1.6.1 build; NOISE_SEED honoured', 'confirmed',
         'infotheory.est.kozachenko|iid_gaussian|256|kernel|properties (superclass EntropyCalculatorMultiVariateCommon, NOISE_SEED 42), |iid_gaussian|1024|kernel|determinism (bit-identical, equals replica to 6e-15); infotheory.est.gaussian|var2_bivariate|64|kernel|jar-provenance'),
        ('NORMALISE reads true but is inert', 'confirmed',
         'infotheory.est.kozachenko|iid_gaussian|256|kernel|properties (H(10x) - H(x) = ln 10 to 1e-12 noise off); infotheory.je.kozachenko|scaled_offset|1024|kernel|shift-d2 (raw-path shifts 0.016-3.91 nat, equal to canonical KL on raw rows to 5.5e-8) and |scaled_offset|1024|kernel|jrand (exact on raw rows)'),
        ('estimator uses the Euclidean norm, not the max-norm (refutes the pack hypothesis)', 'confirmed',
         'infotheory.est.kozachenko|iid_gaussian|1024|kernel|direct-noiseoff and |var2_bivariate|1024|kernel|direct-noiseoff: Euclidean canonical KL to 7.1e-15 for d = 1..10'),
        ("kozachenko variants carry the label 'linear' (documented 'nonlinear')", 'confirmed',
         "infotheory.est.kozachenko|var2_bivariate|64|kernel|labels (all 7 identifiers: 'linear' present, 'nonlinear' absent)"),
        ('tied data give a jitter-determined value', 'confirmed',
         'infotheory.est.kozachenko|iid_gaussian|256|kernel|ties (-14.668 with jitter, -inf noise off); infotheory.je.kozachenko|shared_envelope|1024|pipeline|ties'),
        ('BIAS_CORRECTION set by pyspi is ignored by this calculator', 'confirmed',
         'infotheory.est.kozachenko|iid_gaussian|256|kernel|properties (getProperty BIAS_CORRECTION is None)'),
    ])

U['je.kozachenko'] = dict(
    check_method='independent-impl',
    check_reference=COMMON_CHECKREF + f'{REF}:chk_truth (population 2 H1 + 0.5 ln(1 - rho^2)), chk_order, chk_noise_sens, chk_je_shift',
    check_data='iid_gaussian T256; bivariate_gaussian T256/T1024/T4096 (pairs 0-1, 2-3); var2_bivariate T1024/T4096; anm T1024; gauss_ar1_pair T1024; shared_envelope and logistic_maps T1024; scaled_offset T1024 (kernel); trending T1024 (pipeline-detrend)',
    agreement_criterion=AGREE,
    closeness=('Canonical KL (kl, 5 runs incl. T4096): max_abs 1.3e-7 (the jitter). Jitter replica (jrand, 6 runs incl. scaled_offset kernel and trending pipeline-detrend): '
               'max_abs 1.2e-14; noise-off probe 0.0. T4096 var2_bivariate: 2.82078501 vs canonical 2.82078503 (d = 2 is unaffected by the > 2000-row defect). '
               'Population 2 H1 + 0.5 ln(1 - rho^2): 6/6 pass, max_z <= 1.82 (T4096 rho=0.3: 2.7503 vs 2.7907, MC SD 0.022). Order probe exact (A01 - A10 = 0; fresh '
               'bivariate(0,1) vs (1,0) differ by 4.2e-8, jitter layout). Ties: shared_envelope rows 0-2 je = -28.809 and moves by 9.2103 nat (= 2 ln 100) when the jitter '
               'goes 1e-8 -> 1e-6, pairs with row 3 move <= 7.8e-5; logistic_maps pair (period-4 row) moves 3.9e-3 nat, above the 1e-3 I set beforehand (run fails).'),
    verdict='matches', score_0_10=9,
    what_changed=("Canonical Kozachenko-Leonenko joint entropy of the z-scored pair in nats, columns [z_max, z_min]; convention: JIDT's seeded 1e-8 jitter (<= 1.3e-7 nat here). "
                  "d = 2 is practically untouched by the > 2000-row NN defect. Labelled 'linear' although the estimator is nonparametric (documented 'nonlinear'). "
                  'On near-tied rows the value is set by the jitter level (shared_envelope: shifts by exactly d ln of the jitter ratio).'),
    new_finding=True,
    check_cost='cheap: <= 0.2 s per pyspi run (T4096), 0.03 s at T1024',
    symmetry_observed='sym: max|A - A.T| = 0.0 on all runs (kl/jrand on iid_gaussian, bivariate_gaussian, var2_bivariate T1024/T4096, anm)',
    direction_observed='undirected: A[i,j] = A[j,i] = H_KL([z_b, z_a]) for a < b (the (i=b, j=a) visit fills the joint-entropy cache first); orientation of the columns only moves the jitter layout (4.2e-8)',
    resolutions=[
        ("label 'linear' for the nonparametric KL variant", 'confirmed', 'infotheory.est.kozachenko|var2_bivariate|64|kernel|labels'),
        ('value set by the jitter on tied or near-tied rows', 'confirmed',
         'infotheory.je.kozachenko|shared_envelope|1024|pipeline|ties (rows 0-2: -28.809, move 9.2103 nat for jitter 1e-8 -> 1e-6, replica to 5.3e-14); |logistic_maps|1024|pipeline|ties (milder: 3.9e-3 nat)'),
    ])

U['ce.kozachenko'] = dict(
    check_method='independent-impl',
    check_reference=COMMON_CHECKREF + f'{REF}:chk_truth (population H1 + 0.5 ln(1 - rho^2)), chk_dir (orientation and anm ordering)',
    check_data='iid_gaussian T256; bivariate_gaussian T256/T1024/T4096; var2_bivariate T1024/T4096; anm T1024; scaled_offset T1024 (kernel)',
    agreement_criterion=AGREE,
    closeness=('Canonical KL (kl, 5 runs): max_abs 1.4e-4 (jitter, d = 1 marginal term); T4096 var2_bivariate 3.7e-5. Jitter replica (5 runs incl. scaled_offset kernel): max_abs 1.7e-14; '
               'noise-off probe 2.7e-15. Population H1 + 0.5 ln(1 - rho^2): 6/6 pass, max_z <= 1.27 (T4096 rho=0.8: 0.9354/0.9255 vs 0.9081). Orientation (anm): pyspi equals '
               'the H(z_j | z_i) replica to 8.9e-15 and differs from its transpose by 0.262; tanh pair A[2,3] = 0.104 < A[3,2] = 0.311; cubic pair A[0,1] = 0.668 vs A[1,0] = 0.615.'),
    verdict='matches', score_0_10=9,
    what_changed=("A[i,j] = H_KL(z_max, z_min) - H_KL(z_i) = H(x_j | x_i), canonical KL in nats with the jitter convention (<= 1.4e-4 nat). Two separate KL estimates, so the matrix "
                  "is asymmetric even after z-scoring (unlike ce_gaussian), while the supplement keyword says 'undirected'. Labelled 'linear' (documented 'nonlinear')."),
    new_finding=True,
    check_cost='cheap: <= 0.4 s per pyspi run',
    symmetry_observed='asym: max|A - A.T| = 0.0232 (var2_bivariate T1024), 0.0137 (T4096), 0.262 (anm), 0.089 (bivariate_gaussian T1024), 0.093 (iid_gaussian T256)',
    direction_observed='A[i,j] = H(x_j | x_i): row = conditioning process, column = process whose uncertainty is measured (anm orientation run: matches replica 8.9e-15, transpose off by 0.262; A[2,3] = H(x3|x2) = 0.104 < A[3,2] = 0.311)',
    resolutions=[
        ("label 'linear' for the nonparametric KL variant", 'confirmed', 'infotheory.est.kozachenko|var2_bivariate|64|kernel|labels'),
        ("documentation keyword 'undirected' while the class is Directed and values are asymmetric", 'confirmed',
         'infotheory.ce.kozachenko|anm|1024|pipeline|kl (max|A - A.T| 0.262), |var2_bivariate|1024|pipeline|kl (0.0232); supplement 1.4.2 keyword list'),
    ])

U['xme.kozachenko_k1'] = dict(
    check_method='independent-impl',
    check_reference=COMMON_CHECKREF + f'{REF}:chk_truth (refs/it_gaussian.py:pop_xme_delayed), chk_dir, chk_k2, chk_shift_rep',
    check_data='iid_gaussian T256/T1024 (shift construction); var2_bivariate T1024/T4096; delayed_noise T256/T1024/T4096 (pairs 0-1, 0-3); logistic_maps_bidir T1024',
    agreement_criterion=AGREE,
    closeness=('Canonical KL (kl, 5 runs incl. T4096): max_abs 1.8e-4 (jitter; logistic_maps_bidir). Jitter replica (4 runs + k2 + shift): max_abs 2.1e-14; noise-off probe 1.8e-15. '
               'Population (delayed_noise): 5/6 pass; T4096 pair 0-1 -0.919 vs -0.889 (z 0.82); T1024 pair 0-3 fails at max_z 2.01 (1.5446 vs 1.4189; canonical KL on the same data '
               'equals pyspi, z vs MC mean 2.13: the draw). history_length=2 probe: equals the k=2 replica to 4.4e-15 and differs from k=1 by <= 2.0e-3 (same lag set {1}, one sample fewer). '
               'Shift construction: k1 sees neither the lag-9 nor the lag-10 copy (1.475, 1.380).'),
    verdict='related-quantity', score_0_10=5,
    what_changed=("No documented definition; computes H(x_j(t) | x_i(t-1)) with canonical KL (jitter convention), without the target's own past and without any cross mapping. "
                  "history_length=1 and =2 use the same lag set. d <= 2, so the > 2000-row defect does not reach it (T4096 3.7e-5). Labelled 'linear'."),
    new_finding=True,
    check_cost='cheap: <= 1.3 s per pyspi run',
    symmetry_observed='asym: max|A - A.T| = 0.133 (var2_bivariate T1024), 0.213 (T4096), 2.42 (delayed_noise), 2.58 (logistic_maps_bidir), 0.297 (iid_gaussian T256)',
    direction_observed='A[i,j] = H(x_j(t) | x_i(t-1)): row = lagged source, column = target (orientation runs: replica to 1.9e-14, transpose off by 2.42). var2_bivariate A[0,1] = 1.266 < A[1,0] = 1.398; delayed_noise A[0,1] = -0.937 < A[1,0] = 1.479',
    resolutions=[
        ("'Cross-map entropy' has no documented definition and performs no cross mapping", 'confirmed',
         'supplement / GitBook search (trace); infotheory.xme.kozachenko_k1|var2_bivariate|1024|pipeline|jrand and |noiseoff reproduce H(y_t | x_{t-1}) exactly (2e-15)'),
        ("label 'linear' for the nonparametric KL variant", 'confirmed', 'infotheory.est.kozachenko|var2_bivariate|64|kernel|labels'),
    ])

U['xme.kozachenko_k10'] = dict(
    check_method='independent-impl',
    check_reference=COMMON_CHECKREF + f'{REF}:chk_shift_pattern (canonical KL of the 9-lag and 10-lag designs), chk_threshold, chk_truth, chk_dir',
    check_data='iid_gaussian T256/T1024 (shift construction)/T4096 (threshold truncations); var2_bivariate T1024/T4096; delayed_noise T256/T1024; logistic_maps_bidir T1024',
    agreement_criterion=AGREE,
    closeness=('T <= 1024: canonical KL (4 runs) max_abs 1.0e-8, jitter replica 2.8e-14, noise-off 1.8e-14. T4096 var2_bivariate (|kl fails): pyspi -0.048/-0.113 vs canonical '
               '1.329/1.433, max_abs 1.546; the naive-routine port reproduces pyspi to 5.3e-15 (same-lineage). Threshold: xme(0->1) on truncations T\' = 2008..2010 (<= 2000 '
               'rows) equals canonical to 9e-9, T\' = 2011 (2001 rows) gives -0.1976 vs 1.4489 (jump -1.646). Lag set: lag-10 copy u(t-10) gives 1.50506 = canonical 9-lag '
               'design 1.50506 and not the 10-lag design 0.689; lag-9 copy 0.640. Population (delayed_noise, Gaussian -0.889 for a used lag): 0/4 pass; canonical KL MC mean '
               '0.607 at T1024 and 0.777 at T256 (bias +1.50 / +1.67 nat in d = 10); pyspi 0.583 (z vs MC mean 1.43). Direction: delayed_noise 6/6 pairs, var2 1/1.'),
    verdict='related-quantity', score_0_10=3,
    what_changed=("No documented definition; H(x_j(t) | x_i(t-1..t-9)): history_length=10 uses 9 source lags. In d = 10 the k=1 KL estimate is strongly biased for a "
                  "near-deterministic relation (+1.5 nat at T = 1024, an estimator property). From T = 2011 (> 2000 rows per estimate) the JIDT naive NN routine drops the "
                  "value by about 1.6 nat and can flip its sign. Labelled 'linear'."),
    new_finding=True,
    check_cost='cheap: <= 1.8 s per pyspi run (T4096 0.8 s; threshold probe 4.8 s)',
    symmetry_observed='asym: max|A - A.T| = 0.194 (var2_bivariate T1024), 0.065 (T4096), 0.98 (delayed_noise), 11.33 (logistic_maps_bidir), 0.251 (iid_gaussian T256)',
    direction_observed='A[i,j] = H(x_j(t) | x_i(t-1..t-9)): row = lagged source, column = target (orientation run: replica 2.8e-14, transpose off by 0.98). delayed_noise: every leading pair A[a,b] (0.58-0.63) < A[b,a] (1.49-1.58); var2_bivariate A[0,1] = 1.315 < A[1,0] = 1.509',
    resolutions=[
        ('history_length=10 yields 9 source lags (off by one)', 'confirmed',
         'infotheory.xme.kozachenko_k10|iid_gaussian|1024|pipeline|shift-pattern (lag-10 copy 1.50506 = 9-lag design, 10-lag design 0.689)'),
        ('JIDT naive NN path for T >= 2011 changes the value', 'confirmed',
         'infotheory.xme.kozachenko_k10|iid_gaussian|4096|pipeline|threshold (T\'=2010 1.44653 = canonical; T\'=2011 -0.1976 vs 1.4489); |var2_bivariate|4096|pipeline|kl (fails, max_abs 1.546) and |jidt (port 5.3e-15)'),
        ('no documented definition; no cross mapping performed', 'confirmed', 'trace documentation search; infotheory.xme.kozachenko_k10|var2_bivariate|1024|pipeline|noiseoff (composition exact)'),
        ("label 'linear' for the nonparametric KL variant", 'confirmed', 'infotheory.est.kozachenko|var2_bivariate|64|kernel|labels'),
    ])

U['cce.kozachenko'] = dict(
    check_method='independent-impl',
    check_reference=COMMON_CHECKREF + f'{REF}:chk_truth (refs/it_gaussian.py:pop_cce; 5 H1 for white pairs), chk_dir, chk_n10, chk_configured_n',
    check_data='iid_gaussian T256/T1024/T4096; var2_bivariate T64/T1024/T4096; gauss_ar1_pair T256/T1024/T4096; delayed_noise T256/T1024; bivariate_gaussian T1024; logistic_maps_bidir T1024',
    agreement_criterion=AGREE,
    closeness=('T <= 1024: canonical KL (5 runs) max_abs 1.4e-4 (jitter), jitter replica 3.7e-14, noise-off 2.7e-14. T4096 (|kl fails): var2_bivariate 4.379/4.686 vs canonical '
               '6.218/6.653 (max_abs 1.967), iid_gaussian 4.484/4.400 vs 7.078/7.007 (2.607); the naive-routine port reproduces both to 1.4e-14 (same-lineage). Population '
               '(gauss_ar1_pair 5.813/5.563): T256 pass (max_z 1.08), T1024 pass (5.857/5.447, max_z 0.58), T4096 fails (4.506/4.370, max_z 13.2; canonical MC mean 5.847/5.610). '
               'White pair 5 H1 = 7.095: 7.306/7.306 (z 1.8). n=10 probe 12.97/13.95 vs n=5 6.21/6.71 (replica to 4.6e-14). Direction: var2 6.212 < 6.710; delayed_noise 5/5 pairs; '
               'logistic_maps_bidir recorded only (A[0,1] = -15.28 < A[1,0] = -8.62: ordered by the target\'s own predictability).'),
    verdict='variant', score_0_10=5,
    what_changed=("Kramer's causally conditioned entropy H(Y^n || X^n), present x included, computed exactly with canonical KL for T <= 2004, but with n = 5 where the "
                  "supplement documents 10 (same composition as cce_gaussian). From T = 2005 every term has > 2000 rows and the JIDT naive NN routine lowers the value by "
                  "about 2-2.6 nat. Labelled 'linear'."),
    new_finding=True,
    check_cost='cheap: <= 9.6 s per pyspi run (P=4-5, T=1024); T4096 P=2 runs 3-4 s',
    symmetry_observed='asym: max|A - A.T| = 0.499 (var2_bivariate T1024), 6.97 (delayed_noise T256), 0.409 (gauss_ar1_pair), 0.501 (iid_gaussian T256), 0.319 (bivariate_gaussian), 6.66 (logistic_maps_bidir)',
    direction_observed='A[i,j] = H(x_j^5 || x_i^5): column = target, row = causally conditioning source (orientation runs: replica 3.7e-14, transpose off by 0.50 / 8.14). var2_bivariate A[0,1] = 6.212 < A[1,0] = 6.710; delayed_noise A[0,1] = 1.222 < A[1,0] = 9.364',
    resolutions=[
        ('history length 5 instead of the documented 10', 'confirmed',
         'infotheory.cce.kozachenko|var2_bivariate|64|pipeline|configured-n (5, 5); |var2_bivariate|1024|pipeline|n10-jrand (12.97 vs 6.21); infotheory.cce.gaussian|var2_bivariate|64|pipeline|configured-n'),
        ('JIDT naive NN path for T >= 2005 lowers the value', 'confirmed',
         'infotheory.cce.kozachenko|var2_bivariate|4096|pipeline|kl (max_abs 1.967), |iid_gaussian|4096|pipeline|kl (2.607), |jidt runs (port 1.4e-14), |gauss_ar1_pair|4096|pipeline|truth (max_z 13.2)'),
        ("label 'linear' for the nonparametric KL variant", 'confirmed', 'infotheory.est.kozachenko|var2_bivariate|64|kernel|labels'),
    ])

U['di.kozachenko'] = dict(
    check_method='independent-impl',
    check_reference=COMMON_CHECKREF + f'{REF}:chk_massey (Massey 1990 eq. 6 with canonical KL), chk_massey_identity, chk_indep_rep / chk_indep_truth, chk_truth, chk_dir, chk_n10',
    check_data='iid_gaussian T256/T4096; var2_bivariate T1024/T4096; gauss_ar1_pair T256/T1024; delayed_noise T256/T1024; bivariate_gaussian T1024; logistic_maps_bidir T1024; cointegrated T1024 rows 2-3; constructed pair [iid row 0, var2 row 0] T1024',
    agreement_criterion=AGREE,
    closeness=('T <= 1024: canonical KL (5 runs) max_abs 1.9e-4 (jitter), replica 4.3e-14, noise-off 2.8e-14. Massey form (var2 T1024, |massey fails by design): pyspi 0.614/0.134 vs '
               'Massey 0.449/-0.181, max_abs 0.315; pyspi = Massey + B(target) to 3.7e-14 with B_KL 0.165 (target x1) / 0.315 (target x0), Gaussian plug-in 0.126/0.159, '
               'population 0.138/0.177. Independent random walks (cointegrated rows 2-3): B_KL 2.52/2.77 against Massey 0.51/0.41. Independent white source -> AR(2) target '
               '(T1024): pyspi -0.112 (Massey KL -0.427), population B 0.177, fails at max_z 2.04 (canonical MC mean 0.057, z vs MC 1.35). T4096 (|kl fails): iid_gaussian '
               '2.613/2.704 vs canonical 0.028/0.106 (2.598), var2 2.409/2.096 vs 0.574/0.133 (1.963); port 5.2e-14. Population pyspi-form DI on gauss_ar1_pair: 2/2 pass '
               '(max_z 1.04). n=10 probe 0.579/-0.466 vs n=5 0.614/0.134. Direction 3/3.'),
    verdict='related-quantity', score_0_10=3,
    what_changed=("First term is sum_{m=1..5} H(Y^m)/m, not H(Y^5): pyspi DI = Massey DI_5 + B(target), B >= 0 in population and driven by the target's autocorrelation "
                  "(same composition as di_gaussian), so independent autocorrelated pairs get large positive values (2.5-2.8 nat for random walks). n = 5 instead of 10. "
                  "From T = 2005 the JIDT naive NN routine corrupts the CCE and block terms (iid pair 2.61 instead of 0.03). Labelled 'linear'."),
    new_finding=True,
    check_cost='cheap: <= 14 s per pyspi run (P=4, T=1024); T4096 P=2 runs about 5 s',
    symmetry_observed='asym: max|A - A.T| = 0.480 (var2_bivariate T1024), 6.95 (delayed_noise T256), 0.277 (gauss_ar1_pair), 0.533 (iid_gaussian T256), 0.266 (bivariate_gaussian), 1.49 (logistic_maps_bidir)',
    direction_observed='A[i,j] = DI(x_i -> x_j) as pyspi defines it (orientation runs: replica 3.7e-14, transpose off by 0.48 / 8.10). var2_bivariate A[0,1] = 0.614 > A[1,0] = 0.134; delayed_noise A[0,1] = 5.760 > A[1,0] = -2.341; logistic_maps_bidir A[1,0] = 2.163 > A[0,1] = 0.674 (y -> x stronger)',
    resolutions=[
        ('target term sum_k H(Y^k)/k instead of H(Y^n): upward bias B for autocorrelated targets', 'confirmed',
         'infotheory.di.kozachenko|var2_bivariate|1024|pipeline|massey (max_abs 0.315), |massey-identity (3.7e-14; B_KL 0.165/0.315), |cointegrated|1024|pipeline|massey-identity (B_KL 2.52/2.77); infotheory.di.gaussian|var2_bivariate|4096|pipeline|indep-truth (closed-form B 0.1766)'),
        ('history length 5 instead of the documented 10', 'confirmed',
         'infotheory.cce.kozachenko|var2_bivariate|64|pipeline|configured-n (di_n 5); infotheory.di.kozachenko|var2_bivariate|1024|pipeline|n10-jrand (0.579 vs 0.614)'),
        ('JIDT naive NN path for T >= 2005 corrupts the value', 'confirmed',
         'infotheory.di.kozachenko|iid_gaussian|4096|pipeline|kl (2.613 vs 0.028), |var2_bivariate|4096|pipeline|kl (2.409 vs 0.574), |jidt runs (port 5.2e-14)'),
        ("label 'linear' for the nonparametric KL variant", 'confirmed', 'infotheory.est.kozachenko|var2_bivariate|64|kernel|labels'),
    ])

U['si.kozachenko'] = dict(
    check_method='independent-impl',
    check_reference=COMMON_CHECKREF + f'{REF}:chk_truth (population SI from A and Sigma_E; white-pair MI), chk_null_si, chk_order',
    check_data='iid_gaussian T256/T1024; var2_bivariate T1024/T4096; gauss_ar1_pair T256/T1024/T4096; bivariate_gaussian T1024 (pair 2-3); logistic_maps_bidir T1024',
    agreement_criterion=AGREE,
    closeness=('T <= 1024: canonical KL (4 runs) max_abs 2.7e-4 (jitter, logistic_maps_bidir), replica 4.1e-14, noise-off 7.1e-15. T4096 var2_bivariate (|kl fails): 0.16774 vs '
               'canonical 0.16557 (2.2e-3, d = 4 terms through the naive NN routine; port to 3.2e-14). Population 0.0999 (gauss_ar1_pair): 3/3 pass, T1024 0.025 (MC mean 0.123, '
               'SD 0.118), T4096 -0.0128 (max_z 1.96). bivariate_gaussian rho=0.8 T1024 fails at max_z 2.52 (0.802 vs 0.511; canonical KL on the same data equals pyspi, z vs '
               'MC 2.43: the draw). Null iid_gaussian: T256 mean -0.046 over 10 pairs, 5 negative (MC 0.004 +- 0.103); T1024 mean 0.088, 3 negative (MC 0.027 +- 0.067); both pass. '
               'Order probe exact (A01 = A10; direct calls differ by 3.1e-8).'),
    verdict='matches', score_0_10=9,
    what_changed=("Ay's stochastic interaction with one-step kernels from six canonical KL estimates (jitter convention). Values are noisy (MC SD 0.12 at T = 1024 against a "
                  "population of 0.10) and sign-varying under the null; the > 2000-row defect changes T = 4096 values by about 2e-3. Labelled 'linear'."),
    new_finding=True,
    check_cost='cheap: <= 3.3 s per pyspi run (P=5, T=1024)',
    symmetry_observed='sym: max|A - A.T| = 0.0 on all runs (upper triangle mirrored)',
    direction_observed='undirected: A[i,j] = A[j,i] = SI(z_min(i,j), z_max(i,j)); direct calls in the two orders differ by 3.1e-8 (jitter layout)',
    resolutions=[
        ('nonzero, sign-varying null values and a large relative bias on a known Gaussian process', 'confirmed',
         'infotheory.si.kozachenko|iid_gaussian|256|pipeline|null (5/10 negative) and |1024|pipeline|null (3/10 negative). The bias part is refuted: |gauss_ar1_pair|1024|pipeline|truth canonical MC mean 0.123 vs population 0.0999, SD 0.118, so 0.025 is a draw (sampling variance, not bias)'),
        ("label 'linear' for the nonparametric KL variant", 'confirmed', 'infotheory.est.kozachenko|var2_bivariate|64|kernel|labels'),
    ])

for u, f in U.items():
    path = REC.format(P + u)
    d = yaml.safe_load(open(path))
    c = d['correctness']
    cands = c.get('new_finding_candidates') or []
    res = f.pop('resolutions')
    assert len(res) == len(cands), (u, len(res), len(cands))
    for k in ('check_method', 'check_reference', 'check_data', 'agreement_criterion', 'closeness', 'verdict', 'score_0_10', 'what_changed', 'new_finding'):
        c[k] = f[k]
    c['definition_under_review'] = False
    for k in ('check_cost', 'symmetry_observed', 'direction_observed'):
        c[k] = f[k]
    c['candidate_resolutions'] = [{'candidate': a, 'outcome': b, 'evidence': e} for a, b, e in res]
    c['checks_run'] = checks_run(P + u)
    d['status'] = 'checked'
    with open(path, 'w') as fh:
        yaml.safe_dump(d, fh, sort_keys=False, width=200, allow_unicode=True)
    print('updated', u)
