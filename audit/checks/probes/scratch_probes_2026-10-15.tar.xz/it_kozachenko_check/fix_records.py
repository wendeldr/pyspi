import yaml
from pathlib import Path
R = Path('/media/dan/Data/git/pyspi/audit/records')
PRB = 'audit/checks/refs/it_kozachenko.py:chk_frame with audit/checks/probes/it_kozachenko_probes.py:frame'

def load(u):
    return yaml.safe_load((R / f'infotheory.{u}.yaml').read_text())

def save(u, d):
    (R / f'infotheory.{u}.yaml').write_text(yaml.safe_dump(d, sort_keys=False, width=200, allow_unicode=True, default_flow_style=False))

def fix_trace(c, repl):
    out = []
    n = 0
    for line in c['implementation_trace']:
        for old, new in repl:
            if line.startswith(old):
                line = new
                n += 1
        out.append(line)
    c['implementation_trace'] = out
    return n

CALC_OLD = 'pyspi/calculator.py:264,294,297'
CALC_NEW = ('pyspi/calculator.py:277 load_dataset: Data(Data.convert_to_numpy(dataset), normalise=self._normalise, detrend=self._detrend) (normalise=True default, :50); '
            'pyspi/calculator.py:329 S = self._spis[spi].multivariate(self.dataset); pyspi/calculator.py:332 np.fill_diagonal(S, np.nan) (HEAD lines)')
FRAME_CAND = ("Candidate (copy path, added at the check stage): in a CalculatorFrame the SPI's entropy calculator is a deep copy (CalculatorFrame.init_from_list, pyspi/calculator.py:559 "
              "calc = copy.deepcopy(base_calc); JIDTBase.__deepcopy__, pyspi/statistics/infotheory.py:77-82, deep-copies the JPype proxy without re-running _setup). The copy reads NOISE_SEED 'NONE' "
              "while NOISE_LEVEL_TO_ADD stays 1e-8, so every CalculatorFrame computation draws an unseeded jitter and is not reproducible. Same mechanism as the KERNEL_WIDTH reset confirmed in "
              "it_kernel (infotheory.est.kernel|bivariate_gaussian|256|pipeline|copy-props). The Calculator path and a pickle round trip (__setstate__ -> _getcalc -> _setup) keep NOISE_SEED=42.")

def frame_res(evidence):
    return {'candidate': "CalculatorFrame (deepcopy) path drops NOISE_SEED=42: unseeded jitter, outputs not reproducible", 'outcome': 'confirmed', 'evidence': evidence}

def add_check(c, run_ids, ref, outcome):
    c['checks_run'].append({'run_ids': run_ids, 'reference': ref, 'outcome': outcome})

def add_frame(u, c, frame_runs, evidence, outcome, closeness_add, what_add):
    c['new_finding_candidates'].append(FRAME_CAND)
    c['candidate_resolutions'].append(frame_res(evidence))
    add_check(c, frame_runs, PRB, outcome)
    c['closeness'] = c['closeness'].rstrip() + ' ' + closeness_add
    c['what_changed'] = c['what_changed'].rstrip() + ' ' + what_add
    if 'chk_frame' not in c['check_reference']:
        c['check_reference'] = c['check_reference'].rstrip() + ', chk_frame (Calculator vs two CalculatorFrame objects vs pickle round trip, audit/checks/probes/it_kozachenko_probes.py:frame)'

FR_WHAT = ("CalculatorFrame path: the deep-copied calculator reads NOISE_SEED 'NONE', so frame-path values carry an unseeded jitter and are not reproducible "
           "(carried as a finding, not scored: path-dependent).")

# ---------------------------------------------------------------- est
u = 'est.kozachenko'; d = load(u); c = d['correctness']
n = fix_trace(c, [('pyspi/calculator.py:48,264', 'pyspi/calculator.py:48-50 Calculator.__init__(..., detrend=False, normalise=True) default; pyspi/calculator.py:277 Data(Data.convert_to_numpy(dataset), normalise=self._normalise, detrend=self._detrend); pyspi/data.py:193-195 zscore(axis=1, ddof=1)'),
                  ('pyspi/statistics/infotheory.py:103-110', "pyspi/statistics/infotheory.py:103-110 _getcalc('entropy') -> kozachenko.EntropyCalculatorMultiVariateKozachenko(); pyspi/statistics/infotheory.py:134 return self._setup(calc)"),
                  ('pyspi/statistics/infotheory.py:84-93', "pyspi/statistics/infotheory.py:84-93 _setup: setProperty('BIAS_CORRECTION','false') at :90, setProperty(self._SEED, '42') i.e. NOISE_SEED=42 at :91; no NORMALISE / NOISE_LEVEL_TO_ADD set")])
assert n == 3, n
c['implementation_trace'].append("pyspi/statistics/infotheory.py:77-82 JIDTBase.__deepcopy__: newone = type(self)(), then copy.deepcopy of every attribute (the JPype calculator proxy comes back in JIDT's default state, NOISE_SEED 'NONE'); used by pyspi/calculator.py:559 CalculatorFrame.init_from_list calc = copy.deepcopy(base_calc)")
c['new_finding_candidates'].append(FRAME_CAND)
c['candidate_resolutions'][1] = {'candidate': 'shipped infodynamics.jar is a post-v1.6.1 build; NOISE_SEED honoured on the Calculator and pickle paths only (CalculatorFrame path: see the copy-path candidate)',
    'outcome': 'confirmed',
    'evidence': ("infotheory.est.kozachenko|iid_gaussian|256|kernel|properties (superclass EntropyCalculatorMultiVariateCommon, NOISE_SEED 42), |iid_gaussian|1024|kernel|determinism (bit-identical, equals replica "
                 "to 6e-15); infotheory.est.gaussian|var2_bivariate|64|kernel|jar-provenance. Qualifier: determinism holds for the original SPI object and a pickle round trip; a deepcopy reads NOISE_SEED 'NONE' "
                 "(infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props)")}
c['candidate_resolutions'].append(frame_res(
    "infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props (all 7 identifiers: NOISE_SEED original 42 / deepcopy 'NONE' / pickle 42; NOISE_LEVEL_TO_ADD 1e-8 on all three); per-unit |frame runs "
    "(e.g. infotheory.cce.kozachenko|shared_envelope|1024|pipeline|frame: two CalculatorFrame objects differ by 0.480 nat, Calculator and pickle equal the seeded replica to 3.8e-13)"))
add_check(c, ['infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props'],
          'audit/checks/refs/it_kozachenko.py:chk_copy_props with audit/checks/probes/it_kozachenko_probes.py:copy_props', "1/1 pass; deepcopy NOISE_SEED 'NONE' on all 7 identifiers, original and pickle 42")
c['check_reference'] = c['check_reference'].rstrip() + '; chk_copy_props (property read-back on original / copy.deepcopy / pickle, probe copy_props) and the per-unit chk_frame runs'
c['check_data'] = c['check_data'].rstrip() + '; var2_bivariate T64 pipeline (copy-props)'
c['closeness'] = c['closeness'].rstrip() + (" Copy path (|var2_bivariate|64|pipeline|copy-props): NOISE_SEED reads 42 on the original and after a pickle round trip and 'NONE' after copy.deepcopy for all 7 identifiers; "
    "NOISE_LEVEL_TO_ADD 1e-8 on all three.")
c['score_0_10'] = 1
c['what_changed'] = ("For estimates with <= 2000 rows JIDT computes the canonical Kozachenko-Leonenko estimate (Euclidean norm, k = 1, psi(N) - psi(1), nats) to fp precision; the only convention is the seeded "
    "1e-8 jitter (effect <= 2.7e-4 nat, from d = 1 terms). For > 2000 rows JIDT switches to EuclideanUtils.computeMinEuclideanDistancesNaive, whose early exit compares a squared partial sum with the un-squared "
    "running minimum; in d >= 2 it returns a distance shorter than the nearest-neighbour distance at points whose true NN distance exceeds 1, so the output is no longer the KL estimate (iid N(0,1): -0.038 nat at d=5, "
    "-4.33 nat at d=10, N=4096) and the scale law fails. Score: rubric anchor 1 (wrong estimator substituted): above 2000 rows the delegate replaces the nearest-neighbour distance by a different distance. "
    "The <= 2000-row computation on its own would rate 9 (anchor 9, jitter convention). This defect is scored here, on the shared estimator unit, and carried as an inherited finding (not re-scored) on the composed units. "
    "NORMALISE reads true but is not applied; BIAS_CORRECTION is ignored. " + FR_WHAT)
c['check_cost'] = c['check_cost'].rstrip() + '; copy-props probe 3.5 s'
save(u, d)

# ---------------------------------------------------------------- composed units
def comp(u, frame_runs, ev, outcome, cl, extra=None):
    d = load(u); c = d['correctness']
    n = fix_trace(c, [(CALC_OLD, CALC_NEW),
                      ('pyspi/calculator.py:264,294', CALC_NEW),
                      ('pyspi/statistics/infotheory.py:103-110,84-93', "pyspi/statistics/infotheory.py:103-110 _getcalc('entropy') -> EntropyCalculatorMultiVariateKozachenko(); pyspi/statistics/infotheory.py:91 calc.setProperty(self._SEED, '42') (NOISE_SEED=42, in _setup :84-93)")])
    assert n >= 1, (u, n)
    add_frame(u, c, frame_runs, ev, outcome, cl, FR_WHAT)
    if extra:
        extra(c)
    save(u, d)
    return n

# je
def je_extra(c):
    c['candidate_resolutions'][1]['evidence'] = ("infotheory.je.kozachenko|shared_envelope|1024|pipeline|ties (rows 0-2: -28.809, move 9.2103 nat for jitter 1e-8 -> 1e-6, replica to 5.3e-14): confirmed for shared_envelope. "
        "For logistic_maps the trace's expectation of a many-nat move is refuted: |logistic_maps|1024|pipeline|ties moves 3.9e-3 nat (about 2400 times smaller than shared_envelope; the run fails its own 1e-3 rule).")
comp('je.kozachenko', ['infotheory.je.kozachenko|var2_bivariate|1024|pipeline|frame', 'infotheory.je.kozachenko|shared_envelope|1024|pipeline|frame'],
     "infotheory.je.kozachenko|var2_bivariate|1024|pipeline|frame (frame - Calculator 6.3e-8 / 7.7e-8), |shared_envelope|1024|pipeline|frame (A[0,1]: Calculator -28.8094, frames -28.7913 / -28.7975; frames differ by 0.0776); infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props",
     "2/2 pass; Calculator and pickle = seeded replica <= 5.3e-14; frames differ from the Calculator by <= 7.7e-8 (var2) and 0.061 (shared_envelope)",
     "CalculatorFrame path (|frame runs): Calculator and pickle equal the seeded replica (8.9e-16 var2, 5.3e-14 shared_envelope); two CalculatorFrame objects differ from the Calculator by 6.3e-8 / 7.7e-8 on var2_bivariate T1024 and by 0.061 / 0.042 on shared_envelope T1024 (A[0,1] -28.8094 vs -28.7913 / -28.7975), and from each other by 1.4e-8 / 0.078.",
     je_extra)

# ce
def ce_extra(c):
    c['candidate_resolutions'][1] = {'candidate': "documentation keyword 'undirected' while the class is Directed and values are asymmetric",
        'outcome': 'confirmed',
        'evidence': ("infotheory.ce.kozachenko|anm|1024|pipeline|kl (max|A - A.T| 0.262), |var2_bivariate|1024|pipeline|kl (0.0232), |nonlinear_dependence|1024|pipeline|direction (0.410); supplement 1.4.2 keyword list. "
                     "The asymmetry is the conditioning order ce = H(i,j) - H(i) already documented in REVIEW M8, and the keyword question falls under M9 (label structure): recorded as an elaboration of M8/M9, "
                     "not as a new finding (as infotheory.ce.kernel)")}
    c['checks_run'].append({'run_ids': ['infotheory.ce.kozachenko|bivariate_gaussian|256|pipeline|rho-order', 'infotheory.ce.kozachenko|bivariate_gaussian|1024|pipeline|rho-order',
                                        'infotheory.ce.kozachenko|bivariate_gaussian|4096|pipeline|rho-order'],
                            'reference': 'audit/checks/refs/it_kozachenko.py:chk_rho_order (population H1 + 0.5 ln(1 - rho^2) ordering; jitter replica, port above 2000 rows)',
                            'outcome': '3/3 pass; rho=0.8 cells below rho=0.3 cells by 0.419 / 0.393 / 0.406 nat (T256 / T1024 / T4096)'})
    c['checks_run'].append({'run_ids': ['infotheory.ce.kozachenko|nonlinear_dependence|1024|pipeline|direction'],
                            'reference': 'audit/checks/refs/it_kozachenko.py:chk_dir (orientation vs the H(z_j | z_i) replica and its transpose)',
                            'outcome': '1/1 pass; replica 2.8e-14, transpose 0.410; A[0,1] = -0.354 < A[1,0] = -0.313'})
    c['check_data'] = c['check_data'].rstrip() + '; bivariate_gaussian T256/T1024/T4096 all 4 rows (rho-order); nonlinear_dependence T1024; var2_bivariate T1024 (frame)'
    c['check_reference'] = c['check_reference'].rstrip() + ', chk_rho_order'
    c['closeness'] = c['closeness'].rstrip() + (" Ordering by rho (|bivariate_gaussian|<T>|pipeline|rho-order, all 4 rows): both rho=0.8 cells below both rho=0.3 cells at every T "
        "(T256 0.899/0.937 vs 1.358/1.355; T1024 0.940/0.999 vs 1.392/1.412; T4096 0.935/0.925 vs 1.342/1.344; population 0.908 vs 1.372), replica <= 3.3e-14. "
        "nonlinear_dependence (x1 = x0^2 + 0.05 e): A[0,1] = H(x1|x0) = -0.354 < A[1,0] = H(x0|x1) = -0.313 (margin 0.042), replica 2.8e-14, transpose off by 0.410; circle pair A[2,3] = -4.0945 vs A[3,2] = -4.0932.")
    c['direction_observed'] = c['direction_observed'].rstrip() + '; nonlinear_dependence: A[0,1] = H(x1|x0) = -0.354 < A[1,0] = H(x0|x1) = -0.313, i.e. lower when the column process is nearly a function of the row process'
    c['symmetry_observed'] = c['symmetry_observed'].rstrip() + ', 0.410 (nonlinear_dependence)'
    c['what_changed'] = c['what_changed'].replace("while the supplement keyword says 'undirected'.", "while the supplement keyword says 'undirected' (conditioning order REVIEW M8, keyword M9: an elaboration, not a new finding).")
comp('ce.kozachenko', ['infotheory.ce.kozachenko|var2_bivariate|1024|pipeline|frame'],
     "infotheory.ce.kozachenko|var2_bivariate|1024|pipeline|frame (frame - Calculator 3.4e-4 / 1.9e-4; frames differ by 1.6e-4); infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props",
     "1/1 pass; Calculator and pickle = seeded replica 8.9e-16; frames differ from the Calculator by <= 3.4e-4",
     "CalculatorFrame path (|var2_bivariate|1024|pipeline|frame): Calculator and pickle equal the seeded replica to 8.9e-16; two CalculatorFrame objects differ from the Calculator by 3.4e-4 / 1.9e-4 and from each other by 1.6e-4 (frame - canonical KL <= 2.0e-4).",
     ce_extra)

# cce
def cce_extra(c):
    c['score_0_10'] = 7
    c['what_changed'] = ("Kramer's causally conditioned entropy H(Y^n || X^n), present x included, computed exactly with canonical KL (jitter convention) for T <= 2004, with n = 5 where the supplement documents 10 "
        "(same composition as cce_gaussian and cce_kernel; anchor 7). From T = 2005 every term has > 2000 rows and the JIDT naive NN routine lowers the value by about 2-2.6 nat: inherited from "
        "infotheory.est.kozachenko, where it is scored, and carried here as a finding, not deducted. Labelled 'linear'. " + FR_WHAT)
comp('cce.kozachenko', ['infotheory.cce.kozachenko|var2_bivariate|1024|pipeline|frame', 'infotheory.cce.kozachenko|shared_envelope|1024|pipeline|frame'],
     "infotheory.cce.kozachenko|var2_bivariate|1024|pipeline|frame (frame - Calculator 2.1e-4 / 4.7e-5), |shared_envelope|1024|pipeline|frame (frames differ from the Calculator by 0.360 / 0.376 and from each other by 0.480; A[1,0] -84.373 vs -84.095 / -84.204); infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props",
     "2/2 pass; Calculator and pickle = seeded replica <= 3.8e-13; frames differ from the Calculator by <= 2.1e-4 (var2) and 0.376 (shared_envelope)",
     "CalculatorFrame path (|frame runs): Calculator and pickle equal the seeded replica (3.7e-14 var2, 3.8e-13 shared_envelope); two CalculatorFrame objects differ from the Calculator by 2.1e-4 / 4.7e-5 on var2_bivariate T1024 (A[0,1] 6.211631 vs 6.211839 / 6.211638) and by 0.360 / 0.376 on shared_envelope T1024 (A[1,0] -84.373 vs -84.095 / -84.204), and from each other by 2.6e-4 / 0.480.",
     cce_extra)

# di
def di_extra(c):
    c['score_0_10'] = 4
    c['what_changed'] = ("First term is sum_{m=1..5} H(Y^m)/m, not H(Y^5): pyspi DI = Massey DI_5 + B(target), B >= 0 in population and driven by the target's autocorrelation (same composition as di_gaussian "
        "and di_kernel; anchor 4, 'DI with block-entropy rate'), so independent autocorrelated pairs get large positive values (2.5-2.8 nat for random walks); on white targets B is about 0. n = 5 instead of 10. "
        "From T = 2005 the JIDT naive NN routine corrupts the CCE and block terms (iid pair 2.61 instead of 0.03): inherited from infotheory.est.kozachenko, where it is scored, and carried here as a finding, "
        "not deducted. Labelled 'linear'. " + FR_WHAT)
    c['checks_run'].append({'run_ids': ['infotheory.di.kozachenko|iid_gaussian|1024|pipeline|massey-identity', 'infotheory.di.kozachenko|gauss_ar1_pair|1024|pipeline|massey-identity'],
                            'reference': 'audit/checks/refs/it_kozachenko.py:chk_massey_identity (sample identity with the jitter replica; population B from refs/it_gaussian.py:pop_di_excess_univariate; Gaussian plug-in B from refs/_kernels_infotheory.py:di_block_term)',
                            'outcome': '2/2 pass; identity 7.1e-14 / 3.4e-14; iid gap pyspi - Massey in [-0.105, 0.070] (|gap| <= 0.15), Gaussian plug-in |B| <= 0.0096; gauss_ar1_pair B_KL 0.331/0.302 vs population 0.351/0.305'})
    c['check_data'] = c['check_data'].rstrip() + '; iid_gaussian T1024 and gauss_ar1_pair T1024 (massey-identity); var2_bivariate T1024 (frame)'
    c['closeness'] = c['closeness'].rstrip() + (" Block term on white and AR(1) targets (|massey-identity): iid_gaussian T1024 (5 rows, 20 cells) identity 7.1e-14, gap pyspi - Massey in [-0.105, 0.070] (mean 0.009, "
        "so |gap| <= 0.15 as the trace expected), Gaussian plug-in B in [-0.0053, 0.0096], population B = 0; gauss_ar1_pair T1024 identity 3.4e-14, B_KL 0.331 (target 0) / 0.302 (target 1), Gaussian plug-in 0.358 / 0.361, "
        "population 0.351 / 0.305.")
    r0 = c['candidate_resolutions'][0]
    r0['evidence'] = r0['evidence'].rstrip() + ("; |iid_gaussian|1024|pipeline|massey-identity (white targets: gap within [-0.105, 0.070], Gaussian plug-in |B| <= 0.0096), "
        "|gauss_ar1_pair|1024|pipeline|massey-identity (B_KL 0.331/0.302 vs population 0.351/0.305)")
comp('di.kozachenko', ['infotheory.di.kozachenko|var2_bivariate|1024|pipeline|frame'],
     "infotheory.di.kozachenko|var2_bivariate|1024|pipeline|frame (frame - Calculator 3.0e-4 / 2.2e-4; frames differ by 1.7e-4); infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props",
     "1/1 pass; Calculator and pickle = seeded replica 3.7e-14; frames differ from the Calculator by <= 3.0e-4",
     "CalculatorFrame path (|var2_bivariate|1024|pipeline|frame): Calculator and pickle equal the seeded replica to 3.7e-14; two CalculatorFrame objects differ from the Calculator by 3.0e-4 / 2.2e-4 and from each other by 1.7e-4.",
     di_extra)

# si
def si_extra(c):
    c['candidate_resolutions'][0] = {'candidate': 'nonzero, sign-varying null values and a large relative bias on a known Gaussian process (two parts)',
        'outcome': 'refuted',
        'evidence': ("Split. Part 1 (nonzero, sign-varying null values) is observed but is not a deviation: infotheory.si.kozachenko|iid_gaussian|256|pipeline|null (mean -0.046, 5/10 negative) and "
                     "|1024|pipeline|null (mean 0.088, 3/10 negative) both lie inside the Monte Carlo distribution of the canonical KL estimator, i.e. estimator sampling variance. Part 2 (large relative bias) is refuted: "
                     "|gauss_ar1_pair|1024|pipeline|truth canonical MC mean 0.123 vs population 0.0999, SD 0.118, so 0.025 is a draw. The candidate as a finding is therefore refuted; part 1 stays in what_changed as estimator behaviour.")}
    c['what_changed'] = c['what_changed'].replace("the > 2000-row defect changes T = 4096 values by about 2e-3.",
        "the > 2000-row defect changes T = 4096 values by about 2e-3 (inherited from infotheory.est.kozachenko, where it is scored; small against the MC SD, not deducted).")
comp('si.kozachenko', ['infotheory.si.kozachenko|var2_bivariate|1024|pipeline|frame'],
     "infotheory.si.kozachenko|var2_bivariate|1024|pipeline|frame (frame - Calculator 2.1e-4 / 1.1e-4; frames differ by 1.0e-4); infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props",
     "1/1 pass; Calculator and pickle = seeded replica 6.2e-15; frames differ from the Calculator by <= 2.1e-4",
     "CalculatorFrame path (|var2_bivariate|1024|pipeline|frame): Calculator and pickle equal the seeded replica to 6.2e-15; two CalculatorFrame objects differ from the Calculator by 2.1e-4 / 1.1e-4 and from each other by 1.0e-4.",
     si_extra)

# xme_k1
comp('xme.kozachenko_k1', ['infotheory.xme.kozachenko_k1|var2_bivariate|1024|pipeline|frame'],
     "infotheory.xme.kozachenko_k1|var2_bivariate|1024|pipeline|frame (frame - Calculator 5.0e-4 / 5.1e-5; frames differ by 4.5e-4); infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props",
     "1/1 pass; Calculator and pickle = seeded replica 7.1e-15; frames differ from the Calculator by <= 5.0e-4",
     "CalculatorFrame path (|var2_bivariate|1024|pipeline|frame): Calculator and pickle equal the seeded replica to 7.1e-15; two CalculatorFrame objects differ from the Calculator by 5.0e-4 / 5.1e-5 and from each other by 4.5e-4.")

# xme_k10
def k10_extra(c):
    c['score_0_10'] = 4
    c['what_changed'] = ("No documented definition; H(x_j(t) | x_i(t-1..t-9)): history_length=10 uses 9 source lags, so the identifier does not describe the lag set (anchor 4, as infotheory.xme.gaussian_k10 "
        "and infotheory.xme.kernel_k10). In d = 10 the k=1 KL estimate is strongly biased for a near-deterministic relation (+1.5 nat at T = 1024, an estimator property). From T = 2011 (> 2000 rows per estimate) "
        "the JIDT naive NN routine drops the value by about 1.6 nat and can flip its sign: inherited from infotheory.est.kozachenko, where it is scored, and carried here as a finding, not deducted. Labelled 'linear'. " + FR_WHAT)
comp('xme.kozachenko_k10', ['infotheory.xme.kozachenko_k10|var2_bivariate|1024|pipeline|frame'],
     "infotheory.xme.kozachenko_k10|var2_bivariate|1024|pipeline|frame (frame - Calculator 1.3e-8 / 6.8e-9; frames differ by 6.6e-9; d >= 2 terms only, so the jitter effect is small); infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props",
     "1/1 pass; Calculator and pickle = seeded replica 1.4e-14; frames differ from the Calculator by <= 1.3e-8",
     "CalculatorFrame path (|var2_bivariate|1024|pipeline|frame): Calculator and pickle equal the seeded replica to 1.4e-14; two CalculatorFrame objects differ from the Calculator by 1.3e-8 / 6.8e-9 (all terms d >= 2).",
     k10_extra)
print('done')
