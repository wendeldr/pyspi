import sys; sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import it_kozachenko as R, make_data, numpy as np
z = R.zs(make_data.load('var2_bivariate',1024)['x']); h = R.Hf('jrand')
for t in (1, 0):
    s = 1 - t
    cce = R.cce_val(z[s], z[t], 5, h)
    pys = R.rates_val(z[t], 5, h); mas = R.massey_target_val(z[t], 5, h); H5 = h(R.K.embed(z[t], 5))
    print(f"src{s}->tgt{t}: cce {cce:.4f} pyspi-term {pys:.4f} (DI {pys-cce:.4f}) | Massey H(Y^5) via chain {mas:.4f} (DI {mas-cce:.4f}) | joint H_KL(Y^5) {H5:.4f} (DI {H5-cce:.4f}) | rate H5/5 {H5/5:.4f} (DI {H5/5-cce:.4f})")
