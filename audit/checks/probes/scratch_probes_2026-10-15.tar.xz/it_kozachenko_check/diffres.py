import json,sys,math
a=json.load(open(sys.argv[1])); b=json.load(open(sys.argv[2]))
print('keys before/after', len(a), len(b), 'only before', set(a)-set(b), 'only after', set(b)-set(a))
nd=0
def num(x):
    return isinstance(x,(int,float)) and not isinstance(x,bool)
for k in sorted(set(a)&set(b)):
    ra, rb = a[k], b[k]
    for f in set(ra)|set(rb):
        x,y=ra.get(f),rb.get(f)
        if f in ('time_s','ref_time_s','timestamp') : continue
        if num(x) and num(y):
            if not (x==y or (math.isnan(x) and math.isnan(y)) or abs(x-y)<=1e-9*max(1,abs(x))):
                nd+=1; print('DIFF',k,f,x,y) if nd<40 else None
        elif x!=y and not (isinstance(x,float) and isinstance(y,float)):
            nd+=1; print('DIFF',k,f,str(x)[:80],str(y)[:80]) if nd<40 else None
print('ndiff',nd)
print(json.dumps(b[sorted(b)[0]])[:800])
