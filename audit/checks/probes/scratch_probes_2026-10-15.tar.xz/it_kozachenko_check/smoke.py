import sys, time, importlib.util, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
from regression import harness
harness.ensure_jvm(); harness.import_statistics_modules()
import make_data
spec = importlib.util.spec_from_file_location('pr', '/media/dan/Data/git/pyspi/audit/checks/probes/it_kozachenko_probes.py')
pr = importlib.util.module_from_spec(spec); spec.loader.exec_module(pr)
x = make_data.load('iid_gaussian', 4096)['x']
for fn in ['properties', 'labels', 'determinism', 'ties', 'configured_n', 'scale_law', 'scale_law_naive']:
    t=time.time(); v = getattr(pr, fn)(x if fn!='ties' else make_data.load('iid_gaussian',256)['x'], {'run_id': 'a|b|c|d|x', 'T': 4096}); print(fn, f'{time.time()-t:.2f}s', np.round(v, 6).tolist()[:21])
t=time.time(); v = pr.nn_routines(x, {'run_id':'a|nn','T':4096}); print('nn', time.time()-t, v.shape)
t=time.time(); v = pr.xme10_threshold(x, {'run_id':'a|thr','T':4096}); print('thr', time.time()-t, v)
