from pathlib import Path
p = Path('/media/dan/Data/git/pyspi/audit/notes/it_kozachenko.md')
s = p.read_text()

def rep(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:80], s.count(old))
    s = s.replace(old, new)

rep("3. Data arrive z-scored with ddof=1 (`calculator.py:264`, `data.py:193-195`).",
    "3. Data arrive z-scored with ddof=1 (`calculator.py:277` at HEAD, `data.py:193-195`).")

rep("**Setup.** The manifest `audit/checks/manifest/it_kozachenko.json` has 166 runs.",
    "**Setup.** The manifest `audit/checks/manifest/it_kozachenko.json` has 182 runs (166 from the first check pass plus 16 added after the adversarial review: the copy-path runs, the ce ordering and nonlinear_dependence runs, and the di block-term runs on white and AR(1) targets).")
rep("Results (`audit/checks/out/results/it_kozachenko.json`): **147 pass, 19 fail, 0 without reference, no script errors**. Every failure is listed below with its cause; none comes from a reference error. The pyspi side took 259 s in total (166 runs, under machine load; longest the nn-routines probe 17 s and di on bivariate_gaussian T=1024 14 s); `run_checks.py --family it_kozachenko` with cached pyspi outputs took 3.5 min wall, mostly the Monte Carlo runs.",
    "Results (`audit/checks/out/results/it_kozachenko.json`, re-run with `--force`): **163 pass, 19 fail, 0 without reference, no script errors**. The 16 added runs all pass, and the 19 failures are the same runs as before. Every failure is listed below with its cause; none comes from a reference error. The pyspi side took 291 s in total (182 runs, under machine load; longest cce CalculatorFrame on shared_envelope 21 s, di massey-identity on iid_gaussian T=1024 14 s, nn-routines 12 s); the references took about 4 min wall, mostly the Monte Carlo runs.")

# score policy + copy path section, inserted before the est section
rep("### Shared estimator `infotheory.est.kozachenko`: wrong, score 3\n",
"""**Score policy (applied after review).** A composed unit is scored on its composition, using the formula anchor that the it_gaussian and it_kernel siblings use. The JIDT > 2000-row nearest-neighbour defect is in the shared estimator. It is scored once, on `infotheory.est.kozachenko`, and carried on cce, di, si and xme_k10 as an inherited finding (`what_changed`, `new_finding`) with no deduction. Path-dependent defects (the CalculatorFrame copy path below) are carried as findings and not scored, as in it_kernel. The first pass lowered cce (7 → 5), di (4 → 3) and xme_k10 (4 → 3) for the inherited defect but not si (2.2e-3 at T4096) or je/ce. That was inconsistent, so those three are now back at their formula anchors.

**Copy (CalculatorFrame) path, added after review.** `CalculatorFrame.init_from_list` deep-copies the base Calculator (`pyspi/calculator.py:559`). `JIDTBase.__deepcopy__` (`pyspi/statistics/infotheory.py:77-82`) builds `type(self)()` and deep-copies every attribute without re-running `_setup`, and the JPype calculator proxy comes back in JIDT's default state.
- **Properties** (`infotheory.est.kozachenko|var2_bivariate|64|pipeline|copy-props`, pass): for all seven identifiers NOISE_SEED reads 42 on the original, 'NONE' after `copy.deepcopy` and 42 after a pickle round trip (`__setstate__` → `_getcalc` → `_setup`). NOISE_LEVEL_TO_ADD reads 1e-8 on all three. So the frame-path calculator still adds the 1e-8 jitter, but from an unseeded `Random`.
- **Values** (`<unit>|var2_bivariate|1024|pipeline|frame` for all seven SPIs, plus je and cce on shared_envelope T1024; all pass). In every run the Calculator and pickle slices equal the seeded replica (≤ 3.8e-13), and two separate CalculatorFrame objects differ from the Calculator and from each other:

  | Run | frame A − Calculator | frame B − Calculator | frame A − frame B |
  |---|---|---|---|
  | je var2 | 6.3e-8 | 7.7e-8 | 1.4e-8 |
  | ce var2 | 3.4e-4 | 1.9e-4 | 1.6e-4 |
  | cce var2 | 2.1e-4 | 4.7e-5 | 2.6e-4 |
  | xme_k1 var2 | 5.0e-4 | 5.1e-5 | 4.5e-4 |
  | xme_k10 var2 | 1.3e-8 | 6.8e-9 | 6.6e-9 |
  | di var2 | 3.0e-4 | 2.2e-4 | 1.7e-4 |
  | si var2 | 2.1e-4 | 1.1e-4 | 1.0e-4 |
  | je shared_envelope | 0.061 | 0.042 | 0.078 |
  | cce shared_envelope | 0.360 | 0.376 | 0.480 |

  (max |·| over the matrix). On continuous data the frame values remain KL estimates with another jitter draw (frame − canonical KL ≤ 3.6e-4, within the 5e-4 jitter allowance), so the effect is non-reproducibility at the d = 1 jitter level. On the near-tied shared_envelope rows the frame values differ by up to 0.48 nat between two runs on the same data. The reviewer's probe (scratchpad `verify_it_kozachenko_it_kernel/p_copy2.py`) found the same effect.
- **Finding.** CalculatorFrame outputs of every kozachenko SPI are not reproducible. The mechanism is the one it_kernel confirmed for KERNEL_WIDTH (`infotheory.est.kernel|bivariate_gaussian|256|pipeline|copy-props`). It is not in KNOWN_ISSUES.md, so it is recorded as a new finding candidate (confirmed) on all eight records.

### Shared estimator `infotheory.est.kozachenko`: wrong, score 1 (anchor 1: above 2000 rows a non-nearest-neighbour distance is substituted)
""")

rep("- **Verdict.** The score is set by the > 2000-row regime, where the output is not the KL estimate. The rubric has no anchor for a size-dependent implementation defect; 3 is my judgement, and the ≤ 2000-row computation on its own would rate 9 (jitter convention).",
    "- **Copy path.** NOISE_SEED is honoured on the Calculator path and after a pickle round trip, but not after `copy.deepcopy` (`…|var2_bivariate|64|pipeline|copy-props`). The determinism result above therefore holds for the Calculator path only.\n"
    "- **Verdict.** The verdict is wrong, score 1. In the > 2000-row regime JIDT replaces the nearest-neighbour distance with a different (partial-sum) distance, so the output is not the KL estimate. That is rubric anchor 1 (wrong estimator substituted). The first pass gave 3, which has no rubric basis: anchor 3 covers an ignored hyperparameter or a label that does not describe the computation. The ≤ 2000-row computation on its own would rate 9 (jitter convention). Under the score policy above, this is the only unit scored for the defect.")

# je
rep("- **`je|logistic_maps|1024|pipeline|ties` fails.** The pair moves by 3.9e-3 nat, above the 1e-3 I set before running. It is jitter-sensitive, but four orders of magnitude less than shared_envelope.",
    "- **`je|logistic_maps|1024|pipeline|ties` fails.** The pair moves by 3.9e-3 nat, above the 1e-3 I set before running. It is mildly jitter-sensitive, about 2400 times (three to four orders of magnitude) less than shared_envelope. The trace expected the logistic_maps pairs to move by many nats, and that expectation is refuted.\n"
    "- **Copy path** (`je|var2_bivariate|1024|pipeline|frame`, `je|shared_envelope|1024|pipeline|frame`, both pass). The frame slices differ from the Calculator by ≤ 7.7e-8 on var2 and by 0.061 on shared_envelope (A[0,1] −28.8094 vs −28.7913 / −28.7975).")
rep("- **Candidates:** 'linear' label confirmed; jitter-set value on near-tied rows confirmed.",
    "- **Candidates:** 'linear' label confirmed. Jitter-set value on near-tied rows: confirmed for shared_envelope, while logistic_maps is only mildly sensitive (above). Copy path confirmed.")

# ce
rep("- **Symmetry:** asymmetric even after z-scoring (0.023 on var2, 0.262 on anm), unlike ce_gaussian.\n- **Candidates:** 'linear' label confirmed. The 'undirected' keyword conflict is confirmed: Directed class, asymmetric values.",
    "- **Ordering by ρ** (`ce|bivariate_gaussian|{256,1024,4096}|pipeline|rho-order`, all four rows, 3/3 pass). Both ρ = 0.8 cells lie below both ρ = 0.3 cells at every T: 0.899/0.937 vs 1.358/1.355 at T256, 0.940/0.999 vs 1.392/1.412 at T1024, and 0.935/0.925 vs 1.342/1.344 at T4096 (population 0.908 vs 1.372). Margins are 0.419 / 0.393 / 0.406 nat, and the replica matches to ≤ 3.3e-14.\n"
    "- **Orientation on nonlinear_dependence** (`ce|nonlinear_dependence|1024|pipeline|direction`, pass). pyspi equals the H(z_j | z_i) replica to 2.8e-14 and differs from its transpose by 0.410. For x1 = x0² + 0.05e, A[0,1] = H(x1|x0) = −0.354 < A[1,0] = H(x0|x1) = −0.313 (margin 0.042). The circle pair is nearly symmetric (−4.0945 vs −4.0932).\n"
    "- **Symmetry:** asymmetric even after z-scoring (0.023 on var2, 0.262 on anm, 0.410 on nonlinear_dependence), unlike ce_gaussian.\n"
    "- **Copy path** (`ce|var2_bivariate|1024|pipeline|frame`, pass): the frames differ from the Calculator by ≤ 3.4e-4.\n"
    "- **Candidates:** 'linear' label confirmed. The 'undirected' keyword vs asymmetric Directed values is confirmed, but as an elaboration of REVIEW M8 (ce = H(i,j) − H(i), the conditioning order) and M9 (label structure), as it_kernel records it. It is not a new finding of this family; ce's `new_finding` rests on the 'linear' label and the copy path. Copy path confirmed.")

# xme_k1
rep("- **Candidates:** documentation/naming confirmed; label confirmed.\n\n### xme_k10: related-quantity, score 3 (anchor 3: the identifier's history length does not describe the lag set; plus the defect regime)",
    "- **Copy path** (`xme_k1|var2_bivariate|1024|pipeline|frame`, pass): the frames differ from the Calculator by ≤ 5.0e-4.\n- **Candidates:** documentation/naming confirmed; label confirmed; copy path confirmed.\n\n### xme_k10: related-quantity, score 4 (anchor 4, as xme.gaussian_k10 and xme.kernel_k10: 9 lags under history_length = 10; the defect regime is inherited, not deducted)")
rep("- **Direction:** delayed_noise 6/6 pairs, var2 1/1.\n- **Candidates:** off-by-one confirmed; defect confirmed; documentation confirmed; label confirmed.",
    "- **Direction:** delayed_noise 6/6 pairs, var2 1/1.\n- **Copy path** (`xme_k10|var2_bivariate|1024|pipeline|frame`, pass): the frames differ from the Calculator by ≤ 1.3e-8 (all terms have d ≥ 2).\n- **Candidates:** off-by-one confirmed; defect confirmed (inherited, scored on est); documentation confirmed; label confirmed; copy path confirmed.")

# cce
rep("### cce: variant, score 5 (anchor 7 for the n = 5 variant as in cce_gaussian, lowered for the T ≥ 2005 defect)",
    "### cce: variant, score 7 (anchor 7: the n = 5 variant, as cce_gaussian and cce_kernel; the T ≥ 2005 defect is inherited, not deducted)")
rep("- **Candidates:** n = 5 confirmed (cross-estimator, as `infotheory.cce.gaussian|var2_bivariate|64|pipeline|configured-n`); defect confirmed; label confirmed.",
    "- **Copy path** (`cce|var2_bivariate|1024|pipeline|frame`, `cce|shared_envelope|1024|pipeline|frame`, both pass): the frames differ from the Calculator by ≤ 2.1e-4 on var2 (A[0,1] 6.211631 vs 6.211839 / 6.211638) and by 0.360 / 0.376 on shared_envelope. The two frames differ from each other by 0.480.\n"
    "- **Candidates:** n = 5 confirmed (cross-estimator, as `infotheory.cce.gaussian|var2_bivariate|64|pipeline|configured-n`); defect confirmed (inherited, scored on est); label confirmed; copy path confirmed.")

# di
rep("### di: related-quantity, score 3 (anchor 4 as in di_gaussian, lowered for the defect)",
    "### di: related-quantity, score 4 (anchor 4: DI with block-entropy rate, as di_gaussian and di_kernel; the defect is inherited, not deducted)")
rep("  - Independent random walks (`di|cointegrated|1024|pipeline|massey-identity`): B_KL = 2.52/2.77 against Massey 0.51/0.41.",
    "  - Independent random walks (`di|cointegrated|1024|pipeline|massey-identity`): B_KL = 2.52/2.77 against Massey 0.51/0.41.\n"
    "  - White targets (`di|iid_gaussian|1024|pipeline|massey-identity`, five rows, 20 cells, pass). The identity holds to 7.1e-14. The gap pyspi − Massey lies in [−0.105, 0.070] (mean 0.009), so |gap| ≤ 0.15 as the trace expected. The Gaussian plug-in B is in [−0.0053, 0.0096], against a population B of 0.\n"
    "  - AR(1) targets (`di|gauss_ar1_pair|1024|pipeline|massey-identity`, pass). The identity holds to 3.4e-14. B_KL = 0.331 (target 0) / 0.302 (target 1), the Gaussian plug-in gives 0.358 / 0.361, and the population B (`refs/it_gaussian.py:pop_di_excess_univariate`) is 0.351 / 0.305.")
rep("- **Direction:** 3/3 (logistic_maps_bidir: A[1,0] = 2.163 > A[0,1] = 0.674).\n- **Candidates:** all four confirmed.",
    "- **Direction:** 3/3 (logistic_maps_bidir: A[1,0] = 2.163 > A[0,1] = 0.674).\n- **Copy path** (`di|var2_bivariate|1024|pipeline|frame`, pass): the frames differ from the Calculator by ≤ 3.0e-4.\n- **Candidates:** all four confirmed (the defect is inherited and scored on est); copy path confirmed.")

# si
rep("- **Symmetry:** 0.0.\n- **Candidates:** sign-varying null confirmed (bias part refuted); label confirmed.",
    "- **Symmetry:** 0.0.\n- **T4096 defect.** The 2.2e-3 shift is inherited from est and is not deducted (score policy). It is small against the MC SD.\n- **Copy path** (`si|var2_bivariate|1024|pipeline|frame`, pass): the frames differ from the Calculator by ≤ 2.1e-4.\n"
    "- **Candidates.** The trace candidate 'nonzero, sign-varying null values and a large relative bias' is recorded as refuted, with the two parts split in the evidence:\n"
    "  - the sign-varying nulls are observed, but they lie inside the canonical estimator's Monte Carlo distribution, so they are sampling variance and not a deviation;\n"
    "  - the bias part is refuted (MC mean 0.123 vs population 0.0999, SD 0.118).\n"
    "  - The 'linear' label and the copy path are confirmed.")

# failures table unchanged; corrections
rep("- The est record's jitter magnitude is extended with check-stage numbers (see the next list).",
    "- The est record's jitter magnitude is extended with check-stage numbers (see the next list).\n"
    "- The trace's open question 5 expected the logistic_maps pairs to move by many nats with the jitter. The measured move is 3.9e-3 nat, so this part is refuted (`je|logistic_maps|1024|pipeline|ties`).\n"
    "- The est record's 'NOISE_SEED honoured' (provenance candidate) now carries the qualifier 'Calculator and pickle paths only'. A deepcopy reads 'NONE' (`est|var2_bivariate|64|pipeline|copy-props`).")
rep("""2. **Jitter magnitude.** `infotheory.est.kozachenko` `deviation_from_canonical` (a) now ends with the check-stage jitter numbers:""",
    """2. **Stale citations.** The `pyspi/calculator.py:48,264` and `:264,294,297` citations in all eight `implementation_trace` lists now point at HEAD: `:277` (Data(..., normalise=self._normalise)), `:329` (multivariate) and `:332` (fill_diagonal). The je/ce NOISE_SEED citation now names `infotheory.py:91`, the setProperty line. `audit/checks/citations.py` reports no stale, token-miss or out-of-range citations in the family's records and note.
3. **Jitter magnitude.** `infotheory.est.kozachenko` `deviation_from_canonical` (a) now ends with the check-stage jitter numbers:""")

# open questions
rep("""   - **Pinning:** the check shows that the shipped build's seeded jitter makes every kozachenko output reproducible to ≤ 6e-14 by an independent replica. The regression environment should therefore pin this jar, by checksum, rather than the v1.6.1 tag, whose unseeded `Random` would make outputs vary at the 1e-5 to 1e-4 nat level for d = 1 terms (the measured jitter effect).""",
    """   - **Pinning:** on the Calculator path, and after a pickle round trip, the shipped build's seeded jitter makes every kozachenko output reproducible to ≤ 6e-14 by an independent replica. The regression environment should therefore pin this jar, by checksum, rather than the v1.6.1 tag, whose unseeded `Random` would make outputs vary at the 1e-5 to 1e-4 nat level for d = 1 terms (the measured jitter effect).
   - **Pinning does not cover the CalculatorFrame path.** There the deep-copied calculator reads NOISE_SEED 'NONE' (`est|var2_bivariate|64|pipeline|copy-props`), so frame outputs vary between runs even with the pinned jar: by up to 5.0e-4 nat on var2_bivariate and up to 0.48 nat on the near-tied shared_envelope rows (`cce|shared_envelope|1024|pipeline|frame`). Reproducibility there needs a pyspi-side fix: re-run `_setup` after the copy, as `__setstate__` does.""")
rep("""5. **Dataset suitability.** Confirmed.
   - On shared_envelope rows 0–2, je is set by the jitter: it shifts by 2 ln 100 for a 100× jitter change.
   - On logistic_maps, the period-4 row makes je mildly jitter-sensitive (3.9e-3).""",
    """5. **Dataset suitability.** Confirmed for shared_envelope; refuted for logistic_maps, where the effect is three to four orders of magnitude smaller than the trace expected.
   - On shared_envelope rows 0–2, je is set by the jitter: it shifts by 2 ln 100 (9.2103 nat) for a 100× jitter change (`je|shared_envelope|1024|pipeline|ties`).
   - On logistic_maps, the trace expected the pairs to move by many nats. They move by 3.9e-3 nat (`je|logistic_maps|1024|pipeline|ties`, which fails its pre-set 1e-3 rule). The period-4 row is tied only in one dimension, and je in two dimensions stays nearly jitter-insensitive. So logistic_maps is only mildly unsuitable.""")
p.write_text(s)
print('ok')
