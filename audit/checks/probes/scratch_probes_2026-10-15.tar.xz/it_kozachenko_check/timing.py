import sys, time, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
from regression import harness
harness.ensure_jvm(); harness.import_statistics_modules()
import make_data
from pyspi.data import Data
from pyspi.statistics.infotheory import *
for T, P in ((1024, 2), (1024, 5), (4096, 2)):
    x = make_data.load('var2_bivariate', T)['x'] if P == 2 else make_data.load('iid_gaussian', T)['x']
    for name, spi in (('je', JointEntropy(estimator='kozachenko')), ('ce', ConditionalEntropy(estimator='kozachenko')),
                      ('xme1', CrossmapEntropy(history_length=1, estimator='kozachenko')),
                      ('xme10', CrossmapEntropy(history_length=10, estimator='kozachenko')),
                      ('cce', CausalEntropy(estimator='kozachenko')), ('di', DirectedInfo(estimator='kozachenko')),
                      ('si', StochasticInteraction(estimator='kozachenko'))):
        if T == 4096 and name in ('di',) and False: continue
        t0 = time.perf_counter(); S = harness.compute_spi(spi, Data(np.array(x), dim_order='ps')); dt = time.perf_counter() - t0
        print(T, P, name, f'{dt:.2f}s', np.round(S[0, 1], 4), flush=True)
