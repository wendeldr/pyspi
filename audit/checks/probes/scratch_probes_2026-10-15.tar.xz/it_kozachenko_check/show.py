import json, sys
r = json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/results/it_kozachenko.json'))
flt = sys.argv[1:] 
skip = {'family','unit_id','identifier','dataset','T','path','run_id','reference_detail','notes','criterion','reference_kind','nan_mask_equal','rtol','atol'}
for k, v in r.items():
    if flt and not any(f in k for f in flt): continue
    if v.get('pass') is None and 'no reference' in str(v.get('error')): continue
    ex = {kk: vv for kk, vv in v.items() if kk not in skip}
    print(('PASS' if v.get('pass') else 'FAIL'), k.replace('infotheory.', ''), v.get('criterion'), json.dumps(ex, default=str)[:900])
