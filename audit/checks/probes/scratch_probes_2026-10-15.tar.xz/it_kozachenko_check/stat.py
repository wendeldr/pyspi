import json, numpy as np, sys
r = json.load(open('audit/checks/out/results/it_kozachenko.json'))
for k, v in r.items():
    if v.get('criterion') != 'statistical': continue
    S = np.load(f'audit/checks/out/pyspi/{k}.npz')['value']
    z = np.load(f'audit/checks/out/ref/{k}.npz')
    def f(a):
        a = np.asarray(a, float); return np.round(a[~np.isnan(a)], 4).tolist() if a.ndim else round(float(a),4)
    print('PASS' if v['pass'] else 'FAIL', k.replace('infotheory.','').replace('|pipeline',''), 'pyspi', f(S), 'pop', f(z['value']), 'mc', f(z['mc_mean']), 'sd', f(z['mc_sd']), 'zpop', round(v['ref_z_vs_population'],2), 'zmc', round(v['ref_z_vs_mc_mean'],2), 'canon-pyspi', f(z['pyspi_minus_canonical_on_data_maxabs']) if 'pyspi_minus_canonical_on_data_maxabs' in z.files else '')
