"""Build checks_run entries per unit from results/it_kozachenko.json (imported by update_records.py)."""
import json, collections
R = json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/results/it_kozachenko.json'))
REF = "audit/checks/refs/it_kozachenko.py"
PR = "audit/checks/probes/it_kozachenko_probes.py"
FN = {"kl": f"{REF}:chk_comp mode kl (canonical KL via audit/checks/refs/_kernels_infotheory.py:entropy_kozachenko, tolerance atol 5e-4)",
      "jrand": f"{REF}:chk_comp mode jrand (canonical KL on input + java.util.Random(42) jitter replica, exact rtol/atol 1e-10)",
      "jidt": f"{REF}:chk_comp mode jidt (port of JIDT naive NN routine, same-lineage, mechanism only)",
      "noiseoff": f"{REF}:chk_noiseoff with {PR}:spi_noiseoff (exact vs canonical KL)",
      "truth": f"{REF}:chk_truth (population value, se = Monte Carlo SD of the canonical estimator)",
      "direction": f"{REF}:chk_dir (orientation vs jitter replica and its transpose; ground-truth ordering)",
      "order": f"{REF}:chk_order with {PR}:order_check",
      "ties": f"{REF}:chk_noise_sens with {PR}:noise_sensitivity",
      "shift-d2": f"{REF}:chk_je_shift with {PR}:je_scaled_shift",
      "k2-jrand": f"{REF}:chk_k2 with {PR}:xme_k2", "shift-jrand": f"{REF}:chk_shift_rep with {PR}:xme_shift",
      "shift-pattern": f"{REF}:chk_shift_pattern with {PR}:xme_shift", "threshold": f"{REF}:chk_threshold with {PR}:xme10_threshold",
      "n10-jrand": f"{REF}:chk_n10 with {PR}:cce_n10 / di_n10", "configured-n": f"{REF}:chk_configured_n with {PR}:configured_n",
      "massey": f"{REF}:chk_massey (Massey 1990 eq. 6 with canonical KL)", "massey-identity": f"{REF}:chk_massey_identity",
      "indep-jrand": f"{REF}:chk_indep_rep with {PR}:di_indep", "indep-truth": f"{REF}:chk_indep_truth with {PR}:di_indep",
      "null": f"{REF}:chk_null_si",
      "direct-noiseoff": f"{REF}:chk_est_direct mode kl with {PR}:est_direct", "direct-jrand": f"{REF}:chk_est_direct mode jrand with {PR}:est_direct",
      "direct-naive-noiseoff": f"{REF}:chk_est_direct mode jidt (same-lineage port) with {PR}:est_direct",
      "nn-routines": f"{REF}:chk_nn with {PR}:nn_routines", "scale-law": f"{REF}:chk_scale with {PR}:scale_law",
      "scale-law-naive": f"{REF}:chk_scale_naive with {PR}:scale_law_naive", "determinism": f"{REF}:chk_determinism with {PR}:determinism",
      "properties": f"{REF}:chk_properties with {PR}:properties", "labels": f"{REF}:chk_labels with {PR}:labels"}

def group(tag):
    t = tag.split('-')[0] if tag.startswith('truth') else tag
    if tag.endswith('-order'): t = 'order'
    return t

def checks_run(unit):
    g = collections.OrderedDict()
    for k, v in R.items():
        if v['unit_id'] != unit: continue
        tag = k.split('|')[-1]
        if unit.endswith('est.kozachenko') and tag == 'ties': key = 'est-ties'
        else: key = group(tag)
        g.setdefault(key, []).append((k, v))
    out = []
    for key, items in g.items():
        n = len(items); p = sum(bool(v['pass']) for _, v in items)
        crit = items[0][1].get('criterion')
        parts = [f"{p}/{n} pass"]
        if crit in ('exact', 'tolerance'):
            parts.append(f"max_abs <= {max(v.get('max_abs', 0) for _, v in items):.2g}")
            fails = [(k.split('|')[1] + ' T' + k.split('|')[2], v.get('max_abs')) for k, v in items if not v['pass']]
            if fails: parts.append('fails: ' + ', '.join(f"{a} max_abs {b:.3g}" for a, b in fails))
        elif crit == 'statistical':
            parts.append('max_z ' + ', '.join(f"{k.split('|')[1]} T{k.split('|')[2]} {v.get('max_z', float('nan')):.2f}" for k, v in items))
        ref = FN.get('ties' if key == 'est-ties' else key, REF)
        if key == 'est-ties': ref = f"{REF}:chk_ties with {PR}:ties"
        out.append({"run_ids": [k for k, _ in items], "reference": ref, "outcome": "; ".join(parts)})
    return out
