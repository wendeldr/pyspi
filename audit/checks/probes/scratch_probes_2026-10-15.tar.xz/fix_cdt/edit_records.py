import yaml
R='/media/dan/Data/git/pyspi/audit/records/'
def load(u): return yaml.safe_load(open(R+u+'.yaml'))
def save(u,r):
    with open(R+u+'.yaml','w') as f: yaml.safe_dump(r,f,sort_keys=False,width=130,allow_unicode=True)
def rep(s,old,new):
    assert old in s, (old[:60],)
    return s.replace(old,new)
PB_OLD='pyspi/base.py:27-49 parse_bivariate: two raw arrays are wrapped into a new Data object (z-scored) with i, j = 0, 1'
PB_NEW=('pyspi/base.py:27-49 parse_bivariate: two raw arrays are wrapped into a new Data object with i, j = 0, 1 (base.py:33-36); '
        'Data.add_process z-scores only the first array (data.py:238 set_data, normalise=True) and appends the second raw (data.py:230-234); '
        'the Calculator/multivariate path passes the already z-scored Data through unchanged. Owned by unit preproc.two_array_api')
# ---------------- CDS
u='causal.cds'; r=load(u); c=r['correctness']
c['implementation_trace']=[PB_NEW if t==PB_OLD else t for t in c['implementation_trace']]
c['implemented_as']=rep(c['implemented_as'],'Returns exactly 0 if no bin\n    has > 12 samples.' if 'Returns exactly 0 if no bin\n    has > 12 samples.' in c['implemented_as'] else 'Returns exactly 0 if no bin has > 12 samples.',
  'Returns exactly 0 if no bin has > 12 samples (CDS.py:190-191), and also exactly 0 whenever all qualifying bins have identical pmfs, in particular when exactly one bin has > 12 samples (P is then 1 x 13, CDS.py:194 centring gives all zeros, np.std = 0.0 at CDS.py:195).')
c['implementation_trace']=[ (t+'; with exactly one qualifying bin, or several with identical pmfs, the centred matrix is all zeros and np.std returns 0.0') if t.startswith('.venv/lib/python3.12/site-packages/cdt/causality/pairwise/CDS.py:190-195') else t for t in c['implementation_trace']]
c['deviation_from_documented']=rep(c['deviation_from_documented'],'and the 0 return value when no bin qualifies are undocumented',
  'and the exact 0 returned when at most one bin qualifies (or all qualifying pmfs coincide) are undocumented')
c['deviation_from_canonical']=rep(c['deviation_from_canonical'],'exact 0 is returned when no bin qualifies.',
  'exact 0 is returned when no bin qualifies (CDS.py:190-191) and, through the centring, when exactly one bin qualifies or all qualifying pmfs are identical (CDS.py:193-195); the paper does not define CDS for fewer than two x-values.')
c['units_and_range']=('dimensionless (SD of probabilities); >= 0, bounded above by 0.5; exactly 0 when at most one x-bin has > 12 samples (no-bin branch '
  'CDS.py:190-191, possible only for T <= 156 = 13 x 12; single-bin branch CDS.py:193-195, possible at any T when one bin holds all but <= 144 '
  'samples) and also when all qualifying bins have identical conditional pmfs. Observed: anm_T64 all 12 entries (process 0 has no qualifying bin, '
  'max count 12; processes 1-3 have exactly one, max counts 16, 16, 18); iid_gaussian_T64 8 of 20 entries (rows 0 and 2, exactly one qualifying '
  'bin each, max counts 16 and 13). Invariant to positive affine rescaling of either input (internal standardisation); asymmetric.')
nf=c['new_finding_candidates']
assert nf[0].startswith('Candidate (degenerate zero at short T)')
nf[0]=('Candidate (degenerate exact zero when at most one x-bin qualifies): CDS.py:164 keeps only x-bins with count > 12; with no qualifying bin '
  'CDS.py:190-191 returns 0, and with exactly one qualifying bin the 1 x 13 pmf matrix minus its own column mean is all zeros so np.std returns '
  '0.0 (CDS.py:193-195); the same happens when several qualifying bins have identical pmfs. Probe fix_cdt/cds_zero.py over all 76 check files '
  '(19 datasets x T in {64, 256, 1024, 4096}): 91 exact-zero entries, all at T=64; 90 have row process i with <= 1 qualifying bin (anm_T64: 3 '
  'entries from process 0 with no qualifying bin, 9 from processes 1-3 with one; iid_gaussian_T64: 8 entries from rows 0 and 2 with one), and 1 '
  '(narrowband_f0-0.25_T64 A[1,0]) has two qualifying bins of 32 samples with identical y-level counts {-2: 4, -1: 12, 1: 11, 2: 5}; every process '
  'with <= 1 qualifying bin gave an all-zero row. The no-bin branch cannot occur for T > 156, but the single-bin branch is not tied to short T: '
  'probe fix_cdt/cds_zero3.py built a spike-heavy x at T = 458 (406 samples in bin 0, every other bin <= 11) and cds_score returned 0.0. '
  'A 0 reads as the most causal possible value rather than ''not computable''.')
pc=c['proposed_checks'][3]
assert 'predicate' in pc['reference']
pc['reference']=('predicate computed from scratch per ordered pair (i, j): after cdt binning of z_i (trimmed re-standardisation, ffactor=2, maxdev=3), '
  'the set of x-bins with count > 12 has at most one member, or all their discretised conditional pmfs of z_j are identical; the count part '
  '(number of x-bins with count > 12 is <= 1) depends on process i only and is a sufficient condition')
pc['expected_outcome']=('A[i, j] == 0 exactly iff the predicate holds; every process with <= 1 qualifying bin gives an all-zero row (probe: 90 of 91 '
  'zero entries on the check files, all at T=64; the remaining one, narrowband_f0-0.25_T64 A[1,0], is the identical-pmf case); include an inline '
  'spike-heavy input at T >= 256 with one qualifying bin (probe T=458 gives 0.0) to show the zero is not confined to short T')
save(u,r)
# ---------------- ANM
u='causal.anm'; r=load(u); c=r['correctness']
c['implementation_trace']=[PB_NEW if t==PB_OLD else t for t in c['implementation_trace']]
c['implemented_as']=rep(c['implemented_as'].replace('\n',' ') if False else c['implemented_as'],'~1e-5..6e-4','~1e-5..8.3e-4 (max on anm_T64 pair 2 -> 3: 8.33e-4)')
c['deviation_from_canonical']=rep(c['deviation_from_canonical'],'anm_T64 7/12 entries equal the plain m*HSIC_b(y, x) to 4 decimals; max relative difference 0.09-0.24',
  'anm_T64 9/12 entries equal the plain m*HSIC_b(y, x) to 4 decimals, the exceptions being (2,0), (2,1), (2,3); max relative difference 0.09-0.24')
nf=c['new_finding_candidates']
nf[0]=rep(nf[0],'for 7 of 12 entries to 4 decimals,','for 9 of 12 entries to 4 decimals (exceptions (2,0) 0.6091 vs 0.6409, (2,1) 0.5530 vs 0.5896, (2,3) 6.314 vs 7.417; anm_T256 0 of 12 at 4 decimals, max relative 0.124; probe fix_cdt/anm_count.py), fitted length scales 1e-5..8.33e-4 on anm_T64,')
save(u,r)
# ---------------- IGCI
u='causal.igci'; r=load(u); c=r['correctness']
c['implementation_trace']=[PB_NEW if t==PB_OLD else t for t in c['implementation_trace']]
nf=c['new_finding_candidates']
assert nf[2].startswith('Candidate (bivariate path not exactly antisymmetric)')
nf[2]=('Candidate (bivariate raw-array path not exactly antisymmetric; preprocessing asymmetry owned by preproc.two_array_api / base.pair_handling): '
  'parse_bivariate (base.py:33-36) builds Data via add_process, which z-scores only the first array (data.py:238 set_data, normalise=True) and '
  'appends the second raw (data.py:230-234). bivariate(x, y) therefore evaluates IGCI on (zscore(x), raw y) and bivariate(y, x) on (zscore(y), raw x); '
  'IGCI''s StandardScaler (IGCI.py ref_measure gaussian) re-standardises both, so the two calls differ only at ulp level, amplified by the log of '
  'tiny spacings in eval_entropy. Probe fix_cdt/igci_raw.py (x ~ U(0,1), y = x^3, T=1024, default_rng(0)): 0.8105075201018178 vs -0.8105075125133075 '
  '(gap 7.6e-9); IGCI().predict_proba((zscore(x, ddof=1), y)) and ((zscore(y, ddof=1), x)) reproduce both values exactly; with both inputs z-scored '
  'the gap is 0.0, and the Calculator/multivariate path gives A[0,1] + A[1,0] = 0.0. Earlier probe: 5e-9 (0.8448910243 vs -0.8448910189). '
  'Low impact for igci; the generic raw-append behaviour is locked by tests/unit/test_data.py:74-88 and recorded under preproc.two_array_api.')
save(u,r)
# ---------------- RECI (same inaccurate trace line)
u='causal.reci'; r=load(u); c=r['correctness']
c['implementation_trace']=[PB_NEW if t==PB_OLD else t for t in c['implementation_trace']]
save(u,r)
print('ok')
