import sys, warnings, io, contextlib, numpy as np, pandas as pd
from collections import Counter
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
from cdt.causality.pairwise.CDS import discretized_sequence, CDS
base='/media/dan/Data/git/pyspi/audit/checks/data/'
def quiet(f,*a,**k):
    with contextlib.redirect_stdout(io.StringIO()): return f(*a,**k)
D=quiet(Data,np.load(base+'narrowband_f0-0.25_T64.npz')['x']); z=D.to_numpy()
x=pd.Series(z[1].ravel()); y=pd.Series(z[0].ravel())
xd=discretized_sequence(x,"Numerical",2,3); c=Counter(xd)
for a in c:
    if c[a]>12:
        yx=y[xd==a]; yx=(yx-np.mean(yx))/np.std(y)
        yq=discretized_sequence(yx,"Numerical",2,3,norm=False)
        print('bin',a,'n',c[a],'y levels',dict(Counter(yq.astype(int))))
print('cds', CDS().cds_score(z[1],z[0]))
rng=np.random.default_rng(1)
x=np.r_[np.zeros(900), rng.uniform(-3,3,100)]; rng.shuffle(x); y=rng.standard_normal(1000)
xd=discretized_sequence(pd.Series(x),"Numerical",2,3); c=Counter(xd)
print('T=1000 dominant-mode counts',sorted(c.items()),'cds',CDS().cds_score(x.reshape(-1,1),y.reshape(-1,1)))
