import sys, warnings, io, contextlib, numpy as np
from scipy.stats import zscore
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
import pyspi.statistics.causal as C
from cdt.causality.pairwise import IGCI
def quiet(f,*a,**k):
    with contextlib.redirect_stdout(io.StringIO()): return f(*a,**k)
rng=np.random.default_rng(0); x=rng.uniform(0,1,1024); y=x**3
s=C.InformationGeometricConditionalIndependence()
fxy=quiet(s.bivariate,x,y); fyx=quiet(s.bivariate,y,x)
print('raw bivariate', repr(fxy), repr(fyx), 'gap', fxy+fyx)
d=Data(); quiet(d.add_process,x); quiet(d.add_process,y); z=d.to_numpy()
print('row0 mean/std(ddof1)',z[0].mean(),z[0].std(ddof=1),'row1 equals raw y:',np.array_equal(z[1].ravel(),y))
r1=IGCI().predict_proba((zscore(x,ddof=1),y)); r2=IGCI().predict_proba((zscore(y,ddof=1),x))
print('reconstructed (zscore(x),raw y)',repr(r1),'==',r1==fxy,'; (zscore(y),raw x)',repr(r2),'==',r2==fyx)
D=quiet(Data,np.vstack([x,y])); A=s.multivariate(D); print('Data path A01+A10',A[0,1]+A[1,0])
r3=IGCI().predict_proba((zscore(x,ddof=1),zscore(y,ddof=1))); r4=IGCI().predict_proba((zscore(y,ddof=1),zscore(x,ddof=1))); print('both z-scored gap',r3+r4)
