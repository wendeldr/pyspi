import sys, warnings, io, contextlib, glob, os, numpy as np, pandas as pd
from collections import Counter
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
import pyspi.statistics.causal as C
from cdt.causality.pairwise.CDS import discretized_sequence, CDS
base='/media/dan/Data/git/pyspi/audit/checks/data/'
def quiet(f,*a,**k):
    with contextlib.redirect_stdout(io.StringIO()): return f(*a,**k)
def nqual(x):
    xd=discretized_sequence(pd.Series(x),"Numerical",2,3)
    c=Counter(xd); return sum(v>12 for v in c.values()), max(c.values())
tot_zero=0; tot_zero_pred=0; mism=0; by=Counter()
for f in sorted(glob.glob(base+'*_T*.npz')):
    name=os.path.basename(f)[:-4]
    D=quiet(Data,np.load(f)['x']); z=D.to_numpy(); A=quiet(C.ConditionalDistributionSimilarity().multivariate,D)
    M=z.shape[0]
    for i in range(M):
        nq,mx=nqual(z[i].ravel())
        for j in range(M):
            if i==j: continue
            zero=(A[i,j]==0); pred=(nq<=1)
            if zero: tot_zero+=1; by[(name, nq)]+=1
            if zero!=pred: mism+=1; print('MISMATCH',name,i,j,nq,mx,A[i,j])
print('total zero entries',tot_zero,'mismatches vs nq<=1',mism)
for k,v in sorted(by.items()): print(k,v)
for name in ('anm_T64','iid_gaussian_T64'):
    D=quiet(Data,np.load(base+name+'.npz')['x']); z=D.to_numpy()
    for i in range(z.shape[0]): print(name,i,nqual(z[i].ravel()))
rng=np.random.default_rng(0)
x=np.r_[rng.normal(0,0.05,40), rng.uniform(-3,3,400)]; 
print('T=440 single dominant mode', nqual(x))
x=np.r_[rng.normal(0,0.01,200), rng.uniform(-30,30,800)]; y=rng.standard_normal(1000)
print('T=1000 nqual',nqual(x),'cds',CDS().cds_score(x.reshape(-1,1),y.reshape(-1,1)))
