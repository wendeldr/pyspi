import sys, warnings, io, contextlib, numpy as np
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
import pyspi.statistics.causal as C
from cdt.causality.pairwise.ANM import normalized_hsic
from sklearn.gaussian_process import GaussianProcessRegressor
base='/media/dan/Data/git/pyspi/audit/checks/data/'
def quiet(f,*a,**k):
    with contextlib.redirect_stdout(io.StringIO()): return f(*a,**k)
for name in ['anm_T64','anm_T256']:
    D=quiet(Data,np.load(base+name+'.npz')['x']); z=D.to_numpy(); M=z.shape[0]
    A=C.AdditiveNoiseModel().multivariate(D)
    n4=0; ls=[]; maxrel=0
    for i in range(M):
        for j in range(M):
            if i==j: continue
            H=normalized_hsic(z[j], z[i])
            eq=round(A[i,j],4)==round(H,4); n4+=eq; maxrel=max(maxrel,abs(A[i,j]-H)/H)
            gp=GaussianProcessRegressor(random_state=42).fit(z[i],z[j]); l=gp.kernel_.k2.length_scale; ls.append(l)
            if not eq: print(name,(i,j),'A',round(A[i,j],4),'H',round(H,4))
    print(name,'equal at 4 dp:',n4,'of',M*(M-1),'max rel',round(maxrel,4),'length scale min/max',min(ls),max(ls), 'argmax pair', np.argmax(ls))
