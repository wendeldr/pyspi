import warnings, numpy as np, pandas as pd
from collections import Counter
warnings.simplefilter('ignore')
from cdt.causality.pairwise.CDS import discretized_sequence, CDS
rng=np.random.default_rng(2)
found=0
for trial in range(4000):
    n0=int(rng.integers(200,900)); m=int(rng.integers(20,140)); sc=10**rng.uniform(-2,1); df=rng.uniform(0.5,5)
    x=np.r_[rng.normal(0,1e-6,n0), sc*rng.standard_t(df,m)]; rng.shuffle(x)
    xd=discretized_sequence(pd.Series(x),"Numerical",2,3); c=Counter(xd)
    if sum(v>12 for v in c.values())==1:
        y=rng.standard_normal(len(x))
        print('T',len(x),'n0',n0,'m',m,'counts',sorted((int(k),v) for k,v in c.items()),'cds',CDS().cds_score(x.reshape(-1,1),y.reshape(-1,1)))
        found+=1
        if found>=2: break
print('found',found)
