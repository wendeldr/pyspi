import json, numpy as np, collections
r=json.load(open('out/results/cov_prec_robust.json'))
man=json.load(open('manifest/cov_prec_robust.json'))
probe={x['run_id']:x['probe'] is not None for x in man['runs']}
units=sorted({v['unit_id'] for v in r.values()})
for u in units:
    print('=====',u)
    rows=[(k,v) for k,v in r.items() if v['unit_id']==u]
    by=collections.defaultdict(list)
    for k,v in rows: by[k.split('|')[-1]].append((k,v))
    for tag,lst in sorted(by.items()):
        p=sum(1 for _,v in lst if v['pass']); 
        ma=max([v.get('max_abs',0) or 0 for _,v in lst]); mr=max([v.get('max_rel',0) or 0 for _,v in lst])
        print(f'  {tag:10s} {p}/{len(lst)} max_abs={ma:.3g} max_rel={mr:.3g}')
    # symmetry over SPI runs
    sy=[]
    for k,v in rows:
        if probe[k]: continue
        A=np.load(f'out/pyspi/{k}.npz')['value']
        m=~np.isnan(A)&~np.isnan(A.T)
        sy.append(np.abs(A-A.T)[m].max())
    print('  symmetry max|A-A.T| over', len(sy),'SPI runs:', max(sy), 'n nonzero', sum(1 for s in sy if s>0))
