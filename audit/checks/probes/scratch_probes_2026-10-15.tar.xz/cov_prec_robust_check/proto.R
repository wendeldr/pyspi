suppressMessages(library(rrcov))
for (tag in c("contaminated_1024","bivariate_gaussian_1024","contaminated_256","bivariate_gaussian_256","contaminated_4096","sparse_precision_64")) {
  z <- as.matrix(read.csv(paste0("z_",tag,".csv"), header=FALSE)); sup <- scan(paste0("sup_",tag,".csv"), quiet=TRUE)
  n <- nrow(z); p <- ncol(z); h <- length(sup); n2 <- (n+p+1)%/%2
  alpha <- (h - (2*n2-n) + 1e-9)/(2*(n-n2)); stopifnot(robustbase::h.alpha.n(alpha,n,p)==h)
  d <- CovMcd(z, alpha=alpha, nsamp="deterministic", initHsets=matrix(sup,ncol=1), use.correction=FALSE)
  o <- CovMcd(z, alpha=alpha, use.correction=FALSE, seed=c(10407L, as.integer(c(1:6)*1000+1)))
  sw <- sum(d@wt)
  cat(tag, "h", h, "R det sum.w", sw, " own sum.w", sum(o@wt), "\n")
  print(getCov(d)*(sw-1)/sw); print(getCov(o)*(sum(o@wt)-1)/sum(o@wt))
}
