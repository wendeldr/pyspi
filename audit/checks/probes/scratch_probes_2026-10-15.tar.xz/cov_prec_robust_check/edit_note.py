p='/media/dan/Data/git/pyspi/audit/notes/cov_prec_robust.md'
s=open(p).read()
reps=[
("| rrcov | SPI output (pipeline) | `rrcov::CovMcd` with its own FAST-MCD search (nsamp 500, 20 R seeds), h matched, `use.correction=FALSE`; atol = sklearn 20-seed range + rrcov 20-seed range | external-pkg |",
 "| rrcov | SPI output (pipeline) | `rrcov::CovMcd` with its own FAST-MCD search (nsamp 500, 20 R seeds), h matched, `use.correction=FALSE`; atol = sklearn 20-seed range + rrcov 20-seed range (wide by construction; `ref_within_sklearn_range_only` records the stricter elementwise bound of the sklearn range alone) | external-pkg |"),
("| seeds / range / det / rngstream / fresh* / alias / singular / breakdown / pcorr | probes and SPI outputs | numpy propositions (documented range, partial correlation, determinism, RNG-stream independence, fresh-process reproducibility, aliasing, singular input, closer to the clean truth than EmpiricalCovariance) | qualitative |",
 "| seeds / det / rngstream / fresh* / alias | probes and SPI outputs | numpy summaries of pyspi's own outputs (seed independence, determinism, RNG-stream independence, fresh-process reproducibility, aliasing): pyspi self-consistency, qualitative propositions | same-lineage |\n"
 "| range / singular / breakdown / pcorr | probes and SPI outputs | qualitative propositions (documented range, singular input via numpy matrix_rank of the input, closer to the clean truth than EmpiricalCovariance, documented partial correlation) | literature-only / independent-impl / analytic |"),
("with divisor **h-1**. This was verified: `ref_r_raw_cov_vs_sklearn_raw_conv_max_rel` = 0.0 on every rdet run.",
 "with divisor **h-1**. This holds to floating point, not bit-exactly: `ref_r_raw_cov_vs_sklearn_raw_conv_max_rel` is 1.1e-15 to 1.25e-13 over the 28 rdet runs (1.25e-13 on `sparse_precision|1024|pipeline|rdet`, 8.1e-14 on `iid_gaussian|1024|pipeline|rdet`)."),
("* Search, external: rrcov 5/6 within the combined seed range.",
 "* Search, external: rrcov 5/6 within the combined seed range. This atol is wide by construction (sum of two 20-seed ranges), so a pass here is weak\n"
 "  evidence and not value-level agreement. With the sklearn 20-seed range alone as the elementwise bound (`ref_within_sklearn_range_only`) the count is 4/6:\n"
 "  `bivariate_gaussian|1024|pipeline|rrcov` then also fails, with 2 off-diagonal entries outside (`ref_n_offdiag_outside_sklearn_range` = 2)."),
("* Optimality: 3/14 runs pass. sklearn's seed_all(42) raw subset is the best found (by 2000 from-scratch C-step runs and 20 rrcov seeds) only on\n  delayed_noise|64, delayed_noise|1024 and iid_gaussian|1024. Gaps in log det:\n  * 0.046 (iid|64) and 0.128 (sparse|64);",
 "* Optimality: 3/14 runs pass. sklearn's seed_all(42) raw subset is the best found (by 2000 from-scratch C-step runs and 20 rrcov seeds) only on\n  delayed_noise|64, delayed_noise|1024 and iid_gaussian|1024. The search is not exhaustive: each \"best found\" is an upper bound on the minimum\n"
 "  log det, so each gap below is a lower bound (a better search can only make sklearn look worse). Gaps in log det:\n  * >= 0.046 (iid|64) and >= 0.128 (sparse|64);"),
("  * rrcov is not exhaustive either. On iid_gaussian|256 no rrcov seed reaches the from-scratch best. On sparse_precision|64 one rrcov seed beats the 2000-start search by 0.0059.",
 "  * rrcov is not exhaustive either. On iid_gaussian|256 no rrcov seed reaches the from-scratch best. On `basic.cov.MinCovDet|sparse_precision|64|pipeline|opt`\n"
 "    two rrcov seeds (`ref_rrcov_n_seeds_at_best` = 2) reach a log det 0.0059 below the 2000-start search (`ref_scratch_best_gap`).\n"
 "  * The prec-unit opt runs solve the same raw problem with another search seed and found lower determinants on two datasets:\n"
 "    iid_gaussian|256 best found -3.25164 (prec) vs -3.25023 (cov), so sklearn's gap is >= 0.0202 (`basic.prec.MinCovDet|iid_gaussian|256|pipeline|opt` ref_gap);\n"
 "    sparse_precision|64 -4.69293 vs -4.69047, gap >= 0.131. The 3/14 count is unchanged by this."),
("  * freshbasic: with only the 8 robust SPIs they differ by 0.148.",
 "  * freshbasic: with only the 8 robust SPIs they differ by 0.0765. Both processes seed the global RNG from OS entropy, so this size changes between check runs."),
("  * The family cap (\"<= 7 unless R agrees to tolerance\") is not binding: R agrees to tolerance on 22/24 own-search runs and 24/28 deterministic runs across the four units.",
 "  * The family cap (\"<= 7 unless R agrees to tolerance\") is not binding at 6. The value-level external evidence is rdet: robustbase, started from\n"
 "    sklearn's raw subset, agrees on 24/28 runs across the four units (max_rel 3.51e-15 cov, 2.97e-13 prec; the 4 fails are the one divisor-band point).\n"
 "    The rrcov own-search runs (22/24 within the combined seed range, 20/24 with the sklearn range alone) carry little weight, because their atol is\n"
 "    wide by construction (0.0276 on bivariate_gaussian|1024 cov, 0.313 on bivariate_gaussian|256 prec, 0.525 on contaminated|1024 prec). The score does not rest on them."),
("* Its own external runs give the same pattern as MinCovDet: rdet 5/6 (the same divisor-band point) and rrcov 5/6 (the same contaminated|256 fail).",
 "* Its own external runs give the same pattern as MinCovDet: rdet 5/6 (the same divisor-band point) and rrcov 5/6 (the same contaminated|256 fail; 4/6 with the sklearn range alone)."),
("cov_MinCovDet differed by 0.148 in the same configuration.", "cov_MinCovDet differed by 0.0765 in the same configuration."),
("* External search: rrcov 6/6 (contaminated|256: 0.106 vs atol 0.119).",
 "* External search: rrcov 6/6 (contaminated|256: 0.106 vs atol 0.119), also 6/6 with the sklearn range alone. The atol reaches 0.313 (bivariate_gaussian|256)\n"
 "  and 0.525 (contaminated|1024), so this is weak evidence, not value-level agreement."),
("* Optimality 3/12, with the same gaps as the shared fit.",
 "* Optimality 3/12, with the same gaps as the shared fit (lower bounds; this unit's search found the lower bests quoted above for iid_gaussian|256 and sparse_precision|64)."),
("* rdet 5/6 (max_rel 1.76e-14 on the passing runs); rrcov 6/6.",
 "* rdet 5/6 (max_rel 1.76e-14 on the passing runs); rrcov 6/6 (weak evidence: wide atol, see prec_MinCovDet)."),
("the two processes differ by 0.148 (`...|freshbasic`).",
 "the two processes differ by 0.0765 (`...|freshbasic`; the processes seed from OS entropy, so the size changes between check runs)."),
("the log det gap of sklearn's seed-42 subset is 0.046 (iid) and 0.128 (sparse_precision)",
 "the log det gap of sklearn's seed-42 subset is at least 0.046 (iid) and at least 0.131 (sparse_precision; best found over the cov and prec opt runs)"),
]
for a,b in reps:
    assert s.count(a)==1,a[:90]
    s=s.replace(a,b)
open(p,'w').write(s)
print('ok')
