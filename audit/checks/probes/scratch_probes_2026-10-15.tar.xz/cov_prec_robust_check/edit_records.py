import re
R='/media/dan/Data/git/pyspi/audit/records/'
def edit(fn, reps):
    s=open(R+fn).read()
    for a,b in reps:
        n=s.count(a)
        assert n>=1, (fn,a[:80])
        s=s.replace(a,b)
    open(R+fn,'w').write(s)

# item 1 (all four)
old1="robustbase raw.cov = c(p,h/n) * MLE * h/(h-1) exactly (ref_r_raw_cov_vs_sklearn_raw_conv_max_rel 0.0)"
rng={'cov.MinCovDet':'1.1e-15 to 1.25e-13 over the 8 rdet runs','prec.MinCovDet':'1.1e-15 to 1.25e-13 over the 8 rdet runs',
     'cov.EllipticEnvelope':'1.1e-15 to 4.9e-14 over the 6 rdet runs','prec.EllipticEnvelope':'1.1e-15 to 4.9e-14 over the 6 rdet runs'}
for u,r in rng.items():
    edit(f'basic.{u}.yaml',[(old1,f"robustbase raw.cov = c(p,h/n) * MLE * h/(h-1) to floating point, not bit-exactly (ref_r_raw_cov_vs_sklearn_raw_conv_max_rel {r})")])

# agreement_criterion rrcov (all four)
oldac="rrcov: atol = sklearn 20-seed range + rrcov 20-seed range (two randomised searches for the same h-subset optimum can differ by at most their own run-to-run variability), rtol 0;"
newac=("rrcov: atol = sklearn 20-seed range + rrcov 20-seed range (two randomised searches for the same h-subset optimum can differ by at most their own run-to-run variability), rtol 0; wide by"
       " construction, so a pass is weak evidence and not value-level agreement (ref_within_sklearn_range_only records the stricter elementwise bound of the sklearn 20-seed range alone);")
for u in rng: edit(f'basic.{u}.yaml',[(oldac,newac)])

# freshbasic re-quote
for u in rng:
    edit(f'basic.{u}.yaml',[("freshbasic differs by 0.148 between","freshbasic differs by 0.0765 between")])
edit('basic.cov.MinCovDet.yaml',[("freshbasic 0/1 (0.148).","freshbasic 0/1 (0.0765; the two processes seed the global RNG from OS entropy, so this size changes between check runs).")])
edit('basic.cov.EllipticEnvelope.yaml',[("while cov_MinCovDet differed by 0.148)","while cov_MinCovDet differed by 0.0765)")])

# cov MCD closeness: rrcov + opt
edit('basic.cov.MinCovDet.yaml',[
 ("(seed 42: -6.46297). stat",
  "(seed 42: -6.46297). With the sklearn 20-seed range alone as the elementwise bound 4/6 (bivariate_gaussian|1024 also has 2 entries outside, ref_n_offdiag_outside_sklearn_range"
  " 2); the combined atol is wide by construction (0.0276 on bivariate_gaussian|1024), so these passes are weak evidence, not value-level agreement. stat"),
 ("opt: sklearn''s seed_all(42) raw h-subset is the best found (2000 from-scratch C-step runs + 20 rrcov seeds) in 3/14 runs; log det gaps 0.046 (iid|64), 0.128 (sparse|64), 0.012-0.023 (T=256), 4.4e-6\n    to 9.6e-4 (T>=1024);",
  "opt: sklearn''s seed_all(42) raw h-subset is the best found (2000 from-scratch C-step runs + 20 rrcov seeds) in 3/14 runs; the search is not exhaustive, so each best found is an upper bound on\n"
  "    the minimum log det and each gap a lower bound: log det gaps >= 0.046 (iid|64), >= 0.128 (sparse|64), 0.012-0.023 (T=256), 4.4e-6 to 9.6e-4 (T>=1024); the prec-unit opt runs (another search seed,\n"
  "    same raw problem) found lower determinants on iid_gaussian|256 (-3.25164 vs -3.25023, gap >= 0.0202) and sparse_precision|64 (-4.69293 vs -4.69047, gap >= 0.131);"),
])
# cov EE closeness
edit('basic.cov.EllipticEnvelope.yaml',[
 ("rrcov reaches a lower raw log det in all 20 seeds).",
  "rrcov reaches a lower raw log det in all 20 seeds); 4/6 with the sklearn 20-seed range alone as the elementwise bound (bivariate_gaussian|1024: ref_n_offdiag_outside_sklearn_range"
  " 2), and the combined atol is wide by construction, so these passes are weak evidence, not value-level agreement."),
])
# prec MCD closeness
edit('basic.prec.MinCovDet.yaml',[
 ("rrcov own search 6/6 (contaminated|256: 0.106 vs atol 0.119; bivariate_gaussian|1024: 0.0119 vs 0.0761).",
  "rrcov own search 6/6 (contaminated|256: 0.106 vs atol 0.119; bivariate_gaussian|1024: 0.0119 vs 0.0761), also 6/6 with the sklearn 20-seed range alone as the elementwise bound; the combined atol is"
  " wide by construction (0.313 on bivariate_gaussian|256, 0.525 on contaminated|1024), so these passes are weak evidence, not value-level agreement."),
 ("opt 3/12 (gaps as for cov: 0.046 iid|64, 0.131 sparse|64, 0.012-0.023 at T=256, 4.6e-4 to 9.6e-4\n    at T=1024).",
  "opt 3/12 (best found from a non-exhaustive search, so the gaps are lower bounds: >= 0.046 iid|64, >= 0.131 sparse|64, 0.012-0.023 at T=256, 4.6e-4 to\n"
  "    9.6e-4 at T=1024)."),
])
edit('basic.prec.EllipticEnvelope.yaml',[
 ("rrcov 6/6 (contaminated|256: 0.106 vs atol 0.119).",
  "rrcov 6/6 (contaminated|256: 0.106 vs atol 0.119), also 6/6 with the sklearn 20-seed range alone as the elementwise bound; the combined atol is wide by construction (up to 0.525), so these passes"
  " are weak evidence, not value-level agreement."),
])
# checks_run outcomes for rrcov
edit('basic.cov.MinCovDet.yaml',[("outcome: 'mixed 5/6: rrcov own FAST-MCD search within the combined seed range except as noted in closeness'",
  "outcome: 'mixed 5/6: rrcov own FAST-MCD search within the combined seed range except as noted in closeness; 4/6 with the sklearn seed range alone; weak evidence (wide atol)'")])
edit('basic.cov.EllipticEnvelope.yaml',[("outcome: 'mixed 5/6: rrcov own FAST-MCD search within the combined seed range except as noted in closeness'",
  "outcome: 'mixed 5/6: rrcov own FAST-MCD search within the combined seed range except as noted in closeness; 4/6 with the sklearn seed range alone; weak evidence (wide atol)'")])
for u in ['prec.MinCovDet','prec.EllipticEnvelope']:
    edit(f'basic.{u}.yaml',[("outcome: 'pass 6/6: rrcov own FAST-MCD search within the combined seed range except as noted in closeness'",
      "outcome: 'pass 6/6: rrcov own FAST-MCD search within the combined seed range except as noted in closeness; also 6/6 with the sklearn seed range alone; weak evidence (wide atol)'")])
print('done')
