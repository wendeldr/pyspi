suppressMessages(library(rrcov))
tag <- "bivariate_gaussian_1024"
z <- as.matrix(read.csv(paste0("z_",tag,".csv"), header=FALSE)); sup <- scan(paste0("sup_",tag,".csv"), quiet=TRUE)
n <- nrow(z); p <- ncol(z); h <- length(sup); n2 <- (n+p+1)%/%2
alpha <- (h - (2*n2-n) + 1e-9)/(2*(n-n2))
d <- CovMcd(z, alpha=alpha, nsamp="deterministic", initHsets=matrix(sup,ncol=1), use.correction=FALSE, trace=1)
cat("best==sup", identical(sort(d@best), sort(as.integer(sup))), length(d@best), "\n")
cat("raw.cnp2", d@raw.cnp2, " cnp2", d@cnp2, "\n")
S <- cov(z[sup,]); print(S*(h-1)/h); print(getRaw.cov(d)) 
print(d@iBest); str(d@n.csteps)
