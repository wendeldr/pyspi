suppressMessages(library(robustbase))
for (tag in c("contaminated_1024","bivariate_gaussian_1024","contaminated_256","bivariate_gaussian_256","contaminated_4096","sparse_precision_64")) {
z <- as.matrix(read.csv(paste0("z_",tag,".csv"), header=FALSE)); sup <- scan(paste0("sup_",tag,".csv"), quiet=TRUE)
n <- nrow(z); p <- ncol(z); h <- length(sup); n2 <- (n+p+1)%/%2
alpha <- (h - (2*n2-n) + 1e-9)/(2*(n-n2))
d <- covMcd(z, alpha=alpha, nsamp="deterministic", initHsets=matrix(as.integer(sup),ncol=1), use.correction=FALSE)
sw <- sum(d$mcd.wt)
cat(tag, "best==sup", identical(sort(d$best), sort(as.integer(sup))), "csteps", d$n.csteps, "sum.w", sw, "\n")
print(d$cov*(sw-1)/sw)
}
