import json
FAM = "cov_prec_robust"
PROBE = "probes/cov_prec_robust_mcd.py"
runs = []
def add(unit, ident, ds, T, path, tag, probe=None, processes=None):
    rid = f"{unit}|{ds}|{T}|{path}|{tag}"
    runs.append(dict(run_id=rid, unit_id=unit, identifier=ident, dataset=ds, T=T, path=path,
                     processes=processes, seed=42,
                     probe=None if probe is None else {"module": PROBE, "function": probe}))
for kind in ("cov", "prec"):
    for est in ("MinCovDet", "EllipticEnvelope"):
        U = f"basic.{kind}.{est}"; I = f"{kind}_{est}"; Isq = f"{kind}-sq_{est}"; mcd = est == "MinCovDet"
        # 1/2 fit state + from-scratch reweight (kernel) and the plain SPI on the same fit
        kds = ["iid_gaussian", "sparse_precision", "contaminated", "bivariate_gaussian", "delayed_noise"] if mcd \
            else ["contaminated", "bivariate_gaussian"]
        for ds in kds:
            for T in ((64, 1024) if mcd else (1024,)):
                add(U, None, ds, T, "kernel", "state", "fit_state")
                if mcd:
                    add(U, I, ds, T, "kernel", "base")
        # 3 external: robustbase deterministic from sklearn raw support; 4 rrcov own search; 5 seed companions
        rd = [(d, T) for d in ("contaminated", "bivariate_gaussian") for T in (256, 1024, 4096)]
        if mcd:
            rd += [("sparse_precision", 1024), ("iid_gaussian", 1024)]
        for ds, T in rd:
            add(U, None, ds, T, "pipeline", "state", "fit_state")
            add(U, I, ds, T, "pipeline", "rdet")
        for ds in ("contaminated", "bivariate_gaussian"):
            for T in (256, 1024, 4096):
                add(U, I, ds, T, "pipeline", "rrcov")
                add(U, None, ds, T, "pipeline", "seeds", "seeds")
        if mcd:
            for ds in ("iid_gaussian", "sparse_precision", "delayed_noise"):
                for T in (64, 256, 1024, 4096):
                    add(U, None, ds, T, "pipeline", "seeds", "seeds")
        # 6 documented range [-1, 1] over 20 seeds
        rng = [("cointegrated", 256)] + ([("trending", 256), ("iid_gaussian", 64), ("shared_envelope", 64)] if mcd else [])
        if kind == "prec" and mcd:
            rng.append(("narrowband_f0-0.25", 64))
        for ds, T in rng:
            add(U, None, ds, T, "pipeline", "range", "seeds")
        # 7 EllipticEnvelope == MinCovDet under the same seed
        if not mcd:
            for ds in ("iid_gaussian", "sparse_precision", "delayed_noise", "contaminated"):
                for T in (64, 1024):
                    add(U, I, ds, T, "kernel", "eeqmcd")
        # 8 determinism and RNG-stream dependence
        for ds, T in (("sparse_precision", 64), ("bivariate_gaussian", 1024)):
            add(U, None, ds, T, "pipeline", "det", "determinism")
            add(U, None, ds, T, "pipeline", "rngstream", "determinism")
        if kind == "cov":   # fresh-process reproducibility (open question: full default config vs robust-only config)
            add(U, None, "sparse_precision", 64, "pipeline", "freshfull", "fresh_process")
            add(U, None, "sparse_precision", 64, "pipeline", "freshbasic", "fresh_process")
        add(U, None, "bivariate_gaussian", 64, "kernel", "alias", "aliasing")
        # 9 analytic targets with Monte-Carlo SE
        if kind == "cov":
            st = [("bivariate_gaussian", T, "pipeline") for T in (256, 1024, 4096)] if mcd else [("bivariate_gaussian", 1024, "pipeline")]
            st += [("contaminated", T, "pipeline") for T in ((256, 1024, 4096) if mcd else (1024,))]
            if mcd:
                st += [("iid_gaussian", 1024, "pipeline"), ("delayed_noise", 1024, "pipeline"), ("trending", 1024, "pipeline-detrend"),
                       ("contaminated", 1024, "kernel")]
        else:
            st = [(d, T, "pipeline") for d in ("bivariate_gaussian", "sparse_precision") for T in ((256, 1024, 4096) if mcd else (1024,))]
            if mcd:
                st += [("iid_gaussian", 1024, "pipeline"), ("trending", 1024, "pipeline-detrend"), ("contaminated", 1024, "kernel")]
        for ds, T, path in st:
            add(U, I, ds, T, path, "stat")
        if mcd:   # null datasets: convergence across T and the conditional (same-draw) comparison
            for T in (256, 4096):
                add(U, I, "iid_gaussian", T, "pipeline", "stat")
            for ds, T in (("iid_gaussian", 256), ("iid_gaussian", 1024), ("iid_gaussian", 4096), ("delayed_noise", 1024)):
                add(U, I, ds, T, "pipeline", "statc")
        if kind == "prec":
            for ds in ("bivariate_gaussian", "sparse_precision"):
                add(U, I, ds, 1024, "pipeline", "pcorr")
        if kind == "cov":
            for T in ((256, 1024, 4096) if mcd else (1024,)):
                add(U, None, "contaminated", T, "kernel", "rcorr", "robust_corr")
            if mcd:
                add(U, None, "contaminated", 1024, "pipeline", "rcorr", "robust_corr")
        # breakdown vs EmpiricalCovariance
        for T in ((256, 1024, 4096) if mcd else (1024,)):
            add(U, I, "contaminated", T, "kernel", "breakdown")
        if kind == "prec":
            add(U, I, "shared_envelope", 64, "pipeline", "singular")
        # -sq, orientation, direction
        for ds in ("bivariate_gaussian", "contaminated"):
            add(U, Isq, ds, 1024, "pipeline", "sq")
        add(U, I, "bivariate_gaussian", 1024, "pipeline", "perm", processes=[3, 2, 1, 0])
        for ds in ("bivariate_gaussian", "sparse_precision"):
            add(U, I, ds, 1024, "pipeline", "dir")
        # optimality of the raw FAST-MCD search
        if mcd:
            for ds in ("iid_gaussian", "sparse_precision", "contaminated", "delayed_noise"):
                for T in (64, 256, 1024):
                    add(U, None, ds, T, "pipeline", "opt", "fit_state")
            if kind == "cov":
                for ds in ("iid_gaussian", "contaminated"):
                    add(U, None, ds, 4096, "pipeline", "opt", "fit_state")
ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids)), "duplicate run ids"
json.dump({"family": FAM, "runs": runs}, open(f"/media/dan/Data/git/pyspi/audit/checks/manifest/{FAM}.json", "w"), indent=1)
print(len(runs))
