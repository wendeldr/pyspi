import numpy as np, sys
from scipy.stats import zscore
from sklearn.covariance import MinCovDet
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import cov_prec_robust as R
for T,reps in [(1024,200),(4096,100)]:
    rng=np.random.default_rng(7); dsk=[]; dsc=[]
    for r in range(reps):
        z=zscore(rng.standard_normal((5,T)),axis=1,ddof=1).T
        E=R.mle_cov(z)
        np.random.seed(r); C=MinCovDet().fit(z).covariance_
        dsk.append(C-E); dsc.append(R.scratch_rmcd(z,rng)['cov']-E)
    off=~np.eye(5,dtype=bool)
    print(T,'sklearn diff sd',np.round(np.std(dsk,0,ddof=1)[off].max(),4),np.round(np.std(dsk,0,ddof=1)[off].mean(),4),' scratch diff sd',np.round(np.std(dsc,0,ddof=1)[off].max(),4),np.round(np.std(dsc,0,ddof=1)[off].mean(),4))
