import json, math
a=json.load(open('/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/cov_prec_robust_results_before_fix.json'))
b=json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/results/cov_prec_robust.json'))
print(len(a),len(b), sum(x['pass'] for x in a.values()), sum(x['pass'] for x in b.values()))
skip={'reference_kind','reference_detail','notes'}
for k in sorted(set(a)|set(b)):
    if k not in a or k not in b: print('MISSING',k); continue
    for f in sorted(set(a[k])|set(b[k])):
        if f in skip: continue
        u,v=a[k].get(f),b[k].get(f)
        if u==v: continue
        if isinstance(u,float) and isinstance(v,float) and (math.isnan(u) and math.isnan(v) or abs(u-v)<=1e-12*max(1,abs(u))): continue
        print(k,f,u,'->',v)
