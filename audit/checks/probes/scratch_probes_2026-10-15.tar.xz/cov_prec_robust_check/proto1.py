import sys, numpy as np, time
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import make_data
from scipy.stats import zscore
from sklearn.covariance import MinCovDet
for ds,T in [('contaminated',1024),('bivariate_gaussian',1024),('contaminated',256),('bivariate_gaussian',256),('contaminated',4096),('sparse_precision',64)]:
    x=make_data.load(ds,T)['x']; z=zscore(x,axis=1,ddof=1).T
    np.random.seed(42); t=time.time(); m=MinCovDet().fit(z); dt=time.time()-t
    np.savetxt(f'z_{ds}_{T}.csv', z, delimiter=',')
    np.savetxt(f'sup_{ds}_{T}.csv', np.where(m.raw_support_)[0]+1, fmt='%d')
    np.save(f'cov_{ds}_{T}.npy', m.covariance_); np.save(f'raw_{ds}_{T}.npy', m.raw_covariance_)
    print(ds,T,'h',m.raw_support_.sum(),'nw',m.support_.sum(),'t',round(dt,3)); print(m.covariance_)
