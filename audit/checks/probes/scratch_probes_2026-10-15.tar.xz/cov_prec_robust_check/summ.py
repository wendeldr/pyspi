import json, collections, sys
r=json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/results/cov_prec_robust.json'))
by=collections.defaultdict(lambda:[0,0])
for k,v in r.items():
    tag=k.split('|')[-1]; by[(tag)][0 if v['pass'] else 1]+=1
for t,(p,f) in sorted(by.items()): print(f'{t:10s} pass {p:3d} fail {f:3d}')
