import json
import yaml

REC = "/media/dan/Data/git/pyspi/audit/records/{}.yaml"
MAN = json.load(open("/media/dan/Data/git/pyspi/audit/checks/manifest/cov_prec_robust.json"))
RES = json.load(open("/media/dan/Data/git/pyspi/audit/checks/out/results/cov_prec_robust.json"))
REF = "refs/cov_prec_robust.py"
RSCRIPT = "r/cov_prec_robust.R"
PROBE = "probes/cov_prec_robust_mcd.py"


def ids(unit, *tags):
    return [r["run_id"] for r in MAN["runs"] if r["unit_id"] == unit and r["run_id"].split("|")[-1] in tags]


def outcome(unit, *tags):
    rs = [RES[i] for i in ids(unit, *tags)]
    return sum(bool(r["pass"]) for r in rs), len(rs)


def fix_trace(c):
    def sub(s):
        s = s.replace("pyspi/calculator.py:226-244 _load_yaml imports (:226 importlib.import_module,\n    :243 getattr(module, fcn)(**params))",
                      "pyspi/calculator.py:230-264 _load_yaml imports (:239 importlib.import_module, :256 getattr(module, fcn)(**params))")
        s = s.replace("pyspi/calculator.py:226-244 _load_yaml imports (:226 importlib.import_module, :243 getattr(module, fcn)(**params))",
                      "pyspi/calculator.py:230-264 _load_yaml imports (:239 importlib.import_module, :256 getattr(module, fcn)(**params))")
        s = s.replace("pyspi/calculator.py:294 S = self._spis[spi].multivariate(self.dataset); :297 np.fill_diagonal(S, np.nan); :300 self._table[spi] = S",
                      "pyspi/calculator.py:329 S = self._spis[spi].multivariate(self.dataset); :332 np.fill_diagonal(S, np.nan); :335 self._table[spi] = S")
        s = s.replace("tests/README.md line 126", "tests/README.md line 145").replace("line 115 (CALC_E2E_SKIP", "line 134 (CALC_E2E_SKIP")
        s = s.replace("line 116 (shared-cache", "line 135 (shared-cache").replace("line 106 (FORCE_SLOW", "line 125 (FORCE_SLOW")
        s = s.replace("tests/README.md:126", "tests/README.md:145")
        return s
    for k, v in list(c.items()):
        if isinstance(v, str):
            c[k] = sub(v)
        elif isinstance(v, list):
            c[k] = [sub(x) if isinstance(x, str) else x for x in v]
    return c


COMMON_REF = (f"{RSCRIPT} (robustbase==0.99.2 covMcd(nsamp='deterministic', initHsets = sklearn raw_support_); rrcov==1.7.5 "
              f"CovMcd own FAST-MCD search, 20 R seeds; system R 4.6.1); {REF} (h_rdet, h_rrcov, h_state/h_base from-scratch "
              f"Croux-Haesbroeck correction + reweighting, h_stat/h_rcorr/h_dir analytic targets with Monte-Carlo SE of a "
              f"from-scratch reweighted FAST-MCD, h_opt 2000-start C-step search); {PROBE} (fit_state, seeds, determinism, "
              f"fresh_process, robust_corr, aliasing)")

AGREE = ("state/base: rtol 1e-9 on the whole fitted state given sklearn's raw estimates (same-lineage); rdet: rtol 1e-9, atol 1e-12 "
         "after mapping robustbase's divisor n_w-1 to sklearn's n_w (external-pkg); rrcov: atol = sklearn 20-seed range + rrcov "
         "20-seed range (two randomised searches for the same h-subset optimum can differ by at most their own run-to-run "
         "variability), rtol 0; stat/rcorr: |pyspi - analytic target| <= 2 se with se = Monte-Carlo SD x Bonferroni factor over "
         "the P(P-1)/2 distinct entries; statc: same against the MLE estimate of the same draw; opt: sklearn raw log det <= best "
         "found + 1e-8; eeqmcd/sq: exact; perm: rtol 1e-9; dir: sign agreement where |corr| or |partial corr| >= 0.2; "
         "qualitative runs: pass = the stated proposition holds")

COST = ("cheap per call: one sklearn fit per Data object and estimator, median 0.025 s at T=64, 0.35 s at T=1024, 0.75 s "
        "(max 1.14 s) at T=4096 for P=4-5 (out/pyspi/index/cov_prec_robust.json); the family's 323 pyspi runs took 465 s in "
        "total (20-fit seed studies up to 21 s at T=4096), the references (Monte-Carlo SE, 2000-start searches, R) about 2 min")


def cov_block(unit, est):
    mcd = est == "MinCovDet"
    if mcd:
        clos = (
            "state (same-lineage: sklearn raw_location_/raw_covariance_ -> from-scratch Croux-Haesbroeck c(p,h/n) on raw distances, "
            "chi2_{p,0.975} rejection, MLE divisor, c(p,0.975)): 18/18 pass, max_abs 2.27e-13, max_rel 1.54e-13 over the whole "
            "fitted state; base 10/10, max_abs 1.11e-16. rdet (robustbase covMcd from sklearn's raw support, divisor mapped): 7/8 "
            "pass, max_abs 6.66e-16, max_rel 3.51e-15; the failing basic.cov.MinCovDet|bivariate_gaussian|256|pipeline|rdet differs "
            "by one reweighting point (robustbase keeps 245, sklearn 244) that lies in the raw-divisor band [q, q h/(h-1)) "
            "(ref_disagreements_all_in_divisor_band = 1; robustbase's raw scatter divisor is h-1, sklearn's is h), max_abs 0.0118. "
            "rrcov own search: 5/6 within atol (bivariate_gaussian|1024: max_abs 0.0058 vs atol 0.0276; contaminated|4096: "
            "0.00037 vs 0.0061); fail contaminated|256: 0.00576 vs atol 0.00373, where all 20 rrcov seeds reach raw log det "
            "-6.4858 to -6.4831 and all 20 sklearn seeds stay at -6.4630 to -6.4591 (seed 42: -6.46297). stat (analytic "
            "Sigma_ij/(s_i s_j), Monte-Carlo SE, Bonferroni): 11/12 pass; bivariate_gaussian max raw z 1.00/1.32/1.78 at "
            "T=256/1024/4096; contaminated pipeline target 0.147, max_abs 0.0036 at T=1024; contaminated kernel target 0.8, "
            "max_abs 0.0197; trending pipeline-detrend raw z 1.14; delayed_noise null raw z 0.78; fail iid_gaussian|1024 null "
            "(max_abs 0.124, raw z 3.65, the draw's own Pearson r(0,2) = 0.084). statc (vs MLE of the same draw): 3/4, fail "
            "iid_gaussian|4096 (max_abs 0.0246, MC SE 0.00995, raw z 2.95). rcorr: robust correlation 0.8087/0.8071/0.7905 at "
            "T=256/1024/4096 vs 0.8 (4/4, max_z 1.30). opt: sklearn's seed_all(42) raw h-subset is the best found (2000 "
            "from-scratch C-step runs + 20 rrcov seeds) in 3/14 runs; log det gaps 0.046 (iid|64), 0.128 (sparse|64), 0.012-0.023 "
            "(T=256), 4.4e-6 to 9.6e-4 (T>=1024); where several seeds reach the best h-subset they give identical output (spread 0.0: delayed_noise|64 10 seeds, iid_gaussian|1024 6, delayed_noise|1024 3). seeds: 20-seed max "
            "spread 0.155/0.068/0.013/0.0027 (iid_gaussian T=64/256/1024/4096), 0.257/0.061/0.015/0.0044 (sparse_precision), "
            "0.0037/0.0018/0.0038 (contaminated T=256/1024/4096). range: max |off-diag| 1.141 (cointegrated|256), 1.008 "
            "(trending|256), 1.083 (shared_envelope|64). breakdown 3/3: kernel contaminated |pyspi - 0.8| / |EmpiricalCovariance "
            "- 0.8| = 0.0139/0.0042/0.0032 (pyspi 0.735/0.820/0.815, empirical -3.904/-3.938/-3.910). det 2/2 bit-identical; "
            "rngstream 0/2 (max_abs 0.111 sparse_precision|64, 0.0081 bivariate_gaussian|1024); freshfull 1/1 identical, "
            "freshbasic 0/1 (0.148). sq 2/2 and perm 1/1 bitwise; dir 2/2 (agreement 1.0)."
        )
    else:
        clos = (
            "eeqmcd 8/8 bitwise equal to cov_MinCovDet under the same seed (iid_gaussian, sparse_precision, delayed_noise, "
            "contaminated; T=64 and 1024; same-lineage). state 8/8, max_abs 2.27e-13, max_rel 4.65e-14. rdet (robustbase covMcd "
            "from sklearn's raw support): 5/6, max_abs 6.66e-16, max_rel 3.51e-15; fail bivariate_gaussian|256 by the same single "
            "raw-divisor-band point as cov_MinCovDet (max_abs 0.0118). rrcov own search: 5/6 (bivariate_gaussian|1024 0.0058 vs "
            "atol 0.0276); fail contaminated|256 (0.00576 vs 0.00373; rrcov reaches a lower raw log det in all 20 seeds). stat 2/2 "
            "(bivariate_gaussian|1024 raw z 1.32; contaminated|1024 pipeline target 0.147, max_abs 0.0036); rcorr 1/1 (0.8071 vs "
            "0.8, z 0.51). breakdown 1/1 (err ratio 0.0042). seeds 0/6 (spread 0.0018-0.063, identical to cov_MinCovDet). range "
            "cointegrated|256: max 1.141. det 2/2; rngstream 0/2 (0.111 sparse_precision|64, 0.0081 bivariate_gaussian|1024); "
            "freshfull identical; freshbasic identical in this pair of fresh processes (0.0; both landed on the same local "
            "optimum, while cov_MinCovDet differed by 0.148). sq 2/2, perm 1/1 bitwise; dir 2/2."
        )
    return clos


def prec_block(unit, est):
    mcd = est == "MinCovDet"
    if mcd:
        return (
            "state 18/18 (max_rel 1.54e-13, precision_ vs numpy.linalg.inv of the from-scratch scatter); base 10/10, max_abs "
            "8.88e-15, max_rel 1.54e-13. rdet: 7/8, max_abs 2.45e-13, max_rel 2.97e-13; fail bivariate_gaussian|256 (one "
            "raw-divisor-band point, max_abs 0.0244). rrcov own search 6/6 (contaminated|256: 0.106 vs atol 0.119; "
            "bivariate_gaussian|1024: 0.0119 vs 0.0761). stat (analytic Omega_ij s_i s_j): 10/11; bivariate_gaussian raw z "
            "1.72/2.10/1.60 at T=256/1024/4096, sparse_precision 1.83/2.45/2.25, trending pipeline-detrend 2.00, contaminated "
            "kernel 0.38; fail iid_gaussian|1024 null (max_abs 0.134, raw z 3.82). statc 2/4: fail iid_gaussian|1024 (raw z 2.83) "
            "and |4096 (raw z 3.06). pcorr 0/2: pyspi prec(2,3) = -2.480 vs the documented partial correlation +0.8 (Omega_z "
            "target -2.191), sparse_precision prec(0,1) = -0.611 vs +0.4 (target -0.542); max_z 18.0 and 14.3. range 0/5: max "
            "|off-diag| 32.7 (cointegrated|256), 12.3 (trending|256), 1.60 (iid|64), 2.28 (shared_envelope|64), 368.3 "
            "(narrowband_f0-0.25|64). singular: shared_envelope|64 input rank 3 of 4, finite pseudo-inverse output, prec(0,2) = "
            "0.446, no NaN. opt 3/12 (gaps as for cov: 0.046 iid|64, 0.131 sparse|64, 0.012-0.023 at T=256, 4.6e-4 to 9.6e-4 at T=1024). seeds: 20-seed "
            "max spread 0.817/0.079/0.016/0.0028 (iid_gaussian T=64/256/1024/4096), 0.803/0.163/0.020/0.0055 (sparse_precision). "
            "breakdown 3/3: kernel contaminated prec(0,1) -2.573/-2.280/-2.045 vs clean -2.222 vs empirical +0.282/+0.279/+0.277 "
            "(error ratio 0.140/0.023/0.071). det 2/2; rngstream 0/2 (0.134 sparse_precision|64, 0.0177 bivariate_gaussian|1024). "
            "sq 2/2 bitwise; perm 1/1 (max_abs 3.11e-15); dir 2/2."
        )
    return (
        "eeqmcd 8/8 bitwise equal to prec_MinCovDet under the same seed. state 8/8 (max_rel 4.65e-14). rdet 5/6, max_abs "
        "2.45e-13, max_rel 1.76e-14; fail bivariate_gaussian|256 (one raw-divisor-band point, max_abs 0.0244). rrcov 6/6 "
        "(contaminated|256: 0.106 vs atol 0.119). stat 2/2 (bivariate_gaussian|1024 raw z 2.10, sparse_precision|1024 2.45). "
        "pcorr 0/2 (-2.480 vs +0.8; -0.611 vs +0.4). singular: finite pseudo-inverse, prec(0,2) = 0.446, input rank 3 of 4. "
        "range cointegrated|256: 32.7. breakdown 1/1 (err ratio 0.023). seeds 0/6 (spread 0.0081-0.20). det 2/2; rngstream 0/2 "
        "(0.134, 0.0177). sq 2/2, perm 1/1, dir 2/2."
    )


def resolutions(kind, est):
    mcd = est == "MinCovDet"
    pre = f"basic.{kind}.{est}"
    red = dict(candidate="EllipticEnvelope covariance_/precision_ equal MinCovDet's for the same RNG state; the identifiers differ only by RNG position",
               outcome="confirmed",
               evidence=("basic.{k}.EllipticEnvelope|*|kernel|eeqmcd: 8/8 bitwise equal to basic.{k}.MinCovDet|*|kernel|base "
                         "(iid_gaussian, sparse_precision, delayed_noise, contaminated; T=64, 1024); basic.{k}.*|*|pipeline|rngstream: "
                         "after the other robust SPI consumed the global RNG the output moves by up to {m} (sparse_precision|64)").format(
                             k=kind, m="0.111" if kind == "cov" else "0.134"))
    mag = dict(candidate="seed-to-seed spread is large, not last-bit (stochasticity itself already documented, tests/README.md:145)",
               outcome="confirmed",
               evidence=("basic.{k}.MinCovDet|*|pipeline|seeds: 20-seed max spread {a} at T=64 falling to {b} at T=4096; "
                         "basic.{k}.MinCovDet|*|pipeline|opt: the spread comes from FAST-MCD local optima (seeds at the best "
                         "h-subset give spread 0.0; sklearn's seed_all(42) subset is the best found in 3/{n} runs); "
                         "basic.cov.MinCovDet|sparse_precision|64|pipeline|freshbasic differs by 0.148 between two fresh processes").format(
                             k=kind, a="0.155-0.257" if kind == "cov" else "0.353-0.817",
                             b="0.0027-0.0044" if kind == "cov" else "0.0028-0.0055", n="14" if kind == "cov" else "12"))
    drift = dict(candidate="version drift from documented sklearn 0.24.1 (Croux-Haesbroeck raw factor and c(p,0.975) on the reweighted covariance)",
                 outcome="inconclusive",
                 evidence=(f"{pre}|*|state: the executed 1.9.1 output is reproduced (max_rel <= 1.54e-13) only with c(p,h/n) on "
                           "the raw distances and c(p,0.975) on the reweighted MLE covariance, so the 1.9.1 side is numerically "
                           "confirmed; sklearn 0.24.1 was not executed (no install allowed), so the size of the drift rests on its "
                           "source text only. Settle by running 0.24.1 MinCovDet on the same seed and data"))
    rng = dict(candidate="documented range claim ('covariance = correlation within [-1, 1]') is false for the robust estimator",
               outcome="confirmed",
               evidence=("basic.cov.MinCovDet|cointegrated|256|pipeline|range max 1.141, |trending|256| 1.008, "
                         "|shared_envelope|64| 1.083; basic.cov.MinCovDet|contaminated|*|pipeline|stat: pyspi tracks "
                         "Sigma_ij/(s_i s_j) = 0.147 (non-robust SD), while basic.cov.MinCovDet|contaminated|*|rcorr gives the "
                         "robust correlation 0.79-0.81"))
    pcorr = dict(candidate="documented 'precision = partial correlation within [-1, 1]' is false: raw precision entries, opposite sign, unbounded",
                 outcome="confirmed",
                 evidence=(f"{pre}|bivariate_gaussian|1024|pipeline|pcorr: -2.480 vs +0.8 (max_z 18.0); "
                           f"{pre}|sparse_precision|1024|pipeline|pcorr: -0.611 vs +0.4 (max_z 14.3); |stat runs match Omega_z instead; "
                           "range: 368.3 (narrowband_f0-0.25|64), 32.7 (cointegrated|256). Only the robust estimators were run here"))
    sing = dict(candidate="silent pseudo-inverse and suppressed warnings on singular input",
                outcome="confirmed",
                evidence=(f"{pre}|shared_envelope|64|pipeline|singular: input rank 3 of 4 (x2 == x0) yet the output is finite "
                          "(prec(0,2) = 0.446, no NaN); the warning suppression is basic.py:37-38 (code)"))
    alias = dict(candidate="returned unsquared matrix is the cached sklearn attribute with its diagonal NaN-ed in place (value-neutral in Calculator)",
                 outcome="confirmed",
                 evidence=(f"{pre}|bivariate_gaussian|64|kernel|alias: returned_is_cached_attribute 1, cached diagonal all NaN 1, "
                           "write_through_to_cache 1, next call returns the edited value 1, the other attribute's diagonal stays "
                           "finite 1; Calculator copies into its DataFrame (calculator.py:335), and the sq/perm/base runs agree "
                           "bitwise, so the effect is value-neutral there"))
    minor = dict(candidate="minor variants: h = ceil((n+p+1)/2), MLE divisor n_w in the reweighted covariance",
                 outcome="confirmed",
                 evidence=(f"{pre}|*|pipeline|rdet: robustbase raw.cov = c(p,h/n) * MLE * h/(h-1) exactly "
                           "(ref_r_raw_cov_vs_sklearn_raw_conv_max_rel 0.0) and the reweighted values agree to 3.5e-15 only after "
                           f"the (n_w-1)/n_w divisor mapping; {pre}|*|pipeline|rrcov: rrcov default h (floor) 129 vs sklearn 130 "
                           "(contaminated|256), default-convention difference 0.0102-0.0186 at T=256 and 4e-5 to 0.0028 (cov) at T>=1024"))
    if kind == "cov":
        return [red, mag, drift, rng, alias, minor]
    return [red, mag, drift, pcorr, sing, alias, minor]


def checks_run(unit, kind, est):
    mcd = est == "MinCovDet"
    out = []

    def add(tags, ref, text):
        rids = ids(unit, *tags)
        if not rids:
            return
        p, n = outcome(unit, *tags)
        out.append(dict(run_ids=rids, reference=ref, outcome=f"{'pass' if p == n else 'fail' if p == 0 else 'mixed'} {p}/{n}: {text}"))

    add(("state",), f"{REF}:h_state", "whole fitted state vs from-scratch reweighting, max_rel <= 1.54e-13")
    add(("base",), f"{REF}:h_base", "SPI output vs from-scratch reweighting of the same fit")
    add(("rdet",), f"{RSCRIPT} det via {REF}:h_rdet", "robustbase from sklearn's raw support; one bivariate_gaussian|256 point in the raw-divisor band")
    add(("rrcov",), f"{RSCRIPT} own via {REF}:h_rrcov", "rrcov own FAST-MCD search within the combined seed range except as noted in closeness")
    add(("eeqmcd",), f"{REF}:h_eeqmcd", "bitwise equal to the MinCovDet output under the same seed")
    add(("stat",), f"{REF}:h_stat", "analytic targets in path units with Monte-Carlo SE (Bonferroni)")
    add(("statc",), f"{REF}:h_statc", "MCD vs MLE of the same draw on the null datasets")
    add(("rcorr",), f"{REF}:h_rcorr", "robust correlation vs the clean correlation 0.8")
    add(("pcorr",), f"{REF}:h_pcorr", "proposition prec = partial correlation (documented) does not hold")
    add(("opt",), f"{REF}:h_opt and {RSCRIPT} own", "sklearn raw log det vs best of 2000 from-scratch C-step runs and 20 rrcov seeds")
    add(("seeds",), f"{REF}:h_seeds", "proposition 'no seed dependence' does not hold; spreads quoted in closeness")
    add(("range",), f"{REF}:h_seeds", "documented [-1, 1] range")
    add(("breakdown",), f"{REF}:h_breakdown", "robust estimate closer to the clean truth than EmpiricalCovariance")
    add(("singular",), f"{REF}:h_singular", "proposition 'singular input is signalled' does not hold")
    add(("det",), f"{REF}:h_det", "two seed_all(42) calls bit-identical")
    add(("rngstream",), f"{REF}:h_det", "proposition 'unchanged after another RNG-consuming SPI' does not hold")
    add(("freshfull", "freshbasic"), f"{REF}:h_fresh", "fresh-process Calculator reproducibility, default config vs robust-only config")
    add(("alias",), f"{REF}:h_alias", "returned matrix aliases the cached sklearn attribute")
    add(("sq", "perm", "dir"), f"{REF}:h_sq, h_perm, h_dir", "-sq = square (bitwise), permutation equivariance, analytic sign")
    return out


def check_fields(unit):
    _, kind, est = unit.split(".")
    mcd = est == "MinCovDet"
    clos = cov_block(unit, est) if kind == "cov" else prec_block(unit, est)
    data = ("iid_gaussian, sparse_precision, contaminated, bivariate_gaussian, delayed_noise (T=64-4096, kernel and pipeline), "
            "trending (pipeline-detrend 1024; range 256), cointegrated|256, shared_envelope|64"
            + (", narrowband_f0-0.25|64" if kind == "prec" else "")) if mcd else (
            "iid_gaussian, sparse_precision, delayed_noise, contaminated (kernel, T=64/1024), contaminated and bivariate_gaussian "
            "(pipeline, T=256/1024/4096), sparse_precision|64, cointegrated|256" + (", shared_envelope|64" if kind == "prec" else ""))
    if kind == "cov":
        what = ("Reweighted FAST-MCD covariance of the z-scored data, computed exactly as sklearn 1.9.1 defines it (external robustbase "
                "agrees to 3.5e-15 given the same raw h-subset). Differs from the canonical reweighted MCD by: (1) the raw h-subset "
                "is a FAST-MCD local optimum drawn from the global numpy RNG, so the value depends on the seed and on RNG position "
                "(20-seed spread 0.155-0.257 at T=64, 0.0027-0.0044 at T=4096) and is often not the lowest-determinant subset "
                "(sklearn's seed_all(42) subset is the best found in 3/14 runs; rrcov's search finds lower determinants on "
                "contaminated|256 in all 20 seeds); (2) h = ceil((n+p+1)/2); (3) MLE divisor n_w and c(p,0.975) applied even when "
                "every point is kept. Differs from the supplement: it is not a correlation in [-1,1] (values up to 1.141; 0.15 on "
                "contaminated data where the robust correlation is 0.81, because the non-robust z-score sets the scale), and "
                "sklearn 1.9.1 multiplies the reweighted covariance by c(p,0.975), which the documented 0.24.1 did not (source only).")
        if not mcd:
            what = ("Same computation as cov_MinCovDet: EllipticEnvelope.fit is MinCovDet.fit plus offset_, so the output is bitwise "
                    "the MinCovDet covariance for the same RNG state and differs from cov_MinCovDet in a Calculator pass only by RNG "
                    "position (up to 0.111 at T=64). " + what)
    else:
        what = ("Inverse (scipy pinvh) of the reweighted FAST-MCD scatter of the z-scored data, exactly as sklearn 1.9.1 defines it "
                "(external robustbase + numpy inverse agree to 3e-13 given the same raw subset). Canonical deviations as for cov "
                "(FAST-MCD local optima drawn from the global RNG, ceil h, MLE divisor). Differs from the supplement: it is not the "
                "partial correlation (sign opposite, magnitude unbounded: -2.48 where the partial correlation is +0.8, up to 368 on "
                "narrowband data), and on singular input a pseudo-inverse is returned silently (warnings suppressed).")
        if not mcd:
            what = ("Same computation as prec_MinCovDet (EllipticEnvelope.fit = MinCovDet.fit + offset_): bitwise equal for the "
                    "same RNG state, otherwise differing only by RNG position (up to 0.134 at T=64). " + what)
    return dict(
        check_method="external-pkg",
        check_reference=COMMON_REF,
        check_data=data,
        agreement_criterion=AGREE,
        closeness=clos,
        verdict="variant",
        score_0_10=6,
        what_changed=what,
        new_finding=True,
        definition_under_review=True,
        check_cost=COST,
        symmetry_observed=("sym: max|A - A.T| = 0.0 over all {} SPI-output runs (exactly symmetric; np.cov output)".format(
            48 if mcd else 28) if kind == "cov" else
            "sym to round-off: max|A - A.T| = 2.66e-15 over {} SPI-output runs ({} with a nonzero last-bit difference; pinvh, REVIEW M2)".format(
                50 if mcd else 31, 37 if mcd else 21)),
        direction_observed=("undirected and contemporaneous: A[i,j] = A[j,i] is the (i,j) entry of the robust scatter fitted on the "
                            "processes in the given order ({p}|bivariate_gaussian|1024|pipeline|perm: reversing the processes permutes "
                            "the output, max_abs {pm}); signs follow the analytic {q} ({p}|*|dir 2/2, agreement 1.0); no lag "
                            "sensitivity: delayed_noise (x_k = x0 delayed by 1, 3, 5) gives off-diagonals at the null level "
                            "({dn})").format(p=unit, pm="0.0" if kind == "cov" else "3.11e-15",
                                             q="covariance (+ on the rho = 0.3/0.8 pairs)" if kind == "cov" else "precision (- on positively correlated pairs)",
                                             dn="basic.%s.MinCovDet|delayed_noise|1024|pipeline|stat and |statc pass" % kind),
        candidate_resolutions=resolutions(kind, est),
        checks_run=checks_run(unit, kind, est),
    )


for unit in ("basic.cov.MinCovDet", "basic.cov.EllipticEnvelope", "basic.prec.MinCovDet", "basic.prec.EllipticEnvelope"):
    path = REC.format(unit)
    d = yaml.safe_load(open(path))
    d["status"] = "checked"
    c = fix_trace(d["correctness"])
    c["direction_convention"] = c["direction_convention"].replace("; to confirm empirically in the check stage",
                                                                  "; confirmed empirically in the check stage (perm and dir runs)")
    for k in list(c.keys()):
        if k in ("check_method",):
            pass
    c.update(check_fields(unit))
    d["correctness"] = c
    with open(path, "w") as fh:
        yaml.safe_dump(d, fh, sort_keys=False, allow_unicode=True, width=200, default_flow_style=False)
    print("updated", unit, len(c["checks_run"]), "check groups")
