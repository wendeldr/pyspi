import sys, time; sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import importlib.util, make_data, numpy as np
spec=importlib.util.spec_from_file_location('p','/media/dan/Data/git/pyspi/audit/checks/probes/cov_prec_robust_mcd.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
x=make_data.load('sparse_precision',64)['x']
for tag in ['freshfull','freshbasic']:
    t=time.time(); A=m.fresh_process(x, {'run_id':'basic.cov.MinCovDet|sparse_precision|64|pipeline|'+tag,'unit_id':'basic.cov.MinCovDet'}); print(tag, time.time()-t, np.nanmax(np.abs(A[0]-A[1])))
