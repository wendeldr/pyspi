import sys, numpy as np, io, contextlib
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.statistics.distance import GromovWasserstainTau as G
from pyspi.data import Data
from scipy.stats import zscore
rng=np.random.default_rng(0)
T=256
X=rng.standard_normal((3,T))
with contextlib.redirect_stdout(io.StringIO()):
    d=Data(X)
print('to_numpy shape', d.to_numpy().shape)
spi=G()
print('labels',spi.labels,'identifier',spi.identifier)
with contextlib.redirect_stdout(io.StringIO()):
    A=spi.multivariate(d)
print('A=\n',A)
# from-scratch
Z=zscore(X,axis=1,ddof=1)
def L(x):
    return np.cumsum(np.sqrt(1+np.diff(x)**2))
def ref(x,y): return np.sqrt(np.mean((L(x)-L(y))**2))
def ref_root(x,y):
    a=np.r_[0,L(x)]; b=np.r_[0,L(y)]; return np.sqrt(np.mean((a-b)**2))
r=ref(Z[0],Z[1]); print('pyspi',A[0,1],'ref no-root',r,'diff',A[0,1]-r)
print('ref with root',ref_root(Z[0],Z[1]),'ratio',ref_root(Z[0],Z[1])/A[0,1],'sqrt((T-1)/T)',np.sqrt((T-1)/T))
# direct bivariate call order symmetric
with contextlib.redirect_stdout(io.StringIO()):
    print('bivariate(i=0,j=1) vs (1,0):', spi.bivariate(d,i=0,j=1), spi.bivariate(d,i=1,j=0))
# vec_geo_dist length & monotone
v=G.vec_geo_dist(np.column_stack([np.arange(T),Z[0]]))
print('len v',len(v),'T',T,'strictly increasing',np.all(np.diff(v)>0),'min step',np.diff(np.r_[0,v]).min())
# sign flip invariance and constant offset
print('gwtau(x,-x)=',G.gwtau(Z[0],-Z[0]),' gwtau(x,x+5)=',G.gwtau(Z[0],Z[0]+5))
print('gwtau(x, x reversed)=',G.gwtau(Z[0],Z[0][::-1]))
# joint permutation
p=rng.permutation(T)
print('joint permutation: before',G.gwtau(Z[0],Z[1]),'after',G.gwtau(Z[0][p],Z[1][p]))
# scale dependence (no z-score)
print('gwtau(x,2x)=',G.gwtau(Z[0],2*Z[0]), ' gwtau(0.01x, 0.02x)=',G.gwtau(0.01*Z[0],0.02*Z[0]))
# T growth for iid pairs
for TT in [64,256,1024,4096]:
    vals=[]
    for s in range(20):
        Y=zscore(rng.standard_normal((2,TT)),axis=1,ddof=1); vals.append(G.gwtau(Y[0],Y[1]))
    print('T',TT,'mean gwtau iid',np.mean(vals))
# unequal-length branch reachable?
try:
    with contextlib.redirect_stdout(io.StringIO()):
        out=spi.bivariate(rng.standard_normal(100), rng.standard_normal(80))
    print('unequal bivariate returned',out)
except Exception as e:
    print('unequal bivariate raised',type(e).__name__, str(e)[:200])
# unequal branch vs from-scratch quantile W2
def w2_quantile(a,b):
    a=np.sort(a); b=np.sort(b)
    qs=np.unique(np.r_[np.arange(len(a)+1)/len(a), np.arange(len(b)+1)/len(b)])
    tot=0
    for lo,hi in zip(qs[:-1],qs[1:]):
        m=(lo+hi)/2
        tot+=(hi-lo)*(a[int(np.floor(m*len(a)))]-b[int(np.floor(m*len(b)))])**2
    return np.sqrt(tot)
a=rng.standard_normal(37); b=rng.standard_normal(53)
print('unequal wass_sorted',G.wass_sorted(a,b),'quantile ref',w2_quantile(a,b))
print('equal wass_sorted',G.wass_sorted(a[:30],b[:30]),'quantile ref',w2_quantile(a[:30],b[:30]))
