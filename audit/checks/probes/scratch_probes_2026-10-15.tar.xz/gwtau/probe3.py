import sys, numpy as np, io, contextlib
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.statistics.distance import GromovWasserstainTau as G
from pyspi.data import Data
spi=G(); base='/media/dan/Data/git/pyspi/audit/checks/data/'
for name in ['delayed_noise','iid_gaussian','narrowband_f0-0.25','bivariate_gaussian','scaled_offset']:
    for T in [256,4096]:
        X=np.load(f'{base}{name}_T{T}.npz')['x']
        with contextlib.redirect_stdout(io.StringIO()):
            A=spi.multivariate(Data(X))
        print(name,T,np.round(A[0],3), 'sym exact', np.array_equal(np.nan_to_num(A),np.nan_to_num(A.T)))
