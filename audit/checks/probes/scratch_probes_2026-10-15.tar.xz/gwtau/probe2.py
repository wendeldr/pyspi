import sys, numpy as np, io, contextlib
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.statistics.distance import GromovWasserstainTau as G
from pyspi.data import Data
spi=G()
z=np.load('/media/dan/Data/git/pyspi/audit/checks/data/scaled_offset_T1024.npz'); print(list(z.keys()))
X=z['x'] if 'x' in z else z[list(z.keys())[0]]
for n,dt in [(True,False),(False,False),(True,True)]:
    with contextlib.redirect_stdout(io.StringIO()):
        A=spi.multivariate(Data(X,normalise=n,detrend=dt))
    print('normalise',n,'detrend',dt,'\n',np.round(A,4))
print('dtype',Data(X).to_numpy().dtype if False else '')
