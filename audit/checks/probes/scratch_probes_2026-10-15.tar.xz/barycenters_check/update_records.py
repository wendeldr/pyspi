"""Fill the check-stage block of the four barycenter records (run in the project venv: needs PyYAML).
Trace fields are edited by exact text replacement; the check block is appended under `correctness:`."""
import sys
import yaml
from pathlib import Path

REC = Path("/media/dan/Data/git/pyspi/audit/records")
sys.path.insert(0, str(Path(__file__).parent))
from record_content import CONTENT, TRACE_FIXES  # noqa: E402

for unit, block in CONTENT.items():
    p = REC / f"{unit}.yaml"
    s = p.read_text()
    if "\n  check_method:" in s:
        print("skip", unit); continue
    s = s.replace("status: traced\n", "status: checked\n", 1)
    for old, new in TRACE_FIXES.get(unit, []):
        assert s.count(old) >= 1, (unit, old[:80])
        s = s.replace(old, new)
    dumped = yaml.safe_dump(block, default_flow_style=False, allow_unicode=True, sort_keys=False, width=100000)
    s = s.rstrip("\n") + "\n" + "".join("  " + ln + "\n" for ln in dumped.splitlines())
    doc = yaml.safe_load(s)
    assert doc["status"] == "checked" and doc["correctness"]["verdict"] == block["verdict"]
    p.write_text(s)
    print("updated", unit)
