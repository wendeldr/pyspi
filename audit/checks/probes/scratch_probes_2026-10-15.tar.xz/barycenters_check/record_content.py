"""Check-stage content for the barycenter records. Numbers are quoted from audit/checks/out/results/barycenters.json."""
EU, DT, SG, SD = ("distance.bary." + m for m in ("euclidean", "dtw", "sgddtw", "softdtw"))
REF = "audit/checks/refs/barycenters.py"

COMMON_FIXES = [
    ("calculator.py:238-244", "calculator.py:252-266"),
    ("calculator.py:289-294", "calculator.py:329"),
]

TRACE_FIXES = {
    EU: COMMON_FIXES + [
        ("tests/README.md:128 tolerance table", "tests/README.md:147 tolerance table"),
    ],
    DT: COMMON_FIXES,
    SG: COMMON_FIXES + [
        ("tests/README.md:115 and :127 (bary*_sgddtw_*", "tests/README.md:134 and :146 (bary*_sgddtw_*"),
        ("is already documented (tests/README.md:115/127)", "is already documented (tests/README.md:134/146)"),
        ("mean: near 0, either sign (probe2 |mean| <= 0.0162).",
         "mean: near 0, either sign; the trace-stage bound 0.0162 held only for the nine single pairs of trace probe2. Check runs "
         "(max over pairs of |bary_sgddtw_mean|): 0.0012-0.0128 on the z-scored pipeline at T=1024 (bivariate_gaussian "
         "0.0012, iid_gaussian 0.0048, delayed_noise 0.0079, logistic_maps 0.0128), and on raw (kernel-path) input up "
         "to 0.126 (bivariate_gaussian T=64) and 0.242 (delayed_noise T=64), where the series are not zero-mean."),
        ("Undocumented: results are stochastic (global numpy RNG, no seed exposed).",
         "Not stated in the supplement or GitBook: results are stochastic (global numpy RNG, no seed exposed); "
         "the RNG dependence itself is documented in tests/README.md:134/146."),
    ],
    SD: COMMON_FIXES,
}

# ---------------------------------------------------------------------------------------------- euclidean
CONTENT = {}
CONTENT[EU] = dict(
    check_method="analytic",
    check_reference=f"{REF}:h_zero, h_formula, h_offset, h_popstat (analytic); {REF}:h_scratch, h_detrend, h_cold (from-scratch numpy z-score/detrend and (z_i+z_j)/2); h_invariance, h_sym (same-lineage self-consistency)",
    check_data="all 21 datasets at T=64/1024/4096 (pipeline) and T=1024 (pipeline-detrend) for bary_euclidean_mean; bivariate_gaussian, sparse_precision, iid_gaussian, contaminated (formula); bivariate_gaussian, delayed_noise, narrowband_f0-0.25, nonlinear_dependence (kernel T=256, pipeline T=1024); trending, scaled_offset (pipeline-detrend T=256/1024); scaled_offset kernel (offset); bivariate_gaussian T=256/1024/4096 (population); var2_bivariate, delayed_noise, logistic_maps_chaotic, anm (symmetry/direction)",
    agreement_criterion="analytic zero: atol 1e-12; analytic (1+r)(T-1)/(2T) and from-scratch statistics: exact (rtol 1e-10, atol 1e-12); detrend path: rtol 1e-9; population value (1+rho)/2 (T-1)/T: |pyspi - value| <= 2 se with se = sd(r)/2 inflated by 2.865/2 (Bonferroni over 6 pairs, alpha 0.05); symmetry: max|A - A.T| == 0",
    closeness="bary_euclidean_mean: max|A| = 2.52e-16 over all 84 zero runs (21 datasets x T 64/1024/4096 pipeline + T 1024 pipeline-detrend; worst distance.bary.euclidean|logistic_maps|1024|pipeline|zero|bary_euclidean_mean), all pass atol 1e-12. bary-sq_euclidean_mean vs (1+r)(T-1)/(2T): 12/12 pass, max_rel 1.36e-15. From-scratch statistics (all four identifiers, kernel T=256 and pipeline T=1024): 32/32 pass, max_abs 0. Detrend path: 16/16 pass, max_abs 4.97e-14 (bary-sq_euclidean_max on trending T=1024; the max_rel 12 entries are bary_euclidean_mean values of order 1e-17, inside atol). Kernel path offset: pyspi bary_euclidean_mean = (mean x_i + mean x_j)/2 to 4.4e-16 with sample means [0.0136, 0.987, -2.112, 4.678] for design offsets [0, 1, -2, 5]. Population: max_z 0.738 (T=256), 0.813 (T=1024), 0.720 (T=4096) on the Bonferroni-scaled se, max_abs 0.0329 / 0.0182 / 0.0081 (shrinking ~1/sqrt(T)). Invariance (same-lineage): scaled_offset equals bivariate_gaussian for the four identifiers within rtol 1e-10. Symmetry: max|A - A.T| = 0 on all four direction datasets; cold-cache bivariate(i,j) vs (j,i): 0.",
    verdict="degenerate",
    score_0_10=0,
    what_changed="Scored on the representative identifier bary_euclidean_mean (in config.yaml and in the EEG selection), which is identically zero on every pyspi preprocessing path that z-scores: mean_t (z_i + z_j)/2 = 0, observed |A| <= 2.52e-16 on all 21 datasets. The barycenter itself is the exact Euclidean Frechet mean (z_i + z_j)/2 and the other three identifiers are computed exactly as stated (fp-exact against independent numpy): bary_euclidean_max (in the supplement) would rate 10 on its own; bary-sq_euclidean_mean is the affine transform (1 + r)(T - 1)/(2T) of Pearson r (rtol 1.4e-15), so it duplicates Pearson correlation; bary-sq_euclidean_max is (max_t |z_i + z_j|/2)^2. With normalise=False the mean statistic becomes the average of the two offsets, not a coupling measure. Labels: the class is Signed while all documentation says unsigned; only the mean statistics can be negative.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap (every run < 0.1 s on the pyspi side, including T=4096)",
    symmetry_observed="sym: max|A - A.T| = 0 exactly on var2_bivariate, delayed_noise, logistic_maps_chaotic, anm (T=1024, bary_euclidean_max, *|sym|* runs); cold-cache ordered-pair matrix on delayed_noise T=1024 also has max|M - M.T| = 0 (the Euclidean average is order-invariant)",
    direction_observed="none: A[i,j] = A[j,i] bit-identically on var2_bivariate (x0 -> x1), delayed_noise (x0 leads), logistic_maps_chaotic (x -> y) and anm; the statistic is a symmetric function of the pair and carries no direction",
    candidate_resolutions=[
        dict(candidate="bary_euclidean_mean is structurally zero on the default pipeline", outcome="confirmed",
             evidence="84 runs distance.bary.euclidean|<dataset>|{64,1024,4096}|pipeline|zero|bary_euclidean_mean and |1024|pipeline-detrend|zero|: max|A| = 2.52e-16, all within atol 1e-12 of the analytic 0"),
        dict(candidate="bary-sq_euclidean_mean equals (1+r)(T-1)/(2T)", outcome="confirmed",
             evidence="12 runs distance.bary.euclidean|{bivariate_gaussian,sparse_precision,iid_gaussian,contaminated}|{64,256,1024}|pipeline|formula|bary-sq_euclidean_mean: max_rel 1.36e-15"),
        dict(candidate="label inconsistency: Signed class vs documented unsigned", outcome="confirmed",
             evidence="code: distance.py:211-215 (Directed, Signed; label 'signed'); values: bary_euclidean_mean takes both signs (zero runs, e.g. bivariate_gaussian T=1024 min -2.3e-17 max -6.9e-18; kernel-path offset run min -1.05) while the max statistics are >= 0 on z-scored data (sym runs min 1.17)"),
        dict(candidate="statistic max_time exists in code and GitBook but in no config", outcome="confirmed",
             evidence="static: pyspi/config.yaml has no 'max_time' (grep); distance.py:240-241 defines it; not run numerically (no config identifier)"),
        dict(candidate="with normalise=False the mean statistic measures offsets", outcome="confirmed",
             evidence="distance.bary.euclidean|scaled_offset|1024|kernel|offset|bary_euclidean_mean: pyspi = (mean x_i + mean x_j)/2 to 4.4e-16; sample means [0.0136, 0.987, -2.112, 4.678] track the design offsets [0, 1, -2, 5]"),
    ],
    checks_run=[
        dict(run_ids=["distance.bary.euclidean|*|*|pipeline|zero|bary_euclidean_mean", "distance.bary.euclidean|*|1024|pipeline-detrend|zero|bary_euclidean_mean"], reference=f"{REF}:h_zero (analytic)", outcome="pass 84/84; max|A| 2.52e-16"),
        dict(run_ids=["distance.bary.euclidean|*|*|pipeline|formula|bary-sq_euclidean_mean"], reference=f"{REF}:h_formula (analytic)", outcome="pass 12/12; max_rel 1.36e-15"),
        dict(run_ids=["distance.bary.euclidean|*|256|kernel|scratch|*", "distance.bary.euclidean|*|1024|pipeline|scratch|*"], reference=f"{REF}:h_scratch (independent-impl)", outcome="pass 32/32; max_abs 0"),
        dict(run_ids=["distance.bary.euclidean|{trending,scaled_offset}|{256,1024}|pipeline-detrend|detrend|*"], reference=f"{REF}:h_detrend (independent-impl)", outcome="pass 16/16; max_abs 4.97e-14"),
        dict(run_ids=["distance.bary.euclidean|scaled_offset|1024|kernel|offset|bary_euclidean_mean"], reference=f"{REF}:h_offset (analytic)", outcome="pass; max_abs 4.4e-16"),
        dict(run_ids=["distance.bary.euclidean|bivariate_gaussian|{256,1024,4096}|pipeline|popstat|bary-sq_euclidean_mean"], reference=f"{REF}:h_popstat (analytic, statistical)", outcome="pass 3/3; max_z 0.74 / 0.81 / 0.72"),
        dict(run_ids=["distance.bary.euclidean|scaled_offset|1024|pipeline|invariance|*"], reference=f"{REF}:h_invariance (same-lineage)", outcome="pass 4/4"),
        dict(run_ids=["distance.bary.euclidean|*|1024|pipeline|sym|bary_euclidean_max", "distance.bary.euclidean|delayed_noise|1024|pipeline|cold|bary_euclidean_max"], reference=f"{REF}:h_sym (same-lineage), h_cold (independent-impl)", outcome="pass 5/5; max|A - A.T| 0"),
    ],
)

# ---------------------------------------------------------------------------------------------- dtw
CONTENT[DT] = dict(
    check_method="independent-impl",
    check_reference=f"audit/checks/refs/_kernels_distance.py:dba, dtw_path, dtw_dp (from-scratch DBA, Petitjean et al. 2011, tslearn init/stopping mirrored) via {REF}:h_dba, h_dba_bc, h_cold; {REF}:h_opt_dtw (Frechet cost and 8-start DBA); {REF}:h_xx (analytic); {REF}:h_vs_eucl, h_sym (same-lineage)",
    check_data="bivariate_gaussian, delayed_noise, narrowband_f0-0.25, logistic_maps (kernel T=64/256, all four identifiers + raw barycenters); the same plus iid_gaussian (pipeline T=64/256/1024); iid_gaussian processes [0,0] (analytic); bivariate_gaussian, delayed_noise, narrowband_f0-0.25 T=256 (optimality); var2_bivariate, delayed_noise, logistic_maps_chaotic, anm T=1024 (symmetry)",
    agreement_criterion="from-scratch DBA statistics and barycenters: rtol 1e-9, atol 1e-10; analytic DBA(x, x) = x: exact; optimality: F(pyspi) <= F(Euclidean init) for every pair, with the gap to an 8-start DBA reported; symmetry: max|A - A.T| == 0",
    closeness="Statistics: 52/52 runs pass, max_abs 1.1e-16, max_rel 4.2e-14 (kernel T=64/256 four identifiers; pipeline T=64/256/1024). Raw barycenters: 8/8 pass, max_abs 4.4e-16 (*|dba-bc|*). Iterations 2-12 per pair, all stopped by the tolerance/increase rule well before max_iter 30. DBA(x, x) = x: 4/4 exact. Optimality (*|256|pipeline|opt|*): F(pyspi) <= F(Euclidean init) on every pair (pass), but the 8-start minimum is much lower: rel_gap_best 0.12-0.56 on bivariate_gaussian, 1.85-44.5 on delayed_noise (F 49.1 vs 1.08 for pair (0,1); a raw input series has F 2.14), 0.13 / 13.5 / 0.12 on narrowband_f0-0.25. Narrowband pair (0,1): DBA returns the Euclidean init (2 iterations, stalled_at_init 1 at T=64/256/1024), the init alignment paths are diagonal with 0 backtrack ties and min dF over 20 random perturbations +1e-6 > 0, so it is a strict local minimum, not a tie artefact. bary_dtw_mean range (max over pairs |A|, pipeline): 0.051-0.090 at T=64, 0.005-0.063 at T=256, 0.004-0.012 at T=1024 except logistic_maps 0.071; bary_dtw_max 1.20-3.04 at T=1024. Symmetry: max|A - A.T| = 0 on all four direction datasets; cold-cache ordered pairs on delayed_noise T=256: max|M - M.T| = 0.",
    verdict="variant",
    score_0_10=6,
    what_changed="pyspi/tslearn compute DBA exactly as the from-scratch reference (single run, init = (x+y)/2, absolute tol 1e-5). The canonical target is the DTW Frechet mean argmin_b F(b); a single mean-initialised DBA run returns a local minimiser whose cost is 12-56% above an 8-start minimum on Gaussian pairs and 1.9-45x above it on delayed copies (where it is worse than simply returning one input series). The value of every bary_dtw_* identifier therefore depends on the initialisation rule; Petitjean et al. initialise from an input sequence. On one narrowband pair DBA stays at the Euclidean mean (a strict local minimum), so bary_dtw_max equals bary_euclidean_max there. bary_dtw_mean is near zero (<= 0.09) because the barycenter starts at a zero-mean average.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap on the pyspi side (numba DTW; <= 4.6 s per run, T <= 1024); the from-scratch reference costs ~1 s per DBA at T=1024 and 8-17 s per optimality run at T=256",
    symmetry_observed="sym: max|A - A.T| = 0 on var2_bivariate, delayed_noise, logistic_maps_chaotic, anm (T=1024, bary_dtw_max, *|sym|* runs); cold-cache bivariate(i,j) vs bivariate(j,i) on delayed_noise T=256: max|M - M.T| = 0, i.e. DBA with mean init is order-invariant, not only cache-symmetric",
    direction_observed="none: A[i,j] = A[j,i] bit-identically on var2_bivariate, delayed_noise, logistic_maps_chaotic, anm; the statistic carries no direction",
    candidate_resolutions=[
        dict(candidate="DBA can return its Euclidean initialisation unchanged, so bary_dtw_* equals bary_euclidean_* there", outcome="confirmed",
             evidence="narrowband_f0-0.25 pair (0,1) only (1 of 3 pairs): stalled_at_init 1 in distance.bary.dtw|narrowband_f0-0.25|{64,256,1024}|*|dba|*; bary_dtw_max 1.3317 = bary_euclidean_max 1.3317 in distance.bary.dtw|narrowband_f0-0.25|1024|pipeline|vs-eucl|bary_dtw_max (the other two pairs move: 1.521 vs 0.864, 1.340 vs 0.628, so that qualitative run fails its all-pairs expectation)"),
        dict(candidate="bary_dtw_mean is near-degenerate", outcome="confirmed",
             evidence="pipeline *|dba|bary_dtw_mean runs: max over pairs |A| 0.051-0.090 (T=64), 0.005-0.063 (T=256), 0.004-0.012 (T=1024) except logistic_maps 0.071, vs bary_dtw_max 1.20-3.04 (T=1024); not identically zero"),
        dict(candidate="label inconsistencies and undocumented bary-sq_dtw_* identifiers", outcome="confirmed",
             evidence="static (distance.py:211-215, config.yaml:255-311, supplement lines 321-329); bary_dtw_mean takes both signs (e.g. bivariate_gaussian T=64 pipeline min -0.051, max 0.033)"),
        dict(candidate="DBA returns a local minimiser that depends on the init rule", outcome="confirmed",
             evidence="distance.bary.dtw|{bivariate_gaussian,delayed_noise,narrowband_f0-0.25}|256|pipeline|opt|bary_dtw_mean: rel_gap_best 0.12-0.56, 1.85-44.5, 0.12-13.5"),
    ],
    checks_run=[
        dict(run_ids=["distance.bary.dtw|*|{64,256}|kernel|dba|*", "distance.bary.dtw|*|{64,256,1024}|pipeline|dba|*"], reference="refs/_kernels_distance.py:dba via refs/barycenters.py:h_dba (independent-impl)", outcome="pass 52/52; max_rel 4.2e-14"),
        dict(run_ids=["distance.bary.dtw|*|{64,256}|kernel|dba-bc|bary_dtw_mean"], reference=f"{REF}:h_dba_bc (independent-impl)", outcome="pass 8/8; max_abs 4.4e-16"),
        dict(run_ids=["distance.bary.dtw|iid_gaussian|256|kernel|xx|*|p0-0"], reference=f"{REF}:h_xx (analytic)", outcome="pass 4/4; exact"),
        dict(run_ids=["distance.bary.dtw|*|256|pipeline|opt|bary_dtw_mean"], reference=f"{REF}:h_opt_dtw (independent-impl, optimality)", outcome="pass 3/3 (descent); rel_gap_best up to 44.5"),
        dict(run_ids=["distance.bary.dtw|{delayed_noise,narrowband_f0-0.25}|1024|pipeline|vs-eucl|bary_dtw_max"], reference=f"{REF}:h_vs_eucl (same-lineage, qualitative)", outcome="delayed_noise pass (dtw_max > euclid_max on 6/6 pairs); narrowband fail (equal on 1/3 pairs only)"),
        dict(run_ids=["distance.bary.dtw|*|1024|pipeline|sym|bary_dtw_max", "distance.bary.dtw|delayed_noise|256|pipeline|cold|bary_dtw_max"], reference=f"{REF}:h_sym (same-lineage), h_cold (independent-impl)", outcome="pass 5/5; max|A - A.T| 0"),
    ],
)

# ---------------------------------------------------------------------------------------------- sgddtw
CONTENT[SG] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:ssg (from-scratch stochastic subgradient mean, Schultz & Jain 2018, tslearn step schedule and stopping rule mirrored, driven by numpy.random.RandomState(seed) with the global-RNG stream simulated over pairs in Directed.multivariate order) via h_ssg, h_ssg_bc, h_rngdep, h_cache, h_cold (order), h_seeds50; {REF}:h_vs_dba (objective vs from-scratch DBA, qualitative); {REF}:h_xx (analytic); h_det, h_sym (same-lineage)",
    check_data="bivariate_gaussian, delayed_noise, narrowband_f0-0.25 (kernel T=64/256, four identifiers + raw barycenters); bivariate_gaussian, delayed_noise, logistic_maps, iid_gaussian (pipeline T=1024); bivariate_gaussian seed 43; bivariate_gaussian / iid_gaussian processes [0,1] T=256 over seeds 0..49; bivariate_gaussian, delayed_noise, logistic_maps T=256 and delayed_noise [0,3] T=1024 (objective); iid_gaussian [0,0] (analytic); var2_bivariate, delayed_noise, logistic_maps_chaotic, anm T=1024 (symmetry)",
    agreement_criterion="from-scratch SSG on the same RNG stream: rtol 1e-9, atol 1e-10 (statistics, raw barycenters, 50-seed barycenters, after-consumer and shared-cache runs, ordered pairs); analytic SSG(x, x) = x: exact; determinism under seed_all(42): bit-identical; objective comparison: qualitative, pass if F(sgddtw) < F(Euclidean init) on every pair, gaps to DBA and to a 30-epoch SSG reported",
    closeness="SSG statistics: 33/33 runs pass, max_abs 2.2e-16, max_rel 9.6e-14 (kernel T=64/256 four identifiers, pipeline T=1024, seed 43); raw barycenters 6/6, max_abs 2.2e-16; 50 seeds x 2 datasets: max_abs 2.2e-16. After another sgddtw SPI consumed the global RNG (*|rngdep|*): max_abs 0 against the reference that simulates the consumer's draws, and the pyspi value moved by up to 0.0278 (1.5% relative) from the plain seed-42 run. Shared Data (*|cache|*): the second sgddtw identifier reuses the first one's barycenter and consumes no RNG draws (flag 0), max_abs 0. Determinism: two seed_all(42) runs differ by 0. Epochs: bivariate_gaussian T=256 kernel stops after 3-5 epochs on all 6 pairs by the cost-increase rule; delayed_noise T=1024 3-30 epochs. Seed spread (bivariate_gaussian [0,1] T=256 pipeline): SD over 50 seeds 3.0e-4 (mean), 8.0e-3 (max), range of max 0.0168; iid_gaussian: 1.8e-3 / 2.9e-3. Objective F = mean_k DTW^2 (*|vs-dba|*): F(sgddtw) < F(Euclidean init) on every pair (pass), but F(sgddtw)/F(DBA) - 1 = 0.02-0.43 on bivariate_gaussian (30-epoch SSG 0.006-0.15), -0.05 to 3.62 on delayed_noise T=256, 1.86 on logistic_maps, 0.995 on delayed_noise [0,3] T=1024. SSG(x, x) = x: 4/4 exact. Symmetry: max|A - A.T| = 0 on all four direction datasets.",
    verdict="variant",
    score_0_10=5,
    what_changed="The update rule and step schedule match tslearn's stochastic subgradient mean exactly (independent replication to 1e-13, including the global-RNG stream). It deviates from Schultz & Jain (arXiv:1701.06393v1, Sec. 3 termination criteria T1/T2; Sec. 5.1 runs fixed 50 epochs): tslearn stops when the pre-update DTW^2 of the single last-processed series rises between epochs, which happens after 3-5 epochs on most Gaussian pairs, so the returned barycenter is an under-converged Frechet-mean estimate (cost 2-43% above DBA on bivariate_gaussian, up to 3.6x on delayed copies). The update uses 2*eta where arXiv v1 Alg. 3 line 8 has eta (a factor-2 step-size scaling). The value depends on the global numpy RNG state, hence on every RNG draw consumed earlier in a Calculator run (already documented, tests/README.md:134/146); within one Data object the first sgddtw identifier fixes the barycenter for the other three. Scored 5: a non-standard estimator with no literature definition (SSG with last-sample early stopping), computed exactly as the code states.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap on the pyspi side (<= 2.8 s per run, T <= 1024); from-scratch SSG ~0.1 s per epoch per series at T=1024",
    symmetry_observed="sym: max|A - A.T| = 0 on var2_bivariate, delayed_noise, logistic_maps_chaotic, anm (T=1024, bary_sgddtw_max) because of the per-pair cache; the uncached routine is NOT order-invariant: cold-cache bivariate(i,j) vs bivariate(j,i) with the same seed differ by max|M - M.T| = 0.0486 (bivariate_gaussian) and 0.379 (delayed_noise) on bary_sgddtw_max at T=256 (*|order|* runs, reproduced exactly by the reference)",
    direction_observed="none: A[i,j] = A[j,i] bit-identically on var2_bivariate, delayed_noise, logistic_maps_chaotic, anm; any input-order effect is stochastic and hidden by the cache, so A[i,j] carries no direction",
    candidate_resolutions=[
        dict(candidate="premature last-sample stopping makes sgddtw an under-converged DTW barycenter", outcome="confirmed",
             evidence="distance.bary.sgddtw|*|vs-dba|*: F(sgddtw) > F(DBA) on 13 of 14 pairs and > F(30-epoch SSG) on 12 of 14 (equal on the other 2, where the run went the full 30 epochs) (bivariate_gaussian rel gap to DBA 0.02-0.43 vs 0.006-0.15 for 30 epochs; logistic_maps 1.86 vs 0.80); ref_stopped_on_increase 1 on all 6 pairs of distance.bary.sgddtw|bivariate_gaussian|256|kernel|ssg|* after 3-5 epochs; paper termination (T1)/(T2) uses F over all samples (arXiv:1701.06393v1 Sec. 3)"),
        dict(candidate="cache/ordering effect: the first sgddtw identifier fixes the barycenter for the others; pair {a<b} computed from z[[b, a]]", outcome="confirmed",
             evidence="distance.bary.sgddtw|bivariate_gaussian|256|kernel|cache|bary_sgddtw_max: second identifier equals the seed-42 reference with max_abs 0 and consumed no RNG draws (flag 0); the z[[b, a]] order is part of every exact *|ssg|* match (stream simulated in that order)"),
        dict(candidate="input-order dependence for a fixed RNG draw, hidden by the cache", outcome="confirmed",
             evidence="distance.bary.sgddtw|{bivariate_gaussian,delayed_noise}|256|kernel|order|bary_sgddtw_max: with np.random.seed(42) before every cold call, max|M - M.T| = 0.0486 and 0.379; the from-scratch SSG reproduces the ordered-pair matrix (max_abs 2.2e-16)"),
        dict(candidate="_mm_assignment cost uses weights[0]/weights.sum() for every series (harmless with uniform weights)", outcome="confirmed",
             evidence="the from-scratch SSG uses dist^2 * 1/n for the stopping cost and reproduces every stopping decision (all *|ssg|* and *|seeds50|* runs exact to 2.2e-16); with unit weights weights[0]/sum = 1/n for every series"),
    ],
    checks_run=[
        dict(run_ids=["distance.bary.sgddtw|*|{64,256}|kernel|ssg|*", "distance.bary.sgddtw|*|1024|pipeline|ssg|*", "distance.bary.sgddtw|bivariate_gaussian|256|kernel|ssg|bary_sgddtw_mean|seed43"], reference=f"{REF}:h_ssg (independent-impl)", outcome="pass 33/33; max_rel 9.6e-14"),
        dict(run_ids=["distance.bary.sgddtw|*|{64,256}|kernel|ssg-bc|bary_sgddtw_mean"], reference=f"{REF}:h_ssg_bc (independent-impl)", outcome="pass 6/6; max_abs 2.2e-16"),
        dict(run_ids=["distance.bary.sgddtw|bivariate_gaussian|256|kernel|rngdep|bary_sgddtw_max", "distance.bary.sgddtw|bivariate_gaussian|256|kernel|cache|bary_sgddtw_max"], reference=f"{REF}:h_rngdep, h_cache (independent-impl)", outcome="pass 2/2; max_abs 0; change vs plain seed-42 run 0.0278"),
        dict(run_ids=["distance.bary.sgddtw|{bivariate_gaussian,iid_gaussian}|256|pipeline|seeds50|bary_sgddtw_mean|p0-1"], reference=f"{REF}:h_seeds50 (independent-impl)", outcome="pass 2/2; SD over seeds of bary_sgddtw_max 8.0e-3 / 2.9e-3"),
        dict(run_ids=["distance.bary.sgddtw|{bivariate_gaussian,delayed_noise}|256|kernel|order|bary_sgddtw_max"], reference=f"{REF}:h_cold (independent-impl)", outcome="pass 2/2; max_abs 2.2e-16; max|M - M.T| 0.0486 / 0.379"),
        dict(run_ids=["distance.bary.sgddtw|*|vs-dba|bary_sgddtw_mean"], reference=f"{REF}:h_vs_dba (independent-impl, qualitative)", outcome="pass 4/4 (descent); rel gap to DBA up to 3.62"),
        dict(run_ids=["distance.bary.sgddtw|iid_gaussian|256|kernel|xx|*|p0-0"], reference=f"{REF}:h_xx (analytic)", outcome="pass 4/4; exact"),
        dict(run_ids=["distance.bary.sgddtw|bivariate_gaussian|256|kernel|det|bary_sgddtw_max", "distance.bary.sgddtw|*|1024|pipeline|sym|bary_sgddtw_max"], reference=f"{REF}:h_det, h_sym (same-lineage)", outcome="pass 5/5; repeat diff 0; max|A - A.T| 0"),
    ],
)

# ---------------------------------------------------------------------------------------------- softdtw
CONTENT[SD] = dict(
    check_method="independent-impl",
    check_reference=f"audit/checks/refs/_kernels_distance.py:soft_dtw_barycenter_objective (Cuturi & Blondel 2017 Alg. 1-2) + scipy.optimize.minimize L-BFGS-B with tslearn's settings via {REF}:softdtw_bary, h_sdtw, h_sdtw_bc, h_obj0, h_cold, h_xx; {REF}:h_fd (central differences); {REF}:h_opt_sdtw (gradient at the returned barycenter and tight re-optimisation); {REF}:h_gamma (analytic contrast, gamma sweep); h_sym (same-lineage)",
    check_data="bivariate_gaussian, delayed_noise, narrowband_f0-0.25, iid_gaussian (kernel T=64, four identifiers + raw barycenters); bivariate_gaussian, delayed_noise, narrowband_f0-0.25 (pipeline T=256 statistics; optimality at T=64/256 all pairs and T=1024 pair [0,1]); bivariate_gaussian [0,1] T=4096 (optimality lower bound); bivariate_gaussian, delayed_noise T=64/256 (objective at init); bivariate_gaussian, iid_gaussian [0,1] T=64 (finite differences); iid_gaussian, narrowband_f0-0.25 [0,0] T=256 (identical series, gamma sweep); var2_bivariate, delayed_noise, logistic_maps_chaotic, anm T=1024 (symmetry)",
    agreement_criterion="statistics of the from-scratch barycenter: rtol 1e-6, atol 1e-8; raw barycenters rtol/atol 1e-6; objective and gradient at the init: rtol 1e-9, atol 1e-9; finite differences: rtol/atol 1e-5; optimality (declared before running): relative objective gap to a tight L-BFGS-B re-optimisation (ftol = gtol = 1e-12) <= 1e-3 on every pair (T=4096: lower bound from one Armijo step); gamma sweep: var(b) < var(x) at gamma 1 and max|b - x| decreasing with gamma; symmetry: max|A - A.T| == 0",
    closeness="From-scratch soft-DTW barycenter vs pyspi: statistics 19/19 pass, max_abs 3.7e-13, max_rel 2.4e-13 (*|sdtw|*; L-BFGS-B took 4-12 iterations, all success); raw barycenters 4/4, max_abs 7.0e-14; objective and gradient at the Euclidean init 4/4, max_abs 2.8e-13; tslearn gradient vs central differences 2/2, max_abs 2.4e-8. Optimality (*|opt|*) FAILS on bivariate_gaussian and delayed_noise at every T: relative objective gap 2.2e-5 to 0.0138 (T=64), 2.5e-4 to 0.0058 (T=256), >= 0.0012 and >= 0.0031 (T=1024, re-optimisation capped at 40 iterations), >= 0.0010 (T=4096, one line-search step); max|grad(b)|/max|grad(b0)| 0.02-0.27; re-optimisation moves bary_softdtw_max by up to 0.051 and bary_softdtw_mean by up to 0.030 (bivariate_gaussian T=64 pair (2,3)). narrowband_f0-0.25 passes at T=64/256/1024 (gap <= 6.0e-5). Identical series (x, x), raw input, gamma=1: pyspi barycenter equals the reference to 7.3e-14 and is shrunk: iid_gaussian max|b - x| 1.315, var(b) 0.732 vs var(x) 1.015; narrowband_f0-0.25 var(b) 0.0036 vs 0.511 and max(b) 0.312 vs max(x) 1.142. gamma sweep 1 / 0.1 / 0.01: max|b - x| 1.315 / 0.234 / 0.022 (iid) and 1.136 / 0.0015 / 0 (narrowband). Symmetry: max|A - A.T| = 0 on the four direction datasets; cold-cache ordered pairs (delayed_noise T=64) match the reference to 4.1e-12 with max|M - M.T| = 0.",
    verdict="variant",
    score_0_10=6,
    what_changed="Objective, gradient and the optimiser path are reproduced exactly (the soft-DTW code in tslearn is Blondel's; independent reference to 1e-13). Two value-changing properties: (1) tslearn calls L-BFGS-B with tol=1e-3 (ftol = gtol) and maxiter 50 and returns res.x without checking convergence; on Gaussian and delayed pairs it stops 0.02-1.4% above the attainable objective, which moves bary_softdtw_max by up to 0.05 and bary_softdtw_mean by up to 0.03 at T=64 (narrowband pairs converge). (2) With gamma = 1 on z-scored or raw data, the soft-DTW barycenter is strongly smoothed and shrunk (the barycenter of (x, x) is not x; a raw sinusoid collapses to var 0.0036 from 0.511). This follows from the soft-DTW definition (soft-DTW is not a divergence), so it is a property of the canonical quantity with gamma = 1, not an implementation error, but it makes bary_softdtw_max a different quantity from the DTW-barycenter max that the supplement's wording ('minimizes the sum of squared distances') suggests.",
    new_finding=True,
    definition_under_review=False,
    check_cost="expensive: pyspi ~4 s per pair at T=1024 (24.6 s for 6 pairs of delayed_noise) and 66 s for ONE pair at T=4096 (O(T^2) per objective evaluation); the from-scratch objective costs ~0.7 s per evaluation at T=1024",
    symmetry_observed="sym: max|A - A.T| = 0 on var2_bivariate, delayed_noise, logistic_maps_chaotic, anm (T=1024, bary_softdtw_max); cold-cache ordered pairs on delayed_noise T=64 also give max|M - M.T| = 0 (symmetric objective, Euclidean init)",
    direction_observed="none: A[i,j] = A[j,i] bit-identically on all four direction datasets; the statistic carries no direction",
    candidate_resolutions=[
        dict(candidate="gamma = 1 shrinks/smooths the barycenter; barycenter of (x, x) is not x", outcome="confirmed",
             evidence="distance.bary.softdtw|{iid_gaussian,narrowband_f0-0.25}|256|kernel|{xx,gamma}|bary_softdtw_mean|p0-0: max|b - x| 1.315 / 1.136, var(b) 0.732 vs 1.015 and 0.0036 vs 0.511; deviation falls to 0.022 / 0 at gamma 0.01. A property of the soft-DTW definition (Blondel, Mensch & Vert 2021), recorded as such"),
        dict(candidate="tol=1e-3, maxiter 50, no success check could return a non-converged barycenter", outcome="confirmed",
             evidence="distance.bary.softdtw|*|opt|bary_softdtw_mean: 7 of 10 runs fail the declared gap <= 1e-3 rule; gaps up to 0.0138 (T=64), 0.0058 (T=256), >= 0.0031 (T=1024), >= 0.0010 (T=4096); statistic changes up to 0.051 (max) and 0.030 (mean). Already visible at T=64, not only at T=4096"),
        dict(candidate="cost: O(T^2) per objective evaluation, dominant barycenter cost", outcome="confirmed",
             evidence="out/pyspi/index/barycenters.json time_s: distance.bary.softdtw|delayed_noise|1024|pipeline|sym|bary_softdtw_max 24.6 s (6 pairs), distance.bary.softdtw|bivariate_gaussian|4096|pipeline|opt|bary_softdtw_mean|p0-1 66.4 s (1 pair); DBA and SSG runs <= 4.6 s"),
        dict(candidate="label inconsistencies and undocumented bary-sq_softdtw_* identifiers", outcome="confirmed",
             evidence="static (distance.py:211-215, config.yaml:255-311, supplement lines 321-329); bary_softdtw_mean takes both signs (trace probe2 -0.0243 .. 0.0036)"),
    ],
    checks_run=[
        dict(run_ids=["distance.bary.softdtw|*|64|kernel|sdtw|*", "distance.bary.softdtw|*|256|pipeline|sdtw|bary_softdtw_max"], reference=f"{REF}:h_sdtw (independent-impl)", outcome="pass 19/19; max_rel 2.4e-13"),
        dict(run_ids=["distance.bary.softdtw|*|64|kernel|sdtw-bc|bary_softdtw_mean"], reference=f"{REF}:h_sdtw_bc (independent-impl)", outcome="pass 4/4; max_abs 7.0e-14"),
        dict(run_ids=["distance.bary.softdtw|*|kernel|obj0|bary_softdtw_mean", "distance.bary.softdtw|*|64|kernel|fd|bary_softdtw_mean|p0-1"], reference=f"{REF}:h_obj0, h_fd (independent-impl)", outcome="pass 6/6; objective/gradient max_abs 2.8e-13; finite differences 2.4e-8"),
        dict(run_ids=["distance.bary.softdtw|*|pipeline|opt|bary_softdtw_mean*"], reference=f"{REF}:h_opt_sdtw (independent-impl, optimality)", outcome="fail 7/10 (bivariate_gaussian and delayed_noise at T=64/256/1024/4096); pass 3/3 narrowband; max gap 0.0138"),
        dict(run_ids=["distance.bary.softdtw|*|256|kernel|xx|bary_softdtw_mean|p0-0", "distance.bary.softdtw|*|256|kernel|gamma|bary_softdtw_mean|p0-0"], reference=f"{REF}:h_xx (independent-impl), h_gamma (analytic contrast)", outcome="pass 4/4; max|b - x| 1.315 / 1.136 at gamma 1"),
        dict(run_ids=["distance.bary.softdtw|*|1024|pipeline|sym|bary_softdtw_max", "distance.bary.softdtw|delayed_noise|64|pipeline|cold|bary_softdtw_max"], reference=f"{REF}:h_sym (same-lineage), h_cold (independent-impl)", outcome="pass 5/5; max|A - A.T| 0"),
    ],
)
