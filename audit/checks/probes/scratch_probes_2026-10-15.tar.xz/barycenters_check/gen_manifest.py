import json
OUT = '/media/dan/Data/git/pyspi/audit/checks/manifest/barycenters.json'
EU, DT, SG, SD = ('distance.bary.' + m for m in ('euclidean', 'dtw', 'sgddtw', 'softdtw'))
ALL_DS = ['iid_gaussian', 'bivariate_gaussian', 'scaled_offset', 'trending', 'var2_bivariate', 'var2_chain',
          'delayed_noise', 'narrowband_f0-0.1', 'narrowband_f0-0.25', 'narrowband_f0-0.4', 'logistic_maps',
          'logistic_maps_bidir', 'logistic_maps_chaotic', 'logistic_maps_sugihara', 'nonlinear_dependence',
          'contaminated', 'cointegrated', 'anm', 'sparse_precision', 'shared_envelope', 'gauss_ar1_pair']
DIR_DS = ['var2_bivariate', 'delayed_noise', 'logistic_maps_chaotic', 'anm']
runs = []
def add(unit, ident, ds, T, path, tag, processes=None, seed=42, probe=None):
    rid = f"{unit}|{ds}|{T}|{path}|{tag}"
    if ident is not None:
        rid += f"|{ident}"
    if processes is not None:
        rid += "|p" + "-".join(map(str, processes))
    if seed != 42:
        rid += f"|seed{seed}"
    runs.append(dict(run_id=rid, unit_id=unit, identifier=ident, dataset=ds, T=T, path=path,
                     processes=processes, seed=seed,
                     probe=None if probe is None else {"module": "probes/barycenters_probes.py", "function": probe}))
def ids(mode):
    return [f"bary_{mode}_mean", f"bary_{mode}_max", f"bary-sq_{mode}_mean", f"bary-sq_{mode}_max"]

# ---------------- euclidean
for ds in ALL_DS:
    for T in (64, 1024, 4096):
        add(EU, 'bary_euclidean_mean', ds, T, 'pipeline', 'zero')
    add(EU, 'bary_euclidean_mean', ds, 1024, 'pipeline-detrend', 'zero')
for ds in ('bivariate_gaussian', 'sparse_precision', 'iid_gaussian', 'contaminated'):
    for T in (64, 256, 1024):
        add(EU, 'bary-sq_euclidean_mean', ds, T, 'pipeline', 'formula')
for ds in ('bivariate_gaussian', 'delayed_noise', 'narrowband_f0-0.25', 'nonlinear_dependence'):
    for ident in ids('euclidean'):
        add(EU, ident, ds, 256, 'kernel', 'scratch')
        add(EU, ident, ds, 1024, 'pipeline', 'scratch')
for ds in ('trending', 'scaled_offset'):
    for T in (256, 1024):
        for ident in ids('euclidean'):
            add(EU, ident, ds, T, 'pipeline-detrend', 'detrend')
add(EU, 'bary_euclidean_mean', 'scaled_offset', 1024, 'kernel', 'offset')
for ident in ids('euclidean'):
    add(EU, ident, 'scaled_offset', 1024, 'pipeline', 'invariance')
for T in (256, 1024, 4096):
    add(EU, 'bary-sq_euclidean_mean', 'bivariate_gaussian', T, 'pipeline', 'popstat')
for ds in DIR_DS:
    add(EU, 'bary_euclidean_max', ds, 1024, 'pipeline', 'sym')
add(EU, 'bary_euclidean_max', 'delayed_noise', 1024, 'pipeline', 'cold', probe='cold_matrix')

# ---------------- dtw (DBA)
DBA_DS = ['bivariate_gaussian', 'delayed_noise', 'narrowband_f0-0.25', 'logistic_maps']
for ds in DBA_DS:
    for T in (64, 256):
        for ident in ids('dtw'):
            add(DT, ident, ds, T, 'kernel', 'dba')
        add(DT, 'bary_dtw_mean', ds, T, 'kernel', 'dba-bc', probe='barycenters')
for ds in DBA_DS + ['iid_gaussian']:
    for T in (64, 256, 1024):
        add(DT, 'bary_dtw_mean', ds, T, 'pipeline', 'dba')
    add(DT, 'bary_dtw_max', ds, 1024, 'pipeline', 'dba')
for ds in ('bivariate_gaussian', 'delayed_noise', 'narrowband_f0-0.25'):
    add(DT, 'bary_dtw_mean', ds, 256, 'pipeline', 'opt', probe='barycenters')
for ident in ids('dtw'):
    add(DT, ident, 'iid_gaussian', 256, 'kernel', 'xx', processes=[0, 0])
for ds in ('delayed_noise', 'narrowband_f0-0.25'):
    add(DT, 'bary_dtw_max', ds, 1024, 'pipeline', 'vs-eucl')
for ds in DIR_DS:
    add(DT, 'bary_dtw_max', ds, 1024, 'pipeline', 'sym')
add(DT, 'bary_dtw_max', 'delayed_noise', 256, 'pipeline', 'cold', probe='cold_matrix')

# ---------------- sgddtw (SSG)
SSG_DS = ['bivariate_gaussian', 'delayed_noise', 'narrowband_f0-0.25']
for ds in SSG_DS:
    for T in (64, 256):
        for ident in ids('sgddtw'):
            add(SG, ident, ds, T, 'kernel', 'ssg')
        add(SG, 'bary_sgddtw_mean', ds, T, 'kernel', 'ssg-bc', probe='barycenters')
for ds in ('bivariate_gaussian', 'delayed_noise', 'logistic_maps', 'iid_gaussian'):
    for ident in ('bary_sgddtw_mean', 'bary_sgddtw_max'):
        add(SG, ident, ds, 1024, 'pipeline', 'ssg')
add(SG, 'bary_sgddtw_mean', 'bivariate_gaussian', 256, 'kernel', 'ssg', seed=43)
add(SG, 'bary_sgddtw_max', 'bivariate_gaussian', 256, 'kernel', 'det', probe='sgd_twice')
add(SG, 'bary_sgddtw_max', 'bivariate_gaussian', 256, 'kernel', 'rngdep', probe='sgd_after_consumer')
add(SG, 'bary_sgddtw_max', 'bivariate_gaussian', 256, 'kernel', 'cache', probe='sgd_cache')
for ds in ('bivariate_gaussian', 'delayed_noise'):
    add(SG, 'bary_sgddtw_max', ds, 256, 'kernel', 'order', probe='cold_matrix')
for ds in ('bivariate_gaussian', 'iid_gaussian'):
    add(SG, 'bary_sgddtw_mean', ds, 256, 'pipeline', 'seeds50', processes=[0, 1], probe='sgd_seeds')
for ds in ('bivariate_gaussian', 'delayed_noise', 'logistic_maps'):
    add(SG, 'bary_sgddtw_mean', ds, 256, 'pipeline', 'vs-dba', probe='barycenters')
add(SG, 'bary_sgddtw_mean', 'delayed_noise', 1024, 'pipeline', 'vs-dba', processes=[0, 3], probe='barycenters')
for ident in ids('sgddtw'):
    add(SG, ident, 'iid_gaussian', 256, 'kernel', 'xx', processes=[0, 0])
for ds in DIR_DS:
    add(SG, 'bary_sgddtw_max', ds, 1024, 'pipeline', 'sym')

# ---------------- softdtw
SD_DS = ['bivariate_gaussian', 'delayed_noise', 'narrowband_f0-0.25', 'iid_gaussian']
for ds in SD_DS:
    for ident in ids('softdtw'):
        add(SD, ident, ds, 64, 'kernel', 'sdtw')
    add(SD, 'bary_softdtw_mean', ds, 64, 'kernel', 'sdtw-bc', probe='barycenters')
for ds in ('bivariate_gaussian', 'delayed_noise', 'narrowband_f0-0.25'):
    add(SD, 'bary_softdtw_max', ds, 256, 'pipeline', 'sdtw')
for ds in ('bivariate_gaussian', 'delayed_noise'):
    for T in (64, 256):
        add(SD, 'bary_softdtw_mean', ds, T, 'kernel', 'obj0', probe='softdtw_obj_at_init')
for ds in ('bivariate_gaussian', 'iid_gaussian'):
    add(SD, 'bary_softdtw_mean', ds, 64, 'kernel', 'fd', processes=[0, 1], probe='softdtw_obj_at_init')
for ds in ('bivariate_gaussian', 'delayed_noise', 'narrowband_f0-0.25'):
    for T in (64, 256):
        add(SD, 'bary_softdtw_mean', ds, T, 'pipeline', 'opt', probe='barycenters')
    add(SD, 'bary_softdtw_mean', ds, 1024, 'pipeline', 'opt', processes=[0, 1], probe='barycenters')
add(SD, 'bary_softdtw_mean', 'bivariate_gaussian', 4096, 'pipeline', 'opt', processes=[0, 1], probe='barycenters')
for ds in ('iid_gaussian', 'narrowband_f0-0.25'):
    add(SD, 'bary_softdtw_mean', ds, 256, 'kernel', 'xx', processes=[0, 0], probe='barycenters')
    add(SD, 'bary_softdtw_mean', ds, 256, 'kernel', 'gamma', processes=[0, 0], probe='barycenters')
for ds in DIR_DS:
    add(SD, 'bary_softdtw_max', ds, 1024, 'pipeline', 'sym')
add(SD, 'bary_softdtw_max', 'delayed_noise', 64, 'pipeline', 'cold', probe='cold_matrix')

rids = [r['run_id'] for r in runs]
assert len(rids) == len(set(rids))
json.dump({"family": "barycenters", "runs": runs}, open(OUT, 'w'), indent=1)
print(len(runs), 'runs')
