import sys, time, json
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import barycenters as B
import numpy as np
from scipy.optimize import minimize
kd = B.kd
man = json.load(open('/media/dan/Data/git/pyspi/audit/checks/manifest/barycenters.json'))['runs']
for ds in sys.argv[1:]:
    rid = f"distance.bary.softdtw|{ds}|1024|pipeline|opt|bary_softdtw_mean|p0-1"
    run = [r for r in man if r['run_id'] == rid][0]
    z = B.prep(B.load_x(run), run['path'])
    b = B.pyspi_value(rid)[0]
    a, c = list(B.pairs(z.shape[0]))[0]
    X = z[[c, a]]
    t = time.time()
    fb = kd.soft_dtw_barycenter_objective(b, X)[0]
    res = minimize(lambda q: kd.soft_dtw_barycenter_objective(q, X), b, method="L-BFGS-B", jac=True,
                   options=dict(maxiter=2000, ftol=1e-12, gtol=1e-8))
    g = kd.soft_dtw_barycenter_objective(res.x, X)[1]
    print(ds, 'nit', res.nit, 'nfev', res.nfev, res.message, 'time', round(time.time()-t,1), 'fb', fb, 'fbest', res.fun,
          'gap', (fb-res.fun)/abs(res.fun), 'maxgrad', np.max(np.abs(g)), 'dmax', abs(res.x.max()-b.max()), 'dmean', abs(res.x.mean()-b.mean()), flush=True)
