import sys, time, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import make_data, _kernels_distance as kd
for T in (256, 1024):
    x = make_data.load('bivariate_gaussian', T)['x']
    z = (x - x.mean(1, keepdims=True)) / x.std(1, ddof=1, keepdims=True)
    t = time.perf_counter(); d, p = kd.dtw_path(z[0], z[1]); print(T, 'dtw_path', time.perf_counter() - t)
    t = time.perf_counter(); b, c = kd.dba(z[[1, 0]]); print(T, 'dba', len(c), time.perf_counter() - t)
    t = time.perf_counter(); f, g = kd.soft_dtw_barycenter_objective(z[[1, 0]].mean(0), z[[1, 0]]); print(T, 'sdtw obj', time.perf_counter() - t)
