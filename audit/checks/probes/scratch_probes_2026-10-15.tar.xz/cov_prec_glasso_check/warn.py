# direct sklearn fit outside pyspi: does a ConvergenceWarning exist to be silenced?
import sys, warnings
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); import make_data, numpy as np
from scipy.stats import zscore
from sklearn.covariance import GraphicalLasso, GraphicalLassoCV
for ds,T,E in [('var2_bivariate',4096,GraphicalLasso),('shared_envelope',4096,GraphicalLassoCV),('narrowband_f0-0.25',256,GraphicalLasso)]:
    z=zscore(make_data.load(ds,T)['x'],axis=1,ddof=1).T
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always'); E().fit(z)
    print(ds,T,E.__name__,[str(x.category.__name__)+': '+str(x.message)[:70] for x in w])
