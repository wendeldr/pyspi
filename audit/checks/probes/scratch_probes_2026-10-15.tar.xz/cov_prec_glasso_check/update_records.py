"""Fill the check-stage fields of the four cov_prec_glasso records (throwaway writer)."""
import yaml

REC = "/media/dan/Data/git/pyspi/audit/records/{}.yaml"
REF = "audit/checks/refs/cov_prec_glasso.py"
PROBE = "audit/checks/probes/cov_prec_glasso_fit.py"
RSCRIPT = "audit/checks/r/cov_prec_glasso.R"

COMMON_REF = (f"{REF}: ref_cf (analytic P=2 closed form W12 = soft(S12, alpha), Theta = inv(W)), admm_glasso (numpy ADMM, "
              "Boyd et al. 2011 §6.5, off-diagonal l1, stopped at KKT residual <= 1e-12*max(1,max|S|)), ref_kkt "
              "(_kernels_basic_misc.glasso_kkt_residual, Friedman, Hastie & Tibshirani 2008 eq. 2 with unpenalised diagonal), "
              f"ref_rglasso (R glasso==1.11, R 4.6.1, glasso(S, rho=alpha, penalize.diagonal=FALSE, thr=1e-12) via {RSCRIPT}), "
              "ref_stat, ref_sym, ref_perm, ref_fail, ref_range/ref_pcorr, ref_side, ref_sq; probes "
              f"{PROBE} (full_fit, calc_style, perm, side_effects)")

DATA_GL = ("kernel: var2_bivariate T64/256/1024/4096, gauss_ar1_pair T256/1024/4096, logistic_maps T1024, logistic_maps_bidir T1024, "
           "contaminated T256/1024, sparse_precision T64-4096, bivariate_gaussian T64-4096, iid_gaussian, delayed_noise, "
           "nonlinear_dependence, var2_chain, scaled_offset T1024; pipeline: var2_bivariate T64-4096, gauss_ar1_pair T1024/4096, "
           "logistic_maps(_bidir, _chaotic) T1024, sparse_precision/bivariate_gaussian T64-4096, narrowband_f0-0.1/0.25/0.4 "
           "T256/1024/4096, shared_envelope T64-4096, cointegrated/trending T256/1024/4096, iid_gaussian T64/1024, delayed_noise, "
           "var2_chain, scaled_offset, contaminated T64/1024; pipeline-detrend: trending T4096, shared_envelope T1024, "
           "narrowband_f0-0.1 T64")
DATA_CV = DATA_GL.replace("pipeline-detrend: trending T4096, shared_envelope T1024, narrowband_f0-0.1 T64",
                          "pipeline-detrend: shared_envelope T256/1024, narrowband_f0-0.1 T64, trending T4096; "
                          "CV-only: iid_gaussian T64-4096 and nonlinear_dependence/var2_chain T1024 (degenerate check), "
                          "sparse_precision T256/1024, bivariate_gaussian/iid_gaussian/delayed_noise/var2_chain T1024 (CV selection)")

CRIT = ("cf: tolerance 1e-10 abs (P=2 closed form); admm, rglasso and perm: tolerance 1e-3*max|ref off-diagonal| abs; kkt: "
        "optimality, pass iff KKT residual <= 1e-4 (sklearn tol/enet_tol = 1e-4 act on the dual gap; the actual residual and "
        "sklearn's final dual gap are reported per run); stat: statistical, |pyspi - population glasso target| <= "
        "Bonferroni z (2.81 for 10 entries) * asymptotic Gaussian-MLE sd; sym: bit-exact max|A - A.T| == 0; sq: exact "
        "square of the base identifier; fail/side: qualitative, observed outcome equals the trace-stage prediction")

UNITS = {}

# ----------------------------------------------------------------------------------------- cov.GraphicalLasso
UNITS["basic.cov.GraphicalLasso"] = dict(
    check_method="analytic",
    check_reference=COMMON_REF,
    check_data=DATA_GL,
    agreement_criterion=CRIT + "; range: |W_ij| <= (T-1)/T and |W_ij - S_ij| <= alpha + 1e-4",
    closeness=(
        "P=2 closed form (|cf): 16/19 pass, converged fits agree to <= 2.25e-12 abs; fails var2_bivariate T4096 pipeline 8.652e-4 "
        "(pyspi W12 0.20643823 equals the 0.95*S12 starting value to 9.6e-12; optimum 0.20730340), var2_bivariate T1024 pipeline "
        "1.333e-5 and logistic_maps_chaotic T1024 pipeline 5.71e-5 (early stop). ADMM (|admm): 17/17 pass, max abs 5.64e-5. "
        "R glasso 1.11 (|rglasso): 10/11 pass, max abs 7.86e-5; fail var2_bivariate T4096 8.65e-4 (the stall); R KKT residual "
        "<= 7.5e-12. KKT on pyspi's W (|kkt): 34/37 <= 1e-4 (well-conditioned sparse_precision/bivariate_gaussian max 4.22e-5); "
        "fails cointegrated T256 1.33e-4, var2_bivariate T4096 8.65e-4, trending T4096 FloatingPointError (all-NaN). 13 of 36 "
        "fits end with |dual gap| >= 1e-4 after up to 100 sweeps, 0 warnings reach the caller, a direct sklearn fit of the same "
        "array emits ConvergenceWarning in all 13; W stays within 1.33e-4 of the ADMM optimum except the stall; objective excess "
        "up to 0.031 (shared_envelope T1024). W_ii - S_ii <= 4.4e-16 and W_ii - (T-1)/T <= 8.9e-16 (pipeline). max|inv(W) - "
        "Theta|: 9.5e-6 to 2.44e-4 on sparse_precision/bivariate_gaussian, 1.6e-13/1.9e-13/2.2e-16 on gauss_ar1_pair/"
        "logistic_maps/logistic_maps_bidir T1024, up to 0.408 (shared_envelope T1024). Statistical (|stat, sparse_precision "
        "kernel): 3/4 pass (max_z 1.05-1.26); T1024 max_z 2.29 because the sample covariance itself is 3.20 sd from cov_true "
        "on entry (2,3). Symmetry 0.0 on all 65 plain runs; permutation 3/3 (<= 3.8e-5); range 6/6; -sq exact; failure modes "
        "6/6 as predicted; side effects 2/2 as predicted."),
    verdict="variant",
    score_0_10=7,
    what_changed=(
        "Yuan & Lin form of Friedman 2008 (diagonal not penalised: W_ii = S_ii; R glasso with penalize.diagonal=TRUE differs "
        "by up to 2.2e-3 off-diagonal), S divides by T on ddof=1 z-scored data (W_ii = (T-1)/T), alpha = 0.01 fixed absolute. "
        "Optimisation is approximate and silent: sklearn 1.9.1 stops at |dual gap| < 1e-4 or 100 sweeps, ConvergenceWarning "
        "is suppressed, and on var2_bivariate T4096 (P=2) the solver returns its 0.95*S starting point (error 8.65e-4). "
        "Ill-conditioned inputs can raise FloatingPointError (all-NaN SPI). The supplement's 'sparsify the covariance matrix' "
        "does not hold (the penalty acts on the precision)."),
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap (whole family 499 runs in about 3.3 min: pyspi 78 s, references 6-8 s; a GraphicalLasso fit takes milliseconds, T <= 4096)",
    symmetry_observed="sym: max|A - A.T| = 0.0 (bit-exact) on all 65 plain runs; diagonal NaN",
    direction_observed=(
        "undirected: A[i, j] = A[j, i] exactly on the directed datasets too (var2_bivariate x0->x1, logistic_maps_chaotic x->y, "
        "var2_chain, delayed_noise); A[i, j] refers to processes i and j in input row order (permutation equivariance within "
        "3.8e-5, |perm runs); no lag or direction content"),
)

# ----------------------------------------------------------------------------------------- prec.GraphicalLasso
UNITS["basic.prec.GraphicalLasso"] = dict(
    check_method="analytic",
    check_reference=COMMON_REF,
    check_data=DATA_GL,
    agreement_criterion=CRIT + "; pcorr: tolerance 0.05 abs against the documented partial correlation",
    closeness=(
        "P=2 closed form (|cf): 16/19 pass, converged fits <= 3.32e-13 abs; fails var2_bivariate T4096 pipeline 9.852e-4 "
        "(stall), T1024 pipeline 1.43e-5, logistic_maps_chaotic T1024 pipeline 5.79e-5. ADMM (|admm): 17/17 pass, max abs "
        "2.36e-4. R glasso 1.11 (|rglasso): 8/11 pass, max abs 2.35e-4 on well-conditioned data; fails narrowband_f0-0.25 "
        "T256 0.101, shared_envelope T1024 0.149, var2_bivariate T4096 9.85e-4. KKT on pyspi's Theta (W = inv(Theta), |kkt): "
        "16/37 <= 1e-4; bivariate_gaussian T4096 2.35e-4 although sklearn's dual gap is 7.3e-6 (converged by its own "
        "criterion); ill-conditioned inputs up to 0.212 (shared_envelope T1024); max|Theta - Theta_ADMM| up to 0.267 "
        "(shared_envelope T256, max|Theta_ij| 49.4); 13 non-converged fits with 0 warnings reaching the caller. Statistical "
        "(|stat, sparse_precision kernel): 4/4 pass, max_z 0.81-1.55; nearest-neighbour entries negative at every T; exact "
        "zeros among the 12 non-neighbour entries: 0 (T64, T256), 2 (T1024), 6 (T4096). Documented partial correlation "
        "(|pcorr): 0/4 within 0.05; sign opposite on 100% of nonzero entries; max abs difference 3.21 (bivariate_gaussian "
        "T256, prec 2.385 in magnitude). Symmetry 0.0 on all 63 plain runs; permutation 3/3 (<= 4.4e-5); -sq exact."),
    verdict="variant",
    score_0_10=6,
    what_changed=(
        "Returns the raw graphical-lasso precision entry Theta_ij (Yuan & Lin form, unpenalised diagonal, divide-by-T S, "
        "alpha 0.01), not the documented partial correlation: sign opposite to -Theta_ij/sqrt(Theta_ii Theta_jj) and "
        "unbounded (|Theta_ij| up to 49 on shared_envelope). Theta is the solver's running iterate, not inv(W): its KKT "
        "residual exceeds 1e-4 on 21/37 inputs and its error against the exact optimum reaches 0.27 on ill-conditioned data, "
        "silently (ConvergenceWarning suppressed). The P=2 stall on var2_bivariate T4096 gives 9.85e-4."),
    new_finding=True,
    definition_under_review=True,
    check_cost="cheap (whole family 499 runs in about 3.3 min; a GraphicalLasso fit takes milliseconds, T <= 4096)",
    symmetry_observed="sym: max|A - A.T| = 0.0 (bit-exact) on all 63 plain runs; diagonal NaN (unlike the pinvh precision estimators of REVIEW M2)",
    direction_observed=(
        "undirected: A[i, j] = A[j, i] exactly on the directed datasets too (var2_bivariate x0->x1, logistic_maps_chaotic x->y, "
        "var2_chain, delayed_noise); A[i, j] refers to processes i and j in input row order (permutation equivariance within "
        "4.4e-5); a positive dependence gives a negative entry (sign opposite to the partial correlation)"),
)

# ----------------------------------------------------------------------------------------- cov.GraphicalLassoCV
CV_REF = (COMMON_REF + "; CV-specific: ref_cvsel (independent contiguous 5-fold re-scoring of sklearn's own alpha grid with "
          "ADMM fits, Gaussian test log-likelihood with the test fold centred on its own mean, ties to the smaller alpha), "
          "ref_degen, ref_fit; every reference uses the alpha_ exported by the full_fit probe on the same dataset/T/path "
          "(self-consistency at sklearn's selected alpha, family cap 7)")
UNITS["basic.cov.GraphicalLassoCV"] = dict(
    check_method="independent-impl",
    check_reference=CV_REF,
    check_data=DATA_CV,
    agreement_criterion=CRIT + "; range as for GraphicalLasso at alpha_; cvsel: qualitative, sklearn alpha_ equals the "
    "argmax of the independent CV score; degen: all-zero off-diagonal iff alpha_ >= alpha_max(S); fit: probe off-diagonals "
    "bit-identical to the plain SPI runs",
    closeness=(
        "alpha_ (|fit, |kkt) ranges from 3.05e-8 (var2_bivariate T1024 pipeline) to 0.2069 = alpha_max (iid_gaussian T64); "
        "33/33 probe fits bit-identical to the plain SPI output. CV selection (|cvsel): 6/6 independent re-scorings select "
        "the same alpha_; sklearn's 10-iteration fold fits change mean scores by <= 2.84e-4 without changing the choice. "
        "P=2 closed form at alpha_ (|cf): 16/19 pass (<= 2.25e-12); fails logistic_maps_bidir T1024 pipeline 7.06e-3 (W12 "
        "equals the 0.95*S12 start to 1.5e-7), var2_bivariate T64 pipeline 3.59e-3, T256 pipeline 4.95e-4 (non-converged, "
        "100 sweeps). ADMM (|admm): 14/17; the 3 fails (delayed_noise, iid_gaussian, nonlinear_dependence T1024 kernel) "
        "differ by 2.7e-6 to 6.9e-5 abs, solver-tolerance level, but exceed 1e-3*max|ref| because alpha_ is near alpha_max "
        "and the entries are small. R glasso (|rglasso): 8/8, max abs 5.64e-5. KKT on W (|kkt): 32/37; fails "
        "logistic_maps_bidir 7.06e-3, logistic_maps 6.35e-3, trending T4096 4.61e-4, shared_envelope T256/T1024 "
        "FloatingPointError; 17 of 35 final refits non-converged with 0 warnings reaching the caller. max|inv(W) - Theta| "
        "5.9e-6 to 2.62e-4 (sparse_precision/bivariate_gaussian), 1.7e-13 (gauss_ar1_pair T1024), 1.2e-12 and 2.5e-8 for the "
        "non-converged logistic_maps/logistic_maps_bidir T1024 fits, up to 0.509 (narrowband_f0-0.25 T4096). Degenerate "
        "(|degen): 6/6 consistent; alpha_ = alpha_max on iid_gaussian T64/256/4096 and nonlinear_dependence T1024, giving "
        "all-zero off-diagonals with 2 roundoff entries <= 1.4e-17. Statistical (|stat): 3/4 (T1024 max_z 2.29, same sample "
        "effect as GraphicalLasso). Symmetry 0.0 on all 68 plain runs; permutation 3/3 (<= 3.8e-5); range 6/6; -sq exact; "
        "failure modes 7/8 (shared_envelope T1024 also fails with detrending, not predicted); side effects 2/2."),
    verdict="variant",
    score_0_10=6,
    what_changed=(
        "As basic.cov.GraphicalLasso (unpenalised diagonal, divide-by-T S, approximate and silent optimisation) at an alpha "
        "chosen by sklearn's contiguous (unshuffled) 5-fold CV over a 16-point refined grid. alpha_ spans 3e-8 to alpha_max; "
        "at alpha_max the output is a constant all-zero matrix. Final refits can stall (P=2 error 7.06e-3 on "
        "logistic_maps_bidir T1024) or raise FloatingPointError (shared_envelope T256/T1024 with and without detrending, "
        "narrowband_f0-0.1 T64), giving all-NaN output."),
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap (a GraphicalLassoCV fit takes 0.05-0.5 s at P <= 5, T <= 4096; whole family about 3.3 min)",
    symmetry_observed="sym: max|A - A.T| = 0.0 (bit-exact) on all 68 plain runs; diagonal NaN",
    direction_observed=(
        "undirected: A[i, j] = A[j, i] exactly on the directed datasets (var2_bivariate, logistic_maps_chaotic, var2_chain, "
        "delayed_noise); A[i, j] refers to processes i and j in input order (permutation equivariance within 3.8e-5); no "
        "direction content"),
)

# ----------------------------------------------------------------------------------------- prec.GraphicalLassoCV
UNITS["basic.prec.GraphicalLassoCV"] = dict(
    check_method="independent-impl",
    check_reference=CV_REF,
    check_data=DATA_CV,
    agreement_criterion=CRIT + "; pcorr: tolerance 0.05 abs against the documented partial correlation; cvsel/degen/fit "
    "as for basic.cov.GraphicalLassoCV",
    closeness=(
        "Same alpha_ and CV-selection evidence as basic.cov.GraphicalLassoCV (|cvsel 6/6, |fit 33/33 bit-identical, alpha_ "
        "3.05e-8 to 0.2069). P=2 closed form (|cf): 15/19 pass (<= 3.34e-13); fails logistic_maps_bidir T1024 pipeline "
        "2.28e-2 (stall at the starting point), var2_bivariate T64 pipeline 4.42e-3, T256 pipeline 5.91e-4, T256 kernel "
        "6.2e-7. ADMM (|admm): 14/17, max abs 2.54e-4 on passing runs; fails 1.1e-5 to 6.3e-5 abs against criteria of "
        "2.8e-6 to 3.9e-5 (alpha_ near alpha_max). R glasso (|rglasso): 8/8, max abs 2.53e-4. KKT on Theta (|kkt): 16/37; "
        "bivariate_gaussian T4096 2.53e-4 with sklearn dual gap 1.0e-5; narrowband up to 0.232, shared_envelope T4096 0.103; "
        "max|Theta - Theta_ADMM| up to 0.336 (narrowband_f0-0.4 T1024, max|Theta_ij| 74.9); 17 non-converged final refits "
        "silent. Statistical (|stat): 4/4 pass, max_z 0.81-1.54, nearest-neighbour entries negative at all T. Documented "
        "partial correlation (|pcorr): 0/4 within 0.05; sign opposite on 83-100% of nonzero entries; max abs difference 3.16 "
        "(bivariate_gaussian T256). Degenerate 6/6 consistent (all-zero at alpha_ = alpha_max with roundoff <= 1.4e-17). "
        "Symmetry 0.0 on all 66 plain runs; permutation 3/3 (<= 4.5e-5); -sq exact; failure modes 7/8 as for the cov unit."),
    verdict="variant",
    score_0_10=6,
    what_changed=(
        "Raw graphical-lasso precision entry (not the documented partial correlation: opposite sign, unbounded, |Theta_ij| "
        "up to 75 on narrowband) at sklearn's CV-selected alpha_; the precision iterate is not inv(W) and misses the "
        "optimum by up to 0.34 on ill-conditioned data without a warning; constant all-zero output when alpha_ = alpha_max; "
        "all-NaN output when the final refit raises FloatingPointError."),
    new_finding=True,
    definition_under_review=True,
    check_cost="cheap (a GraphicalLassoCV fit takes 0.05-0.5 s at P <= 5, T <= 4096; whole family about 3.3 min)",
    symmetry_observed="sym: max|A - A.T| = 0.0 (bit-exact) on all 66 plain runs; diagonal NaN",
    direction_observed=(
        "undirected: A[i, j] = A[j, i] exactly on the directed datasets (var2_bivariate, logistic_maps_chaotic, var2_chain, "
        "delayed_noise); A[i, j] refers to processes i and j in input order (permutation equivariance within 4.5e-5); a "
        "positive dependence gives a negative entry"),
)

# ----------------------------------------------------------------------------------------- candidate resolutions
GL_RES = [
    dict(candidate="silent non-convergence (ConvergenceWarning suppressed at basic.py:37-38)", outcome="confirmed",
         evidence=("kkt runs: 13 of 36 GraphicalLasso fits end with |dual gap| >= 1e-4 after up to 100 sweeps (cointegrated "
                   "T256/1024/4096, narrowband_f0-0.1 T4096, narrowband_f0-0.25 T256, narrowband_f0-0.4 T1024, "
                   "shared_envelope T64-4096, trending T256/1024, var2_bivariate T4096); ref_warnings_seen = 0 through the HEAD "
                   "Calculator hook pyspi.calculation._capture_metric_warnings while ref_convergence_warnings_direct >= 1 for a "
                   "direct sklearn fit of the same array; deviation from the ADMM optimum: W <= 1.33e-4 (8.65e-4 in the "
                   "stall), Theta up to 0.267 (shared_envelope T256)")),
    dict(candidate="solver stall on var2_bivariate T4096 (P=2) at the 0.95*S starting point", outcome="confirmed",
         evidence=("basic.*.GraphicalLasso|var2_bivariate|4096|pipeline|cf and |rglasso and |kkt: pyspi W12 = 0.20643823 equals "
                   "0.95*S12 to 9.6e-12; closed form and R glasso give 0.20730340 (cov error 8.652e-4, prec error 9.852e-4); "
                   "n_iter 100, dual gap -3.73e-4. The kernel-path run on the raw data (var2_bivariate|4096|kernel|cf) "
                   "converges (0.0). The inner-CD mechanism (_cd_fast.pyx:1173-1182) and the sklearn 0.24.1 behaviour were not "
                   "re-run here (trace-stage probe only). Further P=2 early stops: var2_bivariate T1024 pipeline 1.33e-5, "
                   "logistic_maps_chaotic T1024 pipeline 5.7e-5")),
    dict(candidate="covariance_ and precision_ are not exact inverses of each other", outcome="confirmed",
         evidence=("kkt runs ref_inv_err: max|inv(W) - Theta| 9.5e-6 to 2.44e-4 on sparse_precision/bivariate_gaussian "
                   "(all T, kernel and pipeline), 1.6e-13 / 1.9e-13 / 2.2e-16 on gauss_ar1_pair / logistic_maps / "
                   "logistic_maps_bidir T1024, 0.408 on shared_envelope T1024; W satisfies KKT (W-based residual <= 1.3e-4 "
                   "except the stall) while Theta does not (Theta-based residual up to 0.212)")),
    dict(candidate="multivariate() writes NaN into the cached estimator's diagonal (value-neutral for these SPIs)",
         outcome="confirmed",
         evidence=("basic.*.GraphicalLasso|sparse_precision|256|pipeline|side: diag_mutated 1, returned_is_cached 1, "
                   "value_neutral 1 (cov, cov-sq, prec, prec-sq outputs bit-identical whether the covariance or the precision "
                   "identifiers run first)")),
    dict(candidate="FloatingPointError -> all-NaN SPI and four refits per failing estimator", outcome="confirmed",
         evidence=("basic.*.GraphicalLasso|trending|4096|pipeline|fail (FloatingPointError, all-NaN) and |pipeline-detrend|fail "
                   "(finite); basic.*.GraphicalLasso|trending|4096|pipeline|side: n_fits 4, n_allnan 4")),
    dict(candidate="scale: ddof=1 z-scoring then divide-by-T covariance gives S_ii = (T-1)/T", outcome="confirmed",
         evidence=("kkt runs (pipeline): ref_W_diag_minus_Tm1_over_T <= 8.9e-16 and ref_W_diag_minus_S_diag <= 4.4e-16; "
                   "|range runs: max|W_ij| stays below (T-1)/T")),
]
CV_RES = [
    dict(candidate="silent non-convergence (ConvergenceWarning suppressed at basic.py:37-38)", outcome="confirmed",
         evidence=("kkt runs: 17 of 35 final GraphicalLassoCV refits end with |dual gap| >= 1e-4 (narrowband all 9, "
                   "shared_envelope T64/4096, cointegrated T1024, trending T256/1024/4096, logistic_maps and logistic_maps_bidir "
                   "T1024); ref_warnings_seen = 0 for all, ref_convergence_warnings_direct >= 1 for all; deviation from the ADMM "
                   "optimum at alpha_: W up to 7.06e-3 (logistic_maps_bidir), Theta up to 0.336 (narrowband_f0-0.4 T1024)")),
    dict(candidate="covariance_ and precision_ are not exact inverses of each other", outcome="confirmed",
         evidence=("kkt runs ref_inv_err: 5.9e-6 to 2.62e-4 on sparse_precision/bivariate_gaussian, 1.7e-13 on gauss_ar1_pair "
                   "T1024, 1.2e-12 and 2.5e-8 on the non-converged logistic_maps / logistic_maps_bidir T1024 fits, up to 0.509 "
                   "on narrowband_f0-0.25 T4096")),
    dict(candidate="multivariate() writes NaN into the cached estimator's diagonal (value-neutral for these SPIs)",
         outcome="confirmed",
         evidence=("basic.*.GraphicalLassoCV|sparse_precision|256|pipeline|side: diag_mutated 1, returned_is_cached 1, "
                   "value_neutral 1")),
    dict(candidate="FloatingPointError in the final refit -> all-NaN SPI, four refits, detrending does not fix shared_envelope T256",
         outcome="confirmed",
         evidence=("|fail runs: shared_envelope T256 (pipeline and pipeline-detrend), shared_envelope T1024 (pipeline, and "
                   "also pipeline-detrend, which the trace did not predict), narrowband_f0-0.1 T64 pipeline raise "
                   "FloatingPointError (all-NaN); narrowband_f0-0.1 T64 detrended and trending T4096 succeed; "
                   "|shared_envelope|256|pipeline|side: n_fits 4, n_allnan 4")),
    dict(candidate="scale: ddof=1 z-scoring then divide-by-T covariance gives S_ii = (T-1)/T", outcome="confirmed",
         evidence="kkt runs (pipeline): ref_W_diag_minus_Tm1_over_T <= 8.9e-16, ref_W_diag_minus_S_diag <= 4.4e-16"),
    dict(candidate="alpha_ spans many orders of magnitude; alpha_ >= alpha_max gives a constant all-zero matrix with roundoff entries",
         outcome="confirmed",
         evidence=("|fit and |kkt runs: alpha_ from 3.05e-8 (var2_bivariate T1024 pipeline) to 0.2069 (iid_gaussian T64); "
                   "|degen runs: alpha_ = alpha_max on iid_gaussian T64/256/4096 and nonlinear_dependence T1024, all off-diagonal "
                   "entries 0 except 2 roundoff values of 1.4e-17 (T256), 3.5e-18 (T4096), 6.9e-18 (nonlinear_dependence)")),
    dict(candidate="CV protocol: unshuffled contiguous KFold(5), 10-iteration fold fits, test fold centred on its own mean, alpha=0 not selectable",
         outcome="confirmed",
         evidence=("|cvsel runs: an independent numpy re-scoring with exactly these conventions (contiguous folds, exact ADMM "
                   "fold fits, own-mean test centring, ties to the smaller alpha, alpha=0 excluded) selects sklearn's alpha_ on "
                   "6/6 datasets; sklearn's 10-iteration fold scores differ from the exact-fit scores by <= 2.84e-4")),
    dict(candidate="CV alpha_ close to the fixed 0.01 on Gaussian data; strongly different on rank-deficient data",
         outcome="confirmed",
         evidence=("|kkt runs: sparse_precision alpha_ 0.0097 / 0.0239 / 0.0085 / 0.0049 (T64/256/1024/4096), "
                   "bivariate_gaussian 0.0566 / 0.0129 / 0.0099 / 0.0055; GraphicalLasso vs GraphicalLassoCV on "
                   "sparse_precision T1024 pipeline (|sym runs) differ by at most 1.5e-3 (cov) and 6.6e-3 (prec); on narrowband "
                   "alpha_ 1.1e-5 to 4.6e-4 and max|Theta_ij| 59-75 against 14.4-14.7 for GraphicalLasso")),
]


def checks_run(uid, cv, kind):
    p = uid + "|"
    rows = [
        dict(run_ids=[p + "*|cf"], reference=f"{REF}:ref_cf",
             outcome={("cov", False): "16/19 pass; converged <= 2.25e-12, fails up to 8.652e-4 (var2_bivariate T4096 stall)",
                      ("prec", False): "16/19 pass; converged <= 3.32e-13, fails up to 9.852e-4 (stall)",
                      ("cov", True): "16/19 pass; fails up to 7.06e-3 (logistic_maps_bidir T1024 stall)",
                      ("prec", True): "15/19 pass; fails up to 2.28e-2 (logistic_maps_bidir T1024 stall)"}[(kind, cv)]),
        dict(run_ids=[p + "*|admm"], reference=f"{REF}:admm_glasso",
             outcome={("cov", False): "17/17 pass, max abs 5.64e-5", ("prec", False): "17/17 pass, max abs 2.36e-4",
                      ("cov", True): "14/17 pass; fails 2.7e-6 to 6.9e-5 abs at alpha_ near alpha_max",
                      ("prec", True): "14/17 pass; fails 1.1e-5 to 6.3e-5 abs at alpha_ near alpha_max"}[(kind, cv)]),
        dict(run_ids=[p + "*|rglasso"], reference=f"{RSCRIPT} via {REF}:ref_rglasso (R glasso==1.11)",
             outcome={("cov", False): "10/11 pass, max abs 7.86e-5; fail var2_bivariate T4096 8.65e-4",
                      ("prec", False): "8/11 pass, max abs 2.35e-4; fails shared_envelope T1024 0.149, narrowband_f0-0.25 T256 0.101, var2_bivariate T4096 9.85e-4",
                      ("cov", True): "8/8 pass, max abs 5.64e-5", ("prec", True): "8/8 pass, max abs 2.53e-4"}[(kind, cv)]),
        dict(run_ids=[p + "*|kkt"], reference=f"{REF}:ref_kkt + _kernels_basic_misc.glasso_kkt_residual",
             outcome={("cov", False): "34/37 <= 1e-4 (W-based); fails 1.33e-4, 8.65e-4, one FloatingPointError",
                      ("prec", False): "16/37 <= 1e-4 (Theta-based); up to 0.212",
                      ("cov", True): "32/37 <= 1e-4; fails up to 7.06e-3 and two FloatingPointError",
                      ("prec", True): "16/37 <= 1e-4; up to 0.232"}[(kind, cv)]),
        dict(run_ids=[p + "*|sym", p + "*|perm"], reference=f"{REF}:ref_sym, ref_perm (probe perm)",
             outcome="sym 5/5 (max|A - A.T| = 0.0), perm 3/3 (<= 4.5e-5)"),
        dict(run_ids=[p + "*|stat"], reference=f"{REF}:ref_stat",
             outcome=("4/4 pass, max_z <= 1.55" if kind == "prec" else
                      "3/4 pass; T1024 max_z 2.29 (sample covariance itself 3.20 sd off cov_true)")),
        dict(run_ids=[p + "*|fail", p + "*|side"], reference=f"{REF}:ref_fail, ref_side (probes calc_style, side_effects)",
             outcome=("fail 7/8 (shared_envelope T1024 pipeline-detrend also raises), side 2/2" if cv else
                      "fail 6/6, side 2/2")),
        dict(run_ids=[p + "gauss_ar1_pair|1024|pipeline|cf-sq", p + "sparse_precision|1024|pipeline|sym-sq"],
             reference=f"{REF}:ref_sq", outcome="2/2 exact (max abs 0.0)"),
    ]
    if kind == "cov":
        rows.append(dict(run_ids=[p + "*|range"], reference=f"{REF}:ref_range", outcome="6/6 pass"))
    else:
        rows.append(dict(run_ids=[p + "*|pcorr"], reference=f"{REF}:ref_pcorr",
                         outcome="0/4 within 0.05 of the documented partial correlation; sign opposite, max abs diff 3.2"))
    if cv:
        rows.append(dict(run_ids=[p + "*|cvsel", p + "*|degen"] + (["basic.cov.GraphicalLassoCV|*|fit"]),
                         reference=f"{REF}:ref_cvsel, ref_degen, ref_fit (probe full_fit)",
                         outcome="cvsel 6/6 same alpha_, degen 6/6 consistent, fit 33/33 bit-identical"))
    return rows


import json
_M = json.load(open("/media/dan/Data/git/pyspi/audit/checks/manifest/cov_prec_glasso.json"))["runs"]


def _expand(pattern):
    """'<uid>|*|<tag>' -> exact run_ids of that unit and tag in the manifest; exact ids pass through."""
    if "|*|" not in pattern:
        return [pattern]
    head, tag = pattern.split("|*|")
    return [r["run_id"] for r in _M if r["run_id"].startswith(head + "|") and r["run_id"].split("|")[-1] == tag]


for uid, fields in UNITS.items():
    path = REC.format(uid)
    rec = yaml.safe_load(open(path))
    c = rec["correctness"]
    cv = uid.endswith("CV")
    kind = "prec" if ".prec." in uid else "cov"
    c.update(fields)
    res = CV_RES if cv else GL_RES
    assert len(res) == len(c["new_finding_candidates"]), (uid, len(res), len(c["new_finding_candidates"]))
    c["candidate_resolutions"] = res
    cr = checks_run(uid, cv, kind)
    for row in cr:
        ids = [i for pat in row["run_ids"] for i in _expand(pat)]
        assert ids and all(any(r["run_id"] == i for r in _M) for i in ids), row
        row["run_ids"] = ids
    c["checks_run"] = cr
    rec["status"] = "checked"
    with open(path, "w") as f:
        yaml.safe_dump(rec, f, sort_keys=False, allow_unicode=True, width=200, default_flow_style=False)
    print("wrote", uid)
