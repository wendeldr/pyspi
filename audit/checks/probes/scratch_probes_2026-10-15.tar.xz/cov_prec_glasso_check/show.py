import json,sys
r=json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/results/cov_prec_glasso.json'))
tag=sys.argv[1]; only_fail=len(sys.argv)>2 and sys.argv[2]=='f'
keys=sys.argv[3].split(',') if len(sys.argv)>3 else ['max_abs','max_rel','atol','max_z','notes']
for k,v in sorted(r.items()):
    if k.split('|')[-1]!=tag: continue
    if only_fail and v.get('pass'): continue
    print(('PASS ' if v.get('pass') else 'FAIL ')+'|'.join(k.split('|')[:-1]).replace('basic.',''), {kk:(v.get(kk) if not isinstance(v.get(kk),float) else float('%.4g'%v.get(kk))) for kk in keys if kk in v or 'ref_'+kk in v} , {kk:v.get('ref_'+kk) for kk in keys if 'ref_'+kk in v})
