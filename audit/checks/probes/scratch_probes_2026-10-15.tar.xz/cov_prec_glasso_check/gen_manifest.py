"""Generate audit/checks/manifest/cov_prec_glasso.json (throwaway generator; the JSON is the artefact)."""
import json

FAM = "cov_prec_glasso"
PROBE = "probes/cov_prec_glasso_fit.py"
UNITS = {("cov", "GraphicalLasso"): "basic.cov.GraphicalLasso",
         ("cov", "GraphicalLassoCV"): "basic.cov.GraphicalLassoCV",
         ("prec", "GraphicalLasso"): "basic.prec.GraphicalLasso",
         ("prec", "GraphicalLassoCV"): "basic.prec.GraphicalLassoCV"}
runs = []
seen = set()


def add(kind, est, ds, T, path, tag, probe=None, sq=False):
    uid = UNITS[(kind, est)]
    ident = f"{kind}{'-sq' if sq else ''}_{est}"
    rid = f"{uid}|{ds}|{T}|{path}|{tag}" + ("-sq" if sq else "")
    assert rid not in seen, rid
    seen.add(rid)
    runs.append(dict(run_id=rid, unit_id=uid, identifier=ident, dataset=ds, T=T, path=path,
                     processes=None, seed=42,
                     probe=None if probe is None else {"module": PROBE, "function": probe}))


CF = [("var2_bivariate", t, "kernel") for t in (64, 256, 1024, 4096)] + \
     [("gauss_ar1_pair", t, "kernel") for t in (256, 1024, 4096)] + \
     [("logistic_maps", 1024, "kernel"), ("logistic_maps_bidir", 1024, "kernel")] + \
     [("contaminated", t, "kernel") for t in (256, 1024)] + \
     [("var2_bivariate", t, "pipeline") for t in (64, 256, 1024, 4096)] + \
     [("gauss_ar1_pair", t, "pipeline") for t in (1024, 4096)] + \
     [("logistic_maps_bidir", 1024, "pipeline"), ("logistic_maps_chaotic", 1024, "pipeline")]
ADMM = [(d, 1024, "kernel") for d in ("sparse_precision", "bivariate_gaussian", "iid_gaussian", "delayed_noise",
                                      "nonlinear_dependence", "var2_chain", "scaled_offset")] + \
       [(d, t, "kernel") for d in ("sparse_precision", "bivariate_gaussian") for t in (64, 256, 4096)] + \
       [(d, 1024, "pipeline") for d in ("sparse_precision", "bivariate_gaussian", "scaled_offset", "var2_chain")]
RGL = [(d, t, "pipeline") for d in ("sparse_precision", "bivariate_gaussian") for t in (256, 1024, 4096)] + \
      [(d, 1024, "kernel") for d in ("sparse_precision", "bivariate_gaussian")]
RGL_GL_ONLY = [("shared_envelope", 1024, "pipeline"), ("narrowband_f0-0.25", 256, "pipeline"),
               ("var2_bivariate", 4096, "pipeline")]
KKT = [(d, t, "pipeline") for d in ("sparse_precision", "bivariate_gaussian") for t in (64, 256, 1024, 4096)] + \
      [(d, 1024, "kernel") for d in ("sparse_precision", "bivariate_gaussian")] + \
      [(d, t, "pipeline") for d in ("narrowband_f0-0.1", "narrowband_f0-0.25", "narrowband_f0-0.4")
       for t in (256, 1024, 4096)] + \
      [("shared_envelope", t, "pipeline") for t in (64, 256, 1024, 4096)] + \
      [(d, t, "pipeline") for d in ("cointegrated", "trending") for t in (256, 1024, 4096)] + \
      [("var2_bivariate", t, "pipeline") for t in (1024, 4096)] + \
      [(d, 1024, "pipeline") for d in ("gauss_ar1_pair", "logistic_maps", "logistic_maps_bidir", "delayed_noise")] + \
      [("iid_gaussian", t, "pipeline") for t in (64, 1024)]
SYM = [(d, 1024, "pipeline") for d in ("sparse_precision", "iid_gaussian", "bivariate_gaussian", "delayed_noise", "var2_chain")]
PERM = [(d, 1024, "pipeline") for d in ("sparse_precision", "iid_gaussian", "bivariate_gaussian")]
FAIL = {"GraphicalLasso": [("trending", 4096), ("shared_envelope", 1024), ("narrowband_f0-0.1", 64)],
        "GraphicalLassoCV": [("shared_envelope", 256), ("shared_envelope", 1024), ("narrowband_f0-0.1", 64),
                             ("trending", 4096)]}
RANGE = [(d, t, "pipeline") for d in ("bivariate_gaussian", "contaminated", "delayed_noise") for t in (64, 1024)]
PCORR = [("bivariate_gaussian", 256, "pipeline"), ("bivariate_gaussian", 1024, "pipeline"),
         ("sparse_precision", 1024, "pipeline"), ("delayed_noise", 1024, "pipeline")]
STAT = [("sparse_precision", t, "kernel") for t in (64, 256, 1024, 4096)]
SQ = [("gauss_ar1_pair", 1024, "pipeline", "cf"), ("sparse_precision", 1024, "pipeline", "sym")]
SIDE = {"GraphicalLasso": [("sparse_precision", 256), ("trending", 4096)],
        "GraphicalLassoCV": [("sparse_precision", 256), ("shared_envelope", 256)]}
DEGEN = [("iid_gaussian", t, "pipeline") for t in (64, 256, 1024, 4096)] + \
        [(d, 1024, "pipeline") for d in ("nonlinear_dependence", "var2_chain")]
CVSEL = [("sparse_precision", 256, "pipeline")] + \
        [(d, 1024, "pipeline") for d in ("sparse_precision", "bivariate_gaussian", "iid_gaussian", "delayed_noise", "var2_chain")]

for est in ("GraphicalLasso", "GraphicalLassoCV"):
    for kind in ("cov", "prec"):
        for ds, T, path in CF:
            add(kind, est, ds, T, path, "cf")
        for ds, T, path in ADMM:
            add(kind, est, ds, T, path, "admm")
        for ds, T, path in RGL + (RGL_GL_ONLY if est == "GraphicalLasso" else []):
            add(kind, est, ds, T, path, "rglasso")
        for ds, T, path in KKT:
            add(kind, est, ds, T, path, "kkt", probe="full_fit")
        for ds, T, path in SYM:
            add(kind, est, ds, T, path, "sym")
        for ds, T, path in PERM:
            add(kind, est, ds, T, path, "perm", probe="perm")
        for ds, T in FAIL[est]:
            for path in ("pipeline", "pipeline-detrend"):
                add(kind, est, ds, T, path, "fail", probe="calc_style")
        if kind == "cov":
            for ds, T, path in RANGE:
                add(kind, est, ds, T, path, "range")
        else:
            for ds, T, path in PCORR:
                add(kind, est, ds, T, path, "pcorr")
        for ds, T, path in STAT:
            add(kind, est, ds, T, path, "stat")
        for ds, T, path, base in SQ:
            add(kind, est, ds, T, path, base, sq=True)
        for ds, T in SIDE[est]:
            add(kind, est, ds, T, "pipeline", "side", probe="side_effects")
        if est == "GraphicalLassoCV":
            for ds, T, path in DEGEN:
                add(kind, est, ds, T, path, "degen")
            for ds, T, path in CVSEL:
                add(kind, est, ds, T, path, "cvsel", probe="full_fit")

# every GraphicalLassoCV plain run needs a full_fit probe at the same (dataset, T, path) for alpha_
have_fit = {(r["dataset"], r["T"], r["path"]) for r in runs
            if r["identifier"].endswith("GraphicalLassoCV") and r["probe"] and r["probe"]["function"] == "full_fit"}
need = sorted({(r["dataset"], r["T"], r["path"]) for r in runs
               if r["identifier"].endswith("GraphicalLassoCV") and r["probe"] is None} - have_fit)
for ds, T, path in need:
    add("cov", "GraphicalLassoCV", ds, T, path, "fit", probe="full_fit")

out = "/media/dan/Data/git/pyspi/audit/checks/manifest/cov_prec_glasso.json"
with open(out, "w") as f:
    json.dump({"family": FAM, "runs": runs}, f, indent=1)
    f.write("\n")
print(len(runs), "runs;", len(need), "extra CV fit probes")
