import sys, time
sys.path.insert(0,'/media/dan/Data/git/pyspi/tests'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import numpy as np, importlib.util, make_data
from regression import harness
spec=importlib.util.spec_from_file_location('p','/media/dan/Data/git/pyspi/audit/checks/probes/cov_prec_glasso_fit.py'); p=importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
for ds,T,path,ident in [('sparse_precision',1024,'pipeline','prec_GraphicalLasso'),('var2_bivariate',4096,'pipeline','prec_GraphicalLasso'),('shared_envelope',256,'pipeline','prec_GraphicalLassoCV'),('sparse_precision',1024,'pipeline','prec_GraphicalLassoCV'),('trending',4096,'pipeline','cov_GraphicalLasso')]:
    x=make_data.load(ds,T)['x']; run=dict(identifier=ident,path=path)
    t=time.time(); v=p.full_fit(x,run); print(ds,T,ident,'hdr',v[:8], round(time.time()-t,2))
    print(' calc', p.calc_style(x,run)[:2], ' side', p.side_effects(x,run))
    if v[1]==0: print(' perm', np.nanmax(np.abs(p.perm(x,run)-harness.compute_spi(p._spi(*p._parse(ident)), p._data(x,path)))))
