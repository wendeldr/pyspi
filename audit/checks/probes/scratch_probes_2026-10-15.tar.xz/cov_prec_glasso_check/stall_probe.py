"""Fable project-venv probe: the P=2 stall, the warning suppression and EE==MCD (pyspi-side evidence)."""
import sys, warnings
import numpy as np
from scipy import stats
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
from regression import harness  # noqa
import make_data
import sklearn
from sklearn.covariance import GraphicalLasso, MinCovDet, EllipticEnvelope, EmpiricalCovariance
from pyspi.data import Data
from pyspi.statistics.basic import Covariance, Precision
from pyspi.calculation import _capture_metric_warnings

print('sklearn', sklearn.__version__)
x = np.asarray(make_data.load('var2_bivariate', 4096)['x'], float)
z = stats.zscore(x, axis=1, ddof=1).T
S = np.cov(z.T, bias=1)
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter('always')
    g = GraphicalLasso().fit(z)
soft = np.sign(S[0, 1]) * max(abs(S[0, 1]) - 0.01, 0)
print(f'var2_bivariate T=4096 pipeline: W12 {g.covariance_[0, 1]:.10f}  0.95*S12 {0.95 * S[0, 1]:.10f}  closed form {soft:.10f}  n_iter_ {g.n_iter_}  dual gap {g.costs_[-1][1]:.3e}  warnings {[type(i.message).__name__ for i in w]}')
g2 = GraphicalLasso(enet_tol=1e-8).fit(z)
print(f'  enet_tol=1e-8: W12 {g2.covariance_[0, 1]:.10f} n_iter_ {g2.n_iter_}')
g3 = GraphicalLasso(mode='lars').fit(z)
print(f'  mode=lars:     W12 {g3.covariance_[0, 1]:.10f} n_iter_ {g3.n_iter_}')
# raw (kernel) path
S0 = np.cov(x, bias=1); g0 = GraphicalLasso().fit(x.T)
print(f'  kernel path: W12 {g0.covariance_[0, 1]:.10f} closed form {np.sign(S0[0, 1]) * max(abs(S0[0, 1]) - 0.01, 0):.10f} n_iter_ {g0.n_iter_}')

# warning capture through pyspi on a non-converging input
x = np.asarray(make_data.load('shared_envelope', 256)['x'], float)
d = Data(x, dim_order='ps')
with _capture_metric_warnings() as emitted:
    out = Precision(estimator='GraphicalLasso').multivariate(d)
print(f'shared_envelope T=256 prec_GraphicalLasso via pyspi: warnings captured by the Calculator hook: {len(emitted)}; n_iter_ {d.covariance["GraphicalLasso"].n_iter_}; dual gap {d.covariance["GraphicalLasso"].costs_[-1][1]:.3e}')
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter('always')
    GraphicalLasso().fit(d.to_numpy(squeeze=True).T)
print(f'  direct sklearn fit of the same array: {[type(i.message).__name__ for i in w]}')

# EE == MCD under the same seed; aliasing of the cached attribute
x = np.asarray(make_data.load('sparse_precision', 256)['x'], float); z = stats.zscore(x, axis=1, ddof=1).T
np.random.seed(0); a = MinCovDet().fit(z); np.random.seed(0); b = EllipticEnvelope().fit(z)
print('EllipticEnvelope == MinCovDet (seed 0): cov', np.array_equal(a.covariance_, b.covariance_), 'prec', np.array_equal(a.precision_, b.precision_))
d = Data(x, dim_order='ps'); harness.seed_all(42); M = Covariance(estimator='EmpiricalCovariance').multivariate(d)
est = d.covariance['EmpiricalCovariance']
print('cov_EmpiricalCovariance returns the cached array:', M is est.covariance_, 'cached diag all NaN:', np.isnan(np.diag(est.covariance_)).all(), 'score() ->', est.score(d.to_numpy(squeeze=True).T))
Q = Precision(estimator='EmpiricalCovariance').multivariate(d)
print('prec returns the cached precision_:', Q is est.precision_, 'score() after prec ->', est.score(d.to_numpy(squeeze=True).T))
