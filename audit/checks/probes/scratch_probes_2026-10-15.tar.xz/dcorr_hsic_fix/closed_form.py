# Independent closed-form population HSIC for standard bivariate normal, Gaussian kernel
# k(a,b)=exp(-(a-b)^2/(2 s^2)), same s for both variables. E[exp(-z'Az/2)] = det(I + A C)^-1/2 for z~N(0,C).
import numpy as np
from scipy.stats import norm
s = np.sqrt(2)*norm.ppf(0.75)
def E(C):
    A = np.eye(2)/s**2
    return np.linalg.det(np.eye(2)+A@np.asarray(C,float))**-0.5
def hsic(r):
    t1 = E([[2,2*r],[2*r,2]])
    t2 = (1+2/s**2)**-1
    t3 = E([[2,r],[r,2]])
    return t1+t2-2*t3
for r in (0.3,0.8):
    v = hsic(r)/hsic(1.0)
    print(r, s, v, np.sqrt(v))
# Monte Carlo cross-check with the Song unbiased estimator at large n via pyspi-free numpy (blocks)
rng = np.random.default_rng(1)
def hsic_u(K,L):
    n=K.shape[0]; K=K.copy(); L=L.copy(); np.fill_diagonal(K,0); np.fill_diagonal(L,0)
    o=np.ones(n)
    return (np.trace(K@L) + (o@K@o)*(o@L@o)/((n-1)*(n-2)) - 2/(n-2)*(o@K@L@o))/(n*(n-3))
for r in (0.3,0.8):
    vals=[]
    for rep in range(20):
        n=1500
        x=rng.standard_normal(n); y=r*x+np.sqrt(1-r*r)*rng.standard_normal(n)
        K=np.exp(-(x[:,None]-x[None])**2/(2*s*s)); L=np.exp(-(y[:,None]-y[None])**2/(2*s*s))
        vals.append(hsic_u(K,L)/np.sqrt(hsic_u(K,K)*hsic_u(L,L)))
    print(r, np.mean(vals), np.std(vals)/np.sqrt(len(vals)))
