# Brute-force Gretton et al. 2007 eq. (3) (three U-statistics) vs Song et al. 2012 eq. (5), small m
import itertools, numpy as np
rng=np.random.default_rng(0); m=9
x=rng.standard_normal(m); y=x**2+0.3*rng.standard_normal(m)
K=np.exp(-(x[:,None]-x[None])**2/2); L=np.exp(-(y[:,None]-y[None])**2/2)
def ff(m,n):
    r=1
    for t in range(n): r*=m-t
    return r
t1=sum(K[i,j]*L[i,j] for i,j in itertools.permutations(range(m),2))/ff(m,2)
t2=sum(K[i,j]*L[q,r] for i,j,q,r in itertools.permutations(range(m),4))/ff(m,4)
t3=sum(K[i,j]*L[i,q] for i,j,q in itertools.permutations(range(m),3))/ff(m,3)
eq3=t1+t2-2*t3
Kt=K.copy();Lt=L.copy();np.fill_diagonal(Kt,0);np.fill_diagonal(Lt,0);o=np.ones(m);n=m
song=(np.trace(Kt@Lt)+(o@Kt@o)*(o@Lt@o)/((n-1)*(n-2))-2/(n-2)*(o@Kt@Lt@o))/(n*(n-3))
print(eq3,song,eq3-song)
