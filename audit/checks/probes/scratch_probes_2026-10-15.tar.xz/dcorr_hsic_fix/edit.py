import yaml
R='/media/dan/Data/git/pyspi/audit/records/'
def load(u): return yaml.safe_load(open(R+u+'.yaml'))
def save(u,d): open(R+u+'.yaml','w').write(yaml.safe_dump(d,sort_keys=False,allow_unicode=True,width=120))
def rep(s,old,new):
    assert old in s,(old[:60])
    return s.replace(old,new)
GLOSS=("GitBook glossary-of-terms.md:21 (keyword table, 'Signed' row): 'Other SPIs, such as distance correlation (defined in "
       "the range [0,1]) are unsigned.'")
MEDIAN=("Gretton et al. 2007 Sec. 4 says only 'We used a Gaussian kernel, with kernel size set to the median distance between "
        "points in input space'; it does not say explicitly whether the median is taken separately for x and y. A separate "
        "median for each variable is the common reading and common practice; it is not stated in [15]")

# ---- hsic unbiased
u='distance.hsic.biased-False'; d=load(u); c=d['correctness']
c['canonical_ref']=("HSIC: Gretton, Bousquet, Smola & Scholkopf 2005, ALT, LNCS 3734:63-77 (HSIC_b = (m-1)^-2 tr(KHLH)); Gretton "
 "et al. 2007, NIPS 20 'A kernel statistical test of independence' (= supplement ref [15]): eq. (2) population HSIC, eq. (3) "
 "unbiased estimator as a sum of three U-statistics, eq. (4) biased HSIC_b = m^-2 tr(KHLH); Sec. 4 Gaussian kernel with "
 "'kernel size set to the median distance between points in input space' (whether per variable is not stated); unbiased "
 "estimator in matrix form: Song, Smola, Gretton, Bedo & Borgwardt 2012, JMLR 13:1393-1434, eq. (5) (numerically identical to "
 "Gretton 2007 eq. (3): brute-force probe at m=9 differs by 1.8e-16); kernel/distance equivalence: Sejdinovic et al. 2013, Ann. "
 "Statist. 41(5):2263-2291; normalisation used here: Shen & Vogelstein 2020 (hyppo docs) / centred kernel alignment (Cortes, "
 "Mohri & Rostamizadeh 2012, JMLR 13:795-828)")
c['canonical_definition']=rep(c['canonical_definition'],
 "sigma^2)) with sigma = median inter-sample distance of that variable (Gretton et al. 2007).",
 "sigma^2)) with sigma = median inter-sample distance (Gretton et al. 2007 Sec. 4; applying it separately to each variable is "
 "the common reading, not stated explicitly there). Song eq. (5) equals the three-U-statistic estimator of Gretton et al. 2007 eq. (3).")
c['documented_definition']=c['documented_definition'].rstrip()+'. '+GLOSS
c['deviation_from_documented']=(
 "(a) The supplement and GitBook describe HSIC as 'an RKHS-based statistic' with biased and unbiased estimators; neither says "
 "that the returned value is NORMALISED (HSIC(x,y)/sqrt(HSIC(x,x) HSIC(y,y)), a correlation-like number), nor that the Gaussian "
 "kernel bandwidth is the median heuristic computed from the first argument only and reused for the second. (b) 'the unbiased "
 "(and consistent) estimator can be derived by double centering the kernel distance matrix [15]': citing [15] for an unbiased "
 "estimator is supported, since Gretton et al. 2007 eq. (3) is an unbiased U-statistic estimator (eq. (4) is the biased one). "
 "The deviation is the 'double centering' wording only: the code's unbiased estimator U-centres 1-K (equal to Gretton 2007 eq. (3) "
 "and Song et al. 2012 eq. (5) before normalisation), and double centring is what the biased variant does. (c) Labelled "
 "'undirected' but the bivariate value depends on argument order (made symmetric only by mirroring). (d) The unbiased value is "
 "on the squared-correlation scale while hsic_biased is square-rooted; the documentation presents them as two estimators of one "
 "quantity. (e) Labelled 'unsigned' (config.yaml keywords; the GitBook glossary, glossary-of-terms.md:21, defines unsigned SPIs "
 "by the example of distance correlation 'defined in the range [0,1]') but can be negative.")
c['deviation_from_canonical']=rep(c['deviation_from_canonical'],
 "the per-variable median of Gretton et al. 2007 would give 0.7720 instead",
 "a separate median for each variable (the common reading of Gretton et al. 2007 Sec. 4, which does not state it explicitly) would give 0.7720 instead")
c['deviation_from_canonical']=rep(c['deviation_from_canonical'],
 "The unbiased centring itself matches Song et al. 2012 eq. (5) exactly.",
 "The unbiased centring itself matches Song et al. 2012 eq. (5), equivalently Gretton et al. 2007 eq. (3), exactly.")
nf=c['new_finding_candidates']
i=[k for k,s in enumerate(nf) if s.startswith('Candidate (sign label)')][0]
nf[i]=rep(nf[i],"labelled ''unsigned''".replace("''","'"),"labelled 'unsigned' (config.yaml; GitBook glossary-of-terms.md:21 describes unsigned SPIs with distance correlation 'defined in the range [0,1]')")
i=[k for k,s in enumerate(nf) if s.startswith('Candidate (order dependence)')][0]
nf[i]=nf[i].rstrip()+(" Framed as a deviation from the usual per-variable median practice; Gretton et al. 2007 Sec. 4 does not "
 "state per-variable medians explicitly.")
for pc in c['proposed_checks']:
    if 'per-variable medians (Gretton 2007)' in pc['expected_outcome']:
        pc['expected_outcome']=rep(pc['expected_outcome'],'per-variable medians (Gretton 2007)','per-variable medians (common practice; not stated explicitly in Gretton 2007)')
    if pc['reference'].startswith('analytic population normalised HSIC'):
        pc['reference']=("population normalised HSIC for a standard bivariate normal with a common Gaussian kernel sigma = "
         "sqrt(2)*Phi^-1(0.75) = 0.9539 (population median of |X-X'|): HSIC(rho) = det(I + 2C_rho/sigma^2)^-1/2 + (1 + 2/sigma^2)^-1 "
         "- 2 det(I + C'_rho/sigma^2)^-1/2 with C_rho = [[1,rho],[rho,1]], C'_rho = [[2,rho],[rho,2]] (from E[exp(-z'Az/2)] = "
         "det(I + A Sigma)^-1/2), normalised value HSIC(rho)/HSIC(1). AUDIT DERIVATION, NOT FROM THE LITERATURE AND NOT YET "
         "VERIFIED: rho=0.3 -> 0.04553, rho=0.8 -> 0.47393 (closed_form.py in this audit's scratchpad reproduces the earlier "
         "popref.py values; Monte Carlo with the Song eq. (5) estimator at n=1500, 20 reps, fixed sigma: 0.0418 +- 0.0017 and "
         "0.4742 +- 0.0026). The check stage must re-derive these constants independently before using them as a reference")
        pc['expected_outcome']=("provisional, pending re-derivation of the constants: pair (0,1) -> about 0.046 and pair (2,3) -> "
         "about 0.47 (squared scale), converging with T; independent cross pairs centred on 0; the sample bandwidth fluctuates "
         "around 0.9539, which adds variability at small T")
save(u,d)

# ---- hsic biased
u='distance.hsic.biased-True'; d=load(u); c=d['correctness']
c['canonical_ref']=rep(c['canonical_ref'],
 "Gretton et al. 2007, NIPS 20 (HSIC_b = (1/m^2) tr(KHLH), Gaussian kernel with per-variable median-distance bandwidth)",
 "Gretton et al. 2007, NIPS 20 (= supplement ref [15]; eq. (3) unbiased U-statistic estimator, eq. (4) biased HSIC_b = (1/m^2) "
 "tr(KHLH); Sec. 4 Gaussian kernel with 'kernel size set to the median distance between points in input space', whether per "
 "variable is not stated)")
c['canonical_definition']=rep(c['canonical_definition'],
 "sigma = median inter-sample distance of each variable (Gretton et al. 2007)",
 "sigma = median inter-sample distance (Gretton et al. 2007 Sec. 4; a separate median for each variable is the common reading, "
 "not stated explicitly there)")
c['deviation_from_documented']=rep(c['deviation_from_documented'],
 "[15]': [15] (Gretton et al. 2007) defines the biased V-statistic; the unbiased estimator in the code is the U-centring of 1-K "
 "(equivalent to Song et al. 2012), and double centring is the biased variant.",
 "[15]': citing [15] for both estimators is supported (Gretton et al. 2007 eq. (3) is the unbiased U-statistic estimator, eq. "
 "(4) the biased HSIC_b). The deviation is the 'double centering' wording: double centring of 1-K is what this biased variant "
 "computes, while the unbiased variant U-centres (equal to Gretton 2007 eq. (3) / Song et al. 2012 eq. (5)).")
c['deviation_from_canonical']=rep(c['deviation_from_canonical'],
 "(per-variable median would give 0.8805",
 "(a separate median per variable, the common reading of Gretton et al. 2007 Sec. 4, would give 0.8805")
nf=c['new_finding_candidates']
i=[k for k,s in enumerate(nf) if s.startswith('Candidate (order dependence)')][0]
nf[i]=nf[i].rstrip()+(" Framed as a deviation from the usual per-variable median practice; Gretton et al. 2007 Sec. 4 does not "
 "state per-variable medians explicitly.")
for pc in c['proposed_checks']:
    if 'per-variable-median variant' in pc['expected_outcome']:
        pc['expected_outcome']=rep(pc['expected_outcome'],'per-variable-median variant','per-variable-median variant (common practice, not stated explicitly in Gretton 2007)')
    if pc['reference'].startswith('analytic population normalised HSIC'):
        pc['reference']=("square root of the population normalised HSIC for a standard bivariate normal (closed form as in "
         "distance.hsic.biased-False: common sigma = 0.9539, HSIC(rho)/HSIC(1) from det(I + A Sigma)^-1/2 Gaussian integrals). "
         "AUDIT DERIVATION, NOT FROM THE LITERATURE AND NOT YET VERIFIED: rho=0.3 -> sqrt(0.04553) = 0.2134, rho=0.8 -> "
         "sqrt(0.47393) = 0.6884. The check stage must re-derive these constants independently before using them as a reference")
        pc['expected_outcome']=("provisional, pending re-derivation of the constants: pair (0,1) -> about 0.21 and (2,3) -> about "
         "0.69, approached from above (positive V-statistic bias) as T grows")
save(u,d)

# ---- dcorr unbiased
u='distance.dcorr.biased-False'; d=load(u); c=d['correctness']
c['canonical_ref']=c['canonical_ref'].rstrip()+(", Theorem 7(ii) (bivariate-normal closed form; arXiv 0803.4101 text, p.18, "
 "checked against the paper)")
c['documented_definition']=c['documented_definition'].rstrip()+'. '+GLOSS
c['deviation_from_documented']=rep(c['deviation_from_documented'],
 "(5) Labelled 'unsigned' but returns negative values.",
 "(5) Labelled 'unsigned' (config.yaml keywords; GitBook glossary-of-terms.md:21 gives distance correlation 'defined in the "
 "range [0,1]' as the example of an unsigned SPI) but returns negative values.")
nf=c['new_finding_candidates']
i=[k for k,s in enumerate(nf) if s.startswith('Candidate (sign label)')][0]
nf[i]=rep(nf[i],"labelled 'unsigned' yet","labelled 'unsigned' (config.yaml; GitBook glossary-of-terms.md:21: 'distance correlation (defined in the range [0,1]) are unsigned') yet")
for pc in c['proposed_checks']:
    if 'Thm 7' in pc['reference']:
        pc['reference']=rep(pc['reference'],'Szekely, Rizzo & Bakirov 2007 Thm 7 bivariate-normal closed form:',
          'Szekely, Rizzo & Bakirov 2007 Theorem 7(ii) bivariate-normal closed form (confirmed against the paper text, arXiv 0803.4101 p.18):')
save(u,d)
