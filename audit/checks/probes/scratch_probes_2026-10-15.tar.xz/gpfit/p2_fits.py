import sys, warnings, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi.data import Data
from pyspi.statistics.misc import GPModel
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.base import clone
D = '/media/dan/Data/git/pyspi/audit/checks/data/'
np.set_printoptions(precision=4, suppress=True, linewidth=150)

def own_mean(X, y, kern):
    # from-scratch posterior mean at the fitted hyperparameters (no sklearn kernel evaluation)
    p = kern.get_params()
    c = p['k1__k1__constant_value']; w = p['k1__k2__noise_level']
    x = X[:, 0]
    if 'k2__length_scale' in p:
        l = p['k2__length_scale']; Kf = c + np.exp(-0.5 * (x[:, None] - x[None, :])**2 / l**2)
    else:
        s0 = p['k2__sigma_0']; Kf = c + s0**2 + np.outer(x, x)
    K = Kf + (w + 1e-10) * np.eye(len(x))
    a = np.linalg.solve(K, y)
    return Kf @ a

for name, T in [('bivariate_gaussian', 64), ('bivariate_gaussian', 256), ('nonlinear_dependence', 256), ('anm', 256), ('iid_gaussian', 256), ('delayed_noise', 256)]:
    x = np.load(f'{D}{name}_T{T}.npz')['x']
    for k in ['DotProduct', 'RBF']:
        spi = GPModel(kernel=k)
        dat = Data(x, dim_order='ps')
        A = spi.multivariate(dat)
        z = dat.to_numpy()
        print(f'== {name}_T{T} {k}  kernel after: {spi._kernel}')
        print(A)
        for (i, j) in [(0, 1), (1, 0), (2, 3), (3, 2)][: (4 if x.shape[0] >= 4 else 2)]:
            X, y = z[i], np.ravel(z[j])
            with warnings.catch_warnings(record=True) as wl:
                warnings.simplefilter('always')
                gp = GaussianProcessRegressor(kernel=clone(spi._kernel)).fit(X, y)
            yp = gp.predict(X); mse = np.mean((yp - y)**2)
            om = own_mean(X, y, gp.kernel_); mse_own = np.mean((om - y)**2)
            gpr = GaussianProcessRegressor(kernel=clone(spi._kernel), n_restarts_optimizer=15, random_state=0).fit(X, y)
            mse_r = np.mean((gpr.predict(X) - y)**2)
            r = np.corrcoef(X[:, 0], y)[0, 1]
            lin = (T - 1) / T * (1 - r**2)
            print(f'  ({i},{j}) pyspi={A[i,j]:.6g} rep={mse:.6g} eq={mse==A[i,j]} own={mse_own:.6g} |own-rep|={abs(mse_own-mse):.1e} '
                  f'restart={mse_r:.6g} LML={gp.log_marginal_likelihood_value_:.4f} LMLr={gpr.log_marginal_likelihood_value_:.4f} '
                  f'(T-1)/T(1-r^2)={lin:.6g} kern={gp.kernel_} warns={len(wl)} {[str(w.message)[:60] for w in wl][:2]}')
