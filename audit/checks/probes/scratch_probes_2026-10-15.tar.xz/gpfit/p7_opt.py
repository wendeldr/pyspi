import sys, warnings, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi'); warnings.simplefilter('ignore')
from pyspi.data import Data
from pyspi.statistics.misc import GPModel
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.base import clone
D = '/media/dan/Data/git/pyspi/audit/checks/data/'
def loo(gp, X):
    K = gp.kernel_(X); K[np.diag_indices_from(K)] += 1e-10
    Ki = np.linalg.inv(K); a = Ki @ gp.y_train_
    return np.mean((a / np.diag(Ki))**2)
kern = GPModel(kernel='RBF')._kernel
tot = worse = 0
for T in [64, 256]:
    for nm in ['iid_gaussian', 'bivariate_gaussian', 'anm', 'nonlinear_dependence', 'delayed_noise', 'var2_chain', 'logistic_maps', 'shared_envelope', 'narrowband_f0-0.1']:
        x = np.load(f'{D}{nm}_T{T}.npz')['x']; z = Data(x, dim_order='ps').to_numpy(); P = len(x)
        rows = []
        for i in range(P):
            for j in range(P):
                if i == j: continue
                X, y = z[i], np.ravel(z[j])
                g1 = GaussianProcessRegressor(kernel=clone(kern)).fit(X, y)
                g2 = GaussianProcessRegressor(kernel=clone(kern), n_restarts_optimizer=10, random_state=1).fit(X, y)
                m1 = np.mean((g1.predict(X) - y)**2); m2 = np.mean((g2.predict(X) - y)**2)
                d = g2.log_marginal_likelihood_value_ - g1.log_marginal_likelihood_value_
                tot += 1; worse += d > 1e-3
                rows.append((i, j, m1, loo(g1, X), d, m2, g2.kernel_.get_params()['k2__length_scale'], g2.kernel_.get_params()['k1__k2__noise_level']))
        nw = sum(r[4] > 1e-3 for r in rows)
        print(f'{nm}_T{T}: pairs={len(rows)} single-start below best LML (>1e-3): {nw}; ' +
              '; '.join(f'({r[0]},{r[1]}) mse={r[2]:.3g} loo={r[3]:.3g} dLML={r[4]:.2f} mse_best={r[5]:.2g} l_best={r[6]:.2g} w_best={r[7]:.2g}' for r in rows if r[4] > 1e-3)[:900], flush=True)
print('TOTAL', worse, 'of', tot)
