import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi.statistics.misc import GPModel
import sklearn, scipy
print('sklearn', sklearn.__version__, 'scipy', scipy.__version__, 'numpy', np.__version__)
for k in ['DotProduct', 'RBF']:
    s = GPModel(kernel=k)
    print(k, s.identifier, s.labels, type(s).__mro__[1:3])
    print('  kernel:', s._kernel)
    for h in s._kernel.hyperparameters: print('   ', h)
    print('  theta(log):', s._kernel.theta, 'bounds:', s._kernel.bounds.tolist())
