import sys, warnings, json, time, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi.data import Data
from pyspi.statistics.misc import GPModel
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.base import clone
D = '/media/dan/Data/git/pyspi/audit/checks/data/'
names = ['iid_gaussian','bivariate_gaussian','scaled_offset','trending','var2_bivariate','var2_chain','delayed_noise','narrowband_f0-0.1','narrowband_f0-0.25','narrowband_f0-0.4','logistic_maps','nonlinear_dependence','contaminated','cointegrated','anm','sparse_precision','shared_envelope','gauss_ar1_pair']
out = {}
for T in [64, 256, 1024]:
    for nm in names:
        x = np.load(f'{D}{nm}_T{T}.npz')['x']
        dat = Data(x, dim_order='ps'); z = dat.to_numpy()
        res = {}
        for k in ['DotProduct', 'RBF']:
            t0 = time.time()
            A = GPModel(kernel=k).multivariate(dat)
            dt = time.time() - t0
            P = A.shape[0]
            # closed-form linear reference and fitted hyperparameters
            lin = np.full_like(A, np.nan); hyp = {}
            for i in range(P):
                for j in range(P):
                    if i == j: continue
                    r = np.corrcoef(z[i][:, 0], z[j][:, 0])[0, 1]
                    lin[i, j] = (T - 1) / T * (1 - r**2)
                    if k == 'RBF':
                        with warnings.catch_warnings():
                            warnings.simplefilter('ignore')
                            gp = GaussianProcessRegressor(kernel=clone(GPModel(kernel=k)._kernel)).fit(z[i], np.ravel(z[j]))
                        p = gp.kernel_.get_params()
                        hyp[f'{i}{j}'] = (round(p['k1__k1__constant_value'], 6), round(p['k1__k2__noise_level'], 6), round(p['k2__length_scale'], 6))
            off = ~np.eye(P, dtype=bool)
            asym = np.nanmax(np.abs(A - A.T)[off])
            res[k] = dict(A=A.tolist(), time=dt, asym=float(asym), max_rel_lin=float(np.nanmax(np.abs(A - lin)[off] / lin[off])), hyp=hyp,
                          min=float(np.nanmin(A[off])), max=float(np.nanmax(A[off])))
            flag = ''
            if k == 'RBF':
                small = [kk for kk, v in hyp.items() if v[2] < 0.05]
                flag = f' small_l={small}'
            print(f'{nm}_T{T} {k}: t={dt:.1f}s min={res[k]["min"]:.4g} max={res[k]["max"]:.4g} max|A-A^T|={asym:.2e} max rel |A-lin|/lin={res[k]["max_rel_lin"]:.2e}{flag}', flush=True)
        out[f'{nm}_T{T}'] = res
json.dump(out, open('p3_scan.json', 'w'))
