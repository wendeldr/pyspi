import sys, warnings, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi'); warnings.simplefilter('ignore')
from pyspi.data import Data
from pyspi.statistics.misc import GPModel
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.base import clone
D = '/media/dan/Data/git/pyspi/audit/checks/data/'
np.set_printoptions(precision=5, linewidth=150)
for nm, T in [('shared_envelope', 64), ('narrowband_f0-0.4', 64)]:
    x = np.load(f'{D}{nm}_T{T}.npz')['x']; d = Data(x, dim_order='ps'); z = d.to_numpy()
    A = GPModel(kernel='RBF').multivariate(d); print(nm, T); print(A)
    P = len(x)
    for i in range(P):
        for j in range(P):
            if i == j: continue
            g = GaussianProcessRegressor(kernel=clone(GPModel(kernel='RBF')._kernel)).fit(z[i], np.ravel(z[j]))
            print(' ', i, j, g.kernel_, round(g.log_marginal_likelihood_value_, 3))
