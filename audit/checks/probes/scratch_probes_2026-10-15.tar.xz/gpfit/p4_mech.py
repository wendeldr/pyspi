import sys, warnings, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi')
warnings.simplefilter('ignore')
from pyspi.data import Data
from pyspi.statistics.misc import GPModel
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.base import clone
D = '/media/dan/Data/git/pyspi/audit/checks/data/'
x = np.load(f'{D}iid_gaussian_T256.npz')['x']
dat = Data(x, dim_order='ps'); z = dat.to_numpy()
X, y = z[0], np.ravel(z[1]); T = len(y)
kern = GPModel(kernel='RBF')._kernel
gpr = GaussianProcessRegressor(kernel=clone(kern), n_restarts_optimizer=15, random_state=0).fit(X, y)
print('restart winner:', gpr.kernel_, 'LML', gpr.log_marginal_likelihood_value_)
gp1 = GaussianProcessRegressor(kernel=clone(kern)).fit(X, y)
print('single start  :', gp1.kernel_, 'LML', gp1.log_marginal_likelihood_value_)
# LML of explicit alternatives (theta in log space: c, w, l)
for lab, th in [('l=1e-5,w=1e-5,c=1e-5', [np.log(1e-5), np.log(1e-5), np.log(1e-5)]), ('l=1e5,w=1,c=1e-5', [np.log(1e-5), 0., np.log(1e5)])]:
    print(lab, gp1.log_marginal_likelihood(np.array(th)))
# min pairwise spacing of x vs fitted length scale
xs = np.sort(X[:, 0]); print('min spacing', np.diff(xs).min(), 'median spacing', np.median(np.diff(xs)))
# convergence status of the pyspi single start (pyspi suppresses warnings)
from scipy.optimize import minimize
gp = GaussianProcessRegressor(kernel=clone(kern)); gp.fit(X, y)
# replicate optimisation to inspect result object
def obj(th):
    l, g = gp.log_marginal_likelihood(th, eval_gradient=True, clone_kernel=True); return -l, -g
r = minimize(obj, clone(kern).theta, method='L-BFGS-B', jac=True, bounds=clone(kern).bounds)
print('L-BFGS-B from theta0=0:', r.success, r.message, 'nit', r.nit, 'x', np.exp(r.x), 'fun', r.fun)

# DotProduct closed form with fitted s
for nm, (i, j) in [('bivariate_gaussian', (0, 1)), ('anm', (0, 1))]:
    for T in [64, 256]:
        xx = np.load(f'{D}{nm}_T{T}.npz')['x']; d = Data(xx, dim_order='ps'); zz = d.to_numpy()
        A = GPModel(kernel='DotProduct').multivariate(d)
        g = GaussianProcessRegressor(kernel=clone(GPModel(kernel='DotProduct')._kernel)).fit(zz[i], np.ravel(zz[j]))
        p = g.kernel_.get_params(); s = p['k1__k2__noise_level']
        xv, yv = zz[i][:, 0], zz[j][:, 0]
        r = np.corrcoef(xv, yv)[0, 1]; b = (xv @ yv) / (xv @ xv + s)
        cf = np.mean((yv - b * xv)**2)
        print(f'{nm}_T{T} A[i,j]={A[i,j]!r} A[j,i]={A[j,i]!r} bitwise_sym={A[i,j]==A[j,i]} closed={cf!r} rel={abs(cf-A[i,j])/A[i,j]:.2e} s={s:.4g} c={p["k1__k1__constant_value"]:.3g} sigma0={p["k2__sigma_0"]:.3g}')

# scale sensitivity: normalise=False on scaled_offset vs normalise=True
xx = np.load(f'{D}scaled_offset_T256.npz')['x']
for norm in [True, False]:
    d = Data(xx, dim_order='ps', normalise=norm)
    for k in ['DotProduct', 'RBF']:
        A = GPModel(kernel=k).multivariate(d)
        print('scaled_offset_T256 normalise', norm, k, np.round(A, 4).tolist())
