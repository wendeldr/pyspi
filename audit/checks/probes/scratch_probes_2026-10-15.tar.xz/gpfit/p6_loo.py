import sys, warnings, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi'); warnings.simplefilter('ignore')
from pyspi.data import Data
from pyspi.statistics.misc import GPModel
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.base import clone
D = '/media/dan/Data/git/pyspi/audit/checks/data/'
def loo(gp, X):
    K = gp.kernel_(X); K[np.diag_indices_from(K)] += 1e-10
    Ki = np.linalg.inv(K); a = Ki @ gp.y_train_
    return np.mean((a / np.diag(Ki))**2)  # R&W eq. 5.12 LOO residual
for nm, T, pairs in [('shared_envelope', 64, [(0, 1), (1, 0), (0, 2)]), ('shared_envelope', 256, [(0, 1), (1, 0), (2, 1)]), ('iid_gaussian', 256, [(0, 1)])]:
    x = np.load(f'{D}{nm}_T{T}.npz')['x']; d = Data(x, dim_order='ps'); z = d.to_numpy()
    for (i, j) in pairs:
        X, y = z[i], np.ravel(z[j])
        g = GaussianProcessRegressor(kernel=clone(GPModel(kernel='RBF')._kernel)).fit(X, y)
        ins = np.mean((g.predict(X) - y)**2)
        xs = np.sort(X[:, 0]); dup = np.sum(np.diff(xs) == 0)
        print(f'{nm}_T{T} ({i},{j}) in-sample MSE={ins:.3g}  LOO MSE={loo(g, X):.3g}  kernel={g.kernel_}  LML={g.log_marginal_likelihood_value_:.2f} min_dx={np.diff(xs).min():.2e} dup={dup}')
        # LML of a sensible alternative: refit with noise_level lower bound 1e-2
        from sklearn.gaussian_process import kernels
        k2 = kernels.ConstantKernel() + kernels.WhiteKernel(noise_level_bounds=(1e-2, 1e5)) + kernels.RBF()
        g2 = GaussianProcessRegressor(kernel=k2).fit(X, y)
        print(f'      noise>=1e-2 refit: in-sample={np.mean((g2.predict(X)-y)**2):.3g} LOO={loo(g2, X):.3g} LML={g2.log_marginal_likelihood_value_:.2f} {g2.kernel_}')
