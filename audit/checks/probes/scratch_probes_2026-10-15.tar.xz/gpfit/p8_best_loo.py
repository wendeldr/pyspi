import sys, warnings, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi'); warnings.simplefilter('ignore')
from pyspi.data import Data
from pyspi.statistics.misc import GPModel
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.base import clone
D = '/media/dan/Data/git/pyspi/audit/checks/data/'
def loo(gp, X):
    K = gp.kernel_(X); K[np.diag_indices_from(K)] += 1e-10
    Ki = np.linalg.inv(K); a = Ki @ gp.y_train_
    return np.mean((a / np.diag(Ki))**2)
kern = GPModel(kernel='RBF')._kernel
for nm, T, (i, j) in [('narrowband_f0-0.1', 64, (1, 0)), ('narrowband_f0-0.1', 64, (1, 2)), ('shared_envelope', 64, (0, 1)), ('iid_gaussian', 64, (0, 1)), ('nonlinear_dependence', 64, (1, 0)), ('var2_chain', 64, (0, 1))]:
    z = Data(np.load(f'{D}{nm}_T{T}.npz')['x'], dim_order='ps').to_numpy(); X, y = z[i], np.ravel(z[j])
    g1 = GaussianProcessRegressor(kernel=clone(kern)).fit(X, y)
    g2 = GaussianProcessRegressor(kernel=clone(kern), n_restarts_optimizer=10, random_state=1).fit(X, y)
    f = lambda g: f'mse={np.mean((g.predict(X)-y)**2):.3g} loo={loo(g, X):.3g} LML={g.log_marginal_likelihood_value_:.2f} {g.kernel_}'
    print(f'{nm}_T{T} ({i},{j})\n   single: {f(g1)}\n   best  : {f(g2)}')
