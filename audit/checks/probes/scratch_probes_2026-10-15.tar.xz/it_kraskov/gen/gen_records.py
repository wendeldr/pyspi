"""Generate audit/records/<unit>.yaml for the it_kraskov family (traced stage)."""
import yaml
from pathlib import Path

OUT = Path('/media/dan/Data/git/pyspi/audit/records')
J = 'https://github.com/jlizier/jidt/blob/a9b6b3e77ca8c051f1031003474e2e35dd4a3269/java/source/infodynamics/'
J161 = 'https://github.com/jlizier/jidt/blob/v1.6.1/java/source/infodynamics/'
MC = J + 'measures/continuous/'
KR = MC + 'kraskov/'

DELEGATE_MI = ("JIDT jar pyspi/lib/jidt/infodynamics.jar (labelled 1.6.1 by pyspi/lib/jidt/version-1.6.1.txt, but its classes "
               "contain the NOISE_SEED property that JIDT master added after the v1.6.1 tag; build date 2024-04-21 matches master "
               "a9b6b3e of 2024-04-20, whose source is cited below) "
               "infodynamics.measures.continuous.kraskov.MutualInfoCalculatorMultiVariateKraskov1.computeAverageLocalOfObservations, "
               "called through jpype 1.7.1 on OpenJDK 21.0.12")
DELEGATE_TE = ("JIDT jar pyspi/lib/jidt/infodynamics.jar (labelled 1.6.1; contents match post-1.6.1 master a9b6b3e, see infotheory.est.ksg1) "
               "infodynamics.measures.continuous.kraskov.TransferEntropyCalculatorKraskov (KSG algorithm 1 conditional MI "
               "ConditionalMutualInfoCalculatorMultiVariateKraskov1) .setObservations/.computeAverageLocalOfObservations, via jpype 1.7.1 on OpenJDK 21.0.12")

# ---------------------------------------------------------------- shared trace pieces
T_PRE = [
    "pyspi/data.py:184-195 Data.set_data preprocessing: optional scipy.signal.detrend(axis=1), then scipy.stats.zscore(axis=1, ddof=1) when normalise=True (Calculator default normalise=True, detrend=False)",
    "pyspi/calculator.py:281-302 Calculator.compute: S = spi.multivariate(dataset); any exception escaping multivariate turns the whole SPI matrix NaN (per-pair JIDT exceptions are caught earlier inside bivariate and give a NaN entry)",
]
T_DIRECTED = "pyspi/base.py:84-94 Directed.multivariate: outer loop j, inner loop i != j, A[i, j] = self.bivariate(data, i=i, j=j) (no mirroring)"
T_UNDIR = [
    "pyspi/base.py:84-94 Directed.multivariate (called via super): outer j, inner i != j, A[i, j] = bivariate(i, j)",
    "pyspi/base.py:132-138 Undirected.multivariate: li = tril_indices(-1); A[li] = A.T[li] (upper triangle i<j, computed as bivariate(i, j), is kept and mirrored)",
]
T_INIT = [
    "pyspi/statistics/infotheory.py:28-58 JIDTBase.__init__: identifier += '_kraskov_NN-{prop_k}', labels += ['nonlinear'], '_DCE' appended when dyn_corr_excl is truthy",
    "pyspi/statistics/infotheory.py:84-93 JIDTBase._setup: setProperty('k', '4'); setProperty('BIAS_CORRECTION', 'false') (not a property of the Kraskov calculators: probe getProperty('BIAS_CORRECTION') -> None, i.e. ignored); setProperty('NOISE_SEED', '42')",
]
T_THEILER = [
    "pyspi/statistics/infotheory.py:195-216 JIDTBase._set_theiler_window (dyn_corr_excl='AUTO'): on the first call for a Data object computes, for every pair _i<_j, theiler[_i,_j] = theiler[_j,_i] = 2 * np.dot(utils.acf(z[_j]), utils.acf(z[_i])) and caches it as data.theiler; then setProperty('DYN_CORR_EXCL', str(int(data.theiler[i, j]))) on the calculator for the current pair",
    "pyspi/utils.py:47-60 acf(x): x = scipy.stats.zscore(x) (ddof=0); acf = np.correlate(x, x, 'full'); acf /= acf[T-1]; returns lags 0..T-1 (biased sample ACF, divisor sum x^2 at every lag, no lag truncation)",
]
T_MI_COMMON = [
    "JIDT " + MC + "MutualInfoMultiVariateCommon.java#L574-L643 MutualInfoMultiVariateCommon.finaliseAddObservations: copies data, computes means and std (MatrixUtils.stdDevs, divisor N-1, MatrixUtils.java#L2490-L2502), normalises each column when NORMALISE=true (default true, :164; MatrixUtils.normalise :2663-2672), then adds random.nextGaussian()*noiseLevel to every source then destination entry row by row from java.util.Random seeded with NOISE_SEED (:626-642; NOISE_SEED parsed at :265-271)",
    "JIDT " + KR + "MutualInfoCalculatorMultiVariateKraskov.java#L180-L185 constructor: addNoise=true, noiseLevel=1e-8; :74 k default 4; :79 normType = NORM_MAX_NORM; :133 numThreads = availableProcessors() (probe: 64 here)",
    "JIDT " + KR + "MutualInfoCalculatorMultiVariateKraskov.java#L225-L250 setProperty: k, NORM_TYPE, DYN_CORR_EXCL (dynCorrExcl = W > 0), NUM_THREADS; unknown names go to MutualInfoMultiVariateCommon.setProperty (unknown ignored)",
    "JIDT " + KR + "MutualInfoCalculatorMultiVariateKraskov.java#L294-L308 finaliseAddObservations: throws if totalObservations <= k + 2*DYN_CORR_EXCL; digammaK = digamma(k), digammaN = digamma(totalObservations) (N not reduced for the exclusion window)",
    "JIDT " + KR + "MutualInfoCalculatorMultiVariateKraskov.java#L315-L330 computeAverageLocalOfObservations -> computeFromObservations :427-526: splits time points over numThreads threads, sums per-thread partial digamma sums, returns digammaK - averageDiGammas + digammaN for algorithm 1 (:518-522)",
    "JIDT " + KR + "MutualInfoCalculatorMultiVariateKraskov.java#L715-L738 ensureKdTreesConstructed: joint KdTree over (source, dest) and per-marginal NearestNeighbourSearcher (UnivariateNearestNeighbourSearcher for 1-D), all max-norm, carrying observationTimePoints for the exclusion window",
    "JIDT " + KR + "MutualInfoCalculatorMultiVariateKraskov1.java#L60-L123 partialComputeFromObservations: eps_t = distance of the k-th nearest neighbour in the joint space (kdTreeJoint.findKNearestNeighbours(k, t, dynCorrExclTime), :79-83); n_x, n_y = countPointsStrictlyWithinR(t, eps_t, dynCorrExclTime) in each marginal (:88-91); sum digamma(n_x+1) + digamma(n_y+1) (:97-99)",
    "JIDT " + J + "utils/KdTree.java#L751-L753 findKNearestNeighbours: a candidate is admissible only if it comes from another observation set or |timePoint(candidate) - timePoint(sample)| > dynCorrExclTime (so W=0 excludes only the sample itself); " + J + "utils/UnivariateNearestNeighbourSearcher.java#L497-L530 countPointsWithinR skips |dt| <= dynCorrExclTime and counts norm < r strictly (allowEqualToR=false)",
]
T_CMI = [
    "JIDT " + KR + "TransferEntropyCalculatorKraskov.java#L118-L121 constructor: super(COND_MI_CALCULATOR_KRASKOV1) -> ConditionalMutualInfoCalculatorMultiVariateKraskov1 (ALG_NUM=1, probe getProperty('ALG_NUM') = 1); :213-233 setProperty passes unknown names (k, BIAS_CORRECTION, NOISE_SEED, DYN_CORR_EXCL) to TransferEntropyCalculatorViaCondMutualInfo.setProperty",
    "JIDT " + MC + "TransferEntropyCalculatorViaCondMutualInfo.java#L435-L470 setProperty: k_HISTORY, k_TAU, l_HISTORY, l_TAU, DELAY (default 1), AUTO_EMBED_METHOD, AUTO_EMBED_K_SEARCH_MAX, AUTO_EMBED_TAU_SEARCH_MAX handled here; everything else is forwarded to the CMI calculator and stored in props (:462-465)",
    "JIDT " + MC + "TransferEntropyCalculatorViaCondMutualInfo.java#L323-L363 initialise() re-uses the current k, k_tau, l, l_tau, delay fields",
    "JIDT " + MC + "TransferEntropyCalculatorViaCondMutualInfo.java#L375-L385 computeStartTimeForFirstDestEmbedding = max((k-1)*k_tau, (l-1)*l_tau + delay - 1)",
    "JIDT " + MC + "TransferEntropyCalculatorViaCondMutualInfo.java#L505-L509 setObservations -> startAddObservations/addObservations/finaliseAddObservations; :865-875 finaliseAddObservations runs preFinaliseAddObservations (auto-embedding, :701-855) then prepareCMICalculator",
    "JIDT " + MC + "TransferEntropyCalculatorViaCondMutualInfo.java#L585-L619 addObservationsWithGivenParams: destPast = delay embedding of dest (k, k_tau) ending at time n; destNext = dest[n+1]; sourcePast = embedding of source (l, l_tau) ending at n+1-delay; CMI var1 = sourcePast, var2 = destNext, cond = destPast; N = T - start - 1 samples",
    "JIDT " + MC + "TransferEntropyCalculatorViaCondMutualInfo.java#L1067-L1068 computeAverageLocalOfObservations returns condMiCalc.computeAverageLocalOfObservations()",
    "JIDT " + MC + "ConditionalMutualInfoMultiVariateCommon.java#L705-L780 finaliseAddObservations: per-column normalisation (NORMALISE default true, :158) and 1e-8 Gaussian jitter from java.util.Random seeded with NOISE_SEED, row by row over var1, var2, cond columns (:766-780)",
    "JIDT " + KR + "ConditionalMutualInfoCalculatorMultiVariateKraskov.java#L214-L219 constructor addNoise=true, noiseLevel=1e-8; :96 k=4 default; :101 NORM_MAX_NORM; :155 numThreads = availableProcessors(); :265-285 setProperty (k, NORM_TYPE, DYN_CORR_EXCL, NUM_THREADS); :312-325 finaliseAddObservations throws if N <= k + 2*DYN_CORR_EXCL; :539-546 algorithm-1 result digamma(k) + averageDiGammas",
    "JIDT " + KR + "ConditionalMutualInfoCalculatorMultiVariateKraskov1.java#L75-L270 partialComputeFromObservations: eps_t = k-th NN max-norm distance in the joint (x, y, z) space with the exclusion window (:102-108); n_xz, n_yz, n_z counted strictly within eps_t (option B/C code paths :140-240); sum digamma(n_z+1) - digamma(n_xz+1) - digamma(n_yz+1) (:252-255)",
]
T_AUTO = [
    "JIDT " + MC + "TransferEntropyCalculatorViaCondMutualInfo.java#L701-L855 preFinaliseAddObservations (AUTO_EMBED_METHOD=MAX_CORR_AIS): builds ActiveInfoStorageCalculatorKraskov(1) (:740), copies every stored property (k, BIAS_CORRECTION, NOISE_SEED and DYN_CORR_EXCL when set) into it (:752-754), sets its AUTO_EMBED_METHOD=MAX_CORR_AIS, K_SEARCH_MAX, TAU_SEARCH_MAX (:765-773), embeds the destination (k, k_tau from the AIS calculator, :779-783) and then the source (l, l_tau, :788-797); re-run on every setObservations call, i.e. for every ordered pair",
    "JIDT " + MC + "ActiveInfoStorageCalculatorViaMutualInfo.java#L579-L614 MAX_CORR_AIS search: for k_candidate = 1..k_search_max, tau_candidate = 1..tau_search_max (tau loop broken after tau=1 when k_candidate=1), thisAIS = KSG MI between the (k, tau) past embedding and the next value minus computeAdditionalBiasToRemove() (= 0, :636-639, not overridden by the Kraskov class); keeps the strict maximum; any exception aborts the whole search ('Exception encountered in attempting auto-embedding')",
    "JIDT " + MC + "ActiveInfoStorageCalculatorViaMutualInfo.java#L669-L694 prepareMICalculator: initialise(k_candidate, 1) and add all (past, next) pairs for this candidate; N varies with the candidate (T - (k-1)*tau - 1)",
    "JIDT " + KR + "ActiveInfoStorageCalculatorKraskov.java#L148-L154 constructor ActiveInfoStorageCalculatorKraskov(1) -> MutualInfoCalculatorMultiVariateKraskov1",
]
T_COPY = "pyspi/statistics/infotheory.py:71-82 and :369-374 JIDTBase.__setstate__/__deepcopy__ and TransferEntropy.__setstate__: the calculator is rebuilt with self._getcalc('TransferEntropy'), which applies only _setup (k, BIAS_CORRECTION, NOISE_SEED); the auto-embedding / k_HISTORY / l_HISTORY properties set in TransferEntropy.__init__ (:344-367) are not re-applied (see new_finding_candidates)"

ALREADY_M8_TLMI = "docs/storage_comparison/REVIEW.md M8 ('tlmi is asymmetric by construction', recorded for tlmi_gaussian; the same lag construction is used here)"
ALREADY_CML7 = "tests/README.md worth knowing: 'auto-embedding TE kraskov equals fixed k=1 on cml7' (confirmed here: cml7 first 3 channels give k,kt,l,lt = 1,1,1,1 and te value equal to te_k1, probe p11)"

C_JAR = ("CANDIDATE (provenance): the bundled jar is not the v1.6.1 release. Evidence: `strings` on the jar's MutualInfoMultiVariateCommon.class lists "
         "NOISE_SEED, noiseSeedSet, setSeed; the v1.6.1 tag source " + J161 + "measures/continuous/MutualInfoMultiVariateCommon.java#L519-L529 "
         "uses 'Random random = new Random();' with no seed and its setProperty (:201-229) has no NOISE_SEED; the property arrives in master commit 2a18cd0 "
         "(2024-04-16) and the jar entries are dated 2024-04-21 (last master commit before that: a9b6b3e, 2024-04-20). With the real v1.6.1 the "
         "NOISE_SEED=42 that pyspi sets would be silently ignored and the jitter unseeded. The documented versions are v1.5 (supplement §1.4) and v1.6.1 (GitBook).")
C_THREADS = ("CANDIDATE: the value depends on the machine's core count at the 1e-14 level, because NUM_THREADS defaults to availableProcessors() (64 here) and per-thread "
             "digamma partial sums are added in thread order. Probe p2 (bivariate_gaussian T=1024): max |A(default) - A(NUM_THREADS=1)| = 7.1e-15 mi, 1.1e-14 mi_DCE, "
             "1.6e-14 tlmi, 2.4e-15 te_k1, 4.2e-15 te_auto; repeat runs on the same machine are bit-identical.")
C_JITTER = ("CANDIDATE: on tied or discrete-valued inputs the estimate is set by the 1e-8 jitter and its seed. Probe p12, logistic_maps T=256 (series 1 is the "
            "period-4 r=3.5 map, 4 distinct values): pair 1->0 for NOISE_SEED 42/43/44 gives mi 0.226622/0.226587/0.230899, tlmi 0.278902/0.276961/0.281417, "
            "te_k1 0.115063/0.113329/0.107266, te_auto 0.101410 (l,lt=7,2) / 0.089128 (10,2) / 0.044229 (6,1); bivariate_gaussian is identical for all seeds.")
C_NEG = ("CANDIDATE (estimator property, not a pyspi bug): labelled 'unsigned' but KSG estimates are negative on independent data. Probe p13 minima at T=64: "
         "mi -0.167 (nonlinear_dependence), tlmi -0.143 (iid_gaussian), te_k1 -0.134 (logistic_maps), te_auto_DCE -0.178 (cointegrated); at T=256 iid_gaussian mi min -0.055.")
C_BIAS = ("CANDIDATE (no-op setting): pyspi sets BIAS_CORRECTION=false (infotheory.py:90) but neither Kraskov calculator defines that property; probe p1 "
          "getProperty('BIAS_CORRECTION') returns None for all nine units, so the call has no effect and no bias correction exists for KSG here.")
C_COPY = ("CANDIDATE (new, confirmed by probe): copying a TransferEntropy SPI silently drops its embedding settings while keeping the identifier. "
          "TransferEntropy.__setstate__ (infotheory.py:369-374) and JIDTBase.__deepcopy__ (:77-82) end with a calculator built by _getcalc/_setup only, so "
          "AUTO_EMBED_METHOD returns to NONE and k_HISTORY to 1 (probe p9: after pickle, getProperty -> k_HISTORY '1', AUTO_EMBED_METHOD 'NONE'). "
          "CalculatorFrame.init_from_list deepcopies the base Calculator (calculator.py:503-510), so a CalculatorFrame computes fixed k=1 TE under these identifiers. "
          "Probe p10, var2_bivariate T=256, A[0,1]: te_kraskov_NN-4_k-max-10_tau-max-4 Calculator 0.060599 vs CalculatorFrame 0.133643 (= te_k1 0.133643); "
          "te_kraskov_NN-4_DCE_k-2_kt-1_l-1_lt-1 Calculator 0.159244 vs CalculatorFrame 0.134372. MutualInfo and TLMI are unaffected (their settings come from _setup or are set per call; probe mi_DCE diff 0.0).")


def ksg_mi_ref(label='KSG1 MI'):
    return ("from-scratch brute-force " + label + " in numpy (max-norm pairwise distance matrices, k-th neighbour by sort, strict counts, |dt| <= W exclusion) + "
            "scipy.special.digamma, columns standardised with ddof=1 and the 1e-8 jitter regenerated by a pure-Python java.util.Random LCG "
            "(nextGaussian polar method, seed 42; matches java.util.Random to 2e-16); does not import JIDT/jpype. Prototype: "
            "scratchpad it_kraskov/probes/ksg_ref.py")


def mk(unit_id, c):
    rec = {'unit_id': unit_id, 'status': 'traced', 'correctness': c}
    (OUT / f'{unit_id}.yaml').write_text(yaml.safe_dump(rec, sort_keys=False, allow_unicode=True, width=200))


# ================================================================= MI
MI_DOC = ("supplement §1.4.3, p.10 (pack lines 469-476): 'Mutual information [33] is an undirected measure of the (potentially nonlinear) dependence between paired "
          "observations of x and y.' Estimator: supplement §1.4, p.9 (pack lines 414-453): 'The Kraskov–Stögbauer-Grassberger (KSG) technique (ksg) combines "
          "nearest-neighbor estimators for mutual information based measures (default of four nearest neighbors, indicated by modifier NN-4)'; 'We primarily use v1.5 "
          "of the Java Information Dynamics Toolkit [32]'. GitBook information-theory.md:11 says v1.6.1, :16 repeats the KSG text, :160-180 lists mi_kraskov_NN-4 and mi_kraskov_NN-4_DCE.")
MI_CANON_REF = ("Kraskov, Stögbauer & Grassberger 2004, Phys. Rev. E 69, 066138, algorithm 1 (their Eq. 8; equation number from memory); MI definition: Cover & Thomas 2006, "
                "Elements of Information Theory, 2nd ed., §8.5. The supplement's own reference for MI is [33] MacKay 2003.")
MI_CANON_DEF = ("I(X;Y) = ∫∫ p(x,y) log[p(x,y) / (p(x) p(y))] dx dy (nats). KSG1: Î = ψ(k) − ⟨ψ(n_x(i)+1) + ψ(n_y(i)+1)⟩_i + ψ(N), where ε(i) is the max-norm "
                "distance from z_i = (x_i, y_i) to its k-th nearest neighbour (j ≠ i) and n_x(i), n_y(i) count j ≠ i with |x_j − x_i| < ε(i), |y_j − y_i| < ε(i); "
                "samples assumed i.i.d.")


def mi_checks(dce):
    W = ', with the pair-specific Theiler window W_ij from infotheory.theiler_window' if dce else ', W = 0'
    checks = [
        {'datasets': ['bivariate_gaussian', 'nonlinear_dependence', 'delayed_noise', 'iid_gaussian', 'logistic_maps'] + (['narrowband_f0-0.1', 'gauss_ar1_pair'] if dce else []),
         'path': 'kernel', 'reference': ksg_mi_ref() + W + ', applied to the z-scored rows (i, j)',
         'reference_kind': 'independent-impl', 'criterion': 'tolerance',
         'expected_outcome': 'agreement to <= 1e-12 absolute on every pair at T in {64, 256, 1024} (prototype probe p5 at T=256: |Δ| <= 3e-15' + (', W up to 85' if dce else '') + '); confirms the trace including jitter order and strict counts'},
        {'datasets': ['bivariate_gaussian', 'gauss_ar1_pair'], 'path': 'pipeline',
         'reference': "analytic Gaussian MI −½ log(1 − ρ²): bivariate_gaussian truth 'true_mi_nats' = (0.0472, 0.5108) for pairs (0,1),(2,3); gauss_ar1_pair ρ from truth Sigma_X gives 0.1578 nats (computed in this stage from Sigma_X)",
         'reference_kind': 'analytic', 'criterion': 'statistical',
         'expected_outcome': 'KSG1 converges to the analytic value as T grows: |Î − I| shrinking with T and below ~0.02 nats at T=4096 for bivariate_gaussian; ' + ('for gauss_ar1_pair (autocorrelated) the DCE estimate is compared with the non-DCE one to see whether the window reduces or increases the error (probe p5 T=256: non-DCE 0.1195, DCE 0.1688, analytic 0.1578)' if dce else 'gauss_ar1_pair is autocorrelated so the i.i.d. assumption is violated; record the error (probe p5 T=256: 0.1195 vs 0.1578)')},
        {'datasets': ['iid_gaussian'], 'path': 'pipeline', 'reference': 'analytic null I = 0 for independent processes',
         'reference_kind': 'analytic', 'criterion': 'statistical',
         'expected_outcome': 'off-diagonal values centred near 0 with spread shrinking with T; negative values expected (probe: T=64 min -0.096' + (' (non-DCE)' if dce else '') + ', T=256 min -0.055)'},
        {'datasets': ['bivariate_gaussian', 'scaled_offset'], 'path': 'pipeline',
         'reference': 'invariance: scaled_offset is the same draw as bivariate_gaussian times a per-process scale plus offset; z-scoring (and the estimator) remove both',
         'reference_kind': 'analytic', 'criterion': 'tolerance',
         'expected_outcome': 'A(scaled_offset) equals A(bivariate_gaussian) to <= 1e-10 (residual only from floating-point differences in the z-scored inputs relative to the 1e-8 jitter)'},
        {'datasets': ['iid_gaussian', 'delayed_noise', 'bivariate_gaussian'], 'path': 'pipeline',
         'reference': 'symmetry: A == A.T and bivariate(i, j) == bivariate(j, i) evaluated fresh (KSG1 is symmetric in X, Y apart from jitter assignment)',
         'reference_kind': 'analytic', 'criterion': 'exact',
         'expected_outcome': 'A symmetric exactly (mirror); fresh bivariate(i,j) and bivariate(j,i) equal to <= 1e-14 (probe p2: 0.033251782902 both orders)'},
        {'datasets': ['bivariate_gaussian', 'nonlinear_dependence'], 'path': 'kernel',
         'reference': 'sklearn.feature_selection.mutual_info_regression(x[:,None], y, n_neighbors=4, discrete_features=False) (independent KSG implementation; it adds its own small noise and scales without centring, so differences are expected)',
         'reference_kind': 'external-pkg', 'criterion': 'tolerance',
         'expected_outcome': 'close (|Δ| < 0.01 nats on continuous data at T >= 256); note sklearn clips negative estimates to 0, so compare only where both are positive'},
    ]
    if dce:
        checks.append({'datasets': ['narrowband_f0-0.1', 'narrowband_f0-0.25', 'shared_envelope', 'cointegrated', 'trending'], 'path': 'pipeline',
                       'reference': 'analytic expectation of the window rule: W ≈ T/3 for a sinusoid (2 Σ_k (1−k/T)² cos²(ωk) ≈ T/3), and the JIDT guard N <= k + 2W raises',
                       'reference_kind': 'analytic', 'criterion': 'qualitative',
                       'expected_outcome': 'W grows linearly with T on oscillatory/trending inputs (probe p3: narrowband 22/85/339/1353 at T=64/256/1024/4096; trending without detrend 1403 at T=4096, 2 with detrend); MI is still finite (no NaN in probe p13 at T=64, 256) but each sample excludes about 2/3 of the series; record DCE vs non-DCE values (probe narrowband T=256 pair (0,1): 1.448 -> 2.239)'})
        checks.append({'datasets': ['trending', 'cointegrated'], 'path': 'pipeline-detrend',
                       'reference': 'same window rule on detrended input (Data(detrend=True))',
                       'reference_kind': 'analytic', 'criterion': 'qualitative',
                       'expected_outcome': 'trending: W collapses from 58-1403 to 1-2 after detrend (probe p3), cointegrated remains large (T=4096: 1093 with detrend); MI_DCE values change accordingly'})
    return checks


mk('infotheory.mi.kraskov', {
    'metric_name_standard': 'mutual information I(X;Y) in nats, Kraskov-Stögbauer-Grassberger estimator algorithm 1 (KSG1), k = 4 nearest neighbours, max-norm',
    'canonical_ref': MI_CANON_REF,
    'canonical_definition': MI_CANON_DEF,
    'documented_definition': MI_DOC,
    'delegate_lib': DELEGATE_MI,
    'implemented_as': ("Each channel optionally detrended, then z-scored (ddof=1). bivariate(i, j): src = x_i, targ = x_j, full length T, no lag, no exclusion window. "
                       "JIDT re-standardises each variable (mean, std with divisor N−1), adds N(0, (1e-8)²) jitter in standardised units from java.util.Random(42) "
                       "(row by row: source then target), finds for each t the max-norm distance ε_t to the 4th nearest neighbour in the joint space (self excluded), "
                       "counts marginal neighbours strictly closer than ε_t, and returns ψ(4) − mean_t[ψ(n_x+1) + ψ(n_y+1)] + ψ(T) in nats. No bias correction. "
                       "Time points are split across all available cores and partial sums added. The matrix is the upper triangle bivariate(i<j) mirrored. "
                       "A JIDT exception gives NaN for the pair (bare except, infotheory.py:279-283)."),
    'implementation_trace': ["pyspi/config.yaml:495-512 MutualInfo configs: estimator kraskov, prop_k 4 (this unit) and the DCE variant"] + T_PRE + T_UNDIR + T_INIT + [
        "pyspi/statistics/infotheory.py:103-134 JIDTBase._getcalc('MutualInfo') -> infodynamics.measures.continuous.kraskov.MutualInfoCalculatorMultiVariateKraskov1 (:116-119), then _setup",
        "pyspi/statistics/infotheory.py:253-260 MutualInfo.__init__ (Undirected) creates the calculator once per SPI",
        "pyspi/statistics/infotheory.py:267-283 MutualInfo.bivariate: _set_theiler_window (no-op when dyn_corr_excl is None, :217), calc.initialise(1, 1), src, targ = data.to_numpy(squeeze=True)[[i, j]], setObservations(JArray(src), JArray(targ)), return computeAverageLocalOfObservations(); bare except -> NaN with a 'Cholesky factorisation' warning",
    ] + T_MI_COMMON,
    'deviation_from_documented': ("Estimator matches the documentation (KSG, k=4). Undocumented details: 1e-8 Gaussian jitter with fixed seed 42, no bias correction, results in nats, "
                                  "and estimates can be negative although the SPI is labelled 'unsigned'. Version: supplement says JIDT v1.5, GitBook v1.6.1, the shipped jar is a post-1.6.1 master build. "
                                  "The time series samples are treated as i.i.d.; the supplement itself notes that autocorrelation biases the estimate (§1.4, p.9) and offers the DCE variant for that."),
    'deviation_from_canonical': ("Matches KSG algorithm 1 (a from-scratch brute-force KSG1 reproduces pyspi to <= 3e-15 on bivariate_gaussian, delayed_noise, var2_bivariate, gauss_ar1_pair and "
                                 "narrowband_f0-0.1 at T=256, probe p5). Implementation choices on top of the paper: inputs re-standardised, 1e-8 jitter (changes the value only with ties, "
                                 "e.g. logistic_maps, see candidates), ψ(N) with N = T, max-norm. Applying an i.i.d. estimator to autocorrelated time series is outside the estimator's assumptions "
                                 "(gauss_ar1_pair T=256: 0.1195 vs analytic 0.1578)."),
    'units_and_range': 'nats; real-valued, can be negative (finite-sample bias; probe minimum -0.167 at T=64); unbounded above; symmetric; NaN only when JIDT raises (e.g. T <= 4)',
    'direction_convention': 'Undirected: A[i, j] = A[j, i] = Î(x_min(i,j); x_max(i,j)), computed once as bivariate(min, max) (base.py:91-93) and mirrored (base.py:136-137); KSG1 itself is symmetric (probe p2: bivariate(0,1) = bivariate(1,0) = 0.033251782902)',
    'symmetry_expected': 'sym',
    'already_documented': 'no',
    'new_finding_candidates': [C_JAR, C_THREADS, C_JITTER, C_NEG, C_BIAS],
    'proposed_checks': mi_checks(False),
})

mk('infotheory.mi.kraskov_DCE', {
    'metric_name_standard': 'mutual information I(X;Y) in nats, KSG1 estimator (k=4, max-norm) with a Theiler window (dynamic correlation exclusion) of W_ij samples',
    'canonical_ref': MI_CANON_REF + " Theiler window: Theiler 1986, Phys. Rev. A 34, 2427 (supplement [36]); Kantz & Schreiber 2004, Nonlinear Time Series Analysis, 2nd ed. (section on the Theiler window, cited by the JIDT javadoc). Window heuristic: see infotheory.theiler_window (Bartlett 1946, supplement [37]).",
    'canonical_definition': MI_CANON_DEF + " With a Theiler window W, neighbours j with |t_j − t_i| <= W are excluded from both the k-NN search and the marginal counts, so temporally correlated points do not count as independent neighbours.",
    'documented_definition': MI_DOC + " DCE: supplement §1.4, p.9-10: 'A common solution to reduce bias in nonlinear estimators (like the KSG technique) is to use dynamic correlation exclusion (also known as a Theiler window) [35, 36], which excludes any data points within a given time window from the density estimate ... here, we set the window as the product of the autocorrelation functions of both time series (a heuristic for the autocorrelation time based on Bartlett's formula [10, 37]). The DCE modifier indicates that the Theiler window is used for the KSG estimator.' Same text GitBook information-theory.md:20.",
    'delegate_lib': DELEGATE_MI,
    'implemented_as': ("As infotheory.mi.kraskov, but before each pair pyspi sets DYN_CORR_EXCL = int(2 · Σ_{k=0}^{T−1} r_i(k) r_j(k)) where r is the biased sample ACF of each "
                       "z-scored channel over all T lags (computed once per Data for all pairs and cached as data.theiler). JIDT then excludes every point with |t − t'| <= W "
                       "from the joint k-NN search and both marginal counts, keeps ψ(N) with N = T, and raises (-> NaN) if T <= 4 + 2W."),
    'implementation_trace': ["pyspi/config.yaml:510-512 MutualInfo config estimator kraskov, prop_k 4, dyn_corr_excl AUTO"] + T_PRE + T_UNDIR + T_INIT + T_THEILER + [
        "pyspi/statistics/infotheory.py:103-134 _getcalc('MutualInfo') -> MutualInfoCalculatorMultiVariateKraskov1 (:116-119)",
        "pyspi/statistics/infotheory.py:267-283 MutualInfo.bivariate: _set_theiler_window(data, i, j) first (:270), then initialise(1,1), setObservations(x_i, x_j), computeAverageLocalOfObservations; bare except -> NaN",
    ] + T_MI_COMMON,
    'deviation_from_documented': ("(1) Window formula: documented as 'the product of the autocorrelation functions of both time series'; implemented as 2 × the inner product of the two full "
                                  "sample ACFs over lags 0..T−1, truncated with int(). (2) Documented as a heuristic for the autocorrelation time from Bartlett's formula; the implemented value "
                                  "equals Bartlett's 1 + 2Σ_{k>=1} r_i(k) r_j(k) plus exactly 1 before truncation (probe p3: raw − Bartlett = 1.00 on every pair). (3) Because all T−1 lags are "
                                  "summed, W is not an autocorrelation time for oscillatory or trending inputs: it grows linearly with T (narrowband ≈ T/3: 22/85/339/1353 at T=64/256/1024/4096). "
                                  "(4) Other undocumented details as in infotheory.mi.kraskov (jitter, seed, nats, negative values)."),
    'deviation_from_canonical': ("KSG1 with Theiler window as implemented in JIDT (from-scratch KSG1 with |dt| <= W exclusion reproduces pyspi to <= 1e-12 at W = 2-85, probe p5). "
                                 "ψ(N) is not adjusted for the excluded points (JIDT notes this as an open TODO, MutualInfoCalculatorMultiVariateKraskov1.java:102-104). "
                                 "The window size rule is a pyspi heuristic (see infotheory.theiler_window); canonical practice chooses W of the order of the autocorrelation time, "
                                 "whereas here W can exclude about two thirds of the series. Effect on values is large where W is large (narrowband_f0-0.1 T=256 pair (0,1): 1.448 without, 2.239 with DCE)."),
    'units_and_range': 'nats; real, can be negative (probe iid_gaussian T=256 min -0.036); symmetric; NaN when T <= 4 + 2W (JIDT exception caught), not observed for MI on the audit datasets because W <= ~T/3',
    'direction_convention': 'Undirected: A[i, j] = A[j, i] = KSG1 MI of (x_min, x_max) with window W_min,max (window matrix is symmetric, infotheory.py:208-211); mirrored from the upper triangle',
    'symmetry_expected': 'sym',
    'already_documented': 'no',
    'new_finding_candidates': [
        "CANDIDATE (pack hypothesis confirmed): window = int(2·dot(acf_i, acf_j)) = int(Bartlett + 1); probe p3 shows raw2dot − (1 + 2Σ_{k>=1}) = 1.00 for every pair, e.g. iid_gaussian T=256 W = 2 where Bartlett gives 1.04; gauss_ar1_pair T=1024 W = 5 vs 4.14. The pair value is computed once per Data object and cached (infotheory.py:197-212), not recomputed per pair.",
        "CANDIDATE: W scales with T for oscillatory, trending or slowly varying inputs because the inner product runs over all T lags: narrowband_f0-0.1 W = 22/85/339/1353 (T=64..4096), logistic_maps 14/39/208/665, trending without detrend 1403 at T=4096 (2 with detrend), cointegrated 1277 at T=4096, shared_envelope 1084 at T=4096 (probe p3). A Theiler window of ~T/3 removes about 2/3 of candidate neighbours for every point.",
        "CANDIDATE: on these inputs DCE increases the estimate markedly instead of only removing a small bias: narrowband_f0-0.1 T=256 pair (0,1) 1.448 -> 2.239; narrowband_f0-0.25 T=64 min over pairs 0.329 -> 1.227; logistic_maps T=64 0.186 -> 0.720 (probes p5, p13).",
        C_THREADS, C_JITTER, C_NEG,
    ],
    'proposed_checks': mi_checks(True),
})

# ================================================================= TLMI
TL_DOC = ("supplement §1.4.4, p.10 (pack lines 477-485): 'Keywords: undirected, nonlinear, unsigned, bivariate, time-dependent. Time-lagged mutual information [35] is an undirected "
          "measure of the dependence between time series x and a time-lagged instance of the series y. We include statistics for only lag-one mutual information'. "
          "GitBook information-theory.md:235-251: keywords 'directed', 'Time-lagged mutual information is a directed measure ...', lists tlmi_kraskov_NN-4 and tlmi_kraskov_NN-4_DCE. "
          "[35] = Schreiber 2000. Estimator text as in supplement §1.4, p.9.")
TL_REF = ("Lagged (time-delayed) mutual information I(X_t; Y_{t+τ}), as discussed by Schreiber 2000, Phys. Rev. Lett. 85, 461 (supplement [35]) as the conventional predecessor of transfer entropy; "
          "estimator Kraskov, Stögbauer & Grassberger 2004, Phys. Rev. E 69, 066138, algorithm 1.")
TL_DEF = ("τ = 1: I(X_t; Y_{t+1}) = ∫∫ p(x_t, y_{t+1}) log[p(x_t, y_{t+1}) / (p(x_t) p(y_{t+1}))], estimated by KSG1 on the N = T − 1 pairs (x_t, y_{t+1}), t = 1..T−1; "
          "not symmetric in (X, Y).")


def tl_checks(dce):
    W = ' with |dt| <= W_ij exclusion (W from the unshifted series)' if dce else ''
    return [
        {'datasets': ['delayed_noise', 'var2_bivariate', 'gauss_ar1_pair', 'bivariate_gaussian', 'iid_gaussian'], 'path': 'kernel',
         'reference': ksg_mi_ref() + ' applied to (x_i[:-1], x_j[1:])' + W,
         'reference_kind': 'independent-impl', 'criterion': 'tolerance',
         'expected_outcome': 'agreement to <= 1e-12 on every ordered pair (prototype probe p5 T=256: identical to 12 printed decimals)'},
        {'datasets': ['delayed_noise', 'var2_bivariate', 'gauss_ar1_pair', 'logistic_maps'], 'path': 'pipeline',
         'reference': 'known coupling direction: delayed_noise x0 leads x1, x2, x3 by 1, 3, 5 samples; var2_bivariate x0 -> x1; gauss_ar1_pair A=[[0.5,0.3],[0.2,0.5]] (both directions, stronger 1->0 at lag 1); logistic_maps y (index 1) -> x (index 0)',
         'reference_kind': 'analytic', 'criterion': 'direction',
         'expected_outcome': 'A[i, j] = I(x_i(t); x_j(t+1)), i.e. row = earlier (source) channel: A[0,1] >> A[1,0] on delayed_noise (probe p5 T=256: 2.168 vs 0.048' + (' non-DCE' if dce else '') + '), A[0,1] > A[1,0] on var2_bivariate (0.236 vs -0.020), A[1,0] > A[0,1] on gauss_ar1_pair (analytic 0.1738 vs 0.1266)'},
        {'datasets': ['gauss_ar1_pair', 'delayed_noise'], 'path': 'pipeline',
         'reference': 'analytic Gaussian lagged MI −½ log(1 − ρ_ij(1)²) with ρ_ij(1) = corr(x_i(t), x_j(t+1)) from the AR(1) truth (Cov(X_{t+1}, X_t) = A Σ_X): gauss_ar1_pair 0->1 0.1266, 1->0 0.1738; delayed_noise 0->1 ½ log(1 + 1/0.01) = 2.3076',
         'reference_kind': 'analytic', 'criterion': 'statistical',
         'expected_outcome': 'convergence towards the analytic values with T; KSG underestimates large MI at small T (probe delayed_noise T=256: 2.168 vs 2.308)' + ('; compare the DCE and non-DCE errors' if dce else '')},
        {'datasets': ['iid_gaussian'], 'path': 'pipeline', 'reference': 'analytic null 0 for independent white processes',
         'reference_kind': 'analytic', 'criterion': 'statistical',
         'expected_outcome': 'values centred near 0, negative values present (probe T=64 min ' + ('-0.054' if dce else '-0.143') + ')'},
        {'datasets': ['delayed_noise', 'iid_gaussian'], 'path': 'pipeline',
         'reference': 'asymmetry by construction: A != A.T; A(x) equals A(reversed time).T only approximately',
         'reference_kind': 'analytic', 'criterion': 'qualitative',
         'expected_outcome': 'A is asymmetric (directed SPI, no mirror); confirms that the supplement keyword "undirected" does not describe the output'},
    ] + ([{'datasets': ['narrowband_f0-0.1', 'logistic_maps', 'shared_envelope'], 'path': 'pipeline',
           'reference': 'window rule as in infotheory.theiler_window; JIDT guard N = T−1 <= 4 + 2W raises',
           'reference_kind': 'analytic', 'criterion': 'qualitative',
           'expected_outcome': 'W ≈ T/3 on narrowband inputs, values rise strongly with DCE (probe p13 T=64 narrowband_f0-0.25 min 0.344 -> 1.208); no NaN at the audit sizes'}] if dce else [])


TL_IMPL = ("Each channel optionally detrended, then z-scored. bivariate(i, j): src = x_i[:-1], targ = x_j[1:] (pyspi slices the arrays itself; JIDT TIME_DIFF stays 0), "
           "then the KSG1 MI exactly as infotheory.mi.kraskov on N = T − 1 pairs: re-standardisation, 1e-8 jitter (seed 42), k = 4, max-norm, ψ(4) − ⟨ψ(n_x+1)+ψ(n_y+1)⟩ + ψ(T−1). "
           "Directed: all ordered pairs computed, no mirror.")
TL_TRACE_PY = ["pyspi/config.yaml:516-536 TimeLaggedMutualInfo configs (kraskov prop_k 4; kraskov prop_k 4 dyn_corr_excl AUTO)"] + T_PRE + [T_DIRECTED] + T_INIT

mk('infotheory.tlmi.kraskov', {
    'metric_name_standard': 'lag-1 time-lagged mutual information I(X_t; Y_{t+1}) in nats, KSG1 estimator, k = 4',
    'canonical_ref': TL_REF,
    'canonical_definition': TL_DEF,
    'documented_definition': TL_DOC,
    'delegate_lib': DELEGATE_MI,
    'implemented_as': TL_IMPL,
    'implementation_trace': TL_TRACE_PY + [
        "pyspi/statistics/infotheory.py:286-299 TimeLaggedMutualInfo(JIDTBase, Directed): labels ['unsigned','infotheory','temporal','directed'], calculator MutualInfoCalculatorMultiVariateKraskov1",
        "pyspi/statistics/infotheory.py:301-317 TimeLaggedMutualInfo.bivariate: _set_theiler_window (no-op without DCE), initialise(1, 1), src, targ = data.to_numpy(squeeze=True)[[i, j]]; src = src[:-1]; targ = targ[1:]; setObservations(src, targ); computeAverageLocalOfObservations; bare except -> NaN",
    ] + T_MI_COMMON,
    'deviation_from_documented': ("Supplement §1.4.4 calls tlmi 'undirected' (keyword list and text); the code labels it 'directed', computes every ordered pair without mirroring, and the "
                                  "value is asymmetric (probe p5 delayed_noise T=256: A[0,1] 2.168 vs A[1,0] 0.048). The GitBook says 'directed'. Documented 'dependence between time series x and a "
                                  "time-lagged instance of the series y': implemented as I(x_i(t); x_j(t+1)), i.e. y = column channel is advanced by one sample. Other undocumented details as for "
                                  "infotheory.mi.kraskov (jitter, seed, nats, negative values, version)."),
    'deviation_from_canonical': ("Matches lag-1 KSG1 lagged MI (from-scratch KSG1 on (x_i[:-1], x_j[1:]) reproduces pyspi to 12 decimals, probe p5). Autocorrelated samples are treated as i.i.d. "
                                 "Lagged MI is not a measure of directed transfer in the TE sense (shared history inflates it), which is a property of the quantity, not a deviation."),
    'units_and_range': 'nats; real, can be negative (probe iid_gaussian T=64 min -0.143); asymmetric; NaN only if JIDT raises (T−1 <= 4)',
    'direction_convention': 'A[i, j] = I(x_i(t); x_j(t+1)): row i is the earlier (source) channel, column j the later one (infotheory.py:306-308; probe p5 delayed_noise, x0 leads x1 by 1: A[0,1] = 2.168, A[1,0] = 0.048). To be confirmed empirically in the check stage.',
    'symmetry_expected': 'asym',
    'already_documented': ALREADY_M8_TLMI,
    'new_finding_candidates': [
        "CANDIDATE (pack hypothesis confirmed): lag convention src = x_i[:-1], targ = x_j[1:] gives I(X_t; Y_{t+1}) with X = row channel; from-scratch KSG1 on those slices matches pyspi on 10 ordered pairs (probe p5, e.g. var2_bivariate (0,1) 0.236189889797 both).",
        "CANDIDATE (documentation): supplement §1.4.4 labels tlmi 'undirected' while the code/GitBook label it 'directed' and the output is asymmetric (REVIEW M8 already notes the asymmetry; the supplement/code label conflict is the new part).",
        C_THREADS, C_JITTER, C_NEG,
    ],
    'proposed_checks': tl_checks(False),
})

mk('infotheory.tlmi.kraskov_DCE', {
    'metric_name_standard': 'lag-1 time-lagged mutual information I(X_t; Y_{t+1}) in nats, KSG1 (k=4) with Theiler window W_ij',
    'canonical_ref': TL_REF + " Theiler window: Theiler 1986, Phys. Rev. A 34, 2427.",
    'canonical_definition': TL_DEF + " With a Theiler window W, pairs with |t − t'| <= W are excluded from neighbour searches and counts.",
    'documented_definition': TL_DOC + " DCE text: supplement §1.4, p.9-10 ('we set the window as the product of the autocorrelation functions of both time series (a heuristic for the autocorrelation time based on Bartlett's formula [10, 37])').",
    'delegate_lib': DELEGATE_MI,
    'implemented_as': TL_IMPL + " Before each pair DYN_CORR_EXCL = int(2·Σ_{k=0}^{T−1} r_i(k) r_j(k)) computed on the unshifted, preprocessed series (shared cache data.theiler); JIDT excludes |t − t'| <= W; raises (-> NaN) if T − 1 <= 4 + 2W.",
    'implementation_trace': TL_TRACE_PY + T_THEILER + [
        "pyspi/statistics/infotheory.py:301-317 TimeLaggedMutualInfo.bivariate: _set_theiler_window(data, i, j) (:303) then the lag-1 slices and KSG1 MI",
    ] + T_MI_COMMON,
    'deviation_from_documented': ("As infotheory.tlmi.kraskov (documented 'undirected', implemented directed) plus the window deviations of infotheory.mi.kraskov_DCE: W = int(Bartlett + 1) over all lags, "
                                  "not a product of ACFs, growing ∝ T on oscillatory/trending input. The window is computed from the unshifted series, which is immaterial for a 1-sample lag."),
    'deviation_from_canonical': ("Lag-1 KSG1 with Theiler window as in JIDT (reproduced from scratch, probe p5). ψ(N) not adjusted for the exclusion. Window-size rule is a pyspi heuristic "
                                 "(see infotheory.theiler_window). Values rise strongly where W is large (narrowband_f0-0.25 T=64 min over pairs 0.344 -> 1.208, probe p13)."),
    'units_and_range': 'nats; real, can be negative (iid_gaussian T=64 min -0.054); asymmetric; NaN when T−1 <= 4 + 2W (not reached on the audit datasets)',
    'direction_convention': 'A[i, j] = I(x_i(t); x_j(t+1)) with window W_ij = W_ji: row = earlier/source channel (same code path as infotheory.tlmi.kraskov); to be confirmed in the check stage',
    'symmetry_expected': 'asym',
    'already_documented': ALREADY_M8_TLMI,
    'new_finding_candidates': [
        "CANDIDATE: the Theiler window rule over-estimates Bartlett's autocorrelation time by 1 and grows ∝ T on oscillatory input (see infotheory.theiler_window; probe p3).",
        "CANDIDATE (documentation): supplement §1.4.4 'undirected' vs code 'directed' (as infotheory.tlmi.kraskov).",
        C_THREADS, C_JITTER, C_NEG,
    ],
    'proposed_checks': tl_checks(True),
})

# ================================================================= TE
TE_DOC = ("supplement §1.4.5, p.10-11 (pack lines 486-510): 'Transfer entropy [35] is a measure of information transfer from a source time series x to a target time series y, based on "
          "the Takens time-delay embedding ... The embedding lengths are denoted by modifier's l and k for the source, x, and target, y, respectively; the time delay is denoted lt and kt ... "
          "The fixed parameters are minimal values, i.e., typically with a fixed target embedding length of 1 (denoted by k-1) or 2 (denoted by k-2). The optimized parameters are inferred by "
          "choosing the embedding parameters (up to a maximum embedding length of 10, denoted by k-max-10, and maximum time delay of 2, tau-max-2) that maximize a univariate "
          "information-theoretic measure known as active information storage (see the MAX_CORR_AIS method of [32] for details).' Same text GitBook information-theory.md:206-226 "
          "(also 'tau-max-2'), which lists the five te_kraskov identifiers.")
TE_REF = ("Schreiber 2000, Phys. Rev. Lett. 85, 461, Eq. (4) (supplement [35]); embedding delays and source-target delay u: Wibral et al. 2013, PLoS ONE 8, e55809; "
          "estimator: Frenzel & Pompe 2007, Phys. Rev. Lett. 99, 204101 (KSG-type conditional MI) with Kraskov et al. 2004 algorithm 1; JIDT: Lizier 2014, Front. Robot. AI 1:11 (supplement [32]). "
          "Equation numbers from memory.")
TE_DEF_FIXED = ("T_{X→Y} = I(Y_{t+1}; X_t^{(l,lt)} | Y_t^{(k,kt)}) = E[log p(y_{t+1} | y_t^{(k)}, x_t^{(l)}) / p(y_{t+1} | y_t^{(k)})], with y_t^{(k,kt)} = (y_t, y_{t−kt}, ..., y_{t−(k−1)kt}) and "
                "source embedding ending at t+1−u (u = 1). KSG CMI (algorithm 1): Î = ψ(K) + ⟨ψ(n_z+1) − ψ(n_xz+1) − ψ(n_yz+1)⟩, ε from the K-th neighbour (max-norm) in the joint (x, y, z) space.")
TE_DEF_AUTO = (TE_DEF_FIXED + " Embedding selection (MAX_CORR_AIS, Garland, James & Bradley 2016, Phys. Rev. E 93, 022221, as cited by JIDT): for each series choose (k, τ), k <= k_max, τ <= τ_max, maximising the "
               "(bias-corrected) active information storage A = I(Y_t^{(k,τ)}; Y_{t+1}); target embedding from the target's AIS, source embedding from the source's AIS.")


def te_trace(cfg_line, auto=False, dce=False):
    tr = [cfg_line] + T_PRE + [T_DIRECTED] + T_INIT + (T_THEILER if dce else []) + [
        "pyspi/statistics/infotheory.py:103-134 _getcalc('TransferEntropy') -> infodynamics.measures.continuous.kraskov.TransferEntropyCalculatorKraskov (:127-128), then _setup",
        ("pyspi/statistics/infotheory.py:326-355 TransferEntropy.__init__ with auto_embed_method: setProperty('AUTO_EMBED_METHOD', 'MAX_CORR_AIS'), ('AUTO_EMBED_K_SEARCH_MAX', '10'), ('AUTO_EMBED_TAU_SEARCH_MAX', '4'); identifier += '_k-max-10_tau-max-4'"
         if auto else
         "pyspi/statistics/infotheory.py:326-367 TransferEntropy.__init__ without auto-embedding: setProperty k_HISTORY, k_TAU, l_HISTORY, l_TAU (:358-362); identifier += '_k-{k}_kt-{kt}_l-{l}_lt-{lt}'; DELAY not set (JIDT default 1)"),
        "pyspi/statistics/infotheory.py:376-391 TransferEntropy.bivariate (docstring 'Compute transfer entropy from i->j'): _set_theiler_window, calc.initialise(), src, targ = data.to_numpy(squeeze=True)[[i, j]], setObservations(src, targ), computeAverageLocalOfObservations; exception -> NaN with a warning",
        T_COPY,
    ] + T_CMI + (T_AUTO if auto else []) + [
        "JIDT " + J + "utils/KdTree.java#L751-L753 and utils/UnivariateNearestNeighbourSearcher.java#L497-L530: exclusion of |dt| <= DYN_CORR_EXCL in k-NN search and counts (W=0 excludes only the sample itself)",
    ]
    return tr


def te_checks(k, l, auto, dce):
    emb = f'k={k}, kt=1, l={l}, lt=1, u=1' if not auto else 'the (k, kt, l, lt) chosen by a from-scratch MAX_CORR_AIS search (k <= 10, tau <= 4, tau skipped for k = 1, strict maximum of KSG1 AIS' + (', AIS with the pair window W_ij' if dce else '') + ')'
    ch = [
        {'datasets': ['var2_bivariate', 'gauss_ar1_pair', 'delayed_noise', 'bivariate_gaussian', 'logistic_maps'] + (['narrowband_f0-0.1'] if not auto else []), 'path': 'kernel',
         'reference': ksg_mi_ref('KSG1 conditional MI (Frenzel-Pompe form, ψ(K) + ⟨ψ(n_z+1) − ψ(n_xz+1) − ψ(n_yz+1)⟩)') + ' on the JIDT sample layout (dest past ending at t, dest next t+1, source past ending at t, start = max((k−1)kt, (l−1)lt)), ' + emb + (', exclusion |dt| <= W_ij' if dce else ''),
         'reference_kind': 'independent-impl', 'criterion': 'tolerance',
         'expected_outcome': ('agreement to <= 1e-12 on every ordered pair and identical selected embedding' if auto else 'agreement to <= 1e-12 on every ordered pair') + ' (prototype probe ' + ('p6: var2_bivariate, gauss_ar1_pair, logistic_maps T=256 reproduce both the embedding and the value to 12 decimals' if auto else 'p5 at T=256: identical to 12 printed decimals') + ')'},
        {'datasets': ['delayed_noise', 'var2_bivariate', 'gauss_ar1_pair', 'logistic_maps'], 'path': 'pipeline',
         'reference': 'known coupling: delayed_noise x0 -> x1 (lag 1), x2 (lag 3), x3 (lag 5); var2_bivariate x0 -> x1 only; gauss_ar1_pair analytic Gaussian TE (k=l=1) 1->0 = 0.0524, 0->1 = 0.0271; logistic_maps index 1 (y) -> index 0 (x) only',
         'reference_kind': 'analytic', 'criterion': 'direction',
         'expected_outcome': "A[i, j] = TE(x_i -> x_j): row = source, column = target. Expected A[0,1] > A[1,0] on var2_bivariate and delayed_noise (probe p5 te_k1 T=256: delayed_noise 1.616 vs -0.016; var2 0.134 vs -0.023), A[1,0] > A[0,1] on gauss_ar1_pair and logistic_maps" + ('; with u = 1 and l = 1, delayed_noise pairs with lag 3 or 5 are expected near 0 unless the source embedding reaches the lag' if not auto else '')},
    ]
    if not auto and k == 1 and l == 1:
        ch.append({'datasets': ['gauss_ar1_pair', 'var2_bivariate'], 'path': 'pipeline',
                   'reference': 'analytic Gaussian TE for the same embedding: ½ log(Var(y_{t+1}|y_t) / Var(y_{t+1}|y_t, x_t)) from the stationary autocovariances (gauss_ar1_pair: Σ_X and A Σ_X; var2_bivariate: Gamma0 and Yule-Walker lag-1 covariance from A1, A2, Sigma)',
                   'reference_kind': 'analytic', 'criterion': 'statistical',
                   'expected_outcome': 'convergence towards 0.0524 (1->0) and 0.0271 (0->1) on gauss_ar1_pair as T grows (|Δ| < ~0.02 nats at T=4096); var2_bivariate 1->0 towards 0' + ('; record DCE vs non-DCE error' if dce else '')})
    if not auto and k == 2:
        ch.append({'datasets': ['var2_bivariate', 'gauss_ar1_pair'], 'path': 'pipeline',
                   'reference': 'analytic Gaussian TE with k=2, l=1: ½ log(Var(y_{t+1}|y_t, y_{t−1}) / Var(y_{t+1}|y_t, y_{t−1}, x_t)) from the VAR autocovariances up to lag 2',
                   'reference_kind': 'analytic', 'criterion': 'statistical',
                   'expected_outcome': 'convergence towards the analytic value with T; var2_bivariate 1->0 towards 0'})
    ch.append({'datasets': ['iid_gaussian'], 'path': 'pipeline', 'reference': 'analytic null TE = 0 for independent white processes',
               'reference_kind': 'analytic', 'criterion': 'statistical',
               'expected_outcome': 'values centred near 0 with negative values present (probe p13 T=64 minimum ' + {('auto', False): '-0.046', ('auto', True): '-0.026', ('k2', True): '-0.057', ('k1', True): '-0.104', ('k1', False): '-0.060'}[('auto' if auto else f'k{k}', dce)] + ')'})
    if auto:
        ch.append({'datasets': ['var2_bivariate', 'gauss_ar1_pair', 'narrowband_f0-0.1', 'logistic_maps'], 'path': 'pipeline',
                   'reference': 'read back k_HISTORY, k_TAU, l_HISTORY, l_TAU from the JIDT calculator after each pair and compare with the from-scratch MAX_CORR_AIS choice and with fixed k=1 TE',
                   'reference_kind': 'independent-impl', 'criterion': 'exact',
                   'expected_outcome': 'embedding varies by pair and T (probe p4: var2_bivariate 0->1 T=256 (10,1,1,1), T=1024 (3,1,2,1); narrowband_f0-0.1 DCE T=256 (10,4,10,4)); equals (1,1,1,1) on cml7 (documented)'})
        ch.append({'datasets': ['var2_bivariate'], 'path': 'pipeline',
                   'reference': 'CalculatorFrame (deepcopy) vs Calculator on the same data and config',
                   'reference_kind': 'analytic', 'criterion': 'exact',
                   'expected_outcome': 'differs: CalculatorFrame returns the fixed k=1 TE (probe p10 A[0,1] 0.133643 vs Calculator 0.060599); documents the copy bug'})
    if not auto and k == 2:
        ch.append({'datasets': ['var2_bivariate'], 'path': 'pipeline',
                   'reference': 'CalculatorFrame (deepcopy) vs Calculator on the same data and config',
                   'reference_kind': 'analytic', 'criterion': 'exact',
                   'expected_outcome': 'differs: CalculatorFrame computes k=1 with DCE (probe p10 A[0,1] 0.134372 vs Calculator 0.159244)'})
    if dce:
        ch.append({'datasets': ['narrowband_f0-0.1', 'narrowband_f0-0.25', 'logistic_maps', 'shared_envelope'], 'path': 'pipeline',
                   'reference': 'analytic guard: JIDT raises when N <= 4 + 2W; for auto-embedding the AIS candidate k=10, tau=4 has N = T − 37',
                   'reference_kind': 'analytic', 'criterion': 'qualitative',
                   'expected_outcome': ('NaN entries at T=64 where W >= (T−41)/2 = 12: probe p13 te_auto_DCE NaN 6/6 narrowband (all three), 2/2 logistic_maps, 6/12 shared_envelope; no NaN at T=256' if auto else
                                        'no NaN at audit sizes (N = T−' + str(k) + ' > 4 + 2W since W ≈ T/3 at most); values change strongly with W (probe p13 narrowband_f0-0.1 T=64 min over pairs te_k1 0.218 vs te_k1_DCE 0.295, te_k2_DCE 0.013)')})
    return ch


TE_COMMON_CANDS = [C_THREADS, C_JITTER, C_NEG, C_BIAS]

# auto, no DCE
mk('infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4', {
    'metric_name_standard': 'transfer entropy T_{X→Y} in nats, KSG1 conditional-MI estimator (k=4 neighbours), target and source embeddings (k, kt), (l, lt) selected per pair by maximum KSG active information storage (k <= 10, tau <= 4), source-target delay u = 1',
    'canonical_ref': TE_REF + " Embedding selection: Garland, James & Bradley 2016, Phys. Rev. E 93, 022221 (cited by JIDT for MAX_CORR_AIS).",
    'canonical_definition': TE_DEF_AUTO,
    'documented_definition': TE_DOC,
    'delegate_lib': DELEGATE_TE,
    'implemented_as': ("For each ordered pair (i, j), with src = x_i, targ = x_j (z-scored): JIDT searches k_candidate = 1..10, tau = 1..4 (tau only 1 for k = 1) maximising the KSG1 AIS "
                       "I(y_t^{(k,tau)}; y_{t+1}) of the target (no extra bias correction for KSG), then the same for the source to set (l, lt); then computes the KSG1 conditional MI "
                       "I(x_t^{(l,lt)}; y_{t+1} | y_t^{(k,kt)}) with u = 1 on N = T − 1 − max((k−1)kt, (l−1)lt) samples, each embedding column standardised, 1e-8 jitter (seed 42), "
                       "max-norm, ψ(4) + ⟨ψ(n_z+1) − ψ(n_xz+1) − ψ(n_yz+1)⟩, nats. Embedding search repeated for every ordered pair. No Theiler window."),
    'implementation_trace': te_trace("pyspi/config.yaml:550-556 TransferEntropy config: estimator kraskov, prop_k 4, auto_embed_method MAX_CORR_AIS, k_search_max 10, tau_search_max 4 (the comment at :551 says 'and DCE' but this entry has no dyn_corr_excl)", auto=True),
    'deviation_from_documented': ("(1) Maximum embedding delay: documented 'maximum time delay of 2, tau-max-2' (supplement §1.4.5, GitBook :216); implemented tau_search_max = 4 (config.yaml:556, identifier 'tau-max-4'). "
                                  "(2) The documentation says the parameters maximise AIS; the code does this for target and source separately (both from their own AIS), which the text implies only for the "
                                  "target. (3) Values can be negative though labelled 'unsigned'; nats; jitter/seed undocumented; JIDT version as in infotheory.est.ksg1. "
                                  "(4) config.yaml:551 comment mentions DCE for this non-DCE entry."),
    'deviation_from_canonical': ("Schreiber TE with KSG1 CMI as implemented in JIDT; a from-scratch KSG1 CMI + MAX_CORR_AIS search reproduces the chosen embedding and the value to 12 decimals on "
                                 "var2_bivariate, gauss_ar1_pair and logistic_maps (T=256, probe p6). The AIS-maximisation criterion (Garland et al. 2016) differs from Ragwitz's prediction-error criterion "
                                 "and from selecting the source embedding to maximise TE (JIDT's MAX_CORR_AIS_AND_TE); AIS values for different (k, tau) use different N and are compared without bias "
                                 "correction, so the choice can drift to large k (var2_bivariate T=256 target k=10). Only u = 1 is considered."),
    'units_and_range': 'nats; real, can be negative (probe p13 T=64 min -0.095); asymmetric; NaN when JIDT raises (caught per pair)',
    'direction_convention': 'A[i, j] = TE(x_i -> x_j): row = source, column = target (infotheory.py:383-388, bivariate docstring "from i->j"; probe p4 var2_bivariate T=1024: A[0,1] 0.132, A[1,0] 0.015, truth x0 -> x1). To be confirmed in the check stage.',
    'symmetry_expected': 'asym',
    'already_documented': ALREADY_CML7,
    'new_finding_candidates': [
        C_COPY,
        "CANDIDATE (pack hypothesis confirmed beyond cml7): the embedding is selected per ordered pair and differs between pairs and T; probe p4: var2_bivariate 0->1 (k,kt,l,lt) = (3,3,1,1) at T=64, (10,1,1,1) at T=256, (3,1,2,1) at T=1024; gauss_ar1_pair 1->0 (2,4,1,1)/(2,3,5,1)/(2,4,2,3). Equal to fixed k=1 on cml7 (documented).",
        "CANDIDATE (documentation): tau_search_max = 4 in config and identifier, documented as tau-max-2 in the supplement and GitBook.",
        "CANDIDATE (efficiency, correctness-neutral): without DCE the AIS search for a channel's embedding does not depend on the partner, yet it is repeated for each of the P−1 pairs where the channel is target and P−1 where it is source (TransferEntropyCalculatorViaCondMutualInfo.java:779-797 runs on every setObservations).",
    ] + TE_COMMON_CANDS,
    'proposed_checks': te_checks(None, None, True, False),
})

mk('infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4', {
    'metric_name_standard': 'transfer entropy T_{X→Y} in nats, KSG1 conditional MI (k=4) with Theiler window W_ij, embeddings selected per pair by maximum KSG AIS (k <= 10, tau <= 4) computed with the same window, u = 1',
    'canonical_ref': TE_REF + " Embedding selection: Garland, James & Bradley 2016, Phys. Rev. E 93, 022221. Theiler window: Theiler 1986, Phys. Rev. A 34, 2427.",
    'canonical_definition': TE_DEF_AUTO + " Theiler window: neighbours with |t − t'| <= W excluded.",
    'documented_definition': TE_DOC + " DCE: supplement §1.4, p.9-10 (window = 'the product of the autocorrelation functions of both time series').",
    'delegate_lib': DELEGATE_TE,
    'implemented_as': ("As infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4, plus DYN_CORR_EXCL = int(2·Σ_k r_i(k) r_j(k)) set before each pair. The property is forwarded to the CMI "
                       "calculator and, through the stored props, to the AIS calculator, so the target and source embeddings are also selected with the pair's window and can differ between pairs. "
                       "If any AIS candidate has N <= 4 + 2W (the k=10, tau=4 candidate has N = T − 37) JIDT throws, the whole search aborts and pyspi returns NaN for the pair."),
    'implementation_trace': te_trace("pyspi/config.yaml:558-563 TransferEntropy config: kraskov, prop_k 4, MAX_CORR_AIS, k_search_max 10, tau_search_max 4, dyn_corr_excl AUTO", auto=True, dce=True),
    'deviation_from_documented': ("(1) tau-max documented as 2, implemented 4. (2) Window rule as in infotheory.theiler_window (int(Bartlett + 1), all lags, ∝ T on oscillatory input). "
                                  "(3) Undocumented: the window also changes the embedding search, and short or oscillatory series give NaN (probe p13 T=64: narrowband 6/6, logistic_maps 2/2, shared_envelope 6/12 pairs NaN). "
                                  "(4) Negative values despite 'unsigned'."),
    'deviation_from_canonical': ("KSG1 TE with Theiler window and AIS-based embedding as in JIDT (from-scratch reproduction of embedding and value with the window, probe p6 gauss_ar1_pair 1->0 (1,1,2,2) 0.061885014901, "
                                 "logistic_maps (1,1,9,4) 0.049012628767). Canonical choice of embedding does not depend on the partner series; here it does via W. ψ(N) unadjusted for exclusion."),
    'units_and_range': 'nats; real, can be negative (probe p13 T=64 min -0.178 cointegrated); asymmetric; NaN for pairs where the AIS search hits N <= 4 + 2W',
    'direction_convention': 'A[i, j] = TE(x_i -> x_j): row = source, column = target (same code path as the non-DCE unit; probe p4 var2_bivariate T=1024 A[0,1] 0.132 vs A[1,0] 0.015). To be confirmed in the check stage.',
    'symmetry_expected': 'asym',
    'already_documented': ALREADY_CML7,
    'new_finding_candidates': [
        C_COPY,
        "CANDIDATE: NaN for short or oscillatory series because the AIS candidate (k=10, tau=4) leaves N = T − 37 samples and JIDT requires N > 4 + 2W; one failing candidate aborts the search (ActiveInfoStorageCalculatorViaMutualInfo.java:609-612). Probe p13 T=64: narrowband_f0-0.1/0.25/0.4 6/6 pairs NaN, logistic_maps 2/2, shared_envelope 6/12; probe p4 shows the stale embedding (1,1,1,1) reported after the failure.",
        "CANDIDATE: the Theiler window is forwarded to the AIS embedding search (TransferEntropyCalculatorViaCondMutualInfo.java:752-754 copies props), so the embedding depends on the partner channel: gauss_ar1_pair T=256 1->0 embedding (2,3,5,1) without and (1,1,2,2) with DCE (probe p4/p6); narrowband_f0-0.1 T=256 jumps to (10,4,10,4) for every pair with W=85.",
        "CANDIDATE (documentation): tau-max-2 documented, 4 implemented.",
    ] + TE_COMMON_CANDS,
    'proposed_checks': te_checks(None, None, True, True),
})


def te_fixed_unit(uid, k, dce, cfg):
    name = f'transfer entropy T_{{X→Y}} in nats, KSG1 conditional MI (k=4 neighbours), fixed embedding k={k}, kt=1, l=1, lt=1, u=1' + (', Theiler window W_ij' if dce else '')
    impl = (f"For each ordered pair (i, j), src = x_i, targ = x_j (z-scored): KSG1 conditional MI I(x_t; y_{{t+1}} | " + ('y_t' if k == 1 else 'y_t, y_{t−1}') + f") on N = T − {k} samples "
            "(JIDT start time max((k−1)kt, (l−1)lt) = " + str(k - 1) + "), each embedding column standardised (ddof=1), 1e-8 jitter (seed 42), max-norm, ψ(4) + ⟨ψ(n_z+1) − ψ(n_xz+1) − ψ(n_yz+1)⟩, nats."
            + (" Before each pair DYN_CORR_EXCL = int(2·Σ_k r_i(k) r_j(k)) (shared cache data.theiler); points with |t − t'| <= W excluded; raises (-> NaN) if N <= 4 + 2W." if dce else " No Theiler window."))
    dev_doc = ("Matches the documented fixed minimal embedding (k-" + str(k) + ", l-1, delays 1). "
               + ("The config.yaml:565 comment calls this entry 'auto-embedding on target-only', but no auto-embedding is configured (fixed k=2). " if k == 2 else "")
               + ("Window rule deviates as described in infotheory.theiler_window (int(Bartlett + 1), all lags, ∝ T on oscillatory input). " if dce else "")
               + "Undocumented: nats, 1e-8 jitter with seed 42, negative values despite 'unsigned', source-target delay fixed at u = 1, JIDT version (post-1.6.1 build).")
    dev_can = ("Schreiber TE with finite embedding estimated by KSG1 CMI (Frenzel-Pompe form); a from-scratch implementation reproduces pyspi to 12 decimals (probe p5, T=256, five datasets"
               + (", W up to 85" if dce else "") + "). Finite k=" + str(k) + " history: for processes with longer memory (var2_bivariate is order 2) the quantity is the TE for this embedding, not the full-history TE. "
               + ("ψ(N) unadjusted for the exclusion window." if dce else "Autocorrelated samples treated as i.i.d. neighbours."))
    cands = [C_COPY] if k == 2 else [
        "CANDIDATE (scope note): fixed-embedding TE units keep their settings under deepcopy only by coincidence when k=l=1 (the rebuilt calculator defaults to k_HISTORY=1, l_HISTORY=1, probe p10: te_k1 identical in Calculator and CalculatorFrame); the copy bug in infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4 therefore does not change this unit."]
    if dce:
        cands.append("CANDIDATE: on oscillatory inputs the window is ≈ T/3 (see infotheory.theiler_window) and changes the estimate: k=1 narrowband_f0-0.1 T=64 minimum over pairs 0.218 without vs 0.295 with DCE (probe p13). (The much lower k=2 values on the same data, 0.013, reflect the two-sample target history predicting a sinusoid, not the window.)")
    mk(uid, {
        'metric_name_standard': name,
        'canonical_ref': TE_REF + (" Theiler window: Theiler 1986, Phys. Rev. A 34, 2427." if dce else ""),
        'canonical_definition': TE_DEF_FIXED + f" Here k={k}, kt=1, l=1, lt=1, u=1" + (", neighbours with |t − t'| <= W excluded." if dce else "."),
        'documented_definition': TE_DOC + (" DCE: supplement §1.4, p.9-10 (window = 'the product of the autocorrelation functions of both time series')." if dce else ""),
        'delegate_lib': DELEGATE_TE,
        'implemented_as': impl,
        'implementation_trace': te_trace(cfg, auto=False, dce=dce),
        'deviation_from_documented': dev_doc,
        'deviation_from_canonical': dev_can,
        'units_and_range': 'nats; real, can be negative (probe p13 T=64 minimum ' + {(2, True): '-0.096', (1, True): '-0.114', (1, False): '-0.134'}[(k, dce)] + ' on logistic_maps); asymmetric; NaN only when JIDT raises (N <= 4 + 2W)',
        'direction_convention': 'A[i, j] = TE(x_i -> x_j): row = source, column = target (infotheory.py:383-388; probe p5 T=256 delayed_noise, x0 leads x1 by 1: ' + {(2, True): 'A[0,1] 1.194 vs A[1,0] -0.030', (1, True): 'te_k1 A[0,1] 1.616 vs A[1,0] -0.016 (non-DCE path, same code)', (1, False): 'A[0,1] 1.616 vs A[1,0] -0.016'}[(k, dce)] + '). To be confirmed in the check stage.',
        'symmetry_expected': 'asym',
        'already_documented': 'no',
        'new_finding_candidates': cands + TE_COMMON_CANDS,
        'proposed_checks': te_checks(k, 1, False, dce),
    })


te_fixed_unit('infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1', 2, True, "pyspi/config.yaml:565-570 TransferEntropy config: kraskov, prop_k 4, k_history 2, l_history 1, dyn_corr_excl AUTO (comment :565 says 'auto-embedding on target-only', which this entry does not configure)")
te_fixed_unit('infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1', 1, True, "pyspi/config.yaml:572-577 TransferEntropy config: kraskov, prop_k 4, k_history 1, l_history 1, dyn_corr_excl AUTO")
te_fixed_unit('infotheory.te.kraskov_k-1_kt-1_l-1_lt-1', 1, False, "pyspi/config.yaml:579-583 TransferEntropy config: kraskov, prop_k 4, k_history 1, l_history 1 (no DCE)")

# ================================================================= infrastructure: KSG1
mk('infotheory.est.ksg1', {
    'metric_name_standard': 'Kraskov-Stögbauer-Grassberger nearest-neighbour estimator, algorithm 1, for mutual information and (Frenzel-Pompe form) conditional mutual information, as used by all mi/tlmi/te kraskov SPIs',
    'canonical_ref': "Kraskov, Stögbauer & Grassberger 2004, Phys. Rev. E 69, 066138 (algorithm 1); Frenzel & Pompe 2007, Phys. Rev. Lett. 99, 204101 (conditional MI); Lizier 2014, Front. Robot. AI 1:11 (JIDT, supplement [32]).",
    'canonical_definition': "MI: ψ(k) − ⟨ψ(n_x+1) + ψ(n_y+1)⟩ + ψ(N); CMI: ψ(k) − ⟨ψ(n_xz+1) + ψ(n_yz+1) − ψ(n_z+1)⟩; ε(i) = max-norm distance to the k-th neighbour in the joint space, marginal counts strictly within ε(i), j ≠ i; optional Theiler window excluding |t_j − t_i| <= W.",
    'documented_definition': "supplement §1.4, p.9 (pack lines 414-453): 'The Kraskov–Stögbauer-Grassberger (KSG) technique (ksg) combines nearest-neighbor estimators for mutual information based measures (default of four nearest neighbors, indicated by modifier NN-4). The KSG estimator is effectively a combination of multiple Kozachenko estimators that includes techniques to remove a bias ...'; 'We primarily use v1.5 of the Java Information Dynamics Toolkit [32]'. GitBook information-theory.md:11-16 (v1.6.1, same KSG text).",
    'delegate_lib': "JIDT jar pyspi/lib/jidt/infodynamics.jar (labelled 1.6.1; classes contain NOISE_SEED, matching master a9b6b3e of 2024-04-20 rather than the v1.6.1 tag of 2023-08-22): MutualInfoCalculatorMultiVariateKraskov1 and ConditionalMutualInfoCalculatorMultiVariateKraskov1 (via TransferEntropyCalculatorKraskov), jpype 1.7.1, OpenJDK 21.0.12",
    'implemented_as': ("Properties as probed on all nine SPIs (probe p1): k = 4, NORM_TYPE = MAX_NORM, NORMALISE = true (per-column z-score, std divisor N−1), NOISE_LEVEL_TO_ADD = 1e-8 "
                       "(added after normalisation, row by row source/dest[/cond] from java.util.Random(42)), NOISE_SEED = 42, NUM_THREADS = 64 (= availableProcessors), ALG_NUM = 1 for TE, "
                       "DYN_CORR_EXCL = 0 unless the DCE heuristic sets it, BIAS_CORRECTION unrecognised (None). Average = ψ(k) − ⟨digammas⟩ + ψ(N) (MI) or ψ(k) + ⟨digammas⟩ (CMI) over all N samples; "
                       "time points split across threads and the partial sums added; results in nats. JIDT exceptions (e.g. N <= k + 2W) are caught by pyspi and return NaN."),
    'implementation_trace': T_INIT + [
        "pyspi/statistics/infotheory.py:103-134 JIDTBase._getcalc: kraskov -> MutualInfoCalculatorMultiVariateKraskov1 (:116-119) or TransferEntropyCalculatorKraskov (:127-128)",
        "pyspi/utils.py:112-125 is_jpype_jvm_available: starts the JVM with -Djava.class.path=pyspi/lib/jidt/infodynamics.jar",
        "pyspi/lib/jidt/version-1.6.1.txt:8-10 'Version 1.6.1  22/08/2023' (label); jar META-INF entries dated 2024-04-21",
    ] + T_MI_COMMON + T_CMI[7:] + [
        "JIDT v1.6.1 tag for comparison: " + J161 + "measures/continuous/MutualInfoMultiVariateCommon.java#L519-L529 'Random random = new Random();' without seed; setProperty :201-229 lacks NOISE_SEED (the jar has it)",
    ],
    'deviation_from_documented': ("Estimator matches 'KSG, NN-4'. Version: documented v1.5 (supplement) / v1.6.1 (GitBook); the jar is a post-1.6.1 master build. Undocumented: max-norm, 1e-8 jitter with seed 42, "
                                  "no bias correction (pyspi's BIAS_CORRECTION=false is a no-op), multi-threading over all cores, nats."),
    'deviation_from_canonical': ("Algorithm 1 exactly as published (from-scratch brute-force MI/CMI reproduce pyspi to <= 3e-15 for MI and 12 decimals for CMI on five datasets, probes p5-p7, including "
                                 "the jitter regenerated with a Python java.util.Random). Additions: standardisation, 1e-8 jitter (tie-breaking; changes values on tied data), ψ(N) not adjusted when a Theiler window is used."),
    'units_and_range': 'nats; real-valued and can be negative (finite-sample bias); invariant to per-variable affine transforms up to the jitter scale',
    'direction_convention': 'n/a (estimator); MI symmetric in its two arguments up to the jitter assignment (probe p2 exact equality), CMI asymmetric only through which variable is conditioned',
    'symmetry_expected': 'n/a',
    'already_documented': 'no',
    'new_finding_candidates': [C_JAR, C_THREADS, C_JITTER, C_BIAS, C_NEG],
    'proposed_checks': [
        {'datasets': ['bivariate_gaussian', 'nonlinear_dependence', 'delayed_noise', 'var2_bivariate', 'gauss_ar1_pair', 'logistic_maps'], 'path': 'kernel',
         'reference': ksg_mi_ref('KSG1 MI and CMI') + '; for CMI the Frenzel-Pompe counts n_xz, n_yz, n_z',
         'reference_kind': 'independent-impl', 'criterion': 'tolerance',
         'expected_outcome': '<= 1e-12 absolute on MI and CMI for W in {0, 2, 5, 85}, including logistic_maps where the jitter matters (prototype: AIS on the period-4 series matched JIDT to 4e-15, probe p7)'},
        {'datasets': ['bivariate_gaussian'], 'path': 'kernel',
         'reference': 'analytic Gaussian MI −½ log(1 − ρ²) (truth true_mi_nats)',
         'reference_kind': 'analytic', 'criterion': 'statistical',
         'expected_outcome': 'bias and variance of the estimator vs T in {64, 256, 1024, 4096}; |Î − I| decreasing with T'},
        {'datasets': ['bivariate_gaussian', 'logistic_maps'], 'path': 'kernel',
         'reference': 'self-consistency under NUM_THREADS = 1 and NOISE_SEED in {42, 43, 44} (no external reference)',
         'reference_kind': 'analytic', 'criterion': 'tolerance',
         'expected_outcome': 'thread count changes values by <= 1e-13; seed changes continuous-data values by 0 and tied-data values by up to ~0.05 nats (probe p12)'},
        {'datasets': ['bivariate_gaussian'], 'path': 'kernel',
         'reference': 'sklearn.feature_selection.mutual_info_regression(n_neighbors=4) (independent KSG implementation)',
         'reference_kind': 'external-pkg', 'criterion': 'tolerance',
         'expected_outcome': '|Δ| < 0.01 nats where both are positive (sklearn clips at 0 and uses its own noise)'},
    ],
})

# ================================================================= infrastructure: Theiler window
mk('infotheory.theiler_window', {
    'metric_name_standard': "Theiler window (dynamic correlation exclusion) size chosen from the autocorrelation time of the pair via Bartlett's formula",
    'canonical_ref': ("Theiler 1986, Phys. Rev. A 34, 2427 (window, supplement [36]); Bartlett 1946, J. R. Stat. Soc. Suppl. 8, 27 (supplement [37]) for the variance of the sample cross-correlation of two "
                      "autocorrelated series, Var(r_xy) ≈ (1/T) Σ_{k=−∞}^{∞} ρ_x(k) ρ_y(k); the effective-sample-size form T_eff = T / (1 + 2 Σ_{k>=1} ρ_x(k) ρ_y(k)) as used by Cliff et al. 2021, Phys. Rev. Research 3, 013145 (supplement [10]). Forms from memory; see Open questions."),
    'canonical_definition': ("Autocorrelation time of the pair τ = Σ_{k=−∞}^{∞} ρ_x(k) ρ_y(k) = 1 + 2 Σ_{k>=1} ρ_x(k) ρ_y(k) (population ACFs; in practice the sum is truncated at a lag where the "
                             "sample ACF is no longer distinguishable from 0); Theiler window W of about τ samples, excluding neighbours with |t − t'| <= W."),
    'documented_definition': "supplement §1.4, p.9-10 (pack lines 414-453): 'The window size should be large enough to render observations included in the density estimate uncorrelated (sometimes called the \"autocorrelation time\" [36]); here, we set the window as the product of the autocorrelation functions of both time series (a heuristic for the autocorrelation time based on Bartlett's formula [10, 37]). The DCE modifier indicates that the Theiler window is used for the KSG estimator.' GitBook information-theory.md:20 same text.",
    'delegate_lib': 'pyspi (numpy 2.5.4 np.correlate / np.dot, scipy 1.17.1 scipy.stats.zscore); consumed by JIDT DYN_CORR_EXCL',
    'implemented_as': ("On the first DCE call for a Data object: for every pair _i < _j, W[_i,_j] = W[_j,_i] = 2 · Σ_{k=0}^{T−1} r_i(k) r_j(k), with r the biased sample ACF of the z-scored "
                       "(ddof=0) preprocessed series over all lags 0..T−1 (np.correlate 'full', normalised by lag 0); cached as data.theiler and shared by every DCE SPI on that Data. "
                       "Per pair the calculator receives DYN_CORR_EXCL = int(W[i,j]) (truncation toward 0). In JIDT a neighbour is excluded when |t − t'| <= W; W = 0 or 1 still excludes only very close points."),
    'implementation_trace': [
        "pyspi/statistics/infotheory.py:57-58 '_DCE' added to the identifier when dyn_corr_excl is truthy ('AUTO' in config.yaml:512, :534, :563, :570, :577)",
    ] + T_THEILER + [
        "pyspi/statistics/infotheory.py:217-220 numeric dyn_corr_excl alternative (not used by any config)",
        "pyspi/statistics/infotheory.py:270, :303, :381 MutualInfo/TimeLaggedMutualInfo/TransferEntropy.bivariate call _set_theiler_window(data, i, j) before initialise",
        "JIDT " + KR + "MutualInfoCalculatorMultiVariateKraskov.java#L231-L233 DYN_CORR_EXCL -> dynCorrExclTime, dynCorrExcl = W > 0; :298-303 throws if N <= k + 2W",
        "JIDT " + KR + "ConditionalMutualInfoCalculatorMultiVariateKraskov.java#L269-L271 and :316 same for CMI; " + MC + "TransferEntropyCalculatorViaCondMutualInfo.java#L462-L465 forwards and stores it, :752-754 copies it into the auto-embedding AIS calculator",
        "JIDT " + J + "utils/KdTree.java#L751-L753 and utils/UnivariateNearestNeighbourSearcher.java#L503-L505 exclusion test |dt| <= dynCorrExclTime",
    ],
    'deviation_from_documented': ("Documented as 'the product of the autocorrelation functions of both time series'; implemented as twice the inner product of the two full sample ACFs (lags 0..T−1), "
                                  "then int(). Documented as a heuristic for the autocorrelation time; for oscillatory, periodic, trending or random-walk inputs the value grows linearly with T "
                                  "(probe p3: narrowband 22/85/339/1353 at T=64/256/1024/4096) and is not an autocorrelation time."),
    'deviation_from_canonical': ("Relative to Bartlett's 1 + 2Σ_{k>=1} ρ_xρ_y: (1) the lag-0 term is doubled, so the raw value is exactly Bartlett + 1 (probe p3: difference 1.00 on every pair); "
                                 "(2) int() truncation; (3) the sum uses the biased sample ACF over all T−1 lags with no truncation, so noisy high-lag products accumulate and periodic components contribute "
                                 "≈ T/3 (2 Σ (1−k/T)² cos²(ωk)); (4) the window is a pair quantity (product of both ACFs) while a Theiler window is usually set from the autocorrelation time of the "
                                 "embedded variables. For white noise W = 1 or 2 depending on sampling noise (probe p3 iid_gaussian T=1024: [2,2,1,1,2,2,2,2,1,1])."),
    'units_and_range': 'integer number of samples, >= 0 in practice (can be 0 or negative only if the ACF inner product is below 0.5, not observed); symmetric in (i, j); grows ∝ T for non-decaying ACFs',
    'direction_convention': 'n/a (symmetric pair quantity W[i,j] = W[j,i])',
    'symmetry_expected': 'n/a',
    'already_documented': 'no',
    'new_finding_candidates': [
        "CANDIDATE (pack hypothesis confirmed): W = int(2·dot(acf_i, acf_j)) = int(1 + [1 + 2Σ_{k>=1} r_i r_j]), i.e. Bartlett's value plus one before truncation; probe p3 raw − Bartlett = 1.00 on all pairs of 11 datasets × 4 T × 2 preprocessing variants.",
        "CANDIDATE (pack hypothesis refined): the window is pair-specific but is not recomputed per pair: all pairs are computed on the first call and cached as data.theiler (infotheory.py:197-212), shared across all DCE SPIs on that Data object.",
        "CANDIDATE: summing all T−1 lags makes W ∝ T for oscillatory/periodic/trending/random-walk input (probe p3: narrowband ≈ 0.33 T, logistic_maps 665 at T=4096, trending without detrend 1403 at T=4096 but 2 after detrend, cointegrated 1277 at T=4096, shared_envelope 1084), so the 'autocorrelation time' heuristic removes about 2/3 of the series from every neighbour search.",
        "CANDIDATE: large W makes the auto-embedding TE unit return NaN at small T (N = T − 37 <= 4 + 2W; probe p13 T=64 narrowband, logistic_maps, shared_envelope) — see infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4.",
        "CANDIDATE (efficiency): acf of each channel is recomputed inside the pair loop with np.correlate 'full' (O(T²) each), i.e. P(P−1) ACF evaluations instead of P.",
    ],
    'proposed_checks': [
        {'datasets': ['iid_gaussian', 'bivariate_gaussian', 'var2_bivariate', 'gauss_ar1_pair', 'delayed_noise', 'narrowband_f0-0.1', 'logistic_maps', 'cointegrated', 'trending', 'shared_envelope'],
         'path': 'pipeline', 'reference': 'from-scratch numpy: biased ACF by explicit lag loop on z-scored rows, W = int(2 Σ_{k=0}^{T−1} r_i(k) r_j(k)); compare with data.theiler after a DCE call',
         'reference_kind': 'independent-impl', 'criterion': 'exact',
         'expected_outcome': 'integer windows identical on every pair (raw values to <= 1e-10)'},
        {'datasets': ['iid_gaussian', 'gauss_ar1_pair', 'var2_bivariate', 'narrowband_f0-0.1', 'narrowband_f0-0.25'], 'path': 'pipeline',
         'reference': "analytic population value of Bartlett's τ = 1 + 2 Σ_{k>=1} ρ_x(k) ρ_y(k): white noise 1; gauss_ar1_pair and var2_bivariate from the VAR autocovariance sequence; a pure sinusoid has a non-summable product (τ undefined/infinite)",
         'reference_kind': 'analytic', 'criterion': 'tolerance',
         'expected_outcome': 'raw pyspi value ≈ τ + 1 (white noise ≈ 2, giving W in {1, 2}); for narrowband W/T → 1/3 as T grows (0.343, 0.333, 0.331, 0.330 at T=64..4096, probe p3)'},
        {'datasets': ['trending', 'cointegrated'], 'path': 'pipeline-detrend',
         'reference': 'same rule on detrended vs non-detrended input',
         'reference_kind': 'analytic', 'criterion': 'qualitative',
         'expected_outcome': 'trending: W drops from up to 1403 (T=4096) to 1-2 with detrend; cointegrated stays large (1093 at T=4096)'},
    ],
})
print('written')
