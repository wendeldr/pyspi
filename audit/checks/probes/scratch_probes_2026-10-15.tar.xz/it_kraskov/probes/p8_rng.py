import sys; sys.argv=['x']
from common import *
from ksg_ref import JavaRandom
import jpype as jp
r = jp.java.util.Random(42); m = JavaRandom(42)
a = [r.nextGaussian() for _ in range(10)]; b = [m.nextGaussian() for _ in range(10)]
print(np.max(np.abs(np.array(a)-np.array(b))), a[:3], b[:3])
