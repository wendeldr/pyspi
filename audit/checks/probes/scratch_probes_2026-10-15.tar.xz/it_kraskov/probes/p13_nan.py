from common import *
import logging; logging.getLogger().setLevel(logging.CRITICAL)
names = ['iid_gaussian','bivariate_gaussian','var2_bivariate','delayed_noise','narrowband_f0-0.1','narrowband_f0-0.25','narrowband_f0-0.4','logistic_maps','cointegrated','trending','shared_envelope','gauss_ar1_pair','nonlinear_dependence','anm','contaminated']
for T in [64, 256]:
    for name in names:
        x = load(name, T); row = []
        for u in UNITS:
            if 'auto' in u and T > 256: continue
            A = UNITS[u]().multivariate(mkdata(x))
            off = ~np.eye(A.shape[0], dtype=bool)
            n = int(np.isnan(A[off]).sum())
            mn = np.nanmin(A[off]) if n < off.sum() else np.nan
            row.append(f'{u}:nan={n}/{off.sum()},min={mn:.3f}')
        print(T, name, ' '.join(row))
