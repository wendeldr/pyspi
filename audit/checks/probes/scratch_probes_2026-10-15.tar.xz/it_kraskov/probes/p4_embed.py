from common import *
import logging
logging.getLogger().setLevel(logging.ERROR)
names = sys.argv[1].split(',')
Ts = [int(t) for t in sys.argv[2].split(',')]
for name in names:
    for T in Ts:
        x = load(name, T)
        for u in ['te_auto','te_auto_DCE']:
            s = UNITS[u]()
            d = mkdata(x)
            P_ = x.shape[0]
            out = []
            for j in range(P_):
                for i in range(P_):
                    if i == j: continue
                    v = s.bivariate(d, i=i, j=j)
                    c = s._calc
                    emb = tuple(int(str(c.getProperty(p))) for p in ['k_HISTORY','k_TAU','l_HISTORY','l_TAU'])
                    W = str(c.getProperty('DYN_CORR_EXCL'))
                    out.append(f'{i}->{j}:{"nan" if np.isnan(v) else round(v,3)} k,kt,l,lt={emb} W={W}')
            print(name, T, u, ' | '.join(out))
