from common import *
from ksg_ref import *
def ais(x, k, tau, W=0):
    T = len(x); start = (k-1)*tau; tn = np.arange(start+1, T)
    past = np.stack([x[tn-1-q*tau] for q in range(k)][::-1], 1)
    return ksg1_mi(past, x[tn][:, None], W=W)
def best(x, W=0, kmax=10, taumax=4):
    b = (-np.inf, None)
    for k in range(1, kmax+1):
        for tau in range(1, taumax+1):
            v = ais(x, k, tau, W)
            if v > b[0]: b = (v, (k, tau))
            if k == 1: break
    return b
def _main():
  for name, T, i, j in [('var2_bivariate',256,0,1),('gauss_ar1_pair',256,1,0),('logistic_maps',256,1,0)]:
      x = load(name, T); d = mkdata(x); z = d.to_numpy(squeeze=True)
      for u in ['te_auto','te_auto_DCE']:
          s = UNITS[u](); v = s.bivariate(d, i=i, j=j)
          emb = [int(str(s._calc.getProperty(p))) for p in ['k_HISTORY','k_TAU','l_HISTORY','l_TAU']]
          W = int(d.theiler[i,j]) if 'DCE' in u else 0
          bd = best(z[j], W); bs = best(z[i], W)
          ref = te_fixed(z[i], z[j], k=bd[1][0], kt=bd[1][1], l=bs[1][0], lt=bs[1][1], W=W)
          print(name, T, f'{i}->{j}', u, 'pyspi', round(v,12), emb, '| ref dest', bd[1], 'src', bs[1], 'te', round(ref,12))

if __name__ == '__main__':
    _main()