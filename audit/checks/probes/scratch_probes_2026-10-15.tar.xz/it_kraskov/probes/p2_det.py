from common import *
x = load('bivariate_gaussian', 1024)
for name in ['mi','mi_DCE','tlmi','te_k1','te_auto']:
    s = UNITS[name]()
    d = mkdata(x)
    a = s.multivariate(d)
    d2 = mkdata(x); b = UNITS[name]().multivariate(d2)
    s1 = UNITS[name](); s1._calc.setProperty('NUM_THREADS','1')
    c = s1.multivariate(mkdata(x))
    s7 = UNITS[name](); s7._calc.setProperty('NUM_THREADS','7')
    e = s7.multivariate(mkdata(x))
    off = ~np.eye(4, dtype=bool)
    print(name, 'rerun maxdiff', np.nanmax(abs(a-b)), 'threads1 maxdiff', np.nanmax(abs(a-c)), 'threads7', np.nanmax(abs(a-e)))
    print('  A=', np.round(a,4).tolist())
# MI symmetry before mirroring
s = UNITS['mi'](); d = mkdata(x)
print('mi biv(0,1)', s.bivariate(d,i=0,j=1), 'biv(1,0)', s.bivariate(d,i=1,j=0))
print('mi biv(2,3)', s.bivariate(d,i=2,j=3), 'biv(3,2)', s.bivariate(d,i=3,j=2))
print('true mi', np.load(DD+'bivariate_gaussian_T1024.npz')['true_mi_nats'])
