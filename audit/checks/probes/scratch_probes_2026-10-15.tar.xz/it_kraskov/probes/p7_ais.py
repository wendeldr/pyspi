from common import *
from ksg_ref import *
import jpype as jp
from p6_auto import ais
x = load('logistic_maps', 256); d = mkdata(x); z = d.to_numpy(squeeze=True)
y = z[1]
print('unique values of y (rounded 1e-6):', len(np.unique(np.round(y, 6))))
A = jp.JPackage('infodynamics.measures.continuous.kraskov').ActiveInfoStorageCalculatorKraskov
for k, tau in [(1,1),(2,1),(4,1),(7,2),(10,1),(10,4)]:
    c = A(1); c.setProperty('k','4'); c.setProperty('NOISE_SEED','42')
    c.initialise(k, tau); c.setObservations(jp.JArray(jp.JDouble,1)(y))
    print(k, tau, 'jidt', c.computeAverageLocalOfObservations(), 'ref', ais(y, k, tau))
