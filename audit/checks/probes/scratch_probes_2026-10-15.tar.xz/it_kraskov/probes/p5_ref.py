from common import *
from ksg_ref import *
for name, T in [('bivariate_gaussian',256),('delayed_noise',256),('var2_bivariate',256),('gauss_ar1_pair',256),('narrowband_f0-0.1',256)]:
    x = load(name, T); d = mkdata(x); z = d.to_numpy(squeeze=True)
    for (i,j) in [(0,1),(1,0)]:
        mi = UNITS['mi']().bivariate(d, i=i, j=j)
        mid = UNITS['mi_DCE'](); vd = mid.bivariate(d, i=i, j=j); W = int(d.theiler[i,j])
        tl = UNITS['tlmi']().bivariate(d, i=i, j=j)
        te = UNITS['te_k1']().bivariate(d, i=i, j=j)
        te2 = UNITS['te_k2_DCE']().bivariate(d, i=i, j=j)
        r_mi = ksg1_mi(z[i], z[j]); r_mi0 = ksg1_mi(z[i], z[j], noise=False)
        r_mid = ksg1_mi(z[i], z[j], W=W)
        r_tl = ksg1_mi(z[i][:-1], z[j][1:])
        r_te = te_fixed(z[i], z[j]); r_te2 = te_fixed(z[i], z[j], k=2, W=W)
        print(f'{name} ({i},{j}) W={W}: mi {mi:.15f} ref {r_mi:.15f} ref_nonoise {r_mi0:.15f} | miDCE {vd:.12f} ref {r_mid:.12f} | tlmi {tl:.12f} ref {r_tl:.12f} | te_k1 {te:.12f} ref {r_te:.12f} | te_k2_DCE {te2:.12f} ref {r_te2:.12f}')
