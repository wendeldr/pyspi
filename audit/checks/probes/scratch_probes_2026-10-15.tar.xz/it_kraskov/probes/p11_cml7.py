from common import *
x = np.load('/media/dan/Data/git/pyspi/pyspi/data/cml7.npy').T  # sp -> ps
print('shape', x.shape)
d = mkdata(x[:3, :])
for u in ['te_auto','te_auto_DCE']:
    s = UNITS[u]()
    for (i,j) in [(0,1),(1,2)]:
        v = s.bivariate(d, i=i, j=j)
        print(u, i, j, round(v,6), [int(str(s._calc.getProperty(p))) for p in ['k_HISTORY','k_TAU','l_HISTORY','l_TAU']], 'te_k1', round(UNITS['te_k1']().bivariate(d,i=i,j=j),6))
