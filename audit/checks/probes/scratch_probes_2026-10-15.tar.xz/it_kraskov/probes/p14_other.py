from common import *
import copy
x = load('var2_bivariate', 256)
for kw in [dict(estimator='gaussian', auto_embed_method='MAX_CORR_AIS', k_search_max=10, tau_search_max=2), dict(estimator='kernel', kernel_width=0.25, k_history=1, l_history=1), dict(estimator='symbolic', k_history=10, l_history=1)]:
    try:
        s = it.TransferEntropy(**kw); c = copy.deepcopy(s)
        a = s.multivariate(mkdata(x)); b = c.multivariate(mkdata(x))
        print(s.identifier, 'orig', np.round(a,5).tolist(), 'deepcopy', np.round(b,5).tolist(), 'AUTO', str(c._calc.getProperty('AUTO_EMBED_METHOD')), 'k', str(c._calc.getProperty('k_HISTORY')))
    except Exception as e:
        print(kw, 'ERR', type(e).__name__, e)
