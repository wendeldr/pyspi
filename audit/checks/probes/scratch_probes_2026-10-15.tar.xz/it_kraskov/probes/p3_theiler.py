from common import *
from pyspi import utils
def bartlett(a, b, maxlag=None):
    ra, rb = utils.acf(a), utils.acf(b)
    return 1 + 2*np.dot(ra[1:], rb[1:])
for name in ['iid_gaussian','bivariate_gaussian','var2_bivariate','gauss_ar1_pair','delayed_noise','narrowband_f0-0.1','narrowband_f0-0.25','logistic_maps','cointegrated','trending','shared_envelope']:
    for T in [64,256,1024,4096]:
        x = load(name, T)
        for det in [False, True]:
            d = mkdata(x, detrend=det)
            s = UNITS['mi_DCE']()
            s._set_theiler_window(d, 0, 1)
            W = d.theiler
            iu = np.triu_indices(W.shape[0], 1)
            z = d.to_numpy(squeeze=True)
            B = [bartlett(z[j], z[i]) for i,j in zip(*iu)]
            print(f'{name:20s} T={T:5d} det={int(det)} W(int)={[int(w) for w in W[iu]]} raw2dot={np.round(W[iu],2).tolist()} bartlett(1+2sum_k>=1)={np.round(B,2).tolist()}')
