from common import *
for name, f in UNITS.items():
    s = f()
    c = s._calc
    props = {}
    for p in ['k','DYN_CORR_EXCL','NUM_THREADS','NORMALISE','NOISE_LEVEL_TO_ADD','NOISE_SEED','NORM_TYPE','k_HISTORY','k_TAU','l_HISTORY','l_TAU','DELAY','AUTO_EMBED_METHOD','AUTO_EMBED_K_SEARCH_MAX','AUTO_EMBED_TAU_SEARCH_MAX','BIAS_CORRECTION','ALG_NUM','TIME_DIFF']:
        try: props[p] = str(c.getProperty(p))
        except Exception as e: props[p] = 'ERR'
    print(name, s.identifier, type(c).__name__, s.labels, props)
import jpype
print('JVM cpus', jpype.java.lang.Runtime.getRuntime().availableProcessors(), 'os cpus', os.cpu_count())
