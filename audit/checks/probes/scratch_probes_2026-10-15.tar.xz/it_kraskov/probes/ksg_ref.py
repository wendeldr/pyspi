# from-scratch KSG1 MI / CMI (max-norm), brute force, numpy + scipy.special.digamma; no JIDT
import numpy as np
from scipy.special import digamma
MASK = (1 << 48) - 1
class JavaRandom:
    def __init__(self, seed):
        self.s = (seed ^ 0x5DEECE66D) & MASK; self.have = False
    def next(self, bits):
        self.s = (self.s * 0x5DEECE66D + 0xB) & MASK
        r = self.s >> (48 - bits)
        if r >= 1 << 31: r -= 1 << 32
        return r
    def nextDouble(self):
        return ((self.next(26) << 27) + self.next(27)) * (1.0 / (1 << 53))
    def nextGaussian(self):
        if self.have:
            self.have = False; return self.nng
        while True:
            v1 = 2 * self.nextDouble() - 1; v2 = 2 * self.nextDouble() - 1
            s = v1 * v1 + v2 * v2
            if 0 < s < 1: break
        m = np.sqrt(-2 * np.log(s) / s)  # StrictMath in Java; may differ in last ulp
        self.nng = v2 * m; self.have = True
        return v1 * m
def norm_cols(a):
    a = np.asarray(a, float)
    return (a - a.mean(0)) / a.std(0, ddof=1)
def add_noise(blocks, seed=42, level=1e-8):
    # JIDT order: for each row r: all source cols, then all dest cols (then cond cols for CMI)
    rng = JavaRandom(seed); out = [b.copy() for b in blocks]
    for r in range(out[0].shape[0]):
        for b in out:
            for c in range(b.shape[1]):
                b[r, c] += rng.nextGaussian() * level
    return out
def cheb(a):
    return np.max(np.abs(a[:, None, :] - a[None, :, :]), axis=2)
def ksg1_mi(x, y, k=4, W=0, noise=True):
    x = norm_cols(np.reshape(x, (len(x), -1))); y = norm_cols(np.reshape(y, (len(y), -1)))
    if noise: x, y = add_noise([x, y])
    N = len(x); t = np.arange(N)
    excl = np.abs(t[:, None] - t[None, :]) <= W
    dx, dy = cheb(x), cheb(y); dj = np.maximum(dx, dy)
    dj[excl] = np.inf
    eps = np.sort(dj, axis=1)[:, k - 1]
    dx[excl] = np.inf; dy[excl] = np.inf
    nx = (dx < eps[:, None]).sum(1); ny = (dy < eps[:, None]).sum(1)
    return digamma(k) - np.mean(digamma(nx + 1) + digamma(ny + 1)) + digamma(N)
def ksg1_cmi(x, y, z, k=4, W=0, noise=True):
    # JIDT CMI order of noise: var1 (x), var2 (y), cond (z) per row -- to be confirmed
    x = norm_cols(x); y = norm_cols(y); z = norm_cols(z)
    if noise: x, y, z = add_noise([x, y, z])
    N = len(x); t = np.arange(N)
    excl = np.abs(t[:, None] - t[None, :]) <= W
    dx, dy, dz = cheb(x), cheb(y), cheb(z)
    dj = np.maximum(np.maximum(dx, dy), dz); dj[excl] = np.inf
    eps = np.sort(dj, axis=1)[:, k - 1]
    dxz = np.maximum(dx, dz); dyz = np.maximum(dy, dz)
    for d in (dxz, dyz, dz): d[excl] = np.inf
    nxz = (dxz < eps[:, None]).sum(1); nyz = (dyz < eps[:, None]).sum(1); nz = (dz < eps[:, None]).sum(1)
    return digamma(k) + np.mean(digamma(nz + 1) - digamma(nxz + 1) - digamma(nyz + 1))
def te_fixed(src, dst, k=1, kt=1, l=1, lt=1, delay=1, K=4, W=0, noise=True):
    T = len(src)
    start = max((k - 1) * kt, (l - 1) * lt + delay - 1)  # JIDT computeStartTimeForFirstDestEmbedding (to confirm)
    n = T - start - 1
    t_next = np.arange(start + 1, start + 1 + n)
    dpast = np.stack([dst[t_next - 1 - q * kt] for q in range(k)][::-1], 1)
    spast = np.stack([src[t_next - delay - q * lt] for q in range(l)][::-1], 1)
    return ksg1_cmi(spast, dst[t_next][:, None], dpast, k=K, W=W, noise=noise)
