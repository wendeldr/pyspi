from common import *
from pyspi.calculator import Calculator, CalculatorFrame
import warnings; warnings.filterwarnings('ignore')
x = load('var2_bivariate', 256)
with contextlib.redirect_stdout(io.StringIO()):
    c = Calculator(dataset=x, configfile=sys.argv[1]); c.compute()
    f = CalculatorFrame(datasets=[x], names=['a'], labels=[['l']], configfile=sys.argv[1]); f.compute()
cf = f.calculators.iloc[0, 0] if hasattr(f.calculators, 'iloc') else None
for k in c.spis:
    a = c.table[k].to_numpy(); b = cf.table[k].to_numpy()
    print(k, 'Calculator A[0,1]=%.6f' % a[0,1], 'CalculatorFrame A[0,1]=%.6f' % b[0,1])
