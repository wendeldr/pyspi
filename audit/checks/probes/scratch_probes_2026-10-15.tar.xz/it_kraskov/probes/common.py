import sys, os, io, contextlib
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import numpy as np
import pyspi.statistics.infotheory as it
from pyspi.data import Data
DD = '/media/dan/Data/git/pyspi/audit/checks/data/'
def load(name, T):
    return np.load(f'{DD}{name}_T{T}.npz')['x']
def mkdata(x, detrend=False, normalise=True):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, dim_order='ps', detrend=detrend, normalise=normalise)
UNITS = {
 'mi': lambda: it.MutualInfo(estimator='kraskov', prop_k=4),
 'mi_DCE': lambda: it.MutualInfo(estimator='kraskov', prop_k=4, dyn_corr_excl='AUTO'),
 'tlmi': lambda: it.TimeLaggedMutualInfo(estimator='kraskov', prop_k=4),
 'tlmi_DCE': lambda: it.TimeLaggedMutualInfo(estimator='kraskov', prop_k=4, dyn_corr_excl='AUTO'),
 'te_auto': lambda: it.TransferEntropy(estimator='kraskov', prop_k=4, auto_embed_method='MAX_CORR_AIS', k_search_max=10, tau_search_max=4),
 'te_auto_DCE': lambda: it.TransferEntropy(estimator='kraskov', prop_k=4, auto_embed_method='MAX_CORR_AIS', k_search_max=10, tau_search_max=4, dyn_corr_excl='AUTO'),
 'te_k2_DCE': lambda: it.TransferEntropy(estimator='kraskov', prop_k=4, k_history=2, l_history=1, dyn_corr_excl='AUTO'),
 'te_k1_DCE': lambda: it.TransferEntropy(estimator='kraskov', prop_k=4, k_history=1, l_history=1, dyn_corr_excl='AUTO'),
 'te_k1': lambda: it.TransferEntropy(estimator='kraskov', prop_k=4, k_history=1, l_history=1),
}
