from common import *
x = load('logistic_maps', 256); y = load('bivariate_gaussian', 256)
for name, X in [('logistic_maps', x), ('bivariate_gaussian', y)]:
    for u in ['mi','tlmi','te_k1','te_auto']:
        vals = []
        for seed in ['42','43','44']:
            s = UNITS[u](); s._calc.setProperty('NOISE_SEED', seed)
            d = mkdata(X)
            v = s.bivariate(d, i=1, j=0)
            emb = [int(str(s._calc.getProperty(p))) for p in ['k_HISTORY','k_TAU','l_HISTORY','l_TAU']] if 'te' in u else ''
            vals.append((round(v,6), emb))
        print(name, u, '1->0 by seed 42/43/44:', vals)
