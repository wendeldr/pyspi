from common import *
import copy, pickle
x = load('var2_bivariate', 256)
for u in ['te_auto','te_k2_DCE','mi_DCE']:
    s = UNITS[u]()
    a = s.multivariate(mkdata(x))
    try:
        c = copy.deepcopy(s)
        same = c._calc is s._calc
        b = c.multivariate(mkdata(x))
        print(u, 'deepcopy ok; shares _calc:', same, 'id', c.identifier, 'maxdiff', np.nanmax(abs(a-b)))
    except Exception as e:
        print(u, 'deepcopy FAILED', type(e).__name__, e)
    try:
        p = pickle.loads(pickle.dumps(s))
        props = [str(p._calc.getProperty(q)) for q in ['k_HISTORY','AUTO_EMBED_METHOD']] if 'te' in u else []
        b = p.multivariate(mkdata(x))
        print(u, 'pickle ok; id', p.identifier, 'props', props, 'maxdiff', np.nanmax(abs(a-b)), 'A', np.round(a,4).tolist(), 'Apickled', np.round(b,4).tolist())
    except Exception as e:
        print(u, 'pickle FAILED', type(e).__name__, e)
