import yaml
P = "/media/dan/Data/git/pyspi/audit/records/misc.ids.yaml"
r = yaml.safe_load(open(P))
c = r["correctness"]
r["status"] = "checked"

# ---- trace-stage corrections (citation drift + measured symmetry) ----
tr = c["implementation_trace"]
tr[1] = ('pyspi/calculator.py:230-267 Calculator._load_yaml (def 230): importlib.import_module(".statistics.misc") (239) - first import '
         'executes numpy_dependence.py:11-12 np.random.seed(1717) - then the per-config loop 251-267 instantiates InterDependenceScore(**params) '
         '(256) and stores it under identifier "ids" (257)')
tr[3] = ('pyspi/calculator.py:295-355 Calculator.compute (def 295; per-SPI try/except 327-339): S = spi.multivariate(dataset) (329); '
         'fill_diagonal(S, nan) (332); self._table[spi] = S (335); except 336-339: whole block NaN (337), error and warning text recorded (338-339); '
         'MetricReport status "failed" (342-346); on_metric_complete callback (347-353); warnings.warn(failure_warning) emitted after the callback (354-355)')
c["implemented_as"] = c["implemented_as"].replace("exact up to last-bit rounding (probe max |A - A^T| <= 1.1e-16)",
    "exact up to last-bit rounding (check stage: max |A - A^T| = 2.2e-16 over 65 square outputs, 52 of them not bitwise symmetric)")
c["units_and_range"] = c["units_and_range"].replace("symmetric up to last-bit rounding (probe max |A - A^T| <= 1.1e-16, not exactly 0)",
    "symmetric up to last-bit rounding (check stage max |A - A^T| = 2.2e-16, not exactly 0)")
c["direction_convention"] = c["direction_convention"].replace("and holds to ~1e-16.", "and holds to 2.2e-16 (check stage).")
c["deviation_from_documented"] = c["deviation_from_documented"] + (
    ' Check stage: (b) is now shown by construction: a dependent law phi(x)phi(y)(1 + eps g(x)g(y)) with g orthogonal to 1 and to the six '
    'features has population IDS_p = 0 for every p while Corr(g(X), g(Y)) = 0.474; pyspi gives 0.0435 at T = 4096 (null mean 0.0324, q95 0.0477) '
    '(misc.ids|iid_gaussian|4096|pipeline|hidden-dependence).')
assert "2.2e-16" in c["implemented_as"] and "2.2e-16" in c["units_and_range"] and "2.2e-16" in c["direction_convention"]

# ---- check-stage block ----
c["check_method"] = "independent-impl"
c["check_reference"] = (
    "audit/checks/refs/ids.py:chk_kids -> audit/checks/refs/_kernels_basic_misc.py:ids (transform, explicit dot/norm Pearson, max over the term blocks; "
    "no import of pyspi.lib.ids) plus refs/ids.py:eq6_ids (own per-pair transcription of Radhakrishnan et al. 2025 PNAS Eq. 6, 11, 12, B = sqrt(1/(2*bandwidth))); "
    "refs/ids.py:chk_eq6 (bandwidth 0.25/0.5/1.0, pnorm 1/2 through probes/ids_probes.py:ids_param); refs/ids.py:chk_identical, chk_signflip, chk_invariance (analytic); "
    "refs/ids.py:chk_truth (population IDS-max of a standard bivariate normal by 2-D Gauss-Hermite quadrature, 120 nodes, plus own Monte Carlo, 2000 draws); "
    "refs/ids.py:chk_null (own Monte Carlo null, 2000 draws, iid and random-walk; AR(1) extra keys); refs/ids.py:chk_structure (per-pair permutation bound, 1000 shuffles); "
    "refs/ids.py:chk_hidden (constructed dependent law with population IDS = 0, probes/ids_probes.py:hidden_construction, own MC 300 draws); "
    "refs/ids.py:chk_minmax (paper's reported min-max [0, 8] preprocessing); refs/ids.py:chk_pnorm_unsupported; refs/ids.py:chk_rng (legacy MT19937 stream "
    "np.random.RandomState(seed), fresh interpreters via probes/ids_probes.py:rng_import, rng_calculator, rng_cross_spi); refs/ids.py:chk_symmetry; numpy==2.5.4, scipy==1.18.1")
c["check_data"] = (
    "kernel path: iid_gaussian T64/T256/T1024/T4096, nonlinear_dependence T64/T256/T1024/T4096, bivariate_gaussian, anm, contaminated, logistic_maps, delayed_noise, "
    "scaled_offset T1024; pipeline: the same seven datasets T1024, iid_gaussian T64-T4096 (null), bivariate_gaussian pairs (0,1)/(2,3) T256/T1024/T4096 (truth), "
    "scaled_offset T1024 (invariance), cointegrated x2,x3 T1024 (random-walk null), delayed_noise T4096 (zero lag), shared_envelope x0,x2 T256 (identical pair), "
    "nonlinear_dependence/contaminated/anm/bivariate_gaussian T4096 (paper preprocessing), trending T1024 (pipeline and pipeline-detrend); "
    "constructed hidden-dependence sample T4096 (kernel and pipeline); RNG probes on iid_gaussian T64")
c["agreement_criterion"] = (
    "exact: rtol 1e-10, atol 1e-12 (kernel mirror, Eq. 6 transcription, analytic invariances and identical-pair = 1); statistical: |pyspi - MC mean| <= 2 se with se = MC sd "
    "(truth, hidden-dependence) or MC sd x familywise factor over the pairs (null); qualitative: structure (max|A-A^T| <= 1e-15, NaN diagonal, dependent pairs above and "
    "independent pairs below a per-pair permutation (1 - 0.05/m) bound), RNG side effects reproduced exactly against the MT19937 stream, unsupported pnorm failure mode, "
    "symmetry <= 1e-15 over every square output; the paper-minmax08 runs are exact comparisons with the paper's reported preprocessing and are expected to fail (they size "
    "the preprocessing effect)")
c["closeness"] = (
    "Kernel mirror: all 22 kids runs pass, max_abs <= 2.2e-15 (kernel path <= 7.8e-16 on 14 runs; pipeline-detrend trending 2.2e-15 with own lstsq detrend); own Eq. 6/11/12 "
    "transcription vs kernel mirror <= 1.0e-15 (ref_eq6_vs_kernel_maxabs). Bandwidth 0.25/0.5/1.0 vs Eq. 6 with B = 1.414/1.0/0.707: max_abs <= 4.4e-16 (6 runs); "
    "pnorm 1 and 2 vs Eq. 12: 1.1e-16. Analytic: identical rows ([x0, x0, -x0, 2.5 x0 - 1]) and the shared_envelope x2 = x0 copy give exactly 1 (max_abs 0.0); "
    "sign flip 1.1e-16; scaled_offset pipeline vs z-scored bivariate_gaussian 5.6e-17, while the raw kernel path differs by 0.628 (not scale invariant). "
    "Population (quadrature): 0.26408 (rho 0.3) and 0.73485 (rho 0.8), argmax (k,l) = (3,3); pyspi 0.2746/0.2617/0.2697 (rho 0.3) and 0.7617/0.7492/0.7303 (rho 0.8) at "
    "T = 256/1024/4096, all 6 within 2 MC sd (max_z <= 0.93); MC mean - population 0.0173/0.0029/0.00004 (rho 0.3). Null iid_gaussian (MC 2000): MC mean 0.2579/0.1273/"
    "0.0648/0.0324 at T = 64/256/1024/4096 (mean x sqrt(T) 2.06/2.04/2.07/2.07, q95 0.368/0.183/0.094/0.047); pyspi off-diagonal mean 0.2354/0.1135/0.0647/0.0324, all "
    "4 runs pass (max_z <= 1.50). AR(1) null at T = 1024: MC mean 0.069/0.132/0.359 and q95 0.100/0.192/0.557 for phi 0.5/0.9/0.99; independent random walks: MC mean "
    "0.568 (8.8 x the iid mean), pyspi 0.465 (pass, z 0.62). Structure: nonlinear_dependence (0,1)/(2,3) 0.945/0.985 (T1024) and 0.943/0.993 (T4096), anm 0.853/0.968, "
    "bivariate_gaussian 0.262/0.749, independent pairs <= 0.071 and below their permutation bounds (5/5 qualitative pass, including delayed_noise T4096 max 0.046 vs bound "
    "median 0.055 and trending detrended 0.263/0.750 with cross pairs <= 0.077, versus 0.996 without detrend). Paper preprocessing (min-max [0, 8], B = 1): pyspi on "
    "min-max rows agrees with Eq. 6 to <= 3.3e-16 (4 runs); pyspi default vs paper setting differs by 0.680 (nonlinear_dependence: 0.943/0.993 vs 0.485/0.313), 0.357 "
    "(contaminated 0.949 vs 0.592), 0.178 (anm 0.857/0.965 vs 0.828/0.787) and 0.054 (bivariate_gaussian 0.270/0.730 vs 0.225/0.677) at T = 4096 (4 expected fails). "
    "Hidden dependence (population IDS = 0, Corr(g(X), g(Y)) = 0.474): pyspi 0.0436 (kernel) / 0.0435 (pipeline) vs null MC mean 0.0325/0.0324 (pass, z 1.30/1.38); "
    "own MC under that law 0.0322/0.0317 vs null 0.0325/0.0324 (z -0.62/-1.26) while the sample Corr(g(X), g(Y)) is 0.491 (z 31.4). RNG: seed(123) then import of "
    "pyspi.lib.ids gives the seed(1717) state (first draw 0.35547 = RandomState(1717)); importing pyspi.calculator alone leaves the stream (0.69647 = RandomState(123)); "
    "one IDS compute leaves the stream (next draw 0.26495 = second draw of RandomState(1717)); IDS identical under seeds 1 and 2 (diff 0.0); a second Calculator in the "
    "same process keeps the user seed (0.22199 = RandomState(5)); cov_MinCovDet sum|A| is 2.30186 under user seeds 1 and 2 set before Calculator() and equals the no-ids "
    "config under seed 1717, while without ids seeds 1/2 give 2.64277/2.24323; with ids computed before MinCovDet and seed 7 set after construction MinCovDet is unchanged "
    "(2.74185 both). Symmetry: max|A - A^T| 2.2e-16 over 65 square outputs, 52 not bitwise symmetric.")
c["verdict"] = "variant"
c["score_0_10"] = 7
c["what_changed"] = (
    "The estimator is the paper's IDS_inf with k = 6 and B = 1 (bandwidth 0.5 is the coefficient of z^2) to floating-point precision, against an own transcription of "
    "Eq. 6/11/12 and the shared kernel mirror; bandwidth and pnorm 1/2 also match Eq. 6/12. Score 7 (README anchor: matches the documented variant but differs from canonical "
    "in a value-changing way, here input normalisation): pyspi feeds z-scored data (ddof=1) while the paper's reported setting min-max scales each variable to [0, 8]; "
    "the Gaussian damping is not scale/shift invariant, so values differ by up to 0.68 (nonlinear_dependence (2,3) 0.993 vs 0.313 at T = 4096). The paper allows other "
    "normalisations, so this is a variant, not an error; neither the GitBook nor the code says which normalisation pyspi uses. Documentation claims checked: '0 indicates "
    "independence' holds only asymptotically (finite-sample null mean about 2.07/sqrt(T) for iid pairs, much larger for autocorrelated series: random walks 0.57 at T = 1024); "
    "'can detect any type of dependence' does not hold for the k = 6 statistic (constructed dependent law with population IDS = 0, pyspi at the null level). Not a "
    "generalisation of |Pearson| (rho 0.8 gives 0.735). Code-level: module import reseeds the global numpy RNG (confirmed, new); last-bit asymmetry 2.2e-16; pnorm other "
    "than 'max'/1/2 gives a silent all-NaN Calculator block. Not 9: the normalisation difference is value-changing and undocumented, not a trivial convention. Not 10: "
    "there is no supplement description and the canonical reported setting is not reproduced on pyspi's default path.")
c["new_finding"] = True
c["definition_under_review"] = False
c["check_cost"] = ("cheap: every SPI run <= 0.005 s at T = 4096 (index time_s); the RNG cross-SPI probe takes 14 s because it starts 7 fresh interpreters with "
                   "MinCovDet; whole family about 75 s pyspi side and 60 s reference side")
c["symmetry_observed"] = ("sym up to last-bit rounding: max|A - A.T| = 2.2e-16 over 65 square outputs, 52 of them not bitwise symmetric (worst "
                          "misc.ids|nonlinear_dependence|256|kernel|kids; misc.ids|iid_gaussian|4096|pipeline|symmetry); diagonal NaN after the pipeline")
c["direction_observed"] = ("undirected: A[i,j] = A[j,i] = IDS-max(z_i, z_j) at zero lag. anm x0 -> x1 gives 0.853 in both orientations and x2 -> x3 0.968 "
                           "(misc.ids|anm|1024|pipeline|structure), so no direction information; delayed_noise lagged copies (lags 1, 3, 5) score at the null level, "
                           "max 0.046 vs permutation bound median 0.055 at T = 4096 (misc.ids|delayed_noise|4096|pipeline|zero-lag)")
c["candidate_resolutions"] = [
    {"candidate": "global RNG side effect: pyspi/lib/ids/numpy_dependence.py:11-12 np.random.seed(1717) at import replaces a user seed set before the first Calculator()",
     "outcome": "confirmed",
     "evidence": ("misc.ids|iid_gaussian|64|pipeline|rng-import (seed(123) then import pyspi.lib.ids: state equals seed(1717), first draw 0.35547; pyspi.calculator import alone "
                  "does not reseed; IDS consumes no RNG and is identical under seeds 1 and 2); misc.ids|iid_gaussian|64|pipeline|rng-calculator (first Calculator() reseeds, "
                  "second keeps the user seed 5); misc.ids|iid_gaussian|64|pipeline|rng-cross-spi (cov_MinCovDet identical, 2.30186, under user seeds 1 and 2 set before "
                  "Calculator() and equal to seed 1717 without ids; seeds 1/2 without ids give 2.64277/2.24323; computing ids does not shift the stream MinCovDet sees). "
                  "Not in KNOWN_ISSUES.md; inherited from upstream. sgddtw was not run; it draws from the same global stream (tests/README.md:146).")},
    {"candidate": "null bias undocumented: GitBook 'a score of 0 indicating independence' vs a positive finite-sample null level",
     "outcome": "confirmed",
     "evidence": ("misc.ids|iid_gaussian|{64,256,1024,4096}|pipeline|null: pyspi off-diagonal mean 0.2354/0.1135/0.0647/0.0324 vs own MC 0.2579/0.1273/0.0648/0.0324 "
                  "(mean x sqrt(T) about 2.07), all pass; misc.ids|cointegrated|1024|pipeline|null-randomwalk: random-walk null MC mean 0.568, pyspi 0.465. This is "
                  "estimator behaviour (README: finite-sample bias is not incorrectness); the deviation is in the documentation.")},
    {"candidate": "preprocessing differs from the paper's reported setting (z-score vs min-max [0, 8])",
     "outcome": "confirmed",
     "evidence": ("misc.ids|nonlinear_dependence|4096|pipeline|paper-minmax08 max_abs 0.680, misc.ids|contaminated|4096|pipeline|paper-minmax08 0.357, "
                  "misc.ids|anm|4096|pipeline|paper-minmax08 0.178, misc.ids|bivariate_gaussian|4096|pipeline|paper-minmax08 0.054 (expected fails); pyspi itself "
                  "reproduces the paper setting on min-max rows (4 minmax08 kernel runs <= 3.3e-16). Variant, not an error.")},
    {"candidate": "last-bit asymmetry from the missing mirror (np.corrcoef division order)",
     "outcome": "confirmed",
     "evidence": ("misc.ids|iid_gaussian|4096|pipeline|symmetry: max|A - A^T| 2.2e-16, 52 of 65 square outputs not bitwise symmetric. Same class as REVIEW M2, "
                  "which does not list IDS; negligible in value.")},
    {"candidate": "unsupported p_norm returns a 4-D array that the Calculator cannot store",
     "outcome": "confirmed",
     "evidence": ("misc.ids|bivariate_gaussian|256|pipeline|pnorm-unsupported: pnorm 3 and '2' give compute_IDS ndim 4; Calculator block all NaN, MetricReport failed, "
                  "ValueError at P = 4 (fill_diagonal) and AssertionError at P = 6 (table store), all four cases. Only reachable with a non-default config.")},
]
c["checks_run"] = [
    {"run_ids": ["misc.ids|iid_gaussian|1024|kernel|kids", "misc.ids|bivariate_gaussian|1024|kernel|kids", "misc.ids|nonlinear_dependence|1024|kernel|kids",
                 "misc.ids|anm|1024|kernel|kids", "misc.ids|contaminated|1024|kernel|kids", "misc.ids|logistic_maps|1024|kernel|kids",
                 "misc.ids|delayed_noise|1024|kernel|kids", "misc.ids|iid_gaussian|64|kernel|kids", "misc.ids|iid_gaussian|256|kernel|kids",
                 "misc.ids|iid_gaussian|4096|kernel|kids", "misc.ids|nonlinear_dependence|64|kernel|kids", "misc.ids|nonlinear_dependence|256|kernel|kids",
                 "misc.ids|nonlinear_dependence|4096|kernel|kids", "misc.ids|scaled_offset|1024|kernel|kids"],
     "reference": "refs/ids.py:chk_kids (_kernels_basic_misc.ids; eq6_ids as extra key)",
     "outcome": "14/14 pass; max_abs <= 7.8e-16; Eq. 6 transcription vs kernel <= 1.0e-15"},
    {"run_ids": ["misc.ids|iid_gaussian|1024|pipeline|kids", "misc.ids|bivariate_gaussian|1024|pipeline|kids", "misc.ids|nonlinear_dependence|1024|pipeline|kids",
                 "misc.ids|anm|1024|pipeline|kids", "misc.ids|contaminated|1024|pipeline|kids", "misc.ids|logistic_maps|1024|pipeline|kids",
                 "misc.ids|delayed_noise|1024|pipeline|kids", "misc.ids|iid_gaussian|64|pipeline|kids", "misc.ids|trending|1024|pipeline|kids",
                 "misc.ids|trending|1024|pipeline-detrend|kids"],
     "reference": "refs/ids.py:chk_kids on own z-scored (ddof=1) / detrended rows",
     "outcome": "10/10 pass; max_abs <= 2.2e-15"},
    {"run_ids": ["misc.ids|nonlinear_dependence|1024|kernel|eq6-bw0.25", "misc.ids|nonlinear_dependence|1024|kernel|eq6-bw0.5", "misc.ids|nonlinear_dependence|1024|kernel|eq6-bw1.0",
                 "misc.ids|iid_gaussian|1024|kernel|eq6-bw0.25", "misc.ids|iid_gaussian|1024|kernel|eq6-bw0.5", "misc.ids|iid_gaussian|1024|kernel|eq6-bw1.0",
                 "misc.ids|nonlinear_dependence|1024|pipeline|pnorm1", "misc.ids|nonlinear_dependence|1024|pipeline|pnorm2"],
     "reference": "refs/ids.py:chk_eq6 (paper Eq. 6/11/12, B = sqrt(1/(2*bandwidth)))",
     "outcome": "8/8 pass; max_abs <= 4.4e-16"},
    {"run_ids": ["misc.ids|bivariate_gaussian|256|pipeline|identical", "misc.ids|shared_envelope|256|pipeline|identical-pair",
                 "misc.ids|bivariate_gaussian|1024|pipeline|signflip", "misc.ids|bivariate_gaussian|1024|kernel|signflip",
                 "misc.ids|scaled_offset|1024|pipeline|invariance"],
     "reference": "refs/ids.py:chk_identical, chk_signflip, chk_invariance (analytic)",
     "outcome": "5/5 pass; identical = 1 exactly (0.0), sign flip 1.1e-16, scaled_offset 5.6e-17"},
    {"run_ids": ["misc.ids|bivariate_gaussian|256|pipeline|truth-p01", "misc.ids|bivariate_gaussian|256|pipeline|truth-p23",
                 "misc.ids|bivariate_gaussian|1024|pipeline|truth-p01", "misc.ids|bivariate_gaussian|1024|pipeline|truth-p23",
                 "misc.ids|bivariate_gaussian|4096|pipeline|truth-p01", "misc.ids|bivariate_gaussian|4096|pipeline|truth-p23"],
     "reference": "refs/ids.py:chk_truth (Gauss-Hermite population value + own MC)",
     "outcome": "6/6 pass; max_z <= 0.93; population 0.2641 / 0.7349"},
    {"run_ids": ["misc.ids|iid_gaussian|64|pipeline|null", "misc.ids|iid_gaussian|256|pipeline|null", "misc.ids|iid_gaussian|1024|pipeline|null",
                 "misc.ids|iid_gaussian|4096|pipeline|null", "misc.ids|cointegrated|1024|pipeline|null-randomwalk"],
     "reference": "refs/ids.py:chk_null (own MC, 2000 draws, familywise se)",
     "outcome": "5/5 pass; max_z <= 1.50; iid MC mean x sqrt(T) 2.04-2.07"},
    {"run_ids": ["misc.ids|nonlinear_dependence|1024|pipeline|structure", "misc.ids|nonlinear_dependence|4096|pipeline|structure",
                 "misc.ids|anm|1024|pipeline|structure", "misc.ids|bivariate_gaussian|1024|pipeline|structure",
                 "misc.ids|delayed_noise|4096|pipeline|zero-lag", "misc.ids|trending|1024|pipeline-detrend|structure"],
     "reference": "refs/ids.py:chk_structure (known structure + per-pair permutation bound)",
     "outcome": "6/6 pass; dependent margins >= 0.152, independent pairs <= 0.84 of their bound"},
    {"run_ids": ["misc.ids|nonlinear_dependence|4096|kernel|minmax08", "misc.ids|contaminated|4096|kernel|minmax08", "misc.ids|anm|4096|kernel|minmax08",
                 "misc.ids|bivariate_gaussian|4096|kernel|minmax08"],
     "reference": "refs/ids.py:chk_minmax (Eq. 6 on min-max [0, 8] rows)",
     "outcome": "4/4 pass; max_abs <= 3.3e-16"},
    {"run_ids": ["misc.ids|nonlinear_dependence|4096|pipeline|paper-minmax08", "misc.ids|contaminated|4096|pipeline|paper-minmax08",
                 "misc.ids|anm|4096|pipeline|paper-minmax08", "misc.ids|bivariate_gaussian|4096|pipeline|paper-minmax08"],
     "reference": "refs/ids.py:chk_minmax (pyspi default vs the paper's reported setting)",
     "outcome": "0/4 pass (expected): max_abs 0.680 / 0.357 / 0.178 / 0.054, the size of the preprocessing effect"},
    {"run_ids": ["misc.ids|iid_gaussian|4096|kernel|hidden-dependence", "misc.ids|iid_gaussian|4096|pipeline|hidden-dependence"],
     "reference": "refs/ids.py:chk_hidden (probes/ids_probes.py:hidden_construction; own MC under the law and under the null)",
     "outcome": "2/2 pass; pyspi 0.0436 / 0.0435 vs null mean 0.0325 / 0.0324 while Corr(g(X), g(Y)) = 0.474"},
    {"run_ids": ["misc.ids|bivariate_gaussian|256|pipeline|pnorm-unsupported"],
     "reference": "refs/ids.py:chk_pnorm_unsupported",
     "outcome": "1/1 pass; all-NaN block, report failed, ValueError (P=4) / AssertionError (P=6)"},
    {"run_ids": ["misc.ids|iid_gaussian|64|pipeline|rng-import", "misc.ids|iid_gaussian|64|pipeline|rng-calculator", "misc.ids|iid_gaussian|64|pipeline|rng-cross-spi"],
     "reference": "refs/ids.py:chk_rng (np.random.RandomState stream; fresh interpreters)",
     "outcome": "3/3 pass; reseed to 1717 on first import reproduced, IDS consumes no RNG, user seed before Calculator() ignored by MinCovDet"},
    {"run_ids": ["misc.ids|iid_gaussian|4096|pipeline|symmetry"],
     "reference": "refs/ids.py:chk_symmetry",
     "outcome": "1/1 pass; max|A - A^T| 2.2e-16 over 65 outputs"},
]
yaml.safe_dump(r, open(P, "w"), sort_keys=False, width=150, allow_unicode=True)
print("ok")
