import sys, time, numpy as np, importlib.util
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); import make_data
spec=importlib.util.spec_from_file_location('p','/media/dan/Data/git/pyspi/audit/checks/probes/ids_probes.py'); p=importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
coef, scale, eps, sup, ortho = p.hidden_construction(); print('hidden', eps, sup, ortho)
s = p.hidden_sample(4096, 42); g = p.hidden_g(s, coef, scale); print('corr g', np.corrcoef(g)[0,1], s.mean(1), s.std(1))
x = make_data.load('iid_gaussian',64)['x']
for fn in ['rng_import','rng_calculator','rng_cross_spi']:
    t=time.time(); print(fn, getattr(p,fn)(x,{}), time.time()-t)
xb = make_data.load('bivariate_gaussian',256)['x']
t=time.time(); print(p.pnorm_calculator(xb,{}), time.time()-t)
rs=np.random.RandomState(1717); print('rs1717', rs.random_sample(2)); print('rs123', np.random.RandomState(123).random_sample(), 'rs5', np.random.RandomState(5).random_sample())
