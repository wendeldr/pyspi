import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); import make_data
from sklearn.covariance import MinCovDet
from scipy.stats import zscore
for name in ['iid_gaussian','contaminated','cointegrated','logistic_maps_chaotic','anm','nonlinear_dependence','sparse_precision','var2_chain','delayed_noise']:
  for T in [64,256,1024]:
    x = zscore(make_data.load(name,T)['x'],axis=1,ddof=1).T
    vals=[]
    for s in range(6):
        np.random.seed(s); vals.append(MinCovDet().fit(x).covariance_[0,1])
    print(name,T,np.ptp(vals))
