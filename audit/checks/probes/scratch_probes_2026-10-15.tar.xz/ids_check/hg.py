import numpy as np, math
from numpy.polynomial.hermite_e import hermegauss
def feats(x): return np.stack([np.exp(-0.5*x**2)*x**k/math.sqrt(math.factorial(k)) for k in range(6)])
t,w=hermegauss(150); w=w/w.sum()
Bm=np.vstack([np.ones_like(t),feats(t)]); sw=np.sqrt(w)
grid=np.linspace(-14,14,100001); Bg=np.vstack([np.ones_like(grid),feats(grid)])
cands = {f'cos{o}':(lambda x,o=o: np.cos(o*x)) for o in [1,2,3,4,6,8]}
cands.update({f'sin{o}':(lambda x,o=o: np.sin(o*x)) for o in [1,2,3,4,6,8]})
cands['x^2']=lambda x: x**2; cands['x^3']=lambda x:x**3
cands['tanh3x']=lambda x: np.tanh(3*x); cands['sgn']=lambda x: np.tanh(50*x)
cands['cos2x2']=lambda x: np.cos(x**2)
for n,f in cands.items():
    c,*_=np.linalg.lstsq((Bm*sw).T,f(t)*sw,rcond=None); r=f(t)-c@Bm; s=np.sqrt(np.sum(w*r**2))
    sup=np.max(np.abs((f(grid)-c@Bg)/s)) 
    print(n, 'scale',round(s,4),'sup',round(sup,3),'eps',round(0.95/sup**2,4))
