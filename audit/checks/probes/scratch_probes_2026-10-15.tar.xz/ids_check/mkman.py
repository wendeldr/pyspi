import json
U="misc.ids"; runs=[]
def add(ds,T,path,tag,ident="ids",probe=None,processes=None):
    runs.append(dict(run_id=f"{U}|{ds}|{T}|{path}|{tag}",unit_id=U,identifier=ident,dataset=ds,T=T,path=path,
                     processes=processes,seed=42,probe=probe))
P="probes/ids_probes.py"
seven=["iid_gaussian","bivariate_gaussian","nonlinear_dependence","anm","contaminated","logistic_maps","delayed_noise"]
# A/B exact vs _kernels_basic_misc.ids
for ds in seven: add(ds,1024,"kernel","kids")
for ds in ["iid_gaussian","nonlinear_dependence"]:
    for T in [64,256,4096]: add(ds,T,"kernel","kids")
add("scaled_offset",1024,"kernel","kids")
for ds in seven: add(ds,1024,"pipeline","kids")
add("iid_gaussian",64,"pipeline","kids")
add("trending",1024,"pipeline","kids")
add("trending",1024,"pipeline-detrend","kids")
# invariance
add("scaled_offset",1024,"pipeline","invariance")
add("bivariate_gaussian",1024,"pipeline","signflip",ident=None,probe={"module":P,"function":"ids_transformed"})
add("bivariate_gaussian",1024,"kernel","signflip",ident=None,probe={"module":P,"function":"ids_transformed"})
# analytic identical
add("bivariate_gaussian",256,"pipeline","identical",ident=None,probe={"module":P,"function":"ids_transformed"})
add("shared_envelope",256,"pipeline","identical-pair",processes=[0,2])
# Eq. 6 transcription across bandwidths
for ds in ["nonlinear_dependence","iid_gaussian"]:
    for bw in ["0.25","0.5","1.0"]:
        add(ds,1024,"kernel",f"eq6-bw{bw}",ident=None,probe={"module":P,"function":"ids_param"})
# Eq. 12 p = 1, 2
for p in [1,2]: add("nonlinear_dependence",1024,"pipeline",f"pnorm{p}",ident=None,probe={"module":P,"function":"ids_param"})
# paper preprocessing
for ds in ["nonlinear_dependence","contaminated","anm","bivariate_gaussian"]:
    add(ds,4096,"kernel","minmax08",ident=None,probe={"module":P,"function":"ids_transformed"})
    add(ds,4096,"pipeline","paper-minmax08")
# population truth (statistical)
for T in [256,1024,4096]:
    add("bivariate_gaussian",T,"pipeline","truth-p01",processes=[0,1])
    add("bivariate_gaussian",T,"pipeline","truth-p23",processes=[2,3])
# null (statistical)
for T in [64,256,1024,4096]: add("iid_gaussian",T,"pipeline","null")
add("cointegrated",1024,"pipeline","null-randomwalk",processes=[2,3])
# structure / index convention (qualitative)
add("nonlinear_dependence",1024,"pipeline","structure")
add("nonlinear_dependence",4096,"pipeline","structure")
add("anm",1024,"pipeline","structure")
add("bivariate_gaussian",1024,"pipeline","structure")
add("delayed_noise",4096,"pipeline","zero-lag")
add("trending",1024,"pipeline-detrend","structure")
# hidden dependence (population IDS-max = 0, dependent)
add("iid_gaussian",4096,"kernel","hidden-dependence",ident=None,probe={"module":P,"function":"hidden_dependence"})
add("iid_gaussian",4096,"pipeline","hidden-dependence",ident=None,probe={"module":P,"function":"hidden_dependence"})
# unsupported pnorm through Calculator
add("bivariate_gaussian",256,"pipeline","pnorm-unsupported",ident=None,probe={"module":P,"function":"pnorm_calculator"})
# RNG side effects
for t in ["rng-import","rng-calculator","rng-cross-spi"]:
    add("iid_gaussian",64,"pipeline",t,ident=None,probe={"module":P,"function":t.replace('-','_')})
# symmetry summary over the family
add("iid_gaussian",4096,"pipeline","symmetry")
ids=[r["run_id"] for r in runs]; assert len(ids)==len(set(ids))
json.dump({"family":"ids","runs":runs},open('/media/dan/Data/git/pyspi/audit/checks/manifest/ids.json','w'),indent=1)
print(len(runs))
