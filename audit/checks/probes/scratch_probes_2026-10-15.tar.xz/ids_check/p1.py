import time, sys, numpy as np
t0=time.time()
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); import make_data
x = make_data.load('contaminated',256)['x']
x = np.vstack([x, make_data.load('iid_gaussian',256)['x'][:2]])
seed=int(sys.argv[1]); after=len(sys.argv)>2
if not after: np.random.seed(seed)
from pyspi.calculator import Calculator
c=Calculator(dataset=x, configfile='cfg.yaml')
if after: np.random.seed(seed)
c.compute()
print("RESULT", seed, after, c.table['cov_MinCovDet'].to_numpy()[0,1], time.time()-t0)
