from common import *
from units_a import chk, U

TE_PYSPI = [
  "pyspi/statistics/infotheory.py:320-341 TransferEntropy(JIDTBase, Directed).__init__: estimator absent or 'gaussian' -> identifier 'gc' (:338-339); _calc = _getcalc('TransferEntropy') (:341)",
  "pyspi/statistics/infotheory.py:376-391 bivariate(i,j): _set_theiler_window (no-op); _calc.initialise(); src, targ = data.to_numpy(squeeze=True)[[i, j]]; setObservations(src, targ); computeAverageLocalOfObservations(); exception -> warning + NaN",
]
GC_DOC = "supplement §1.4.6, p.11 (supplement.txt:500-511): 'Granger causality [40] is obtained by assessing directed dependence of x -> y as the predictive power of a bivariate autoregressive model (comprising x and y) over the univariate autoregressive model (with y only). The statistic included in our framework is the log-ratio of residual variance for the two models, which is a variant of Granger causality popularized by Geweke [41] later found to be equivalent to transfer entropy with a Gaussian estimator [38]'; keywords 'directed, linear, unsigned, bivariate, time-dependent'. GitBook information-theory.md:90-107 same text. Supplement §1.4.5, p.10-11 (supplement.txt:476-493) defines k, kt (target) and l, lt (source)."
GC_CANON_REF = "Geweke J. 1982, J Am Stat Assoc 77:304-313, eq. (2.3)-(2.4) F_{X->Y} = ln(var(e_restricted)/var(e_full)); Barnett L., Barrett A.B. & Seth A.K. 2009, Phys Rev Lett 103:238701 (F_{X->Y} = 2 TE_{X->Y} for Gaussian variables); Schreiber T. 2000, Phys Rev Lett 85:461, eq. (4)"

U["infotheory.te.gaussian_k-1_kt-1_l-1_lt-1"] = dict(
 metric_name_standard="Gaussian transfer entropy with target history k=1 and source history l=1 (= one half of Geweke's lag-1 Granger causality log variance ratio)",
 canonical_ref=GC_CANON_REF,
 canonical_definition="TE_{X->Y} = I(X_t; Y_{t+1} | Y_t) = 0.5*ln(sigma^2(Y_{t+1}|Y_t) / sigma^2(Y_{t+1}|Y_t,X_t)) = F_{X->Y}/2, where F = ln(RSS_restricted/RSS_full) is Geweke's GC",
 documented_definition=GC_DOC,
 delegate_lib=DELEGATE + "gaussian.TransferEntropyCalculatorGaussian -> TransferEntropyCalculatorViaCondMutualInfo -> ConditionalMutualInfoCalculatorMultiVariateGaussian",
 implemented_as="For each ordered pair (i=source, j=target) on z-scored data: N = T-1 samples (t = 0..T-2) of (x_i(t), x_j(t+1), x_j(t)); JIDT Gaussian CMI with ddof=1 covariance: TE = 0.5*ln(det S(x_i(t),x_j(t)) det S(x_j(t+1),x_j(t)) / (det S(all three) var x_j(t))) = 0.5*ln(RSS_r/RSS_f) of the OLS-with-intercept regressions x_j(t+1) ~ x_j(t) and x_j(t+1) ~ x_j(t) + x_i(t) on the same samples. Properties confirmed by getProperty: k_HISTORY=1, k_TAU=1, l_HISTORY=1, l_TAU=1, DELAY=1, AUTO_EMBED_METHOD=NONE, BIAS_CORRECTION=false, NORMALISE=false.",
 implementation_trace=[CALC, DATA, DIRECTED, INIT, SETUP, GETCALC] + TE_PYSPI + [
   "pyspi/statistics/infotheory.py:357-365 no auto-embedding: setProperty k_HISTORY, k_TAU, l_HISTORY, l_TAU; identifier += '_k-1_kt-1_l-1_lt-1'",
   "pyspi/config.yaml:604-606 TransferEntropy config: estimator gaussian, k_history 1, l_history 1"] + TE_JIDT,
 deviation_from_documented="Factor 1/2: the documented statistic is 'the log-ratio of residual variance for the two models' (Geweke F), but the returned value is the Gaussian transfer entropy = F/2. Probe var2_bivariate_T1024: pyspi A[0,1] = 0.14832534 = 0.5*ln(RSS_r/RSS_f) (numpy OLS, agreement 1e-15), so F = 0.29665. Ranking is unaffected. Otherwise matches (one-lag models; time delays kt=lt=1).",
 deviation_from_canonical="none as Gaussian TE (Barnett et al. 2009); as Geweke GC the value is F/2 (candidate above). Model order fixed at 1 lag for both target and source (a configuration choice; under-specified for the VAR(2) test data). No bias correction.",
 units_and_range="nats; [0, +inf); asymmetric; scale invariant; exactly 0 when the target past makes the source linearly redundant (probe shared_envelope identical channels -> 0.0)",
 direction_convention="A[i,j] = TE from x_i (source) to x_j (target) (bivariate docstring infotheory.py:379, src/targ order :383). Probe var2_bivariate_T1024 (x0 drives x1): A[0,1]=0.1483 > A[1,0]=0.0127",
 symmetry_expected="asym",
 already_documented="tests/README.md bug 1 (te_symbolic_* == gc_gaussian_*, so te_symbolic_k-1 duplicates this unit); REVIEW.md 'current metadata for gc_gaussian_k-1_kt-1_l-1_lt-1 lacks pyspi labels' (metadata only)",
 new_finding_candidates=[
   "CANDIDATE (documented-value mismatch): gc_gaussian returns TE = F/2, not the documented 'log-ratio of residual variance' F. Evidence: JIDT CMI formula 0.5*ln(...) (ConditionalMutualInfoCalculatorMultiVariateGaussian.java:464-466); probe var2_bivariate_T1024 A[0,1] = 0.14832534 vs numpy 0.5*ln(RSS_r/RSS_f) = 0.14832533717957885 and A[1,0] = 0.01265255 vs 0.012652549306752473.",
 ],
 proposed_checks=[
   chk(["var2_bivariate","gauss_ar1_pair","delayed_noise","iid_gaussian","logistic_maps"], "pipeline", "from-scratch numpy OLS with intercept: F = ln(RSS(x_j(t+1) ~ 1 + x_j(t)) / RSS(x_j(t+1) ~ 1 + x_j(t) + x_i(t))) on t = 0..T-2; reference TE = F/2", "independent-impl", "tolerance", "pyspi equals F/2 to 1e-12 on every ordered pair; pyspi/F = 0.5 exactly (documents the factor)"),
   chk(["var2_bivariate"], "pipeline", "analytic population TE for k=l=1 from the VAR(2) autocovariances (companion-form discrete Lyapunov via scipy.linalg.solve_discrete_lyapunov, then Gamma(0), Gamma(1) of (x0, x1)); 0.5*ln of conditional variance ratio", "analytic", "statistical", "within 3 sampling SDs at T=4096; reverse direction (1->0) population value > 0 is possible because the lag-1 model is misspecified, record it"),
   chk(["var2_bivariate","delayed_noise"], "pipeline", "known ground truth: var2_bivariate x0 -> x1 only; delayed_noise x0 leads x1 by one sample (TE 0->1 approx 0.5*ln(101) = 2.3076, 1->0 approx 0)", "analytic", "direction", "A[0,1] > A[1,0] in both datasets for T >= 256; establishes A[i,j] = TE(i -> j)"),
   chk(["iid_gaussian"], "pipeline", "analytic null: 2*N*TE_hat ~ chi-square(1) (Barnett & Bossomaier 2012 PRL 109:138105)", "analytic", "statistical", "mean over ordered pairs approx 1/(2(T-1)); no negative values"),
 ],
)

U["infotheory.te.gaussian_auto-MAX_CORR_AIS_kmax-10_taumax-2"] = dict(
 metric_name_standard="Gaussian transfer entropy (half Geweke GC) with target and source embeddings selected by JIDT's MAX_CORR_AIS rule",
 canonical_ref=GC_CANON_REF + "; embedding selection: Lizier J.T. 2014, Front Robot AI 1:11 (JIDT) and JIDT javadoc ActiveInfoStorageCalculatorViaMutualInfo.AUTO_EMBED_METHOD_MAX_CORR_AIS ('maximise bias-corrected AIS')",
 canonical_definition="TE_{X->Y} = I(X^{(l,lt)}_t; Y_{t+1} | Y^{(k,kt)}_t) = 0.5*ln(RSS_r/RSS_f) with (k,kt) = argmax over k<=10, kt<=2 of [I(Y^{(k,kt)}_t; Y_{t+1}) - k/(2N)] on the target and (l,lt) chosen the same way on the source's own AIS",
 documented_definition=GC_DOC + " For the optimised variant: supplement §1.4.5, p.11 (supplement.txt:487-491): 'The optimized parameters are inferred by choosing the embedding parameters (up to a maximum embedding length of 10, denoted by k-max-10, and maximum time delay of 2, tau-max-2) that maximize a univariate information-theoretic measure known as active information storage (see the MAX_CORR_AIS method of [32] for details)'.",
 delegate_lib=DELEGATE + "gaussian.TransferEntropyCalculatorGaussian with AUTO_EMBED_METHOD=MAX_CORR_AIS (auto-embedding via gaussian.ActiveInfoStorageCalculatorGaussian)",
 implemented_as="For each ordered pair (i=source, j=target) on z-scored data, JIDT first runs MAX_CORR_AIS on the target alone: for k = 1..10 and tau = 1..2 (tau skipped when k = 1) it computes the Gaussian MI between the k-dim delay vector (spacing tau) and the next sample, N = T-(k-1)tau-1, subtracts the analytic chi-square null mean k/(2N), and keeps the argmax -> (k, k_tau); the same search on the source alone gives (l, l_tau). It then computes Gaussian TE with those embeddings and delay 1 (start = max((k-1)k_tau, (l-1)l_tau)). The search is repeated for every ordered pair. No bias correction of the final TE. Probe var2_bivariate_T1024: selected k=2, k_tau=1 for target x1 and l=9, l_tau=1 for source x0.",
 implementation_trace=[CALC, DATA, DIRECTED, INIT, SETUP, GETCALC] + TE_PYSPI + [
   "pyspi/statistics/infotheory.py:343-355 auto_embed_method given: setProperty AUTO_EMBED_METHOD='MAX_CORR_AIS', AUTO_EMBED_K_SEARCH_MAX='10', AUTO_EMBED_TAU_SEARCH_MAX='2'; identifier += '_k-max-10_tau-max-2'",
   "pyspi/config.yaml:599-602 TransferEntropy config: estimator gaussian, auto_embed_method MAX_CORR_AIS, k_search_max 10, tau_search_max 2"] + TE_JIDT + [
   J + "measures/continuous/TransferEntropyCalculatorViaCondMutualInfo.java preFinaliseAddObservations :701-850: AIS Gaussian calculator for a Gaussian CMI (:732), props (BIAS_CORRECTION=false, NOISE_SEED=42) copied (:752), target embedded first (:779 -> k, k_tau), then the source with the same AIS rule for MAX_CORR_AIS (:794 -> l, l_tau); start time recomputed :847-849",
   J + "measures/continuous/ActiveInfoStorageCalculatorViaMutualInfo.java MAX_CORR_AIS loop :579-615 (k = 1..k_search_max, tau = 1..tau_search_max, thisAIS -= computeAdditionalBiasToRemove() :594, tau loop broken for k == 1 :605); addObservationsWithGivenParams :438-454 (past = makeDelayEmbeddingVector(x, k, tau, (k-1)tau, N), next = x[(k-1)tau+1 ...]); prepareMICalculator :669-673",
   V + "measures/continuous/gaussian/ActiveInfoStorageCalculatorGaussian.java :73/:97 Gaussian MI calculator; computeAdditionalBiasToRemove :152-170 returns ChiSquareMeasurementDistribution mean (Boolean.getBoolean(...) at :154 reads a JVM system property, so biasCorrected is always false and the analytic correction is always subtracted, which is also the intended outcome with BIAS_CORRECTION=false)",
   V + "utils/ChiSquareMeasurementDistribution.java :100-102 meanOfUncorrectedDistribution = df/(2N) with df = k*1; getMeanOfDistribution :150-156",
 ],
 deviation_from_documented="Embedding search matches the documented MAX_CORR_AIS description (k-max-10, tau-max-2). Same factor-1/2 issue as the fixed-lag unit (value is TE = F/2, not the log-ratio F). Not stated in the docs: the source embedding (l, lt) is chosen from the source's own AIS, not from TE, and the search is repeated per ordered pair so different pairs use different model orders.",
 deviation_from_canonical="As Gaussian TE given the chosen embeddings: none (probe: from-scratch numpy re-implementation of the AIS search and TE reproduced the selected parameters for every ordered pair and the values to <= 6e-14 on var2_bivariate T=64/1024 and delayed_noise T=256). The selection rule is JIDT-specific (AIC-like penalty k/(2N)), not a standard Geweke model-order criterion; source order chosen by source predictability rather than by the bivariate model.",
 units_and_range="nats; [0, +inf); asymmetric; scale invariant",
 direction_convention="A[i,j] = TE(x_i -> x_j) with embeddings selected per pair. Probe var2_bivariate_T1024: A[0,1]=0.1631 > A[1,0]=0.0011",
 symmetry_expected="asym",
 already_documented="tests/README.md worth knowing ('auto-embedding TE kraskov equals fixed k=1 on cml7' concerns the kraskov variant, not this one); REVIEW.md GC metadata note",
 new_finding_candidates=[
   "CANDIDATE (documented-value mismatch): value is Gaussian TE = Geweke F/2, not the documented log-ratio F (same mechanism as the fixed-lag unit).",
   "CANDIDATE (estimator behaviour): MAX_CORR_AIS selection is unstable because penalised AIS curves are nearly flat. Probe var2_bivariate_T1024 source x0 (a true AR(2)): penalised AIS for k=2..10 (tau=1) ranged 0.11649..0.11801 and k=9 was selected; delayed_noise_T256: white-noise x0 was given k=7, and x1/x2 (white noise copies) k=10. Different pairs therefore mix very different model orders.",
   "CANDIDATE (efficiency, value-neutral): the target and source AIS searches (19 MI fits each) are recomputed inside every bivariate call (TransferEntropyCalculatorViaCondMutualInfo.java:865-869 via finaliseAddObservations), i.e. 2*P*(P-1) searches where P are sufficient; results are deterministic, so caching per process would be bit-identical.",
 ],
 proposed_checks=[
   chk(["var2_bivariate","delayed_noise","gauss_ar1_pair","logistic_maps"], "pipeline", "from-scratch numpy re-implementation: penalised AIS(k,tau) = Gaussian MI(delay vector, next sample) - k/(2N) over k=1..10, tau=1..2 (tau skipped at k=1), argmax with strict '>' tie rule; then TE = 0.5*ln(RSS_r/RSS_f) with the selected (k,kt,l,lt) and delay 1", "independent-impl", "tolerance", "selected (k,kt,l,lt) identical to calc.getProperty for every ordered pair; values agree to 1e-10"),
   chk(["var2_bivariate","delayed_noise"], "pipeline", "known ground truth (x0 -> x1)", "analytic", "direction", "A[0,1] > A[1,0] for T >= 256"),
   chk(["iid_gaussian","var2_bivariate"], "pipeline", "statistical stability of the selected order: compare selected k against the true AR order (0 for white noise, 2 for var2_bivariate) across T = 64..4096", "analytic", "qualitative", "report the selected (k,kt) per process and T; the hypothesis is that over-long orders are frequent even at T=4096"),
 ],
)

U["infotheory.te.symbolic"] = dict(
 metric_name_standard="Symbolic transfer entropy (documented) - actually Gaussian transfer entropy with k=1 or k=10, l=1",
 canonical_ref="Staniek M. & Lehnertz K. 2008, Phys Rev Lett 100:158101 (symbolic transfer entropy on ordinal patterns)",
 canonical_definition="STE_{X->Y} = sum p(s^y_{t+delta}, s^y_t, s^x_t) log [p(s^y_{t+delta} | s^y_t, s^x_t) / p(s^y_{t+delta} | s^y_t)] where s are ordinal (permutation) symbols of embedding vectors (order m, delay l)",
 documented_definition="supplement §1.4.5, p.11 (supplement.txt:492-497): 'We also include a symbolic estimator for transfer entropy (denoted by the modifier symbolic), with details in [39]' ([39] = Staniek & Lehnertz 2008); listed as 78. te_symbolic_k-1_kt-1_l-1_lt-1 and 79. te_symbolic_k-10_kt-1_l-1_lt-1. GitBook information-theory.md:206-231 same.",
 delegate_lib=DELEGATE + "gaussian.TransferEntropyCalculatorGaussian (estimator 'symbolic' falls through the else branch of _getcalc)",
 implemented_as="JIDTBase.__init__ keeps identifier 'te' + '_symbolic', adds label 'symbolic' and returns early (infotheory.py:45-52); _getcalc('TransferEntropy') has no 'symbolic' branch so the else branch builds TransferEntropyCalculatorGaussian (:129-130). The result is Gaussian TE (= Geweke F/2) with k_HISTORY = 1 or 10, k_TAU = 1, l_HISTORY = 1, l_TAU = 1, delay 1 on z-scored data. No ordinal symbolisation happens anywhere.",
 implementation_trace=[CALC, DATA, DIRECTED,
   "pyspi/statistics/infotheory.py:338-341 TransferEntropy.__init__: estimator 'symbolic' -> identifier stays 'te'; _calc = _getcalc('TransferEntropy')",
   "pyspi/statistics/infotheory.py:45-52 JIDTBase.__init__: estimator == 'symbolic' -> labels += ['symbolic'], _dyn_corr_excl = None, return (no 'linear' label)",
   "pyspi/statistics/infotheory.py:124-130 _getcalc('TransferEntropy'): only 'kernel' and 'kraskov' branches; 'symbolic' -> gaussian.TransferEntropyCalculatorGaussian",
   SETUP,
   "pyspi/statistics/infotheory.py:357-365 fixed embedding properties k_HISTORY (1 or 10), k_TAU 1, l_HISTORY 1, l_TAU 1",
   "pyspi/statistics/infotheory.py:376-391 bivariate as for gc_gaussian",
   "pyspi/config.yaml:608-614 configs: estimator symbolic with k_history 1 / 10, l_history 1"] + TE_JIDT,
 deviation_from_documented="Complete: documented as symbolic TE after Staniek & Lehnertz 2008, implemented as linear-Gaussian TE. Probe var2_bivariate_T1024: te_symbolic_k-1 matrix bitwise equal to gc_gaussian_k-1 (np.array_equal True); te_symbolic_k-10 A[0,1] = 0.138939272 equals numpy 0.5*ln(RSS_r/RSS_f) with 10 target lags and 1 source lag (0.13893927237035966).",
 deviation_from_canonical="Complete (no ordinal patterns; Gaussian covariance estimator; continuous values).",
 units_and_range="nats; [0, +inf); asymmetric; scale invariant (STE would be invariant to monotone transforms, this is not)",
 direction_convention="A[i,j] = (Gaussian) TE from x_i to x_j, as for gc_gaussian. Probe var2_bivariate_T1024: k-1 A[0,1]=0.1483 > A[1,0]=0.0127; k-10 A[0,1]=0.1389 > A[1,0]=1.5e-6",
 symmetry_expected="asym",
 already_documented="tests/README.md bug 1 (TransferEntropy(estimator='symbolic') falls through to the Gaussian calculator, te_symbolic_* == gc_gaussian_*)",
 new_finding_candidates=[
   "CANDIDATE (elaboration of bug 1, metadata): the two te_symbolic identifiers are in the EEG selection; te_symbolic_k-1_kt-1_l-1_lt-1 is bitwise identical to gc_gaussian_k-1_kt-1_l-1_lt-1 (probe np.array_equal True) and te_symbolic_k-10 is Gaussian TE with 10 target lags (not any other configured SPI). Instance labels carry 'symbolic' but not 'linear' (probe labels: ['unsigned','embedding','infotheory','temporal','directed','symbolic']), so label-based grouping misclassifies a linear Gaussian measure as symbolic.",
 ],
 proposed_checks=[
   chk(["var2_bivariate","logistic_maps","delayed_noise"], "pipeline", "from-scratch numpy Gaussian TE = 0.5*ln(RSS_r/RSS_f) with k target lags (1 or 10), 1 source lag, delay 1", "independent-impl", "tolerance", "te_symbolic_k-1 and te_symbolic_k-10 equal the Gaussian reference to 1e-12 (documents the fall-through value)"),
   chk(["var2_bivariate","logistic_maps"], "pipeline", "pyspi gc_gaussian_k-1_kt-1_l-1_lt-1 output on the same Data (same-lineage identity test)", "same-lineage", "exact", "te_symbolic_k-1 bitwise equal to gc_gaussian_k-1"),
   chk(["logistic_maps","anm","nonlinear_dependence"], "kernel", "from-scratch Staniek-Lehnertz symbolic TE: ordinal patterns of order m=3 (delay 1) with np.argsort, plug-in probabilities over pattern triplets (s^y_{t+1}, s^y_t, s^x_t), log base e", "independent-impl", "qualitative", "pyspi values differ from STE (no agreement expected); STE is invariant to monotone transforms of the inputs while pyspi te_symbolic is not (check with x -> exp(x))"),
 ],
)
