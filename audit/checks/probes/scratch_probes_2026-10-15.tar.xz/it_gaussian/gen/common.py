V = "https://github.com/jlizier/jidt/blob/v1.6.1/java/source/infodynamics/"
J = "https://github.com/jlizier/jidt/blob/a9b6b3e77ca8c051f1031003474e2e35dd4a3269/java/source/infodynamics/"
H1 = "0.5*(1+ln 2pi) = 1.4189385332"
DELEGATE = ("JIDT infodynamics.jar bundled at pyspi/lib/jidt (labelled 1.6.1 by version-1.6.1.txt, but its class inventory includes "
            "EntropyCalculatorMultiVariateCommon, added upstream in commit 3d1f3fe on 2024-04-20; the Gaussian classes used here are unchanged "
            "between tag v1.6.1 and commit a9b6b3e apart from observation-ID/noise-seed bookkeeping) via JPype1==1.7.1 on OpenJDK 21; ")

CALC = "pyspi/calculator.py:294 Calculator.compute calls self._spis[spi].multivariate(self.dataset); :297 fill_diagonal NaN; :301-303 any exception from any pair -> the whole SPI entry becomes NaN"
DATA = "pyspi/data.py:184-195 preprocessing in Data.set_data: optional scipy.signal.detrend(axis=1), then (default normalise=True) scipy.stats.zscore(axis=1, ddof=1)"
DIRECTED = "pyspi/base.py:84-94 Directed.multivariate: for every ordered pair i != j, A[i,j] = self.bivariate(data, i=i, j=j)"
UNDIRECTED = "pyspi/base.py:132-138 Undirected.multivariate: Directed loop then A[li] = A.T[li] with li = tril_indices(P,-1) (lower triangle overwritten from the upper, i<j)"
INIT = "pyspi/statistics/infotheory.py:28-58 JIDTBase.__init__: _entropy_calc = _getcalc('entropy') (:36); identifier += '_gaussian' (:38); estimator 'gaussian' -> labels += ['linear'], _dyn_corr_excl = None (:53-55)"
SETUP = "pyspi/statistics/infotheory.py:84-93 _setup: every calculator gets setProperty('BIAS_CORRECTION','false') and setProperty('NOISE_SEED','42'); no NORMALISE property is set"
GETCALC = "pyspi/statistics/infotheory.py:103-134 _getcalc: 'gaussian' (and any unrecognised estimator) falls to the else branches -> gaussian.EntropyCalculatorMultiVariateGaussian (:111-112), gaussian.MutualInfoCalculatorMultiVariateGaussian (:120-123), gaussian.TransferEntropyCalculatorGaussian (:129-130)"
ENT_JIDT = [
  J + "measures/continuous/gaussian/EntropyCalculatorMultiVariateGaussian.java EntropyCalculatorMultiVariateGaussian (extends EntropyCalculatorMultiVariateCommon, :53-54): finaliseAddObservations :87-96 computes means and MatrixUtils.covarianceMatrix(observations, means); setCovariance :110-123 takes MatrixUtils.CholeskyDecomposition (throws on non-PD); computeAverageLocalOfObservations :162-175 returns 0.5*(d*(1+ln 2pi) + ln det(Sigma)) in nats",
  J + "measures/continuous/EntropyCalculatorMultiVariateCommon.java :66 normalise = true by default, but finaliseAddObservations :178-212 only stacks observations and adds noise if addNoise (default false, :70); no normalisation is applied for the Gaussian estimator; NOISE_SEED handled :133-139 (no effect without addNoise)",
  V + "utils/MatrixUtils.java covarianceMatrix(double[][], double[]) :3426-3439 -> covarianceTwoColumns :3370-3377 divides by (n-1) (ddof=1); CholeskyDecomposition :4496-4498 (tol 10e-10 = 1e-9) / :4528-4560 throws NonPositiveDefiniteMatrixException when a pivot <= tol; determinantViaCholeskyResult :4673-4680",
]
MI_JIDT = [
  V + "measures/continuous/gaussian/MutualInfoCalculatorMultiVariateGaussian.java constructor :123-125 normalise = false; setProperty BIAS_CORRECTION :160-174; finaliseAddObservations :204-220 -> MatrixUtils.covarianceMatrix(source, dest) (ddof=1); setCovariance :269-329 Cholesky of source, dest (redundant components pruned) and joint (L=null on joint linear redundancy); computeAverageLocalOfObservations :384-424 returns 0.5*ln|detS*detD/detJoint| (0 if a marginal is fully redundant, +Infinity if L==null; bias correction :418-421 off because pyspi sets BIAS_CORRECTION=false)",
  J + "measures/continuous/MutualInfoMultiVariateCommon.java finaliseAddObservations :574-630 (timeDiff = 0 default, normalise only if flag true :622, which the Gaussian constructor turned off)",
]
CMI_JIDT = V + "measures/continuous/gaussian/ConditionalMutualInfoCalculatorMultiVariateGaussian.java constructor :143-147 normalise = false; finaliseAddObservations :236-253 covariance of (var1=source past, var2=dest next, cond=dest past) with ddof=1; computeAverageLocalOfObservations :427-482 returns 0.5*ln(det(S_c1)*det(S_c2)/(det(S_all)*det(S_cc))) (0 if var1 or var2 fully redundant given cond; +Infinity if L==null); no bias correction (pyspi BIAS_CORRECTION=false)"
TE_JIDT = [
  V + "measures/continuous/gaussian/TransferEntropyCalculatorGaussian.java constructor :117-119 builds TransferEntropyCalculatorViaCondMutualInfo around ConditionalMutualInfoCalculatorMultiVariateGaussian; setProperty :165-180 forwards to parent",
  J + "measures/continuous/TransferEntropyCalculatorViaCondMutualInfo.java defaults k=1 (:98), delay=1 (:116); setProperty :435-471 (k_HISTORY, k_TAU, l_HISTORY, l_TAU, AUTO_EMBED_*; anything else forwarded to the CMI calculator and remembered in props :463-464); computeStartTimeForFirstDestEmbedding :375-384 = max((k-1)*k_tau, (l-1)*l_tau + delay - 1); finaliseAddObservations :865-869 -> prepareCMICalculator :923-929 initialise(l, 1, k)",
  J + "measures/continuous/TransferEntropyCalculatorViaCondMutualInfo.java addObservationsWithGivenParams :586-621: dest past = makeDelayEmbeddingVector(dest, k, k_tau, start, N) (:606), dest next = dest[start+1 ...] (:610), source past = makeDelayEmbeddingVector(source, l, l_tau, start+1-delay, N) (:614), N = T - start - 1",
  V + "utils/MatrixUtils.java makeDelayEmbeddingVector(double[], k, tau, startKthPoint, n) :2212-2230: row r = [x[t], x[t-tau], ..., x[t-(k-1)tau]] with t = startKthPoint + r",
  CMI_JIDT,
]
REF_CT = "Cover T.M. & Thomas J.A. 2006, Elements of Information Theory, 2nd ed., Wiley"
SUPP = "/media/dan/Data/git/pyspiDocumentation/supplement/supplement.txt"
GB = "information-theory.md"
