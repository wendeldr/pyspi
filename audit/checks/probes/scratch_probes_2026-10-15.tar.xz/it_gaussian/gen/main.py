import yaml, sys
from units_c import U
OUT = "/media/dan/Data/git/pyspi/audit/records/"
ORDER = ["metric_name_standard","canonical_ref","canonical_definition","documented_definition","delegate_lib","implemented_as",
         "implementation_trace","deviation_from_documented","deviation_from_canonical","units_and_range","direction_convention",
         "symmetry_expected","already_documented","new_finding_candidates","proposed_checks"]
for uid, c in U.items():
    assert set(c) == set(ORDER), (uid, set(ORDER) ^ set(c))
    rec = {"unit_id": uid, "status": "traced", "correctness": {k: c[k] for k in ORDER}}
    with open(OUT + uid + ".yaml", "w") as f:
        yaml.safe_dump(rec, f, sort_keys=False, allow_unicode=True, width=200)
    print("wrote", uid)
