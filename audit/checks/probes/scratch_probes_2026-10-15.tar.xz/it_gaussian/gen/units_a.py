from common import *

def chk(datasets, path, reference, kind, criterion, expected):
    return dict(datasets=datasets, path=path, reference=reference, reference_kind=kind, criterion=criterion, expected_outcome=expected)

U = {}

U["infotheory.est.gaussian"] = dict(
 metric_name_standard="Linear-Gaussian (plug-in maximum-likelihood covariance) estimator of differential entropy, mutual information and conditional mutual information / transfer entropy",
 canonical_ref=REF_CT + ", Theorem 8.4.1 (h(N_n(mu,K)) = 0.5 log((2 pi e)^n |K|)) and Example 8.5.1 (I = -0.5 log(1-rho^2)); Barnett, Barrett & Seth 2009, Phys Rev Lett 103:238701 (Gaussian TE = half Geweke GC)",
 canonical_definition="h(X) = 0.5*(d*(1+ln 2pi) + ln det Sigma_X); I(X;Y) = 0.5*ln(det Sigma_X det Sigma_Y / det Sigma_XY); I(X;Y|Z) = 0.5*ln(det Sigma_XZ det Sigma_YZ / (det Sigma_XYZ det Sigma_Z)), all in nats with Sigma the (sample) covariance",
 documented_definition="supplement §1.4, p.9 (supplement.txt:405-415): 'The Gaussian-distribution model (denoted by modifier gaussian) assumes a linear-Gaussian multivariate, where the measure is derived from the cross-covariance matrix'; the supplement says JIDT 'v1.5' while GitBook information-theory.md:11-13 says 'v1.6.1'. Units (nats) and covariance normalisation are not documented.",
 delegate_lib=DELEGATE + "gaussian.EntropyCalculatorMultiVariateGaussian, gaussian.MutualInfoCalculatorMultiVariateGaussian, gaussian.TransferEntropyCalculatorGaussian (CMI Gaussian underneath)",
 implemented_as="Input is the pyspi Data array after optional detrend and default z-scoring with ddof=1. Entropies: sample covariance with divisor n-1 (JIDT MatrixUtils), Cholesky (non-PD -> Java NonPositiveDefiniteMatrixException propagated to Python), h = 0.5*(d(1+ln 2pi)+ln det) in nats; the jar's entropy class reports NORMALISE=true but the Gaussian path never normalises. MI/CMI: covariance determinants with linearly redundant components pruned, NORMALISE=false, BIAS_CORRECTION=false (set by pyspi), returns 0 for fully redundant marginals and +Infinity for joint redundancy. Because pyspi z-scores with ddof=1 and JIDT also uses ddof=1, every univariate Gaussian entropy is exactly 0.5*(1+ln 2pi) = 1.4189385332 nats. pyspi caches univariate entropies in data.entropy[(estimator,)] and joint entropies in data.joint_entropy (infotheory.py:137-177).",
 implementation_trace=[CALC, DATA, INIT, SETUP, GETCALC,
   "pyspi/statistics/infotheory.py:137-156 _compute_entropy: x = data.to_numpy()[i] squeezed; initialise(1); setObservations(double[]); computeAverageLocalOfObservations; cached in data.entropy[key][i] with -inf as 'not computed' sentinel",
   "pyspi/statistics/infotheory.py:159-177 _compute_joint_entropy: initialise(2); setObservations(np.concatenate([x, y], axis=1)); cached symmetric in data.joint_entropy[key]",
   "pyspi/statistics/infotheory.py:180-193 _compute_conditional_entropy(X, Y) = H(X,Y) - H(Y) using the same entropy calculator (H(X|Y))",
   "pyspi/statistics/infotheory.py:195-220 _set_theiler_window: no-op for gaussian (_dyn_corr_excl None)",
 ] + ENT_JIDT + MI_JIDT + [CMI_JIDT, V + "utils/ChiSquareMeasurementDistribution.java :100-102 analytic null mean df/(2N) (used only inside auto-embedding, see TE auto unit)"],
 deviation_from_documented="none in substance (covariance-based linear-Gaussian model). Undocumented conventions: nats, ddof=1 covariance, z-scored input. The supplement's JIDT version (v1.5) differs from GitBook (v1.6.1) and from the bundled jar, which is a post-1.6.1 build (candidate).",
 deviation_from_canonical="none for the formulas (probe: entropy of a 500-sample series matched 0.5*(1+ln 2pi)+0.5*ln var_ddof1 to 3e-16; all derived SPIs matched numpy determinant formulas to <=6e-14). Estimator is the plug-in ML form with n-1 covariance, no small-sample bias correction (the analytic chi-square correction is available in JIDT but switched off).",
 units_and_range="nats; entropies are differential (any real value, negative possible); MI/CMI >= 0 with +Infinity on exact joint linear redundancy; entropy-based quantities raise (-> NaN matrix in Calculator) on singular covariance",
 direction_convention="n/a (estimator layer); argument order (source, dest) for MI/TE is set by the calling SPI",
 symmetry_expected="n/a",
 already_documented="REVIEW M8 (Gaussian joint/conditional entropy can be negative; ce is H(i,j)-H(i)); tests/README.md bug 1 (symbolic falls through to the Gaussian calculator); the raw-array parse_bivariate preprocessing asymmetry is recorded as a candidate in audit/records/basic.spearmanr.yaml",
 new_finding_candidates=[
   "CANDIDATE (provenance): the bundled infodynamics.jar is not a build of tag v1.6.1. Evidence: unzip lists infodynamics/measures/continuous/EntropyCalculatorMultiVariateCommon.class, which is absent from the v1.6.1 source tree (GitHub tree API: 249 source classes, jar has those 249 + this one); upstream added it in commit 3d1f3fe (2024-04-20) and the jar entries are dated 2024-04-21, while pyspi/lib/jidt/version-1.6.1.txt says 'Version 1.6.1 22/08/2023'. JPype reflection: EntropyCalculatorMultiVariateGaussian superclass = EntropyCalculatorMultiVariateCommon. The v1.6.1...a9b6b3e diff touches only bookkeeping (observation IDs, NOISE_SEED) in the Gaussian MI/CMI/TE/AIS paths, and probes agree with from-scratch formulas, so no value impact was found.",
   "CANDIDATE (convention, value-relevant): the hypothesis that NORMALISE defaults differ is CONFIRMED but has no effect on values: entropy calculator getProperty('NORMALISE') -> 'true' (EntropyCalculatorMultiVariateCommon:66), MI/TE calculators -> 'false' (probe), yet the Gaussian entropy is never normalised (scaling a series by 10 raised H by exactly ln 10: 1.3288662 -> 3.6314513). With pyspi's default z-scoring every univariate Gaussian entropy is the constant 1.4189385332 (probe: data.entropy = [1.41893853, 1.41893853] on var2_bivariate_T1024), so ce_gaussian = 1.4189 - mi_gaussian and je_gaussian = 2*1.4189 - mi_gaussian exactly.",
   "CANDIDATE (robustness): a single linearly redundant pair (e.g. duplicated channel) makes every entropy-based Gaussian SPI raise. Probe on shared_envelope_T256 rows 0 and 2 (bit-identical): je, ce, cce, di and si raise infodynamics.utils.NonPositiveDefiniteMatrixException; mi returns inf; gc_k1 returns 0.0; tlmi and xme stay finite. Calculator.compute (calculator.py:301-303) then replaces the whole P x P matrix for je/ce/cce/di/si with NaN, not only the offending pair.",
   "CANDIDATE (documentation): pyspi sets NOISE_SEED=42 and BIAS_CORRECTION=false on every calculator (infotheory.py:90-91); for the Gaussian entropy calculator BIAS_CORRECTION is not a recognised property (getProperty -> None) and NOISE_SEED has no effect because addNoise defaults to false. Harmless, but the settings suggest options that do nothing here.",
 ],
 proposed_checks=[
   chk(["iid_gaussian","bivariate_gaussian","var2_bivariate","delayed_noise"], "pipeline", "analytic sample identity: after zscore(ddof=1) every univariate Gaussian entropy equals 0.5*(1+ln(2*pi)) = 1.4189385332046727; compare data.entropy after running je/ce", "analytic", "exact", "every cached univariate entropy within 1e-12 of 1.4189385332046727 for all T"),
   chk(["var2_bivariate","sparse_precision","iid_gaussian"], "kernel", "from-scratch numpy: h = 0.5*(d*(1+ln 2pi) + slogdet(np.cov(M, rowvar=False, ddof=1))) on random column subsets / delay embeddings of dimension 1..10; MI and CMI via the same determinant formula (no JIDT import)", "independent-impl", "tolerance", "abs difference <= 1e-10 for JIDT entropy, MI and CMI calls driven directly through pyspi's JIDTBase calculators"),
   chk(["scaled_offset"], "pipeline", "analytic: with Data(normalise=False), H(s*x+c) - H(x) = ln|s| for the univariate Gaussian entropy; MI/CMI invariant to per-channel affine maps", "analytic", "exact", "entropy shifts equal ln(scale) to 1e-12 (scale = 0.2, 2, 5, 10 relative to D2); mi/tlmi/te identical (1e-12) between normalise=True and normalise=False"),
   chk(["shared_envelope"], "pipeline", "qualitative degenerate-input contract: x2 is a bit-identical copy of x0", "analytic", "qualitative", "record which Gaussian SPIs raise (expected je, ce, cce, di, si), return +inf (mi) or 0 (gc_k1), and confirm that Calculator.compute turns a raising SPI into an all-NaN matrix"),
 ],
)

U["infotheory.je.gaussian"] = dict(
 metric_name_standard="Joint differential entropy H(X,Y) under a bivariate Gaussian model",
 canonical_ref=REF_CT + ", §8.4 Theorem 8.4.1 (differential entropy of a multivariate normal); supplement cites MacKay 2003, Information Theory, Inference and Learning Algorithms",
 canonical_definition="H(X,Y) = 0.5*ln((2*pi*e)^2 det Sigma_XY) = (1+ln 2pi) + 0.5*ln(sx^2 sy^2 (1-rho^2)) nats",
 documented_definition="supplement §1.4.1, p.10 (supplement.txt:444-449): 'The joint entropy [33] quantifies the uncertainty over the paired observations'; keywords 'undirected, nonlinear, unsigned, bivariate, contemporaneous'. GitBook information-theory.md:139-157 same text.",
 delegate_lib=DELEGATE + "gaussian.EntropyCalculatorMultiVariateGaussian (initialise(2) + setObservations(double[][]) + computeAverageLocalOfObservations)",
 implemented_as="Each channel z-scored (ddof=1) by Data; for i<j the (T,2) matrix [x_i, x_j] is passed to the JIDT Gaussian entropy calculator: 0.5*(2*(1+ln 2pi) + ln det C) with C the ddof=1 sample covariance. Since both diagonals of C are exactly 1, je = (1+ln 2pi) + 0.5*ln(1-r^2) = 2*1.4189385 - mi_gaussian, with r the sample Pearson correlation. Cached in data.joint_entropy (shared with ce). Lower triangle mirrored.",
 implementation_trace=[CALC, DATA, UNDIRECTED, INIT, SETUP, GETCALC,
   "pyspi/statistics/infotheory.py:223-234 JointEntropy(JIDTBase, Undirected); bivariate -> _compute_joint_entropy",
   "pyspi/statistics/infotheory.py:159-177 _compute_joint_entropy: x, y = data.to_numpy()[[i, j]] (each (T,1)); initialise(2); setObservations(np.concatenate([x, y], axis=1)); value stored at [i,j] and [j,i]",
   "pyspi/config.yaml:397-409 JointEntropy configs: estimator gaussian (no further parameters)"] + ENT_JIDT,
 deviation_from_documented="none for the quantity. Labels: config.yaml keyword 'nonlinear' is not carried by the instance (instance labels end with 'linear'); 'unsigned' label although values can be negative (REVIEW M8).",
 deviation_from_canonical="none (plug-in Gaussian estimator with ddof=1 covariance). After default z-scoring the value carries no marginal-scale information and is an affine function of r^2: je = 2.8378770664 + 0.5*ln(1-r^2) (probe var2_bivariate_T1024: 2.81900377 = 2*1.41893853 - 0.01887329).",
 units_and_range="nats; real, <= 2.8378770664 under z-scoring (equality iff r=0), -> -inf as |r| -> 1, raises on exact collinearity (Cholesky); without normalisation shifts by ln(sx*sy); symmetric",
 direction_convention="undirected: A[i,j] = A[j,i] = H(x_i, x_j), computed for i<j and mirrored (base.py:136-137)",
 symmetry_expected="sym",
 already_documented="REVIEW M8 (Gaussian joint entropy can be negative; not an abs omission)",
 new_finding_candidates=[
   "CANDIDATE (redundancy): under default normalise=True, je_gaussian is an exact affine transform of mi_gaussian: je = 2*0.5*(1+ln 2pi) - mi. Probe var2_bivariate_T1024: je 2.81900377, mi 0.01887329, 2*1.41893853 - 0.01887329 = 2.81900377. Hence je_gaussian, ce_gaussian and mi_gaussian carry identical ranking information (all functions of |r|).",
   "CANDIDATE (robustness): exact collinearity raises NonPositiveDefiniteMatrixException (probe shared_envelope rows 0/2) and Calculator blanks the whole je matrix (calculator.py:301-303); see infotheory.est.gaussian.",
 ],
 proposed_checks=[
   chk(["bivariate_gaussian","var2_bivariate","iid_gaussian","contaminated"], "pipeline", "from-scratch numpy: z-score each row with ddof=1, H = 0.5*(2*(1+ln 2pi) + ln det np.cov([x_i,x_j], ddof=1))", "independent-impl", "tolerance", "abs difference <= 1e-12 for every pair and T"),
   chk(["bivariate_gaussian"], "pipeline", "analytic population value for unit-variance pairs: (1+ln 2pi) + 0.5*ln(1-rho^2): rho=0.3 -> 2.7907217, rho=0.8 -> 2.3270514", "analytic", "statistical", "at T=4096 within 3 sampling SDs (delta method on r); bias shrinks with T over 64..4096"),
   chk(["bivariate_gaussian","var2_bivariate"], "pipeline", "analytic identity je = 2*1.4189385332046727 - mi_gaussian (both computed by pyspi on the same Data)", "analytic", "exact", "identity holds to 1e-12 on every pair"),
   chk(["scaled_offset"], "pipeline", "analytic: with normalise=False, je(scaled) - je(D2 rows) = ln(s_i*s_j)", "analytic", "exact", "shift equals ln(s_i s_j) to 1e-10; with normalise=True scaled_offset equals bivariate_gaussian (same draw) to 1e-12"),
 ],
)

U["infotheory.ce.gaussian"] = dict(
 metric_name_standard="Conditional differential entropy H(Y|X) under a bivariate Gaussian model",
 canonical_ref=REF_CT + ", §8.6 (conditional differential entropy h(Y|X) = h(X,Y) - h(X)); supplement cites MacKay 2003",
 canonical_definition="H(Y|X) = H(X,Y) - H(X) = 0.5*ln(2*pi*e*sy^2*(1-rho^2)) nats",
 documented_definition="supplement §1.4.2, p.10 (supplement.txt:451-457): 'Conditional entropy [33] quantifies the uncertainty over the observations in y in the context of simultaneously observing x'; keywords 'undirected, nonlinear, unsigned, bivariate, contemporaneous'. GitBook information-theory.md:46-64 same text.",
 delegate_lib=DELEGATE + "gaussian.EntropyCalculatorMultiVariateGaussian (joint entropy of (x_i,x_j) and univariate entropy of x_i)",
 implemented_as="A[i,j] = H(x_i, x_j) - H(x_i) = H(x_j | x_i), both from the JIDT Gaussian entropy calculator on z-scored (ddof=1) data, reusing the je cache and the univariate cache. With z-scoring H(x_i) = 1.4189385332 exactly, so A[i,j] = 1.4189385332 + 0.5*ln(1-r^2) = 1.4189385332 - mi_gaussian, which is symmetric in (i,j) despite the Directed class.",
 implementation_trace=[CALC, DATA, DIRECTED, INIT, SETUP, GETCALC,
   "pyspi/statistics/infotheory.py:237-250 ConditionalEntropy(JIDTBase, Directed); bivariate returns _compute_joint_entropy(i,j) - _compute_entropy(i) (conditioning variable = i)",
   "pyspi/statistics/infotheory.py:137-156 _compute_entropy (univariate, cached); :159-177 _compute_joint_entropy (cached, shared with je)",
   "pyspi/config.yaml:411-423 ConditionalEntropy configs: estimator gaussian"] + ENT_JIDT,
 deviation_from_documented="Quantity matches 'uncertainty in y given x' with x = process i, y = process j. Keywords say 'undirected' while the class is Directed (REVIEW M8 already notes the conditioning order). Under the default pipeline the output is exactly symmetric, so 'directed' has no effect on values (candidate below).",
 deviation_from_canonical="none for H(x_j|x_i) under the Gaussian model; plug-in estimator, ddof=1. Under z-scoring the marginal-scale term vanishes and the value is 1.4189385 - mi_gaussian.",
 units_and_range="nats; real, <= 1.4189385332 under z-scoring, -> -inf as |r| -> 1, raises on exact collinearity; with normalise=False shifts by ln(s_j) and is asymmetric",
 direction_convention="A[i,j] = H(x_j | x_i): row i is the conditioning (observed) process, column j the process whose uncertainty is measured (infotheory.py:248-250). Probe scaled_offset_T1024 with normalise=False: A[0,1]=2.0787 vs A[1,0]=-0.2373 (x1 has scale 2, x0 scale 0.2)",
 symmetry_expected="asym",
 already_documented="REVIEW M8 (Gaussian conditional entropy can be negative; ce is H(i,j)-H(i), conditioning order)",
 new_finding_candidates=[
   "CANDIDATE (degenerate direction): under default normalise=True ce_gaussian is exactly symmetric, A[i,j] = A[j,i] = 1.4189385332 - mi_gaussian. Probe var2_bivariate_T1024: A[0,1] = A[1,0] = 1.40006524 and 1.41893853 - 0.01887329 = 1.40006524; scaled_offset_T1024 z-scored matrix symmetric to 4 decimals at every pair, while normalise=False gives an asymmetric matrix (A[0,1]=2.0787, A[1,0]=-0.2373). The 'directed' label therefore carries no information in the default pipeline.",
   "CANDIDATE (redundancy): ce_gaussian = 1.4189385332 - mi_gaussian exactly under z-scoring (same probe), so ce, je and mi Gaussian are mutually affine.",
 ],
 proposed_checks=[
   chk(["bivariate_gaussian","var2_bivariate","contaminated"], "pipeline", "from-scratch numpy H(x_i,x_j) - H(x_i) with ddof=1 sample covariances on z-scored rows", "independent-impl", "tolerance", "abs difference <= 1e-12 for every ordered pair"),
   chk(["scaled_offset"], "kernel", "from-scratch numpy H(x_j|x_i) on Data(normalise=False) (raw scaled data) to fix the conditioning order", "independent-impl", "direction", "A[i,j] equals the reference for H(x_j | x_i) (not H(x_i | x_j)) to 1e-12; A[0,1]-A[1,0] = ln(s1/s0) = ln 10 up to 1e-12"),
   chk(["bivariate_gaussian","var2_bivariate","iid_gaussian"], "pipeline", "analytic identity ce = 1.4189385332046727 - mi_gaussian and symmetry A = A.T", "analytic", "exact", "identity and symmetry hold to 1e-12 under normalise=True"),
   chk(["bivariate_gaussian"], "pipeline", "analytic population H(y|x) for unit variance: 0.5*ln(2*pi*e*(1-rho^2)): rho=0.3 -> 1.3717832, rho=0.8 -> 0.9081129", "analytic", "statistical", "within 3 sampling SDs at T=4096"),
 ],
)

U["infotheory.mi.gaussian"] = dict(
 metric_name_standard="Gaussian (linear) mutual information I(X;Y) = -0.5 ln(1 - r^2)",
 canonical_ref=REF_CT + ", Example 8.5.1 (MI of a bivariate normal); supplement cites MacKay 2003",
 canonical_definition="I(X;Y) = 0.5*ln(sx^2 sy^2 / det Sigma_XY) = -0.5*ln(1-rho^2) nats",
 documented_definition="supplement §1.4.3, p.10 (supplement.txt:459-465): 'Mutual information [33] is an undirected measure of the (potentially nonlinear) dependence between paired observations of x and y'; keywords 'undirected, nonlinear, unsigned, bivariate, contemporaneous'. GitBook information-theory.md:161-180.",
 delegate_lib=DELEGATE + "gaussian.MutualInfoCalculatorMultiVariateGaussian (initialise(1,1), setObservations(double[], double[]), computeAverageLocalOfObservations)",
 implemented_as="For each pair (i<j kept), source = x_i, dest = x_j (z-scored, squeezed); JIDT computes the ddof=1 covariance of the pair and returns 0.5*ln|var_i var_j / det C| = -0.5*ln(1-r^2) with r the sample Pearson correlation, no time lag (TIME_DIFF=0), no bias correction, no Theiler window. Any exception -> logged warning and NaN for that pair (bare except, infotheory.py:279-283). Exact joint collinearity returns +inf (not an exception).",
 implementation_trace=[CALC, DATA, UNDIRECTED, INIT, SETUP, GETCALC,
   "pyspi/statistics/infotheory.py:253-265 MutualInfo(JIDTBase, Undirected); __init__ builds self._calc = _getcalc('MutualInfo')",
   "pyspi/statistics/infotheory.py:267-283 bivariate: _set_theiler_window (no-op for gaussian); initialise(1,1); src, targ = data.to_numpy(squeeze=True)[[i, j]]; setObservations(JArray(src), JArray(targ)); return computeAverageLocalOfObservations(); bare except -> NaN",
   "pyspi/config.yaml:495-507 MutualInfo configs: estimator gaussian (first entry)"] + MI_JIDT + ENT_JIDT[2:],
 deviation_from_documented="none for the quantity; 'nonlinear' keyword is not applicable to the Gaussian estimator (it captures only linear dependence; instance labels say 'linear').",
 deviation_from_canonical="none: probe var2_bivariate_T1024 mi = 0.01887329 equals -0.5*ln(1-r^2) = 0.0188732936 to machine precision; no small-sample bias correction (E[I_hat] ~ 1/(2N) under independence).",
 units_and_range="nats; [0, +inf]; +inf on exact collinearity; scale invariant; symmetric",
 direction_convention="undirected: A[i,j] = A[j,i] = I(x_i; x_j), computed for i<j and mirrored",
 symmetry_expected="sym",
 already_documented="no",
 new_finding_candidates=[
   "CANDIDATE (redundancy, information): mi_gaussian is a monotone function of r^2 (sample Pearson); je_gaussian and ce_gaussian are exact affine functions of it under z-scoring (see those units), so the three SPIs are rank-equivalent.",
   "CANDIDATE (bias): no bias correction is applied (pyspi forces BIAS_CORRECTION=false, infotheory.py:90); under independence the expected value is about 1/(2N) nats (chi-square(1)/(2N), ChiSquareMeasurementDistribution:100-102), i.e. 0.0078 at T=64. To quantify on iid_gaussian.",
 ],
 proposed_checks=[
   chk(["bivariate_gaussian","var2_bivariate","iid_gaussian","contaminated","nonlinear_dependence"], "pipeline", "from-scratch numpy: -0.5*ln(1 - np.corrcoef(x_i,x_j)[0,1]**2)", "independent-impl", "tolerance", "abs difference <= 1e-12 on every pair and T"),
   chk(["bivariate_gaussian"], "pipeline", "analytic true_mi_nats = -0.5*ln(1-rho^2) stored in the dataset (rho=0.3 -> 0.0471547, rho=0.8 -> 0.5108256)", "analytic", "statistical", "within 3 sampling SDs at T=4096 (SD approx |rho|/sqrt(T) on the MI scale via delta method); converges with T"),
   chk(["iid_gaussian"], "pipeline", "analytic null: 2*N*I_hat ~ chi-square(1), mean 1/(2N)", "analytic", "statistical", "mean over the 10 pairs consistent with 1/(2N) at each T (one-sided bias, never negative)"),
   chk(["nonlinear_dependence"], "pipeline", "qualitative: x1 = x0^2 + noise has near-zero Pearson correlation", "analytic", "qualitative", "mi_gaussian near 0 for the (0,1) and (2,3) pairs despite strong dependence, documenting the linear-only scope"),
 ],
)

U["infotheory.tlmi.gaussian"] = dict(
 metric_name_standard="Lag-1 time-lagged (cross) mutual information I(X_t; Y_{t+1}) under a Gaussian model",
 canonical_ref="Fraser A.M. & Swinney H.L. 1986, Phys Rev A 33:1134 (time-delayed mutual information); supplement cites Schreiber 2000, Phys Rev Lett 85:461; Gaussian form " + REF_CT + ", Example 8.5.1",
 canonical_definition="I(X_t; Y_{t+1}) = -0.5*ln(1 - corr(X_t, Y_{t+1})^2) nats for jointly Gaussian stationary processes",
 documented_definition="supplement §1.4.4, p.10 (supplement.txt:467-474): 'Time-lagged mutual information [35] is an undirected measure of the dependence between time series x and a time-lagged instance of the series y. We include statistics for only lag-one mutual information'; keywords 'undirected, nonlinear, unsigned, bivariate, time-dependent'. GitBook information-theory.md:235-254 calls it 'a directed measure'.",
 delegate_lib=DELEGATE + "gaussian.MutualInfoCalculatorMultiVariateGaussian on (x_i[:-1], x_j[1:])",
 implemented_as="For each ordered pair: src = x_i[0:T-1], targ = x_j[1:T] (z-scored, squeezed), Gaussian MI with ddof=1 covariance on the T-1 aligned samples = -0.5*ln(1 - r(x_i(t), x_j(t+1))^2). No bias correction, no Theiler window. Bare except -> NaN.",
 implementation_trace=[CALC, DATA, DIRECTED, INIT, SETUP, GETCALC,
   "pyspi/statistics/infotheory.py:286-299 TimeLaggedMutualInfo(JIDTBase, Directed); _calc = _getcalc('MutualInfo')",
   "pyspi/statistics/infotheory.py:301-317 bivariate: initialise(1,1); src, targ = data.to_numpy(squeeze=True)[[i, j]]; src = src[:-1]; targ = targ[1:]; setObservations; computeAverageLocalOfObservations; bare except -> NaN",
   "pyspi/config.yaml:518-530 TimeLaggedMutualInfo configs: estimator gaussian"] + MI_JIDT,
 deviation_from_documented="Value matches 'lag-one MI between x and a lagged y' with x = source i (earlier) and y = target j (later). The supplement keyword 'undirected' conflicts with the code (Directed, asymmetric) and with GitBook ('directed'); REVIEW M8 already notes tlmi is asymmetric by construction.",
 deviation_from_canonical="none (plug-in Gaussian lagged MI; probe var2_bivariate_T1024: A[0,1] = 0.16664117, A[1,0] = 0.00276225, both equal to -0.5*ln(1-r^2) of the lagged pairs to machine precision).",
 units_and_range="nats; [0, +inf]; asymmetric; scale invariant",
 direction_convention="A[i,j] = I(x_i(t); x_j(t+1)): row i leads by one sample, column j lags (infotheory.py:306-308). Probe var2_bivariate (x0 drives x1): A[0,1]=0.1666 > A[1,0]=0.0028",
 symmetry_expected="asym",
 already_documented="REVIEW M8 (tlmi is asymmetric by construction)",
 new_finding_candidates=[
   "CANDIDATE (documentation): supplement §1.4.4 keywords/text say 'undirected' while GitBook information-theory.md:243 says 'directed' and the implementation is Directed with A[i,j] = I(x_i(t); x_j(t+1)); the documentation is internally inconsistent (value behaviour itself is covered by REVIEW M8).",
 ],
 proposed_checks=[
   chk(["var2_bivariate","delayed_noise","gauss_ar1_pair","iid_gaussian"], "pipeline", "from-scratch numpy: -0.5*ln(1 - np.corrcoef(x_i[:-1], x_j[1:])[0,1]**2) on z-scored rows", "independent-impl", "tolerance", "abs difference <= 1e-12 on every ordered pair"),
   chk(["delayed_noise"], "pipeline", "analytic: x1(t) = x0(t-1) + 0.1 noise with x0 white unit variance -> I(x0(t); x1(t+1)) = 0.5*ln(1 + 1/0.01) = 2.3075603; reverse I(x1(t); x0(t+1)) = 0", "analytic", "direction", "A[0,1] near 2.3076 (statistical, T=4096) and A[1,0] near 0; establishes A[i,j] = I(x_i(t); x_j(t+1)) (row leads)"),
   chk(["gauss_ar1_pair"], "pipeline", "analytic population lagged correlation from Sigma_X and Sigma_XY = A Sigma_X stored in the dataset: rho(x_i(t), x_j(t+1)) = Sigma_XY[j,i]/sqrt(Sigma_X[i,i] Sigma_X[j,j])", "analytic", "statistical", "both ordered pairs within 3 sampling SDs at T=4096"),
 ],
)
