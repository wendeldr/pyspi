from common import *
from units_b import chk, U

XME_DOC = "Not defined in the supplement (no section for xme in §1.4, supplement.txt:405-565) nor in GitBook information-theory.md; only listed in GitBook table-of-spis.md:73 as 'Cross-Map Entropy', base identifier xme, estimators xme_kozachenko_k1/k10, xme_gaussian_k1/k10, xme_kernel_k1/k10. No formula, keywords or reference are documented."
XME_TRACE = [CALC, DATA, DIRECTED, INIT, SETUP, GETCALC,
  "pyspi/statistics/infotheory.py:394-403 CrossmapEntropy(JIDTBase, Directed).__init__(history_length=10): identifier += f'_k{history_length}'",
  "pyspi/statistics/infotheory.py:405-414 bivariate: src, targ = data.to_numpy(squeeze=True)[[i, j]]; k = history_length; targ_future = targ[k:]; src_past first column src[k-1:-1] (lag 1); loop 'for i in range(2, k)' appends src[k-i:-i] (lags 2..k-1; shadows the argument i, harmless)",
  "pyspi/statistics/infotheory.py:416-426 joint = [src_past, targ_future]; H_xy = Gaussian entropy of joint; H_y = Gaussian entropy of src_past; return H_xy - H_y = H(targ_future | src_past)",
  "pyspi/config.yaml:439-464 CrossmapEntropy configs: estimator gaussian with history_length 1 and 10"] + ENT_JIDT

def xme_unit(k):
    lags = "1" if k == 1 else "1..9"
    nl = "1 lag" if k == 1 else "9 lags (1..9)"
    return dict(
 metric_name_standard=f"Conditional differential entropy of the target given lagged source values, H(Y_t | X_(t-1..t-{max(1,k-1)})) (pyspi 'cross-map entropy', no standard name)",
 canonical_ref="none found: 'cross-map entropy' is not a standard named quantity and pyspi documents no reference; nearest standard quantity is conditional differential entropy (" + REF_CT + ", §8.6). Not related in code to convergent cross mapping (Sugihara et al. 2012).",
 canonical_definition=f"H(Y_t | X_{{t-1}}, ..., X_{{t-m}}) = H(Y_t, X_past) - H(X_past), m = history length; under the Gaussian model 0.5*ln(2*pi*e*sigma^2(Y_t | X_past))",
 documented_definition=XME_DOC,
 delegate_lib=DELEGATE + "gaussian.EntropyCalculatorMultiVariateGaussian (two calls: joint and source-past)",
 implemented_as=f"history_length={k}: target future y_j(t) for t = {k}..T-1 (N = T-{k} samples); source past uses {nl} of x_i (lags 1 and range(2,k) -> {lags}). Value = H([x_i past, y_j(t)]) - H(x_i past) with ddof=1 Gaussian entropies on z-scored data = 0.5*ln(2*pi*e*RSS/(N-1)) of the OLS (with intercept) regression of y_j(t) on the source lags. The target's own past is not conditioned on.",
 implementation_trace=XME_TRACE,
 deviation_from_documented="No documented definition exists (only a table entry), so the implementation cannot be compared with documentation; the history parameter named 'k' does not equal the number of source lags used (" + ("k=1 -> 1 lag, as the name suggests" if k == 1 else "k=10 -> 9 lags") + "). The name suggests a cross-mapping (CCM-like) construct but the code is a plain lagged conditional entropy.",
 deviation_from_canonical=("none relative to H(Y_t | X_{t-1}) under the Gaussian model (probe var2_bivariate_T1024 A[0,1] = 1.25161306 equals numpy H([x0(t-1), x1(t)]) - H(x0(t-1)) = 1.2516130588681806). " if k == 1 else "Relative to a history of 10 source lags: uses lags 1..9 only (range(2,k) excludes k). Probe var2_bivariate_T1024 A[0,1] = 1.2375756 equals numpy H(x1(t) | x0(t-1..t-9)) = 1.2375755952972707. ") + "History lengths k=1 and k=2 both use only lag 1 (probe: k=1 1.2516131, k=2 1.2520804, k=3 1.2509918 on the same pair; k=2 differs from k=1 only by dropping one sample).",
 units_and_range="nats; real (differential entropy): <= approx 1.4189 under z-scoring and negative when the source past predicts the target well (analytic delayed_noise 0->1 with lag 1: approx -0.889); asymmetric; scale-dependent without normalisation",
 direction_convention="A[i,j] = H(x_j(t) | x_i(t-1..)): row i is the conditioning source, column j the target (infotheory.py:407-426). Probe var2_bivariate_T1024: A[0,1]=" + ("1.2516" if k == 1 else "1.2376") + " < A[1,0]=" + ("1.4158" if k == 1 else "1.4112") + " (lower = more predictable target)",
 symmetry_expected="asym",
 already_documented="REVIEW M8 (Gaussian joint/conditional entropies can be negative despite 'unsigned') covers the sign behaviour by the same mechanism",
 new_finding_candidates=([
   "CANDIDATE (documentation gap): xme has no definition, keywords or reference in the supplement or GitBook SPI descriptions; only GitBook table-of-spis.md:73 lists it.",
   "CANDIDATE (off-by-one, hypothesis partly confirmed): the source-lag loop is range(2, k) (infotheory.py:411), so history_length k uses lags 1..k-1 for k >= 2 and lag 1 for k = 1; k=1 and k=2 therefore use the same lag set and differ only by one sample (probe 1.2516131 vs 1.2520804). Affects xme_gaussian_k10 (9 lags); xme_gaussian_k1 is as named.",
   "CANDIDATE (interpretation): the target's own past is not conditioned on, so A[i,j] is dominated by the target's marginal entropy (constant 1.4189 under z-scoring) minus the lagged linear predictability from the source; for autocorrelated targets it mixes common drive and autocorrelation; it is not a causal (TE-like) measure and is unrelated to cross mapping.",
 ] if k == 1 else [
   "CANDIDATE (off-by-one, confirmed by reading and probe): history_length=10 uses source lags 1..9, not 1..10 (range(2, k) at infotheory.py:411; probe reference with lags [1..9] reproduces 1.2375756 exactly). A coupling at exactly lag 10 is invisible to xme_gaussian_k10.",
   "CANDIDATE (documentation gap): no definition, keywords or reference documented (only table-of-spis.md:73).",
   "CANDIDATE (sign): with 9 source lags and strong lagged coupling, the value is negative (differential entropy), contrary to the 'unsigned' label (REVIEW M8 mechanism).",
 ]),
 proposed_checks=[
   chk(["var2_bivariate","delayed_noise","gauss_ar1_pair","iid_gaussian"], "pipeline", f"from-scratch numpy: y = z_j[{k}:], X = z_i lags {{{lags}}} aligned to y; H(X,y) - H(X) with ddof=1 slogdet Gaussian entropies", "independent-impl", "tolerance", "abs difference <= 1e-12 on every ordered pair and T"),
   chk(["delayed_noise"], "pipeline", "analytic: x1(t) = x0(t-1) + 0.1 noise (x0 white, unit variance), z-scored: H(x1(t) | x0(t-1)) = 0.5*ln(2*pi*e*0.01/1.01) = -0.8886217; reverse H(x0(t) | x1(t-1..)) approx 1.4189 (x0 white)", "analytic", "direction", "A[0,1] near -0.889 (statistical at T=4096), A[1,0] near 1.419; establishes A[i,j] = H(x_j | past of x_i)" + ("" if k == 1 else "; also A[0,3] (delay 5, within lags 1..9) near -0.889 while xme_k1 A[0,3] near 1.419")),
   chk(["iid_gaussian"], "kernel", "constructed shift test from an iid_gaussian row u: target y(t) = u(t-d) + 0.1 noise for d = 9 and d = 10 (built inside the check, numpy only), reference H(y | lags) by numpy", "independent-impl", "qualitative", "xme_gaussian_k10 is strongly negative for d = 9 and approx 1.419 for d = 10 (documents lags 1..9); xme_gaussian_k1 approx 1.419 for both" if k == 10 else "xme_gaussian_k1 captures d = 1 only; history_length=2 gives nearly the same value as k=1 (same lag set)"),
 ],
)

U["infotheory.xme.gaussian_k1"] = xme_unit(1)
U["infotheory.xme.gaussian_k10"] = xme_unit(10)

CCE_DOC = "supplement §1.4.7, p.11 (supplement.txt:513-524): 'Causally conditioned entropy [42-44] aims to measure the uncertainty remaining in time series y in the context of the entire (causal) past of both time series x and y. The measure is computed as a sum of conditional entropies (of y given both the past of x and the past of y) with increasing history lengths. ... for computational reasons, we restrict the history length to 10. This corresponds to the assumption that the joint process is, at maximum, a 10th-order Markov chain.' Keywords 'directed, nonlinear, unsigned, bivariate, time-dependent'. GitBook information-theory.md:24-42 same text."
CCE_TRACE = [
  "pyspi/statistics/infotheory.py:429-437 CausalEntropy(JIDTBase, Directed).__init__(n=5) -> self._n = 5 (config passes no n)",
  "pyspi/statistics/infotheory.py:439-454 _compute_causal_entropy(src, targ): for i = 1..n: Yp = MatrixUtils.makeDelayEmbeddingVector(targ, i-1)[:-1] (targ lags 1..i-1), Xp = makeDelayEmbeddingVector(src, i) (src lags 0..i-1, i.e. including the present x(t)), Yf = targ[i-1:]; sum of _compute_conditional_entropy(Yf, [Yp, Xp]) = H(y(t) | y(t-1..t-i+1), x(t..t-i+1)) on T-i+1 samples",
  "pyspi/statistics/infotheory.py:180-193 _compute_conditional_entropy(X, Y) = H(X,Y) - H(Y) with the Gaussian entropy calculator",
  "pyspi/statistics/infotheory.py:456-457 _getkey adds n to the cache key; :459-474 bivariate caches data.causal_entropy[(estimator, n)][i,j] = _compute_causal_entropy(z[i], z[j]) (src = i, targ = j)",
  V + "utils/MatrixUtils.java makeDelayEmbeddingVector(double[], k) :2084-2092 -> (data, k, k-1, T-k+1) :2140-2158, rows [x(t), x(t-1), ..., x(t-k+1)] for t = k-1..T-1; k = 0 yields T+1 zero-width rows (probe-consistent)",
]
U["infotheory.cce.gaussian"] = dict(
 metric_name_standard="Causally conditioned (block) entropy H(Y^n || X^n) with block length n = 5, Gaussian model",
 canonical_ref="Kramer G. 1998, PhD thesis 'Directed information for channels with feedback', ETH Zurich, eq. (3.x) causal conditioning H(Y^N||X^N) = sum_{n=1}^N H(Y_n | Y^{n-1}, X^n); Ziebart B.D., Bagnell J.A. & Dey A.K. 2010, ICML (maximum causal entropy); Amblard P.-O. & Michel O.J.J. 2011, J Comput Neurosci 30:7-16",
 canonical_definition="H(Y^N || X^N) = sum_{n=1}^{N} H(Y_n | Y_1..Y_{n-1}, X_1..X_n) (X up to and including time n)",
 documented_definition=CCE_DOC,
 delegate_lib=DELEGATE + "gaussian.EntropyCalculatorMultiVariateGaussian (2 entropies per term, 5 terms) and infodynamics.utils.MatrixUtils.makeDelayEmbeddingVector",
 implemented_as="A[i,j] = sum_{m=1}^{5} H(x_j(t) | x_j(t-1..t-m+1), x_i(t..t-m+1)) with each term a stationary (sliding-window, T-m+1 samples) Gaussian conditional entropy on z-scored data (ddof=1). This is the block quantity H(Y^5 || X^5) under stationarity (not a per-sample rate), it includes the contemporaneous source sample x_i(t) in every term, and n = 5 (constructor default) rather than the documented 10.",
 implementation_trace=[CALC, DATA, DIRECTED, INIT, SETUP, GETCALC] + CCE_TRACE + ["pyspi/config.yaml:425-437 CausalEntropy configs: estimator gaussian (no n)"] + ENT_JIDT,
 deviation_from_documented="(1) History restricted to n = 5 terms (infotheory.py:435), not 10 as documented (supplement §1.4.7; GitBook). (2) Each term conditions on the present x(t) as well as the past ('past of x' in the text); this follows Kramer's definition but not the supplement wording. (3) The value is a sum over 5 terms (magnitude approx 5 x per-sample entropy, e.g. 6.12 nats on var2_bivariate_T1024), not 'the uncertainty remaining in y' per sample.",
 deviation_from_canonical="Matches Kramer's causally conditioned entropy for block length N = 5 under stationarity (probe var2_bivariate_T1024: A[0,1] = 6.12472743 and A[1,0] = 6.63088572 equal a numpy re-implementation 6.124727425882034 / 6.630885716374198). Finite truncation (5) instead of the whole past; terms estimated on different sample counts (T-m+1).",
 units_and_range="nats; real (sum of differential conditional entropies), approx 5*1.4189 = 7.09 for independent white series under z-scoring, can be negative for strongly coupled pairs; asymmetric; raises on singular embeddings (Calculator blanks the matrix)",
 direction_convention="A[i,j] = H(x_j^5 || x_i^5): column j is the target whose uncertainty is measured, row i the causally conditioning source (infotheory.py:472 passes z[i] as src, z[j] as targ). Probe var2_bivariate_T1024 (x0 drives x1): A[0,1]=6.125 < A[1,0]=6.631",
 symmetry_expected="asym",
 already_documented="REVIEW M8 (sign of Gaussian entropies) by the same mechanism; tests/README.md lists cce_* as FORCE_SLOW only",
 new_finding_candidates=[
   "CANDIDATE (documented parameter mismatch, hypothesis confirmed): CausalEntropy uses n = 5 (infotheory.py:435 'def __init__(self, n=5, ...)'; config.yaml:425-437 passes no n) while supplement §1.4.7 and GitBook say the history is restricted to 10.",
   "CANDIDATE (documentation wording): every term conditions on x(t) (makeDelayEmbeddingVector(src, i) contains lags 0..i-1, infotheory.py:449), i.e. 'past and present of x', matching Kramer's X^n but not the supplement's 'past of x'.",
   "CANDIDATE (scale of output): the value is a 5-term block sum, so it scales with n and is not comparable to a per-sample conditional entropy (iid z-scored data give approx 7.09 nats, not approx 1.42).",
 ],
 proposed_checks=[
   chk(["var2_bivariate","delayed_noise","gauss_ar1_pair","iid_gaussian","bivariate_gaussian"], "pipeline", "from-scratch numpy: sum_{m=1}^{5} [H(y(t), y lags 1..m-1, x lags 0..m-1) - H(y lags 1..m-1, x lags 0..m-1)] with ddof=1 slogdet entropies, sample alignment t = m-1..T-1", "independent-impl", "tolerance", "abs difference <= 1e-10 on every ordered pair and T"),
   chk(["bivariate_gaussian","iid_gaussian"], "pipeline", "analytic for serially independent Gaussian pairs: 5*(1.4189385 + 0.5*ln(1-rho^2)): rho=0.8 -> 4.5405645, rho=0.3 -> 6.8589160, independent -> 7.0946927", "analytic", "statistical", "within 3 sampling SDs at T=4096; symmetric for these white pairs"),
   chk(["delayed_noise","var2_bivariate"], "pipeline", "known ground truth: x0 drives x1", "analytic", "direction", "A[0,1] < A[1,0] (conditioning on the driver lowers the target's causally conditioned entropy); establishes A[i,j] = H(x_j || x_i)"),
   chk(["gauss_ar1_pair"], "pipeline", "analytic population value of the 5-term sum from the stationary VAR(1) autocovariances Gamma(h) = A^h Sigma_X (dataset truth), building each block covariance explicitly", "analytic", "statistical", "within 3 sampling SDs at T=4096"),
 ],
)

U["infotheory.di.gaussian"] = dict(
 metric_name_standard="Directed information I(X^n -> Y^n) (Massey), block length n = 5, Gaussian model (pyspi variant)",
 canonical_ref="Massey J. 1990, Proc. Int. Symp. Inf. Theory Appl. (ISITA), 'Causality, feedback and directed information', eq. (6)-(7); Kramer G. 1998 PhD thesis ETH Zurich (I(X^N->Y^N) = H(Y^N) - H(Y^N||X^N)); Amblard & Michel 2011, J Comput Neurosci 30:7-16",
 canonical_definition="I(X^N -> Y^N) = sum_{n=1}^{N} I(X^n; Y_n | Y^{n-1}) = H(Y^N) - H(Y^N || X^N), with H(Y^N) = sum_n H(Y_n | Y^{n-1})",
 documented_definition="supplement §1.4.8, p.11-12 (supplement.txt:526-537): 'Directed information [42, 45] is a measure of information flow from a source time series x to a target time series y that is related to transfer entropy, but has no time lag between source and target [46, App. C]. The directed information can be computed as a difference between the conditional entropy of y given its own past, and causally conditioned entropy [42-44]. For the same reasons as for causally conditioned entropy, we restrict its computation up to a history length of 10.' Keywords 'directed, nonlinear, unsigned, bivariate, time-dependent'. GitBook information-theory.md:68-86 same text.",
 delegate_lib=DELEGATE + "gaussian.EntropyCalculatorMultiVariateGaussian (block entropies and the CausalEntropy terms)",
 implemented_as="A[i,j] = sum_{m=1}^{5} H(Y^m)/m - cce(i,j), where H(Y^m) is the Gaussian entropy of the m-dimensional delay vector of x_j (T-m+1 samples, z-scored, ddof=1) and cce(i,j) is the CausalEntropy value (5-term sum, shared cache). The first term is a sum of block-entropy-per-symbol estimates, not H(Y^5) = sum_m H(Y_m | Y^{m-1}). Since H(Y^m)/m >= H(Y_m|Y^{m-1}) for every m, the code value exceeds Massey's DI by sum_{m=1}^{5} H(Y^m)/m - H(Y^5) >= 0, a quantity that depends only on the target's autocorrelation (for an AR(1) target with coefficient phi it equals 0.6417*(-ln(1-phi^2)) nats).",
 implementation_trace=[CALC, DATA, DIRECTED, INIT, SETUP, GETCALC,
   "pyspi/statistics/infotheory.py:477-485 DirectedInfo(CausalEntropy, Directed).__init__(n=5): self._n = 5",
   "pyspi/statistics/infotheory.py:487-501 _compute_entropy_rates(targ): for i = 1..n: Yi = makeDelayEmbeddingVector(targ, i); entropy_rate_sum += H(Yi)/i",
   "pyspi/statistics/infotheory.py:503-510 bivariate: entropy_rates of z[j] minus CausalEntropy.bivariate(data, i, j) (cached, same key as cce_gaussian)"] + CCE_TRACE + ["pyspi/config.yaml:466-478 DirectedInfo configs: estimator gaussian (no n)"] + ENT_JIDT,
 deviation_from_documented="(1) First term is sum_m H(Y^m)/m, not 'the conditional entropy of y given its own past' (sum_m H(Y_m | Y^{m-1}) = H(Y^5)). (2) n = 5, not 10. (3) Includes the contemporaneous term (consistent with the docs' 'no time lag').",
 deviation_from_canonical="Not Massey's directed information: value = Massey DI_5 + [sum_{m=1}^{5} H(Y^m)/m - H(Y^5)]. Probe var2_bivariate_T1024: pyspi A[0,1] = 0.77460407 and A[1,0] = 0.19588843 reproduce the code-form numpy reference exactly, whereas canonical DI_5 = 0.64825 and 0.03690. Probe with an independent white source and AR(1) target (T=4096): phi=0.5 -> di 0.1803 (predicted excess 0.1846), phi=0.9 -> di 1.0553 (predicted 1.0656), phi=0 -> 0.0061, reverse direction approx 0.",
 units_and_range="nats; population value >= 0 and larger than Massey DI by a target-only term; asymmetric; scale invariant (shifts cancel); raises on singular embeddings",
 direction_convention="A[i,j] = DI from x_i (source) to x_j (target): entropy term from z[j] (infotheory.py:507), cce(src=i, targ=j). Probe var2_bivariate_T1024: A[0,1]=0.775 > A[1,0]=0.196",
 symmetry_expected="asym",
 already_documented="no",
 new_finding_candidates=[
   "CANDIDATE (formula, hypothesis confirmed): _compute_entropy_rates sums block entropies divided by block length (infotheory.py:493-499 'entropy_rate_sum + H(Yi)/i') instead of H(Y^n) = sum H(Y_m|Y^{m-1}), so di_gaussian = Massey DI + sum_m H(Y^m)/m - H(Y^5). Evidence: numpy code-form reference reproduces pyspi exactly (0.7746040739304512) while canonical DI_5 is 0.6482541289427077 on var2_bivariate_T1024 0->1.",
   "CANDIDATE (spurious directed information): because the excess depends only on the target's autocorrelation, an independent source gives large positive di for autocorrelated targets. Probe (independent white source, AR(1) target, T=4096): phi=0.9 -> di[src->y] = 1.0553 vs reverse 0.0008; analytic excess 0.641667*(-ln(1-phi^2)) = 1.0656.",
   "CANDIDATE (documented parameter mismatch): n = 5 (infotheory.py:483) vs documented 10 (same as cce).",
 ],
 proposed_checks=[
   chk(["var2_bivariate","gauss_ar1_pair","delayed_noise","iid_gaussian"], "pipeline", "from-scratch numpy code-form: sum_{m=1}^{5} H(Y^m)/m - CCE_5 (ddof=1 slogdet entropies) AND the canonical Massey form sum_{m=1}^{5} H(Y_m | Y^{m-1}) - CCE_5 (same stationary sliding-window estimates)", "independent-impl", "tolerance", "pyspi equals the code-form reference to 1e-10 and differs from the canonical form by exactly sum_m H(Y^m)/m - H(Y^5) (sample identity)"),
   chk(["bivariate_gaussian"], "pipeline", "analytic: for serially white targets both forms equal 5*MI = -2.5*ln(1-rho^2): rho=0.3 -> 0.2357767, rho=0.8 -> 2.5541281", "analytic", "statistical", "within 3 sampling SDs at T=4096, both directions (symmetric for these pairs)"),
   chk(["var2_bivariate","iid_gaussian"], "pipeline", "constructed independent pair (row 0 of var2_bivariate = AR(2) target, row 0 of iid_gaussian at the same T = independent source); analytic excess sum_{m=1}^{5} h(Y^m)/m - h(Y^5) from the AR(2) population autocovariance (Gamma0 and A1, A2 in the dataset)", "analytic", "statistical", "pyspi di(source -> AR target) approx equals the analytic excess (> 0) while canonical DI approx 0; reverse direction approx 0"),
   chk(["var2_bivariate","delayed_noise"], "pipeline", "known ground truth (x0 drives x1)", "analytic", "direction", "A[0,1] > A[1,0]; establishes A[i,j] = DI(i -> j)"),
 ],
)

U["infotheory.si.gaussian"] = dict(
 metric_name_standard="Stochastic interaction (Ay) of a bivariate first-order Markov process, Gaussian model",
 canonical_ref="Ay N. 2015, Entropy 17:2432-2458 'Information geometry on complexity and stochastic interaction' (SI as KL divergence to the split Markov kernel); Ay N. & Wennekers T. 2003, Neurocomputing 52-54:461-466",
 canonical_definition="SI = sum_v H(X_{v,t+1} | X_{v,t}) - H(X_{t+1} | X_t) for the joint process X = (X_1, X_2); Gaussian: 0.5*ln(sigma^2(x_{t+1}|x_t) sigma^2(y_{t+1}|y_t) / det Sigma((x,y)_{t+1} | (x,y)_t))",
 documented_definition="supplement §1.4.9, p.12 (supplement.txt:539-548): 'Stochastic interaction [47, 48] is a measure of integrated information between two processes in the context of their own past. It is quantified by the difference between the joint entropy of the bivariate process and the individual entropies of each univariate process. Both entropies are measured in context of (conditioned on) the history of the processes; we restrict this history to be only one-step, assuming a first-order Markov process.' Keywords 'undirected, nonlinear, unsigned, bivariate, time-dependent'. GitBook information-theory.md:184-202 same.",
 delegate_lib=DELEGATE + "gaussian.EntropyCalculatorMultiVariateGaussian (three conditional entropies = six entropy calls)",
 implemented_as="With tau = delay = 1: H_joint = H(xy(t) | xy(t-1)), H_src = H(x(t) | x(t-1)), H_targ = H(y(t) | y(t-1)), each via _compute_conditional_entropy (H(A,B) - H(B)) on T-1 aligned samples of z-scored data; returns H_src + H_targ - H_joint. Gaussian constants and the ddof scaling cancel, giving 0.5*ln(s_x|x * s_y|y / det S_xy|xy) from residual covariances of AR(1)/VAR(1) fits on the same samples. Undirected (upper triangle mirrored).",
 implementation_trace=[CALC, DATA, UNDIRECTED, INIT, SETUP, GETCALC,
   "pyspi/statistics/infotheory.py:513-522 StochasticInteraction(JIDTBase, Undirected).__init__(delay=1): identifier += '_k-1' (k denotes the delay)",
   "pyspi/statistics/infotheory.py:524-534 bivariate: x, y = data.to_numpy()[[i, j]] (each (T,1)); xy = concat; H_joint = _compute_conditional_entropy(xy[tau:], xy[:-tau]); H_src, H_targ likewise; return H_src + H_targ - H_joint",
   "pyspi/statistics/infotheory.py:180-193 _compute_conditional_entropy(X, Y) = H(X,Y) - H(Y)",
   "pyspi/config.yaml:480-492 StochasticInteraction configs: estimator gaussian (delay default 1)"] + ENT_JIDT,
 deviation_from_documented="none in substance (one-step history, individual minus joint conditional entropies). The prose says 'difference between the joint entropy ... and the individual entropies' (order reversed); the code returns individual minus joint, which is the non-negative orientation of Ay's definition.",
 deviation_from_canonical="none for Ay's SI with one-step Markov kernels under a Gaussian model (probe var2_bivariate_T1024: 0.16167711 equals numpy 0.1616771067541367). Plug-in estimator, no bias correction; for a VAR(2) process the one-step Markov assumption is misspecified (documented choice).",
 units_and_range="nats; >= 0 in population (sample values from three separately estimated conditional entropies on the same samples are non-negative up to rounding, by the determinant inequality); symmetric; scale invariant; raises on singular covariance",
 direction_convention="undirected: A[i,j] = A[j,i] = SI(x_i, x_j) (formula symmetric in x and y; upper triangle mirrored)",
 symmetry_expected="sym",
 already_documented="no",
 new_finding_candidates=[
   "CANDIDATE (robustness): for exactly redundant channels the joint conditional covariance is singular and JIDT raises NonPositiveDefiniteMatrixException (probe shared_envelope rows 0/2), which Calculator turns into an all-NaN si matrix (calculator.py:301-303).",
   "CANDIDATE (interpretation): under the Gaussian model SI includes both lagged cross-coupling and contemporaneous innovation correlation (det Sigma_E term), so it is non-zero for two independent-dynamics processes with correlated innovations; consistent with Ay's definition but worth stating in the docs.",
 ],
 proposed_checks=[
   chk(["var2_bivariate","gauss_ar1_pair","delayed_noise","iid_gaussian"], "pipeline", "from-scratch numpy: SI = H(x1|x0) + H(y1|y0) - H(x1,y1 | x0,y0) with ddof=1 slogdet Gaussian entropies on t = 1..T-1", "independent-impl", "tolerance", "abs difference <= 1e-12 on every pair and T"),
   chk(["gauss_ar1_pair"], "pipeline", "analytic population SI from dataset truth: Sigma_X, Sigma_XY = A Sigma_X, Sigma_E; sigma^2(x_v(t+1)|x_v(t)) = Sigma_X[v,v] - Sigma_XY[v,v]^2/Sigma_X[v,v]; SI = 0.5*ln(prod_v sigma^2_v / det Sigma_E)", "analytic", "statistical", "within 3 sampling SDs at T=4096, converging over T"),
   chk(["iid_gaussian"], "pipeline", "analytic null SI = 0 for independent white processes", "analytic", "statistical", "small positive values of order (number of extra parameters)/(2N); symmetric matrix exactly"),
 ],
)
