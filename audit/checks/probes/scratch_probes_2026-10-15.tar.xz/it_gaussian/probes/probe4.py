import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
import jpype as jp
for name in ['infodynamics.measures.continuous.gaussian.EntropyCalculatorMultiVariateGaussian',
             'infodynamics.measures.continuous.EntropyCalculatorMultiVariateCommon',
             'infodynamics.measures.continuous.gaussian.MutualInfoCalculatorMultiVariateGaussian',
             'infodynamics.measures.continuous.gaussian.TransferEntropyCalculatorGaussian',
             'infodynamics.measures.continuous.gaussian.ConditionalMutualInfoCalculatorMultiVariateGaussian']:
    C = jp.JClass(name); jc = C.class_
    print(name, "super:", jc.getSuperclass().getName() if jc.getSuperclass() else None)
    print("  fields:", [f.getName() for f in jc.getDeclaredFields()])
    print("  methods:", sorted({m.getName() for m in jc.getDeclaredMethods()}))
E = jp.JClass('infodynamics.measures.continuous.gaussian.EntropyCalculatorMultiVariateGaussian')()
for p in ['NORMALISE','BIAS_CORRECTION','NUM_DIMENSIONS','NOISE_SEED']:
    try: print("entropy getProperty", p, E.getProperty(p))
    except Exception as ex: print("entropy getProperty", p, "EXC", ex)
# does entropy normalise? feed scaled data
x = np.random.default_rng(1).standard_normal(500)
for s in [1.0, 10.0]:
    E.initialise(1); E.setObservations(jp.JArray(jp.JDouble,1)(x*s)); print("scale", s, "H", E.computeAverageLocalOfObservations(), "ref", 0.5*(1+np.log(2*np.pi))+0.5*np.log(np.var(x*s, ddof=1)))
E.setProperty("NORMALISE","true"); E.initialise(1); E.setObservations(jp.JArray(jp.JDouble,1)(x*10)); print("after NORMALISE=true, scale 10 H", E.computeAverageLocalOfObservations())
