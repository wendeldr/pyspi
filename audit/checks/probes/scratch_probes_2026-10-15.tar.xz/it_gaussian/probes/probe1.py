import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
print("jvm", harness.ensure_jvm())
import pyspi.statistics.infotheory as it
from pyspi.data import Data
import contextlib, io

d = np.load('/media/dan/Data/git/pyspi/audit/checks/data/var2_bivariate_T1024.npz')
X = d['x'] if 'x' in d else d[d.files[0]]
print("files", d.files, X.shape)
with contextlib.redirect_stdout(io.StringIO()):
    data = Data(X.copy(), dim_order='ps', normalise=True)
Z = data.to_numpy(squeeze=True)
print("z std ddof1", Z.std(axis=1, ddof=1))

def H(cols):
    M = np.column_stack(cols); d_ = M.shape[1]
    C = np.atleast_2d(np.cov(M, rowvar=False, ddof=1))
    return 0.5*(d_*(1+np.log(2*np.pi)) + np.log(np.linalg.det(C)))

spis = {
 'je': it.JointEntropy(estimator='gaussian'),
 'ce': it.ConditionalEntropy(estimator='gaussian'),
 'mi': it.MutualInfo(estimator='gaussian'),
 'tlmi': it.TimeLaggedMutualInfo(estimator='gaussian'),
 'gc1': it.TransferEntropy(estimator='gaussian', k_history=1, l_history=1),
 'gcauto': it.TransferEntropy(estimator='gaussian', auto_embed_method='MAX_CORR_AIS', k_search_max=10, tau_search_max=2),
 'tes1': it.TransferEntropy(estimator='symbolic', k_history=1, l_history=1),
 'tes10': it.TransferEntropy(estimator='symbolic', k_history=10, l_history=1),
 'xme1': it.CrossmapEntropy(estimator='gaussian', history_length=1),
 'xme10': it.CrossmapEntropy(estimator='gaussian', history_length=10),
 'cce': it.CausalEntropy(estimator='gaussian'),
 'di': it.DirectedInfo(estimator='gaussian'),
 'si': it.StochasticInteraction(estimator='gaussian'),
}
A = {}
for k, s in spis.items():
    A[k] = s.multivariate(data)
    print(k, s.identifier, s.labels, type(s).__mro__[1].__name__, "\n", A[k])
for k in ['gc1','gcauto','tes1','tes10']:
    c = spis[k]._calc
    print(k, c.getClass().getName(), {p: str(c.getProperty(p)) for p in ['k_HISTORY','k_TAU','l_HISTORY','l_TAU','DELAY','AUTO_EMBED_METHOD','AUTO_EMBED_K_SEARCH_MAX','AUTO_EMBED_TAU_SEARCH_MAX','BIAS_CORRECTION','NORMALISE']})
for k in ['mi','tlmi']:
    c = spis[k]._calc
    print(k, c.getClass().getName(), {p: str(c.getProperty(p)) for p in ['BIAS_CORRECTION','NORMALISE','TIME_DIFF']})
print("entropy calc", spis['je']._entropy_calc.getClass().getName())
x, y = Z
H1 = 0.5*(1+np.log(2*np.pi)); print("H1 const", H1, "data.entropy", data.entropy)
r = np.corrcoef(x,y)[0,1]
print("je ref", H([x,y]), "ce ref H(y|x)", H([x,y])-H([x]))
print("mi ref", -0.5*np.log(1-r**2))
print("tlmi ref 0->1", -0.5*np.log(1-np.corrcoef(x[:-1],y[1:])[0,1]**2), "1->0", -0.5*np.log(1-np.corrcoef(y[:-1],x[1:])[0,1]**2))
def ols_rss(yv, Xs):
    Xm = np.column_stack([np.ones(len(yv))]+Xs); b,*_ = np.linalg.lstsq(Xm, yv, rcond=None); e = yv-Xm@b; return e@e
def te1(src, tg):
    yf, yp, xp = tg[1:], tg[:-1], src[:-1]
    return 0.5*np.log(ols_rss(yf,[yp])/ols_rss(yf,[yp,xp]))
print("te k1 ref 0->1", te1(x,y), "1->0", te1(y,x))
def te_k(src,tg,k):
    T=len(tg); yf=tg[k:]; yp=[tg[k-m:T-m] for m in range(1,k+1)]; xp=[src[k-1:T-1]]
    return 0.5*np.log(ols_rss(yf,yp)/ols_rss(yf,yp+xp))
print("te k10 l1 ref 0->1", te_k(x,y,10), "1->0", te_k(y,x,10))
def xme(src,tg,k):
    T=len(tg); yf=tg[k:]; lags=[1]+list(range(2,k)); xp=[src[k-m:T-m] for m in lags]
    return H(xp+[yf])-H(xp), lags
print("xme1 ref 0->1", xme(x,y,1), "xme10", xme(x,y,10))
def cce(src,tg,n=5):
    T=len(tg); s=0
    for i in range(1,n+1):
        yf=tg[i-1:]; yp=[tg[i-1-m:T-m] for m in range(1,i)]; xp=[src[i-1-m:T-m] for m in range(0,i)]
        s+= H(yp+xp+[yf]) - H(yp+xp)
    return s
def block(tg,i):
    T=len(tg); return H([tg[i-1-m:T-m] for m in range(0,i)])
def di_code(src,tg,n=5): return sum(block(tg,i)/i for i in range(1,n+1)) - cce(src,tg,n)
def di_canon(src,tg,n=5):
    T=len(tg); s=0
    for i in range(1,n+1):
        yf=tg[i-1:]; yp=[tg[i-1-m:T-m] for m in range(1,i)]
        s += (H(yp+[yf])-H(yp)) if i>1 else H([yf])
    return s - cce(src,tg,n)
print("cce ref 0->1", cce(x,y), "1->0", cce(y,x))
print("di code-form ref 0->1", di_code(x,y), "1->0", di_code(y,x))
print("di canonical 0->1", di_canon(x,y), "1->0", di_canon(y,x))
def si(x,y):
    hx = H([x[1:],x[:-1]])-H([x[:-1]]); hy=H([y[1:],y[:-1]])-H([y[:-1]])
    hxy = H([x[1:],y[1:],x[:-1],y[:-1]])-H([x[:-1],y[:-1]])
    return hx+hy-hxy
print("si ref", si(x,y))
