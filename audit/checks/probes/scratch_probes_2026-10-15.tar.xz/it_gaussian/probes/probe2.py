import sys, numpy as np, contextlib, io
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data

def H(cols):
    M = np.column_stack(cols); C = np.atleast_2d(np.cov(M, rowvar=False, ddof=1))
    return 0.5*(M.shape[1]*(1+np.log(2*np.pi)) + np.log(np.linalg.det(C)))
def MI(a, b): return H(a)+H(b)-H(a+b)
def emb(s, k, tau, start, n):  # JIDT makeDelayEmbeddingVector(data,k,tau,start,n): row r = [s[t], s[t-tau],...], t=start+r
    return [s[start - i*tau: start - i*tau + n] for i in range(k)]
def ais_select(s, kmax=10, taumax=2):
    best=-np.inf; bk=bt=1; T=len(s); log=[]
    for k in range(1,kmax+1):
        for tau in range(1,taumax+1):
            n = T-(k-1)*tau-1
            past = emb(s,k,tau,(k-1)*tau,n); nxt=[s[(k-1)*tau+1:(k-1)*tau+1+n]]
            a = MI(past,nxt) - k/(2.0*n)
            log.append((k,tau,round(a,5)))
            if a>best: best, bk, bt = a, k, tau
            if k==1: break
    return bk, bt, log
def te(src, tg, k, kt, l, lt, delay=1):
    T=len(tg); st=max((k-1)*kt,(l-1)*lt+delay-1); n=T-st-1
    yp=emb(tg,k,kt,st,n); yf=[tg[st+1:st+1+n]]; xp=emb(src,l,lt,st+1-delay,n)
    return (H(xp+yp)+H(yf+yp)-H(xp+yf+yp)-H(yp))
for name in ['var2_bivariate_T1024','delayed_noise_T256','var2_bivariate_T64']:
    X = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{name}.npz')['x']
    with contextlib.redirect_stdout(io.StringIO()):
        data = Data(X.copy(), normalise=True)
    Z = data.to_numpy(squeeze=True); P = Z.shape[0]
    s = it.TransferEntropy(estimator='gaussian', auto_embed_method='MAX_CORR_AIS', k_search_max=10, tau_search_max=2)
    sel = {p: ais_select(Z[p])[:2] for p in range(P)}
    print(name, "AIS selection per process", sel)
    maxd=0
    for i in range(P):
        for j in range(P):
            if i==j: continue
            v = s.bivariate(data, i=i, j=j)
            c = s._calc
            got = tuple(int(str(c.getProperty(p))) for p in ['k_HISTORY','k_TAU','l_HISTORY','l_TAU'])
            k,kt = sel[j]; l,lt = sel[i]
            ref = te(Z[i],Z[j],k,kt,l,lt)
            maxd=max(maxd,abs(v-ref))
            if (k,kt,l,lt)!=got: print("  param mismatch", i,j,got,(k,kt,l,lt))
    print("  max |pyspi - ref|", maxd)
print(ais_select(np.load('/media/dan/Data/git/pyspi/audit/checks/data/var2_bivariate_T1024.npz')['x'][0])[2])
# xme k=2 vs k=1
X = np.load('/media/dan/Data/git/pyspi/audit/checks/data/var2_bivariate_T1024.npz')['x']
with contextlib.redirect_stdout(io.StringIO()):
    data = Data(X.copy(), normalise=True)
for k in [1,2,3]:
    print("xme k", k, it.CrossmapEntropy(estimator='gaussian', history_length=k).bivariate(data,i=0,j=1))
# symbolic == gaussian bitwise?
a = it.TransferEntropy(estimator='symbolic', k_history=1, l_history=1).multivariate(data)
b = it.TransferEntropy(estimator='gaussian', k_history=1, l_history=1).multivariate(data)
print("symbolic==gaussian bitwise", np.array_equal(a,b,equal_nan=True))
# normalise=False behaviour: ce asymmetry and je dependence on scale
d2 = np.load('/media/dan/Data/git/pyspi/audit/checks/data/scaled_offset_T1024.npz')['x']
with contextlib.redirect_stdout(io.StringIO()):
    dn = Data(d2.copy(), normalise=False); dz = Data(d2.copy(), normalise=True)
for nm, dd in [('raw',dn),('z',dz)]:
    print(nm, "ce\n", np.round(it.ConditionalEntropy(estimator='gaussian').multivariate(dd),4))
    print(nm, "mi\n", np.round(it.MutualInfo(estimator='gaussian').multivariate(dd),6))
