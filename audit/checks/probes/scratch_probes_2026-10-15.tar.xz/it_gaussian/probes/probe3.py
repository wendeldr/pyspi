import sys, numpy as np, contextlib, io
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
rng = np.random.default_rng(5)
T=4096
for phi in [0.0, 0.5, 0.9]:
    src = rng.standard_normal(T); e = rng.standard_normal(T+500); y=np.zeros(T+500)
    for t in range(1,T+500): y[t]=phi*y[t-1]+e[t]
    y=y[500:]
    with contextlib.redirect_stdout(io.StringIO()):
        d = Data(np.vstack([src,y]), normalise=True)
    di = it.DirectedInfo(estimator='gaussian').multivariate(d)
    print(f"phi={phi}: di[src->y]={di[0,1]:.4f} di[y->src]={di[1,0]:.4f} predicted bias 0.6417*-ln(1-phi^2)={0.641667*-np.log(1-phi**2):.4f}")
# degenerate: identical series
X = np.load('/media/dan/Data/git/pyspi/audit/checks/data/shared_envelope_T256.npz')['x']
with contextlib.redirect_stdout(io.StringIO()):
    d = Data(X[[0,2]].copy(), normalise=True)
print("identical rows equal:", np.array_equal(d.to_numpy(squeeze=True)[0], d.to_numpy(squeeze=True)[1]))
for nm, s in [('je',it.JointEntropy()),('ce',it.ConditionalEntropy()),('mi',it.MutualInfo()),('tlmi',it.TimeLaggedMutualInfo()),
              ('gc1',it.TransferEntropy(k_history=1,l_history=1)),('xme1',it.CrossmapEntropy(history_length=1)),('cce',it.CausalEntropy()),('di',it.DirectedInfo()),('si',it.StochasticInteraction())]:
    try:
        print(nm, s.bivariate(d, i=0, j=1))
    except Exception as ex:
        print(nm, "EXC", type(ex).__name__, str(ex)[:120])
