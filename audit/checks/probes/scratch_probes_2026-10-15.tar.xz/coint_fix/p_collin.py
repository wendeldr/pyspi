import sys, warnings, numpy as np
sys.path.insert(0, '/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/coint')
from common import *
import io, contextlib
from pyspi.data import Data
from statsmodels.tsa.vector_ar.vecm import coint_johansen
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x.copy(), dim_order='ps', normalise=True, detrend=False)
cfgs=[(0,10),(0,1),(1,10),(1,1)]
def run(tag, pair):
    for det,k in cfgs:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                r = coint_johansen(pair.T, det, k)
            print(f'{tag:40s} det{det} k{k:2d} OK  eig={np.round(r.eig,4)} maxeig0={r.max_eig_stat[0]:.2f} trace0={r.trace_stat[0]:.2f}')
        except Exception as e:
            print(f'{tag:40s} det{det} k{k:2d} RAISES {type(e).__name__}: {e}')
# record's original z: seed-0 random walk, z-scored by Data, as in coint/probe3.py
z = np.random.default_rng(0).standard_normal(256).cumsum()
P = mk(np.vstack([z, 3*z+1])).to_numpy(squeeze=True); run('probe3 rw seed0 (Data-normalised)', P)
run('probe3 rw seed0 raw z,3z+1', np.vstack([z,3*z+1]))
for name in ['cointegrated','iid_gaussian','trending','shared_envelope']:
    for T in (256,1024):
        x,_ = load(name,T); zz = mk(x).to_numpy(squeeze=True)
        for ch in (0,1):
            c = zz[ch]; run(f'{name}_T{T} ch{ch} z vs 3z+1', np.vstack([c,3*c+1]))
        if name=='shared_envelope':
            print('x2==x0 bitwise:', np.array_equal(zz[0], zz[2]))
            run(f'{name}_T{T} pair (0,2)', zz[[0,2]])
