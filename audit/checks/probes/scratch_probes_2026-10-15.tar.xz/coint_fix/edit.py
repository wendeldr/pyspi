import re, yaml, pathlib
R = pathlib.Path('/media/dan/Data/git/pyspi/audit/records')
ex = {
 'johansen_order-0_ardiff-10': ('iid_gaussian T=256 ch0, det=0, k=10 -> "Singular matrix"',
    'shared_envelope T=256 ch0: eig [0.9998, 0.5372], trace 2222.44; iid_gaussian T=1024 ch0: eig [0.0465, -0.0319], trace 16.41'),
 'johansen_order-0_ardiff-1': ('cointegrated T=256 ch0, det=0, k=1 -> "Singular matrix"',
    'shared_envelope T=256 ch1: eig [2.1258, -30.6182], trace -907.34; trending T=1024 ch0: eig [10.8869, 0.0441], trace -2295.55'),
 'johansen_order-1_ardiff-10': ('iid_gaussian T=256 ch0, det=1, k=10 -> "Matrix is not positive definite"',
    'cointegrated T=256 ch0: eig [0.0074, -0.395], trace -79.73; iid_gaussian T=256 ch1: eig [0.088, -0.9491], trace -140.94'),
 'johansen_order-1_ardiff-1': ('iid_gaussian T=256 ch0, det=1, k=1 -> "Matrix is not positive definite"',
    'shared_envelope T=1024 ch0: eig [-0.4847, -5.6898], trace -2346.31; cointegrated T=256 ch1: eig [0.0096, -0.2992], trace -64.06'),
}
old_cand = re.compile(r"  - 'CANDIDATE \(robustness\): exactly collinear pairs raise numpy LinAlgError.*?blanks every pair\.'\n", re.S)
old_units = re.compile(r"raises LinAlgError \(singular inverse or non-PD cholesky, vecm\.py:690-694\) for\s+exactly collinear pairs, which makes the whole pipeline matrix NaN;", re.S)
for u, (raise_ex, ok_ex) in ex.items():
    p = R / f'misc.coint.{u}.yaml'; s = p.read_text()
    s, n0 = re.subn(r"both >= 0, trace_stat >= max_eig_stat,", "both >= 0 and trace_stat >= max_eig_stat on non-degenerate pairs,", s)
    s, n1 = old_units.subn("for exactly collinear pairs the outcome is input-dependent: bitwise-identical channels (shared_envelope x2 == x0) raise LinAlgError (singular inverse or non-PD cholesky,\n    vecm.py:690-694), which makes the whole pipeline matrix NaN, while z vs 3z+1 can also return without error with out-of-range values (negative eigenvalues/statistics); see new_finding_candidates;", s)
    cand = ("  - 'CANDIDATE (robustness): exactly collinear pairs give an input-dependent outcome in coint_johansen (vecm.py:650-718), either a numpy LinAlgError or a silently out-of-range value. (a) Bitwise-identical\n"
            "    channels (shared_envelope x2 == x0 after Data normalisation) raised \"Singular matrix\" in all four Johansen configs at T=256 and T=1024; Calculator.compute (calculator.py:300-302) then stores an\n"
            "    all-NaN matrix for the SPI, so one duplicated channel blanks every pair. (b) For z vs 3z+1 (z a Data-normalised channel, coint_johansen called directly on [z, 3z+1]) over\n"
            "    {cointegrated, iid_gaussian, trending, shared_envelope} x T {256, 1024} x channels {0, 1} x four configs, 29/64 raised and 35/64 returned without error, often with negative eigenvalues, negative\n"
            f"    statistics or eigenvalues near 1 with very large statistics. This config: raises e.g. {raise_ex}; returns e.g. {ok_ex}. The z used in the\n"
            "    earlier probe (seed-0 random walk, T=256, coint/probe3.py) passed through Data raises in all four configs. Probe: coint_fix/p_collin.py. Which inputs raise vs return, and whether a returned\n"
            "    value can be distinguished from a valid one, is for the check stage.'\n")
    s, n2 = old_cand.subn(cand, s)
    assert (n0, n1, n2) == (1, 1, 1), (u, n0, n1, n2)
    yaml.safe_load(s); p.write_text(s); print(u, 'ok')
# aeg wording
p = R / 'misc.coint.aeg.yaml'; s = p.read_text()
s2 = s.replace("(pack hypothesis confirmed)", "(pack hypothesis; the probes below are consistent with it, confirmation is for the check stage)")
assert s2 != s; yaml.safe_load(s2); p.write_text(s2)
# notes
p = pathlib.Path('/media/dan/Data/git/pyspi/audit/notes/coint.md'); s = p.read_text()
old = "- **Robustness (candidate).** An exactly collinear pair (shared_envelope, where x2 == x0) raises numpy `LinAlgError` (\"Singular matrix\"). The pair z and 3z+1 at order-1, k=10 raises \"Matrix is not positive definite\". Either way the Calculator blanks the whole matrix.\n"
new = ("- **Robustness (candidate).** What happens with an exactly collinear pair depends on the input.\n"
       "  - Bitwise-identical channels (shared_envelope, where x2 == x0) raised numpy `LinAlgError` (\"Singular matrix\") in all four configs at T=256 and T=1024. The Calculator then blanks the whole matrix.\n"
       "  - A pair z and 3z+1 (z a normalised channel, `coint_johansen` called directly) raised in 29 of 64 probed cases (4 datasets × 2 T × 2 channels × 4 configs). The other 35 returned without error, often with out-of-range values: negative eigenvalues, negative statistics (cointegrated T=256 ch0, order-1, k=10: trace −79.73), or eigenvalues near 1 with very large statistics (shared_envelope T=256 ch0, order-0, k=10: trace 2222.44). These values would enter the matrix silently (probe `coint_fix/p_collin.py`).\n"
       "  - Both stats are ≥ 0 with trace ≥ max-eig only on non-degenerate pairs.\n")
assert old in s; s = s.replace(old, new)
old2 = "- **Index-order dependence (pack hypothesis confirmed).**"
assert old2 in s; s = s.replace(old2, "- **Index-order dependence (candidate; pack hypothesis, probes consistent with it).**")
p.write_text(s); print('notes ok')
