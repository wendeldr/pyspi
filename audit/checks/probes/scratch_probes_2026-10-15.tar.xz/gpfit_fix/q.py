import sys, warnings, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi')
sys.path.insert(0, '/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/gpfit')
from pyspi.data import Data
from pyspi.statistics.misc import GPModel
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.base import clone
D = '/media/dan/Data/git/pyspi/audit/checks/data/'
def own_mean(X, y, kern):
    p = kern.get_params(); c = p['k1__k1__constant_value']; w = p['k1__k2__noise_level']; x = X[:, 0]
    if 'k2__length_scale' in p:
        l = p['k2__length_scale']; Kf = c + np.exp(-0.5*(x[:,None]-x[None,:])**2/l**2)
    else:
        s0 = p['k2__sigma_0']; Kf = c + s0**2 + np.outer(x, x)
    return Kf @ np.linalg.solve(Kf + (w+1e-10)*np.eye(len(x)), y)
mx_m = mx_f = 0
for name in ['bivariate_gaussian_T64','bivariate_gaussian_T256','nonlinear_dependence_T256','anm_T256','iid_gaussian_T256','delayed_noise_T256']:
    x = np.load(f'{D}{name}.npz')['x']
    for k in ['DotProduct','RBF']:
        spi = GPModel(kernel=k); dat = Data(x, dim_order='ps'); spi.multivariate(dat); z = dat.to_numpy()
        for (i,j) in [(0,1),(1,0),(2,3),(3,2)][:(4 if x.shape[0]>=4 else 2)]:
            X, y = z[i], np.ravel(z[j])
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                gp = GaussianProcessRegressor(kernel=clone(spi._kernel)).fit(X, y)
            yp = gp.predict(X); om = own_mean(X, y, gp.kernel_)
            dm = abs(np.mean((om-y)**2)-np.mean((yp-y)**2)); df = np.max(np.abs(om-yp))
            mx_m = max(mx_m, dm); mx_f = max(mx_f, df)
            print(name, k, i, j, f'dMSE={dm:.1e} max|df|={df:.1e}')
print('MAX dMSE', mx_m, 'MAX |f_own - f_sk|', mx_f)
w = 9.999999999999997e-06; T = 256
print('no jitter', (w/(1+w))**2*(T-1)/T, 'jitter', ((w+1e-10)/(1+w+1e-10))**2*(T-1)/T)
