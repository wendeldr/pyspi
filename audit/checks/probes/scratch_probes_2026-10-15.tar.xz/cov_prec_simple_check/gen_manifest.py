"""Generate audit/checks/manifest/cov_prec_simple.json (run once; output is the artifact)."""
import json

ESTS = ["EmpiricalCovariance", "LedoitWolf", "OAS", "ShrunkCovariance"]
PROBE = "probes/cov_prec_simple_probes.py"
runs = []


def add(unit, ident, ds, T, path, tag, probe=None):
    runs.append(dict(run_id=f"{unit}|{ds}|{T}|{path}|{tag}", unit_id=unit, identifier=ident, dataset=ds,
                     T=T, path=path, processes=None, seed=42,
                     probe=None if probe is None else {"module": PROBE, "function": probe}))


for est in ESTS:
    for kind in ("cov", "prec"):
        u = f"basic.{kind}.{est}"
        ident, sq = f"{kind}_{est}", f"{kind}-sq_{est}"
        # (A) kernel: estimator isolated, independent numpy reference
        kds = ["bivariate_gaussian", "scaled_offset", "sparse_precision", "cointegrated", "iid_gaussian"]
        if kind == "prec":
            kds = kds + ["var2_bivariate"]
        for ds in kds:
            add(u, ident, ds, 1024, "kernel", "ref")
        add(u, ident, "bivariate_gaussian", 64, "kernel", "ref")
        add(u, ident, "sparse_precision", 64, "kernel", "ref")
        # (B) pipeline (z-score ddof=1) and pipeline-detrend
        for ds in ["bivariate_gaussian", "scaled_offset", "trending", "iid_gaussian", "cointegrated",
                   "sparse_precision"]:
            add(u, ident, ds, 1024, "pipeline", "ref")
        for ds in ["bivariate_gaussian", "trending"]:
            add(u, ident, ds, 64, "pipeline", "ref")
        for ds in ["trending", "cointegrated"]:
            add(u, ident, ds, 1024, "pipeline-detrend", "ref")
        # (C) squared variant
        add(u, sq, "bivariate_gaussian", 1024, "kernel", "sq-ref")
        add(u, sq, "bivariate_gaussian", 1024, "pipeline", "sq-ref")
        # (D) documented claim (expected to fail: records the size of the gap)
        if kind == "cov":
            for T in (64, 1024):
                add(u, ident, "bivariate_gaussian", T, "pipeline", "doc-corr")
        else:
            for ds in ["bivariate_gaussian", "sparse_precision", "cointegrated"]:
                add(u, ident, ds, 1024, "pipeline", "doc-pcorr")
        # (E) population truth, statistical
        for T in (64, 256, 1024, 4096):
            add(u, ident, "bivariate_gaussian", T, "pipeline", "truth")
        add(u, ident, "scaled_offset", 1024, "pipeline", "truth")
        add(u, ident, "scaled_offset", 4096, "pipeline", "truth")
        for T in (256, 1024, 4096):
            add(u, ident, "sparse_precision", T, "kernel", "truth")
        if kind == "cov":
            add(u, ident, "scaled_offset", 4096, "kernel", "truth")
        # (F) null dataset
        for T in (64, 256, 1024, 4096):
            add(u, ident, "iid_gaussian", T, "pipeline", "null")
        # (G) symmetry on direction datasets
        for ds in ["delayed_noise", "var2_bivariate", "var2_chain", "logistic_maps_chaotic", "anm",
                   "cointegrated"]:
            add(u, ident, ds, 1024, "pipeline", "sym")
        # (H) singular input: duplicated channel, and average reference (rank P-1)
        for T in (256, 1024):
            add(u, ident, "shared_envelope", T, "pipeline", "singular")
        add(u, ident, "bivariate_gaussian", 1024, "pipeline", "avgref", probe="spi")
        add(u, ident, "iid_gaussian", 1024, "pipeline", "stackB-avgref", probe="spi")
        # (I) EEG-like P = 19 stacks
        for st in ("stackA", "stackB"):
            add(u, ident, "iid_gaussian", 1024, "pipeline", st, probe="spi")
            add(u, ident, "iid_gaussian", 1024, "pipeline-detrend", st, probe="spi")
            add(u, ident, "iid_gaussian", 1024, "kernel", st, probe="spi")
        # (J) in-place mutation / aliasing
        add(u, None, "bivariate_gaussian", 256, "pipeline", "mutation", probe="mutation")
        # (K) pipeline-precision scaling identity (Theta_pipe = D1 Theta_kernel D1)
        if kind == "prec" and est == "EmpiricalCovariance":
            for T in (1024, 4096):
                add(u, ident, "sparse_precision", T, "pipeline", "scaling")
        # (L) OAS: Chen et al. 2010 Eq. 23 (2/p terms kept), expected to differ
        if est == "OAS":
            for ds in ["bivariate_gaussian", "sparse_precision"]:
                for T in (64, 1024):
                    add(u, ident, ds, T, "kernel", "eq23")
            for st in ("stackA", "stackB"):
                add(u, ident, "iid_gaussian", 64, "kernel", f"{st}-eq23", probe="spi")
                add(u, ident, "iid_gaussian", 1024, "pipeline", f"{st}-eq23", probe="spi")

# fitted shrinkage readouts (cov units of the two data-driven shrinkage estimators)
for est in ("LedoitWolf", "OAS"):
    u = f"basic.cov.{est}"
    for T in (64, 256, 1024, 4096):
        add(u, None, "bivariate_gaussian", T, "kernel", "shrink", probe="shrinkage")
        add(u, None, "sparse_precision", T, "kernel", "shrink", probe="shrinkage")
        add(u, None, "iid_gaussian", T, "kernel", "stackA-shrink", probe="shrinkage")
        add(u, None, "iid_gaussian", T, "kernel", "stackB-shrink", probe="shrinkage")
        add(u, None, "iid_gaussian", T, "pipeline", "stackA-shrink", probe="shrinkage")
        add(u, None, "iid_gaussian", T, "pipeline", "stackB-shrink", probe="shrinkage")
    for ds in ("bivariate_gaussian", "sparse_precision"):
        add(u, None, ds, 1024, "pipeline", "shrink", probe="shrinkage")

# estimators of other families that share the cache code path (open question 5)
add("basic.cov.EmpiricalCovariance", None, "bivariate_gaussian", 256, "pipeline", "mutation-others",
    probe="mutation_others")

ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids)), "duplicate run_id"
out = "/media/dan/Data/git/pyspi/audit/checks/manifest/cov_prec_simple.json"
with open(out, "w") as f:
    json.dump({"family": "cov_prec_simple", "runs": runs}, f, indent=1)
print(len(runs), "runs ->", out)
