import json, collections, math
r=json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/results/cov_prec_simple.json'))
units=sorted({v['unit_id'] for v in r.values()})
def grp(tag):
    for g in ['shrink','eq23','avgref','doc-','sq-ref','mutation','truth','null','sym','singular','scaling']:
        if g in tag: return g
    if tag.startswith('stack'): return 'stack'
    return tag
for u in units:
    rows=[(k,v) for k,v in r.items() if v['unit_id']==u]
    print('=====',u, len(rows),'runs', sum(1 for k,v in rows if v.get('pass')),'pass')
    G=collections.defaultdict(list)
    for k,v in rows: G[grp(k.split('|')[-1])].append((k,v))
    for g,l in sorted(G.items()):
        ma=max((v.get('max_abs') or 0) for k,v in l); mr=max((v.get('max_rel') or 0) for k,v in l)
        mz=max((v.get('max_z') or 0) for k,v in l)
        sy=[v.get('ref_pyspi_sym_max_abs') for k,v in l if isinstance(v.get('ref_pyspi_sym_max_abs'),float) and not math.isnan(v.get('ref_pyspi_sym_max_abs'))]
        print(f'  {g:10s} n={len(l):3d} pass={sum(1 for k,v in l if v.get("pass")):3d} max_abs={ma:.3g} max_rel={mr:.3g} max_z={mz:.3g} sym_max={max(sy) if sy else None} sym_nonzero_runs={sum(1 for s in sy if s>0)}/{len(sy)}')
