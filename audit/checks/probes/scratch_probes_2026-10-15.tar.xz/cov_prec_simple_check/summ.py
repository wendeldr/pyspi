import json, collections, sys
r=json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/results/cov_prec_simple.json'))
units=sorted({v['unit_id'] for v in r.values()})
sel = sys.argv[1] if len(sys.argv)>1 else None
for u in units:
    if sel and sel not in u: continue
    print('=====',u)
    by=collections.defaultdict(list)
    for k,v in sorted(r.items()):
        if v['unit_id']!=u: continue
        tag=k.split('|')[-1]; by[tag].append((k,v))
    for tag,lst in by.items():
        npass=sum(1 for k,v in lst if v.get('pass'))
        print(f' [{tag}] {npass}/{len(lst)} pass')
        for k,v in lst:
            keys={kk:vv for kk,vv in v.items() if kk.startswith('ref_') or kk in('max_abs','max_rel','max_z')}
            short={kk.replace('ref_',''):(float('%.4g'%vv) if isinstance(vv,float) else vv) for kk,vv in keys.items() if kk not in('ref_P',)}
            print('   ', '|'.join(k.split('|')[1:4]), 'PASS' if v.get('pass') else 'FAIL', short)
