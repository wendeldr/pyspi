"""Append the check-stage block to the eight cov_prec_simple records (status traced -> checked)."""
import collections
import json
import math
import sys
from pathlib import Path

import yaml

AUDIT = Path("/media/dan/Data/git/pyspi/audit")
R = json.loads((AUDIT / "checks/out/results/cov_prec_simple.json").read_text())
EST = ["EmpiricalCovariance", "LedoitWolf", "OAS", "ShrunkCovariance"]


def runs(unit, pred):
    return sorted(k for k, v in R.items() if v["unit_id"] == unit and pred(k.split("|")[-1]))


def g(rid, key):
    v = R[rid].get(key)
    if v is None:
        v = R[rid].get("ref_" + key)
    return v


def f(x, d=4):
    return f"{x:.{d}g}"


def grp_stats(unit, pred):
    ids = runs(unit, pred)
    npass = sum(1 for k in ids if R[k].get("pass"))
    ma = max((R[k].get("max_abs") or 0.0) for k in ids)
    mr = max((R[k].get("max_rel") or 0.0) for k in ids)
    return ids, npass, ma, mr


def sym_stats(unit):
    vals = [(R[k]["ref_pyspi_sym_max_abs"], k) for k in runs(unit, lambda t: True)
            if isinstance(R[k].get("ref_pyspi_sym_max_abs"), float) and not math.isnan(R[k]["ref_pyspi_sym_max_abs"])]
    nz = sum(1 for s, _ in vals if s > 0)
    mx = max(vals)
    return len(vals), nz, mx


def rid(unit, ds, T, path, tag):
    return f"{unit}|{ds}|{T}|{path}|{tag}"


SUPP = ("supplement 1.1.1-1.1.2 (supplement.txt:136-171) lists only the 16 cov_/prec_ identifiers; "
        "pyspi/config.yaml:21-36, 56-71 adds the -sq variants")


def block(est, kind):
    u = f"basic.{kind}.{est}"
    out = {}
    is_cov = kind == "cov"
    ref_ids, ref_pass, ref_ma, ref_mr = grp_stats(u, lambda t: t in ("ref", "sq-ref", "sym", "singular", "avgref")
                                                  or t in ("stackA", "stackB", "stackB-avgref"))
    stack_ids, _, st_ma, st_mr = grp_stats(u, lambda t: t in ("stackA", "stackB", "stackB-avgref"))
    truth_ids, truth_pass, _, _ = grp_stats(u, lambda t: t in ("truth", "null"))
    doc_ids, _, doc_ma, doc_mr = grp_stats(u, lambda t: t.startswith("doc-"))
    mut_ids = runs(u, lambda t: t.startswith("mutation"))
    n_sym, nz_sym, (sym_max, sym_rid) = sym_stats(u)
    tot = runs(u, lambda t: True)
    tot_pass = sum(1 for k in tot if R[k].get("pass"))

    # ---------------- shared fields
    out["check_method"] = "independent-impl"
    out["check_reference"] = (
        "audit/checks/refs/cov_prec_simple.py:ref_matrix/handle (numpy/scipy only, no sklearn) with "
        f"_kernels_basic_misc.{ {'EmpiricalCovariance': 'empirical_cov', 'LedoitWolf': 'ledoit_wolf', 'OAS': 'oas(paper=False) and oas(paper=True)', 'ShrunkCovariance': 'shrunk_cov(0.1)'}[est] }"
        + ("" if is_cov else " followed by np.linalg.inv (LU; the pinvh mirror _kernels_basic_misc.precision is reported as an extra key)")
        + "; Monte Carlo of the dataset population models (refs/cov_prec_simple.py:mc_stats, N=1000); "
        "probes/cov_prec_simple_probes.py:{spi, shrinkage, mutation, mutation_others} for the P=19 stacks, "
        "average-referenced input, fitted shrinkage_ and the cache-mutation flags")
    ds = ["bivariate_gaussian", "scaled_offset", "trending", "sparse_precision", "cointegrated", "iid_gaussian",
          "shared_envelope", "delayed_noise", "var2_bivariate", "var2_chain", "logistic_maps_chaotic", "anm",
          "P=19 stackA (iid_gaussian+bivariate_gaussian+sparse_precision+gauss_ar1_pair+var2_chain)",
          "P=19 stackB (delayed_noise+narrowband_f0-0.1+narrowband_f0-0.25+var2_bivariate+bivariate_gaussian+var2_chain)",
          "average-referenced bivariate_gaussian and stackB (rank P-1)"]
    out["check_data"] = ("; ".join(ds) + ". T in {64, 256, 1024, 4096}; paths kernel, pipeline, pipeline-detrend")
    out["agreement_criterion"] = (
        "exact rtol 1e-10 / atol 1e-12 for the covariance against the independent estimator"
        if is_cov else
        "tolerance rtol 1e-10 with atol 1e-12*max|Theta| (norm-wise accuracy of a computed inverse) against "
        "np.linalg.inv of the independent estimator; pseudo-inverse runs (singular, avgref) against numpy SVD pinv / "
        "eigh pseudo-inverse with the same tolerance") + (
        "; statistical: |pyspi - E_MC| <= 2 se_fw, se_fw = Monte Carlo sd x familywise factor "
        "(1.32 for P=4, 1.40 for P=5) so the rule is a two-sided familywise 5% test over the P(P-1)/2 pairs; "
        "qualitative: symmetry (" + ("bitwise" if is_cov else "<= 1e-12 max|A|, REVIEW M2") +
        ") with value agreement, and order independence under the cache mutation; documented-claim runs "
        "(doc-*" + (", eq23" if est == "OAS" else "") + ") are tolerance 1e-10 comparisons that are expected to fail and "
        "record the size of the gap")

    # ---------------- unit-specific closeness / verdict
    T64 = rid(u, "bivariate_gaussian", 64, "pipeline", "doc-corr")
    T1024 = rid(u, "bivariate_gaussian", 1024, "pipeline", "doc-corr")
    sp_fail = rid(u, "sparse_precision", 1024, "kernel", "truth")
    lines = [f"{tot_pass}/{len(tot)} runs pass in checks/out/results/cov_prec_simple.json.",
             f"Independent reference: {ref_pass}/{len(ref_ids)} value runs pass (kernel, pipeline, pipeline-detrend, "
             f"squared, symmetry, singular, average-referenced, P=19 stacks), max abs {f(ref_ma, 3)}, max rel {f(ref_mr, 3)}."]
    if is_cov:
        lines.append(
            f"Pipeline identity: pyspi / Pearson r = {f(g(T64, 'ratio_min'), 7)} (T=64) and {f(g(T1024, 'ratio_min'), 7)} "
            f"(T=1024) on every pair, equal to the expected (1-s)(T-1)/T = {f(g(T64, 'expected_ratio'), 7)} / "
            f"{f(g(T1024, 'expected_ratio'), 7)} (doc-corr runs, which fail against plain r with max rel "
            f"{f(R[T64]['max_rel'], 4)} / {f(R[T1024]['max_rel'], 4)}).")
        if est == "EmpiricalCovariance":
            lines.append("np.cov(bias=True) differs from the reference by max abs 0.0 on every kernel run "
                         "(ref_max_abs_vs_np_cov_bias).")
        sq = rid(u, "bivariate_gaussian", 1024, "kernel", "sq-ref")
        lines.append(f"cov-sq is bitwise np.square of the plain output (bitwise_equal_square_of_plain = "
                     f"{g(sq, 'bitwise_equal_square_of_plain')} on kernel and pipeline).")
        bt = [rid(u, "bivariate_gaussian", T, "pipeline", "truth") for T in (64, 256, 1024, 4096)]
        lines.append(
            "Statistical vs the population model (N=1000 Monte Carlo): "
            f"{truth_pass}/{len(truth_ids)} pass; bivariate_gaussian pipeline T=64/256/1024/4096 max |pyspi - limit| "
            + "/".join(f(g(k, 'max_dev_vs_limit'), 3) for k in bt)
            + (" (limit = the unshrunk correlation, so for this fixed-shrinkage estimator the number includes the 0.1 "
               "shrinkage)" if est == "ShrunkCovariance" else " (about 1/sqrt(T))")
            + f", max_z <= {f(max(R[k].get('max_z') or 0 for k in bt), 3)}.")
        lines.append(
            f"{sp_fail} fails (max_z {f(R[sp_fail]['max_z'], 3)}, max |dev|/sd {f(g(sp_fail, 'max_dev_over_sd'), 3)}, "
            f"Monte Carlo familywise p = {g(sp_fail, 'mc_familywise_p')}): the realised T=1024 sample has entry (2,3) "
            "3.2 sd above its expectation for every estimator alike; the same file passes the exact reference and "
            "T=256/4096 pass, so this is a property of the draw, not of the estimator.")
        if est in ("LedoitWolf", "OAS"):
            sh = runs(u, lambda t: t.endswith("shrink"))
            sh_ma = max(R[k]["max_abs"] for k in sh)
            lines.append(f"Fitted shrinkage_ (probe) vs the kernel: {len(sh)}/{len(sh)} pass, max abs {f(sh_ma, 3)} "
                         f"(P=4, 5, 19; T=64-4096; kernel and pipeline). Null iid_gaussian pipeline: shrinkage = 1.0 "
                         "at T=64/256/1024/4096 and every off-diagonal is exactly 0.0 (null runs, exact).")
        else:
            lines.append("Null iid_gaussian pipeline T=64-4096: 4/4 within the familywise rule (max_z <= 1.93).")
        if est == "OAS":
            e = {(d, T): rid(u, d, T, "kernel", "eq23") for d in ("bivariate_gaussian", "sparse_precision") for T in (64, 1024)}
            sh = lambda d, T, p, tag="shrink": rid(u, d, T, p, tag)
            lines.append(
                "Chen et al. Eq. 23 (2/p kept): sklearn shrinkage larger by "
                f"{f(100 * g(e[('bivariate_gaussian', 64)], 'rho_rel_diff'), 3)}% (P=4, T=64), "
                f"{f(100 * g(e[('bivariate_gaussian', 1024)], 'rho_rel_diff'), 3)}% (P=4, T=1024), "
                f"{f(100 * g(e[('sparse_precision', 64)], 'rho_rel_diff'), 3)}% (P=5, T=64), "
                f"{f(100 * g(sh('iid_gaussian', 1024, 'kernel', 'stackA-shrink'), 'rho_rel_diff'), 2)}% and "
                f"{f(100 * g(sh('iid_gaussian', 1024, 'kernel', 'stackB-shrink'), 'rho_rel_diff'), 2)}% (P=19 stacks, T=1024); "
                "off-diagonal relative change "
                f"{f(g(e[('bivariate_gaussian', 64)], 'offdiag_max_rel_diff'), 3)} (P=4, T=64), "
                f"{f(g(e[('bivariate_gaussian', 1024)], 'offdiag_max_rel_diff'), 3)} (P=4, T=1024), "
                f"{f(g(rid(u, 'iid_gaussian', 64, 'kernel', 'stackA-eq23'), 'offdiag_max_rel_diff'), 3)} (P=19, T=64), "
                f"{f(g(rid(u, 'iid_gaussian', 1024, 'pipeline', 'stackA-eq23'), 'offdiag_max_rel_diff'), 3)} (P=19, T=1024 pipeline). "
                "pyspi equals the no-2/p variant (pyspi_vs_variant_max_abs <= 5.6e-17).")
    else:
        b = rid(u, "bivariate_gaussian", 1024, "pipeline", "doc-pcorr")
        c = rid(u, "cointegrated", 1024, "pipeline", "doc-pcorr")
        sp = rid(u, "sparse_precision", 1024, "pipeline", "doc-pcorr")
        lines.append(
            f"Partial correlation (documented quantity): pyspi has the opposite sign on every pair with |pcorr| > 1e-3 "
            f"(frac_opposite_sign = {g(b, 'frac_opposite_sign')} on bivariate_gaussian, sparse_precision and cointegrated), "
            f"bivariate_gaussian T=1024 pair (2,3) prec = {f(g(b, 'pyspi_23'), 4)} vs partial correlation "
            f"{f(g(b, 'pcorr_23'), 4)}, pair (0,1) {f(g(b, 'pyspi_01'), 4)} vs {f(g(b, 'pcorr_01'), 4)}; max |prec| = "
            f"{f(g(c, 'max_abs_pyspi'), 4)} on cointegrated (partial correlation max {f(g(c, 'max_abs_pcorr'), 4)}); "
            f"-prec_ij/sqrt(Theta_ii Theta_jj) reproduces the partial correlation to "
            f"{f(max(g(b, 'max_abs_renormalised_minus_pcorr'), g(c, 'max_abs_renormalised_minus_pcorr'), g(sp, 'max_abs_renormalised_minus_pcorr')), 2)}.")
        sq = rid(u, "bivariate_gaussian", 1024, "kernel", "sq-ref")
        lines.append(f"prec-sq is bitwise np.square of the plain output (bitwise_equal_square_of_plain = "
                     f"{g(sq, 'bitwise_equal_square_of_plain')}).")
        sg = rid(u, "shared_envelope", 256, "pipeline", "singular")
        sg2 = rid(u, "shared_envelope", 1024, "pipeline", "singular")
        if est == "EmpiricalCovariance":
            av = rid(u, "iid_gaussian", 1024, "pipeline", "stackB-avgref")
            av4 = rid(u, "bivariate_gaussian", 1024, "pipeline", "avgref")
            lines.append(
                f"Singular input (shared_envelope, x2 == x0): pyspi equals numpy.linalg.pinv (max rel "
                f"{f(R[sg]['max_rel'], 3)} at T=256, {f(R[sg2]['max_rel'], 3)} at T=1024) while np.linalg.inv raises "
                f"'Singular matrix'; duplicated pair (0,2) = {f(g(sg, 'pyspi_02'), 4)} (T=256) / {f(g(sg2, 'pyspi_02'), 4)} "
                "(T=1024). Average-referenced input (rank P-1): pyspi equals the pseudo-inverse with the structural "
                f"null eigenvalue removed (P=4 max rel {f(R[av4]['max_rel'], 3)}, P=19 max rel {f(R[av]['max_rel'], 3)}; "
                f"smallest eigenvalue {f(g(av4, 'min_eig_S'), 3)} / {f(g(av, 'min_eig_S'), 3)}, LU inverse max "
                f"{f(g(av4, 'inv_LU_max_abs'), 3)} / {f(g(av, 'inv_LU_max_abs'), 3)}).")
            s1, s4 = rid(u, "sparse_precision", 1024, "pipeline", "scaling"), rid(u, "sparse_precision", 4096, "pipeline", "scaling")
            lines.append(
                f"Pipeline scaling: pyspi pipeline prec = D1 Theta_kernel D1 with D1 = diag(sd, ddof=1) to max rel "
                f"{f(max(R[s1]['max_rel'], R[s4]['max_rel']), 3)}; sparse_precision T=4096 pair (0,1): pipeline "
                f"{f(g(s4, 'pyspi_01'), 4)}, kernel {f(g(s4, 'theta_kernel_01'), 4)}, precision_true -0.4.")
        else:
            lines.append(
                f"Duplicated channel (shared_envelope): the shrunk estimate is full rank and pyspi equals its LU inverse "
                f"(max rel {f(max(R[sg]['max_rel'], R[sg2]['max_rel']), 3)}); pair (0,2) = {f(g(sg, 'pyspi_02'), 4)} (T=256) / "
                f"{f(g(sg2, 'pyspi_02'), 4)} (T=1024).")
        st = [rid(u, "sparse_precision", T, "kernel", "truth") for T in (256, 1024, 4096)]
        lines.append(
            f"Statistical vs the population model (N=1000 Monte Carlo through the same estimator): {truth_pass}/{len(truth_ids)} "
            "pass; sparse_precision kernel T=256/1024/4096 max |pyspi - limit| "
            + "/".join(f(g(k, 'max_dev_vs_limit'), 3) for k in st)
            + (" against precision_true (tridiagonal, -0.4)" if est == "EmpiricalCovariance" else
               " against the unshrunk precision_true (the gap includes the shrinkage)")
            + f", max_z <= {f(max(R[k].get('max_z') or 0 for k in truth_ids), 3)}.")
        if est in ("LedoitWolf", "OAS"):
            lines.append("Null iid_gaussian pipeline: every off-diagonal exactly 0.0 at T=64-4096 (shrinkage clipped to 1).")
        if est == "OAS":
            e64 = rid(u, "bivariate_gaussian", 64, "kernel", "eq23")
            e1k = rid(u, "bivariate_gaussian", 1024, "kernel", "eq23")
            s19 = rid(u, "iid_gaussian", 1024, "pipeline", "stackB-eq23")
            lines.append(
                "Inverse of the Chen et al. Eq. 23 estimate: off-diagonal relative difference median/max "
                f"{f(g(e64, 'offdiag_median_rel_diff'), 3)}/{f(g(e64, 'offdiag_max_rel_diff'), 3)} (P=4, T=64), "
                f"{f(g(e1k, 'offdiag_median_rel_diff'), 3)}/{f(g(e1k, 'offdiag_max_rel_diff'), 3)} (P=4, T=1024), "
                f"{f(g(s19, 'offdiag_median_rel_diff'), 3)}/{f(g(s19, 'offdiag_max_rel_diff'), 3)} (P=19 stackB, T=1024 pipeline; "
                "the max is at a near-zero entry).")
    if not is_cov:
        lines.append("The largest elementwise relative difference of the precision comparisons sits at a near-zero entry "
                     "and is inside atol = 1e-12 max|Theta|; rtol was 1e-10 on every run.")
    if sym_max == 0:
        lines.append(f"Symmetry: max|A - A.T| = 0.0 (bitwise) over {n_sym} matrix runs.")
    else:
        lines.append(f"Symmetry: max|A - A.T| = {f(sym_max, 3)} over {n_sym} matrix runs ({nz_sym} with a nonzero "
                     f"last-bit difference; largest at {sym_rid}).")
    out["closeness"] = " ".join(lines)
    return out, dict(ref_ids=ref_ids, stack_ids=stack_ids, truth_ids=truth_ids, doc_ids=doc_ids, mut_ids=mut_ids,
                     n_sym=n_sym, nz_sym=nz_sym, sym_max=sym_max, sym_rid=sym_rid)



def res(cand, outcome, evidence):
    return {"candidate": cand, "outcome": outcome, "evidence": evidence}


def complete(est, kind):
    u = f"basic.{kind}.{est}"
    is_cov = kind == "cov"
    o, st = block(est, kind)
    mut = rid(u, "bivariate_gaussian", 256, "pipeline", "mutation")
    R_mut = (f"{mut}: cov_returned_is_cache=1, cache_cov_diag_all_nan=1, prec_returned_is_cache=1, "
             "cache_prec_diag_all_nan=1; order_indep_fwd=order_indep_rev=1 (every cov/cov-sq/prec/prec-sq output is "
             "bitwise identical on a fresh or shared Data in either order, so no current output changes); the cached "
             "fit's sklearn score() and mahalanobis() return NaN after a prec call (score_nan_after_prec=1, "
             "mahalanobis_nan_frac_after_prec=1.0), not after a cov call alone (score_nan_after_cov_only=0); "
             "basic.cov.EmpiricalCovariance|bivariate_gaussian|256|pipeline|mutation-others: order independent for "
             "EllipticEnvelope, MinCovDet, GraphicalLasso, GraphicalLassoCV (all flags 1)")
    c_mut = res("multivariate() NaNs the diagonal of the cached sklearn covariance_/precision_ in place and returns "
                "the cached array itself (basic.py:49-50)", "confirmed", R_mut)
    sq1, sq2 = rid(u, "bivariate_gaussian", 1024, "kernel", "sq-ref"), rid(u, "bivariate_gaussian", 1024, "pipeline", "sq-ref")
    c_sq = res("the -sq variants are undocumented and are the elementwise square", "confirmed",
               f"{sq1} and {sq2}: bitwise_equal_square_of_plain=1 and agreement with the squared independent "
               "reference; supplement.txt:153-156 and 167-170 list only the 16 unsquared identifiers; GitBook "
               "basic-statistics.md has -sq entries only for xcorr (lines 71-75)")
    c_kw = res("GitBook keyword line contradicts the supplement and config labels", "confirmed",
               "GitBook basic-statistics.md:17 'undirected, nonlinear, unsigned, bivariate, contemporaneous' vs "
               "supplement.txt:137 'undirected, linear, signed, multivariate, contemporaneous' and the Estimators "
               "labels (pyspi/statistics/basic.py:16-27); documentation reading, no numeric run needed")
    T64, T1k = rid(u, "bivariate_gaussian", 64, "pipeline", "doc-corr"), rid(u, "bivariate_gaussian", 1024, "pipeline", "doc-corr")
    c_doc = None
    if is_cov:
        c_doc = res("'covariance equivalent to correlation' holds only up to (1-s)(T-1)/T", "confirmed",
                    f"{T64} and {T1k}: pyspi/r = {f(g(T64, 'ratio_min'), 7)} and {f(g(T1k, 'ratio_min'), 7)} on every "
                    "pair, equal to (1-s)(T-1)/T; the pipeline ref runs reproduce (1-s)(T-1)/T R exactly")
    clip = None
    if est in ("LedoitWolf", "OAS"):
        nulls = ", ".join(rid(u, "iid_gaussian", T, "pipeline", "null") for T in (64, 256, 1024, 4096))
        clip = res("on independent channels the shrinkage clips to 1 and every off-diagonal is exactly 0.0", "confirmed",
                   f"{nulls}: exact zeros, kernel shrinkage 1.0 at every T; also delayed_noise T=1024 pipeline "
                   "(zero-lag uncorrelated delayed copies): shrinkage 1.0 (sym run s_kernel)")
    twop = None
    if est == "OAS":
        e64 = rid(f"basic.cov.OAS", "bivariate_gaussian", 64, "kernel", "eq23")
        twop = res("sklearn's OAS drops the 2/p terms of Chen et al. Eq. 23; matters at small p", "confirmed",
                   f"{e64} and the other basic.cov.OAS/basic.prec.OAS eq23 runs fail against Eq. 23 while the ref runs "
                   "match the no-2/p variant; shrinkage +14.4% (P=4), +9.6-10.3% (P=5), +0.67-0.71% (P=19 stacks) "
                   "relative to Eq. 23 (basic.cov.OAS *|shrink and *stack*-shrink runs, rho_rel_diff); analytic bound "
                   "rho_sklearn/rho_eq23 - 1 <= 1/(p-1) (33% at p=4, 5.6% at p=19, 1.6% at p=64)")
    if is_cov:
        cands = {"EmpiricalCovariance": [c_mut, c_doc, c_sq, c_kw],
                 "LedoitWolf": [c_mut, c_doc, c_sq, c_kw, clip],
                 "OAS": [c_mut, c_doc, c_sq, c_kw, twop, clip],
                 "ShrunkCovariance": [c_mut, c_doc, c_sq, c_kw]}[est]
    else:
        b = rid(u, "bivariate_gaussian", 1024, "pipeline", "doc-pcorr")
        c = rid(u, "cointegrated", 1024, "pipeline", "doc-pcorr")
        c_pc = res("prec is the unnormalised precision entry, not partial correlation, and is not bounded by [-1, 1]",
                   "confirmed",
                   f"{b}: prec[2,3] = {f(g(b, 'pyspi_23'), 4)} vs partial correlation {f(g(b, 'pcorr_23'), 4)}; "
                   f"frac_opposite_sign = 1.0 on all three doc-pcorr runs; {c}: max |prec| = {f(g(c, 'max_abs_pyspi'), 4)}")
        if est == "EmpiricalCovariance":
            sg = rid(u, "shared_envelope", 256, "pipeline", "singular")
            c_sing = res("singular covariance is pseudo-inverted silently by pinvh", "confirmed",
                         f"{sg} and |1024|: pyspi = numpy.linalg.pinv (max rel 4.3e-15 / 4.1e-14), np.linalg.inv raises, "
                         "pair (0,2) = 0.3379 / 0.3338; average reference (rank P-1): "
                         f"{rid(u, 'bivariate_gaussian', 1024, 'pipeline', 'avgref')} and "
                         f"{rid(u, 'iid_gaussian', 1024, 'pipeline', 'stackB-avgref')} equal the pseudo-inverse with the "
                         "structural null eigenvalue dropped; no warning reaches the caller (pyspi suppresses warnings in "
                         "_from_cache, basic.py:37-39). The P > T sub-claim was not re-run here")
            s4 = rid(u, "sparse_precision", 4096, "pipeline", "scaling")
            c_sc = res("pipeline prec is the kernel precision rescaled by the channel standard deviations", "confirmed",
                       f"{s4} and |1024|: pipeline Theta = D1 Theta_kernel D1 with D1 = diag(sd ddof=1) to 3.0e-14 "
                       "(equivalently T/(T-1) D0 Theta_kernel D0 with ddof=0 sds); pair (0,1) pipeline -0.5393, kernel "
                       "-0.3925, precision_true -0.4. Correction to the trace wording: the T/(T-1) factor applies only "
                       "when D uses ddof=0 standard deviations")
            cands = [c_mut, c_pc, c_sq, c_sing, c_sc]
        else:
            pipe = ", ".join(rid(u, d, 1024, "pipeline", "ref") for d in ("bivariate_gaussian", "sparse_precision"))
            c_sc = res("pipeline prec is the inverse of the shrunk correlation matrix times T/(T-1)", "confirmed",
                       f"{pipe} (and every pipeline ref run): pyspi = inv(estimator(z-scored x, ddof=1)) = "
                       "T/(T-1) inv((1-s)R + s I) to <= 6e-12; the D1 Theta_kernel D1 identity holds exactly only for "
                       "EmpiricalCovariance because the shrinkage is recomputed on the z-scored input (e.g. LedoitWolf "
                       "bivariate_gaussian T=1024 s = 0.014312 kernel vs 0.01415 pipeline)")
            if est == "LedoitWolf":
                cands = [c_mut, c_pc, c_sq, clip, c_sc]
            elif est == "OAS":
                cands = [c_mut, c_pc, c_sq, twop, clip, c_sc]
            else:
                cands = [c_mut, c_pc, c_sq, c_sc]
    o["candidate_resolutions"] = cands

    # verdict / score
    if is_cov and est != "OAS":
        o["verdict"], o["score_0_10"] = "matches", 9
        o["what_changed"] = {
            "EmpiricalCovariance": "Canonical MLE covariance (divisor T), fp-exact. On the default pipeline the value is "
                                   "(T-1)/T times Pearson r (ddof=1 z-score vs divisor-T covariance): a constant "
                                   "convention factor (0.984375 at T=64) where the supplement says 'equivalent to "
                                   "correlation'. The -sq identifier is an undocumented elementwise square.",
            "LedoitWolf": "Ledoit-Wolf 2004 estimate, fp-exact. On the pipeline the value is (1-s)(T-1)/T r with a "
                          "data-dependent shrinkage s (0.184 bivariate_gaussian T=64, 0.014 at T=1024), not the "
                          "correlation the supplement equates it with; s clips to 1 on independent or zero-lag "
                          "uncorrelated channels and then every off-diagonal is exactly 0.0. -sq is an undocumented "
                          "elementwise square.",
            "ShrunkCovariance": "sklearn fixed-coefficient shrinkage 0.9 S + 0.1 tr(S)/p I, fp-exact, as the supplement "
                                "describes. On the pipeline the value is 0.9 (T-1)/T r, so |value| <= 0.9 and it is "
                                "never 'equivalent to correlation'. -sq is an undocumented elementwise square.",
        }[est]
        o["definition_under_review"] = False
    elif is_cov:
        o["verdict"], o["score_0_10"] = "variant", 7
        o["what_changed"] = ("sklearn's OAS shrinkage omits the 2/p terms of Chen et al. 2010 Eq. 23 (the variant "
                             "scikit-learn 0.24.1, the supplement's version, also used): shrinkage +14.4% at p=4, +10% at "
                             "p=5, +0.7% at p=19 relative to Eq. 23; off-diagonals change by up to 2.9% (p=4, T=64) and "
                             "0.06% (p=19, T=1024). Otherwise as LedoitWolf: (1-s)(T-1)/T r on the pipeline, exact zeros "
                             "when s clips to 1, undocumented -sq square.")
        o["definition_under_review"] = False
    elif est != "OAS":
        o["verdict"], o["score_0_10"] = "matches", 7
        o["what_changed"] = (
            ("Canonical precision (inverse of the MLE covariance), fp-exact; " if est == "EmpiricalCovariance" else
             f"Inverse of the {est} estimate, fp-exact; ")
            + "scored at the 7 anchor by analogy because the supplement's description ('equivalent to the partial "
            "correlation ... within [-1, 1]') does not hold: the value is Theta_ij = -pcorr_ij sqrt(Theta_ii Theta_jj), "
            "opposite in sign to the partial correlation on every pair and unbounded (max 95.3 / 61.5 / 4.26 on "
            "cointegrated for Empirical / LedoitWolf / Shrunk). On the pipeline it is the inverse of the (shrunk) "
            "correlation matrix times T/(T-1)."
            + (" Singular covariance (duplicated channel, average reference) gives a silent Moore-Penrose "
               "pseudo-inverse." if est == "EmpiricalCovariance" else "")
            + " -sq is an undocumented elementwise square.")
        o["definition_under_review"] = True
    else:
        o["verdict"], o["score_0_10"] = "variant", 6
        o["what_changed"] = ("Inverse of sklearn's no-2/p OAS estimate (Chen et al. Eq. 23 variant; off-diagonal precision "
                             "differs from the Eq. 23 inverse by median 5.1% / max 12.7% at p=4 T=64 and 0.44% / 1.7% "
                             "at T=1024), and the value is the unnormalised precision entry, opposite in sign to the "
                             "documented partial correlation and unbounded (max 49.1 on cointegrated). Deviates from "
                             "both the supplement and the canonical estimator in interpretable ways (6 anchor). -sq is "
                             "an undocumented elementwise square.")
        o["definition_under_review"] = True
    o["new_finding"] = True
    o["check_cost"] = ("cheap: every pyspi run <= 0.02 s (mutation-others probe with GraphicalLassoCV 0.84 s); the whole "
                       "family's 491 pyspi runs take 2.4 s; the Monte Carlo references take about a minute; T up to "
                       "4096 used throughout")
    if is_cov:
        o["symmetry_observed"] = (f"sym: max|A - A.T| = 0.0 (bitwise) on all {st['n_sym']} matrix runs, including "
                                  "delayed_noise, var2_bivariate, var2_chain, logistic_maps_chaotic, anm and cointegrated "
                                  "(sym runs)")
    else:
        o["symmetry_observed"] = (f"sym up to last-bit roundoff: max|A - A.T| = {f(st['sym_max'], 3)} at "
                                  f"{st['sym_rid']}; nonzero in {st['nz_sym']} of {st['n_sym']} matrix runs; "
                                  "consistent with REVIEW M2 (pinvh)")
    dl = ("; on delayed_noise the shrinkage is 1.0 and the whole matrix is 0.0" if est in ("LedoitWolf", "OAS") else "")
    o["direction_observed"] = (
        "undirected: on delayed_noise, var2_bivariate, var2_chain, logistic_maps_chaotic and anm (pipeline, T=1024) "
        "A[i,j] equals A[j,i]" + (" bitwise" if is_cov else " to the last bit") + " and equals the (i,j) entry of the "
        "independent " + ("estimate" if is_cov else "inverse") + " (sym runs, value_ok=1); it carries no direction "
        "information: A[i,j] is the zero-lag " + ("(shrunk) covariance" if is_cov else "precision entry") +
        " of processes i and j (rows of the Data array)" + dl)

    def ids(pred):
        return runs(u, pred)
    cr = [
        {"run_ids": ids(lambda t: t in ("ref", "sym", "singular", "avgref", "stackA", "stackB", "stackB-avgref")),
         "reference": "refs/cov_prec_simple.py:ref_matrix (+ numpy pinv / eigh pseudo-inverse for singular EmpiricalCovariance precision)",
         "outcome": "pass: {}/{} value runs, max abs {}, max rel {}".format(
             *(lambda a: (a[1], len(a[0]), f(a[2], 3), f(a[3], 3)))(grp_stats(u, lambda t: t in (
                 "ref", "sym", "singular", "avgref", "stackA", "stackB", "stackB-avgref"))))},
        {"run_ids": ids(lambda t: t == "sq-ref"), "reference": "refs/cov_prec_simple.py:handle[sq-ref]",
         "outcome": "pass: bitwise np.square of the plain output"},
        {"run_ids": ids(lambda t: t in ("truth", "null")),
         "reference": "refs/cov_prec_simple.py:mc_stats (Monte Carlo of the population model) / analytic exact zeros",
         "outcome": ("pass except the sparse_precision T=1024 kernel draw (max_z 2.26, MC familywise p 0.014)"
                     if is_cov else "pass: all within the familywise 2-se rule")},
        {"run_ids": ids(lambda t: t.startswith("doc-")),
         "reference": "refs/cov_prec_simple.py:handle[" + ("doc-corr] np.corrcoef" if is_cov else "doc-pcorr] -Theta_ij/sqrt(Theta_ii Theta_jj)"),
         "outcome": "fail as expected: documents the gap to the documented quantity"},
        {"run_ids": ids(lambda t: t.startswith("mutation")), "reference": "probes/cov_prec_simple_probes.py:mutation(_others)",
         "outcome": "pass: outputs order independent; cache mutation and aliasing confirmed by the flags"},
    ]
    if est in ("LedoitWolf", "OAS") and is_cov:
        cr.append({"run_ids": ids(lambda t: t.endswith("shrink")), "reference": "probes/cov_prec_simple_probes.py:shrinkage vs _kernels_basic_misc",
                   "outcome": "pass: fitted shrinkage_ equals the kernel shrinkage (max abs <= 4.4e-16)"})
    if est == "OAS":
        cr.append({"run_ids": ids(lambda t: t.endswith("eq23")), "reference": "_kernels_basic_misc.oas(paper=True) (Chen et al. 2010 Eq. 23)",
                   "outcome": "fail as expected: quantifies the 2/p omission"})
    if kind == "prec" and est == "EmpiricalCovariance":
        cr.append({"run_ids": ids(lambda t: t == "scaling"), "reference": "refs/cov_prec_simple.py:handle[scaling] D1 Theta_kernel D1",
                   "outcome": "pass: max rel 3.0e-14"})
    o["checks_run"] = cr
    return o


ORDER = ["check_method", "check_reference", "check_data", "agreement_criterion", "closeness", "verdict", "score_0_10",
         "what_changed", "new_finding", "definition_under_review", "check_cost", "symmetry_observed",
         "direction_observed", "candidate_resolutions", "checks_run"]


def write(unit, o):
    p = AUDIT / "records" / f"{unit}.yaml"
    text = p.read_text()
    rec = yaml.safe_load(text)
    assert rec["status"] in ("traced", "checked"), rec["status"]
    assert "optimisation" not in rec, "optimisation block present: refusing text append"
    if "check_method" in rec["correctness"]:
        raise SystemExit(f"{unit}: check block already present")
    n_c = len(rec["correctness"]["new_finding_candidates"])
    assert len(o["candidate_resolutions"]) == n_c, (unit, len(o["candidate_resolutions"]), n_c)
    dumped = yaml.safe_dump({k: o[k] for k in ORDER}, sort_keys=False, default_flow_style=False, width=4096,
                            allow_unicode=True)
    block_txt = "".join("  " + ln + "\n" if ln else "\n" for ln in dumped.splitlines())
    lines = text.splitlines(keepends=True)
    assert lines[1].startswith("status: traced")
    lines[1] = "status: checked\n"
    new = "".join(lines)
    if not new.endswith("\n"):
        new += "\n"
    new += block_txt
    check = yaml.safe_load(new)
    assert check["correctness"]["verdict"] == o["verdict"] and check["status"] == "checked"
    p.write_text(new)


if __name__ == "__main__":
    dry = "--write" not in sys.argv
    for est in EST:
        for kind in ("cov", "prec"):
            u = f"basic.{kind}.{est}"
            o = complete(est, kind)
            if dry:
                print(u, o["verdict"], o["score_0_10"], len(o["candidate_resolutions"]), [len(c["run_ids"]) for c in o["checks_run"]])
            else:
                write(u, o)
                print("wrote", u)
