import sys, warnings, io, contextlib
import numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
import make_data as md
from scipy.stats import zscore
import pyspi.lib.phi_native as pn
from pyspi.lib.phi_native import phi_comp, cov_comp
from pyspi.data import Data
from pyspi.statistics.infotheory import IntegratedInformation
np.set_printoptions(precision=14)
def X(name, T): return md.load(name, T)['x']
def z(x): return zscore(x, axis=1, ddof=1)
opts = lambda t, n=0: {'type_of_phi': t, 'type_of_dist': 'Gauss', 'normalization': n}

print("=== shared_envelope (0,2) via class path (Data) and via raw-array path ===")
for T in [256, 1024, 4096]:
    x = X('shared_envelope', T)
    with contextlib.redirect_stdout(io.StringIO()):
        d = Data(x, dim_order='ps')
    for pt in ['star', 'Geo']:
        spi = IntegratedInformation(phitype=pt)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            v_class = spi.bivariate(d, i=0, j=2)
        wc = sorted({f'{type(ww.message).__name__}:{str(ww.message)[:45]}' for ww in w})
        with warnings.catch_warnings(record=True) as w2:
            warnings.simplefilter('always')
            with contextlib.redirect_stdout(io.StringIO()):
                v_raw = spi.bivariate(x[0], x[2])
        wr = sorted({f'{type(ww.message).__name__}:{str(ww.message)[:45]}' for ww in w2})
        print(f'  T{T} {pt}: Data path -> {v_class!r} warnings {wc}')
        print(f'  T{T} {pt}: raw-array path (data, data2) -> {v_raw!r} warnings {wr}')

print("=== Geo / star swap through phi_comp (both rows z-scored) vs raw-array path ===")
x = X('gauss_ar1_pair', 4096); xz = z(x)
for pt in ['star', 'Geo']:
    a = phi_comp(xz[[0,1]], np.array([1,2]), {'tau':1}, opts(pt)); b = phi_comp(xz[[1,0]], np.array([1,2]), {'tau':1}, opts(pt))
    spi = IntegratedInformation(phitype=pt)
    with contextlib.redirect_stdout(io.StringIO()):
        r01 = spi.bivariate(x[0], x[1]); r10 = spi.bivariate(x[1], x[0])
    print(f'  {pt}: z-scored rows [0,1] {a!r} [1,0] {b!r} diff {a-b:.3e} | raw-array path (x0,x1) {r01!r} (x1,x0) {r10!r} diff {r01-r10:.3e}')

print("=== off-diagonal bitwise symmetry var2_chain T1024 ===")
with contextlib.redirect_stdout(io.StringIO()):
    dv = Data(X('var2_chain', 1024), dim_order='ps')
for pt in ['star', 'Geo']:
    A = IntegratedInformation(phitype=pt).multivariate(dv)
    m = ~np.eye(3, dtype=bool)
    print(f'  {pt}: array_equal offdiag {np.array_equal(A[m], A.T[m])}; array_equal(A,A.T) {np.array_equal(A, A.T)}; equal_nan {np.array_equal(A, A.T, equal_nan=True)}')

print("=== delayed_noise T64 (0,1) through phi_comp (real path) ===")
xz = z(X('delayed_noise', 64))[[0,1]]
print('  Geo', repr(phi_comp(xz, np.array([1,2]), {'tau':1}, opts('Geo'))), ' star', repr(phi_comp(xz, np.array([1,2]), {'tau':1}, opts('star'))))
xz = z(X('iid_gaussian', 1024))[[2,3]]
print('  iid T1024 (2,3) star', repr(phi_comp(xz, np.array([1,2]), {'tau':1}, opts('star'))))
xz = z(X('gauss_ar1_pair', 1024))[[0,1]]
print('  gauss_ar1_pair T1024 star', repr(phi_comp(xz, np.array([1,2]), {'tau':1}, opts('star'))), 'Geo', repr(phi_comp(xz, np.array([1,2]), {'tau':1}, opts('Geo'))))

# write Octave inputs (z-scored pairs), 2 x T text
R = '/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/fable_review'
np.savetxt(R + '/oct_iid.txt', z(X('iid_gaussian', 1024))[[2,3]], fmt='%.17g')
np.savetxt(R + '/oct_dn.txt', z(X('delayed_noise', 64))[[0,1]], fmt='%.17g')
np.savetxt(R + '/oct_ar.txt', z(X('gauss_ar1_pair', 1024))[[0,1]], fmt='%.17g')

print("=== which pair gave the largest L-BFGS-B gap (re-run of probe 1 set) ===")
