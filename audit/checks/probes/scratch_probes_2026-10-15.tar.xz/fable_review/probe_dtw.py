"""Fable independent probe for dtw_family claims (from-scratch references, no tslearn in refs)."""
import io, contextlib, warnings, sys
import numpy as np
warnings.filterwarnings("ignore")

def dtw_ref(x, y, mask=None, cost="sq"):
    n, m = len(x), len(y)
    R = np.full((n+1, m+1), np.inf); R[0, 0] = 0.0
    for i in range(n):
        for j in range(m):
            if mask is None or mask[i, j]:
                c = (x[i]-y[j])**2 if cost == "sq" else abs(x[i]-y[j])
                R[i+1, j+1] = c + min(R[i, j], R[i, j+1], R[i+1, j])
    return R[n, m]

def sakoe1978(x, y):  # symmetric form, abs cost, diag weight 2, /(I+J)
    n, m = len(x), len(y)
    g = np.full((n+1, m+1), np.inf); g[0, 0] = 0.0
    for i in range(1, n+1):
        for j in range(1, m+1):
            d = abs(x[i-1]-y[j-1])
            g[i, j] = min(g[i, j-1]+d, g[i-1, j-1]+2*d, g[i-1, j]+d)
    return g[n, m]/(n+m)

def band_mask(T, r=1):
    i = np.arange(T)[:, None]; j = np.arange(T)[None, :]
    return np.abs(i-j) <= r

def lcss_ref(x, y, eps=1.0, mask=None, strict=False):
    n, m = len(x), len(y)
    L = np.zeros((n+1, m+1), dtype=np.int64)
    for i in range(1, n+1):
        for j in range(1, m+1):
            if mask is None or mask[i-1, j-1]:
                d = abs(x[i-1]-y[j-1]); ok = d < eps if strict else d <= eps
                L[i, j] = 1 + L[i-1, j-1] if ok else max(L[i, j-1], L[i-1, j])
    return L[n, m]/min(n, m)

def sdtw_ref(x, y, g=1.0):
    from scipy.special import logsumexp
    n, m = len(x), len(y)
    R = np.full((n+1, m+1), np.inf); R[0, 0] = 0.0
    for i in range(1, n+1):
        for j in range(1, m+1):
            a = np.array([R[i-1, j], R[i-1, j-1], R[i, j-1]])
            R[i, j] = (x[i-1]-y[j-1])**2 - g*logsumexp(-a/g)
    return R[n, m]

import tslearn.metrics as tm
from tslearn.metrics import _masks
rng = np.random.default_rng(777)
T = 50
x = rng.standard_normal(T); y = rng.standard_normal(T)
print("DTW none: tslearn", tm.dtw(x, y), "ref sqrt(sumsq)", np.sqrt(dtw_ref(x, y)), "abs-cost DP", dtw_ref(x, y, cost="abs"), "Sakoe1978 normalised", sakoe1978(x, y), "euclid", np.linalg.norm(x-y))
mS = _masks.compute_mask(T, T, 2); mI = _masks.compute_mask(T, T, 1)
print("SC mask equals |i-j|<=1:", np.array_equal(mS, band_mask(T, 1)), "cells", mS.sum(), "3T-2=", 3*T-2)
print("DTW SC: tslearn", tm.dtw(x, y, global_constraint="sakoe_chiba"), "ref masked", np.sqrt(dtw_ref(x, y, mask=band_mask(T, 1))))
print("DTW itakura: tslearn", tm.dtw(x, y, global_constraint="itakura"), "ref masked (tslearn mask)", np.sqrt(dtw_ref(x, y, mask=mI)), "mask frac", mI.mean())
for TT in (64, 256, 1024, 4096):
    ms = _masks.compute_mask(TT, TT, 2); mi = _masks.compute_mask(TT, TT, 1)
    print(f"T={TT} SC band frac {ms.mean():.5f} ({100*ms.mean():.3f}%), itakura frac {mi.mean():.4f}")
# Itakura degenerate corners for LCSS
print("itakura mask T=128 last row allowed cols:", np.where(_masks.compute_mask(128,128,1)[-1])[0], "first row:", np.where(_masks.compute_mask(128,128,1)[0])[0])

# LCSS: constraint ignored?
T = 60
x = rng.standard_normal(T); y = np.r_[rng.standard_normal(5)*5+20, x[:-5]]
for gc in (None, "itakura", "sakoe_chiba"):
    m = _masks.compute_mask(T, T, _masks.GLOBAL_CONSTRAINT_CODE[gc])
    print(f"LCSS {gc}: tslearn {tm.lcss(x, y, global_constraint=gc):.4f} ref-masked {lcss_ref(x, y, mask=m):.4f} ref-unmasked {lcss_ref(x, y):.4f}")
print("np.isfinite(False) =", np.isfinite(False), "; mask dtype:", _masks.compute_mask(5,5,2).dtype)
# torch backend
import torch
T = 64; x = rng.standard_normal(T); y = rng.standard_normal(T)
for gc in ("itakura", "sakoe_chiba"):
    m = _masks.compute_mask(T, T, _masks.GLOBAL_CONSTRAINT_CODE[gc])
    print(f"LCSS {gc} T=64: torch {float(tm.lcss(torch.tensor(x), torch.tensor(y), global_constraint=gc, be='pytorch')):.4f} numpy {tm.lcss(x, y, global_constraint=gc):.4f} ref-masked {lcss_ref(x, y, mask=m):.4f} ref-unmasked {lcss_ref(x,y):.4f}")
# saturation & tie
for T in (64, 256, 1024):
    xs = rng.standard_normal(T); ys = rng.standard_normal(T)
    xs = (xs-xs.mean())/xs.std(ddof=1); ys = (ys-ys.mean())/ys.std(ddof=1)
    print(f"LCSS T={T}: indep {tm.lcss(xs, ys):.3f} x,-x {tm.lcss(xs, -xs):.3f} x,x {tm.lcss(xs, xs):.3f}")
print("lcss([0,0],[1,1]) =", tm.lcss([0., 0.], [1., 1.]), "strict ref", lcss_ref(np.array([0., 0.]), np.array([1., 1.]), strict=True))
# intended itakura LCSS degeneracy
T = 128; mI = _masks.compute_mask(T, T, 1); vals = []
for k in range(30):
    a = rng.standard_normal(T); b = rng.standard_normal(T); vals.append(lcss_ref(a, b, mask=mI))
vals = np.array(vals); print("intended itakura LCSS T=128: frac zero", (vals == 0).mean(), "nonzero mean", vals[vals > 0].mean() if (vals>0).any() else None)

# softdtw
T = 40; x = rng.standard_normal(T); y = rng.standard_normal(T)
print("softdtw tslearn", tm.soft_dtw(x, y), "ref", sdtw_ref(x, y), "diff", abs(tm.soft_dtw(x, y)-sdtw_ref(x, y)))
try:
    tm.soft_dtw(x, y, global_constraint="itakura")
except TypeError as e:
    print("soft_dtw(global_constraint=) ->", type(e).__name__)
for T in (64, 1024):
    xs = rng.standard_normal(T); xs = (xs-xs.mean())/xs.std(ddof=1); ys = rng.standard_normal(T); ys = (ys-ys.mean())/ys.std(ddof=1)
    print(f"softdtw T={T}: (x,x) {tm.soft_dtw(xs, xs):.2f} indep {tm.soft_dtw(xs, ys):.2f} (x,-x) {tm.soft_dtw(xs, -xs):.2f}; dtw indep {tm.dtw(xs,ys):.2f} (x,-x) {tm.dtw(xs,-xs):.2f} euclid {np.linalg.norm(xs-ys):.2f}/{np.linalg.norm(xs+xs):.2f}")

# pyspi end-to-end
from pyspi.data import Data
from pyspi.statistics.distance import DynamicTimeWarping, LongestCommonSubsequence, SoftDynamicTimeWarping
Z = rng.standard_normal((4, 128)); Z[1] = np.roll(Z[0], 3) + 0.3*rng.standard_normal(128)
with contextlib.redirect_stdout(io.StringIO()):
    d = Data(Z.copy(), dim_order="ps")
z = d.to_numpy(squeeze=True)
for cls in (DynamicTimeWarping, LongestCommonSubsequence, SoftDynamicTimeWarping):
    mats = {gc: cls(global_constraint=gc).multivariate(d) for gc in (None, "itakura", "sakoe_chiba")}
    ids = [cls(global_constraint=gc).identifier for gc in (None, "itakura", "sakoe_chiba")]
    print(cls.__name__, cls(global_constraint='sakoe_chiba').name, ids, "itakura==None", np.array_equal(mats[None], mats["itakura"], equal_nan=True), "SC==None", np.array_equal(mats[None], mats["sakoe_chiba"], equal_nan=True), "sym", np.array_equal(mats[None], mats[None].T, equal_nan=True), "diagNaN", np.isnan(np.diag(mats[None])).all())
A = DynamicTimeWarping().multivariate(d)
print("A[1,0]==dtw(z0,z1)?", A[1, 0] == tm.dtw(z[0], z[1]), "A[1,0]==dtw(z1,z0)?", A[1, 0] == tm.dtw(z[1], z[0]), "A[0,1]", A[0,1], "ref", np.sqrt(dtw_ref(z[0], z[1])))
# parse_bivariate asymmetry
a = 5+3*rng.standard_normal(64); b = 5+3*rng.standard_normal(64)
with contextlib.redirect_stdout(io.StringIO()):
    dd = Data(); dd.add_process(a); dd.add_process(b)
zz = dd.to_numpy(squeeze=True); print("raw-array path means", zz.mean(1).round(3), "stds", zz.std(1, ddof=1).round(3))
with contextlib.redirect_stdout(io.StringIO()):
    v_direct = DynamicTimeWarping().bivariate(a, b)
    v_data = DynamicTimeWarping().multivariate(Data(np.vstack([a, b]), dim_order='ps'))[0, 1]
print("spi.bivariate(x,y) raw:", v_direct, "vs Data path:", v_data)
# cost-matrix precision
from tslearn.metrics.softdtw_variants import SquaredEuclidean
x = 1e4 + rng.standard_normal(200); y = x + 1e-6*rng.standard_normal(200)
D = SquaredEuclidean(x, y).compute(); Dd = (x[:, None]-y[None, :])**2
print("offset 1e4: max abs D err", np.abs(D-Dd).max())
x = rng.standard_normal(200); y = x + 1e-3*rng.standard_normal(200)
D = SquaredEuclidean(x, y).compute(); Dd = (x[:, None]-y[None, :])**2
print("z-scored: max abs D err", np.abs(D-Dd).max(), "max rel diag err", np.max(np.abs(np.diag(D)-np.diag(Dd))/np.diag(Dd)))
# save data for dtaidistance cross-venv check
rng5 = np.random.default_rng(5); x5 = rng5.standard_normal(80); y5 = rng5.standard_normal(80)
np.savez(sys.argv[1] + "/dtai_in.npz", x=x5, y=y5, tsl=tm.dtw(x5, y5), tsl_sc=tm.dtw(x5, y5, global_constraint="sakoe_chiba"))
print("T=80 seed5 tslearn dtw", tm.dtw(x5, y5), "SC", tm.dtw(x5, y5, global_constraint="sakoe_chiba"))
