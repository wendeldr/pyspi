import numpy as np, io, contextlib, warnings
warnings.simplefilter('ignore')
from scipy import stats
from pyspi.data import Data
from pyspi.statistics.basic import CrossCorrelation, SpearmanR
B='/media/dan/Data/git/pyspi/audit/checks/data/'
def mk(X, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(X, **kw)
# F1 spearman tied reciprocity magnitude, and mechanism (sd of mid-ranks differ)
rng=np.random.default_rng(5); mx=0; nm=0; ex=None
for t in range(2000):
    n=rng.integers(20,400); x=np.round(rng.standard_normal(n)*3); y=np.round(x*0.5+rng.standard_normal(n)*2)
    a=stats.spearmanr(x,y).correlation; b=stats.spearmanr(y,x).correlation
    if a!=b: nm+=1; mx=max(mx,abs(a-b)); ex=(x,y) if ex is None else ex
print("F1 spearman tied mismatches", nm, "max", mx, "ulp-scale", mx/np.finfo(float).eps)
x,y=ex; rx=stats.rankdata(x); ry=stats.rankdata(y); print("F1 mid-rank sd differ:", rx.std(), ry.std(), "continuous ranks are permutations so sd equal")
# pipeline hides it
S=SpearmanR(); d=mk(np.vstack([x,y])); A=S.multivariate(d); print("F1 pipeline A[0,1]==A[1,0]:", A[0,1]==A[1,0], " fresh bivariate(0,1)==bivariate(1,0):", S.bivariate(d,i=0,j=1)==S.bivariate(d,i=1,j=0))
# F2 mean_sig-False on long-memory data
for name in ('cointegrated','trending','var2_bivariate'):
    for T in (256,1024):
        X=np.load(B+f'{name}_T{T}.npz')['x']
        A=CrossCorrelation(statistic='mean',sigonly=False).multivariate(mk(X.copy()))
        print(f"F2 {name} T={T} mean_sig-False off-diag max|A| = {np.nanmax(np.abs(A)):.4f}  A[0,1]={A[0,1]:.4f}")
# random walk pair explicitly
rng=np.random.default_rng(7); T=1024; w=np.cumsum(rng.standard_normal(T)); X=np.vstack([w+rng.standard_normal(T)*0.1, w+rng.standard_normal(T)*0.1])
A=CrossCorrelation(statistic='mean',sigonly=False).multivariate(mk(X.copy())); print(f"F2 random-walk pair T=1024 mean_sig-False A[0,1] = {A[0,1]:.4f}")
# F3 float32 through Data
X=rng.standard_normal((2,100)).astype(np.float32)
print("F3 float32 in -> Data dtype", mk(X, detrend=True).to_numpy().dtype, mk(X).to_numpy().dtype)
