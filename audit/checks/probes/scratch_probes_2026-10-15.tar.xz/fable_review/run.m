addpath('mtb');
o.type_of_dist='Gauss'; p.tau=1;
for nm={'oct_dn','oct_iid','oct_ar'}
  X=load([nm{1} '.txt']);
  o.type_of_phi='star'; o.normalization=0; s=phi_comp(X,[1 2],p,o);
  o.type_of_phi='Geo'; g=phi_comp(X,[1 2],p,o);
  printf('%s star=%.13g Geo=%.13g\n',nm{1},s,g);
end
probs=Cov_comp(load('oct_iid.txt'),1,1);
[ps,I,b]=phi_star_Gauss(probs.Cov_X,probs.Cov_XY,probs.Cov_Y,[1 2]); printf('iid beta_opt=%.10g phi=%.13g I=%.13g\n',b,ps,I);
printf('octave %s\n',version());
