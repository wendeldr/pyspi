import sys, io, contextlib, warnings, collections, importlib, yaml
warnings.simplefilter('ignore')
import numpy as np
from scipy.stats import zscore
from scipy.signal import detrend
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; print("JVM", harness.ensure_jvm())
from pyspi.data import Data
from pyspi.base import Directed, Undirected, parse_bivariate
B = '/media/dan/Data/git/pyspi/audit/checks/data/'
def mk(X, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(X, **kw)

# --- P1: detrend = OLS; order ratio ---
rng = np.random.default_rng(0); T = 200; t = np.arange(T)
X = rng.standard_normal((3, T)) * np.array([[1.], [3.], [0.5]]) + np.array([[2.], [-1.], [7.]]) + np.array([[0.01], [0.05], [-0.03]]) * t
A = mk(X, normalise=False, detrend=True).to_numpy(squeeze=True)
tc = t - t.mean(); bhat = ((X - X.mean(1, keepdims=True)) * tc).sum(1) / (tc**2).sum()
ref = X - X.mean(1, keepdims=True) - bhat[:, None] * tc
print("P1 closed-form OLS residual maxabs", np.abs(A - ref).max())
cur = mk(X, normalise=True, detrend=True).to_numpy(squeeze=True); hist = detrend(zscore(X, axis=1, ddof=1), axis=1)
ratio = cur / hist
print("P1 ratio per row min/max", ratio.min(1), ratio.max(1), "pred std(x)/std(resid)", X.std(1, ddof=1) / ref.std(1, ddof=1))

# --- P2: flat channel with detrend=True ---
rng = np.random.default_rng(1)
def run(row):
    Xf = np.vstack([rng.standard_normal(len(row)), row])
    try:
        Af = mk(Xf, normalise=True, detrend=True).to_numpy(squeeze=True)
        r = Af[1]; return f"OK std={r.std(ddof=1):.3f} uniq={len(np.unique(r))} rawresid_std={detrend(row).std():.1e} mean={detrend(row).mean():.1e} eps*|mean|={np.finfo(float).eps*abs(detrend(row).mean()):.1e}"
    except ValueError:
        return "ValueError(NaN)"
for T in (64, 1024, 4096):
    tt = np.arange(T)
    for lab, row in (("const 0.0", np.zeros(T)), ("const 3.0", np.full(T, 3.0)), ("linear .37t+1.1", 0.37*tt+1.1)):
        print(f"P2 T={T:5d} {lab:16s} -> {run(row)}")
# constant without detrend
try:
    mk(np.vstack([rng.standard_normal(50), np.full(50, 3.0)]))
except ValueError as e:
    print("P2 const no-detrend ->", str(e)[:75])

# --- P3: inf swallowed ---
Xi = rng.standard_normal((2, 50)) + np.arange(50) * 0.2; Xi[1, 3] = np.inf
buf = io.StringIO()
with contextlib.redirect_stdout(buf):
    d = Data(Xi, normalise=False, detrend=True)
print("P3 inf normalise=False detrend=True accepted; slope row0", np.polyfit(np.arange(50), d.to_numpy(squeeze=True)[0], 1)[0].round(3), "inf present", np.isinf(d.to_numpy()).any(), [l for l in buf.getvalue().splitlines() if 'detrend' in l.lower()])
try:
    mk(Xi, normalise=True, detrend=True); print("P3 inf default path accepted?!")
except ValueError as e:
    print("P3 inf default path -> ValueError", str(e)[:60])

# --- P4: cov ratio (T-1)/T ---
from pyspi.statistics.basic import Covariance
for T in (64, 1024):
    g = np.load(B + f'bivariate_gaussian_T{T}.npz')['x']
    M = Covariance(estimator='EmpiricalCovariance').multivariate(mk(g)); r = np.corrcoef(g)
    print(f"P4 T={T} cov/pearson = {M[0,1]/r[0,1]!r} (T-1)/T = {(T-1)/T!r}")

# --- P5: two-array API ---
from pyspi.statistics.basic import CrossCorrelation, SpearmanR
from pyspi.statistics.distance import DynamicTimeWarping
rng = np.random.default_rng(3); T = 256
x = rng.standard_normal(T); y = 0.6*x + 0.8*rng.standard_normal(T); xs, ys = 4.0*x + 10.0, 3.0*y - 5.0
for spi in (DynamicTimeWarping(), SpearmanR(), CrossCorrelation(statistic='max', sigonly=False)):
    with contextlib.redirect_stdout(io.StringIO()):
        a = spi.bivariate(mk(np.vstack([xs, ys])), i=0, j=1); b = spi.bivariate(xs, ys); c = spi.bivariate(zscore(x, ddof=1), zscore(y, ddof=1))
    print(f"P5 {spi.identifier:24s} Data(raw)={a:.6f} bivariate(xs,ys)={b:.6f} bivariate(z,z)={c:.6f}")
with contextlib.redirect_stdout(io.StringIO()):
    Ml = Covariance(estimator='EmpiricalCovariance').multivariate([xs, ys]); Md = Covariance(estimator='EmpiricalCovariance').multivariate(mk(np.vstack([xs, ys])))
print("P5 cov list raw [0,1] =", Ml[0, 1], "Data raw [0,1] =", Md[0, 1])
# 3 procs no i/j
d3 = mk(rng.standard_normal((3, 64)))
class Probe(Directed):
    identifier = 'probe'
    @parse_bivariate
    def bivariate(self, data, i=None, j=None): return (i, j)
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter('always'); print("P5 3 procs no i/j ->", Probe().bivariate(d3), "warnings", len(w))
# does any SPI silently return a number with i=j=None? test a few cheap ones
from pyspi.statistics.basic import KendallTau
for spi in (SpearmanR(), KendallTau(), CrossCorrelation(statistic='max', sigonly=False), DynamicTimeWarping()):
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            r = spi.bivariate(d3)
        print("P5", spi.identifier, "i=j=None -> RETURNED", r)
    except Exception as e:
        print("P5", spi.identifier, "i=j=None ->", type(e).__name__)

# --- P6: pair handling ---
calls = []
class AsymUnd(Undirected):
    identifier = 'asym_und'
    @parse_bivariate
    def bivariate(self, data, i=None, j=None): calls.append((i, j)); return 10*i + j
d4 = mk(rng.standard_normal((4, 32)))
A = AsymUnd().multivariate(d4); print("P6 Undirected calls", len(calls), "order", calls[:6], "\n", A)
# Barycenter
from pyspi.statistics.distance import Barycenter
print("P6 Barycenter MRO:", [k.__name__ for k in Barycenter.__mro__[:3]], "labels", Barycenter.labels)
bc = Barycenter(mode='euclidean', statistic='mean')
Mb = bc.multivariate(mk(rng.standard_normal((3, 32))))
print("P6 bary_euclidean_mean symmetric:", np.allclose(np.nan_to_num(Mb), np.nan_to_num(Mb.T)), "cache keys", sorted(mk(rng.standard_normal((3,32))).__dict__.keys())[:0])
# gc_gaussian direction on delayed_noise
from pyspi.statistics.infotheory import TransferEntropy
Xd = np.load(B + 'delayed_noise_T256.npz')['x']
with contextlib.redirect_stdout(io.StringIO()):
    te = TransferEntropy(estimator='gaussian', k_history=1, l_history=1); M = te.multivariate(mk(Xd[:2]))
print("P6", te.identifier, "delayed_noise[0:2] A[0,1]=%.3f A[1,0]=%.3f (x0 leads x1 by 1)" % (M[0, 1], M[1, 0]))

# --- P7: class counts over config.yaml ---
cfg = yaml.safe_load(open('/media/dan/Data/git/pyspi/pyspi/config.yaml'))
tot = collections.Counter(); n = 0; bary_lbl = None
for mod, fcns in cfg.items():
    m = importlib.import_module(mod, 'pyspi')
    for fcn, spec in fcns.items():
        cls = getattr(m, fcn)
        for params in (spec.get('configs') or [None]):
            with contextlib.redirect_stdout(io.StringIO()):
                spi = cls(**params) if params else cls()
            n += 1
            und = isinstance(spi, Undirected)
            owner = next(k.__name__ for k in type(spi).__mro__ if 'multivariate' in k.__dict__)
            key = 'Undirected-mirror' if (und and owner == 'Undirected') else 'Undirected-bypass' if und else 'Directed-loop' if owner == 'Directed' else 'Directed-own-multivariate'
            tot[key] += 1
            if fcn == 'Barycenter': bary_lbl = ('undirected' in spi.labels, und, owner)
print("P7 total", n, dict(tot), "Barycenter (label undirected?, isUndirected?, owner):", bary_lbl)
