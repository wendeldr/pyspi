import numpy as np, warnings, io, contextlib, json
from scipy import signal
from pyspi.data import Data
from pyspi.statistics.basic import CrossCorrelation
np.set_printoptions(precision=4, suppress=True, linewidth=150)
B = '/media/dan/Data/git/pyspi/audit/checks/data/'
def mk(X, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(X, dim_order='ps', **kw)

# --- X1: direction convention of scipy.correlate ---
x = np.array([0, 0, 1, 0, 0.]); y = np.array([0, 1, 0, 0, 0.])   # x(t) = y(t-1): y leads
z = signal.correlate(x, y, 'full'); lags = signal.correlation_lags(5, 5, 'full')
print("X1 correlate(x,y), x = y delayed by 1 -> peak lag", lags[np.argmax(z)])
# (T,1) dispatch
for T in (64, 256, 1024, 4096):
    a = np.random.default_rng(0).standard_normal((T, 1))
    print("X1 choose_conv_method (T,1) T=%d ->" % T, signal.choose_conv_method(a, a, 'full'))

# --- X2: lag window, centre, threshold ---
for T in (64, 65, 256):
    lg = signal.correlation_lags(T, T, 'full')[T - T//4: T + T//4]
    N = len(lg)//2
    print(f"X2 T={T} lags {lg[0]}..{lg[-1]} len {len(lg)} N={N} lag at N = {lg[N]} lag0 pos {int(np.where(lg==0)[0][0])} thr code {1.96/np.sqrt(N):.4f} doc {1.96/np.sqrt(T):.4f}")

# --- X3: T/(T-1) scaling ---
rng = np.random.default_rng(0); T = 64
X = rng.standard_normal((2, T)); X[1] += 0.6 * X[0]
d = mk(X.copy()); xz, yz = d.to_numpy()[[0, 1]]
r_full = np.squeeze(signal.correlate(xz, yz, 'full')) / xz.std() / yz.std() / (T - 1)
pear = np.corrcoef(X)[0, 1]
print("X3 lag0/pearson", r_full[T-1] / pear, "T/(T-1)", T / (T - 1))
def bd(x, y, h):
    x = x - x.mean(); y = y - y.mean(); n = len(x)
    g = np.sum(x[h:] * y[:n-h]) / n if h >= 0 else np.sum(x[:n+h] * y[-h:]) / n
    return g / np.sqrt(np.mean(x**2) * np.mean(y**2))
L = signal.correlation_lags(T, T, 'full')
ratios = [r_full[k] / bd(X[0], X[1], L[k]) for k in range(len(L)) if abs(L[k]) < T//4]
print("X3 pyspi/BD ratio over |lag|<T/4: min %.12f max %.12f" % (min(ratios), max(ratios)))
d2 = mk(np.vstack([X[0], X[0]]))
print("X3 identical series max_sig-False =", repr(CrossCorrelation(statistic='max', sigonly=False).bivariate(d2, i=0, j=1)))
# with detrend=True then zscore -> still T/(T-1)?
d3 = mk(X.copy() + np.arange(T) * 0.05, detrend=True)
xz, yz = d3.to_numpy()[[0, 1]]
print("X3 detrend+zscore: std ddof0 =", xz.std(), "expected sqrt((T-1)/T) =", np.sqrt((T-1)/T))

# --- X4: window rule helper, null pair ---
def window(X, i, j, **kw):
    T = X.shape[1]; d = mk(X.copy(), **kw); x, y = d.to_numpy()[[i, j]]
    r = np.squeeze(signal.correlate(x, y, 'full')) / x.std() / y.std() / (T - 1)
    lg = signal.correlation_lags(T, T, 'full')
    r = r[T - T//4: T + T//4]; lg = lg[T - T//4: T + T//4]
    N = len(r)//2; thr = 1.96 / np.sqrt(N)
    fzf = np.where(np.abs(r[N:]) <= thr)[0][0]; fzr = np.where(np.abs(r[:N]) <= thr)[0][-1]
    w = lg[N - fzr: N + fzf]; sig = np.abs(r) > thr
    return r, lg, thr, fzr, fzf, w, sig
rng = np.random.default_rng(1); T = 256; Xn = rng.standard_normal((2, T))
r, lg, thr, fzr, fzf, w, sig = window(Xn, 0, 1)
print(f"X4 null T=256: fzr {fzr} (lag {lg[fzr]}) fzf {fzf} window {w[0]}..{w[-1]} n {len(w)} sig-in-window {int(sig[np.isin(lg, w)].sum())} ; documented contiguous rule would keep: {'empty' if not sig[lg==0][0] else 'nonempty'}")
# crafted: sig only |lag|<=2 (T=64)
T = 64; Lh = T//4; lags = np.arange(-(Lh-1), Lh+1); rc = np.where(np.abs(lags) <= 2, 0.9, 0.0)
dc = mk(rng.standard_normal((2, T))); dc.xcorr = {(0, 1): rc, (1, 0): rc}
N = Lh; fzf = np.where(np.abs(rc[N:]) <= 1.96/np.sqrt(N))[0][0]; fzr = np.where(np.abs(rc[:N]) <= 1.96/np.sqrt(N))[0][-1]
print("X4 crafted |lag|<=2: window lags", lags[N-fzr], "..", lags[N+fzf-1], "mean", CrossCorrelation(statistic='mean').bivariate(dc, i=0, j=1), "max", CrossCorrelation(statistic='max').bivariate(dc, i=0, j=1))
# crafted empty window
re = np.full(2*Lh, 0.9); re[0] = 0.0; re[Lh] = 0.0
dc.xcorr = {(0, 1): re, (1, 0): re}
with warnings.catch_warnings(record=True) as wn:
    warnings.simplefilter('always')
    print("X4 empty-window mean ->", CrossCorrelation(statistic='mean').bivariate(dc, i=0, j=1), [str(q.message)[:30] for q in wn])
try: print("X4 empty-window max ->", CrossCorrelation(statistic='max').bivariate(dc, i=0, j=1))
except Exception as e: print("X4 empty-window max ->", type(e).__name__)

# --- X5: channel-order dependence on delayed_noise T=256 ---
dn = np.load(B + 'delayed_noise_T256.npz'); print("X5 delays", dn['delay']); dn = dn['x']
perm = [3, 2, 1, 0]; inv = np.argsort(perm)
for cfg in [dict(statistic='max'), dict(statistic='max', squared=True), dict(statistic='mean')]:
    s = CrossCorrelation(**cfg)
    A = s.multivariate(mk(dn.copy())); Bk = s.multivariate(mk(dn[perm].copy()))[np.ix_(inv, inv)]
    print(f"X5 {s.identifier}: A[0,3]={A[0,3]:.4f} reversed-order A[0,3]={Bk[0,3]:.4f} max|diff|={np.nanmax(np.abs(A-Bk)):.4f}")
for (i, j) in [(0, 1), (1, 0), (0, 3), (3, 0)]:
    r, lg, thr, fzr, fzf, w, sig = window(dn, i, j)
    print(f"X5 pair ({i},{j}) peak lag {lg[np.argmax(r)]} peak {r.max():.3f} fzf {fzf} fzr {fzr} window {w[0] if len(w) else None}..{w[-1] if len(w) else None}")
# cache content orientation
d = mk(dn[:2].copy()); CrossCorrelation(statistic='max').multivariate(d)
x1, x0 = d.to_numpy()[[1, 0]]; T = 256
r10 = np.squeeze(signal.correlate(x1, x0, 'full')) / x1.std() / x0.std() / (T-1)
print("X5 cache(0,1) == correlate(x1,x0) slice:", np.allclose(d.xcorr[(0, 1)], r10[T-T//4:T+T//4]), "; == correlate(x0,x1) slice:", np.allclose(d.xcorr[(0, 1)], np.squeeze(signal.correlate(x0, x1, 'full'))[T-T//4:T+T//4] / x1.std() / x0.std() / (T-1)))
# iid order dependence
for T in (256, 1024):
    X = np.load(B + f'iid_gaussian_T{T}.npz')['x']; perm = list(range(len(X)))[::-1]
    for cfg in [dict(statistic='max'), dict(statistic='mean'), dict(statistic='max', sigonly=False), dict(statistic='mean', sigonly=False)]:
        s = CrossCorrelation(**cfg); A = s.multivariate(mk(X.copy())); Bm = s.multivariate(mk(X[perm].copy()))[np.ix_(perm, perm)]
        print(f"X5 iid T={T} {s.identifier} max|A-A(rev)| = {np.nanmax(np.abs(A-Bm)):.3e}")

# --- X6: IndexError sweep (spot) ---
def sweep(name, T, det):
    X = np.load(B + f'{name}_T{T}.npz')['x']
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            A = CrossCorrelation(statistic='max').multivariate(mk(X.copy(), detrend=det))
        return 'ok'
    except Exception as e:
        return type(e).__name__
for name, Ts in [('narrowband_f0-0.25', (64, 256, 1024, 4096)), ('logistic_maps', (64, 256, 1024, 4096)), ('cointegrated', (64, 256, 1024, 4096)), ('trending', (64, 256, 1024)), ('shared_envelope', (256, 1024, 4096)), ('narrowband_f0-0.1', (1024, 4096)), ('bivariate_gaussian', (64, 4096)), ('gauss_ar1_pair', (256, 4096))]:
    print("X6", name, {T: (sweep(name, T, False), sweep(name, T, True)) for T in Ts}, "(d0, d1)")

# --- X7: zero-sum identity & mean_sig-False ---
X = np.load(B + 'bivariate_gaussian_T1024.npz')['x']; T = 1024
d = mk(X.copy()); x3, x2 = d.to_numpy()[[3, 2]]
rf = np.squeeze(signal.correlate(x3, x2, 'full')) / x3.std() / x2.std() / (T-1)
win = rf[T-T//4:T+T//4]; tail = rf.sum() - win.sum()
print(f"X7 sum all lags {rf.sum():.2e} mean window {win.mean():.6f} -tail/(2L) {-tail/(2*(T//4)):.6f} lag0 r {rf[T-1]:.4f} lag0/(2L) {rf[T-1]/(2*(T//4)):.6f}")
print("X7 mean_sig-False pipeline (2,3):", CrossCorrelation(statistic='mean', sigonly=False).multivariate(d)[2, 3])
# counter-example to 'close to 0 no matter what': autocorrelated gauss_ar1_pair / narrowband
for name in ('gauss_ar1_pair', 'narrowband_f0-0.1', 'shared_envelope'):
    X = np.load(B + f'{name}_T1024.npz')['x']
    A = CrossCorrelation(statistic='mean', sigonly=False).multivariate(mk(X.copy()))
    print(f"X7 {name} T=1024 mean_sig-False off-diag max |A| = {np.nanmax(np.abs(A)):.4f}")

# --- X8: normalise=False non-centred ---
X = np.load(B + 'scaled_offset_T1024.npz')['x']
for cfg in [dict(statistic='max', sigonly=False), dict(statistic='mean', sigonly=False)]:
    s = CrossCorrelation(**cfg)
    a = s.multivariate(mk(X.copy(), normalise=False)); b = s.multivariate(mk(X.copy()))
    print(f"X8 {s.identifier} raw (2,3)={a[2,3]:.3f} z (2,3)={b[2,3]:.3f} | raw (1,3)={a[1,3]:.3f} z (1,3)={b[1,3]:.3f}")

# --- X9: shared_envelope lag-0 == T/(T-1) ---
for T in (64, 256):
    X = np.load(B + f'shared_envelope_T{T}.npz')['x']
    A = CrossCorrelation(statistic='max', sigonly=False).multivariate(mk(X.copy()))
    print(f"X9 shared_envelope T={T} max_sig-False A[0,2] = {A[0,2]!r} T/(T-1) = {T/(T-1)!r}")
