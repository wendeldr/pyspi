import numpy as np, warnings, io, contextlib, sys
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi.statistics.distance import PairwiseDistance
from pyspi.data import Data
from scipy.spatial import distance as sd

def mk(x, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, **kw)

M = ["euclidean", "cityblock", "cosine", "chebyshev", "canberra", "braycurtis"]
DD = '/media/dan/Data/git/pyspi/audit/checks/data/'

print("== identity probes, same seed as Opus (seed 0, T=256) ==")
rng = np.random.default_rng(0)
T = 256
x = rng.standard_normal(T); y = 0.6 * x + 0.8 * rng.standard_normal(T); z = rng.standard_normal(T)
raw = np.vstack([x, y, z])
d = mk(raw.copy()); Z = d.to_numpy(squeeze=True)
R = np.corrcoef(Z)
iu = np.triu_indices(3, 1)
E = PairwiseDistance(metric="euclidean").multivariate(d)
C = PairwiseDistance(metric="cosine").multivariate(d)
print("sum z^2 per row:", (Z ** 2).sum(1), "expected T-1 =", T - 1)
print("eucl vs sqrt(2(T-1)(1-r)) max dev:", np.abs(E - np.sqrt(np.clip(2 * (T - 1) * (1 - R), 0, None)))[iu].max())
print("cosine vs 1-r max dev:", np.abs(C - (1 - R))[iu].max())
v = Z[0]
A = {m: PairwiseDistance(metric=m).multivariate(mk(np.vstack([v, -v, v]), normalise=False)) for m in M}
print("y=-x: eucl", A["euclidean"][0, 1], "2sqrt(T-1)=", 2 * np.sqrt(T - 1), "| cosine", A["cosine"][0, 1], "| canberra", A["canberra"][0, 1], "| braycurtis", A["braycurtis"][0, 1], "| chebyshev", A["chebyshev"][0, 1], "2max|x|=", 2 * np.abs(v).max())
print("x,x (copy, non-diagonal): eucl", A["euclidean"][0, 2], "cosine", A["cosine"][0, 2], "cityblock", A["cityblock"][0, 2])
print("ispositive/issigned:", PairwiseDistance().issigned())

print("\n== canberra 0/0 ==")
a = np.array([[0., 1., 2.], [0., 1., 3.]])
print(PairwiseDistance(metric="canberra").multivariate(mk(a, normalise=False))[0, 1], sd.canberra(a[0], a[1]))

print("\n== cosine normalise=False affine ==")
A1 = PairwiseDistance(metric="cosine").multivariate(mk(raw.copy(), normalise=False))[0, 1]
A2 = PairwiseDistance(metric="cosine").multivariate(mk(np.vstack([3 * raw[0] + 5, raw[1], raw[2]]), normalise=False))[0, 1]
print("cosine unnormalised:", A1, "->", A2)

print("\n== 64x1024 symmetry / scipy agreement (seed 1 like Opus) ==")
rng = np.random.default_rng(1)
Mn, Tn = 64, 1024
L = rng.standard_normal((Mn, Mn)) * 0.3
raw2 = L @ rng.standard_normal((Mn, Tn)) + rng.standard_normal((Mn, Tn))
d2 = mk(raw2); Z2 = d2.to_numpy(squeeze=True)
off = ~np.eye(Mn, dtype=bool)
for m in M:
    A = PairwiseDistance(metric=m).multivariate(d2)
    ref = sd.squareform(sd.pdist(Z2, m))
    # independent numpy loop reference
    print(f"{m:10s} max|A-A.T|={np.abs(A - A.T).max():.3e}  max|A-scipy pdist|={np.abs(A - ref)[off].max():.3e}")

print("\n== shared_envelope x0 vs x2 (exact copy) ==")
for T in [64, 256, 1024, 4096]:
    x = np.load(DD + f'shared_envelope_T{T}.npz')['x']
    d = mk(x.copy()); Z = d.to_numpy(squeeze=True)
    E = PairwiseDistance(metric="euclidean").multivariate(d)
    print(T, "raw identical", np.array_equal(x[0], x[2]), "z identical", np.array_equal(Z[0], Z[2]), "eucl[0,2]", E[0, 2], "eucl[2,0]", E[2, 0], "direct", np.sqrt(((Z[0] - Z[2]) ** 2).sum()))

print("\n== near-identical rel error T=4096 ==")
rng = np.random.default_rng(1)
# replicate Opus sequence: after 64x1024 draw, x = rng.standard_normal(4096)
L = rng.standard_normal((64, 64)) * 0.3; _ = L @ rng.standard_normal((64, 1024)) + rng.standard_normal((64, 1024))
x = rng.standard_normal(4096)
for eps in [1e-3, 1e-5, 1e-7, 1e-8]:
    yy = x + eps * rng.standard_normal(4096)
    dd = mk(np.vstack([x, yy])); Zz = dd.to_numpy(squeeze=True)
    Av = PairwiseDistance(metric="euclidean").multivariate(dd)[0, 1]
    ref = np.sqrt(np.sum((Zz[0] - Zz[1]) ** 2))
    r = np.corrcoef(Zz)[0, 1]
    print(f"eps={eps:g} sklearn={Av:.6e} direct={ref:.6e} rel={abs(Av - ref) / ref:.2e}  1-r={1 - r:.2e}")

print("\n== braycurtis anticorrelated T=4096 + inf + warnings ==")
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter("always")
    for rho in [-0.5, -0.9, -0.99, -0.999]:
        n = rng.standard_normal(4096)
        yy = rho * x + np.sqrt(1 - rho ** 2) * n
        dd = mk(np.vstack([x, yy]))
        print("rho", rho, "braycurtis", PairwiseDistance(metric="braycurtis").multivariate(dd)[0, 1], "asymptotic", np.sqrt((1 - rho) / (1 + rho)), "canberra/T", PairwiseDistance(metric="canberra").multivariate(dd)[0, 1] / 4096)
    dd = mk(np.vstack([x, -x]))
    with np.errstate(all='raise'):
        try:
            B = PairwiseDistance(metric="braycurtis").multivariate(dd)
            print("x,-x braycurtis (errstate raise):", B[0, 1], B)
        except FloatingPointError as e:
            print("FloatingPointError:", e)
    print("warnings recorded:", [str(i.message)[:80] for i in w])

print("\n== Calculator with pdist_braycurtis on (x,-x): does inf survive compute()? ==")
from pyspi.calculator import Calculator
import tempfile, yaml, os
cfg = {"statistics.distance": {"PairwiseDistance": {"labels": ["undirected"], "dependencies": None, "configs": [{"metric": "braycurtis"}, {"metric": "canberra"}]}}}
# use module path form like config.yaml
with open('/media/dan/Data/git/pyspi/pyspi/config.yaml') as f:
    full = yaml.safe_load(f)
key = [k for k in full if 'distance' in k][0]
cfg = {key: {"PairwiseDistance": full[key]["PairwiseDistance"]}}
cfg[key]["PairwiseDistance"]["configs"] = [{"metric": "braycurtis"}, {"metric": "canberra"}]
tmp = tempfile.NamedTemporaryFile('w', suffix='.yaml', delete=False, dir='/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/fable_review')
yaml.safe_dump(cfg, tmp); tmp.close()
with contextlib.redirect_stdout(io.StringIO()):
    calc = Calculator(dataset=np.vstack([x, -x, 2 * x + 1]), configfile=tmp.name)
    calc.compute()
print(calc.table)
print("has inf:", np.isinf(calc.table.values).any())

print("\n== population constants ==")
print("0.5+ln2/pi =", 0.5 + np.log(2) / np.pi)
rng = np.random.default_rng(5); T = 400000
for rho in [0.0, 0.8]:
    xx = rng.standard_normal(T); yy = rho * xx + np.sqrt(1 - rho ** 2) * rng.standard_normal(T)
    d = mk(np.vstack([xx, yy]))
    out = {m: PairwiseDistance(metric=m).multivariate(d)[0, 1] for m in ["cityblock", "canberra", "braycurtis"]}
    print(rho, "cityblock/T", out["cityblock"] / T, "pop", 2 * np.sqrt((1 - rho) / np.pi), "| canberra/T", out["canberra"] / T, "| bc", out["braycurtis"], "pop", np.sqrt((1 - rho) / (1 + rho)))

print("\n== permutation invariance (T=1024, 64 proc) ==")
p = np.random.default_rng(9).permutation(Tn)
d3 = mk(raw2[:, p])
for m in M:
    print(m, np.abs(PairwiseDistance(metric=m).multivariate(d2) - PairwiseDistance(metric=m).multivariate(d3)).max())
