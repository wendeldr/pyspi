"""Fable independent probe for lagged_dcorr_mgc claims. Read-only."""
import io, contextlib, warnings
import numpy as np
warnings.filterwarnings("ignore")

# ---------- from-scratch unbiased dcorr (Szekely & Rizzo 2014 U-centering), no hyppo ----------
def ucenter(D):
    n = D.shape[0]
    r = D.sum(axis=1, keepdims=True) / (n - 2)
    c = D.sum(axis=0, keepdims=True) / (n - 2)
    g = D.sum() / ((n - 1) * (n - 2))
    U = D - r - c + g
    np.fill_diagonal(U, 0.0)
    return U

def udcorr_from_D(Dx, Dy):
    A, B = ucenter(Dx), ucenter(Dy)
    cov = (A * B).sum(); vx = (A * A).sum(); vy = (B * B).sum()
    if vx <= 0 or vy <= 0:
        return 0.0
    return cov / np.sqrt(vx * vy)

def edist(X):
    X = np.atleast_2d(X)
    if X.shape[0] == 1 and X.ndim == 2 and X.shape[1] > 1 and False:
        pass
    sq = (X ** 2).sum(1)
    D2 = sq[:, None] + sq[None, :] - 2 * X @ X.T
    D2[D2 < 0] = 0
    return np.sqrt(D2)

def edist_1d(x):
    x = np.asarray(x).ravel()
    return np.abs(x[:, None] - x[None, :])

def dist_of_dist_sum(x, y, M):
    n = len(x)
    Dx, Dy = edist_1d(x), edist_1d(y)
    terms = [udcorr_from_D(Dx, Dy)]
    for j in range(1, M + 1):
        Sx, Sy = Dx[j:, j:], Dy[:n - j, :n - j]
        terms.append((n - j) / n * udcorr_from_D(edist(Sx), edist(Sy)))
    return sum(terms), terms

def canonical_sum(x, y, M):
    n = len(x)
    terms = [udcorr_from_D(edist_1d(x), edist_1d(y))]
    for j in range(1, M + 1):
        terms.append((n - j) / n * udcorr_from_D(edist_1d(x[j:]), edist_1d(y[:n - j])))
    return sum(terms), terms

# ---------- toy data as in Opus probe1 (own RNG, so numbers differ; relationships must hold) ----------
rng = np.random.default_rng(12345)
n = 64
y = rng.standard_normal(n)
x = np.r_[0.0, y[:-1]] + 0.3 * rng.standard_normal(n)

from hyppo.time_series import DcorrX, MGCX
from hyppo.independence import MGC
from scipy.stats import multiscale_graphcorr
X, Y = x[:, None], y[:, None]
for M in (1, 3):
    s_h, lag = DcorrX(max_lag=M).statistic(X, Y)
    s_dd, t_dd = dist_of_dist_sum(x, y, M)
    s_can, t_can = canonical_sum(x, y, M)
    print(f"M={M} hyppo DcorrX={s_h!r} opt_lag={lag}")
    print(f"      from-scratch dist-of-dist={s_dd!r} diff={abs(s_h-s_dd):.2e}")
    print(f"      from-scratch canonical    ={s_can!r} diff={abs(s_h-s_can):.2e}")
    print(f"      terms dd ={np.round(t_dd,6)}  canonical={np.round(t_can,6)}")

# MGC: hyppo MGCX vs scipy multiscale_graphcorr on dist-of-dist slices vs on lagged-series slices
def mgc_stat(Dx, Dy):
    return multiscale_graphcorr(Dx, Dy, compute_distance=None, reps=0).statistic
for M in (1,):
    s_h, lag, scale = MGCX(max_lag=M).statistic(X, Y)
    Dx, Dy = edist_1d(x), edist_1d(y)
    dd = [mgc_stat(Dx, Dy)]; can = [mgc_stat(Dx, Dy)]
    for j in range(1, M + 1):
        Sx, Sy = Dx[j:, j:], Dy[:n - j, :n - j]
        dd.append((n - j) / n * mgc_stat(edist(Sx), edist(Sy)))
        can.append((n - j) / n * mgc_stat(Sx, Sy))
    print(f"MGCX M={M} hyppo={s_h!r} dd_sum={sum(dd)!r} canonical_sum={sum(can)!r}")

# ---------- pipeline direction and sign checks through pyspi ----------
from pyspi.data import Data
from pyspi.statistics.distance import CrossDistanceCorrelation as DX, CrossMultiscaleGraphCorrelation as MX
D = '/media/dan/Data/git/pyspi/audit/checks/data/'
def load(name):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(np.load(D + name + '.npz')['x'], dim_order='ps')
d = load('delayed_noise_T256')
d2 = Data(np.load(D + 'delayed_noise_T256.npz')['x'][:2], dim_order='ps') if False else None
with contextlib.redirect_stdout(io.StringIO()):
    d2 = Data(np.load(D + 'delayed_noise_T256.npz')['x'][:2], dim_order='ps')
for cls in (DX, MX):
    for M in (1, 10):
        A = cls(max_lag=M).multivariate(d2)
        print(f"{cls.__name__} M={M} delayed_noise(x0 leads x1 by 1): A[0,1]={A[0,1]:.4f} A[1,0]={A[1,0]:.4f}")
with contextlib.redirect_stdout(io.StringIO()):
    dv = Data(np.load(D + 'var2_bivariate_T256.npz')['x'], dim_order='ps')
for cls in (DX,):
    for M in (1, 10):
        A = cls(max_lag=M).multivariate(dv)
        print(f"{cls.__name__} M={M} var2_bivariate (X0->Y1): A[0,1]={A[0,1]:.4f} A[1,0]={A[1,0]:.4f}")

# iid negativity
di = load('iid_gaussian_T64')
for cls in (DX, MX):
    for M in (1, 10):
        A = cls(max_lag=M).multivariate(di); off = A[~np.eye(A.shape[0], dtype=bool)]
        print(f"{cls.__name__} M={M} iid T64: min={off.min():.4f} n_neg={(off<0).sum()}/{off.size} labels={cls(max_lag=M).labels}")

# MGC lag-0 alone negative on iid? (scipy directly; not via dcorr.py)
zi = di.to_numpy()
negs = []
for a in range(5):
    for b in range(5):
        if a != b:
            negs.append(mgc_stat(edist_1d(zi[a]), edist_1d(zi[b])))
negs = np.array(negs)
print(f"scipy MGC lag-0 on iid T64: min={negs.min():.4f} n_neg={(negs<0).sum()}/{negs.size}")

# sum > 1
for name in ['narrowband_f0-0.1_T256', 'shared_envelope_T256']:
    dd_ = load(name)
    for cls in (DX, MX):
        for M in (1, 10):
            A = cls(max_lag=M).multivariate(dd_); off = A[~np.eye(A.shape[0], dtype=bool)]
            print(f"{name} {cls.__name__} M={M}: max={np.nanmax(off):.4f}")

# small n behaviour (claim: raises for n<=3)
for nn in (2, 3, 4):
    try:
        xx = rng.standard_normal(nn)[:, None]; yy = rng.standard_normal(nn)[:, None]
        print(f"DcorrX n={nn}:", DcorrX(max_lag=1).statistic(xx, yy))
    except Exception as e:
        print(f"DcorrX n={nn}: raises {type(e).__name__}: {e}")
for nn in (4, 5, 6):
    try:
        xx = rng.standard_normal(nn)[:, None]; yy = rng.standard_normal(nn)[:, None]
        print(f"MGCX n={nn}:", MGCX(max_lag=1).statistic(xx, yy)[0])
    except Exception as e:
        print(f"MGCX n={nn}: raises {type(e).__name__}: {e}")

# call counting + RNG state
import hyppo.independence.mgc as hm
cnt = {'n': 0}; orig = hm.multiscale_graphcorr
def wrap(*a, **k):
    cnt['n'] += 1; return orig(*a, **k)
hm.multiscale_graphcorr = wrap
with contextlib.redirect_stdout(io.StringIO()):
    d64 = Data(np.load(D + 'delayed_noise_T64.npz')['x'][:2], dim_order='ps')
for M in (1, 10):
    cnt['n'] = 0
    st0 = np.random.get_state()
    v = MX(max_lag=M).bivariate(d64, i=0, j=1)
    st1 = np.random.get_state()
    same = (st0[1] == st1[1]).all() and st0[2] == st1[2]
    print(f"mgcx M={M}: multiscale_graphcorr calls={cnt['n']} needed={M+1}; global RNG unchanged={same}")
hm.multiscale_graphcorr = orig
# does np.random.randint(size=0) consume state?
st0 = np.random.get_state(); _ = np.random.randint(np.iinfo(np.int32).max, size=0); st1 = np.random.get_state()
print("np.random.randint(size=0) changes state:", not ((st0[1] == st1[1]).all() and st0[2] == st1[2]))

# multi-realisation path: z[i] is (T,R) -> hyppo treats as R-dim sample
with contextlib.redirect_stdout(io.StringIO()):
    dr = Data(np.random.default_rng(1).standard_normal((3, 64, 2)), dim_order='psr')
print("R=2 to_numpy shape", dr.to_numpy().shape, "z[0] shape", dr.to_numpy()[0].shape)
try:
    print("dcorrx R=2 bivariate:", DX(max_lag=1).bivariate(dr, i=0, j=1))
except Exception as e:
    print("dcorrx R=2 raises", type(e).__name__, e)
