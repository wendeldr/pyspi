import sys, warnings, io, contextlib
import numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
import make_data as md
from scipy.stats import zscore
from scipy.optimize import minimize, minimize_scalar
from scipy.linalg import solve, inv
import pyspi.lib.phi_native as pn
from pyspi.lib.phi_native import phi_star_gauss, phi_g_gauss, phi_g_gauss_al, cov_comp, logdet, h_gauss, cov_cond
warnings.simplefilter('ignore')
np.set_printoptions(precision=12)

def X(name, T): return md.load(name, T)['x']
def z(x): return zscore(x, axis=1, ddof=1)

# ---------- independent Gaussian tilde-I(beta): completing the square ----------
def itilde(beta, SX, SXY, SY, parts):
    # SXY = E[x y'] (past x present) as in cov_comp; A = SYX SX^-1
    N = SX.shape[0]
    AD = np.zeros((N, N)); D = np.zeros((N, N))
    for M in parts:
        sx = SX[np.ix_(M, M)]; sxy = SXY[np.ix_(M, M)]; sy = SY[np.ix_(M, M)]
        a = sxy.T @ np.linalg.inv(sx)          # per-part regression y_k on x_k
        AD[np.ix_(M, M)] = a
        D[np.ix_(M, M)] = sy - a @ sxy          # per-part residual covariance
    Dinv = np.linalg.inv(D)
    Qinv = np.linalg.inv(SX) + beta * AD.T @ Dinv @ AD
    Q = np.linalg.inv(Qinv)
    R = beta * Dinv - beta**2 * Dinv @ AD @ Q @ AD.T @ Dinv
    return 0.5*np.linalg.slogdet(SX)[1] + 0.5*np.linalg.slogdet(Qinv)[1] + 0.5*np.trace(R @ SY) - beta*N/2

def istar_ref(SX, SXY, SY, parts=([0],[1])):
    grid = np.linspace(0.01, 5, 2000)
    vals = [itilde(b, SX, SXY, SY, parts) for b in grid]
    b0 = grid[int(np.argmax(vals))]
    r = minimize_scalar(lambda b: -itilde(b, SX, SXY, SY, parts), bounds=(max(1e-6,b0-0.2), b0+0.2), method='bounded', options={'xatol':1e-12})
    return -r.fun, r.x

def I_mi(SX, SXY, SY):
    SE = SY - SXY.T @ np.linalg.solve(SX, SXY)
    return 0.5*(np.linalg.slogdet(SY)[1] - np.linalg.slogdet(SE)[1])

print("=== 1. L-BFGS-B stop at beta=1: iid_gaussian T1024 pair (2,3) ===")
x = z(X('iid_gaussian', 1024))[[2, 3]]
orig_min = pn.minimize
def spy(*a, **k):
    r = orig_min(*a, **k); print('  SPY nit', r.nit, 'nfev', r.nfev, 'x', r.x, 'jac', r.jac, '|', r.message); return r
pn.minimize = spy
c = cov_comp(x, 1)
ps, I, b = phi_star_gauss(c['Cov_X'], c['Cov_XY'], c['Cov_Y'], np.array([1,2]))
pn.minimize = orig_min
Is, bref = istar_ref(c['Cov_X'], c['Cov_XY'], c['Cov_Y'])
print('  pyspi phi*', repr(ps), 'beta', b, '| ref phi*', repr(I - Is), 'beta', bref, '| diff', ps-(I-Is), 'rel', (ps-(I-Is))/(I-Is))

print("=== 2. one-sidedness over 28 pairs (iid, var2_bivariate, delayed_noise, bivariate_gaussian, gauss_ar1_pair at T=1024) ===")
diffs = []
for name in ['iid_gaussian','var2_bivariate','delayed_noise','bivariate_gaussian','gauss_ar1_pair','narrowband_f0-0.25','cointegrated','logistic_maps']:
    xx = z(X(name, 1024)); P = xx.shape[0]
    for i in range(P):
        for j in range(i+1, P):
            c = cov_comp(xx[[i,j]], 1)
            ps, I, b = phi_star_gauss(c['Cov_X'], c['Cov_XY'], c['Cov_Y'], np.array([1,2]))
            Is, bref = istar_ref(c['Cov_X'], c['Cov_XY'], c['Cov_Y'])
            diffs.append((name, i, j, ps - (I-Is), b, bref))
d = np.array([t[3] for t in diffs])
print('  n pairs', len(diffs), 'min diff', d.min(), 'max diff', d.max(), 'beta range', min(t[4] for t in diffs), max(t[4] for t in diffs))
print('  negative diffs (<-1e-12):', [t for t in diffs if t[3] < -1e-12])

print("=== 3. population gauss_ar1_pair ===")
g = md.load('gauss_ar1_pair', 1024)
SX, SXY = g['Sigma_X'], g['Sigma_XY']   # Sigma_XY = A SX = E[y x'] -> cov_comp Cov_XY = E[x y'] = SXY.T
ps, I, b = phi_star_gauss(SX, SXY.T, SX, np.array([1,2]))
Is, bref = istar_ref(SX, SXY.T, SX)
print('  pyspi phi*', repr(ps), 'I', repr(I), 'beta', b, '| ref', repr(I-Is), 'beta', bref)
print('  I from scratch', I_mi(SX, SXY.T, SX))
pg, _, Ap = phi_g_gauss(SX, SXY.T, SX, np.array([1,2]))
A = np.linalg.solve(SX, SXY.T).T; SE = SX - SXY.T.T @ np.linalg.solve(SX, SXY.T)
def fG(a, A, SE, SX):
    Ad = A - np.diag(a); M = SE + Ad @ SX @ Ad.T
    return 0.5*(np.linalg.slogdet(M)[1] - np.linalg.slogdet(SE)[1])
best = min((minimize(fG, s, args=(A,SE,SX), method='Nelder-Mead', options={'xatol':1e-12,'fatol':1e-14,'maxiter':20000}).fun for s in [np.diag(A), np.zeros(2), np.array([1.,1.]), np.array([-1.,-1.])]))
print('  pyspi phi_G', repr(pg), '| direct NM min', repr(best), 'A_p diag', np.diag(Ap), 'offdiag', Ap[0,1], Ap[1,0])
print('  phi_G > phi*?', pg > ps)

print("=== 4. AL non-optimal stop: delayed_noise T64 pair (0,1) ===")
x = z(X('delayed_noise', 64))[[0,1]]
c = cov_comp(x, 1)
A = np.linalg.solve(c['Cov_X'], c['Cov_XY']).T; SE = c['Cov_Y'] - c['Cov_XY'].T @ np.linalg.solve(c['Cov_X'], c['Cov_XY']); SX = c['Cov_X']
ncalls = [0]; orig_logdet = pn.logdet
def ld(Xm): ncalls[0] += 1; return orig_logdet(Xm)
pn.logdet = ld
pg, CEp, Ap = phi_g_gauss_al(SX, SE, A, np.array([1,2]))
pn.logdet = orig_logdet
print('  pyspi phi_G', repr(pg), 'A_p', Ap.ravel(), 'iters ~', (ncalls[0]-2)//2, 'min eig SE', np.linalg.eigvalsh(SE).min(), 'min eig SEp', np.linalg.eigvalsh(CEp).min())
res = []
for s in [np.diag(A), np.zeros(2), np.array([-3.4,0.02]), np.array([1.,1.]), np.array([-1.,0.]), np.array([5.,5.])]:
    r1 = minimize(fG, s, args=(A,SE,SX), method='Nelder-Mead', options={'xatol':1e-12,'fatol':1e-14,'maxiter':40000})
    r2 = minimize(fG, s, args=(A,SE,SX), method='BFGS', options={'gtol':1e-12})
    res += [(r1.fun, r1.x), (r2.fun, r2.x)]
fb, ab = min(res, key=lambda t: t[0])
print('  direct min', repr(fb), 'at', ab, '| gap pyspi-direct', pg - fb)
a_al = np.diag(Ap); eps = 1e-6
grad = np.array([(fG(a_al+eps*e, A,SE,SX)-fG(a_al-eps*e, A,SE,SX))/(2*eps) for e in np.eye(2)])
H = np.zeros((2,2))
for i in range(2):
    for j in range(2):
        ei, ej = np.eye(2)[i], np.eye(2)[j]
        H[i,j] = (fG(a_al+eps*ei+eps*ej,A,SE,SX)-fG(a_al+eps*ei-eps*ej,A,SE,SX)-fG(a_al-eps*ei+eps*ej,A,SE,SX)+fG(a_al-eps*ei-eps*ej,A,SE,SX))/(4*eps*eps)
print('  gradient at AL point', grad, 'Hessian eig', np.linalg.eigvalsh(H), 'f(AL diag)', fG(a_al,A,SE,SX), 'constraint viol', np.sum((Ap - np.diag(np.diag(Ap)))**2))
# other claimed gaps
for name, T, pr in [('delayed_noise', 1024, (0,1)), ('narrowband_f0-0.25', 64, (0,2))]:
    x = z(X(name, T))[list(pr)]; c = cov_comp(x, 1)
    A = np.linalg.solve(c['Cov_X'], c['Cov_XY']).T; SE = c['Cov_Y'] - c['Cov_XY'].T @ np.linalg.solve(c['Cov_X'], c['Cov_XY']); SX = c['Cov_X']
    pg, _, Ap = phi_g_gauss_al(SX, SE, A, np.array([1,2]))
    fb = min(min(minimize(fG, s, args=(A,SE,SX), method='Nelder-Mead', options={'xatol':1e-12,'fatol':1e-14,'maxiter':40000}).fun, minimize(fG, s, args=(A,SE,SX), method='BFGS', options={'gtol':1e-12}).fun) for s in [np.diag(A), np.zeros(2), np.array([1.,1.]), np.array([-1.,-1.])])
    print(f'  {name} T{T} {pr}: pyspi {pg!r} direct {fb!r} gap {pg-fb:.3e}')

print("=== 5. logdet fallback / degenerate pairs ===")
rng = np.random.default_rng(123)
T = 1024; b0 = rng.standard_normal(T+1)
raw = np.stack([b0[1:], b0[:-1]])          # x1(t) = x0(t-1) exactly
for lab, xx in [('raw', raw), ('zscored', z(raw))]:
    c = cov_comp(xx, 1)
    CYX = cov_cond(c['Cov_Y'], c['Cov_XY'].T, c['Cov_X'])
    ev = np.linalg.eigvals(CYX)
    try:
        np.linalg.cholesky(CYX); chol = 'ok'
    except Exception as e: chol = 'FAIL'
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        ps = phi_star_gauss(c['Cov_X'], c['Cov_XY'], c['Cov_Y'], np.array([1,2]))[0]
        pg = phi_g_gauss(c['Cov_X'], c['Cov_XY'], c['Cov_Y'], np.array([1,2]))[0]
    print(f'  {lab}: eig(Cov_Y|X)={ev} chol={chol} logdet={logdet(CYX)!r} phi*={ps!r} phi_G={pg!r} warnings={[str(ww.message)[:40] for ww in w]}')
print('  np.iscomplex(0.1+0j) =', np.iscomplex(0.1+0j), '; isinf of complex finite', np.isinf(0.1+0j))
for T in [64, 256, 1024]:
    xx = z(X('shared_envelope', T))[[0,2]]
    print('  shared_envelope bit-identical?', np.array_equal(xx[0], xx[1]), end=' ')
    c = cov_comp(xx, 1)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        ps = phi_star_gauss(c['Cov_X'], c['Cov_XY'], c['Cov_Y'], np.array([1,2]))[0]
        pg = phi_g_gauss(c['Cov_X'], c['Cov_XY'], c['Cov_Y'], np.array([1,2]))[0]
    print(f'T{T}: phi*={ps!r} phi_G={pg!r} nwarn={len(w)} kinds={set(type(ww.message).__name__ for ww in w)}')

print("=== 6. norm-1 divisor ===")
from pyspi.lib.phi_native import phi_comp
for name, T in [('var2_chain', 1024), ('iid_gaussian', 1024), ('gauss_ar1_pair', 4096)]:
    xx = z(X(name, T))
    for (i,j) in [(0,1),(1,2)] if xx.shape[0] > 2 else [(0,1)]:
        p0 = phi_comp(xx[[i,j]], np.array([1,2]), {'tau':1}, {'type_of_phi':'star','type_of_dist':'Gauss','normalization':0})
        p1 = phi_comp(xx[[i,j]], np.array([1,2]), {'tau':1}, {'type_of_phi':'star','type_of_dist':'Gauss','normalization':1})
        g0 = phi_comp(xx[[i,j]], np.array([1,2]), {'tau':1}, {'type_of_phi':'Geo','type_of_dist':'Gauss','normalization':0})
        g1 = phi_comp(xx[[i,j]], np.array([1,2]), {'tau':1}, {'type_of_phi':'Geo','type_of_dist':'Gauss','normalization':1})
        c = cov_comp(xx[[i,j]], 1)
        hmin = min(0.5*np.log(2*np.pi*np.e*c['Cov_X'][k,k]) for k in range(2))
        print(f'  {name} T{T} ({i},{j}): star ratio {p0/p1:.6f} Geo ratio {g0/g1:.6f} from-scratch min past h {hmin:.6f}')
print('  h_gauss(var=0.04) =', 0.5*np.log(2*np.pi*np.e*0.04), '; threshold var 1/(2 pi e) =', 1/(2*np.pi*np.e))
xx = X('scaled_offset', 1024)[[0,1]]
print('  scaled_offset raw var of rows:', xx.var(axis=1, ddof=1))
for lab, data in [('normalise=False', xx), ('zscored', z(xx))]:
    vals = [phi_comp(data, np.array([1,2]), {'tau':1}, {'type_of_phi':t,'type_of_dist':'Gauss','normalization':n}) for t in ['star','Geo'] for n in [0,1]]
    print(f'  scaled_offset (0,1) {lab}: star0 {vals[0]:.6e} star1 {vals[1]:.6e} Geo0 {vals[2]:.6e} Geo1 {vals[3]:.6e}')
bg = X('bivariate_gaussian', 1024)[[0,1]]
print('  bivariate_gaussian (0,1) raw star0', phi_comp(bg, np.array([1,2]), {'tau':1}, {'type_of_phi':'star','type_of_dist':'Gauss','normalization':0}), ' Geo0', phi_comp(bg, np.array([1,2]), {'tau':1}, {'type_of_phi':'Geo','type_of_dist':'Gauss','normalization':0}))

print("=== 7. direction / symmetry through the class ===")
from pyspi.data import Data
from pyspi.statistics.infotheory import IntegratedInformation
with contextlib.redirect_stdout(io.StringIO()):
    dv = Data(X('var2_chain', 1024), dim_order='ps', normalise=True)
    dg = Data(X('gauss_ar1_pair', 4096), dim_order='ps', normalise=True)
import pyspi.statistics.infotheory as it_mod
print('  MRO:', [k.__name__ for k in IntegratedInformation.__mro__][:4])
for pt in ['star', 'Geo']:
    spi = IntegratedInformation(phitype=pt)
    A = spi.multivariate(dv)
    print(f'  {pt} var2_chain T1024: array_equal(A, A.T) =', np.array_equal(A, A.T), 'A=', A.ravel())
    a01 = spi.bivariate(dg, i=0, j=1); a10 = spi.bivariate(dg, i=1, j=0)
    print(f'  {pt} gauss_ar1 T4096 bivariate(0,1) {a01!r} bivariate(1,0) {a10!r} diff {a01-a10:.3e}')

print("=== 8. parse_bivariate with two raw arrays ===")
r0 = X('scaled_offset', 1024)
with contextlib.redirect_stdout(io.StringIO()):
    dd = Data(); dd.add_process(r0[0]); dd.add_process(r0[1])
arr = dd.to_numpy(squeeze=True)
print('  means', arr.mean(axis=1), 'sds', arr.std(axis=1, ddof=1))
