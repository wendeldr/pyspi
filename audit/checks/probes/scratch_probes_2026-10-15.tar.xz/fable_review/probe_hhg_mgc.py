import sys, numpy as np, io, contextlib, warnings, json, time
sys.path.insert(0, '/media/dan/Data/git/pyspi')
sys.path.insert(0, '/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/hhg_mgc/probes')
from pyspi.statistics.distance import HellerHellerGorfine, MultiscaleGraphCorrelation as M
from pyspi.data import Data
from hyppo.independence import HHG, MGC, Dcorr
from hyppo.tools import compute_dist
from scipy.stats import multiscale_graphcorr
from mgc_scratch import mgc
DD = '/media/dan/Data/git/pyspi/audit/checks/data/'
def load(name, T): return np.load(DD + f'{name}_T{T}.npz')['x']
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, dim_order='ps')

def hhg_scratch(x, y):
    # my own vectorised version: exact distances, Heller 2013
    n = len(x); dx = np.abs(x[:, None] - x[None, :]); dy = np.abs(y[:, None] - y[None, :]); T = 0.0
    for i in range(n):
        a_all = dx[i][None, :] <= dx[i][:, None]   # [j, k]: d(i,k) <= d(i,j)
        b_all = dy[i][None, :] <= dy[i][:, None]
        for j in range(n):
            if i == j: continue
            m = np.ones(n, bool); m[[i, j]] = False
            a = a_all[j, m]; b = b_all[j, m]
            A11 = np.sum(a & b); A12 = np.sum(a & ~b); A21 = np.sum(~a & b); A22 = np.sum(~a & ~b)
            den = (A11 + A12) * (A21 + A22) * (A11 + A21) * (A12 + A22)
            if den > 0: T += (n - 2) * (A12 * A21 - A11 * A22) ** 2 / den
    return T

print("== HHG symmetry on 5 datasets T=64 + scratch ==")
for name in ['iid_gaussian', 'bivariate_gaussian', 'nonlinear_dependence', 'delayed_noise', 'shared_envelope']:
    d = mk(load(name, 64)); A = HellerHellerGorfine().multivariate(d); z = d.to_numpy(squeeze=True)
    print(f"{name:22s} max|A-A.T|={np.nanmax(np.abs(A - A.T))}  scratch(0,1)={hhg_scratch(z[0], z[1])!r}  pyspi(0,1)={A[0, 1]!r}  minA={np.nanmin(A):.1f} maxA={np.nanmax(A):.1f}")
d = mk(load('shared_envelope', 64)); A = HellerHellerGorfine().multivariate(d)
print("shared_envelope (0,2) T=64:", A[0, 2], " N(N-2)(N-3)=", 64 * 62 * 61)
print("iid T=64 all off-diag values:", np.round(np.sort(A[~np.isnan(A)]), 0)[:5], "...", "N(N-1)=", 64 * 63)
d = mk(load('iid_gaussian', 64)); A = HellerHellerGorfine().multivariate(d); print("iid T=64 range", np.nanmin(A), np.nanmax(A))

print("\n== HHG shared_envelope T=64 (0,1) sklearn vs exact ==")
z = mk(load('shared_envelope', 64)).to_numpy(squeeze=True)
a, b = z[0][:, None], z[1][:, None]
ex = np.abs(a - a.T); ey = np.abs(b - b.T)
print("sklearn", HHG().statistic(a, b), "exact", HHG(compute_distance=None).statistic(ex, ey), "diff", HHG().statistic(a, b) - HHG(compute_distance=None).statistic(ex, ey), " n-2 =", 62)
dx, dy = compute_dist(a, b)
print("max|dx-ex|", np.abs(dx - ex).max(), "dx bit-sym", np.array_equal(dx, dx.T), "max|dx-dx.T|", np.abs(dx - dx.T).max())

print("\n== numba signature of _pearson_stat ==")
from hyppo.independence.hhg import _pearson_stat
print(_pearson_stat.signatures)
try:
    print(_pearson_stat.inspect_types.__doc__[:0], end='')
    import re
    txt = _pearson_stat.inspect_types(pretty=False) if False else None
except Exception as e:
    pass
# direct overflow check in numba kernel with synthetic counts: emulate in numpy int64
t = np.int64(5250); print("(n-2)*(t*t)**2 at t=5250, n=10502 in int64 (overflow?):", np.int64(10500) * (t * t) ** 2, " exact:", 10500 * (5250 ** 2) ** 2, " 2^63=", 2 ** 63)

print("\n== rounding-scope at T=256 on all datasets (replicates p7) ==")
names = sorted(set(f['name'] for f in json.load(open(DD + 'MANIFEST.json'))['files']))
T = 256
for name in names:
    z = mk(load(name, T)).to_numpy(); P = z.shape[0]; hr = []; mr = []; hv = []; mv = []
    for i in range(P):
        for j in range(i + 1, P):
            a, b = z[i], z[j]; ex = np.abs(a - a.T); ey = np.abs(b - b.T)
            h1 = HHG().statistic(a, b); h2 = HHG(compute_distance=None).statistic(ex, ey)
            m1 = MGC().statistic(a, b); m2 = MGC(compute_distance=None).statistic(ex, ey)
            hr.append(abs(h1 - h2) / abs(h2)); mr.append(abs(m1 - m2)); hv.append((h1, h2)); mv.append((m1, m2))
    k = int(np.argmax(mr))
    print(f"{name:22s} HHG max rel {max(hr):.2e}  MGC max abs {max(mr):.2e}  (worst MGC pair sklearn={mv[k][0]:.4f} exact={mv[k][1]:.4f})  min unique {min(len(np.unique(z[q])) for q in range(P))}")

print("\n== MGC p3: symmetry, negatives, global vs Dcorr ==")
m = M()
for name in ['iid_gaussian', 'nonlinear_dependence', 'shared_envelope']:
    for T in [64, 256]:
        d = mk(load(name, T)); P = d.n_processes; A = m.multivariate(d)
        B = np.full((P, P), np.nan)
        for i in range(P):
            for j in range(P):
                if i != j: B[i, j] = m.bivariate(d, i=i, j=j)
        print(f"{name} T={T} A sym {np.nanmax(np.abs(A - A.T))}  biv(i,j)-(j,i) max {np.nanmax(np.abs(B - B.T)):.2e}  min {np.nanmin(A):.4f}  max {np.nanmax(A):.4f}  A[0,1]==biv(0,1): {A[0,1]==B[0,1]}")
z = mk(load('iid_gaussian', 256)).to_numpy()
a, b = z[0], z[1]; dx, dy = compute_dist(a, b)
with warnings.catch_warnings():
    warnings.simplefilter('ignore'); r = multiscale_graphcorr(dx, dy, compute_distance=None, reps=0)
mp = r.mgc_dict['mgc_map']
print("iid T=256 (0,1): mgc", repr(r.stat), "opt", r.mgc_dict['opt_scale'], "global", repr(mp[-1, -1]), "Dcorr unbiased", repr(Dcorr().statistic(a, b)), "Dcorr biased", Dcorr(bias=True).statistic(a, b))
# analytic global-scale identity: column-centred
def colcenter(Dm):
    n = Dm.shape[0]; A = Dm - Dm.sum(0, keepdims=True) / (n - 1); np.fill_diagonal(A, 0); return A
Ac, Bc = colcenter(dx), colcenter(dy)
print("analytic global = sum A_ab B_ba / sqrt(...):", (Ac * Bc.T).sum() / np.sqrt((Ac * Ac.T).sum() * (Bc * Bc.T).sum()))

print("\n== MGC p4 variants ==")
for name, pairs, Ts in [('nonlinear_dependence', [(0, 1)], [64, 1024]), ('logistic_maps', [(0, 1)], [64])]:
    for T in Ts:
        z = mk(load(name, T)).to_numpy(squeeze=True); d = mk(load(name, T))
        for i, j in pairs:
            Dx = np.abs(z[i][:, None] - z[i][None, :]); Dy = np.abs(z[j][:, None] - z[j][None, :])
            p = M().bivariate(d, i=i, j=j)
            print(f"{name} T={T} {(i, j)} pyspi={p:.10f} scratch={mgc(Dx, Dy):.10f} n(n-1)={mgc(Dx, Dy, const='nn1'):.10f} tau_n={mgc(Dx, Dy, samp='n'):.10f} region2n={mgc(Dx, Dy, region='2n'):.10f} uniq={len(np.unique(z[i]))},{len(np.unique(z[j]))}")

print("\n== logistic_maps T=64 map shape and region rule ==")
z = mk(load('logistic_maps', 64)).to_numpy(); a, b = z[0], z[1]; dx, dy = compute_dist(a, b)
with warnings.catch_warnings():
    warnings.simplefilter('ignore'); r = multiscale_graphcorr(dx, dy, compute_distance=None, reps=0)
mp = r.mgc_dict['mgc_map']; mm, nn = mp.shape
print("map shape", mp.shape, "opt", r.mgc_dict['opt_scale'], "stat", r.stat, "impl rule needs", np.ceil(0.02 * max(mm, nn)) * min(mm, nn), "2n =", 2 * 64, "2min(m,n) =", 2 * min(mm, nn))

print("\n== shared_envelope T=256 (0,1) MGC sklearn vs exact ==")
z = mk(load('shared_envelope', 256)).to_numpy(); a, b = z[0], z[1]; ex = np.abs(a - a.T); ey = np.abs(b - b.T)
dx, dy = compute_dist(a, b)
with warnings.catch_warnings():
    warnings.simplefilter('ignore'); r1 = multiscale_graphcorr(dx, dy, compute_distance=None, reps=0); r2 = multiscale_graphcorr(ex, ey, compute_distance=None, reps=0)
print("sklearn", r1.stat, r1.mgc_dict['opt_scale'], " exact", r2.stat, r2.mgc_dict['opt_scale'])

print("\n== scipy.sparse.construct deprecation on import ==")
import subprocess
out = subprocess.run(['/media/dan/Data/git/pyspi/.venv/bin/python', '-W', 'always', '-c', 'import hyppo.independence.hhg'], capture_output=True, text=True)
print(out.stderr.strip()[-300:])

print("\n== HHG timing T=1024 single call ==")
z = mk(load('iid_gaussian', 1024)).to_numpy(); a, b = z[0], z[1]
HHG().statistic(z[0][:50], z[1][:50])
t0 = time.time(); HHG().statistic(a, b); print("HHG T=1024 one call: %.2f s" % (time.time() - t0))
