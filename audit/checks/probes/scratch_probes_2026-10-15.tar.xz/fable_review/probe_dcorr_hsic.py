import numpy as np, io, contextlib, sys
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from hyppo.independence import Dcorr, Hsic
from pyspi.statistics.distance import DistanceCorrelation as D, HilbertSchmidtIndependenceCriterion as H
from pyspi.data import Data

def mk(x, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, **kw)

def dist(x): return np.abs(x[:, None] - x[None, :])
def dc(A): return A - A.mean(0)[None, :] - A.mean(1)[:, None] + A.mean()
def uc(A):
    n = A.shape[0]; B = A.copy(); np.fill_diagonal(B, 0)
    r = B.sum(1); C = B - r[:, None] / (n - 2) - r[None, :] / (n - 2) + B.sum() / ((n - 1) * (n - 2)); np.fill_diagonal(C, 0); return C
def dcor_szekely(x, y):
    A, B = dc(dist(x)), dc(dist(y)); V2 = (A * B).mean(); return np.sqrt(V2 / np.sqrt((A * A).mean() * (B * B).mean()))
def bcdcor(x, y):
    A, B = uc(dist(x)), uc(dist(y)); n = len(x)
    f = lambda P, Q: (P * Q).sum() / (n * (n - 3)); return f(A, B) / np.sqrt(f(A, A) * f(B, B))

print("== dcorr probe1 replication (seed 0, n=200) ==")
rng = np.random.default_rng(0)
n = 200
x = rng.standard_normal(n); y = 0.6 * x + 0.8 * rng.standard_normal(n)
X, Y = x[:, None], y[:, None]
hb = Dcorr(bias=True).statistic(X, Y); hu = Dcorr(bias=False).statistic(X, Y)
print("hyppo biased", repr(hb), "szekely dCor", repr(dcor_szekely(x, y)), "dCor^2", dcor_szekely(x, y) ** 2)
print("hyppo unbiased", repr(hu), "bcdcor", repr(bcdcor(x, y)))
vals = np.array([Dcorr().statistic(rng.standard_normal((64, 1)), rng.standard_normal((64, 1))) for _ in range(200)])
print("unbiased dcorr iid T=64: frac<0", vals.mean() if False else (vals < 0).mean(), "min", vals.min())
valsb = np.array([Dcorr(bias=True).statistic(rng.standard_normal((64, 1)), rng.standard_normal((64, 1))) for _ in range(200)])
print("biased dcorr iid T=64: mean", valsb.mean(), "min", valsb.min())
dd = Dcorr(); dd.statistic(X, Y); print("is_fast after statistic:", dd.is_fast)
for b in (False, True):
    s = D(biased=b); print(s.identifier, repr(s.bivariate(x, y)), repr(s.bivariate(y, x)))

print("\n== dcor package available in project venv? ==")
try:
    import dcor
    print("dcor", dcor.__version__, "u_dcor_sqr", dcor.u_distance_correlation_sqr(x, y), "dcor", dcor.distance_correlation(x, y))
except Exception as e:
    print("dcor not importable in project venv:", type(e).__name__, e)

print("\n== hsic probe2 replication (seed 1, n=150) ==")
rng = np.random.default_rng(1)
def sq(x): return (x[:, None] - x[None, :]) ** 2
def gram(x, sigma): return np.exp(-sq(x) / (2 * sigma ** 2))
def med(x):
    d = np.sqrt(sq(x)); iu = np.triu_indices(len(x), 1); return np.median(d[iu])
def hsic_b(K, L): n = len(K); return np.sum(dc(K) * dc(L)) / n ** 2
def hsic_u_song(K, L):
    n = len(K); K = K.copy(); L = L.copy(); np.fill_diagonal(K, 0); np.fill_diagonal(L, 0); o = np.ones(n)
    return (np.trace(K @ L) + (o @ K @ o) * (o @ L @ o) / ((n - 1) * (n - 2)) - 2 / (n - 2) * (o @ K @ L @ o)) / (n * (n - 3))
n = 150
x = rng.standard_normal(n); y = np.exp(x) + 0.3 * rng.standard_normal(n)
sx = med(x); sy = med(y)
K = gram(x, sx); Lx = gram(y, sx); Ly = gram(y, sy)
nb = lambda K, L: hsic_b(K, L) / np.sqrt(hsic_b(K, K) * hsic_b(L, L))
nu = lambda K, L: hsic_u_song(K, L) / np.sqrt(hsic_u_song(K, K) * hsic_u_song(L, L))
X, Y = x[:, None], y[:, None]
# check hyppo's median = our median (off-diagonal, both triangles)
from hyppo.tools import compute_kern
from sklearn.metrics import pairwise_distances
l2 = pairwise_distances(X, metric="l2"); nn = l2.shape[0]
medh = np.median(np.lib.stride_tricks.as_strided(l2, (nn - 1, nn + 1), (l2.itemsize * (nn + 1), l2.itemsize))[:, 1:])
print("median x: mine", sx, "hyppo-style", medh, "| median y", sy)
kx, ky = compute_kern(X, Y, metric="gaussian")
print("hyppo kern x matches gram(x,sx):", np.abs(kx - K).max(), " kern y matches gram(y,sx):", np.abs(ky - Lx).max(), " vs gram(y,sy):", np.abs(ky - Ly).max(), " max K", kx.max())
print("hyppo biased(x,y)", repr(Hsic(bias=True).statistic(X, Y)), " sqrt(nHSIC_b) shared sigma_x", repr(np.sqrt(nb(K, Lx))), " own sigmas", np.sqrt(nb(K, Ly)), " raw HSIC_b", hsic_b(K, Lx))
print("hyppo unbiased(x,y)", repr(Hsic(bias=False).statistic(X, Y)), " nHSIC_u shared", repr(nu(K, Lx)), " own sigmas", nu(K, Ly), " raw HSIC_u", hsic_u_song(K, Lx))
print("hyppo biased(y,x)", Hsic(bias=True).statistic(Y, X), " unbiased(y,x)", Hsic(bias=False).statistic(Y, X))
v = np.array([Hsic().statistic(rng.standard_normal((64, 1)), rng.standard_normal((64, 1))) for _ in range(200)])
print("unbiased hsic iid T=64 frac<0", (v < 0).mean(), "min", v.min())

print("\n== probe3 replication: order dependence through pyspi (seed 1 continued) ==")
x0 = rng.uniform(-1, 1, 256); x1 = x0 ** 2 + 0.05 * rng.standard_normal(256); x2 = rng.standard_normal(256)
d = mk(np.vstack([x0, x1, x2]), dim_order='ps')
np.set_printoptions(precision=6)
for cls in (H, D):
    for b in (False, True):
        s = cls(biased=b); A = s.multivariate(d)
        print(s.identifier, "A[0,1]=%.10f A[1,0]=%.10f biv(0,1)=%.10f biv(1,0)=%.10f" % (A[0, 1], A[1, 0], s.bivariate(d, i=0, j=1), s.bivariate(d, i=1, j=0)), "sym", np.nanmax(np.abs(A - A.T)))

print("\n== probe4 replication: normalise=False rescale y ==")
rng = np.random.default_rng(2)
x = rng.standard_normal(256); y = np.tanh(2 * x) + 0.3 * rng.standard_normal(256)
for scale in (1.0, 10.0, 0.1):
    d = mk(np.vstack([x, scale * y]), dim_order='ps', normalise=False)
    out = []
    for cls in (H, D):
        for b in (False, True):
            s = cls(biased=b); out.append((s.identifier, round(float(s.multivariate(d)[0, 1]), 4)))
    print(scale, out)

print("\n== independent check: U-centring of (J - I) is exactly zero; of J is not ==")
n = 10
J = np.ones((n, n)); print("U(J-I) max abs:", np.abs(uc(J - np.eye(n))).max(), " U(J) off-diag value:", uc(J)[0, 1], "(-1/(n-1) =", -1 / (n - 1), ")")

print("\n== sigma convention check: gamma = 1/(2 med^2) -> k = exp(-|x-y|^2/(2 med^2)) ==")
print("rbf with gamma:", np.exp(-1.0 / (2 * sx ** 2)), "gram(sigma=sx) for |x-y|=1:", np.exp(-1 / (2 * sx ** 2)))

print("\n== population dCor^2 closed form sanity ==")
R2 = lambda r: (r * np.arcsin(r) + np.sqrt(1 - r * r) - r * np.arcsin(r / 2) - np.sqrt(4 - r * r) + 1) / (1 + np.pi / 3 - np.sqrt(3))
print("R2(1)=", R2(1.0), "R2(0.3)=", R2(0.3), "R2(0.8)=", R2(0.8))
# Monte Carlo unbiased dcor at large n to check 0.5699 for rho=0.8
rng = np.random.default_rng(11)
vals = []
for _ in range(20):
    xx = rng.standard_normal(2000); yy = 0.8 * xx + 0.6 * rng.standard_normal(2000)
    vals.append(Dcorr().statistic(xx[:, None], yy[:, None]))
print("MC unbiased dcorr rho=0.8 n=2000 x20: mean", np.mean(vals), "sd", np.std(vals))
