import warnings, io, contextlib, sys
import numpy as np
from scipy import stats
from pyspi.statistics.basic import SpearmanR, KendallTau
from pyspi.data import Data

B = '/media/dan/Data/git/pyspi/audit/checks/data/'
def mk(X, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(X, **kw)

# --- A1: labels in a FRESH interpreter (record quotes both signed+unsigned) ---
print("A1 fresh SpearmanR().labels =", SpearmanR().labels)
print("A1 fresh KendallTau().labels =", KendallTau().labels)
print("A1 after squared=True too:", SpearmanR(squared=True).labels, "-> fresh again:", SpearmanR().labels)

# --- A2: independent scratch implementations ---
def avg_rank(v):
    v = np.asarray(v); n = len(v)
    order = np.argsort(v, kind='stable'); sv = v[order]; r = np.empty(n)
    i = 0
    while i < n:
        j = i
        while j + 1 < n and sv[j+1] == sv[i]: j += 1
        r[order[i:j+1]] = (i + j) / 2 + 1; i = j + 1
    return r
def spearman_scratch(x, y):
    rx, ry = avg_rank(x) - (len(x)+1)/2, avg_rank(y) - (len(y)+1)/2
    return (rx @ ry) / np.sqrt((rx @ rx) * (ry @ ry))
def tau_scratch(x, y):
    x = np.asarray(x); y = np.asarray(y); n = len(x)
    sx = np.sign(x[:, None] - x[None, :]); sy = np.sign(y[:, None] - y[None, :])
    iu = np.triu_indices(n, 1)
    S = (sx[iu] * sy[iu]).sum()
    n0 = n * (n - 1) / 2
    n1 = (sx[iu] == 0).sum(); n2 = (sy[iu] == 0).sum()
    return S / np.sqrt((n0 - n1) * (n0 - n2)), S / n0

rng = np.random.default_rng(0)
x = rng.standard_normal(50); y = 0.6 * x + rng.standard_normal(50)
s = SpearmanR(); k = KendallTau()
print("A2 continuous: spearman pyspi %r scratch %r" % (s.bivariate(x, y), spearman_scratch(x, y)))
tb, ta = tau_scratch(x, y)
print("A2 continuous: kendall pyspi %r tau_b %r tau_a %r" % (k.bivariate(x, y), tb, ta))
xt, yt = np.round(x, 0), np.round(y, 0)
tb, ta = tau_scratch(xt, yt)
print("A2 tied: spearman pyspi %r scratch %r" % (s.bivariate(xt, yt), spearman_scratch(xt, yt)))
print("A2 tied: kendall pyspi %r tau_b %r tau_a %r" % (k.bivariate(xt, yt), tb, ta))
print("A2 no-ties shortcut 1-6sum d^2/(n(n^2-1)) on tied:", 1 - 6 * ((avg_rank(xt) - avg_rank(yt))**2).sum() / (50 * (50**2 - 1)))

# --- A3: tau-b reciprocity 1 ulp ---
rng = np.random.default_rng(3); nk = 0; maxk = 0; ns = 0
for t in range(2000):
    n = rng.integers(20, 400)
    xx = np.round(rng.standard_normal(n) * rng.uniform(1, 5)); yy = np.round(xx * 0.5 + rng.standard_normal(n) * 2)
    a = stats.kendalltau(xx, yy).correlation; b = stats.kendalltau(yy, xx).correlation
    if a != b: nk += 1; maxk = max(maxk, abs(a - b))
    xs = rng.standard_normal(n); ys = xs + rng.standard_normal(n)
    if stats.spearmanr(xs, ys).correlation != stats.spearmanr(ys, xs).correlation: ns += 1
print("A3 kendall tied reciprocal mismatches", nk, "max", maxk, "| spearman mismatches", ns)
# also check spearman on TIED data reciprocity (they only tested continuous)
nst = 0; rng = np.random.default_rng(5)
for t in range(2000):
    n = rng.integers(20, 400)
    xx = np.round(rng.standard_normal(n) * 3); yy = np.round(xx * 0.5 + rng.standard_normal(n) * 2)
    if stats.spearmanr(xx, yy).correlation != stats.spearmanr(yy, xx).correlation: nst += 1
print("A3 spearman TIED reciprocal mismatches", nst, "of 2000")

# --- A4: call count P=4 ---
X = np.load(B + 'bivariate_gaussian_T256.npz')['x']
for cls in (SpearmanR, KendallTau):
    calls = []; orig = cls.bivariate
    def counting(self, data, i=None, j=None, _o=orig, **kw):
        calls.append((i, j)); return _o(self, data, i=i, j=j, **kw)
    cls.bivariate = counting
    A = cls().multivariate(mk(X))
    cls.bivariate = orig
    print("A4", cls.__name__, "n calls", len(calls), "P", X.shape[0], "sym", np.array_equal(np.nan_to_num(A), np.nan_to_num(A.T)), "first calls", calls[:4])

# --- A5: detrend effect on trending_T1024 ---
T4 = np.load(B + 'trending_T1024.npz')['x']
for norm, det in [(True, False), (False, False), (True, True)]:
    D = mk(T4, normalise=norm, detrend=det)
    A = SpearmanR().multivariate(D)
    print(f"A5 n{int(norm)}d{int(det)} spearman (0,1) {A[0,1]:.6f} (2,3) {A[2,3]:.6f}")

# --- A6: R>1 hypothesis ---
R = rng.standard_normal((3, 40, 2))
D = mk(R, dim_order='psr')
xr, yr = D.to_numpy()[[0, 1]]
print("A6 R=2 slice shapes", xr.shape, yr.shape)
res = stats.spearmanr(xr, yr)
print("A6 spearmanr(.correlation) type/shape:", type(res.correlation), np.shape(res.correlation))
try:
    A = SpearmanR().multivariate(D); print("A6 SpearmanR.multivariate on R=2 ->", A.shape)
except Exception as e:
    print("A6 SpearmanR.multivariate on R=2 -> %s: %s" % (type(e).__name__, str(e)[:80]))
try:
    A = KendallTau().multivariate(D); print("A6 KendallTau.multivariate on R=2 -> ok", A.shape, "value", A[0,1], "vs ravel", stats.kendalltau(xr.ravel(), yr.ravel()).correlation)
except Exception as e:
    print("A6 KendallTau.multivariate on R=2 -> %s: %s" % (type(e).__name__, str(e)[:80]))

# --- A7: parse_bivariate raw arrays ---
rng = np.random.default_rng(0); x = rng.standard_normal(30) * 5 + 3; y = rng.standard_normal(30) * 5 + 3
with contextlib.redirect_stdout(io.StringIO()):
    d = Data(); d.add_process(x); d.add_process(y)
a = d.to_numpy()
print("A7 row0 mean/std", a[0].mean().round(6), a[0].std(ddof=1).round(6), "row1 mean/std", a[1].mean().round(3), a[1].std(ddof=1).round(3))

# --- A8: constant channel path: does Data reject before scipy? ---
C = np.vstack([rng.standard_normal(30), np.full(30, 2.0)])
try:
    mk(C); print("A8 const channel accepted?!")
except ValueError as e:
    print("A8 const channel -> ValueError:", str(e)[:70])
