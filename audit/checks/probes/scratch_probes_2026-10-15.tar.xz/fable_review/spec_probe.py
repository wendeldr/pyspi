import sys, warnings, io, contextlib, math
import numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
import make_data as md
from pyspi.data import Data
from pyspi.statistics.spectral import (CoherenceMagnitude, CoherencePhase, ImaginaryCoherence,
    PhaseSlopeIndex, GroupDelay, DirectedCoherence, NonparametricSpectralMultivariate)
from pyspi._spectral_compat import spectral_connectivity as sc
import spectral_connectivity.connectivity as scc
import spectral_connectivity.transforms as sct
from scipy.signal.windows import dpss
from scipy.fftpack import next_fast_len
warnings.simplefilter('ignore')
np.set_printoptions(precision=10, linewidth=160)

def X(name, T): return md.load(name, T)['x']
def D(x, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, dim_order='ps', **kw)
def mv(cls, data, **kw):
    return cls(**kw).multivariate(data)
def off(A): return A[~np.eye(A.shape[0], dtype=bool)]

print("=== A. grid, n_fft, tapers ===")
rng = np.random.default_rng(0)
for T in [63, 64, 67, 256, 1009, 1024, 4096]:
    m = sc.Multitaper(rng.standard_normal((T, 2)), sampling_frequency=1)
    conn = sc.Connectivity.from_multitaper(m)
    f = conn.frequencies
    tap, ev = sct.dpss_windows(T, 3, 5, is_low_bias=False)
    print(f'  T={T}: n_fft={m.n_fft_samples} nbins={len(f)} first={f[:2]} last={f[-1]} n_tapers_kept={m.tapers.shape[1]} eig={np.round(ev,5)} n_obs={conn.n_observations}')

print("=== B. CSM vs from-scratch (scipy dpss + numpy fft), T=256 iid; Im S(0); Hermitian ===")
x = X('iid_gaussian', 256); T = x.shape[1]
m = sc.Multitaper(x.T, sampling_frequency=1); conn = sc.Connectivity.from_multitaper(m)
S_lib = conn._expectation_cross_spectral_matrix()[0]          # (n_fft, P, P)
xc = x - x.mean(axis=1, keepdims=True)
tp, rat = dpss(T, 3, Kmax=5, return_ratios=True)
Xf = np.fft.fft(tp[:, None, :] * xc[None, :, :], n=next_fast_len(T), axis=-1)  # (5, P, nfft)
S_ref = np.mean(Xf[:, :, None, :] * np.conj(Xf[:, None, :, :]), axis=0).transpose(2, 0, 1)
print('  max|S_lib - S_ref| =', np.abs(S_lib - S_ref).max(), '; max|Im S(0)| =', np.abs(S_lib[0].imag).max(), '; Hermitian resid', np.abs(S_lib - np.conj(np.swapaxes(S_lib, -1, -2))).max())
print('  scipy dpss ratios', rat, '| lib tapers vs scipy max|diff| (sign-matched)', max(min(np.abs(m.tapers[:, k] - tp[k]).max(), np.abs(m.tapers[:, k] + tp[k]).max()) for k in range(5)))

print("=== C. direction convention: delayed_noise T1024 phase slope of S[0,j] ===")
x = X('delayed_noise', 1024)
m = sc.Multitaper(x.T, sampling_frequency=1); conn = sc.Connectivity.from_multitaper(m)
S = conn._expectation_cross_spectral_matrix()[0]; f = conn.frequencies
sel = (f > 0) & (f < 0.1)
for j in [1, 2, 3]:
    ph = np.unwrap(np.angle(S[:len(f)][sel, 0, j]))
    print(f'  S[0,{j}] slope/2pi = {np.polyfit(f[sel], ph, 1)[0]/(2*np.pi):+.4f}  (delay {md.load("delayed_noise",1024)["delay"][j]})')
mb = sc.Multitaper(x[[2, 0]].T, sampling_frequency=1); cb = sc.Connectivity.from_multitaper(mb)
Sb = cb._expectation_cross_spectral_matrix()[0]
print('  max|S_mv[2,0] - S_bv(i=2,j=0)[0,1]| =', np.abs(S[:, 2, 0] - Sb[:, 0, 1]).max())

print("=== D. MRO and symmetry ===")
print('  MRO:', [k.__name__ for k in CoherenceMagnitude.__mro__][:7])
for name in ['iid_gaussian', 'delayed_noise', 'var2_chain']:
    d = D(X(name, 256))
    for cls in [CoherenceMagnitude, ImaginaryCoherence, CoherencePhase]:
        A = mv(cls, d); print(f'  {name} {cls.__name__}: max|A-A^T| = {np.nanmax(np.abs(A - A.T)):.3e}', end=';')
    print()

print("=== E. cohmag squared: bivariate_gaussian T4096 ===")
d = D(X('bivariate_gaussian', 4096)); A = mv(CoherenceMagnitude, d)
conn = sc.Connectivity.from_multitaper(sc.Multitaper(d.to_numpy(squeeze=True).T, sampling_frequency=1))
C = conn.coherency()[0]; f = conn.frequencies
print('  pyspi cohmag mean full (0,1),(2,3):', A[0,1], A[2,3], '| mean|C|^2:', np.mean(np.abs(C[:,0,1])**2), np.mean(np.abs(C[:,2,3])**2), '| mean|C|:', np.mean(np.abs(C[:,0,1])), np.mean(np.abs(C[:,2,3])))

print("=== F. null levels iid (mean over off-diagonal) ===")
for T in [64, 256, 1024, 4096]:
    d = D(X('iid_gaussian', T))
    cm = mv(CoherenceMagnitude, d); cx = mv(CoherenceMagnitude, d, statistic='max'); ic = mv(ImaginaryCoherence, d)
    print(f'  T={T}: cohmag mean {off(cm).mean():.4f} cohmag max {off(cx).mean():.4f} icoh mean {off(ic).mean():.4f}')

print("=== G. var2_bivariate T4096 full band vs population ===")
g = md.load('var2_bivariate', 4096); d = D(g['x'])
A = mv(CoherenceMagnitude, d); Ai = mv(ImaginaryCoherence, d)
St = g['S_true']; ft = g['freqs']
print('  S_true shape', St.shape, 'freqs', ft.shape)
# S_true indexed (freq, P, P)?
if St.shape[0] == len(ft): Sf = St
else: Sf = np.moveaxis(St, -1, 0)
g2 = np.abs(Sf[:,0,1])**2/(Sf[:,0,0].real*Sf[:,1,1].real)
imc = np.abs(Sf[:,0,1].imag)/np.sqrt(Sf[:,0,0].real*Sf[:,1,1].real)
conn = sc.Connectivity.from_multitaper(sc.Multitaper(d.to_numpy(squeeze=True).T, sampling_frequency=1)); f = conn.frequencies
print('  pyspi cohmag full', A[0,1], '| population band mean gamma^2 on grid', np.interp(f, ft, g2).mean(), '| + Carter (1-g2)^2/5', np.interp(f, ft, g2 + (1-g2)**2/5).mean())
print('  pyspi icoh full', Ai[0,1], '| population mean |Im C|', np.interp(f, ft, imc).mean())

print("=== H. bin counts inclusive / strict and 0.25 bin ===")
for T in [64, 256, 1024, 4096]:
    f = sc.Connectivity.from_multitaper(sc.Multitaper(np.zeros((T, 2)), sampling_frequency=1)).frequencies
    out = []
    for lo, hi in [(0, 0.5), (0, 0.25), (0.25, 0.5)]:
        inc = ((f >= lo) & (f <= hi)).sum(); st = ((f > lo) & (f < hi)).sum()
        step = int(math.ceil((hi - lo)/50 / (f[1]-f[0]))); npsi = len(range(0, st, step))
        out.append(f'{inc}/{st}/psi{npsi}(step{step})')
    print(f'  T={T}: full,low,high = {out}; 0.25 on grid: {np.any(f == 0.25)}')

print("=== I. narrowband_f0-0.25 T1024 double count identity ===")
d = D(X('narrowband_f0-0.25', 1024))
mf = mv(CoherenceMagnitude, d); ml = mv(CoherenceMagnitude, d, fmin=0, fmax=0.25); mh = mv(CoherenceMagnitude, d, fmin=0.25, fmax=0.5)
conn = sc.Connectivity.from_multitaper(sc.Multitaper(d.to_numpy(squeeze=True).T, sampling_frequency=1)); f = conn.frequencies
msc = np.abs(conn.coherency()[0])**2
k = int(np.where(f == 0.25)[0][0])
print('  257*low + 256*high - 512*full (0,1) =', 257*ml[0,1] + 256*mh[0,1] - 512*mf[0,1], '| MSC(0.25) =', msc[k, 0, 1])

print("=== J. EEG narrow bands (exact k/1024 edges) on 3 iid channels ===")
x3 = X('iid_gaussian', 1024)[:3]
for T in [1024, 512]:
    d = D(x3[:, :T])
    for lo, hi in [(0.5/1024, 2/1024), (2/1024, 4/1024), (4/1024, 6/1024)]:
        f = sc.Connectivity.from_multitaper(sc.Multitaper(np.zeros((T, 2)), sampling_frequency=1)).frequencies
        inc = ((f >= lo) & (f <= hi)).sum(); st = ((f > lo) & (f < hi)).sum()
        res = {}
        for lab, cls in [('cohmag', CoherenceMagnitude), ('psi', PhaseSlopeIndex), ('gd', GroupDelay), ('dcoh', DirectedCoherence)]:
            try:
                kw = dict(fmin=lo, fmax=hi) if lab != 'gd' else dict(fmin=lo, fmax=hi, statistic='delay')
                A = cls(**kw).multivariate(d)
                res[lab] = 'allNaN' if np.all(np.isnan(off(A))) else f'{off(A)[0]:.3g}'
            except Exception as e:
                res[lab] = f'EXC {type(e).__name__}'
        print(f'  T={T} band {lo*1024:g}-{hi*1024:g}/1024: inc {inc} strict {st} -> {res}')

print("=== K. PSI/GD kwargs spy ===")
d = D(X('iid_gaussian', 256))
orig_psi = scc.Connectivity.phase_slope_index; orig_gd = scc.Connectivity.group_delay
def spy_psi(self, *a, **k):
    try:
        r = orig_psi(self, *a, **k); print('   psi call kwargs', k, '-> ok'); return r
    except Exception as e: print('   psi call kwargs', k, '-> raises', type(e).__name__, str(e)[:50]); raise
def spy_gd(self, *a, **k):
    try:
        r = orig_gd(self, *a, **k); print('   gd call kwargs', k, '-> ok'); return r
    except Exception as e: print('   gd call kwargs', k, '-> raises', type(e).__name__, str(e)[:50]); raise
scc.Connectivity.phase_slope_index = spy_psi; scc.Connectivity.group_delay = spy_gd
p_full = mv(PhaseSlopeIndex, d); p_low = mv(PhaseSlopeIndex, d, fmin=0, fmax=0.25)
gdv = mv(GroupDelay, d, statistic='delay')
scc.Connectivity.phase_slope_index = orig_psi; scc.Connectivity.group_delay = orig_gd
print('  psi full vs low differ?', not np.allclose(off(p_full), off(p_low)))

print("=== L. empty band ===")
d = D(X('iid_gaussian', 64))
A = mv(CoherenceMagnitude, d, fmin=1/2048, fmax=4/2048); print('  mean: all NaN?', np.all(np.isnan(A)))
try:
    mv(CoherenceMagnitude, d, fmin=1/2048, fmax=4/2048, statistic='max'); print('  max: no error')
except Exception as e: print('  max raises', type(e).__name__, str(e)[:70])

print("=== M. phase direction & identities ===")
d = D(X('delayed_noise', 1024))
A = mv(CoherencePhase, d, fmin=0, fmax=0.25); print('  delayed_noise low band A[0,1]', A[0,1], 'A[1,0]', A[1,0])
f = sc.Connectivity.from_multitaper(sc.Multitaper(np.zeros((1024, 2)), sampling_frequency=1)).frequencies
print('  analytic mean(-2 pi f) over inclusive low band:', np.mean(-2*np.pi*f[(f>=0)&(f<=0.25)]))
Af = mv(CoherencePhase, d)
conn = sc.Connectivity.from_multitaper(sc.Multitaper(d.to_numpy(squeeze=True).T, sampling_frequency=1)); C = conn.coherency()[0]
print('  pair (3,0) full band arithmetic mean', Af[3,0], '| circular mean arg(sum C/|C|)', np.angle(np.sum(C[:,3,0]/np.abs(C[:,3,0]))))
d = D(X('narrowband_f0-0.1', 1024)); A = mv(CoherencePhase, d, fmin=0.095, fmax=0.105)
print('  narrowband band [0.095,0.105]: A[1,0]', A[1,0], 'A[0,2]', A[0,2], '(phases 0, +pi/4, -pi/2)')
for name in ['iid_gaussian', 'var2_bivariate']:
    d = D(X(name, 256)); A = mv(CoherencePhase, d, statistic='max')
    print(f'  {name} T256 phase max full band: range [{np.nanmin(off(A)):.3f}, {np.nanmax(off(A)):.3f}] max|A+A^T| {np.nanmax(np.abs(A+A.T)):.3f}')
d = D(X('iid_gaussian', 64)); A = mv(CoherencePhase, d, fmin=0, fmax=0.25)
print('  iid T64 low band A+A^T upper:', np.round((A + A.T)[np.triu_indices(5, 1)], 6), '| 2pi/17 =', 2*np.pi/17)
for T in [256, 1024, 4096]:
    g = md.load('var2_bivariate', T); d = D(g['x']); A = mv(CoherencePhase, d, fmin=0.25, fmax=0.5)
    St = g['S_true']; ft = g['freqs']; Sf = St if St.shape[0] == len(ft) else np.moveaxis(St, -1, 0)
    f = sc.Connectivity.from_multitaper(sc.Multitaper(np.zeros((T, 2)), sampling_frequency=1)).frequencies
    sel = (f >= 0.25) & (f <= 0.5)
    pop = np.angle(np.interp(f[sel], ft, Sf[:,0,1].real) + 1j*np.interp(f[sel], ft, Sf[:,0,1].imag)).mean()
    print(f'  var2 T{T} high band phase mean A[0,1] {A[0,1]:+.4f} A[1,0] {A[1,0]:+.4f} | population arithmetic mean arg S01 {pop:+.4f}')

print("=== N. icoh abs and DC ===")
d = D(X('delayed_noise', 1024)); A = mv(ImaginaryCoherence, d)
conn = sc.Connectivity.from_multitaper(sc.Multitaper(d.to_numpy(squeeze=True).T, sampling_frequency=1)); C = conn.coherency()[0]
print('  delayed_noise T1024 full: A[0,1]', A[0,1], 'A[1,0]', A[1,0], '| signed mean Im C_01', C[:,0,1].imag.mean(), 'Im C_10', C[:,1,0].imag.mean())
print('  pair (0,3): pyspi', A[0,3], '| |mean Im C_03|', abs(C[:,0,3].imag.mean()), '| mean |Im C_03|', np.abs(C[:,0,3].imag).mean())
print('  max|Im C(DC)|', np.abs(C[0].imag)[~np.eye(4,dtype=bool)].max())
g = md.load('var2_bivariate', 256); d = D(g['x']); A = mv(ImaginaryCoherence, d, fmin=0, fmax=0.25)
conn = sc.Connectivity.from_multitaper(sc.Multitaper(d.to_numpy(squeeze=True).T, sampling_frequency=1)); f = conn.frequencies
ic = conn.imaginary_coherence()[0]; sel = (f >= 0) & (f <= 0.25)
print('  var2 T256 low band pyspi', repr(A[0,1]), '| mean excl DC * 64/65 =', repr(ic[sel][1:,0,1].mean()*64/65), 'n bins', sel.sum())

print("=== O. shared_envelope, scaled_offset invariance, trending ===")
d = D(X('shared_envelope', 1024))
print('  shared_envelope cohmag mean A[0,2]', repr(mv(CoherenceMagnitude, d)[0,2]), 'max', repr(mv(CoherenceMagnitude, d, statistic='max')[0,2]), 'icoh', repr(mv(ImaginaryCoherence, d)[0,2]), 'phase', repr(mv(CoherencePhase, d)[0,2]))
d1 = D(X('scaled_offset', 1024), normalise=False); d2 = D(X('bivariate_gaussian', 1024))
print('  scaled_offset(normalise=False) vs bivariate_gaussian cohmag max|diff|', np.nanmax(np.abs(mv(CoherenceMagnitude, d1) - mv(CoherenceMagnitude, d2))))
dt0 = D(X('trending', 1024)); dt1 = D(X('trending', 1024), detrend=True); db = D(X('bivariate_gaussian', 1024))
print('  trending low band A[1,3]: no detrend', mv(CoherenceMagnitude, dt0, fmin=0, fmax=0.25)[1,3], 'detrend', mv(CoherenceMagnitude, dt1, fmin=0, fmax=0.25)[1,3], 'untrended', mv(CoherenceMagnitude, db, fmin=0, fmax=0.25)[1,3])

print("=== P. Calculator equals direct multivariate ===")
R = '/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/fable_review'
open(R + '/cfg.yaml', 'w').write('.statistics.spectral:\n  CoherenceMagnitude:\n    labels: [undirected]\n    dependencies:\n    configs:\n      - fs: 1\n  ImaginaryCoherence:\n    labels: [undirected]\n    dependencies:\n    configs:\n      - fmin: 0\n        fmax: 0.25\n')
from pyspi.calculator import Calculator
x = X('var2_chain', 256)
with contextlib.redirect_stdout(io.StringIO()):
    calc = Calculator(dataset=x, configfile=R + '/cfg.yaml'); calc.compute()
d = D(x)
for spi in calc.spis:
    tab = calc.table[spi].to_numpy()
    direct = calc.spis[spi].multivariate(d)
    print(f'  {spi}: max|Calculator - direct| = {np.nanmax(np.abs(tab - direct))}')
