"""Fable independent probe for barycenter claims."""
import io, contextlib, warnings, sys
import numpy as np
warnings.simplefilter("always")
from pyspi.data import Data
from pyspi.statistics.distance import Barycenter
from tslearn.barycenters import euclidean_barycenter, dtw_barycenter_averaging, dtw_barycenter_averaging_subgradient, softdtw_barycenter
from tslearn.metrics import dtw, soft_dtw
D = '/media/dan/Data/git/pyspi/audit/checks/data/'
def load(name, rows=None):
    x = np.load(D + name + '.npz')['x']
    if rows is not None: x = x[rows]
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, dim_order='ps')

# ---- euclidean claims ----
d = load('bivariate_gaussian_T256'); z = d.to_numpy(squeeze=True); P, T = z.shape
A_mean = Barycenter(mode='euclidean', statistic='mean').multivariate(d)
A_sq = Barycenter(mode='euclidean', statistic='mean', squared=True).multivariate(d)
off = ~np.eye(P, dtype=bool)
print("bary_euclidean_mean off-diag range:", A_mean[off].min(), A_mean[off].max())
r = np.corrcoef(np.load(D + 'bivariate_gaussian_T256.npz')['x'])
formula = (1 + r) * (T - 1) / (2 * T)
print("bary-sq_euclidean_mean max |A - (1+r)(T-1)/(2T)|:", np.nanmax(np.abs(A_sq - formula)[off]))
b = Barycenter(mode='euclidean', statistic='max_time')
print("labels:", b.labels, "issigned:", b.issigned(), "max_time value/type:", b.bivariate(d, i=0, j=1), type(b.bivariate(d, i=0, j=1)))
print("Barycenter MRO:", [c.__name__ for c in Barycenter.__mro__][:4])
# symmetry/cache order
with contextlib.redirect_stdout(io.StringIO()):
    d3 = Data(z[:3].copy(), dim_order='ps')
A = Barycenter(mode='euclidean', statistic='max').multivariate(d3)
print("cache keys insertion order:", list(d3.barycenter['euclidean'].keys()), "A==A.T:", np.array_equal(A, A.T, equal_nan=True))
# which order was used? check by computing from z[[1,0]] vs z[[0,1]] with a non-symmetric mode (sgddtw seeded) later.

# ---- DBA stall at init on narrowband_f0-0.25 pair (1,0) ----
for TT in (64, 256, 1024):
    dn = load(f'narrowband_f0-0.25_T{TT}'); zn = dn.to_numpy(squeeze=True)
    X = zn[[1, 0]]
    init = X.mean(axis=0)[:, None]
    cost_init = sum(dtw(init, X[k]) ** 2 for k in range(2))
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        bc = dtw_barycenter_averaging(X, verbose=False)
    cost_bc = sum(dtw(bc, X[k]) ** 2 for k in range(2))
    print(f"narrowband T={TT}: cost_init={cost_init:.4f} cost_dba={cost_bc:.4f} max|bc-init|={np.abs(bc.ravel()-init.ravel()).max():.2e}")
# bary_dtw_mean magnitude on a few datasets
for name in ['bivariate_gaussian_T256', 'delayed_noise_T256', 'narrowband_f0-0.25_T256']:
    dd = load(name); A = Barycenter(mode='dtw', statistic='mean').multivariate(dd)
    print(f"bary_dtw_mean {name}: max|A|={np.nanmax(np.abs(A)):.4f}")

# ---- sgddtw: under-convergence relative to DBA; stopping rule; RNG ----
import tslearn.barycenters.dba as dbamod
from sklearn.utils import check_random_state
rs = check_random_state(None)
print("check_random_state(None) is np.random.mtrand._rand:", rs is np.random.mtrand._rand)
for name, rows in [('bivariate_gaussian_T256', [1, 0]), ('delayed_noise_T1024', [1, 0])]:
    dd = load(name); zz = dd.to_numpy(squeeze=True); X = zz[rows]
    def F(b): return sum(dtw(b, X[k]) ** 2 for k in range(2))
    np.random.seed(0)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        b_ssg = dtw_barycenter_averaging_subgradient(X)
    conv = [str(x.category.__name__) for x in w]
    b_dba = dtw_barycenter_averaging(X)
    b_eu = X.mean(axis=0)[:, None]
    print(f"{name} rows {rows}: F(ssg)={F(b_ssg):.2f} F(dba)={F(b_dba):.2f} F(euclid-init)={F(b_eu):.2f} warnings={conv}")
# unseeded repeat changes value? seeded swapped inputs change barycenter?
dd = load('bivariate_gaussian_T256'); zz = dd.to_numpy(squeeze=True); X = zz[[1, 0]]
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    vals = []
    for k in range(3):
        vals.append(np.nanmean(dtw_barycenter_averaging_subgradient(X)))
    print("unseeded sgddtw mean statistic repeats:", vals, "spread", max(vals) - min(vals))
    np.random.seed(0); b1 = dtw_barycenter_averaging_subgradient(X)
    np.random.seed(0); b2 = dtw_barycenter_averaging_subgradient(X[::-1])
    print("seed0 swapped-input max|b1-b2| =", np.abs(b1 - b2).max())
    np.random.seed(0); b1b = dtw_barycenter_averaging_subgradient(X)
    print("seed0 same-input repeat max|b1-b1b| =", np.abs(b1 - b1b).max())
# does the max SPI consume RNG after mean SPI cached?
with contextlib.redirect_stdout(io.StringIO()):
    d4 = Data(zz.copy(), dim_order='ps')
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    np.random.seed(1)
    Am = Barycenter(mode='sgddtw', statistic='mean').multivariate(d4)
    st0 = np.random.get_state()
    Ax = Barycenter(mode='sgddtw', statistic='max').multivariate(d4)
    st1 = np.random.get_state()
print("after mean SPI: cached pairs:", len(d4.barycenter['sgddtw']), "; max SPI changed RNG state:", not ((st0[1] == st1[1]).all() and st0[2] == st1[2]), "; sgddtw A==A.T:", np.array_equal(Am, Am.T, equal_nan=True))

# ---- softdtw barycenter of (x,x) ----
dd = load('bivariate_gaussian_T256'); zz = dd.to_numpy(squeeze=True); x = zz[0]
Xxx = np.stack([x, x])
b_sd = softdtw_barycenter(Xxx).ravel()
b_db = dtw_barycenter_averaging(Xxx).ravel()
with warnings.catch_warnings():
    warnings.simplefilter("ignore"); np.random.seed(0); b_sg = dtw_barycenter_averaging_subgradient(Xxx).ravel()
print(f"softdtw bary(x,x): max|b-x|={np.abs(b_sd - x).max():.3f} var(b)={b_sd.var(ddof=1):.3f} var(x)={x.var(ddof=1):.3f}; DBA max|b-x|={np.abs(b_db - x).max():.1e}; SSG max|b-x|={np.abs(b_sg - x).max():.1e}")
# softdtw vs DBA max on narrowband
for TT in (64, 256, 1024):
    dn = load(f'narrowband_f0-0.25_T{TT}')
    As = Barycenter(mode='softdtw', statistic='max').multivariate(dn); Ad = Barycenter(mode='dtw', statistic='max').multivariate(dn)
    print(f"narrowband T={TT}: softdtw max range {np.nanmin(As):.3f}-{np.nanmax(As):.3f}; dtw max range {np.nanmin(Ad):.3f}-{np.nanmax(Ad):.3f}")
# L-BFGS-B details: patch scipy.optimize.minimize to capture result
import scipy.optimize as so
import tslearn.barycenters.softdtw as sdmod
captured = []
orig_min = sdmod.minimize
def wrap(*a, **k):
    res = orig_min(*a, **k); captured.append((k.get('tol'), k.get('options'), res.success, res.nit, res.message)); return res
sdmod.minimize = wrap
_ = softdtw_barycenter(zz[[1, 0]])
sdmod.minimize = orig_min
print("softdtw_barycenter minimize call:", captured)
