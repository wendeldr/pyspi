import yaml
R = "/media/dan/Data/git/pyspi/audit/records/"
def load(u):
    return yaml.safe_load(open(R + u + ".yaml"))
def save(u, d):
    open(R + u + ".yaml", "w").write(yaml.safe_dump(d, sort_keys=False, width=120, allow_unicode=True))
def rep(c, k, old, new):
    assert old in c[k], (k, old)
    c[k] = c[k].replace(old, new)

AGG_REF = "; run_agg (exact numpy re-aggregation nanmean / nanmax / nanmean(c - c^T) of pyspi's own cached curve data.ccm[E])"
def agg_close(u, E):
    return (f" Aggregation (agg-E{E}, exact, analytic): on iid_gaussian T=64 (5 processes) and var2_bivariate T=256 the mean,"
            f" max and diff matrices equal nanmean / nanmax / nanmean(c - c^T) of pyspi's own 22-entry cached curve to max_abs"
            f" 0.0 (both pass); max|diff - (mean - mean^T)| <= 5.6e-17.")
def agg_run(u, E):
    return {"run_ids": [f"{u}|iid_gaussian|64|pipeline|agg-E{E}", f"{u}|var2_bivariate|256|pipeline|agg-E{E}"],
            "reference": "audit/checks/refs/ccm.py:run_agg (analytic, numpy on pyspi's cached curve; proposed check 3)",
            "outcome": "pass: exact, max_abs 0.0 for mean, max and diff; curve length 22"}

# ---------------- E-10
u = "causal.ccm.E-10"; d = load(u); c = d["correctness"]
c["check_reference"] += AGG_REF
rep(c, "check_data", "iid_gaussian T256,", "iid_gaussian T64 (5 processes, aggregation) / T256,")
rep(c, "agreement_criterion", "and for the schedule;", "and for the schedule and the re-aggregation of the cached curve;")
rep(c, "closeness", "(z mean 0.10, sd 0.97)", "(z mean 0.10, sd 0.98 with ddof 1)")
c["closeness"] += agg_close(u, "10")
c["score_0_10"] = 6
c["what_changed"] = (
    "The cross-map kernel is the canonical Sugihara simplex cross-map (fp-exact against an independent implementation at"
    " E = 3, 4, 10), the random-library curve agrees within sampling error and the mean / max / diff aggregation of the"
    " cached curve is exact. The output deviates from both the supplement and canonical CCM in interpretable ways (README"
    " anchor 6): (1) mean / max of rho over the curve instead of a convergence test (the supplement's own variant), and"
    " diff is pyspi-specific; (2) the curve has 22 library sizes, not the supplement's '21 uniformly sampled library sizes"
    " between this minimum and maximum' (1.3.5), and stops short of the maximum when cppEDM expands to more than 22 sizes"
    " (T=256: 20..230 of 20..240; T=64: 20..41 of 20..50); (3) A[i,j] is row = target (confirmed), the transpose of the"
    " documented directed-matrix convention (glossary-of-terms.md:25-27, rows are sources) and of TE / gc_gaussian, so a"
    " matrix read as documented gives the direction backwards (not in KNOWN_ISSUES). E = 10 and tau = 1 are fixed for"
    " every dataset, no Theiler window. At T=256 the fixed E = 10 loses the direction on both chaotic logistic datasets"
    " (diff[1,0] -0.0034, -0.1086), which T=1024 recovers (+0.6432). Score 6 (was 7 before the check review) because of"
    " (2) and (3).")
c["symmetry_observed"] = (
    "asym for mean/max. mean: max|A - A.T| from 0.0034 (chaotic T=256 stat-mean) to 0.6432 (chaotic T=1024 stats3-E10);"
    " max: from 0.0147 (chaotic T=256 stat-max) to 0.7684 (chaotic T=1024 stats3-E10); iid_gaussian T=64 (agg-E10)"
    " 0.3981 / 0.4336. diff exactly antisymmetric, max|A + A.T| = 0.0 on every diff run (stat-diff, dir-diff, stats3, agg)")
c["checks_run"].append(agg_run(u, "10"))
save(u, d)

# ---------------- E-1
u = "causal.ccm.E-1"; d = load(u); c = d["correctness"]
c["check_reference"] += AGG_REF
rep(c, "check_data", "iid_gaussian T256,", "iid_gaussian T64 (5 processes, aggregation) / T256,")
rep(c, "agreement_criterion", "and for the\n    schedule;" if "and for the\n    schedule;" in c["agreement_criterion"] else "and for the schedule;",
    "and for the schedule and the re-aggregation of the cached curve;")
rep(c, "closeness", "(z mean 0.10, sd 0.97)", "(z mean 0.10, sd 0.98 with ddof 1)")
c["closeness"] += agg_close(u, "1")
c["score_0_10"] = 6
c["what_changed"] = (
    "The cross-map kernel is the canonical Sugihara simplex cross-map (fp-exact against an independent implementation),"
    " the random-library curve agrees with an independent reference within sampling error and the mean / max / diff"
    " aggregation of the cached curve is exact. The output deviates from both the supplement and canonical CCM in"
    " interpretable ways (README anchor 6): (1) mean / max of rho over the curve (canonical CCM tests convergence of"
    " rho(L); the supplement's own variant), and diff = mean - mean^T is a pyspi construct; (2) the curve has 22 library"
    " sizes, not the supplement's '21 uniformly sampled library sizes between this minimum and maximum' (1.3.5), and stops"
    " short of the maximum when cppEDM expands to more than 22 sizes (T=64: 10..52 of 10..60); (3) A[i,j] is row = target"
    " (confirmed), the transpose of the documented directed-matrix convention (glossary-of-terms.md:25-27, rows are"
    " sources) and of TE / gc_gaussian, so a matrix read as documented gives the direction backwards (not in"
    " KNOWN_ISSUES). With E = 1 there is no delay embedding: the measure is a 2-nearest-neighbour contemporaneous"
    " regression skill and scores static functional dependence (nonlinear_dependence 0.967 vs -0.003). Score 6 (was 7"
    " before the check review) because of (2) and (3).")
c["symmetry_observed"] = (
    "asym for mean/max. mean: max|A - A.T| from 0.0071 (iid_gaussian T=256 stat-mean) to 0.9699 (nonlinear_dependence"
    " static-mean); max: from 0.0009 (iid_gaussian T=256 stat-max) to 0.2801 (chaotic T=64 stats3-E1). diff exactly"
    " antisymmetric, max|A + A.T| = 0.0 on every diff run (stat-diff, dir-diff, stats3, agg)")
c["checks_run"].append(agg_run(u, "1"))
save(u, d)

# ---------------- E-None
u = "causal.ccm.E-None"; d = load(u); c = d["correctness"]
c["check_reference"] += AGG_REF
rep(c, "check_data", "iid_gaussian T256 (processes 0,", "iid_gaussian T64 (5 processes, aggregation) and T256 (processes 0,")
rep(c, "agreement_criterion", "and the library schedule;", "the library schedule and the re-aggregation of the cached curve;")
c["closeness"] += agg_close(u, "None")
c["symmetry_observed"] = (
    "asym for mean/max. mean: max|A - A.T| from 0.0034 (chaotic T=256 stat-mean) to 0.3981 (iid_gaussian T=64 agg-ENone);"
    " max: from 0.0147 (chaotic T=256 stat-max) to 0.4336 (iid_gaussian T=64 agg-ENone); identical to causal.ccm.E-10 on"
    " the same data (known bug 2). diff exactly antisymmetric, max|A + A.T| = 0.0 on every diff run")
c["checks_run"].append(agg_run(u, "None"))
save(u, d)
print("ok")
