import sys, numpy as np, pandas as pd, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import make_data, pyEDM
from scipy.stats import zscore
for ds in ['logistic_maps_chaotic','var2_bivariate','iid_gaussian']:
    x = zscore(make_data.load(ds,256)['x'][:2],axis=1,ddof=1); N=256
    df = pd.DataFrame(np.concatenate([np.arange(N)[None], x]).T, columns=['index','proc0','proc1'])
    for c in ['proc0','proc1']:
        ed = pyEDM.EmbedDimension(dataFrame=df, lib=f"10 {N-10}", pred=f"10 {N-10}", columns=c, showPlot=False)
        print(ds, c, ed['rho'].values.tolist())
    np.save(f'x_{ds}.npy', x)
# also Simplex output layout for one case
s = pyEDM.Simplex(dataFrame=df, lib="10 246", pred="10 246", columns='proc0', target='proc0', E=3, Tp=1)
print(s.head(3)); print(s.tail(3)); print(len(s))
