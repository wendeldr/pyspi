import sys, time, numpy as np, pandas as pd
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import make_data, pyEDM
for ds in ['logistic_maps_chaotic','logistic_maps_sugihara']:
    x = make_data.load(ds,256)['x']
    N=x.shape[1]
    df = pd.DataFrame(np.concatenate([np.arange(N)[None], x]).T, columns=['index','proc0','proc1'])
    for E in [1,2,3,4,10]:
        for L in [N-E+1, 100]:
            t=time.time()
            r = pyEDM.CCM(dataFrame=df,E=E,columns='proc0',target='proc1',libSizes=str(L),sample=1,random=False)
            print(ds,E,L,r.columns.tolist(), r.values.tolist(), round(time.time()-t,3))
