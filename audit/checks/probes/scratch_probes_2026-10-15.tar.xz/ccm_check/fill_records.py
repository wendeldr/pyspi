"""Fill the check-stage block of the three ccm records (run in the project venv)."""
import yaml
from pathlib import Path

REC = Path("/media/dan/Data/git/pyspi/audit/records")
U = {"None": "causal.ccm.E-None", "1": "causal.ccm.E-1", "10": "causal.ccm.E-10"}

CALC_FIX = [
    ("'pyspi/calculator.py:293-303 Calculator.compute: np.fill_diagonal(S, nan); any exception -> whole matrix NaN with a warning'",
     "'pyspi/calculator.py:327-339 Calculator.compute (HEAD a42ebc1; file unchanged since a1f20c7): multivariate call 329, "
     "np.fill_diagonal(S, nan) 332, table store 335; any exception -> whole matrix NaN (except 336-339) with a warning (354-355)'"),
]
TEXT_FIX = [("(calculator.py:301-303)", "(calculator.py:336-339, warning 354-355)"),
            ("(calculator.py:296-297)", "(calculator.py:332)"),
            ("pyspi/calculator.py:293-303 Calculator.compute: np.fill_diagonal(S, nan); any exception -> whole matrix NaN with a warning",
             "pyspi/calculator.py:327-339 Calculator.compute (HEAD a42ebc1; file unchanged since a1f20c7): multivariate call 329, "
             "np.fill_diagonal(S, nan) 332, table store 335; any exception -> whole matrix NaN (except 336-339) with a warning (354-355)")]

DIR_CONFIRMED = (
    " Confirmed in the check stage (the probe quoted above ran on the old period-4 logistic_maps fixture): on logistic_maps_chaotic"
    " (x = process 0 drives y = process 1 only) ccm_E-1_diff gives diff[1,0] = +0.0360 (dir-diff, pass) and the swapped input"
    " (processes [1, 0]) gives diff[0,1] = +0.0360 (dir-diff-swap, pass); ccm_E-10 at T=1024 gives mean A[1,0] = 0.5921 vs"
    " A[0,1] = -0.0512, diff[1,0] = +0.6432 (stats3-E10, T=1024); the delegate kernel at E=2 (full library) gives 'y xmap x'"
    " = A[1,0] = 0.8824 vs A[0,1] = 0.2909. So A[i,j] = rho(x_j | M_{x_i}) and a large A[i,j] is evidence that j -> i (row ="
    " target), the transpose of the glossary convention (glossary-of-terms.md:25-27, rows = sources) and of TE/GC"
    " (base.pair_handling|var2_bivariate|1024|pipeline|calls-gc_gaussian: row = source).")

# ------------------------------------------------------------------ shared pieces
SHARED_RES = [
    dict(candidate="orientation: A[i,j] = rho(x_j | M_{x_i}), large A[i,j] = evidence for j -> i (row = target), opposite to"
                   " pyspi's Directed / glossary convention (rows = sources)",
         outcome="confirmed",
         evidence="causal.ccm.E-1|logistic_maps_chaotic|256|kernel|xmap-E2-Lfull (pyEDM column 'proc1:proc0' = A[1,0] ="
                  " 0.8824 = kernel simplex_crossmap(x1 -> predict x0), exact 1.5e-14); causal.ccm.E-1|logistic_maps_chaotic|256|"
                  "pipeline|dir-diff and dir-diff-swap (diff[effect, cause] = +0.0360 in both input orders, pass);"
                  " causal.ccm.E-10|logistic_maps_chaotic|1024|pipeline|stats3-E10 (A[1,0] 0.5921 vs A[0,1] -0.0512);"
                  " glossary-of-terms.md:25-27 states rows = sources; TE row = source in base.pair_handling|var2_bivariate|1024|"
                  "pipeline|calls-gc_gaussian. Not in KNOWN_ISSUES.md"),
    dict(candidate="library schedule: 22 library sizes (not the documented 21); truncated to the first 22 cppEDM sizes at"
                   " short T",
         outcome="confirmed",
         evidence="sched-E1/E10/ENone runs at T = 64, 256, 1024 (exact, max_abs 0.0 vs the analytic schedule): libSizes"
                  " strings '10 60 2' (E=1, T=64: cppEDM 26 sizes, kept 10..52), '20 50 1' (E=10, T=64: 31 sizes, kept"
                  " 20..41), '20 240 10' (E=10, T=256: 23 sizes, kept 20..230), '10 250 11' (E=1, T=256: 22 sizes, all kept),"
                  " T=1024: 22 sizes, all kept (E=10: 20..1007 step 47; E=1: 10..1018 step 48). The count is always 22 because"
                  " inc = floor((upperE-lowerE)/21) gives >= 22 sizes"),
    dict(candidate="short-series failure: inc = 0 makes cppEDM throw; Calculator stores an all-NaN matrix",
         outcome="confirmed",
         evidence="short-E1-T41 and short-E10-T60 / short-ENone-T60 (qualitative, pass): RuntimeError 'increment 0 is"
                  " invalid' at T = 41 (E=1) and T = 60 (E=10, E=None); T = 42 / 61 compute with all off-diagonal entries"
                  " finite. Calculator.compute catches it (calculator.py:336-339) and warns (354-355). The comment at"
                  " tests/unit/test_known_bugs.py:88 ('about 70 observations') is approximate; the exact thresholds are T >= 42"
                  " (E=1) and T >= 61 (E=10/None)"),
    dict(candidate="no temporal exclusion (exclusionRadius = 0): temporally adjacent neighbours may inflate rho",
         outcome="confirmed",
         evidence="causal.ccm.E-10|gauss_ar1_pair|256|kernel|xmap-E10-Lfull vs ...|xmap-E10-Lfull-X10 (both exact vs the"
                  " reference, max_abs <= 4.4e-16): full-library rho drops from 0.3634 / 0.4548 to 0.2339 / 0.3445 with a"
                  " 10-row Theiler window (gap 0.129 / 0.110, 24-36 % of the skill); narrowband_f0-0.1: 0.99697 / 0.99726"
                  " vs 0.99702 / 0.99727 (gap < 1e-4, the sinusoid's neighbours come from other cycles). Behaviour of the"
                  " method as configured (Sugihara 2012 also uses no Theiler window), not a code defect"),
    dict(candidate="reproducibility: implementation-defined RNG and std::sort tie order",
         outcome="inconclusive",
         evidence="cross-platform RNG: not testable here (one Linux build). Tie order: on the tied fixture logistic_maps the"
                  " tied column depends on the input's rounding even within this build: pyEDM 'proc1:proc0' at E=10 is"
                  " 0.41454840 on the raw series (causal.ccm.E-10|logistic_maps|256|kernel|tied-E10-Lfull) and 0.41299681 on"
                  " the z-scored series (...|pipeline|tied-E10-Lfull), while the order-independent stable-argsort reference"
                  " gives 0.40854783 for both; the tie-free column agrees with the reference to 1.3e-14 on both paths. CCM"
                  " is therefore not affine-invariant on tied data. The libstdc++ introsort emulation"
                  " (scratchpad kernels/probe_ccm_stdsort.py) reproduces pyEDM's tied column to <= 1.1e-13"),
    dict(candidate="diagonal: a direct multivariate call returns 0 on the diagonal; only Calculator sets NaN",
         outcome="confirmed",
         evidence="diag-E1 / diag-E10 / diag-ENone (qualitative, pass): diagonal exactly 0.0, off-diagonal finite;"
                  " Calculator.compute fills NaN (calculator.py:332). Harmless inside the Calculator"),
    dict(candidate="labels: documented 'unsigned' vs class Signed",
         outcome="confirmed",
         evidence="negative values on the check data: iid_gaussian T=256 ccm_E-10_mean A[1,0] = -0.0426, ccm_E-1_mean"
                  " -0.0235 / -0.0306 (stat-mean runs), ccm_E-1_diff on logistic_maps_chaotic diff[0,1] = -0.0360; the code"
                  " label (signed) is the consistent one; documentation-only inconsistency"),
]

E10_STAT = ["causal.ccm.E-10|logistic_maps_chaotic|256|pipeline|stat-mean", "causal.ccm.E-10|logistic_maps_chaotic|256|pipeline|stat-max",
            "causal.ccm.E-10|logistic_maps_chaotic|256|pipeline|stat-diff", "causal.ccm.E-10|logistic_maps_sugihara|256|pipeline|stat-mean",
            "causal.ccm.E-10|logistic_maps_sugihara|256|pipeline|stat-max", "causal.ccm.E-10|logistic_maps_sugihara|256|pipeline|stat-diff",
            "causal.ccm.E-10|iid_gaussian|256|pipeline|stat-mean", "causal.ccm.E-10|iid_gaussian|256|pipeline|stat-max",
            "causal.ccm.E-10|iid_gaussian|256|pipeline|stat-diff", "causal.ccm.E-10|logistic_maps_sugihara|256|pipeline-detrend|stat-mean",
            "causal.ccm.E-10|logistic_maps_chaotic|64|pipeline|stats3-E10", "causal.ccm.E-10|logistic_maps_chaotic|1024|pipeline|stats3-E10"]


def common_checks(u, E):
    """checks_run entries shared in shape by every unit."""
    return [
        dict(run_ids=[f"{u}|logistic_maps_chaotic|{T}|pipeline|sched-E{E}" for T in (64, 256, 1024)],
             reference="audit/checks/refs/ccm.py:run_sched (analytic schedule, causal.py:127-131 + cppEDM Parameter.cc L198-291)",
             outcome="pass: exact (max_abs 0.0); 22 sizes kept, truncated at T=64" + (" and T=256" if E != "1" else "")),
        dict(run_ids=[f"{u}|logistic_maps_chaotic|64|pipeline|short-E{E}-T{41 if E == '1' else 60}",
                      f"{u}|logistic_maps_chaotic|64|pipeline|diag-E{E}"],
             reference="audit/checks/refs/ccm.py:run_short, run_diag (analytic)",
             outcome=f"pass: cppEDM throws at T = {41 if E == '1' else 60}, computes at T = {42 if E == '1' else 61}; direct-call diagonal 0.0"),
    ]


def unit_none():
    u = U["None"]
    stat = [r.replace("E-10", "E-None") for r in E10_STAT[:9]]
    return dict(
        check_method="independent-impl",
        check_reference=("audit/checks/refs/ccm.py:run_embed -> audit/checks/refs/_kernels_distance.py:simplex_predictions"
                         " (from-scratch simplex forecast table rho(E = 1..10), Tp = 1, cppEDM EmbedDimension lib/pred rows);"
                         " audit/checks/refs/ccm.py:run_stat (500 own random libraries per size on pyspi's grid with the"
                         " kernel arithmetic XMap, validated against _kernels_distance.py:simplex_crossmap to 0.0, bootstrap of"
                         " 100-library curves); audit/checks/refs/ccm.py:run_doc_e (same at the documented E); run_sched;"
                         " run_short; run_diag; run_dir; run_eq_e10 (pyspi self-consistency, same-lineage, known bug 2). The"
                         " delegate kernel itself is checked under causal.ccm.E-10 (exact runs at E = 3, 4, 10)"),
        check_data="logistic_maps_chaotic T64/T256/T1024 (pipeline), logistic_maps_sugihara T256, iid_gaussian T256 (processes 0, 1), var2_bivariate T256",
        agreement_criterion=("exact (rtol 1e-10, atol 1e-12) for the EmbedDimension rho(E) table and the library schedule;"
                             " statistical |pyspi - bootstrap mean| <= 2 se for mean/max/diff; direction: sign of diff[effect,"
                             " cause] > 0 under the CCM convention; qualitative for short-series/diagonal/E-10 equality"),
        closeness=("EmbedDimension table reproduced from scratch: embed-ENone max_abs 1.1e-16 (iid), 1.0e-15 (chaotic), 5.6e-16"
                   " (var2); pyspi passes E = 10 for every process while the argmax-rho E is [1, 2] (chaotic), [9, 3] (iid),"
                   " [10, 7] (var2), so the documented E is 2 / 9 / 10. ccm_E-None_* == ccm_E-10_* bitwise (eqE10-mean on"
                   " chaotic and sugihara, pass). Statistical: the 9 stat runs pass, max |z| 1.15 (chaotic mean pyspi"
                   " 0.2844 / 0.2810 vs reference 0.2833 / 0.2801, z 1.03); the documented-E run fails as expected:"
                   " stat-mean-docE pyspi 0.2844 / 0.2810 vs reference at E = 2 0.1992 / 0.6873 (max_z 408.6, max_abs"
                   " 0.406). Direction: dir-diff fails on chaotic (diff[1,0] = -0.0034) and sugihara (diff[1,0] = -0.1086);"
                   " at the documented E = 2 the reference curve orients chaotic correctly (A[1,0] 0.6873 > A[0,1] 0.1992)."),
        verdict="related-quantity",
        score_0_10=4,
        what_changed=("E is fixed at 10 by embed_df.max()['E'] instead of the E that best predicts each series (known bug 2,"
                      " README anchor 4 'CCM max-E selection'); ccm_E-None_* is bitwise equal to ccm_E-10_*. Value-changing:"
                      " on logistic_maps_chaotic T=256 the documented rule gives E = 2 and mean A[1,0] = 0.687 vs A[0,1] ="
                      " 0.199 (direction recovered); pyspi gives 0.281 / 0.284 (no direction). Everything downstream of the E"
                      " choice (cross-map, random libraries, mean/max/diff) agrees with the independent reference within"
                      " statistical tolerance, as for causal.ccm.E-10. Also: A[i,j] is row = target (confirmed, not in"
                      " KNOWN_ISSUES), 22 library sizes, diff undefined in the supplement, convergence not tested."),
        new_finding=True,
        definition_under_review=False,
        check_cost=("expensive: about 3.5-3.8 s per pyspi run at T=256 (each identifier recomputes the 100-library curve and 10"
                    " EmbedDimension fits per process on a fresh Data object); E=10 at T=1024 took 85 s alone (167 s under"
                    " concurrent load in the stats3-E10 run); all E-None runs at T <= 256"),
        symmetry_observed=("asym for mean/max: max|A - A.T| = 0.0034 (chaotic mean) to 0.1086 (sugihara mean); diff exactly"
                           " antisymmetric: max|A + A.T| = 0.0 on every diff run"),
        direction_observed=("A[i,j] = rho(x_j | M_{x_i}) (row = target): large A[i,j] means j -> i. At pyspi's E = 10 and T=256"
                            " the direction is not recovered on logistic_maps_chaotic (diff[1,0] = -0.0034, dir-diff fail) or"
                            " logistic_maps_sugihara (diff[1,0] = -0.1086, fail); it is recovered at T=1024 (same numbers as"
                            " ccm_E-10: A[1,0] 0.5921 vs A[0,1] -0.0512, causal.ccm.E-10|logistic_maps_chaotic|1024|pipeline|"
                            "stats3-E10) and at the documented E = 2 at T=256 (reference 0.6873 vs 0.1992)."),
        candidate_resolutions=SHARED_RES + [
            dict(candidate="intended-design question: one E = max(E_i, E_j) for both directions vs a per-direction E",
                 outcome="inconclusive",
                 evidence="design question, not numerically decidable: embed-ENone shows per-process argmax-rho E of [1, 2]"
                          " (chaotic), [9, 3] (iid), [10, 7] (var2), so the two rules would differ on every dataset checked;"
                          " which is intended is for the maintainers")],
        checks_run=[
            dict(run_ids=[f"{u}|{d}|256|pipeline|embed-ENone" for d in ("logistic_maps_chaotic", "var2_bivariate", "iid_gaussian")],
                 reference="audit/checks/refs/ccm.py:run_embed (from-scratch simplex table)",
                 outcome="pass: exact, max_abs <= 1.0e-15; pyspi E = 10, argmax-rho E [1,2], [10,7], [9,3]"),
            dict(run_ids=stat, reference="audit/checks/refs/ccm.py:run_stat (500 draws, bootstrap)",
                 outcome="pass: 9/9 within 2 se, max |z| 1.15"),
            dict(run_ids=[f"{u}|logistic_maps_chaotic|256|pipeline|stat-mean-docE"],
                 reference="audit/checks/refs/ccm.py:run_doc_e (documented E = 2)",
                 outcome="fail (expected, known bug 2): pyspi 0.2844 / 0.2810 vs 0.1992 / 0.6873, max_z 408.6"),
            dict(run_ids=[f"{u}|logistic_maps_chaotic|256|pipeline|eqE10-mean", f"{u}|logistic_maps_sugihara|256|pipeline|eqE10-mean"],
                 reference="audit/checks/refs/ccm.py:run_eq_e10 (same-lineage)", outcome="pass: bitwise equal to ccm_E-10_mean"),
            dict(run_ids=[f"{u}|logistic_maps_chaotic|256|pipeline|dir-diff", f"{u}|logistic_maps_sugihara|256|pipeline|dir-diff"],
                 reference="audit/checks/refs/ccm.py:run_dir (Sugihara criterion, CONVENTIONS.md D8)",
                 outcome="fail: diff[1,0] = -0.0034 (chaotic), -0.1086 (sugihara); method behaviour at E = 10, T = 256"),
        ] + common_checks(u, "None"),
    )


def unit_one():
    u = U["1"]
    kern = ([f"{u}|{d}|256|kernel|xmap-E{E}-L{L}" for d in ("logistic_maps_chaotic", "logistic_maps_sugihara") for E in (1, 2) for L in ("full", "100")]
            + [f"{u}|{d}|256|kernel|xmap-E1-Lfull" for d in ("var2_bivariate", "nonlinear_dependence", "iid_gaussian")]
            + [f"{u}|nonlinear_dependence|1024|kernel|xmap-E1-Lfull"])
    stat = [r.replace("E-10", "E-1").replace("stats3-E10", "stats3-E1") for r in E10_STAT[:11]]
    return dict(
        check_method="independent-impl",
        check_reference=("audit/checks/refs/_kernels_distance.py:simplex_crossmap (own contiguous-library simplex projection,"
                         " no pyEDM) for the delegate kernel; audit/checks/refs/ccm.py:run_stat / run_curve / run_seeds (own"
                         " random libraries on pyspi's grid with XMap, the kernel arithmetic, validated against simplex_crossmap to"
                         " 0.0); run_affine (analytic invariance); run_tied; run_sched; run_short; run_diag; run_dir; run_static"),
        check_data=("logistic_maps_chaotic T64/T256 (kernel, pipeline), logistic_maps_sugihara T256 (kernel, pipeline,"
                    " pipeline-detrend), logistic_maps_bidir T256, var2_bivariate T256, nonlinear_dependence T256/T1024,"
                    " iid_gaussian T256, logistic_maps T256 (tied fixture, kernel and pipeline), scaled_offset T256 (kernel)"),
        agreement_criterion=("exact (rtol 1e-10, atol 1e-12) for pyEDM.CCM(random=False, one libSize) vs the kernel and for the"
                             " schedule; tolerance 1e-10 for affine invariance; statistical |pyspi - bootstrap mean| <= 2 se for"
                             " mean/max/diff (seed 42) and for the 16-seed bias test; direction: sign of diff[effect, cause];"
                             " qualitative (pre-declared rules) for curves, ties, short series, diagonal and static dependence"),
        closeness=("Kernel: all 12 exact xmap runs pass, max_abs 1.65e-14 (sugihara E1 Lfull; e.g. chaotic E2 Lfull pyEDM"
                   " A[1,0] 0.8824 / A[0,1] 0.2909), no tied rows; affine-E1 max_abs 6.7e-16. Wrapper (seed 42, pyspi's grid"
                   " 10..241 step 11 at T=256): 10 of 13 statistical runs within 2 se; the excursions are stat-mean on"
                   " iid_gaussian (pyspi -0.0235 / -0.0306 vs -0.0245 / -0.0340, |z| 2.99), stat-mean on chaotic (0.1820 vs"
                   " 0.1791, |z| 2.16) and stat-max on sugihara (0.3720 vs 0.3686, |z| 2.04). The bias test with 16 other"
                   " seeds (1600 libraries per size) agrees: seeds-E1-S16 iid -0.02414 / -0.03339 vs -0.02417 / -0.03292"
                   " (|z| 0.08, 1.34), chaotic 0.17971 / 0.21851 vs 0.17944 / 0.21787 (|z| 0.70, 1.55), so no systematic"
                   " bias; over all 58 statistical cells of the family 4 exceed 2 se (z mean 0.10, sd 0.97). Curves"
                   " (curve-E1, 2 x 22 entries): chaotic max|z| 2.29, chi2 p 0.53; sugihara max|z| 2.50, p 0.49."
                   " Static dependence: static-mean A[0,1] 0.9672, A[1,0] -0.0027 (pass)."),
        verdict="variant",
        score_0_10=7,
        what_changed=("The cross-map kernel is the canonical Sugihara simplex cross-map (fp-exact against an independent"
                      " implementation) and the random-library curve agrees with an independent reference within sampling"
                      " error, but the reported quantity is the supplement's variant: mean / max of rho over 22 library sizes"
                      " (canonical CCM tests convergence of rho(L)), and diff = mean - mean^T is a pyspi construct. With E = 1"
                      " there is no delay embedding: the measure is a 2-nearest-neighbour contemporaneous regression skill and"
                      " scores static functional dependence (nonlinear_dependence 0.967 vs -0.003). A[i,j] is row = target"
                      " (confirmed, opposite to the glossary; not in KNOWN_ISSUES)."),
        new_finding=True,
        definition_under_review=False,
        check_cost=("moderate: about 3.4 s per pyspi run at T=256 (each identifier recomputes the 100-library curve); the 16-seed"
                    " bias probe took 56 s; no E=1 run at T=1024 through pyspi (the T=1024 nonlinear_dependence run is a"
                    " single pyEDM call)"),
        symmetry_observed=("asym for mean/max: max|A - A.T| 0.0009 (iid max) to 0.3663 (sugihara detrend mean); diff exactly"
                           " antisymmetric, max|A + A.T| = 0.0 on every diff run"),
        direction_observed=("A[i,j] = rho(x_j | M_{x_i}): large A[i,j] means j -> i (row = target). logistic_maps_chaotic (x -> y)"
                            " diff[1,0] = +0.0360 and with processes swapped diff[0,1] = +0.0360 (both pass);"
                            " logistic_maps_sugihara diff[1,0] = +0.2566 (pass); logistic_maps_bidir (y -> x stronger) diff[0,1]"
                            " = -0.0997 (fail) and var2_bivariate (0 -> 1) diff[1,0] = -0.0369 (fail): with E = 1 the direction"
                            " reading is not reliable on these two datasets."),
        candidate_resolutions=SHARED_RES + [
            dict(candidate="static dependence read as causality (E = 1 is a contemporaneous kNN regression)",
                 outcome="confirmed",
                 evidence="causal.ccm.E-1|nonlinear_dependence|256|pipeline|static-mean (pass): A[0,1] = 0.9672,"
                          " A[1,0] = -0.0027 on iid samples x1 = x0^2 + noise; kernel full library T=256 0.9768 / -0.0073 and"
                          " T=1024 0.9763 / -0.0219 (exact vs simplex_crossmap). Method behaviour at E = 1, documented in the"
                          " note; not a code defect")],
        checks_run=[
            dict(run_ids=kern, reference="audit/checks/refs/_kernels_distance.py:simplex_crossmap via refs/ccm.py:run_xmap",
                 outcome="pass: 12/12 exact, max_abs 1.65e-14, 0 tied rows"),
            dict(run_ids=[f"{u}|scaled_offset|256|kernel|affine-E1-Lfull"], reference="audit/checks/refs/ccm.py:run_affine",
                 outcome="pass: max_abs 6.7e-16"),
            dict(run_ids=[f"{u}|logistic_maps|256|kernel|tied-E1-Lfull", f"{u}|logistic_maps|256|pipeline|tied-E1-Lfull"],
                 reference="audit/checks/refs/ccm.py:run_tied",
                 outcome="pass: tie-free column exact; tied column (256 tied rows) pyEDM 0.2580 vs stable reference 0.0162"),
            dict(run_ids=stat, reference="audit/checks/refs/ccm.py:run_stat (500 draws, bootstrap)",
                 outcome="fail on 3 of 11 runs at |z| 2.99, 2.16, 2.04 (single-seed excursions, see seeds); 8 pass"),
            dict(run_ids=[f"{u}|iid_gaussian|256|pipeline|seeds-E1-S16", f"{u}|logistic_maps_chaotic|256|pipeline|seeds-E1-S16"],
                 reference="audit/checks/refs/ccm.py:run_seeds (2000 draws, analytic se)", outcome="pass: max |z| 1.55"),
            dict(run_ids=[f"{u}|logistic_maps_chaotic|256|pipeline|curve-E1", f"{u}|logistic_maps_sugihara|256|pipeline|curve-E1"],
                 reference="audit/checks/refs/ccm.py:run_curve", outcome="pass: max|z| 2.29 / 2.50, chi2 p 0.53 / 0.49"),
            dict(run_ids=[f"{u}|{d}|256|pipeline|dir-diff" for d in ("logistic_maps_chaotic", "logistic_maps_sugihara", "logistic_maps_bidir", "var2_bivariate")]
                 + [f"{u}|logistic_maps_chaotic|256|pipeline|dir-diff-swap"],
                 reference="audit/checks/refs/ccm.py:run_dir (Sugihara criterion, CONVENTIONS.md D8)",
                 outcome="3 pass (chaotic both orders +0.0360, sugihara +0.2566), 2 fail (bidir -0.0997, var2 -0.0369)"),
            dict(run_ids=[f"{u}|nonlinear_dependence|256|pipeline|static-mean"], reference="audit/checks/refs/ccm.py:run_static",
                 outcome="pass: 0.9672 / -0.0027"),
        ] + common_checks(u, "1"),
    )


def unit_ten():
    u = U["10"]
    kern = ([f"{u}|{d}|256|kernel|xmap-E{E}-L{L}" for d in ("logistic_maps_chaotic", "logistic_maps_sugihara") for E in (3, 4, 10) for L in ("full", "100")]
            + [f"{u}|{d}|256|kernel|xmap-E10-Lfull" for d in ("var2_bivariate", "nonlinear_dependence", "iid_gaussian")])
    return dict(
        check_method="independent-impl",
        check_reference=("audit/checks/refs/_kernels_distance.py:simplex_crossmap (own contiguous-library simplex projection,"
                         " no pyEDM) for the delegate kernel; audit/checks/refs/ccm.py:XMap(excl) for the exclusion-radius"
                         " comparison; audit/checks/refs/ccm.py:run_stat / run_curve (own random libraries on pyspi's grid,"
                         " bootstrap of 100-library curves); run_affine; run_tied; run_sched; run_short; run_diag; run_dir"),
        check_data=("logistic_maps_chaotic T64/T256/T1024, logistic_maps_sugihara T256 (kernel, pipeline, pipeline-detrend),"
                    " logistic_maps_bidir T256, var2_bivariate T256, nonlinear_dependence T256, iid_gaussian T256,"
                    " gauss_ar1_pair T256, narrowband_f0-0.1 T256, logistic_maps T256 (tied fixture), scaled_offset T256"),
        agreement_criterion=("exact (rtol 1e-10, atol 1e-12) for pyEDM.CCM(random=False, one libSize, exclusionRadius 0 or 10)"
                             " vs the kernel and for the schedule; tolerance 1e-10 for affine invariance; statistical |pyspi -"
                             " bootstrap mean| <= 2 se; direction: sign of diff[effect, cause]; qualitative for curves, ties,"
                             " short series and diagonal"),
        closeness=("Kernel: all 15 exact xmap runs (E = 3, 4, 10; L = 100 and full; plus var2, nonlinear_dependence, iid) pass,"
                   " max_abs 1.94e-14 (chaotic E10 L100), no tied rows; exclusion radius 10: gauss_ar1_pair and narrowband"
                   " max_abs <= 3.3e-16; affine-E10 max_abs 1.2e-15. Wrapper (seed 42, pyspi grid 20..230 step 10 at T=256):"
                   " 11 of 12 statistical runs within 2 se; stats3-E10 at T=1024 max |z| 2.06 on mean A[1,0] (pyspi 0.59207 vs"
                   " 0.59318, se 0.00054), the other 5 cells |z| <= 0.99; chaotic T=256 mean 0.2844 / 0.2810 vs 0.2833 /"
                   " 0.2801 (z 1.03). Curves: curve-E10 chaotic max|z| 1.76, chi2 p 0.78; sugihara max|z| 2.32, p 0.45."
                   " Over all 58 statistical cells of the family 4 exceed 2 se (z mean 0.10, sd 0.97); the E-1 seed test found"
                   " no systematic bias of the shared random-library path."),
        verdict="variant",
        score_0_10=7,
        what_changed=("The cross-map kernel is the canonical Sugihara simplex cross-map (fp-exact against an independent"
                      " implementation at E = 3, 4, 10) and the random-library curve agrees within sampling error, but the"
                      " reported quantity is the supplement's variant (mean / max of rho over 22 library sizes instead of a"
                      " convergence test), diff is pyspi-specific, E = 10 and tau = 1 are fixed for every dataset, no Theiler"
                      " window. A[i,j] is row = target (confirmed, opposite to the glossary; not in KNOWN_ISSUES). At T=256"
                      " the fixed E = 10 loses the direction on both chaotic logistic datasets (diff[1,0] -0.0034, -0.1086),"
                      " which T=1024 recovers (+0.6432)."),
        new_finding=True,
        definition_under_review=False,
        check_cost=("expensive: about 3.6 s per pyspi run at T=256; 85 s at T=1024 measured alone (167 s in the stats3-E10 run"
                    " under concurrent load), so only one T=1024 run; reference for that run 524 s (500 x 22 x 2 cross-maps)"),
        symmetry_observed=("asym for mean/max: max|A - A.T| = 0.0034 (chaotic mean T=256) to 0.6433 (chaotic mean T=1024);"
                           " diff exactly antisymmetric, max|A + A.T| = 0.0 on every diff run"),
        direction_observed=("A[i,j] = rho(x_j | M_{x_i}): large A[i,j] means j -> i (row = target). logistic_maps_chaotic (x -> y)"
                            " T=1024: A[1,0] 0.5921 vs A[0,1] -0.0512, diff[1,0] +0.6432 (correct); T=256: diff[1,0] -0.0034"
                            " (dir-diff fail; swapped input gives the transposed result, dir-diff-swap); sugihara T=256 diff[1,0]"
                            " -0.1086 (fail); bidir diff[0,1] +0.1233 (pass); var2_bivariate diff[1,0] -0.2434 (fail: the cause's"
                            " embedding predicts the effect better)."),
        candidate_resolutions=SHARED_RES + [
            dict(candidate="behaviour: on stochastic linear coupling (var2_bivariate) the E=10 CCM reading points the wrong way",
                 outcome="confirmed",
                 evidence="causal.ccm.E-10|var2_bivariate|256|pipeline|dir-diff (fail): diff[0,1] = +0.2434, reading 1 -> 0;"
                          " the delegate kernel shows the same asymmetry on the full library (xmap-E10-Lfull: A[0,1] 0.3054,"
                          " A[1,0] 0.1282, exact). Method behaviour on stochastic linear systems, not a code defect")],
        checks_run=[
            dict(run_ids=kern, reference="audit/checks/refs/_kernels_distance.py:simplex_crossmap via refs/ccm.py:run_xmap",
                 outcome="pass: 15/15 exact, max_abs 1.94e-14, 0 tied rows"),
            dict(run_ids=[f"{u}|{d}|256|kernel|xmap-E10-Lfull{x}" for d in ("gauss_ar1_pair", "narrowband_f0-0.1") for x in ("", "-X10")],
                 reference="audit/checks/refs/ccm.py:run_xmap / XMap(excl=10)",
                 outcome="pass: exact (<= 4.4e-16); Theiler-10 gap 0.129 / 0.110 (AR(1) pair), < 1e-4 (sinusoid)"),
            dict(run_ids=[f"{u}|scaled_offset|256|kernel|affine-E10-Lfull"], reference="audit/checks/refs/ccm.py:run_affine",
                 outcome="pass: max_abs 1.2e-15"),
            dict(run_ids=[f"{u}|logistic_maps|256|kernel|tied-E10-Lfull", f"{u}|logistic_maps|256|pipeline|tied-E10-Lfull"],
                 reference="audit/checks/refs/ccm.py:run_tied",
                 outcome="pass: tie-free column exact; tied column pyEDM 0.41455 (raw) / 0.41300 (z-scored) vs stable 0.40855"),
            dict(run_ids=E10_STAT, reference="audit/checks/refs/ccm.py:run_stat (500 draws, bootstrap)",
                 outcome="11 pass; stats3-E10 T=1024 fails at |z| 2.06 on one of 6 cells"),
            dict(run_ids=[f"{u}|logistic_maps_chaotic|256|pipeline|curve-E10", f"{u}|logistic_maps_sugihara|256|pipeline|curve-E10"],
                 reference="audit/checks/refs/ccm.py:run_curve", outcome="pass: max|z| 1.76 / 2.32, chi2 p 0.78 / 0.45"),
            dict(run_ids=[f"{u}|{d}|256|pipeline|dir-diff" for d in ("logistic_maps_chaotic", "logistic_maps_sugihara", "logistic_maps_bidir", "var2_bivariate")]
                 + [f"{u}|logistic_maps_chaotic|256|pipeline|dir-diff-swap"],
                 reference="audit/checks/refs/ccm.py:run_dir (Sugihara criterion, CONVENTIONS.md D8)",
                 outcome="1 pass (bidir +0.1233), 4 fail (chaotic -0.0034 in both orders, sugihara -0.1086, var2 -0.2434)"),
        ] + common_checks(u, "10"),
    )


FILL = {"None": unit_none, "1": unit_one, "10": unit_ten}
for E, fn in FILL.items():
    p = REC / f"{U[E]}.yaml"
    d = yaml.safe_load(p.read_text())
    c = d["correctness"]
    c["implementation_trace"] = [CALC_FIX[0][1].strip("'") if t == CALC_FIX[0][0].strip("'") else t for t in c["implementation_trace"]]
    for k, v in list(c.items()):
        if isinstance(v, str):
            for a, b in TEXT_FIX:
                v = v.replace(a, b)
            c[k] = v
        elif isinstance(v, list):
            c[k] = [_ for _ in v]
            for i, item in enumerate(c[k]):
                if isinstance(item, str):
                    for a, b in TEXT_FIX:
                        item = item.replace(a, b)
                    c[k][i] = item
    dc = c["direction_convention"]
    if "Confirmed in the check stage" not in dc:
        c["direction_convention"] = dc.replace(" To be confirmed in the check stage.", "") + DIR_CONFIRMED
    c.update(fn())
    d["status"] = "checked"
    p.write_text(yaml.safe_dump(d, sort_keys=False, width=120, allow_unicode=True))
    print("wrote", p)
