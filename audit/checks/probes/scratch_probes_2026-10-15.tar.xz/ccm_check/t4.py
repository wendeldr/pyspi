import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import _kernels_distance as kd
pe = {'logistic_maps_chaotic':[[0.9998532295786414, 0.9996153246925763, 0.9990948119974016, 0.9978396494563655, 0.9939748659737921, 0.9836530581447656, 0.9688050116644569, 0.948616063679343, 0.9199819246215751, 0.8911373550504126]],
      'var2_bivariate':[[0.2870530306895365, 0.3811242091048284, 0.43607501179973973, 0.4302751844476891, 0.41458512721919516, 0.49885425014753415, 0.44271518842693464, 0.45472605892361867, 0.4617210734945097, 0.5029795884864633]]}
for ds,v in pe.items():
    x=np.load(f'x_{ds}.npy')[0]
    for libhi in [245,244]:
        out=[]
        for E in range(1,11):
            t,pred,tied = kd.simplex_predictions(x,x,E,Tp=1,lib_indices=np.arange(9,libhi+1))
            # rows+Tp returned; keep pred rows 9..245 -> targets 10..246
            m=(t>=10)&(t<=246)
            out.append((kd._pearson0(x[t[m]],pred[m]), int(tied[m].sum())))
        r=np.array([o[0] for o in out]); print(ds,libhi, np.max(np.abs(r-np.array(v[0]))), [o[1] for o in out][:10])
