import sys, time, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import make_data, _kernels_distance as kd
for ds in ['logistic_maps_chaotic','logistic_maps_sugihara']:
    x = make_data.load(ds,256)['x']; N=x.shape[1]
    for E in [1,2,3,4,10]:
        for L in [N-E+1,100]:
            valid=np.arange(E-1,N)[:L]
            t=time.time()
            a=kd.simplex_crossmap(x[0],x[1],E,lib_indices=valid,return_tied=True); b=kd.simplex_crossmap(x[1],x[0],E,lib_indices=valid,return_tied=True)
            print(ds,E,L,repr(a),repr(b),round(time.time()-t,3))
