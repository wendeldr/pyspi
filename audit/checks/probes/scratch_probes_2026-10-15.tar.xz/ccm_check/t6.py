import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import _kernels_distance as kd
x=np.load('x_logistic_maps_chaotic.npy')[0]
for E in [1,3]:
    s=np.load(f'simplex_E{E}.npy'); print('first non-nan', s[~np.isnan(s[:,2])][0,0], 'n', (~np.isnan(s[:,2])).sum(), s[0])
    s=s[~np.isnan(s[:,2])]
    for lo,hi in [(9+E-1,245),(9+E-1,244)]:
        t,pred,tied = kd.simplex_predictions(x,x,E,Tp=1,lib_indices=np.arange(lo,hi+1))
        d={int(a):b for a,b in zip(t,pred)}
        diff=np.array([d[int(r[0])]-r[2] for r in s])
        print(lo,hi, np.abs(diff).max())
