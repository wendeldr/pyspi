import sys, time, json
sys.argv=['x']
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import ccm
runs=json.load(open('/media/dan/Data/git/pyspi/audit/checks/manifest/ccm.json'))['runs']
done=set()
for r in runs:
    kind,p,rest=ccm.tag_of(r['run_id'])
    if kind in ('stat','stats3','curve'):
        if kind=='stat':
            E=ccm.E_of_identifier(r['identifier']); E=10 if E is None else E
            if rest[1:]==['docE']: E=2
        else:
            E=10 if p['E']=='None' else int(p['E'])
        x=ccm.prep(ccm.raw(r),r['path'])
        key=f"{r['dataset']}_T{r['T']}_E{E}_{r['path']}_{'-'.join(map(str, r.get('processes') or []))}"
        if key in done: continue
        done.add(key); t=time.time()
        R,sizes,val,dt=ccm.draws(x,E,r['T'],key)
        print(key, R.shape, 'val', val, round(dt,1), flush=True)
