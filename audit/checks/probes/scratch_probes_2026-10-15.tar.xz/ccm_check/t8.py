import sys, time, numpy as np, importlib.util
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import make_data
spec=importlib.util.spec_from_file_location('p','/media/dan/Data/git/pyspi/audit/checks/probes/ccm_probes.py'); p=importlib.util.module_from_spec(spec); spec.loader.exec_module(p)
x=make_data.load('logistic_maps_chaotic',256)['x']
for tag in ['stats3-E1','stats3-E10','stats3-ENone']:
    t=time.time(); r=p.stats3(x,{'run_id':'a|b|'+tag,'path':'pipeline'}); print(tag, round(time.time()-t,2)); print(r)
for tag,fn in [('sched-E10',p.schedule),('sched-E1',p.schedule),('emb-ENone',p.embed_choice),('short-E10-T60',p.short_series),('short-E1-T41',p.short_series),('diag-E1',p.diagonal),('xmap-E2-Lfull',p.kernel_xmap),('xmap-E10-Lfull-X10',p.kernel_xmap)]:
    t=time.time(); r=fn(x,{'run_id':'a|b|'+tag,'path':'pipeline' if 'xmap' not in tag else 'kernel'}); print(tag, round(time.time()-t,2)); print(r)
x=make_data.load('logistic_maps_chaotic',64)['x']
for tag in ['sched-E10','sched-E1']:
    print(tag, 'T64', p.schedule(x,{'run_id':'a|b|'+tag,'path':'pipeline'}))
