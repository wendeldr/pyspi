import sys, numpy as np, pandas as pd, warnings
warnings.filterwarnings('ignore')
import pyEDM
x=np.load('x_logistic_maps_chaotic.npy'); N=256
df = pd.DataFrame(np.concatenate([np.arange(N)[None], x]).T, columns=['index','proc0','proc1'])
for E in [1,3]:
    s = pyEDM.Simplex(dataFrame=df, lib="10 246", pred="10 246", columns='proc0', target='proc0', E=E, Tp=1)
    np.save(f'simplex_E{E}.npy', s[['index','Observations','Predictions']].values.astype(float))
    o=s.dropna(); print(E, np.corrcoef(o.Observations,o.Predictions)[0,1])
