import json
U = {1: "causal.ccm.E-1", 10: "causal.ccm.E-10", None: "causal.ccm.E-None"}
PR = "probes/ccm_probes.py"
PROC = {"iid_gaussian": [0, 1], "nonlinear_dependence": [0, 1], "narrowband_f0-0.1": [0, 1], "scaled_offset": [2, 3]}
runs = []
def add(unit, ident, ds, T, path, tag, fn=None):
    runs.append(dict(run_id=f"{unit}|{ds}|{T}|{path}|{tag}", unit_id=unit, identifier=ident, dataset=ds, T=T,
                     path=path, processes=PROC.get(ds), seed=42,
                     probe=None if fn is None else {"module": PR, "function": fn}))
# 1 kernel exact (delegate isolated): E 1,2 -> E-1 unit; 3,4,10 -> E-10 unit
for ds in ["logistic_maps_chaotic", "logistic_maps_sugihara"]:
    for E in [1, 2, 3, 4, 10]:
        for L in ["full", "100"]:
            add(U[1] if E <= 2 else U[10], None, ds, 256, "kernel", f"xmap-E{E}-L{L}", "kernel_xmap")
for ds in ["var2_bivariate", "nonlinear_dependence", "iid_gaussian"]:
    for E in [1, 10]:
        add(U[E], None, ds, 256, "kernel", f"xmap-E{E}-Lfull", "kernel_xmap")
for E in [1, 10]:
    add(U[E], None, "logistic_maps", 256, "kernel", f"tied-E{E}-Lfull", "kernel_xmap")
    add(U[E], None, "scaled_offset", 256, "kernel", f"affine-E{E}-Lfull", "kernel_xmap")
for ds in ["gauss_ar1_pair", "narrowband_f0-0.1"]:
    for X in [0, 10]:
        add(U[10], None, ds, 256, "kernel", f"xmap-E10-Lfull" + (f"-X{X}" if X else ""), "kernel_xmap")
# 2 E-None embedding choice
for ds in ["logistic_maps_chaotic", "var2_bivariate", "iid_gaussian"]:
    add(U[None], None, ds, 256, "pipeline", "embed-ENone", "embed_choice")
# 3 schedule, short series, diagonal
for E in [1, 10, None]:
    for T in [64, 256, 1024]:
        add(U[E], None, "logistic_maps_chaotic", T, "pipeline", f"sched-E{E}", "schedule")
    add(U[E], None, "logistic_maps_chaotic", 64, "pipeline", f"short-E{E}-T{41 if E == 1 else 60}", "short_series")
    add(U[E], None, "logistic_maps_chaotic", 64, "pipeline", f"diag-E{E}", "diagonal")
# 4 wrapper statistical (plain SPI identifiers)
for E in [1, 10, None]:
    for ds in ["logistic_maps_chaotic", "logistic_maps_sugihara", "iid_gaussian"]:
        for st in ["mean", "max", "diff"]:
            add(U[E], f"ccm_E-{E}_{st}", ds, 256, "pipeline", f"stat-{st}")
add(U[None], "ccm_E-None_mean", "logistic_maps_chaotic", 256, "pipeline", "stat-mean-docE")
for E in [1, 10]:
    add(U[E], f"ccm_E-{E}_mean", "logistic_maps_sugihara", 256, "pipeline-detrend", "stat-mean")
    add(U[E], None, "logistic_maps_chaotic", 64, "pipeline", f"stats3-E{E}", "stats3")
    for ds in ["logistic_maps_chaotic", "logistic_maps_sugihara"]:
        add(U[E], None, ds, 256, "pipeline", f"curve-E{E}", "curve")
add(U[10], None, "logistic_maps_chaotic", 1024, "pipeline", "stats3-E10", "stats3")
# E-1 static dependence (no dynamics): pipeline mean on nonlinear_dependence x1 = x0^2 + noise
add(U[1], "ccm_E-1_mean", "nonlinear_dependence", 256, "pipeline", "static-mean")
add(U[1], None, "nonlinear_dependence", 1024, "kernel", "xmap-E1-Lfull", "kernel_xmap")
# E-None == E-10 (known bug 2), pyspi self-consistency
for ds in ["logistic_maps_chaotic", "logistic_maps_sugihara"]:
    add(U[None], "ccm_E-None_mean", ds, 256, "pipeline", "eqE10-mean")
# 5 direction
for E in [1, 10, None]:
    dss = ["logistic_maps_chaotic", "logistic_maps_sugihara"] + (["logistic_maps_bidir", "var2_bivariate"] if E else [])
    for ds in dss:
        add(U[E], f"ccm_E-{E}_diff", ds, 256, "pipeline", "dir-diff")
# both orientations: same data with the processes swapped (y, x)
for E in [1, 10]:
    runs.append(dict(run_id=f"{U[E]}|logistic_maps_chaotic|256|pipeline|dir-diff-swap", unit_id=U[E],
                     identifier=f"ccm_E-{E}_diff", dataset="logistic_maps_chaotic", T=256, path="pipeline",
                     processes=[1, 0], seed=42, probe=None))
# bias test of the random-library curve (seeds 1..16), the two E-1 mean runs that exceeded 2 se
for ds in ["iid_gaussian", "logistic_maps_chaotic"]:
    add(U[1], None, ds, 256, "pipeline", "seeds-E1-S16", "seeds")
# tied fixture on the z-scored input: does the tied column change under an affine map (std::sort order)?
for E in [1, 10]:
    add(U[E], None, "logistic_maps", 256, "pipeline", f"tied-E{E}-Lfull", "kernel_xmap")
ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids))
json.dump({"family": "ccm", "runs": runs}, open("/media/dan/Data/git/pyspi/audit/checks/manifest/ccm.json", "w"), indent=1)
print(len(runs))
