import sys, time, numpy as np, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import make_data
from pyspi.data import Data
from pyspi.statistics.causal import ConvergentCrossMapping as C
for T in (256,1024):
  x=make_data.load('logistic_maps_chaotic',T)['x']
  for E in (1,10,None):
    if T==1024 and E!=10: continue
    d=Data(np.array(x),dim_order='ps')
    t=time.perf_counter(); S=C('mean',E).multivariate(d); print(T,E,round(time.perf_counter()-t,2), S[0,1],S[1,0])
