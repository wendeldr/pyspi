import sys, numpy as np, pandas as pd, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); import make_data, pyEDM
from scipy.stats import zscore
x=make_data.load('logistic_maps',256)['x']
for lab,z in [('raw',x),('zscore',zscore(x,axis=1,ddof=1))]:
    df=pd.DataFrame(np.concatenate([np.atleast_2d(np.arange(256)),z]).T,columns=['index','proc0','proc1'])
    for L in ('247','256'):
        vals=[pyEDM.CCM(dataFrame=df,E=10,columns='proc0',target='proc1',libSizes=L,sample=1,random=False)['proc1:proc0'].values[0] for _ in range(3)]
        print(lab,L,['%.15f'%v for v in vals])
