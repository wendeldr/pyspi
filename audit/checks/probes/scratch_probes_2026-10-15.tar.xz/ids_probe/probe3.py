import sys, numpy as np, io, contextlib
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
from pyspi.calculator import Calculator
np.random.seed(123)
with contextlib.redirect_stdout(io.StringIO()):
    calc = Calculator(configfile='/media/dan/Data/git/pyspi/pyspi/config.yaml')
s_after = np.random.get_state()
np.random.seed(1717); s_1717 = np.random.get_state()
print('full config: global RNG state after Calculator() == seed(1717) state:', all(np.array_equal(a, b) if isinstance(a, np.ndarray) else a == b for a, b in zip(s_after, s_1717)))
print('n spis', len(calc.spis), 'ids' in calc.spis)
# pipeline on dataset via Calculator with ids only config
X = np.load('/media/dan/Data/git/pyspi/audit/checks/data/nonlinear_dependence_T1024.npz')['x']
from pyspi.data import Data
with contextlib.redirect_stdout(io.StringIO()):
    c2 = Calculator(dataset=Data(X, dim_order='ps'), configfile=sys.argv[1]); c2.compute()
A = c2.table['ids'].to_numpy()
from pyspi.statistics.misc import InterDependenceScore
with contextlib.redirect_stdout(io.StringIO()):
    B = InterDependenceScore().multivariate(Data(X, dim_order='ps'))
print('Calculator table ids:\n', np.round(A, 6)); print('max |calc - direct| offdiag', np.nanmax(np.abs(A - B)))
# detrend pipeline on trending
Xt = np.load('/media/dan/Data/git/pyspi/audit/checks/data/trending_T1024.npz')['x']
with contextlib.redirect_stdout(io.StringIO()):
    a0 = InterDependenceScore().multivariate(Data(Xt, dim_order='ps'))
    a1 = InterDependenceScore().multivariate(Data(Xt, dim_order='ps', detrend=True))
print('trending n1d0 upper', a0[np.triu_indices(4,1)].round(4)); print('trending n1d1 upper', a1[np.triu_indices(4,1)].round(4))
