import numpy as np, math
# population IDS for standard bivariate Gaussian, Gauss-Hermite (probabilists') quadrature
xg, wg = np.polynomial.hermite_e.hermegauss(120); wg = wg / wg.sum()
f = lambda x, k: np.exp(-0.5 * x**2) * x**k / math.sqrt(math.factorial(k))
for rho in [0.3, 0.8]:
    # X = u, Y = rho u + sqrt(1-rho^2) v
    U, V = np.meshgrid(xg, xg, indexing='ij'); W = np.outer(wg, wg)
    X, Y = U, rho * U + math.sqrt(1 - rho**2) * V
    best = 0; arg = None
    for k in range(6):
        for l in range(6):
            fx, fy = f(X, k), f(Y, l)
            mx, my = (W * fx).sum(), (W * fy).sum()
            c = (W * (fx - mx) * (fy - my)).sum() / math.sqrt((W * (fx - mx)**2).sum() * (W * (fy - my)**2).sum())
            if abs(c) > best: best, arg = abs(c), (k, l)
    print(f'rho={rho}: population IDS = {best:.4f} at (k,l)={arg}')
