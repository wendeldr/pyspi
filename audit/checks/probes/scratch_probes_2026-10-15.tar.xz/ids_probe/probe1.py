import numpy as np, math, importlib, sys
# 1. reseed side effect
np.random.seed(0); a0 = np.random.random()
np.random.seed(0)
import pyspi
before = np.random.get_state()[2]
m = importlib.import_module('.statistics.misc', 'pyspi')
x1 = np.random.random()
np.random.seed(1717); ref = np.random.random()
print('seed0 first draw', a0, '| first draw after importing misc', x1, '| seed1717 first draw', ref, '| equal to 1717:', x1 == ref)
# re-import does not reseed
np.random.seed(0); importlib.import_module('.statistics.misc', 'pyspi'); print('re-import reseeds?', np.random.random() != a0)
from pyspi.statistics.misc import InterDependenceScore
from pyspi.data import Data
spi = InterDependenceScore()
print('params', spi._num_terms, spi._p_norm, spi._bandwidth_term, spi.labels, spi.issigned(), type(spi).__mro__)

def ref_ids(X, K=6, B=0.5, p='max'):
    # X: (P, T); from scratch: Taylor features of Gaussian kernel, Pearson corr per pair, max abs
    P, T = X.shape
    F = np.stack([np.exp(-B*X**2) * X**k / math.sqrt(math.factorial(k)) for k in range(K)], 1)  # P,K,T
    F = F - F.mean(-1, keepdims=True)
    nrm = np.sqrt((F**2).sum(-1))
    out = np.zeros((P, P))
    for i in range(P):
        for j in range(P):
            c = np.abs((F[i] @ F[j].T) / np.outer(nrm[i], nrm[j]))
            out[i, j] = c.max() if p == 'max' else (c.mean() if p == 1 else np.sqrt((c**2).mean()))
    return out

base = '/media/dan/Data/git/pyspi/audit/checks/data/'
for name in ['iid_gaussian', 'bivariate_gaussian', 'nonlinear_dependence', 'anm', 'delayed_noise', 'scaled_offset', 'logistic_maps']:
    for T in [64, 256, 1024, 4096]:
        X = np.load(f'{base}{name}_T{T}.npz')['x']
        d = Data(X, dim_order='ps', normalise=True)
        A = spi.multivariate(d)
        Z = np.squeeze(d.to_numpy(), 2)
        R = ref_ids(Z)
        off = ~np.eye(len(A), dtype=bool)
        print(f'{name:22s} T={T:5d} diag={np.diag(A).round(12)} max|A-ref|={np.abs(A-R)[off].max():.2e} max|A-A^T|={np.abs(A-A.T).max():.2e} offdiag mean={A[off].mean():.4f} min={A[off].min():.4f} max={A[off].max():.4f}')
