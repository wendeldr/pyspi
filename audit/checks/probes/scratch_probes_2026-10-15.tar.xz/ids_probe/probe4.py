import numpy as np, math
rng = np.random.default_rng(5)
def feats(x):
    x = (x - x.mean()) / x.std(ddof=1)
    F = np.stack([np.exp(-0.5 * x**2) * x**k / math.sqrt(math.factorial(k)) for k in range(6)])
    F = F - F.mean(1, keepdims=True); return F / np.sqrt((F**2).sum(1, keepdims=True))
for T in [64, 256, 1024, 4096]:
    v = []
    for r in range(400):
        a, b = feats(rng.standard_normal(T)), feats(rng.standard_normal(T))
        v.append(np.abs(a @ b.T).max())
    v = np.array(v); print(f'T={T} null IDS mean={v.mean():.4f} sd={v.std():.4f} q95={np.quantile(v,.95):.4f} mean*sqrt(T)={v.mean()*math.sqrt(T):.3f}')
