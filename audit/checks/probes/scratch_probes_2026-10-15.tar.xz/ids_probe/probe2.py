import numpy as np, warnings
from pyspi.lib.ids.dependence import compute_IDS
from pyspi.statistics.misc import InterDependenceScore
from pyspi.data import Data
base = '/media/dan/Data/git/pyspi/audit/checks/data/'
ld = lambda n, T: np.load(f'{base}{n}_T{T}.npz')['x']
zs = lambda X: (X - X.mean(1, keepdims=True)) / X.std(1, ddof=1, keepdims=True)
mm8 = lambda X: 8 * (X - X.min(1, keepdims=True)) / (X.max(1, keepdims=True) - X.min(1, keepdims=True))
off = lambda A: A[~np.eye(len(A), dtype=bool)].reshape(len(A), -1)
np.set_printoptions(precision=4, suppress=True, linewidth=150)
# preprocessing variants: pyspi z-score vs paper min-max [0,8]
for n in ['iid_gaussian', 'bivariate_gaussian', 'nonlinear_dependence', 'anm', 'contaminated']:
    for T in [256, 4096]:
        X = ld(n, T)
        a = compute_IDS(zs(X).T); b = compute_IDS(mm8(X).T)
        print(f'{n:22s} T={T} zscore upper={a[np.triu_indices(len(a),1)]}  minmax[0,8] upper={b[np.triu_indices(len(b),1)]}')
# kernel scale dependence
X = zs(ld('nonlinear_dependence', 1024))
for s in [0.3, 1, 3]:
    print('scale', s, compute_IDS((s * X).T)[0, 1], compute_IDS((s * X).T)[2, 3])
# shift dependence
print('shift +2 on x0:', compute_IDS(np.vstack([X[0] + 2, X[1]]).T)[0, 1], 'vs', compute_IDS(X[:2].T)[0, 1])
# sign flip invariance
Y = X.copy(); Y[1] = -Y[1]
print('sign flip max diff', np.abs(compute_IDS(X.T) - compute_IDS(Y.T)).max())
# bandwidth: code exp(-B y^2) y^k/sqrt(k!) vs canonical eq 6 with B_paper = sqrt(1/(2B)) incl B^m factor
import math
def canon(X, Bp, K=6):
    F = np.stack([np.exp(-X**2 / (2 * Bp**2)) * X**m / (math.sqrt(math.factorial(m)) * Bp**m) for m in range(K)], 1)
    F = F - F.mean(-1, keepdims=True); n = np.sqrt((F**2).sum(-1)); P = len(X)
    return np.array([[np.abs(F[i] @ F[j].T / np.outer(n[i], n[j])).max() for j in range(P)] for i in range(P)])
for B in [0.25, 0.5, 1.0]:
    print('B', B, 'max |code - eq6(Bp=sqrt(1/2B))|', np.abs(compute_IDS(X.T, bandwidth_term=B) - canon(X, math.sqrt(1 / (2 * B)))).max())
# constant column
Xc = np.vstack([X[0], np.ones(X.shape[1]) * 3.0, X[1]])
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter('always')
    print('constant col kernel IDS:\n', compute_IDS(Xc.T), [str(x.message)[:60] for x in w])
try:
    d = Data(Xc, dim_order='ps', normalise=True)
    print('pipeline const:', InterDependenceScore().multivariate(d))
except Exception as e:
    print('pipeline const error', type(e), e)
# unsupported pnorm
r = compute_IDS(X.T, p_norm=3); print('pnorm=3 shape', r.shape)
r = compute_IDS(X.T, p_norm='2'); print("pnorm='2' shape", r.shape)
print('pnorm=1', off(compute_IDS(X.T, p_norm=1))[0], 'pnorm=2', off(compute_IDS(X.T, p_norm=2))[0])
# term-pair achieving the max: which (k,l)
from pyspi.lib.ids.numpy_dependence import transform, center
for n in ['bivariate_gaussian', 'nonlinear_dependence', 'iid_gaussian']:
    Z = zs(ld(n, 4096)); Xt = center(transform(Z.T)); C = np.abs(np.corrcoef(Xt.T)).reshape(6, len(Z), 6, len(Z))
    print(n, 'argmax (k,l) for pair (0,1):', np.unravel_index(C[:, 0, :, 1].argmax(), (6, 6)), 'feature-feature corr of same variable (term0 vs term2):', C[0, 0, 2, 0].round(3), 'term1 vs term3', C[1,0,3,0].round(3))
# effective rho: Gaussian rho=0.8, linear term corr vs IDS
Z = zs(ld('bivariate_gaussian', 4096)); print('pearson(2,3)', np.corrcoef(Z[2], Z[3])[0, 1], 'IDS', compute_IDS(Z.T)[2, 3], ' pearson(0,1)', np.corrcoef(Z[0], Z[1])[0,1], 'IDS', compute_IDS(Z.T)[0, 1])
