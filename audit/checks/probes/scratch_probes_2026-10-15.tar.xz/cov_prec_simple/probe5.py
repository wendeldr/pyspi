import numpy as np, warnings
warnings.filterwarnings("ignore")
from pyspi.data import Data
from pyspi.statistics import basic
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
for name in ["cointegrated","sparse_precision","bivariate_gaussian","nonlinear_dependence"]:
  for T in [1024]:
    x = np.load(D+f"{name}_T{T}.npz")["x"]; dat = Data(x)
    out=[]
    for est in ["EmpiricalCovariance","LedoitWolf","OAS","ShrunkCovariance"]:
        A = basic.Precision(estimator=est).multivariate(dat); out.append(f"{est}={np.nanmax(np.abs(A)):.3f}")
    print(name, T, "max|prec off-diag|:", ", ".join(out))
z = np.load(D+"sparse_precision_T4096.npz"); x=z["x"]
A = basic.Precision().multivariate(Data(x, normalise=False))
print("sparse_precision T4096 kernel prec row0", np.round(A[0],3), " truth row0", z["precision_true"][0])
A = basic.Precision().multivariate(Data(x))
print("sparse_precision T4096 pipeline prec row0", np.round(A[0],3))
