import numpy as np, warnings, json
warnings.filterwarnings("ignore")
from pyspi.data import Data
from pyspi.statistics import basic
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
m = json.load(open(D+"MANIFEST.json"))
best = {}
for f in m["files"]:
    x = np.load(D+f["file"])["x"]; dat = Data(x)
    for est in ["EmpiricalCovariance","LedoitWolf","OAS","ShrunkCovariance"]:
        A = basic.Precision(estimator=est).multivariate(dat); v = np.nanmax(np.abs(A))
        if v > best.get(est, (0,''))[0]: best[est] = (v, f["file"])
# D Theta D check for sparse_precision
z = np.load(D+"sparse_precision_T4096.npz"); x = z["x"]
K = basic.Precision().multivariate(Data(x, normalise=False))
d = np.sqrt(np.diag(np.cov(x, bias=True)))
print("kernel D*Theta*D [0,1]:", (np.diag(d)@np.where(np.isnan(K),0,K)@np.diag(d))[0,1])
print("argmax files:", best)
