import numpy as np, warnings, json
warnings.filterwarnings("ignore")
from pyspi.data import Data
from pyspi.statistics import basic
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
m = json.load(open(D+"MANIFEST.json"))
res = {}
for f in m["files"]:
    x = np.load(D+f["file"])["x"]
    dat = Data(x)
    for cls in (basic.Covariance, basic.Precision):
        for est in ["EmpiricalCovariance","LedoitWolf","OAS","ShrunkCovariance"]:
            A = cls(estimator=est).multivariate(dat)
            k = f"{cls.identifier}_{est}"
            a = np.nanmax(np.abs(A - A.T))
            r = res.setdefault(k, [0, 0, 0.0, 0.0])
            r[0] += 1; r[1] += int(a > 0); r[2] = max(r[2], a); r[3] = max(r[3], np.nanmax(np.abs(A)))
for k, v in res.items(): print(k, "runs", v[0], "asym runs", v[1], "max asym", v[2], "max |A|", round(v[3],3))
