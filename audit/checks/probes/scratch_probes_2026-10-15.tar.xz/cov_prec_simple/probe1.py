import numpy as np, sys, warnings
warnings.filterwarnings("ignore")
from pyspi.data import Data
from pyspi.statistics import basic
import sklearn, scipy
print("sklearn", sklearn.__version__, "scipy", scipy.__version__, "numpy", np.__version__)
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
z = np.load(D+"bivariate_gaussian_T1024.npz"); print(list(z.keys()))
x = z["x"]; T = x.shape[1]; P = x.shape[0]
dat = Data(x, normalise=True)  # pipeline
r = np.corrcoef(x)
for est in ["EmpiricalCovariance","LedoitWolf","OAS","ShrunkCovariance"]:
    C = basic.Covariance(estimator=est).multivariate(dat)
    m = dat.covariance[est]
    sh = getattr(m, "shrinkage_", getattr(m, "shrinkage", 0.0))
    pred = (1-sh)*(T-1)/T*r
    off = ~np.eye(P, dtype=bool)
    print(est, "shrinkage", sh, "max|C - (1-s)(T-1)/T r| off-diag", np.abs(C[off]-pred[off]).max(),
          "C[0,1]", C[0,1], "r01", r[0,1], "C[2,3]", C[2,3], "r23", r[2,3])
    print("   cached covariance_ diag after call:", np.diag(m.covariance_), " returned is cache:", C is m.covariance_)
    Pm = basic.Precision(estimator=est).multivariate(dat)
    Q = m.precision_
    print("   prec[2,3]", Pm[2,3], " partial corr from it", -Pm[2,3]/np.sqrt(np.diag(np.linalg.inv(np.where(np.isnan(C), (1-sh)*(T-1)/T + sh*(T-1)/T, C)))[[2,3]].prod()),
          " max asym", np.nanmax(np.abs(Pm-Pm.T)), " exact sym", np.array_equal(np.nan_to_num(Pm), np.nan_to_num(Pm.T)))
    Csq = basic.Covariance(estimator=est, squared=True).multivariate(dat)
    print("   sq == square:", np.array_equal(Csq, np.square(C), equal_nan=True))
    Psq = basic.Precision(estimator=est, squared=True).multivariate(dat)
    print("   prec sq == square:", np.array_equal(Psq, np.square(Pm), equal_nan=True))
