import numpy as np, warnings
warnings.filterwarnings("ignore")
from pyspi.data import Data
from pyspi.statistics import basic
import sklearn.covariance as skc
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
def zs(x): return (x - x.mean(1, keepdims=True))/x.std(1, ddof=1, keepdims=True)
# 1) OAS: sklearn vs Chen 2010 eq.23 (with 2/p terms) and LW from scratch
for name in ["bivariate_gaussian","sparse_precision","iid_gaussian"]:
  for T in [64,1024]:
    x = np.load(D+f"{name}_T{T}.npz")["x"]; X = zs(x).T; n,p = X.shape
    Xc = X - X.mean(0); S = Xc.T@Xc/n
    trS2 = np.trace(S@S); trS = np.trace(S)
    chen = min(((1-2/p)*trS2 + trS**2)/((n+1-2/p)*(trS2 - trS**2/p)), 1.0)
    skl_formula = min((trS2 + trS**2)/((n+1)*(trS2 - trS**2/p)), 1.0)
    o = skc.OAS().fit(X).shrinkage_
    # LW 2004 lemma 3.2/3.3/3.4, normalised Frobenius ||A||^2 = tr(AA^T)/p
    m = trS/p; F = lambda A: np.trace(A@A.T)/p
    d2 = F(S - m*np.eye(p))
    b2bar = sum(F(np.outer(xk,xk)-S) for xk in Xc)/n**2
    b2 = min(b2bar, d2); lw = b2/d2
    print(f"{name} T={T} p={p}: OAS sklearn={o:.6g} skl-formula={skl_formula:.6g} Chen-eq23={chen:.6g} | LW sklearn={skc.LedoitWolf().fit(X).shrinkage_:.10g} scratch={lw:.10g}")
# 2) Singular covariance: shared_envelope (x2 == x0) and P > T
x = np.load(D+"shared_envelope_T256.npz")["x"]
print("x2==x0 bitwise:", np.array_equal(x[0], x[2]))
dat = Data(x)
for est in ["EmpiricalCovariance","LedoitWolf","OAS","ShrunkCovariance"]:
    Pm = basic.Precision(estimator=est).multivariate(dat)
    m = dat.covariance[est]
    ev = np.linalg.eigvalsh(np.where(np.isnan(m.covariance_), 0, m.covariance_) + np.diag(np.full(4, np.nan)) if False else m.precision_)
    print(est, "prec row0:", np.round(Pm[0],4), " eig(prec):", np.round(ev,4))
rng = np.random.default_rng(0)
x = rng.standard_normal((8, 5)); dat = Data(x)
Pm = basic.Precision(estimator="EmpiricalCovariance").multivariate(dat)
S = dat.covariance["EmpiricalCovariance"]
print("P=8>T=5 prec_Empirical finite:", np.isfinite(Pm[~np.eye(8,dtype=bool)]).all(), "max|.|", np.nanmax(np.abs(Pm)))
