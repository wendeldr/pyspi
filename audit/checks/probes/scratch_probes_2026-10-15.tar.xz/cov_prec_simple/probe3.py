import numpy as np, warnings
warnings.filterwarnings("ignore")
from pyspi.data import Data
from pyspi.statistics import basic
import sklearn.covariance as skc
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
for T in [256, 4096]:
  x = np.load(D+f"shared_envelope_T{T}.npz")["x"]
  dat = Data(x)
  for est in ["EmpiricalCovariance","LedoitWolf","OAS","ShrunkCovariance"]:
    Pm = basic.Precision(estimator=est).multivariate(dat)
    S = skc.EmpiricalCovariance().fit(dat.to_numpy(squeeze=True).T).covariance_
    print(T, est, "prec row0:", np.round(Pm[0],5), " eig(S_emp):", np.round(np.linalg.eigvalsh(S),8) if est=="EmpiricalCovariance" else "")
rng = np.random.default_rng(0)
x = rng.standard_normal((8, 5)); dat = Data(x)
Pm = basic.Precision(estimator="EmpiricalCovariance").multivariate(dat)
print("P=8>T=5 prec_Empirical finite:", np.isfinite(Pm[~np.eye(8,dtype=bool)]).all(), "max|.|", np.nanmax(np.abs(Pm)))
# iid null: LW/OAS shrinkage=1 gives exactly-zero off-diagonals?
for T in [64,256,1024,4096]:
  x = np.load(D+f"iid_gaussian_T{T}.npz")["x"]; dat = Data(x)
  out = []
  for est in ["LedoitWolf","OAS"]:
    C = basic.Covariance(estimator=est).multivariate(dat); Pm = basic.Precision(estimator=est).multivariate(dat)
    out.append(f"{est}: s={dat.covariance[est].shrinkage_:.4g} max|cov off|={np.nanmax(np.abs(C)):.3g} max|prec off|={np.nanmax(np.abs(Pm)):.3g}")
  print("iid T", T, " | ".join(out))
# kernel path (normalise=False) on scaled_offset: cov = MLE covariance of raw, not correlation
z = np.load(D+"scaled_offset_T1024.npz"); x = z["x"]
C = basic.Covariance().multivariate(Data(x, normalise=False))
print("scaled_offset kernel cov[0,1]", C[0,1], " np.cov bias", np.cov(x, bias=True)[0,1], " pipeline", basic.Covariance().multivariate(Data(x))[0,1], " corr", np.corrcoef(x)[0,1])
