import sys, warnings, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/tests')
from pyspi.calculator import Calculator
X=np.random.default_rng(0).standard_normal((6,256))
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter('always')
    c=Calculator(dataset=X, configfile=sys.argv[1]); c.compute()
for x in w:
    if 'Caught' in str(x.message): print(x.message)
print(list(c.spis.keys()))
for k in c.spis: t=c.table[k]; print(k, t.shape, t.isna().all().all())
