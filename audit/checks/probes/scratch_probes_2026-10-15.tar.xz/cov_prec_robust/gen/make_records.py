import yaml
from pathlib import Path
OUT = Path('/media/dan/Data/git/pyspi/audit/records')
SK = '.venv/lib/python3.12/site-packages/sklearn/covariance'
OLD = 'https://raw.githubusercontent.com/scikit-learn/scikit-learn/0.24.1/sklearn/covariance/_robust_covariance.py'

MCD_CANON_REF = ('Rousseeuw P.J. 1985, "Multivariate estimation with high breakdown point", in Mathematical Statistics and Applications Vol. B, 283-297 (MCD definition); '
                 'Rousseeuw P.J. & Van Driessen K. 1999, Technometrics 41(3):212-223 (FAST-MCD: C-step theorem, raw consistency factor med(d^2)/chi2_{p,0.5}, '
                 'reweighting with hard weights d^2 <= chi2_{p,0.975}); consistency factor c_alpha = alpha / F_{chi2_{p+2}}(chi2_{p,alpha}): Croux C. & Haesbroeck G. 1999, '
                 'J Multivar Anal 71:161-190; small-sample factors: Pison G., Van Aelst S., Willems G. 2002, Metrika 55:111-123')
MCD_CANON_DEF = ('Raw MCD: among all h-subsets (default h = floor((n+p+1)/2), maximal breakdown) choose H minimising det(S_H); mu_raw = mean(H), Sigma_raw = c(p,h/n) * S_H. '
                 'Reweighted MCD: w_i = 1[d^2(x_i; mu_raw, Sigma_raw) <= chi2_{p,0.975}], mu = weighted mean, Sigma = c(p,0.975) * weighted sample covariance '
                 '(robustbase uses divisor sum(w)-1 and optional small-sample factors). Off-diagonal Sigma_ij is a robust, Gaussian-consistent covariance.')
PREC_CANON_DEF = ('Omega = Sigma_MCD^{-1} (reweighted robust MCD scatter, see Covariance unit); the partial correlation is rho_ij|rest = -Omega_ij / sqrt(Omega_ii Omega_jj) '
                  '(Whittaker 1990, Graphical Models in Applied Multivariate Statistics, ch. 5; Lauritzen 1996, Graphical Models). Omega_ij itself is not bounded and has the '
                  'opposite sign of the partial correlation.')
PREC_CANON_REF = MCD_CANON_REF + '; precision -> partial correlation: Whittaker J. 1990, Graphical Models in Applied Multivariate Statistics, Wiley, ch. 5 (Prop. 5.7.1 scaled-inverse identity)'

DOC_COV = ('supplement §1.1.1, pp.3-4: "Due to the z-scoring of the time series, the correlation and covariance matrices are equivalent and thus the covariance statistic is within [-1, 1]. '
           'We use v0.24.1 of scikit-learn [2] ... the elliptic envelope (EllipticEnvelope) [3] and the minimum covariance determinant (MinCovDet) methods for outlier removal"; '
           '[3] = Rousseeuw & Van Driessen 1999 Technometrics 41:212. Keywords "undirected, linear, signed, multivariate, contemporaneous". GitBook basic-statistics.md:21-25 same text '
           '(links to sklearn EllipticEnvelope / MinCovDet pages; no version). The -sq variant is not described in the supplement (only items 2/3 cov_EllipticEnvelope, cov_MinCovDet).')
DOC_PREC = ('supplement §1.1.2, p.4: "The precision matrix is the matrix inverse of the covariance matrix ... For normalized time-series data, the precision matrix is equivalent to the partial '
            'correlation between each pairwise time series, conditioned on all other time series, and is within [-1, 1]. The precision matrix is computed via the same module as the covariance matrix '
            '(in scikit-learn [2]), and has the same estimators." Items 10 prec_EllipticEnvelope, 11 prec_MinCovDet. GitBook basic-statistics.md:107 same text. The -sq variant is not described.')

DELEGATE = 'scikit-learn==1.9.1 (scipy==1.17.1 linalg.pinvh, numpy==2.5.4)'

def common_trace(kind, est):
    cls = 'Covariance' if kind == 'covariance' else 'Precision'
    t = [
        'pyspi/config.yaml:4-36 (Covariance) and :39-71 (Precision) list estimator EllipticEnvelope / MinCovDet with and without squared: True; pyspi/calculator.py:226-244 _load_yaml imports (:226 importlib.import_module, :243 getattr(module, fcn)(**params)) '
        'the module and instantiates getattr(module, fcn)(**params)',
        'pyspi/data.py:184-195 preprocessing before any SPI: optional scipy.signal.detrend(axis=1), then scipy.stats.zscore(axis=1, ddof=1, nan_policy="omit") over the FULL sample (outliers included); '
        ':199-203 NaN after preprocessing raises ValueError',
        'pyspi/calculator.py:294 S = self._spis[spi].multivariate(self.dataset); :297 np.fill_diagonal(S, np.nan); :300 self._table[spi] = S (row i, column j)',
        f'pyspi/statistics/basic.py:{"57-63 class Covariance(Estimators) identifier \"cov\", kind=\"covariance\"" if kind=="covariance" else "66-72 class Precision(Estimators) identifier \"prec\", kind=\"precision\""}',
        'pyspi/statistics/basic.py:9-29 class Estimators(Undirected, Signed): squared -> identifier "-sq" prefix, labels + ["unsigned"], issigned -> False; no estimator hyperparameters are forwarded',
        'pyspi/statistics/basic.py:46-47 Estimators.multivariate overrides Undirected.multivariate (pyspi/base.py:132-138 mirror never runs; REVIEW M1); parse_multivariate pyspi/base.py:51-68',
        f'pyspi/statistics/basic.py:31-44 _from_cache: cache key data.covariance["{est}"] (estimator name only, shared by cov/prec and squared/unsquared); on miss z = data.to_numpy(squeeze=True).T '
        f'(T x P, columns = processes), warnings.simplefilter("ignore") (:37-38, silences sklearn rank / determinant warnings), getattr(cov, "{est}")().fit(z) with ALL defaults (:39) -> '
        'random_state=None, support_fraction=None, assume_centered=False, store_precision=True',
        f'pyspi/statistics/basic.py:49 matrix = getattr(mycov, "{kind}_") (the cached array itself, no copy); :50 np.fill_diagonal(matrix, np.nan) mutates the cached fitted attribute in place; '
        ':51-54 returns np.square(matrix) if squared else matrix',
    ]
    if est == 'EllipticEnvelope':
        t += [
            f'{SK}/_elliptic_envelope.py:15 class EllipticEnvelope(OutlierMixin, MinCovDet); :149-164 __init__ defaults store_precision=True, assume_centered=False, support_fraction=None, '
            'contamination=0.1, random_state=None, all except contamination passed to MinCovDet.__init__',
            f'{SK}/_elliptic_envelope.py:166-185 fit: :183 super().fit(X) (= MinCovDet.fit, unchanged); :184 self.offset_ = np.percentile(-self.dist_, 100*contamination) only sets the outlier '
            'threshold; covariance_ / precision_ are not touched',
        ]
    t += [
        f'{SK}/_robust_covariance.py:770-822 MinCovDet.fit: :788 validate_data; :789 random_state = check_random_state(None) -> global np.random.mtrand._rand '
        '(sklearn/utils/validation.py:1477-1478); :792-795 rank warning; :797-802 fast_mcd raw estimates; :818 correct_covariance(X) (return value discarded, only dist_ rescaled); :820 reweight_covariance(X)',
        f'{SK}/_robust_covariance.py:399-618 fast_mcd: :475-476 n_support = min(ceil(0.5*(n+p+1)), n) (ceil, not floor); :511-589 n>500 path (n//300 random subsets, 500 total trials, '
        'merge to <=1500 samples, permutations from random_state); :590-616 n<=500 path: 30 random starts x 2 C-steps, best 10 refined to convergence',
        f'{SK}/_robust_covariance.py:114-213 _c_step: :129 random initial support random_state.permutation(n)[:h]; :153-170 concentration steps on det(cov(H)) with dist via linalg.pinvh; '
        ':143 cov_computation_method = empirical_covariance (MLE, bias=1)',
        f'{SK}/_robust_covariance.py:253-396 select_candidates: keeps the `select` lowest-determinant C-step results',
        f'{SK}/_robust_covariance.py:824-861 correct_covariance: :858 consistency_factor = _consistency_factor(p, h/n); :860 dist_ /= factor; '
        f'{SK}/_robust_covariance.py:216-250 _consistency_factor: c = alpha / chi2.cdf(chi2.ppf(alpha, p), p+2) (Croux & Haesbroeck 1999)',
        f'{SK}/_robust_covariance.py:863-925 reweight_covariance: :906 mask = dist_ < chi2(p).isf(0.025); :910 location = mean(mask); :911-913 empirical_covariance(data[mask]) (MLE); '
        ':917-920 _set_covariance(cov * _consistency_factor(p, 0.975))',
        f'{SK}/_empirical_covariance.py:65-107 empirical_covariance: np.cov(X.T, bias=1); :196-215 _set_covariance stores covariance_ and precision_ = scipy.linalg.pinvh(covariance, check_finite=False) (:213)',
        f'documented version for comparison: {OLD} (sklearn 0.24.1) correct_covariance :707 correction = np.median(self.dist_) / chi2(p).isf(0.5); reweight_covariance :747 mask, :756 '
        'self._set_covariance(covariance_reweighted) with NO consistency factor',
    ]
    return t

def probe_note():
    return ('probe scripts in /tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/cov_prec_robust/probes/ (p1.py-p4.py)')

CAND_RNG = ('CANDIDATE (reproducibility magnitude, elaborates tests/README.md stochastic marker): seed sensitivity is large, not last-bit. p1.py, 20 seeds of np.random.seed(s) then MinCovDet().fit on z-scored data: '
            'max spread of any covariance_ entry = 0.155 (iid_gaussian T=64), 0.341 (sparse_precision T=64), 0.070-0.163 (T=256), 0.015-0.029 (T=1024), 0.0035-0.0087 (T=4096). '
            'p3.py, two fresh-process Calculator runs (config with only the 8 robust SPIs, no misc import so no np.random.seed(1717)): sparse_precision T=64 cov_EllipticEnvelope[0,1] = 0.398263121046 '
            'then 0.321753737284; delayed_noise T=256 cov_MinCovDet[0,1] = -0.098336054359 then -0.088116611885. Full default config imports pyspi.statistics.misc -> pyspi/lib/ids/numpy_dependence.py:11-12 '
            'np.random.seed(1717) at import, which (hypothesis, not probed) makes a full-config run reproducible only for a fixed SPI order and set.')
CAND_EE = ('CANDIDATE (redundancy, confirms briefing hypothesis 1): EllipticEnvelope covariance_/precision_ are bit-identical to MinCovDet given the same global RNG state. p1.py: np.random.seed(0) before each fit, '
           'np.array_equal(MCD.covariance_, EE.covariance_) and of precision_ -> True on iid_gaussian, sparse_precision, contaminated, delayed_noise at T=64,256,1024,4096 (16/16). Code reason: '
           '_elliptic_envelope.py:183 super().fit(X), :184 only sets offset_. In a Calculator pass the two are fitted at different points of the global RNG stream (separate cache keys, basic.py:33), so '
           '*_EllipticEnvelope vs *_MinCovDet differ only by RNG noise: p3.py max|cov_EE - cov_MCD| = 0.0765 (sparse_precision T=64), 0.0519 (iid T=256), 0.0092-0.0142 (T=1024), and exactly 0 when both '
           'land on the same optimum. The EEG selection keeps prec_EllipticEnvelope and prec_MinCovDet (and -sq) as separate features of one estimator.')
CAND_VER = ('CANDIDATE (version drift from documented sklearn 0.24.1): sklearn 1.9.1 replaces the raw median correction (0.24.1 :707) by the Croux-Haesbroeck factor (_robust_covariance.py:858) and '
            'multiplies the reweighted covariance by c(p,0.975) (:917-920; absent in 0.24.1 :756). c(p,0.975) = 1.10447 (p=2), 1.07848 (p=3), 1.06447 (p=4), 1.05553 (p=5) (p4.py). '
            'p4.py from-scratch emulation of the 0.24.1 steps on the same raw fit: median off-diagonal ratio new/old = 1.0555 (iid_gaussian p=5), 1.0645 (bivariate_gaussian p=4), 1.0969-1.1045 '
            '(contaminated p=2); max abs entry change 0.0065-0.142; reweighted support size can differ (sparse_precision T=64: 57 vs 53). The emulation is a reading of the 0.24.1 source, not a run of 0.24.1.')
CAND_SCALE_COV = ('CANDIDATE (documented range claim false): the robust scatter of z-scored data is not a correlation matrix; diag is not 1 and pyspi does not normalise. p1.py diag(covariance_): '
                  'contaminated T=4096 [0.193, 0.189] (z-score uses the contaminated SD) so cov_MinCovDet[0,1] = 0.151 although the clean-core correlation is ~0.8 (0.151/sqrt(0.193*0.189) ~ 0.79); '
                  'iid_gaussian T=64 diag [1.172 1.001 0.853 0.429 0.772]. Values above 1 occur: p2.py max |off-diag| over 20 seeds = 1.141 (cointegrated T=256), 1.008 (trending T=256); '
                  'shared_envelope T=64 (x2 = copy of x0, rank deficient) cov[0,2] = 1.0478 = (63/64) * c(4,0.975) because every sample passes reweighting and the MLE covariance is inflated by 1.0645.')
CAND_PREC = ('CANDIDATE (documented definition false; affects every prec_* estimator, not only robust ones): pyspi returns raw precision entries, not partial correlations. p2.py bivariate_gaussian T=256 '
             'seed 42: prec_MinCovDet[2,3] = -2.6276 while -Omega_23/sqrt(Omega_22 Omega_33) = +0.8126 (opposite sign, |value| > 1). p2.py max |prec off-diag| over 20 seeds: 3.99 (bivariate_gaussian T=64), '
             '32.7 (cointegrated T=256), 368.3 (narrowband_f0-0.25 T=64).')
CAND_SING = ('CANDIDATE (silent degenerate output): basic.py:37-38 suppress all warnings, including sklearn "covariance matrix ... not full rank" (_robust_covariance.py:792-795) and '
             '"Determinant has increased" (:188-195). For rank-deficient input the precision is a pseudo-inverse: p2.py shared_envelope T=64 (x2 == x0) gives prec[0,2] = +0.345 and prec[0,0] = 0.345 '
             '(pinvh of a singular scatter) with no warning reaching the user.')
CAND_CACHE = ('CANDIDATE (side effect, value-neutral in Calculator): basic.py:49-50 return the cached fitted array and NaN its diagonal in place. p2.py: Covariance(MinCovDet).multivariate(d) is '
              'd.covariance["MinCovDet"].covariance_ -> True and the cached diag becomes [nan nan nan nan]; Precision then reads precision_ from the same fit (True), so cov and prec are mutually consistent '
              'within one Data object. A caller that edits the returned unsquared matrix edits the cache.')
CAND_H = ('CANDIDATE (minor variant): default h = ceil((n+p+1)/2) (_robust_covariance.py:476) vs the canonical floor((n+p+1)/2) (Rousseeuw & Leroy 1987; robustbase h.alpha.n(0.5,n,p)); '
          'they differ by 1 when n+p+1 is odd (p1.py raw support 34 for contaminated T=64, p=2: 67/2 -> 34 vs floor 33). Reweighted covariance uses the MLE divisor n_w (empirical_covariance bias=1) '
          'whereas robustbase cov.wt uses n_w - 1 (factor 47/46 ~ 1.02 at T=64).')

def checks(kind, est):
    other = 'MinCovDet' if est == 'EllipticEnvelope' else 'EllipticEnvelope'
    c = []
    c.append(dict(datasets=['iid_gaussian', 'sparse_precision', 'contaminated', 'bivariate_gaussian', 'delayed_noise'], path='kernel',
        reference=('from-scratch numpy/scipy re-implementation of the correction and reweighting steps (no sklearn import inside the reference): given raw_location_/raw_covariance_/raw_support_ '
                   'taken from the pyspi fit, d2 = Mahalanobis via np.linalg.solve, c_raw = alpha/chi2.cdf(chi2.ppf(alpha,p),p+2) with alpha = h/n, mask = d2/c_raw < chi2.isf(0.025,p), '
                   f'Sigma = c(p,0.975) * MLE covariance of masked rows, Omega = np.linalg.inv(Sigma); compare to the off-diagonal {kind} output'),
        reference_kind='independent-impl', criterion='tolerance',
        expected_outcome=f'off-diagonal {kind} entries agree to <= 1e-10 relative at every T (isolates sklearn correction/reweight from the stochastic raw search; input raw support is sklearn-derived and is the only shared element)'))
    c.append(dict(datasets=['iid_gaussian', 'sparse_precision', 'contaminated', 'delayed_noise'], path='kernel',
        reference=('from-scratch C-step concentration in numpy (Rousseeuw & Van Driessen 1999 Theorem 1): 2000 random h-subsets, h = ceil((n+p+1)/2) as sklearn, iterate C-steps to convergence; '
                   'record the minimum log det(S_H) found'),
        reference_kind='independent-impl', criterion='optimality',
        expected_outcome=('log det of sklearn raw_covariance_ (seeded fit) is <= the from-scratch best + 1e-9 on most datasets; report the gap per T. Hypothesis: gaps > 0 appear at T=64 and explain '
                          'the seed spread (0.155-0.341 at T=64)')))
    c.append(dict(datasets=['bivariate_gaussian', 'contaminated', 'sparse_precision', 'iid_gaussian'], path='pipeline',
        reference=('R robustbase::covMcd (robustbase 0.99.2, external package) on the same z-scored matrix, alpha chosen so h.alpha.n equals sklearn h, use.correction=FALSE, '
                   'initHsets = sklearn raw support (1-based) to remove search randomness; rescale robustbase cov by (n_w-1)/n_w to the MLE divisor'
                   + ('; invert in R with solve()' if kind == 'precision' else '')),
        reference_kind='external-pkg', criterion='tolerance',
        expected_outcome=('agreement to <= 1e-8 relative after the divisor rescale; any residual difference is attributable to robustbase consistency-factor choices and is reported, not tuned away. '
                          'Second run with robustbase default nsamp (own random search): statistical agreement, |diff| within the 20-seed sklearn spread')))
    c.append(dict(datasets=['iid_gaussian', 'sparse_precision', 'delayed_noise', 'contaminated'], path='kernel',
        reference=f'sklearn MinCovDet vs EllipticEnvelope under identical np.random.seed (same-lineage: both are sklearn; tests the redundancy claim, not correctness)',
        reference_kind='same-lineage', criterion='exact',
        expected_outcome=f'{kind}_ of {est} and {other} bit-identical at all T (probe already showed 16/16); in a seeded single Calculator pass the two identifiers differ only through RNG position'))
    c.append(dict(datasets=['iid_gaussian', 'sparse_precision', 'delayed_noise'], path='pipeline',
        reference='reproducibility study: 20 fresh-process Calculator runs (config with the 8 robust SPIs) and 20 np.random.seed values for MinCovDet().fit; numpy only for the summary',
        reference_kind='independent-impl', criterion='statistical',
        expected_outcome='report per-T max spread of each off-diagonal entry; expected (probe) ~0.1-0.35 at T=64 shrinking to <0.01 at T=4096; any run-to-run difference in an unseeded pass confirms non-determinism'))
    if kind == 'covariance':
        c.append(dict(datasets=['contaminated', 'bivariate_gaussian'], path='pipeline',
            reference=('analytic: contaminated truth clean_cov_true (rho = 0.8 core) and bivariate_gaussian cov_true; robust correlation r = C_ij/sqrt(C_ii C_jj) built from the pyspi fit diagonal '
                       '(diag recovered from a reseeded fit since pyspi NaNs it), compared with the true rho; also np.corrcoef on contaminated as the non-robust contrast'),
            reference_kind='analytic', criterion='statistical',
            expected_outcome=('robust correlation within 3 SE of 0.8 at T >= 1024 while np.corrcoef is far off (outliers at (6,-6)); the raw pyspi output cov_*[0,1] ~ 0.15 (not 0.8) on contaminated, '
                              'demonstrating the documented "covariance = correlation in [-1,1]" claim does not hold for this estimator')))
        c.append(dict(datasets=['cointegrated', 'trending', 'iid_gaussian'], path='pipeline',
            reference='range scan: numpy max/min of off-diagonal outputs over 20 seeds and all T',
            reference_kind='independent-impl', criterion='qualitative',
            expected_outcome='documented range [-1,1] violated: |cov| > 1 expected on cointegrated/trending at T=256 (probe 1.141, 1.008); cov-sq > 1 accordingly; diag of the fit not equal to 1'))
    else:
        c.append(dict(datasets=['sparse_precision', 'bivariate_gaussian'], path='pipeline',
            reference=('analytic: precision of the z-scored process Omega_z = S Omega S with S = diag(sqrt(diag(cov_true))) from precision_true / cov_true; partial correlation '
                       '-Omega_ij/sqrt(Omega_ii Omega_jj) (bivariate_gaussian pair (2,3): Omega_23 = -0.8/0.36 = -2.222, partial corr 0.8)'),
            reference_kind='analytic', criterion='statistical',
            expected_outcome=('pyspi prec_* tracks Omega_z (e.g. ~ -2.2 for the rho=0.8 pair, ~ -0.4*s_i*s_j on the sparse_precision tridiagonal, ~0 elsewhere) within sampling error at T >= 1024; it does '
                              'NOT equal the partial correlation (sign flipped, magnitude > 1), refuting the documented definition')))
        c.append(dict(datasets=['bivariate_gaussian', 'sparse_precision'], path='kernel',
            reference='numpy: max |P - P.T| of the returned matrix; np.linalg.inv of the fitted covariance (reseeded) vs returned precision',
            reference_kind='independent-impl', criterion='tolerance',
            expected_outcome='asymmetry at round-off level (probe 8.9e-16; REVIEW M2) and inverse agreement <= 1e-10 relative for full-rank inputs'))
        c.append(dict(datasets=['shared_envelope', 'narrowband_f0-0.25'], path='pipeline',
            reference='numpy: smallest eigenvalue / condition number of the fitted scatter (reseeded fit) and the returned precision',
            reference_kind='independent-impl', criterion='qualitative',
            expected_outcome='shared_envelope (x2 == x0) gives a singular scatter and a pseudo-inverse precision with no warning (probe prec[0,2] = +0.345); narrowband gives |prec| up to ~370'))
    c.append(dict(datasets=['bivariate_gaussian', 'delayed_noise'], path='pipeline',
        reference='direction/symmetry convention: numpy comparison of A with A.T and of A[i,j] with the (i,j) entry of a reseeded sklearn-free reference from check 1',
        reference_kind='independent-impl', criterion='direction',
        expected_outcome='undirected: A[i,j] = A[j,i] (exact for cov, round-off for prec), and A[i,j] is the (i,j) entry of the matrix fitted on columns ordered as processes; no lag or direction'))
    c.append(dict(datasets=['trending'], path='pipeline-detrend',
        reference='analytic cov_true_detrended (trending truth) via the same robust-correlation normalisation as above',
        reference_kind='analytic', criterion='statistical',
        expected_outcome='with detrend=True the robust estimate tracks cov_true_detrended (scaled to z-units); without detrend the trend dominates (probe |cov| up to 1.008 at T=256)'))
    return c

UNITS = {
 'basic.cov.EllipticEnvelope': ('covariance', 'EllipticEnvelope', ['cov_EllipticEnvelope', 'cov-sq_EllipticEnvelope']),
 'basic.cov.MinCovDet': ('covariance', 'MinCovDet', ['cov_MinCovDet', 'cov-sq_MinCovDet']),
 'basic.prec.EllipticEnvelope': ('precision', 'EllipticEnvelope', ['prec_EllipticEnvelope', 'prec-sq_EllipticEnvelope']),
 'basic.prec.MinCovDet': ('precision', 'MinCovDet', ['prec_MinCovDet', 'prec-sq_MinCovDet']),
}

for uid, (kind, est, ids) in UNITS.items():
    iscov = kind == 'covariance'
    name = ('Reweighted Minimum Covariance Determinant (FAST-MCD) robust covariance matrix entry' if iscov else
            'Off-diagonal entry of the inverse of the reweighted MCD robust covariance (robust precision matrix)')
    if est == 'EllipticEnvelope':
        name += ' (computed by sklearn EllipticEnvelope, an outlier detector whose fitted covariance is the MinCovDet estimate)'
    name += f'; {ids[1]} is its square'
    impl = (f'Data z-scored per channel over the full sample (ddof=1; optional detrend first). z (T x P) passed to sklearn {est}() with all defaults and random_state=None (global numpy RNG). '
            'FAST-MCD raw search: h = ceil((T+P+1)/2); T<=500: 30 random h-subsets x 2 C-steps, best 10 refined; T>500: random partition into T//300 subsets, 500 trials, merge on <=1500 samples. '
            'Raw distances divided by the Croux-Haesbroeck factor c(P,h/T); rows with d2 < chi2_{P,0.975} kept; Sigma = c(P,0.975) * MLE covariance (divisor n_w) of kept rows; '
            'precision_ = scipy.linalg.pinvh(Sigma). ')
    if est == 'EllipticEnvelope':
        impl += 'EllipticEnvelope.fit runs exactly MinCovDet.fit and then only sets offset_ (contamination=0.1 never affects covariance_/precision_). '
    impl += (f'pyspi returns the {"covariance_" if iscov else "precision_"} matrix as is (no normalisation to correlation{"" if iscov else " / partial correlation, no sign flip"}), diagonal set to NaN in place on the cached fit; '
             f'{ids[1]} returns its elementwise square. One fit per Data object per estimator name, shared by cov/prec and squared/unsquared identifiers.')
    dev_doc = []
    dev_doc.append('Version: documented sklearn v0.24.1, executed 1.9.1; the MCD correction and reweighting changed (raw median factor -> Croux-Haesbroeck factor; reweighted covariance now multiplied by c(P,0.975) = 1.055-1.104 for P=5..2), so values are not those of the documented version (probe p4.py, ratios 1.055-1.10).')
    if iscov:
        dev_doc.append('Range: documented "equivalent to correlation, within [-1,1]" is false for this estimator: the robust scatter of z-scored data has diagonal != 1 (0.19 on contaminated, 0.43-1.17 on iid T=64) and off-diagonals exceeding 1 occur (1.141 cointegrated T=256; 1.0478 rank-deficient shared_envelope).')
    else:
        dev_doc.append('Definition: documented "equivalent to the partial correlation ... within [-1,1]" is false: the raw precision entry is returned, Omega_ij = -rho_ij|rest * sqrt(Omega_ii Omega_jj), opposite in sign to the partial correlation and unbounded (probe -2.63 vs partial correlation +0.81; up to 368 on narrowband).')
    if est == 'EllipticEnvelope':
        dev_doc.append('Estimator identity: documented as a separate "elliptic envelope" outlier-removal method; its covariance/precision are exactly MinCovDet (bit-identical under equal RNG state), so the EllipticEnvelope and MinCovDet identifiers are the same quantity up to RNG noise.')
    dev_doc.append(f'{ids[1]} undocumented in the supplement. Stochastic output (global RNG) not documented in the supplement (documented in tests/README.md).')
    dev_can = ('Close variant of reweighted FAST-MCD: (1) the search is a stochastic approximation of the MCD optimum (inherent to FAST-MCD) but the random starts come from the global numpy RNG, '
               'so the selected h-subset and hence values vary run to run (spread up to 0.34 at T=64); (2) h = ceil((n+p+1)/2) instead of floor; (3) reweighted covariance uses the MLE divisor n_w '
               '(robustbase: n_w - 1) and no small-sample correction (Pison et al. 2002); (4) raw consistency factor is the asymptotic Croux-Haesbroeck factor rather than RVD 1999 median rescaling; '
               '(5) the input is z-scored with non-robust mean/SD over the full sample before the robust fit, so the output is a robust covariance in units of the contaminated SD, not a robust correlation.')
    if not iscov:
        dev_can += ' (6) precision via pseudo-inverse pinvh: for singular scatter (collinear channels) a Moore-Penrose inverse is returned silently instead of failing.'
    rng = ('cov: dimensionless (z-score units), signed, symmetric, unbounded in principle; typical |value| <= ~1.2 (observed max 1.141); cov-sq >= 0. Diagonal NaN. NaN for all entries only if the fit raises '
           '(e.g. "covariance of the support data is equal to 0", _robust_covariance.py:853-857), which Calculator converts to an all-NaN block.') if iscov else \
          ('prec: dimensionless (inverse z-score units), signed (sign opposite to partial correlation), symmetric up to round-off, unbounded (observed |value| up to 368 on narrowband_f0-0.25 T=64); '
           'prec-sq >= 0. Diagonal NaN. Finite pseudo-inverse values for singular scatter.')
    already = ('tests/README.md lines 106, 115-116 and 126 (tolerance-policy row: "sklearn robust covariance draws from the global numpy RNG; reproducible only via seed_all()", marker stochastic; '
               'CALC_E2E_SKIP of cov*/prec*MinCovDet because a single seeded pass draws in a different order); REVIEW M1 (Undirected mirror bypassed by cov/prec classes)')
    if not iscov:
        already += '; REVIEW M2 (precision last-bit reciprocal asymmetry from pinvh)'
    cands = [CAND_EE, CAND_RNG, CAND_VER]
    cands.append(CAND_SCALE_COV if iscov else CAND_PREC)
    if not iscov:
        cands.append(CAND_SING)
    cands += [CAND_CACHE, CAND_H]
    rec = dict(unit_id=uid, status='traced', correctness=dict(
        metric_name_standard=name,
        canonical_ref=MCD_CANON_REF if iscov else PREC_CANON_REF,
        canonical_definition=MCD_CANON_DEF if iscov else PREC_CANON_DEF,
        documented_definition=DOC_COV if iscov else DOC_PREC,
        delegate_lib=f'{DELEGATE}: sklearn.covariance.{est}().fit -> ' + ('MinCovDet.fit (via EllipticEnvelope.fit super call)' if est == 'EllipticEnvelope' else 'MinCovDet.fit') + f' -> fast_mcd, correct_covariance, reweight_covariance; attribute {kind}_',
        implemented_as=impl,
        implementation_trace=common_trace(kind, est),
        deviation_from_documented=' '.join(dev_doc),
        deviation_from_canonical=dev_can,
        units_and_range=rng,
        direction_convention=('undirected: A[i,j] = A[j,i] = (i,j) entry of the robust ' + ('covariance' if iscov else 'precision') +
                              ' matrix fitted on z (columns ordered as processes, basic.py:35); symmetry comes from the estimator (Undirected mirror bypassed, REVIEW M1); ' +
                              ('np.cov output exactly symmetric (probe max|C-C.T| = 0.0)' if iscov else 'pinvh output symmetric to round-off (probe max|P-P.T| = 8.9e-16)') + '; to confirm empirically in the check stage'),
        symmetry_expected='sym',
        already_documented=already,
        new_finding_candidates=cands,
        proposed_checks=checks(kind, est),
    ))
    (OUT / f'{uid}.yaml').write_text(yaml.safe_dump(rec, sort_keys=False, allow_unicode=True, width=200))
    print('wrote', uid)
