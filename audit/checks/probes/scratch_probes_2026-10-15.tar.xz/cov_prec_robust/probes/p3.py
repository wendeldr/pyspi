import numpy as np, sys
from pyspi.calculator import Calculator
out=[]
for name in ['sparse_precision','iid_gaussian','delayed_noise']:
  for T in [64,256,1024]:
    x=np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{name}_T{T}.npz')['x']
    calc=Calculator(dataset=x, configfile=sys.argv[1]); calc.compute(); t=calc.table
    ee=t['cov_EllipticEnvelope'].to_numpy(); mc=t['cov_MinCovDet'].to_numpy()
    out.append(f'{name} T={T} cov01 EE={ee[0,1]:.12f} MCD={mc[0,1]:.12f} maxdiff={np.nanmax(np.abs(ee-mc)):.3g}')
print('\n'.join(out))
