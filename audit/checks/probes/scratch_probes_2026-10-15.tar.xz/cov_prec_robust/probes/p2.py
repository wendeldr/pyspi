import numpy as np, warnings
import sklearn.covariance as skc
from pyspi.statistics import basic
from pyspi.data import Data
D='/media/dan/Data/git/pyspi/audit/checks/data/'
np.set_printoptions(precision=4, suppress=True, linewidth=150)
def load(n,T): return np.load(f'{D}{n}_T{T}.npz')
# A. pipeline outputs, cache sharing, mutation, identity
x=load('bivariate_gaussian',256)['x']
d=Data(x, normalise=True)
np.random.seed(42)
C=basic.Covariance(estimator='MinCovDet').multivariate(d)
fit=d.covariance['MinCovDet']
print('returned is cached covariance_ object:', C is fit.covariance_, '| cached diag now', np.diag(fit.covariance_))
P=basic.Precision(estimator='MinCovDet').multivariate(d)
print('prec from same cached fit:', P is fit.precision_)
print('C\n',C,'\nP\n',P)
Pq=basic.Precision(estimator='MinCovDet', squared=True).multivariate(d)
print('Psq == P**2 offdiag:', np.allclose(Pq, P**2, equal_nan=True))
# partial correlation vs precision
Pf=fit.precision_.copy(); 
import scipy.linalg as sl
Cfull=fit.covariance_.copy(); np.fill_diagonal(Cfull, np.nan)
print('precision asym max', np.nanmax(np.abs(P-P.T)), 'cov asym max', np.nanmax(np.abs(C-C.T)))
# recompute full precision for partial corr
np.random.seed(42); f2=skc.MinCovDet().fit(d.to_numpy(squeeze=True).T)
Pfull=f2.precision_; pc=-Pfull/np.sqrt(np.outer(np.diag(Pfull),np.diag(Pfull)))
print('partial corr (-P_ij/sqrt(PiiPjj))\n',pc)
print('bit-identical to cached fit when reseeded:', np.array_equal(f2.covariance_[~np.eye(4,dtype=bool)], fit.covariance_[~np.eye(4,dtype=bool)]))
# B. range: any cov offdiag beyond 1 over seeds at T=64
for n in ['bivariate_gaussian','sparse_precision','narrowband_f0-0.25','nonlinear_dependence','delayed_noise','gauss_ar1_pair','cointegrated','trending']:
    for T in [64,256]:
        z=Data(load(n,T)['x'],normalise=True).to_numpy(squeeze=True).T
        mx=0; mxp=0; dmin=9; dmax=0
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            for s in range(20):
                np.random.seed(s); m=skc.MinCovDet().fit(z)
                off=~np.eye(z.shape[1],dtype=bool)
                mx=max(mx,np.abs(m.covariance_[off]).max()); mxp=max(mxp,np.abs(m.precision_[off]).max())
                dmin=min(dmin,np.diag(m.covariance_).min()); dmax=max(dmax,np.diag(m.covariance_).max())
        print(f'{n:22s} T={T:4d} max|cov off| {mx:.3f}  max|prec off| {mxp:.3f} diag range [{dmin:.3f},{dmax:.3f}]')
# C. singular data
for T in [64,256]:
    x=load('shared_envelope',T)['x']; d=Data(x,normalise=True)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always'); np.random.seed(0); m=skc.MinCovDet().fit(d.to_numpy(squeeze=True).T)
    print('shared_envelope',T,'warnings:',[str(i.message)[:70] for i in w][:3])
    print(' cov\n',m.covariance_,'\n prec\n',m.precision_)
