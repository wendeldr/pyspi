import numpy as np, warnings, scipy.linalg as sl
from scipy.stats import chi2
import sklearn.covariance as skc
from sklearn.covariance._robust_covariance import _consistency_factor
from pyspi.data import Data
for p in [2,3,4,5]: print('p',p,'c(p,0.975)=%.5f'%_consistency_factor(p,0.975), ' raw c(p,h/n) n=64:%.4f'%_consistency_factor(p, np.ceil(0.5*(64+p+1))/64))
D='/media/dan/Data/git/pyspi/audit/checks/data/'
for n in ['iid_gaussian','sparse_precision','contaminated','bivariate_gaussian']:
  for T in [64,1024]:
    z=Data(np.load(f'{D}{n}_T{T}.npz')['x'],normalise=True).to_numpy(squeeze=True).T
    np.random.seed(0)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore'); m=skc.MinCovDet().fit(z)
    p=z.shape[1]
    # emulate sklearn 0.24.1 correction + reweight from the same raw estimates
    Xc=z-m.raw_location_; d=np.sum(Xc@sl.pinvh(m.raw_covariance_)*Xc,1)
    d=d/(np.median(d)/chi2(p).isf(0.5))
    mask=d<chi2(p).isf(0.025)
    cov24=np.cov(z[mask].T,bias=True)
    off=~np.eye(p,dtype=bool)
    print(f'{n} T={T} support new {m.support_.sum()} old-emul {mask.sum()} | max|cov191-cov0241| {np.abs(m.covariance_-cov24)[off].max():.4f} ratio offdiag median {np.median(m.covariance_[off]/cov24[off]):.4f}')
