import numpy as np, warnings, sys
from scipy.stats import chi2
import sklearn, sklearn.covariance as skc
from pyspi.statistics import basic
from pyspi.data import Data
D='/media/dan/Data/git/pyspi/audit/checks/data/'
print('sklearn', sklearn.__version__)
for est in ['EllipticEnvelope','MinCovDet']:
    for cls in (basic.Covariance, basic.Precision):
        for sq in (False, True):
            s=cls(estimator=est, squared=sq); print(s.identifier, s.labels, s.issigned())
# 1. identical given same RNG state?
for name in ['iid_gaussian','sparse_precision','contaminated','delayed_noise']:
    for T in [64,256,1024,4096]:
        x=np.load(f'{D}{name}_T{T}.npz')['x']
        d=Data(x, normalise=True); z=d.to_numpy(squeeze=True).T
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            np.random.seed(0); m=skc.MinCovDet().fit(z)
            np.random.seed(0); e=skc.EllipticEnvelope().fit(z)
            np.random.seed(1); m1=skc.MinCovDet().fit(z)
            covs=[]
            for s in range(20):
                np.random.seed(s); covs.append(skc.MinCovDet().fit(z).covariance_)
        covs=np.array(covs)
        spread=np.max(covs.max(0)-covs.min(0))
        print(name,T,'EE==MCD cov',np.array_equal(m.covariance_,e.covariance_),'prec',np.array_equal(m.precision_,e.precision_),
              '| seed0 vs seed1 maxdiff %.3g'%np.abs(m.covariance_-m1.covariance_).max(),'| 20-seed spread %.3g'%spread,
              '| diag', np.round(np.diag(m.covariance_),3), '| max|offdiag| %.3f'%np.max(np.abs(m.covariance_-np.diag(np.diag(m.covariance_)))),
              '| support %d/%d raw %d'%(m.support_.sum(),T,m.raw_support_.sum()))
