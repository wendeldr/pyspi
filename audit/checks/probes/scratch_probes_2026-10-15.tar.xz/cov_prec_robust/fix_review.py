import re, sys
R='/media/dan/Data/git/pyspi/audit/records/'
units=['basic.cov.MinCovDet','basic.cov.EllipticEnvelope','basic.prec.MinCovDet','basic.prec.EllipticEnvelope']
def sub(s, old, new, count=1):
    n=s.count(old)
    assert n==count, (old[:60], n)
    return s.replace(old,new)
for u in units:
    p=R+u+'.yaml'; s=open(p).read()
    # item 1: line citations
    s=sub(s,"already_documented: 'tests/README.md lines 106, 115-116 and 126 (tolerance-policy row: \"sklearn robust covariance draws from the global numpy RNG; reproducible only via seed_all()\", marker stochastic;",
      "already_documented: 'tests/README.md line 126 (tolerance-policy row: \"sklearn robust covariance draws from the global numpy RNG; reproducible only via seed_all()\", marker stochastic), line 115 (CALC_E2E_SKIP of cov*/prec*MinCovDet because a single seeded pass draws in a different order), line 116 (shared-cache test reseeding the 12 stochastic identifiers) and line 106 (FORCE_SLOW list names *MinCovDet* and *EllipticEnvelope*; a timing marker, not a stochasticity note);")
    s=sub(s,"\n    CALC_E2E_SKIP of cov*/prec*MinCovDet because a single seeded pass draws in a different order); REVIEW M1","\n    REVIEW M1")
    # item 3: single draws
    s=sub(s,"differ only by RNG noise: p3.py max|cov_EE - cov_MCD| = 0.0765 (sparse_precision T=64), 0.0519 (iid T=256), 0.0092-0.0142 (T=1024), and exactly 0 when both land on the same optimum.",
      "differ only by RNG noise. These are single unseeded draws that change from pass to pass: the first p3.py pass gave max|cov_EE - cov_MCD| = 0.0765 (sparse_precision T=64), 0.0519 (iid T=256), 0.0092-0.0142 (T=1024); four further fresh-process p3.py passes gave per-pass maxima of 0-0.146 at T=64, 0-0.0337 at T=256 (iid T=256: 0.0176, 0.0212, 0.017, 0.0337) and 0-0.0149 at T=1024, with exactly 0 whenever both fits land on the same optimum.")
    # item 2: scope candidate to magnitude
    s=sub(s,"'CANDIDATE (reproducibility magnitude, elaborates tests/README.md stochastic marker): seed sensitivity is large, not last-bit.",
      "'CANDIDATE (reproducibility MAGNITUDE only; the stochasticity itself and the need for seed_all() are already documented at tests/README.md:126 and are not claimed here): the seed-to-seed spread is large, not last-bit.")
    # item 4: check 1 scope
    s=sub(s,"reference: 'from-scratch numpy/scipy re-implementation of the correction and reweighting steps (no sklearn import inside the reference): given",
      "reference: 'PARTIALLY independent: from-scratch numpy/scipy re-implementation of the correction and reweighting arithmetic only (no sklearn import inside the reference), fed with the raw FAST-MCD search result from sklearn, so it does not test the stochastic search (checks 2 and 3 cover that): given")
    s=sub(s,"    reference_kind: independent-impl\n    criterion: tolerance\n    expected_outcome: off-diagonal",
      "    reference_kind: same-lineage\n    criterion: tolerance\n    expected_outcome: off-diagonal")
    s=sub(s,"(isolates sklearn correction/reweight from the stochastic raw search; input raw support is sklearn-derived and\n      is the only shared element)",
      "(isolates sklearn correction/reweight from the stochastic raw search; input raw support is sklearn-derived and\n      is the only shared element). Labelled same-lineage because the compared output depends on that sklearn raw search; the arithmetic of c(p,h/n), c(p,0.975), the mask and the MLE covariance is independent")
    open(p,'w').write(s)
# notes
p='/media/dan/Data/git/pyspi/audit/notes/cov_prec_robust.md'; s=open(p).read()
s=sub(s,"so they are fitted at different points of the RNG stream. They then differ only by RNG noise: up to 0.0765 at T=64,\n  0.0519 at T=256 and about 0.01 at T=1024, and exactly 0 when both reach the same optimum.",
 "so they are fitted at different points of the RNG stream. They then differ only by RNG noise. Each pass is one unseeded draw:\n  the first p3.py pass gave 0.0765 at T=64 (sparse_precision), 0.0519 at T=256 (iid_gaussian) and about 0.01 at T=1024.\n  Four further fresh-process passes gave per-pass maxima of 0 to 0.146 at T=64, 0 to 0.0337 at T=256 (iid_gaussian T=256:\n  0.0176, 0.0212, 0.017, 0.0337) and 0 to 0.0149 at T=1024. The difference is exactly 0 when both reach the same optimum.")
s=sub(s,"- tests/README.md:106, 115-116, 126: the stochastic marker (\"sklearn robust covariance draws from the global numpy RNG;\n  reproducible only via seed_all()\") and the CALC_E2E_SKIP of cov*/prec*MinCovDet.",
 "- tests/README.md:126: the stochastic marker in the tolerance-policy row (\"sklearn robust covariance draws from the global numpy RNG;\n  reproducible only via seed_all()\"). tests/README.md:115: the CALC_E2E_SKIP of cov*/prec*MinCovDet. tests/README.md:116: the\n  shared-cache test that reseeds the 12 stochastic identifiers. tests/README.md:106 only lists *MinCovDet* and *EllipticEnvelope* in\n  FORCE_SLOW, which is a timing marker.")
s=sub(s,"2. Seed sensitivity is large, not last-bit: 0.155 to 0.341 at T=64 and 0.07 to 0.16 at T=256. Unseeded Calculator runs are not reproducible. This\n   elaborates the tests/README.md stochastic marker.",
 "2. The magnitude of the seed sensitivity is large, not last-bit: 0.155 to 0.341 at T=64, 0.07 to 0.16 at T=256 and 0.0035 to 0.0087 at\n   T=4096. Only the magnitude is a candidate. That the output is stochastic and needs seed_all() is already documented at tests/README.md:126.")
s=sub(s,"  1. A from-scratch numpy implementation of the correction and reweight, given the raw support (tolerance 1e-10).",
 "  1. A from-scratch numpy implementation of the correction and reweight, given the sklearn raw support (tolerance 1e-10). It is\n     labelled same-lineage: the arithmetic is independent, but the input comes from the sklearn search, which checks 2 and 3 test.")
open(p,'w').write(s)
print('ok')
