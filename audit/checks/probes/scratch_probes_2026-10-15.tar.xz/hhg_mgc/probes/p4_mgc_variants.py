import sys, numpy as np, io, contextlib, warnings
sys.path.insert(0,'/media/dan/Data/git/pyspi'); sys.path.insert(0,sys.argv[1])
from mgc_scratch import mgc
from pyspi.statistics.distance import MultiscaleGraphCorrelation as M
from pyspi.data import Data
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
for name,pairs in [('nonlinear_dependence',[(0,1),(2,3)]),('bivariate_gaussian',[(0,1),(2,3)]),('iid_gaussian',[(0,1)]),('logistic_maps',[(0,1)])]:
  for T in [64,256]:
    x=np.load(DD+f'{name}_T{T}.npz')['x']
    with contextlib.redirect_stdout(io.StringIO()): d=Data(x,dim_order='ps')
    z=d.to_numpy(squeeze=True)
    for i,j in pairs:
        Dx=np.abs(z[i][:,None]-z[i][None,:]); Dy=np.abs(z[j][:,None]-z[j][None,:])
        p=M().bivariate(d,i=i,j=j)
        r=[mgc(Dx,Dy), mgc(Dx,Dy,const='nn1'), mgc(Dx,Dy,samp='n'), mgc(Dx,Dy,region='2n'), mgc(Dx,Dy,'nn1','n','2n')]
        print(f'{name} T={T} {(i,j)} pyspi={p:.10f} scratch_impl={r[0]:.10f} n(n-1)={r[1]:.10f} tau_n={r[2]:.10f} region2n={r[3]:.10f} paper_all={r[4]:.10f}')
