import sys, numpy as np, io, contextlib
sys.path.insert(0,'/media/dan/Data/git/pyspi'); sys.path.insert(0,sys.argv[1])
from mgc_scratch import mgc
from pyspi.data import Data
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
for name,pairs in [('nonlinear_dependence',[(0,1),(2,3)]),('anm',[(0,1),(2,3)]),('narrowband_f0-0.1',[(0,1)])]:
  for T in [256,1024]:
    x=np.load(DD+f'{name}_T{T}.npz')['x']
    with contextlib.redirect_stdout(io.StringIO()): d=Data(x,dim_order='ps')
    z=d.to_numpy(squeeze=True)
    for i,j in pairs:
        Dx=np.abs(z[i][:,None]-z[i][None,:]); Dy=np.abs(z[j][:,None]-z[j][None,:])
        print(name,T,(i,j),'impl',round(mgc(Dx,Dy),6),'region2n',round(mgc(Dx,Dy,region='2n'),6),'paper_all',round(mgc(Dx,Dy,'nn1','n','2n'),6))
