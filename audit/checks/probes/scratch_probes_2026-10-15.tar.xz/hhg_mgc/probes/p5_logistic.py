import sys, numpy as np, io, contextlib, warnings
sys.path.insert(0,'/media/dan/Data/git/pyspi'); sys.path.insert(0,sys.argv[1])
from mgc_scratch import mgc, local_corr
from pyspi.data import Data
from hyppo.tools import compute_dist
from hyppo.independence import HHG
from scipy.stats import multiscale_graphcorr
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
for T in [64,256,1024]:
    x=np.load(DD+f'logistic_maps_T{T}.npz')['x']
    with contextlib.redirect_stdout(io.StringIO()): d=Data(x,dim_order='ps')
    z=d.to_numpy(squeeze=True); a,b=z[0][:,None],z[1][:,None]
    print('T',T,'unique vals',len(np.unique(a)),len(np.unique(b)))
    dx,dy=compute_dist(a,b); ex=np.abs(a-a.T); ey=np.abs(b-b.T)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        r1=multiscale_graphcorr(dx,dy,compute_distance=None,reps=0); r2=multiscale_graphcorr(ex,ey,compute_distance=None,reps=0)
    print('  sklearn-dist mgc',r1.stat,'map',r1.mgc_dict['mgc_map'].shape,'opt',r1.mgc_dict['opt_scale'])
    print('  exact-dist   mgc',r2.stat,'map',r2.mgc_dict['mgc_map'].shape,'opt',r2.mgc_dict['opt_scale'])
    print('  max|dx-ex|',np.max(np.abs(dx-ex)),'asym',np.max(np.abs(dx-dx.T)))
    if T<=256:
        print('  HHG sklearn',HHG().statistic(a,b),'exact',HHG(compute_distance=None).statistic(ex,ey))
