import sys, numpy as np, io, contextlib
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.statistics.distance import HellerHellerGorfine, MultiscaleGraphCorrelation
from pyspi.data import Data
from hyppo.independence import HHG
from hyppo.tools import compute_dist
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
def load(name,T):
    z=np.load(DD+f'{name}_T{T}.npz'); return z['x']
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, dim_order='ps')
def hhg_scratch(x,y):
    # exact |xi-xj| distances, Heller 2013 sum of Pearson chi2; zero-denominator -> 0
    n=len(x); dx=np.abs(x[:,None]-x[None,:]); dy=np.abs(y[:,None]-y[None,:]); T=0.0
    for i in range(n):
        for j in range(n):
            if i==j: continue
            m=np.ones(n,bool); m[[i,j]]=False
            a=dx[i,m]<=dx[i,j]; b=dy[i,m]<=dy[i,j]
            A11=np.sum(a&b);A12=np.sum(a&~b);A21=np.sum(~a&b);A22=np.sum(~a&~b)
            den=(A11+A12)*(A21+A22)*(A11+A21)*(A12+A22)
            if den>0: T+=(n-2)*(A12*A21-A11*A22)**2/den
    return T
print(np.load(DD+'iid_gaussian_T64.npz').files)
for name in ['iid_gaussian','bivariate_gaussian','nonlinear_dependence','delayed_noise','shared_envelope']:
    x=load(name,64); d=mk(x)
    A=HellerHellerGorfine().multivariate(d)
    print(name,'T=64 max|A-A.T|=',np.nanmax(np.abs(A-A.T)), 'diag nan', np.isnan(np.diag(A)).all())
    print(np.round(A,2))
    z=d.to_numpy(squeeze=True)
    print(' scratch(0,1)=',hhg_scratch(z[0],z[1]),' pyspi(0,1)=',A[0,1], ' n(n-1)=',64*63)
# check input shape
d=mk(load('iid_gaussian',64)); x,y=d.to_numpy()[[0,1]]; print('x shape',x.shape)
dx,dy=compute_dist(x,y); print('dist sym',np.array_equal(dx,dx.T),'diag0',np.all(np.diag(dx)==0),'max |dx-abs|',np.max(np.abs(dx-np.abs(x-x.T))))
# integer types in numba kernel
from hyppo.independence.hhg import _pearson_stat
print(_pearson_stat.signatures)
