import sys, numpy as np, io, contextlib, warnings
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.statistics.distance import MultiscaleGraphCorrelation as M
from pyspi.data import Data
from hyppo.independence import MGC, Dcorr
from hyppo.tools import compute_dist
from scipy.stats import multiscale_graphcorr
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()): return Data(x,dim_order='ps')
m=M()
for name in ['iid_gaussian','bivariate_gaussian','nonlinear_dependence','shared_envelope','delayed_noise']:
  for T in [64,256]:
    x=np.load(DD+f'{name}_T{T}.npz')['x']; d=mk(x); P=d.n_processes
    A=m.multivariate(d)
    B=np.full((P,P),np.nan)
    for i in range(P):
        for j in range(P):
            if i!=j: B[i,j]=m.bivariate(d,i=i,j=j)
    print(name,T,'A sym',np.nanmax(np.abs(A-A.T)),' bivariate(i,j)-(j,i) max',np.nanmax(np.abs(B-B.T)),' min',np.nanmin(A))
    print(np.round(B,4))
# global scale vs Dcorr unbiased
x=np.load(DD+'iid_gaussian_T256.npz')['x']; d=mk(x); z=d.to_numpy()
for (i,j) in [(0,1),(0,2),(1,3)]:
    a,b=z[i],z[j]
    dx,dy=compute_dist(a,b)
    with warnings.catch_warnings():
        warnings.simplefilter('ignore'); r=multiscale_graphcorr(dx,dy,compute_distance=None,reps=0)
    mp=r.mgc_dict['mgc_map']
    print((i,j),'mgc',r.stat,'opt',r.mgc_dict['opt_scale'],'map shape',mp.shape,'global',mp[-1,-1],'Dcorr unbiased',Dcorr().statistic(a,b),'Dcorr biased',Dcorr(bias=True).statistic(a,b))
# n<5
try: print(MGC().statistic(np.arange(4.)[:,None], np.arange(4.)[:,None]**2))
except Exception as e: print('n=4:',type(e).__name__,e)
