import sys, numpy as np, io, contextlib, warnings, json
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
from hyppo.independence import HHG, MGC
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
names=[f['name'] for f in json.load(open(DD+'MANIFEST.json'))['files']]
names=sorted(set(names))
T=256
for name in names:
    x=np.load(DD+f'{name}_T{T}.npz')['x']
    with contextlib.redirect_stdout(io.StringIO()): d=Data(x,dim_order='ps')
    z=d.to_numpy(); P=z.shape[0]
    hr=[];mr=[]
    for i in range(P):
        for j in range(i+1,P):
            a,b=z[i],z[j]; ex=np.abs(a-a.T); ey=np.abs(b-b.T)
            h1=HHG().statistic(a,b); h2=HHG(compute_distance=None).statistic(ex,ey)
            m1=MGC().statistic(a,b); m2=MGC(compute_distance=None).statistic(ex,ey)
            hr.append(abs(h1-h2)/abs(h2)); mr.append(abs(m1-m2))
    print(f'{name:22s} HHG max rel diff {max(hr):.2e}  MGC max abs diff {max(mr):.2e}  min unique vals {min(len(np.unique(z[k])) for k in range(P))}')
