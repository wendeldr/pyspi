import sys, numpy as np, io, contextlib
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
from hyppo.independence import HHG
from hyppo.tools import compute_dist
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
for T in [64,256]:
    x=np.load(DD+f'shared_envelope_T{T}.npz')['x']
    with contextlib.redirect_stdout(io.StringIO()): d=Data(x,dim_order='ps')
    z=d.to_numpy(squeeze=True)
    for (i,j) in [(0,1),(0,3),(1,3)]:
        a,b=z[i][:,None],z[j][:,None]
        dx,dy=compute_dist(a,b)
        ex=np.abs(a-a.T); ey=np.abs(b-b.T)
        s_sk=HHG().statistic(a,b); s_ex=HHG(compute_distance=None).statistic(ex,ey)
        # count exact ties within rows (off-diagonal)
        def ties(M):
            c=0
            for r in range(M.shape[0]):
                v=np.delete(M[r],r); c+=len(v)-len(np.unique(v))
            return c
        print(T,(i,j),'sklearn',s_sk,'exact',s_ex,'diff',s_sk-s_ex,'row ties exact x/y',ties(ex),ties(ey),'sklearn',ties(dx),ties(dy))
    print('unique values per process', [len(np.unique(z[k])) for k in range(4)], 'T',T)
