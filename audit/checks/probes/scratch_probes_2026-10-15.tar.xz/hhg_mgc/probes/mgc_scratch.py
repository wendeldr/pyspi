import numpy as np
from scipy.stats import beta
from scipy.ndimage import label
def dense_col_rank(D):
    R=np.empty(D.shape,dtype=np.int64)
    for j in range(D.shape[1]):
        _,inv=np.unique(D[:,j],return_inverse=True); R[:,j]=inv  # 0-based
    return R
def colcenter(D):
    n=D.shape[0]; A=D-D.sum(0,keepdims=True)/(n-1); np.fill_diagonal(A,0); return A
def local_corr(Dx,Dy,const='n2'):
    n=Dx.shape[0]; A=colcenter(Dx); B=colcenter(Dy); rA=dense_col_rank(Dx); rB=dense_col_rank(Dy)
    mx=rA.max()+1; my=rB.max()+1
    c=n**2 if const=='n2' else n*(n-1)
    H=np.zeros((mx,my)); np.add.at(H,(rA.ravel(),rB.T.ravel()),(A*B.T).ravel()); H=H.cumsum(0).cumsum(1)
    Sa=np.bincount(rA.ravel(),A.ravel(),minlength=mx).cumsum(); Sb=np.bincount(rB.ravel(),B.ravel(),minlength=my).cumsum()
    cov=H-np.outer(Sa,Sb)/c
    Gx=np.zeros((mx,mx)); np.add.at(Gx,(rA.ravel(),rA.T.ravel()),(A*A.T).ravel()); vx=np.diag(Gx.cumsum(0).cumsum(1))-Sa**2/c
    Gy=np.zeros((my,my)); np.add.at(Gy,(rB.ravel(),rB.T.ravel()),(B*B.T).ravel()); vy=np.diag(Gy.cumsum(0).cumsum(1))-Sb**2/c
    with np.errstate(all='ignore'): C=cov/np.sqrt(np.outer(vx,vy))
    C[C>1]=1; C[vx<=0,:]=0; C[:,vy<=0]=0
    return C
def mgc(Dx,Dy,const='n2',samp='n-1',region='impl'):
    C=local_corr(Dx,Dy,const); m,nn=C.shape; n=Dx.shape[0]
    s=n-1 if samp=='n-1' else n
    sh=s*(s-3)/4-0.5; tau=beta.ppf(1-0.02/s,sh,sh)*2-1
    g=C[-1,-1]; thr=max(tau,g); sig=C>thr
    if sig.sum()==0: return g
    lab,_=label(sig); cnt=np.bincount(lab.ravel()); cnt[0]=0; R=lab==np.argmax(cnt)
    need=np.ceil(0.02*max(m,nn))*min(m,nn) if region=='impl' else 2*n
    if R.sum()<need: return g
    return max(g,C[R].max())
