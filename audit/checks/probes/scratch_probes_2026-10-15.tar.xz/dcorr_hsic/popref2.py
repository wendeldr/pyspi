import numpy as np
from scipy.stats import norm
s=np.sqrt(2)*norm.ppf(0.75); rng=np.random.default_rng(5)
# direct MC of population terms with many independent triples
N=4_000_000; r=0.8
def draw():
    x=rng.standard_normal(N); y=r*x+np.sqrt(1-r*r)*rng.standard_normal(N); return x,y
x,y=draw(); x1,y1=draw(); x2,y2=draw()
k=lambda a,b: np.exp(-(a-b)**2/(2*s*s))
def hs(a,a1,a2,b,b1,b2): return np.mean(k(a,a1)*k(b,b1)) - 2*np.mean(k(a,a1)*k(b,b2)) + np.mean(k(a,a1))*np.mean(k(b,b1))
print(hs(x,x1,x2,y,y1,y2)/np.sqrt(hs(x,x1,x2,x,x1,x2)*hs(y,y1,y2,y,y1,y2)))
