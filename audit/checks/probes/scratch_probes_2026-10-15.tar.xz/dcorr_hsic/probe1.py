import numpy as np, sys
from hyppo.independence import Dcorr, Hsic
from pyspi.statistics.distance import DistanceCorrelation, HilbertSchmidtIndependenceCriterion
from pyspi.data import Data
rng=np.random.default_rng(0)

def dist(x): return np.abs(x[:,None]-x[None,:])
def dc(A):  # double centre
    return A - A.mean(0)[None,:] - A.mean(1)[:,None] + A.mean()
def uc(A):
    n=A.shape[0]; B=A.copy(); np.fill_diagonal(B,0)
    r=B.sum(1); C=B - r[:,None]/(n-2) - r[None,:]/(n-2) + B.sum()/((n-1)*(n-2)); np.fill_diagonal(C,0); return C
def dcor_szekely(x,y):  # Szekely 2007, returns dCor (not squared)
    A,B=dc(dist(x)),dc(dist(y)); V2=(A*B).mean(); return np.sqrt(V2/np.sqrt((A*A).mean()*(B*B).mean()))
def bcdcor(x,y):  # Szekely-Rizzo 2014 bias-corrected dCor^2 (energy::bcdcor)
    A,B=uc(dist(x)),uc(dist(y)); n=len(x)
    f=lambda P,Q:(P*Q).sum()/(n*(n-3)); return f(A,B)/np.sqrt(f(A,A)*f(B,B))

n=200
x=rng.standard_normal(n); y=0.6*x+0.8*rng.standard_normal(n)
X,Y=x[:,None],y[:,None]
print('hyppo biased   ', Dcorr(bias=True).statistic(X,Y), ' szekely dCor', dcor_szekely(x,y), ' dCor^2', dcor_szekely(x,y)**2)
print('hyppo unbiased ', Dcorr(bias=False).statistic(X,Y), ' bcdcor', bcdcor(x,y))
# unbiased can be negative
vals=[Dcorr().statistic(rng.standard_normal((64,1)),rng.standard_normal((64,1))) for _ in range(200)]
print('unbiased dcorr on indep T=64: frac<0', np.mean(np.array(vals)<0), 'min', min(vals))
valsb=[Dcorr(bias=True).statistic(rng.standard_normal((64,1)),rng.standard_normal((64,1))) for _ in range(200)]
print('biased dcorr on indep T=64: mean', np.mean(valsb), 'min', min(valsb))
# is_fast path?
d=Dcorr(); d.statistic(X,Y); print('is_fast after statistic', d.is_fast)
# pyspi
for b in (False,True):
    s=DistanceCorrelation(biased=b); print(s.identifier, s.bivariate(x,y), s.bivariate(y,x))
