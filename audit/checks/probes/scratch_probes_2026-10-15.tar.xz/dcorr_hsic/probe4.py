import numpy as np, contextlib, io
from pyspi.statistics.distance import HilbertSchmidtIndependenceCriterion as H, DistanceCorrelation as D
from pyspi.data import Data
rng=np.random.default_rng(2)
x=rng.standard_normal(256); y=np.tanh(2*x)+0.3*rng.standard_normal(256)
res={}
with contextlib.redirect_stdout(io.StringIO()):
    for scale in (1.0,10.0,0.1):
        d=Data(np.vstack([x,scale*y]),dim_order='ps',normalise=False)
        for cls in (H,D):
            for b in (False,True):
                s=cls(biased=b); res[(s.identifier,scale)]=s.multivariate(d)[0,1]
for k,v in sorted(res.items()): print(k, '%.6f'%v)
