import numpy as np
from scipy.stats import norm
def R2(r): return (r*np.arcsin(r)+np.sqrt(1-r*r)-r*np.arcsin(r/2)-np.sqrt(4-r*r)+1)/(1+np.pi/3-np.sqrt(3))
def E_exp(A,S):  # E[exp(-1/2 z'Az)], z~N(0,S)
    return np.linalg.det(np.eye(len(S))+A@S)**-0.5
def nhsic(r,s):
    # variables (X,Y,X',Y',X'',Y'') three iid copies of bivariate N(0,[[1,r],[r,1]])
    C=np.array([[1,r],[r,1]]); S=np.kron(np.eye(3),C)  # order X,Y,X',Y',X'',Y''
    def q(pairs):
        A=np.zeros((6,6))
        for i,j in pairs:
            v=np.zeros(6); v[i]=1; v[j]=-1; A+=np.outer(v,v)/s**2
        return E_exp(A,S)
    # indices X=0,Y=1,X'=2,Y'=3,X''=4,Y''=5
    def hs(a,b):  # a,b in {'x','y'}: HSIC(a,b) for kernel on a and b
        ia={'x':(0,2,4),'y':(1,3,5)}
        a0,a1,a2=ia[a]; b0,b1,b2=ia[b]
        t1=q([(a0,a1),(b0,b1)]); t2=q([(a0,a1),(b0,b2)]); t3=q([(a0,a1)])*q([(b0,b1)]) if a!=b else q([(a0,a1)])**2
        return t1-2*t2+t3
    return hs('x','y')/np.sqrt(hs('x','x')*hs('y','y'))
s=np.sqrt(2)*norm.ppf(0.75)
for r in (0.3,0.8):
    print('rho',r,'dCor^2',R2(r),'dCor',np.sqrt(R2(r)),'nHSIC',nhsic(r,s),'sqrt nHSIC',np.sqrt(nhsic(r,s)))
# sanity Monte Carlo for nhsic at r=0.8
rng=np.random.default_rng(0); n=1500
x=rng.standard_normal(n); y=0.8*x+0.6*rng.standard_normal(n)
K=np.exp(-(x[:,None]-x)**2/(2*s*s)); L=np.exp(-(y[:,None]-y)**2/(2*s*s))
dc=lambda A:A-A.mean(0)-A.mean(1)[:,None]+A.mean()
Kc,Lc=dc(K),dc(L); print('MC nHSIC_b r=.8', (Kc*Lc).sum()/np.sqrt((Kc*Kc).sum()*(Lc*Lc).sum()), 'sigma', s)
