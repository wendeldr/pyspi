import numpy as np, contextlib, io
from pyspi.statistics.distance import HilbertSchmidtIndependenceCriterion as H, DistanceCorrelation as D
from pyspi.data import Data
rng=np.random.default_rng(1)
x0=rng.uniform(-1,1,256); x1=x0**2+0.05*rng.standard_normal(256); x2=rng.standard_normal(256)
out=[]
with contextlib.redirect_stdout(io.StringIO()):
    d=Data(np.vstack([x0,x1,x2]),dim_order='ps')
    for cls in (H,D):
      for b in (False,True):
        s=cls(biased=b)
        A=s.multivariate(d)
        out.append((s.identifier, A, s.bivariate(d,i=0,j=1), s.bivariate(d,i=1,j=0), s.bivariate(d,i=1,j=2), s.bivariate(d,i=2,j=1)))
np.set_printoptions(precision=6)
for o in out: print(o[0],'\n',o[1],'\n  biv(0,1)=%.10f biv(1,0)=%.10f biv(1,2)=%.10f biv(2,1)=%.10f'%o[2:])
print('data shape', d.to_numpy().shape, d.to_numpy()[[0,1]][0].shape)
# z-score check: std ddof
z=d.to_numpy()[0,:,0]; print('mean,std(ddof1)', z.mean(), z.std(ddof=1))
