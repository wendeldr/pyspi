import yaml
from pathlib import Path
OUT = Path('/media/dan/Data/git/pyspi/audit/records')
HY = '.venv/lib/python3.12/site-packages/hyppo'
SK = '.venv/lib/python3.12/site-packages/sklearn'

COMMON_PRE = [
    "pyspi/data.py:184-195 Data.set_data: scipy.signal.detrend only if detrend=True (default False), then scipy.stats.zscore(axis=1, ddof=1) if normalise=True (default); stored as (M, T, 1)",
    "pyspi/calculator.py:294 Calculator.compute calls self._spis[spi].multivariate(self.dataset); :297 np.fill_diagonal(S, nan)",
    "pyspi/base.py:132-138 Undirected.multivariate: A = Directed.multivariate(data); li = tril_indices(-1); A[li] = A.T[li] (lower triangle overwritten by upper triangle)",
    "pyspi/base.py:84-94 Directed.multivariate: for every ordered pair i != j, A[i, j] = self.bivariate(data, i=i, j=j) (both triangles are computed)",
    "pyspi/base.py:27-49 parse_bivariate: two raw arrays are wrapped into a Data object (which z-scores) and i, j = 0, 1",
    "pyspi/data.py:108-118 Data.to_numpy returns the (M, T, 1) array, so x, y = data.to_numpy()[[i, j]] are (T, 1) column arrays (T samples of a 1-D variable)",
]
DCORR_PY = [
    "pyspi/config.yaml:143-153 DistanceCorrelation configs: biased False / biased True",
    "pyspi/statistics/distance.py:87-90 DistanceCorrelation.__init__ stores biased; identifier += '_biased'",
    "pyspi/statistics/distance.py:92-97 DistanceCorrelation.bivariate: x, y = data.to_numpy()[[i, j]]; stat = Dcorr(bias=self._biased).statistic(x, y)",
]
DCORR_HY = [
    f"{HY}/independence/dcorr.py:114-121 Dcorr.__init__: compute_distance='euclidean', is_fast=False (the O(n log n) path is enabled only inside Dcorr.test, 231-237, never by statistic)",
    f"{HY}/independence/dcorr.py:123-152 Dcorr.statistic: compute_dist(x, y, metric='euclidean') (144-147) then _dcorr(distx, disty, bias=self.bias, is_fast=False) (149)",
    f"{HY}/tools/common.py:436-503 compute_dist -> sklearn.metrics.pairwise_distances(mat, metric='euclidean') for each input (497-501)",
    f"{SK}/metrics/pairwise.py:268 euclidean_distances (dot-product expansion, diagonal forced to 0; probe: max |D - |x_i-x_j|| = 4e-11 at T=4096, effect on the statistic <= 1.3e-15)",
    f"{HY}/independence/dcorr.py:261-281 _center_distmat: bias=True subtracts row/column means (/n) and adds grand mean (/n^2) = double centring (265-271); bias=False uses row/column sums /(n-2) and grand sum /((n-1)(n-2)) and zeroes the diagonal = U-centring (272-280)",
    f"{HY}/independence/dcorr.py:394-413 _dcov with only_dcov=False returns np.sum(A * B) only (402); the 1/n^2 and 1/(n(n-3)) factors (406-411) are skipped and cancel in the ratio",
    f"{HY}/independence/dcorr.py:416-449 _dcorr: covar, varx, vary = sum(A*B), sum(A*A), sum(B*B) (432-434); stat = 0 if varx <= 0 or vary <= 0 or (covar <= 0 and bias) (438-439); else stat = covar / sqrt(varx * vary) (443) and, only when bias=True, stat = sqrt(stat) (446-447)",
]
HSIC_PY = [
    "pyspi/config.yaml:167-177 HilbertSchmidtIndependenceCriterion configs: biased False / biased True",
    "pyspi/statistics/distance.py:54-57 HilbertSchmidtIndependenceCriterion.__init__ stores biased; identifier += '_biased'",
    "pyspi/statistics/distance.py:59-63 HilbertSchmidtIndependenceCriterion.bivariate: x, y = data.to_numpy()[[i, j]]; stat = Hsic(bias=self._biased).statistic(x, y)",
]
HSIC_HY = [
    f"{HY}/independence/hsic.py:83-92 Hsic.__init__: compute_kernel='gaussian', is_kernel=False, bias stored",
    f"{HY}/independence/hsic.py:113-119 Hsic.statistic: kernx, kerny = compute_kern(x, y, metric='gaussian'); distx = 1 - kernx/max(kernx); disty = 1 - kerny/max(kerny) (max = 1, the diagonal)",
    f"{HY}/tools/common.py:321-333 compute_kern: if 'gamma' not in kwargs, med = median of the off-diagonal entries of pairwise_distances(x, 'l2') -- x ONLY; med = med if med else 1; kwargs['gamma'] = 1/(2 med^2)",
    f"{HY}/tools/common.py:342-343 compute_kern: simx = pairwise_kernels(x, 'rbf', gamma) and simy = pairwise_kernels(y, 'rbf', gamma) -- the same gamma (bandwidth of x) is used for y",
    f"{SK}/metrics/pairwise.py:1583-1627 rbf_kernel: K = exp(-gamma * ||x - y||^2) via euclidean_distances(squared=True)",
    f"{HY}/independence/hsic.py:121-122 Hsic.statistic: stat = Dcorr(bias=self.bias, compute_distance=None).statistic(distx, disty) -- the kernel-induced distances are fed to the distance-correlation code",
    f"{HY}/independence/dcorr.py:141-149 Dcorr.statistic with is_distance=True: no distance computation, straight to _dcorr",
    f"{HY}/independence/dcorr.py:261-281 _center_distmat (double centring if bias, U-centring with zero diagonal otherwise)",
    f"{HY}/independence/dcorr.py:416-449 _dcorr: stat = covar/sqrt(varx*vary) (443); sqrt only when bias=True (446-447); 0 if a variance <= 0 (438-439)",
]

def gauss_formula():
    return ("Szekely, Rizzo & Bakirov 2007 Thm 7 bivariate-normal closed form: dCor^2(rho) = [rho*arcsin(rho) + sqrt(1-rho^2) - rho*arcsin(rho/2) - sqrt(4-rho^2) + 1] / [1 + pi/3 - sqrt(3)] (rho=0.3 -> 0.07236, rho=0.8 -> 0.56987; dCor = 0.26900, 0.75490)")

recs = {}

# ---------------- dcorr unbiased ----------------
recs['distance.dcorr.biased-False'] = dict(
  metric_name_standard="bias-corrected squared distance correlation (R*_n, energy::bcdcor); the unbiased (U-statistic) dCov^2 normalised by the unbiased dVar^2 terms",
  canonical_ref="Szekely & Rizzo 2014, Ann. Statist. 42(6):2382-2412, Sec. 2-3 (U-centring, unbiased dCov^2 estimator, Prop. 1); bias-corrected dCor R*_n in Szekely & Rizzo 2013, J. Multivariate Anal. 117:193-213; population dCor: Szekely, Rizzo & Bakirov 2007, Ann. Statist. 35(6):2769-2794",
  canonical_definition="U-centre a_ij=|x_i-x_j|: A~_ij = a_ij - a_i./(n-2) - a_.j/(n-2) + a_../((n-1)(n-2)) for i != j, 0 on the diagonal; (X.Y)_n = 1/(n(n-3)) sum_{i!=j} A~_ij B~_ij (unbiased for dCov^2(X,Y)); R*_n = (X.Y)_n / sqrt((X.X)_n (Y.Y)_n), an estimator of dCor^2 (squared scale), may be negative",
  documented_definition="supplement §1.2.1, p.5: 'The sample distance correlation is computed by summing over the entry-wise product of Euclidean distance matrices. This statistic is biased, however an unbiased estimator can be obtained by first double-centering the distance matrices [14]. ... We compute both the biased and unbiased statistics from the hyppo package' (identifier 22, dcorr). GitBook distance-similarity.md 'Distance Correlation' (same wording, ref arXiv 0803.4101)",
  delegate_lib="hyppo==0.5.2 hyppo.independence.Dcorr(bias=False).statistic (numba 0.68.0 jit _dcorr / _center_distmat); distances via scikit-learn==1.9.1 pairwise_distances('euclidean')",
  implemented_as="Default preprocessing: z-score each series (ddof=1), no detrend (irrelevant for the value: dCor is invariant to per-variable positive scaling and shifts). The T time points are treated as T iid samples of a 1-D variable (time order ignored). Euclidean (=|x_i-x_j|) distance matrices are U-centred (zero diagonal) and stat = sum(A~B~)/sqrt(sum(A~A~) sum(B~B~)) with NO square root, i.e. the bias-corrected dCor^2 R*_n. Returns exactly 0 when either U-centred variance <= 0; negative values are returned unchanged. Both ordered pairs are computed and the upper triangle (x = lower-index process) is mirrored.",
  implementation_trace=COMMON_PRE[:2] + COMMON_PRE[2:] + DCORR_PY + DCORR_HY,
  deviation_from_documented="(1) The supplement says the unbiased estimator is obtained 'by first double-centering the distance matrices'; the code U-centres (n-2 and (n-1)(n-2) denominators, zero diagonal; dcorr.py:273-280), while the biased variant is the one that double-centres. (2) It says the sample statistic is a sum over the product of 'Euclidean distance matrices'; the product is of centred matrices. (3) The documentation does not say that this SPI is on the SQUARED scale (dCor^2) while dcorr_biased is on the root scale (dCor), so the two 'biased/unbiased' SPIs are not estimators of the same quantity. (4) The unbiased-estimator citation [14] is Shen, Priebe & Vogelstein (MGC), not Szekely & Rizzo 2013/2014. (5) Labelled 'unsigned' but returns negative values.",
  deviation_from_canonical="none for the estimator itself: matches the bias-corrected dCor^2 R*_n of Szekely & Rizzo (probe: hyppo 0.25339647074002397 vs from-scratch U-centred formula 0.25339647074002286). Convention notes: it estimates dCor^2, not dCor; clamps to 0 when a U-centred variance is <= 0 (canonical R*_n is undefined there).",
  units_and_range="dimensionless; in [-1, 1] (Cauchy-Schwarz in the U-centred inner-product space); negative values occur under independence (probe: 64.5% of 200 iid N(0,1) pairs at T=64 negative, min -0.0297; pyspi matrix entry -0.005393 on an independent pair); exactly 0 if either series has non-positive U-centred variance; invariant to per-variable affine maps with nonzero scale; symmetric in (x, y).",
  direction_convention="undirected: A[i, j] = A[j, i] = bivariate(x = process min(i, j), y = process max(i, j)) via the mirror in base.py:136-137; the kernel itself is symmetric (probe: bivariate(0,1) = bivariate(1,0) = 0.2180361011).",
  symmetry_expected="sym",
  already_documented="no",
  new_finding_candidates=[
    "Candidate (scale mismatch): dcorr returns the bias-corrected SQUARED distance correlation (no sqrt for bias=False, dcorr.py:446-447 'only biased Dcov is square-rooted'), while dcorr_biased returns the unsquared dCor. Probe on one pair: dcorr = 0.2534 (from-scratch R*_n 0.2534), dcorr_biased = 0.5145 (Szekely dCor 0.5145, dCor^2 0.2647). The documentation presents them as biased/unbiased versions of one statistic.",
    "Candidate (sign label): labelled 'unsigned' yet returns negative values under independence (probe: 64.5% of 200 iid pairs at T=64 negative, min -0.0297; pyspi matrix entry -0.005393). Expected behaviour of an unbiased estimator; related in kind to REVIEW M7/M8 (other SPIs), not documented for dcorr.",
    "Candidate (documentation): the supplement describes the unbiased estimator as obtained 'by double-centering'; code uses U-centring (dcorr.py:272-280); double centring is what the biased variant does (dcorr.py:265-271).",
    "Candidate (edge case, low impact): _dcorr returns 0 when a U-centred variance is <= 0 (dcorr.py:438-439) rather than NaN; through pyspi a constant series becomes NaN in zscore and Data raises first, so this is reachable only via near-degenerate inputs or normalise=False with constant input.",
  ],
  proposed_checks=[
    dict(datasets=["bivariate_gaussian","nonlinear_dependence","anm","contaminated","iid_gaussian"], path="kernel",
         reference="dcor==0.7 dcor.u_distance_correlation_sqr(x, y) (independent package, does not import hyppo) plus from-scratch numpy U-centring of |x_i - x_j| (checks/refs/dcorr_hsic.py)",
         reference_kind="external-pkg", criterion="tolerance",
         expected_outcome="agreement to rtol 1e-10 / atol 1e-12 for every pair and every T in {64,256,1024,4096}, on the same (T,1) arrays pyspi passes to hyppo"),
    dict(datasets=["bivariate_gaussian"], path="pipeline",
         reference=gauss_formula(),
         reference_kind="analytic", criterion="statistical",
         expected_outcome="pair (0,1) -> about 0.0724 and pair (2,3) -> about 0.5699 (the SQUARED scale, not 0.269 / 0.755), error shrinking roughly as T^-1/2 from T=64 to T=4096; cross pairs (independent) -> about 0, sometimes negative"),
    dict(datasets=["iid_gaussian"], path="pipeline",
         reference="analytic null: population dCor^2 = 0 for independent series",
         reference_kind="analytic", criterion="statistical",
         expected_outcome="off-diagonal values centred on 0 (mean within a few standard errors of 0 at each T), a substantial fraction negative, spread shrinking with T"),
    dict(datasets=["anm","nonlinear_dependence","bivariate_gaussian"], path="pipeline",
         reference="from-scratch kernel on (x_i, x_j) and on (x_j, x_i) after pyspi preprocessing",
         reference_kind="independent-impl", criterion="direction",
         expected_outcome="A exactly symmetric; A[i,j] equals kernel(x_min(i,j), x_max(i,j)) and kernel(x_j, x_i) to 1e-12 (no order dependence); reversing the process order permutes A without changing values"),
    dict(datasets=["scaled_offset","bivariate_gaussian"], path="pipeline",
         reference="invariance property: dCor is invariant to per-variable positive scaling and shifts; scaled_offset is the same draw as bivariate_gaussian",
         reference_kind="analytic", criterion="exact",
         expected_outcome="pyspi(scaled_offset) equals pyspi(bivariate_gaussian) to ~1e-12, also with normalise=False on the kernel path"),
    dict(datasets=["trending","bivariate_gaussian"], path="pipeline-detrend",
         reference="detrend(D2 + slope*t) equals detrend(D2), so pipeline-detrend on trending must equal pipeline-detrend on bivariate_gaussian (same draw)",
         reference_kind="analytic", criterion="tolerance",
         expected_outcome="agreement to ~1e-10; contrast run on the plain pipeline (no detrend) is expected to show inflated values on the independent cross pairs with trends (e.g. (1,3), (2,3)) -- qualitative"),
    dict(datasets=["nonlinear_dependence","anm"], path="pipeline",
         reference="qualitative property: dCor detects non-monotone dependence where Pearson is about 0",
         reference_kind="literature-only", criterion="qualitative",
         expected_outcome="(0,1) of nonlinear_dependence (x1 = x0^2) and the circle pair (2,3) clearly above the iid_gaussian null spread at T >= 256"),
  ],
)

# ---------------- dcorr biased ----------------
recs['distance.dcorr.biased-True'] = dict(
  metric_name_standard="sample distance correlation dCor_n (V-statistic, Szekely-Rizzo-Bakirov), unsquared",
  canonical_ref="Szekely, Rizzo & Bakirov 2007, Ann. Statist. 35(6):2769-2794, Sec. 2.2 (empirical dCov V_n^2 = (1/n^2) sum A_kl B_kl with double-centred distance matrices; empirical dCor R_n); Thm 7 bivariate-normal closed form",
  canonical_definition="A_kl = a_kl - a_k. - a_.l + a_.. (double centring of a_kl=|x_k-x_l|, means over n), V_n^2(X,Y) = (1/n^2) sum_kl A_kl B_kl, R_n^2 = V_n^2(X,Y)/sqrt(V_n^2(X,X) V_n^2(Y,Y)) (0 if the denominator is 0); dCor_n = R_n = sqrt(R_n^2) in [0,1]",
  documented_definition="supplement §1.2.1, p.5: 'The sample distance correlation is computed by summing over the entry-wise product of Euclidean distance matrices. This statistic is biased ... We compute both the biased and unbiased statistics from the hyppo package' (identifier 23, dcorr_biased). GitBook distance-similarity.md 'Distance Correlation'",
  delegate_lib="hyppo==0.5.2 hyppo.independence.Dcorr(bias=True).statistic (numba-jitted _dcorr); scikit-learn==1.9.1 pairwise_distances('euclidean')",
  implemented_as="Default preprocessing: z-score (ddof=1), no detrend (value invariant to per-variable affine maps anyway). T time points treated as iid samples of a 1-D variable. Euclidean distance matrices double-centred with 1/n means; stat = sqrt( sum(AB)/sqrt(sum(AA) sum(BB)) ) = dCor_n (unsquared). Returns 0 if a variance <= 0 or the covariance <= 0. Upper triangle (x = lower-index process) mirrored.",
  implementation_trace=COMMON_PRE + DCORR_PY + DCORR_HY,
  deviation_from_documented="(1) Documentation says the statistic sums the product of 'Euclidean distance matrices'; the product is of double-centred matrices (dcorr.py:265-271). (2) Documentation does not say that this SPI is unsquared dCor while the 'unbiased' dcorr is on the squared scale (bias-corrected dCor^2), so the pair are not two estimators of one quantity. Otherwise consistent.",
  deviation_from_canonical="none: equals Szekely et al. 2007 sample dCor_n (probe: hyppo 0.514514058070257 vs from-scratch 0.5145140580702596; dCor^2 would be 0.2647). The 0-clamp when covar <= 0 is not reachable for valid double-centred Euclidean distance matrices (V_n^2 >= 0).",
  units_and_range="dimensionless; [0, 1]; positively biased under independence (probe: mean 0.211, min 0.128 over 200 iid N(0,1) pairs at T=64); 1 for exact linear relation; invariant to per-variable affine maps with nonzero scale; symmetric in (x, y).",
  direction_convention="undirected: A[i, j] = A[j, i] = bivariate(x = process min(i, j), y = process max(i, j)) via base.py:136-137; the kernel is symmetric (probe: bivariate(0,1) = bivariate(1,0) = 0.4767339470).",
  symmetry_expected="sym",
  already_documented="no",
  new_finding_candidates=[
    "Candidate (scale mismatch with dcorr): dcorr_biased is the square root of the normalised V-statistic (dcorr.py:446-447) while dcorr (unbiased) is not square-rooted; probe pair: 0.5145 vs 0.2534. Anyone comparing the two expecting only a bias difference will see a factor of roughly sqrt.",
    "Candidate (documentation): supplement text describes summing 'the entry-wise product of Euclidean distance matrices' without the centring step; implementation double-centres (dcorr.py:265-271).",
  ],
  proposed_checks=[
    dict(datasets=["bivariate_gaussian","nonlinear_dependence","anm","contaminated","iid_gaussian"], path="kernel",
         reference="dcor==0.7 dcor.distance_correlation(x, y) (unsquared; independent of hyppo) and from-scratch numpy double-centring (checks/refs/dcorr_hsic.py)",
         reference_kind="external-pkg", criterion="tolerance",
         expected_outcome="agreement to rtol 1e-10 at every T; dcor.distance_correlation_sqr must NOT match (it equals the square)"),
    dict(datasets=["bivariate_gaussian"], path="pipeline",
         reference=gauss_formula() + "; compare against dCor = sqrt of that",
         reference_kind="analytic", criterion="statistical",
         expected_outcome="pair (0,1) -> about 0.269 and pair (2,3) -> about 0.755, approached from above (positive bias), bias shrinking with T; independent cross pairs positive and decreasing with T"),
    dict(datasets=["iid_gaussian"], path="pipeline",
         reference="analytic null dCor = 0; V-statistic dCor_n has positive bias of order T^-1/2",
         reference_kind="analytic", criterion="direction",
         expected_outcome="all off-diagonal values > 0; mean decreases monotonically from T=64 to T=4096 roughly as T^-1/2"),
    dict(datasets=["bivariate_gaussian","nonlinear_dependence"], path="pipeline",
         reference="relation between the two SPIs: from-scratch R_n^2 and R*_n on the same arrays",
         reference_kind="independent-impl", criterion="qualitative",
         expected_outcome="dcorr_biased^2 is close to dcorr for large T on dependent pairs (both -> dCor^2), while dcorr_biased itself is close to sqrt(dcorr); documents the scale mismatch numerically"),
    dict(datasets=["anm","nonlinear_dependence"], path="pipeline",
         reference="from-scratch kernel on both argument orders",
         reference_kind="independent-impl", criterion="direction",
         expected_outcome="A exactly symmetric and equal to the kernel in either argument order to 1e-12"),
    dict(datasets=["scaled_offset","bivariate_gaussian"], path="pipeline",
         reference="affine invariance of dCor; same draw",
         reference_kind="analytic", criterion="exact",
         expected_outcome="identical values to ~1e-12 (also with normalise=False on the kernel path)"),
    dict(datasets=["trending","bivariate_gaussian"], path="pipeline-detrend",
         reference="detrend(D2 + slope*t) == detrend(D2)",
         reference_kind="analytic", criterion="tolerance",
         expected_outcome="pipeline-detrend(trending) equals pipeline-detrend(bivariate_gaussian) to ~1e-10"),
  ],
)

HSIC_DEV_DOC_COMMON = ("(a) The supplement and GitBook describe HSIC as 'an RKHS-based statistic' with biased and unbiased estimators; neither says that the returned value is NORMALISED (HSIC(x,y)/sqrt(HSIC(x,x) HSIC(y,y)), a correlation-like number), nor that the Gaussian kernel bandwidth is the median heuristic computed from the first argument only and reused for the second. "
    "(b) 'the unbiased (and consistent) estimator can be derived by double centering the kernel distance matrix [15]': [15] (Gretton et al. 2007) defines the biased V-statistic; the unbiased estimator in the code is the U-centring of 1-K (equivalent to Song et al. 2012), and double centring is the biased variant. (c) Labelled 'undirected' but the bivariate value depends on argument order (made symmetric only by mirroring).")

# ---------------- hsic unbiased ----------------
recs['distance.hsic.biased-False'] = dict(
  metric_name_standard="normalised unbiased HSIC with a Gaussian median-heuristic kernel (kernel analogue of bias-corrected dCor^2; an unbiased-centred kernel alignment)",
  canonical_ref="HSIC: Gretton, Bousquet, Smola & Scholkopf 2005, ALT, LNCS 3734:63-77 (HSIC_b = (m-1)^-2 tr(KHLH)); Gretton et al. 2007, NIPS 20 'A kernel statistical test of independence' (Gaussian kernel, median-distance bandwidth per variable); unbiased estimator: Song, Smola, Gretton, Bedo & Borgwardt 2012, JMLR 13:1393-1434, eq. (5); kernel/distance equivalence: Sejdinovic et al. 2013, Ann. Statist. 41(5):2263-2291; normalisation used here: Shen & Vogelstein 2020 (hyppo docs) / centred kernel alignment (Cortes, Mohri & Rostamizadeh 2012, JMLR 13:795-828)",
  canonical_definition="Unbiased HSIC (Song et al. 2012 eq. 5): with K~, L~ = Gram matrices with zeroed diagonal, HSIC_u = [tr(K~L~) + 1'K~1 1'L~1/((n-1)(n-2)) - 2/(n-2) 1'K~L~1] / (n(n-3)); Gaussian kernel k(x,x') = exp(-|x-x'|^2/(2 sigma^2)) with sigma = median inter-sample distance of that variable (Gretton et al. 2007). The quantity is an unnormalised dependence measure (HSIC itself, not a correlation).",
  documented_definition="supplement §1.2.5, p.6: 'The Hibert-Schmidt Independence Criterion (HSIC) [15] is an RKHS-based statistic that quantifies a statistical dependence between random variables via a sample kernel matrix. As with distance correlation, HSIC yields a biased statistic, where the unbiased (and consistent) estimator can be derived by double centering the kernel distance matrix [15]. Both biased and unbiased estimators are computed using hyppo' (identifier 29, hsic). GitBook distance-similarity.md 'Hilbert-Schmidt Independence Criterion' (ref Gretton et al. NIPS 2007)",
  delegate_lib="hyppo==0.5.2 hyppo.independence.Hsic(bias=False).statistic -> hyppo.tools.compute_kern (median heuristic) -> scikit-learn==1.9.1 pairwise_kernels('rbf') -> hyppo Dcorr(bias=False, compute_distance=None).statistic (numba _dcorr)",
  implemented_as="Default preprocessing: z-score (ddof=1), no detrend. T time points treated as iid 1-D samples. sigma = median of the off-diagonal |x_i - x_j| of x (the FIRST argument, i.e. the lower-index process after the mirror) and gamma = 1/(2 sigma^2) is used for BOTH Gram matrices (med = 1 if the median is 0). D = 1 - K (max K = 1 on the diagonal) is U-centred and stat = <U(Dx),U(Dy)>/sqrt(<U(Dx),U(Dx)> <U(Dy),U(Dy)>) with no square root. Since U-centring removes the constant and D has zero diagonal, this equals HSIC_u(K,L)/sqrt(HSIC_u(K,K) HSIC_u(L,L)) of Song et al. (probe: 0.7662620588623132 both ways). Returns 0 if a centred variance <= 0. Upper triangle mirrored.",
  implementation_trace=COMMON_PRE + HSIC_PY + HSIC_HY,
  deviation_from_documented=HSIC_DEV_DOC_COMMON + " (d) The unbiased value is on the squared-correlation scale while hsic_biased is square-rooted; the documentation presents them as two estimators of one quantity. (e) Labelled 'unsigned' but can be negative.",
  deviation_from_canonical="(1) Normalised: returns HSIC_u(x,y)/sqrt(HSIC_u(x,x) HSIC_u(y,y)), not HSIC_u (probe: 0.7663 vs raw HSIC_u 0.0570 on the same arrays); dimensionless, bounded. (2) Bandwidth: median heuristic computed from x only and applied to y (common.py:321-333, 342-343); the per-variable median of Gretton et al. 2007 would give 0.7720 instead of 0.7663 on the probe pair (x ~ N(0,1), y = exp(x) + noise). (3) Consequently the estimator is not symmetric in (x, y). The unbiased centring itself matches Song et al. 2012 eq. (5) exactly.",
  units_and_range="dimensionless; in [-1, 1] (Cauchy-Schwarz in the U-centred inner product); negative under independence (probe: 66% of 200 iid pairs at T=64 negative, min -0.0321; pyspi matrix entries -0.0027, -0.00095); 0 if a centred variance <= 0; invariant to a common positive scaling of x and y and to shifts, NOT invariant to rescaling y relative to x (probe with normalise=False: 0.791 -> 0.353 when y is multiplied by 10), though default z-scoring removes pure scale differences.",
  direction_convention="undirected by mirroring only: bivariate(x, y) != bivariate(y, x) (probe on z-scored x0 ~ U(-1,1) vs x0^2 + noise: 0.3029364702 vs 0.3266473096); Undirected.multivariate (base.py:136-137) keeps the upper triangle, so A[i, j] = A[j, i] = bivariate(x = process min(i, j), y = process max(i, j)) and the bandwidth is that of the lower-index process; the value therefore depends on process ordering.",
  symmetry_expected="sym",
  already_documented="no",
  new_finding_candidates=[
    "Candidate (order dependence): the Gaussian bandwidth is the median distance of the first argument only and is reused for the second (hyppo/tools/common.py:323-333 sets kwargs['gamma'] from x; 342-343 apply it to x and y). Probe: bivariate(0,1) = 0.3029 vs bivariate(1,0) = 0.3266 (7.8% relative) on z-scored uniform vs squared-uniform series; the pyspi matrix reports 0.302936 (upper-triangle value), so permuting the process order changes the reported hsic value. Not covered by tests/README.md bug 5 or REVIEW M1 (those concern classes that bypass the mirror; this class is mirrored but the kernel itself is asymmetric).",
    "Candidate (normalisation not documented): the returned value is normalised HSIC (hsic.py:118-122 feeds 1 - K/max K into Dcorr, whose _dcorr divides by sqrt(varx*vary)); probe: 0.7663 vs raw unbiased HSIC 0.0570. The supplement/GitBook describe plain HSIC.",
    "Candidate (scale mismatch with hsic_biased): no square root for bias=False (dcorr.py:446-447), so hsic is on the squared scale and hsic_biased on the root scale (probe pair: 0.3029 vs 0.5561).",
    "Candidate (relative-scale dependence when normalise=False): because y is kernelised with x's bandwidth, hsic changes when y alone is rescaled (probe, normalise=False: y*1 -> 0.7908, y*10 -> 0.3527, y*0.1 -> 0.7476), whereas dcorr is unchanged (0.8288 in all three). With the default z-scoring only differences in distribution shape remain.",
    "Candidate (sign label): labelled 'unsigned' but negative values are returned under independence (66% negative at T=64 in the probe).",
  ],
  proposed_checks=[
    dict(datasets=["bivariate_gaussian","nonlinear_dependence","anm","contaminated","iid_gaussian"], path="kernel",
         reference="from-scratch numpy: Gaussian Gram matrices with sigma = median off-diagonal |x_i - x_j| of the FIRST argument for both variables, Song et al. 2012 eq. (5) unbiased HSIC with zeroed diagonals, normalised by sqrt(HSIC_u(K,K) HSIC_u(L,L)) (checks/refs/dcorr_hsic.py; no hyppo import)",
         reference_kind="independent-impl", criterion="tolerance",
         expected_outcome="agreement to rtol 1e-10 on every pair and T; a second reference with per-variable medians (Gretton 2007) is expected to differ at the 1e-3..1e-2 relative level on pairs with different marginal shapes (nonlinear_dependence (0,1), anm) and to agree closely on bivariate_gaussian"),
    dict(datasets=["nonlinear_dependence","anm","contaminated"], path="pipeline",
         reference="from-scratch kernel evaluated in both argument orders on pyspi-preprocessed data; run pyspi on the original and on the reversed process order",
         reference_kind="independent-impl", criterion="direction",
         expected_outcome="A[i,j] = A[j,i] = reference(x_min(i,j), x_max(i,j)); reference(x_j, x_i) differs for pairs with different marginal shapes; reversing the process order changes the reported values for those pairs (establishes the convention and quantifies the order dependence)"),
    dict(datasets=["bivariate_gaussian"], path="pipeline",
         reference="analytic population normalised HSIC for a standard bivariate normal with Gaussian kernel sigma = sqrt(2)*Phi^-1(0.75) = 0.9539 (population median of |X-X'|), computed from Gaussian integrals E[exp(-z'Az/2)] = det(I + A Sigma)^-1/2 (scratch derivation: rho=0.3 -> 0.0455, rho=0.8 -> 0.474; Monte Carlo cross-check 0.470 +- 0.005)",
         reference_kind="analytic", criterion="statistical",
         expected_outcome="pair (0,1) -> about 0.046 and pair (2,3) -> about 0.47 (squared scale), converging with T; independent cross pairs centred on 0"),
    dict(datasets=["iid_gaussian"], path="pipeline",
         reference="analytic null: population HSIC = 0 for independent series",
         reference_kind="analytic", criterion="statistical",
         expected_outcome="values centred on 0, a substantial fraction negative, spread shrinking with T"),
    dict(datasets=["scaled_offset","bivariate_gaussian"], path="kernel",
         reference="from-scratch kernel on raw (non-normalised) scaled_offset vs bivariate_gaussian arrays",
         reference_kind="independent-impl", criterion="qualitative",
         expected_outcome="with normalise=False the values differ between the two datasets (relative scale of y vs x changes the effective y bandwidth); through the default pipeline (z-scored) the two datasets give identical values to ~1e-12"),
    dict(datasets=["trending","bivariate_gaussian"], path="pipeline-detrend",
         reference="detrend(D2 + slope*t) == detrend(D2)",
         reference_kind="analytic", criterion="tolerance",
         expected_outcome="pipeline-detrend(trending) equals pipeline-detrend(bivariate_gaussian) to ~1e-10"),
  ],
)

# ---------------- hsic biased ----------------
recs['distance.hsic.biased-True'] = dict(
  metric_name_standard="square root of the normalised biased HSIC (V-statistic) with a Gaussian median-heuristic kernel, i.e. sqrt of centred kernel alignment; kernel analogue of dCor_n",
  canonical_ref="Gretton, Bousquet, Smola & Scholkopf 2005, ALT, LNCS 3734:63-77 (HSIC_b); Gretton et al. 2007, NIPS 20 (HSIC_b = (1/m^2) tr(KHLH), Gaussian kernel with per-variable median-distance bandwidth); normalisation: centred kernel alignment, Cortes, Mohri & Rostamizadeh 2012, JMLR 13:795-828; equivalence with dCov: Sejdinovic et al. 2013, Ann. Statist. 41(5):2263-2291",
  canonical_definition="HSIC_b(x,y) = (1/n^2) tr(K H L H), H = I - 11'/n, K_ij = exp(-|x_i-x_j|^2/(2 sigma_x^2)), L likewise with sigma_y, sigma = median inter-sample distance of each variable (Gretton et al. 2007); unnormalised, >= 0",
  documented_definition="supplement §1.2.5, p.6: 'HSIC yields a biased statistic, where the unbiased (and consistent) estimator can be derived by double centering the kernel distance matrix [15]. Both biased and unbiased estimators are computed using hyppo' (identifier 30, hsic_biased). GitBook distance-similarity.md 'Hilbert-Schmidt Independence Criterion'",
  delegate_lib="hyppo==0.5.2 hyppo.independence.Hsic(bias=True).statistic -> compute_kern (median heuristic) -> scikit-learn==1.9.1 pairwise_kernels('rbf') -> Dcorr(bias=True, compute_distance=None).statistic (numba _dcorr)",
  implemented_as="Default preprocessing: z-score (ddof=1), no detrend. T time points as iid 1-D samples. sigma = median off-diagonal distance of x (first argument) used for both kernels. D = 1 - K double-centred (equals -HKH, the constant vanishes), stat = sqrt( tr(HKH HLH)/sqrt(tr(HKH HKH) tr(HLH HLH)) ) = sqrt of normalised HSIC_b (probe: 0.8773521262252134 vs from-scratch 0.8773521262252156; raw HSIC_b 0.0577). Returns 0 if a variance or the covariance <= 0. Upper triangle mirrored.",
  implementation_trace=COMMON_PRE + HSIC_PY + HSIC_HY,
  deviation_from_documented=HSIC_DEV_DOC_COMMON + " (d) The square root (dcorr.py:446-447) is not mentioned; hsic_biased is on the root scale while hsic is on the squared scale.",
  deviation_from_canonical="(1) Returns sqrt(HSIC_b(x,y)/sqrt(HSIC_b(x,x) HSIC_b(y,y))) rather than HSIC_b (probe: 0.8774 vs 0.0577); (2) bandwidth from x only, reused for y (per-variable median would give 0.8805 instead of 0.8774 on the probe pair); (3) hence asymmetric in (x, y) before pyspi mirrors it. The 1/n^2 vs 1/(n-1)^2 normalisation of HSIC_b is irrelevant after normalisation.",
  units_and_range="dimensionless; [0, 1] (Gaussian Gram matrices are PSD, so the centred inner products are >= 0); positively biased under independence; invariant to common positive scaling and shifts, not to rescaling y relative to x (probe, normalise=False: 0.890 -> 0.603 for y*10), default z-scoring removes pure scale differences.",
  direction_convention="undirected by mirroring only: bivariate(0,1) = 0.5561200526 vs bivariate(1,0) = 0.5771289783 on z-scored x0 vs x0^2; the matrix keeps the upper triangle (base.py:136-137): A[i, j] = A[j, i] = bivariate(x = process min(i, j), y = process max(i, j)).",
  symmetry_expected="sym",
  already_documented="no",
  new_finding_candidates=[
    "Candidate (order dependence): bandwidth computed from the first argument only (hyppo/tools/common.py:323-333, applied to both at 342-343); probe bivariate(0,1) = 0.5561 vs bivariate(1,0) = 0.5771; the pyspi matrix reports 0.55612, so the value depends on which process has the lower index.",
    "Candidate (normalisation and square root not documented): hsic.py:118-122 + dcorr.py:443-447 return sqrt of normalised HSIC_b, not HSIC_b (probe: 0.8774 vs raw 0.0577).",
    "Candidate (relative-scale dependence when normalise=False): probe y*1 -> 0.8896, y*10 -> 0.6030, y*0.1 -> 0.8649 (dcorr_biased constant at 0.9105).",
  ],
  proposed_checks=[
    dict(datasets=["bivariate_gaussian","nonlinear_dependence","anm","contaminated","iid_gaussian"], path="kernel",
         reference="from-scratch numpy: Gaussian Gram matrices with sigma = median off-diagonal distance of the FIRST argument for both, HSIC_b = (1/n^2) tr(KHLH), stat = sqrt(HSIC_b(K,L)/sqrt(HSIC_b(K,K) HSIC_b(L,L))) (checks/refs/dcorr_hsic.py; no hyppo import)",
         reference_kind="independent-impl", criterion="tolerance",
         expected_outcome="agreement to rtol 1e-10; per-variable-median variant differs at the 1e-3..1e-2 relative level on pairs with different marginal shapes"),
    dict(datasets=["nonlinear_dependence","anm","contaminated"], path="pipeline",
         reference="from-scratch kernel in both argument orders; pyspi on original and reversed process order",
         reference_kind="independent-impl", criterion="direction",
         expected_outcome="A[i,j] = A[j,i] = reference(x_min(i,j), x_max(i,j)); reversed process order changes the values for pairs with different marginal shapes"),
    dict(datasets=["bivariate_gaussian"], path="pipeline",
         reference="analytic population normalised HSIC (Gaussian integrals, sigma = 0.9539), then square root: rho=0.3 -> 0.213, rho=0.8 -> 0.688",
         reference_kind="analytic", criterion="statistical",
         expected_outcome="pair (0,1) -> about 0.21 and (2,3) -> about 0.69, approached from above (positive V-statistic bias) as T grows"),
    dict(datasets=["iid_gaussian"], path="pipeline",
         reference="analytic null HSIC = 0; V-statistic positive bias",
         reference_kind="analytic", criterion="direction",
         expected_outcome="all values > 0, mean decreasing with T"),
    dict(datasets=["trending","bivariate_gaussian"], path="pipeline-detrend",
         reference="detrend(D2 + slope*t) == detrend(D2)",
         reference_kind="analytic", criterion="tolerance",
         expected_outcome="pipeline-detrend(trending) equals pipeline-detrend(bivariate_gaussian) to ~1e-10"),
  ],
)

for uid, c in recs.items():
    rec = {"unit_id": uid, "status": "traced", "correctness": c}
    (OUT / f"{uid}.yaml").write_text(yaml.safe_dump(rec, sort_keys=False, allow_unicode=True, width=120))
    print("wrote", uid)
