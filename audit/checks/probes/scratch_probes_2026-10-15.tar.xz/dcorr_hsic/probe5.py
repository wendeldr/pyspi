import numpy as np
from sklearn.metrics import pairwise_distances
from hyppo.independence import Dcorr, Hsic
from hyppo.independence.dcorr import _dcorr
rng=np.random.default_rng(3)
for T in (256,4096):
    x=rng.standard_normal((T,1)); y=(x**2+0.1*rng.standard_normal((T,1)))
    x=(x-x.mean())/x.std(ddof=1); y=(y-y.mean())/y.std(ddof=1)
    Dx=pairwise_distances(x,metric='euclidean'); Ex=np.abs(x-x.T)
    print(T,'max|sk-abs|',np.abs(Dx-Ex).max(), 'diag max', np.abs(np.diag(Dx)).max())
    Dy=pairwise_distances(y,metric='euclidean'); Ey=np.abs(y-y.T)
    for b in (False,True):
        print('  bias',b, 'hyppo',Dcorr(bias=b).statistic(x,y), 'exactdist', _dcorr(Ex,Ey,bias=b), 'diff', Dcorr(bias=b).statistic(x,y)-_dcorr(Ex,Ey,bias=b))
