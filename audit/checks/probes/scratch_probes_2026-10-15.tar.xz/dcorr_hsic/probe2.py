import numpy as np
from hyppo.independence import Hsic
from pyspi.statistics.distance import HilbertSchmidtIndependenceCriterion as H
from pyspi.data import Data
import contextlib, io
rng=np.random.default_rng(1)
def sq(x): return (x[:,None]-x[None,:])**2
def gram(x,sigma): return np.exp(-sq(x)/(2*sigma**2))
def med(x):
    d=np.sqrt(sq(x)); iu=np.triu_indices(len(x),1); return np.median(d[iu])
def dc(A): return A - A.mean(0)[None,:] - A.mean(1)[:,None] + A.mean()
def hsic_b(K,L): n=len(K); return np.sum(dc(K)*dc(L))/n**2       # Gretton 2005 biased (1/n^2 tr KHLH)
def hsic_u_song(K,L):  # Song et al 2012 JMLR eq.5 unbiased
    n=len(K); K=K.copy(); L=L.copy(); np.fill_diagonal(K,0); np.fill_diagonal(L,0); o=np.ones(n)
    return (np.trace(K@L) + (o@K@o)*(o@L@o)/((n-1)*(n-2)) - 2/(n-2)*(o@K@L@o))/(n*(n-3))
n=150
x=rng.standard_normal(n); y=np.exp(x)+0.3*rng.standard_normal(n)   # different marginals
sx=med(x); sy=med(y)
K=gram(x,sx); Lx=gram(y,sx); Ly=gram(y,sy)
print('median x', sx, 'median y', sy)
nb=lambda K,L: hsic_b(K,L)/np.sqrt(hsic_b(K,K)*hsic_b(L,L))
nu=lambda K,L: hsic_u_song(K,L)/np.sqrt(hsic_u_song(K,K)*hsic_u_song(L,L))
X,Y=x[:,None],y[:,None]
print('hyppo biased(x,y)  ', Hsic(bias=True).statistic(X,Y))
print('  sqrt(nHSIC_b) shared sigma_x', np.sqrt(nb(K,Lx)), ' own sigmas', np.sqrt(nb(K,Ly)), ' raw HSIC_b', hsic_b(K,Lx))
print('hyppo unbiased(x,y)', Hsic(bias=False).statistic(X,Y))
print('  nHSIC_u(Song) shared sigma_x', nu(K,Lx), ' own sigmas', nu(K,Ly), ' raw HSIC_u', hsic_u_song(K,Lx))
print('hyppo biased(y,x)  ', Hsic(bias=True).statistic(Y,X), ' unbiased(y,x)', Hsic(bias=False).statistic(Y,X))
Ky=gram(x,sy)
print('  sqrt(nHSIC_b) shared sigma_y', np.sqrt(nb(Ky,Ly)), ' nHSIC_u shared sigma_y', nu(Ky,Ly))
# negative unbiased under independence
v=[Hsic().statistic(rng.standard_normal((64,1)),rng.standard_normal((64,1))) for _ in range(200)]
print('unbiased hsic indep T=64 frac<0', np.mean(np.array(v)<0), 'min', min(v))
# pyspi through Data (z-scored) on nonlinear pair; check asym + mirror
x0=rng.uniform(-1,1,256); x1=x0**2+0.05*rng.standard_normal(256); x2=rng.standard_normal(256)
with contextlib.redirect_stdout(io.StringIO()):
    d=Data(np.vstack([x0,x1,x2]),dim_order='ps')
    for b in (False,True):
        s=H(biased=b)
        A=s.multivariate(d)
        print(s.identifier, 'A=\n', A)
        print('  biv(0,1)', s.bivariate(d,i=0,j=1), 'biv(1,0)', s.bivariate(d,i=1,j=0))
