import warnings, io, contextlib
import numpy as np
warnings.simplefilter("ignore")
from mne.time_frequency import morlet
from mne.time_frequency.tfr import cwt
from scipy.stats import zscore
from pyspi.data import Data
from pyspi.statistics import wavelet as W
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
print("## small-T low band through pyspi (morlet_cwt hypothesis)")
rng = np.random.default_rng(0)
for T in (16, 24, 25):
    with warnings.catch_warnings(record=True) as w, contextlib.redirect_stdout(io.StringIO()):
        warnings.simplefilter("always"); d = Data(rng.standard_normal((3, T)), dim_order="ps")
        A = W.CoherenceMagnitude(fmin=0, fmax=0.25).multivariate(d); Af = W.CoherenceMagnitude().multivariate(d)
    print(T, "n freqs", len(d.mne["coh"][1]), "low-band A[1,0]", A[1,0], "full A[1,0]", Af[1,0], "warnings", sorted({str(x.message)[:40] for x in w}))
print("## ppc: acc.real exactly +-1?")
f = np.linspace(0.2, 0.5, 125); Ws = morlet(1.0, f, n_cycles=f/7.0, zero_mean=True)
x = zscore(np.load(f"{D}iid_gaussian_T256.npz")["x"], axis=1, ddof=1); C = cwt(x, Ws, use_fft=True, mode="same"); csd = C[1]*C[0].conj()
denom = np.abs(csd); acc = csd/denom
print("n |acc.real| != 1:", np.sum(np.abs(acc.real) != 1), " n |acc.real|>1:", np.sum(np.abs(acc.real) > 1), " n |acc.real|<1:", np.sum(np.abs(acc.real) < 1), " (|acc|^2-1)<0:", np.sum((acc*np.conj(acc)).real - 1 < 0))
print("   c*(1/c) < 1 count over the denominators:", np.sum(denom*(1.0/denom) < 1), " > 1:", np.sum(denom*(1.0/denom) > 1))
