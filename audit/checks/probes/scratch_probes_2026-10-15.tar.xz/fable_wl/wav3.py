import warnings, io, contextlib
import numpy as np
warnings.simplefilter("ignore")
import mne_connectivity as mnec
from mne.time_frequency import morlet
from mne.time_frequency.tfr import cwt
from scipy.stats import zscore
from pyspi.data import Data
from pyspi.statistics.wavelet import PhaseSlopeIndex, CoherencePhase
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
f = np.linspace(0.2, 0.5, 125); Ws = morlet(1.0, f, n_cycles=f/7.0, zero_mean=True)
print("## phase: accumulator signed-zero mechanism")
for nm, T in (("narrowband_f0-0.25", 256), ("delayed_noise", 256)):
    x = zscore(np.load(f"{D}{nm}_T{T}.npz")["x"], axis=1, ddof=1)
    C = cwt(x, Ws, use_fft=True, mode="same"); csd = C[1]*C[0].conj()
    cohy = mnec.spectral_connectivity_epochs(x[None], method="cohy", mode="cwt_morlet", sfreq=1, fmin=5/T, fmax=0.5, cwt_freqs=f, cwt_n_cycles=f/7.0, verbose="WARNING").get_data("dense")[1,0]
    z0 = csd.imag == 0
    print(nm, "raw csd: exact-zero Im", z0.sum(), "neg-zero", np.signbit(csd.imag[z0]).sum(), "| mne cohy: exact-zero Im", (cohy.imag==0).sum(), "neg-zero", np.signbit(cohy.imag[cohy.imag==0]).sum())
    nz_neg = np.sum(z0 & (csd.real < 0)); N = csd.size
    with contextlib.redirect_stdout(io.StringIO()):
        A = CoherencePhase().multivariate(Data(x, dim_order="ps")); B = CoherencePhase().multivariate(Data(x[::-1], dim_order="ps"))[::-1, ::-1]
    print("   A01", A[0,1], "B01", B[0,1], "A+B", A[0,1]+B[0,1], " 2pi*n(Im==0&Re<0)/N =", 2*np.pi*nz_neg/N, " n", nz_neg, "N", N)
    print("   pi*frac(z0*z1<0) =", np.pi*np.mean(x[0]*x[1] < 0))
print("## psi delayed_noise T=256 max-variant range")
X = np.load(D+"delayed_noise_T256.npz")["x"]
with contextlib.redirect_stdout(io.StringIO()):
    dd = Data(X, dim_order="ps"); Am = PhaseSlopeIndex(statistic="max").multivariate(dd); Amean = PhaseSlopeIndex().multivariate(dd)
    Al = PhaseSlopeIndex(fmin=0, fmax=0.25, statistic="max").multivariate(dd); Ah = PhaseSlopeIndex(fmin=0.25, fmax=0.5, statistic="max").multivariate(dd)
print("mean variant range", np.nanmin(Amean), np.nanmax(Amean), "max variants ranges", np.nanmin(Am), np.nanmax(Am), np.nanmax(Al), np.nanmax(Ah))
print("## mt_adaptive in psi path bitwise")
z = zscore(X, axis=1, ddof=1)[None]; fr = np.linspace(0.2, 0.5, 10)
a = mnec.phase_slope_index(data=z, mode="cwt_morlet", sfreq=1, mt_adaptive=True, cwt_freqs=fr, verbose="WARNING").get_data("dense")
b = mnec.phase_slope_index(data=z, mode="cwt_morlet", sfreq=1, mt_adaptive=False, cwt_freqs=fr, verbose="WARNING").get_data("dense")
print("psi mt_adaptive True==False bitwise", np.array_equal(a, b))
print("## psi: are all first-10 samples inside cone? wavelet half-length min", min((w.size-1)//2 for w in morlet(1, fr, n_cycles=7, zero_mean=True)))
print("## ppc: can +inf occur? hypot check: |csd| >= |Re csd| always?")
x = zscore(np.load(f"{D}iid_gaussian_T256.npz")["x"], axis=1, ddof=1); C = cwt(x, Ws, use_fft=True, mode="same"); csd = C[1]*C[0].conj()
acc = csd/np.abs(csd); m2 = (acc*np.conj(acc)).real
print("   (|acc|^2 - 1): n>0", np.sum(m2-1 > 0), "n<0", np.sum(m2-1 < 0), "n==0", np.sum(m2-1 == 0), " n |csd|<|Re|", np.sum(np.abs(csd) < np.abs(csd.real)), " n |csd|>|Re|", np.sum(np.abs(csd) > np.abs(csd.real)))
