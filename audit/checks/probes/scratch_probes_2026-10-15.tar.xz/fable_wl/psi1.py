import warnings, io, contextlib
import numpy as np
warnings.simplefilter("ignore")
import mne_connectivity as mnec
from mne.time_frequency import morlet
from mne.time_frequency.tfr import cwt
from scipy.stats import zscore
from pyspi.data import Data
from pyspi.statistics.wavelet import PhaseSlopeIndex
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
print("MRO", [c.__name__ for c in PhaseSlopeIndex.__mro__])
s = PhaseSlopeIndex(); print(s.identifier, s.labels)
freqs = np.linspace(0.2, 0.5, 10)
Wv = morlet(1, freqs, n_cycles=7, zero_mean=True)
print("wavelet lengths", [w.size for w in Wv], "half", [(w.size-1)//2 for w in Wv], "max|Im W(0.5)|", np.abs(Wv[-1].imag).max())
def run(X, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        dd = Data(X, dim_order="ps"); A = PhaseSlopeIndex(**kw).multivariate(dd)
    return A, dd.mne_psi["psi"], dd.mne_psi["freq"]
print("## delayed_noise T=256")
X = np.load(D+"delayed_noise_T256.npz")["x"]
A, psi, fr = run(X); print("psi shape", psi.shape, "freq", fr)
for fmin, fmax in [(0,.5),(0,.25),(.25,.5)]: print("  band", fmin, fmax, "freq_id", np.where((fr>=fmin)*(fr<=fmax))[0])
print("A[1,0]", repr(A[1,0]), "mean psi[1,0,0,:10]", repr(psi[1,0,0,:10].mean()), "equal", A[1,0] == psi[1,0,0,:10].mean(), "all-time mean", psi[1,0,0].mean())
print("upper tri zero", np.all(psi[0,1] == 0), "sym", np.array_equal(A, A.T, equal_nan=True))
Alo, _, _ = run(X, fmin=0, fmax=0.25); Ahi, _, _ = run(X, fmin=0.25, fmax=0.5)
print("low == mean t0,1", Alo[1,0] == psi[1,0,0,:2].mean(), " high == mean t2..9", Ahi[1,0] == psi[1,0,0,2:10].mean())
print("value range mean variant", np.nanmin(A), np.nanmax(A))
print("## unit modulus and sum of sines, delayed_noise T=1024")
X = zscore(np.load(D+"delayed_noise_T1024.npz")["x"], axis=1, ddof=1); z = X[None]
cohy = mnec.spectral_connectivity_epochs(z, method="cohy", mode="cwt_morlet", sfreq=1, cwt_freqs=freqs, verbose="WARNING").get_data("dense")
print("|cohy[1,0]| range", np.abs(cohy[1,0]).min(), np.abs(cohy[1,0]).max(), " Im cohy(0.5) max", np.abs(cohy[1,0,-1].imag).max())
con = mnec.phase_slope_index(data=z, mode="cwt_morlet", sfreq=1, cwt_freqs=freqs, verbose="WARNING"); psi = con.get_data("dense")[:,:,0,:]
tf = cwt(X, Wv, use_fft=True, mode="same"); dphi = np.angle(tf[1]) - np.angle(tf[0])
alt = np.sin(np.diff(dphi, axis=0)).sum(axis=0); print("max|psi[1,0] - sum sin|", np.abs(alt - psi[1,0]).max())
print("Nyquist term mean abs", np.abs(np.sin(dphi[-1]-dphi[-2])).mean(), " dphi(0.5) mod pi uniq", np.unique(np.round(np.mod(dphi[-1], np.pi), 6)))
print("## direction convention test: pure delay, indices seed=0,target=1, x1 = x0 delayed by 2")
rng = np.random.default_rng(1); T = 2048; b = rng.standard_normal(T+2); x0 = b[2:]; x1 = b[:-2]
zz = zscore(np.stack([x0, x1]), axis=1, ddof=1)[None]
c = mnec.phase_slope_index(data=zz, indices=(np.array([0]), np.array([1])), mode="cwt_morlet", sfreq=1, cwt_freqs=freqs, verbose="WARNING").get_data()
print("PSI(seed0->target1) central mean (x0 leads):", c[0,0,60:-60].mean(), " first10 mean", c[0,0,:10].mean())
print("## direction on audit data")
for T in [64,256,1024,4096]:
    X = np.load(D+f"delayed_noise_T{T}.npz")["x"]; A, psi, _ = run(X); psi = psi[:,:,0,:]
    cs = slice(30, T-30) if T > 80 else slice(28, T-28)
    print(T, "; ".join(f"({i},{j}) A{A[i,j]:+.2f} c{psi[i,j,cs].mean():+.2f}" for i in range(4) for j in range(i)))
for T in [64,256,1024,4096]:
    X = np.load(D+f"var2_bivariate_T{T}.npz")["x"]; A, psi, _ = run(X); psi = psi[:,:,0,:]
    print("var2", T, "A[1,0]", round(A[1,0],3), "central", round(psi[1,0,28:T-28].mean(),3), "alltime", round(psi[1,0].mean(),3))
zf = np.load(D+"var2_bivariate_T4096.npz"); S = zf["S_true"]; fq = zf["freqs"]; print("A1", zf["A1"] if "A1" in zf else list(zf.keys()))
C = S[:,0,1]/np.sqrt(S[:,0,0].real*S[:,1,1].real)
for lo, hi in [(0.2,0.5),(0,0.5),(0,0.25),(0.25,0.5)]:
    mm = (fq>=lo)&(fq<=hi); Cb = C[mm]; print("analytic PSI01 band", lo, hi, np.imag(np.sum(np.conj(Cb[:-1])*Cb[1:])), "n bins", mm.sum())
# analytic on the 10-pt wavelet grid
Ci = np.interp(freqs, fq, C.real) + 1j*np.interp(freqs, fq, C.imag); print("analytic PSI01 on linspace(0.2,0.5,10) grid", np.imag(np.sum(np.conj(Ci[:-1])*Ci[1:])))
print("## reversal")
X = np.load(D+"delayed_noise_T256.npz")["x"]
A, _, _ = run(X); B, _, _ = run(X[::-1]); B = B[::-1, ::-1]; print("mean max|B+A|", np.nanmax(np.abs(B + A)))
A, _, _ = run(X, statistic="max"); B, _, _ = run(X[::-1], statistic="max"); B = B[::-1, ::-1]; print("max variant A[1,0]", A[1,0], "B[1,0]", B[1,0])
print("## small T")
rng = np.random.default_rng(0)
for T in [20, 40]:
    X = rng.standard_normal((3, T))
    with warnings.catch_warnings(record=True) as w, contextlib.redirect_stdout(io.StringIO()):
        warnings.simplefilter("always"); dd = Data(X, dim_order="ps"); A = PhaseSlopeIndex(fmin=0, fmax=0.25).multivariate(dd)
    print(T, "freq", np.round(dd.mne_psi["freq"], 3), "A[1,0]", A[1,0], "warn", [str(x.message)[:60] for x in w])
