import warnings, io, contextlib, collections
import numpy as np
warnings.filterwarnings("ignore")
from sklearn.linear_model import SGDRegressor, Ridge, Lasso, ElasticNet, BayesianRidge
from pyspi.data import Data
from pyspi.statistics.misc import LinearModel
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
def mk(x, normalise=True):
    with contextlib.redirect_stdout(io.StringIO()): return Data(x, dim_order="ps", normalise=normalise)
names = ["iid_gaussian","bivariate_gaussian","delayed_noise","nonlinear_dependence","anm","sparse_precision","var2_bivariate","gauss_ar1_pair","narrowband_f0-0.25","contaminated","cointegrated","trending","logistic_maps","shared_envelope"]
def closed(z, model):
    P, T = z.shape; A = np.full((P, P), np.nan)
    for i in range(P):
        for j in range(P):
            if i == j: continue
            x = z[i]-z[i].mean(); y = z[j]-z[j].mean(); sxx = x@x; sxy = x@y; n = T
            if model == "Ridge": w = sxy/(sxx+1.0)
            elif model == "Lasso": w = np.sign(sxy)*max(abs(sxy)-n, 0)/sxx
            elif model == "ElasticNet": w = np.sign(sxy)*max(abs(sxy)-0.5*n, 0)/(sxx+0.5*n)
            elif model == "OLS": w = sxy/sxx
            elif model == "BayesianRidge":
                yv = y.var(); a = 1/(yv+np.finfo(float).eps); lam = 1.0; wold = None
                for it in range(300):
                    w = sxy/(sxx+lam/a); sse = np.sum((y-w*x)**2); g = a*sxx/(lam+a*sxx); lam = (g+2e-6)/(w*w+2e-6); a = (n-g+2e-6)/(sse+2e-6)
                    if it != 0 and abs(wold-w) < 1e-3: break
                    wold = w
                w = sxy/(sxx+lam/a)
            A[i, j] = np.mean((y-w*x)**2)
    return A
tot = 0; worse = collections.Counter(); maxex = (0, None); maxasym = {m: 0 for m in ["Ridge","Lasso","ElasticNet","BayesianRidge","SGDRegressor"]}; maxdiff = {m: 0 for m in ["Ridge","Lasso","ElasticNet","BayesianRidge"]}
lasso_dev = 0; en_const_sets = []
for nm in names:
    for T in [64, 256, 1024, 4096]:
        x = np.load(f"{D}{nm}_T{T}.npz")["x"]; d = mk(x); z = d.to_numpy(squeeze=True); P = z.shape[0]; off = ~np.eye(P, dtype=bool)
        R = np.corrcoef(z); c = (T-1)/T
        for m in ["Ridge","Lasso","ElasticNet","BayesianRidge"]:
            A = LinearModel(m).multivariate(d); ref = closed(z, m)
            maxdiff[m] = max(maxdiff[m], np.nanmax(np.abs(A-ref)[off])); maxasym[m] = max(maxasym[m], np.nanmax(np.abs(A-A.T)))
            if m == "Ridge": assert np.nanmax(np.abs(A - c*(1-R**2*(T-1)*(T+1)/T**2))[off]) < 1e-12
            if m == "Lasso": lasso_dev = max(lasso_dev, np.nanmax(np.abs(A[off]-c)))
            if m == "ElasticNet" and nm in ("iid_gaussian","delayed_noise","nonlinear_dependence"): en_const_sets.append(np.nanmax(np.abs(A[off]-c)))
        A = LinearModel("SGDRegressor").multivariate(d); A2 = LinearModel("SGDRegressor").multivariate(d); assert np.array_equal(A, A2, equal_nan=True)
        ols = c*(1-R**2); ex = (A-ols)[off]; tot += ex.size; worse[T] += int(np.sum(A[off] > c)); maxasym["SGDRegressor"] = max(maxasym["SGDRegressor"], np.nanmax(np.abs(A-A.T)))
        if ex.max() > maxex[0]: maxex = (ex.max(), (nm, T))
        if ex.min() < -1e-12: print("SGD BELOW OLS!", nm, T, ex.min())
print("ordered pairs", tot, "SGD worse than mean by T", dict(worse), "total", sum(worse.values()), "max excess", maxex)
print("maxdiff from closed form", maxdiff, "max asym", maxasym)
print("Lasso max dev from (T-1)/T over all", lasso_dev, " EN constant on iid/delayed/nonlinear: max dev", max(en_const_sets))
print("## SGD details bivariate_gaussian")
for T in [64, 256, 1024, 4096]:
    z = mk(np.load(f"{D}bivariate_gaussian_T{T}.npz")["x"]).to_numpy()
    for (i, j) in [(0,1),(2,3)]:
        X = z[i]; y = np.ravel(z[j])
        with warnings.catch_warnings(record=True) as wl:
            warnings.simplefilter("always"); m = SGDRegressor(random_state=42).fit(X, y)
        mse = np.mean((m.predict(X)-y)**2); xc = X[:,0]-X[:,0].mean(); yc = y-y.mean(); wols = (xc@yc)/(xc@xc); mols = np.mean((yc-wols*xc)**2)
        seeds = [np.mean((SGDRegressor(random_state=s).fit(X, y).predict(X)-y)**2) for s in range(10)]
        print(f"T={T} {i}->{j} n_iter={m.n_iter_} coef={m.coef_[0]:.5f} wols={wols:.5f} icpt={m.intercept_[0]:.2e} excess={mse-mols:.2e} warn={[type(w.message).__name__ for w in wl]} seeds={min(seeds)-mols:.1e}..{max(seeds)-mols:.1e}")
print("## misc on bivariate_gaussian T256 pair 2->3")
z = mk(np.load(f"{D}bivariate_gaussian_T256.npz")["x"]).to_numpy(); X = z[2]; y = np.ravel(z[3]); print("r", np.corrcoef(X[:,0], y)[0,1])
for M in [Ridge, Lasso, ElasticNet]:
    a = M(random_state=42).fit(X, y).predict(X); b = M(random_state=7).fit(X, y).predict(X); cc = M().fit(X, y).predict(X); print(M.__name__, "rs effect", np.max(np.abs(a-b)), np.max(np.abs(a-cc)))
for M in [Lasso, ElasticNet]:
    m = M(random_state=42).fit(X, y); print(M.__name__, "n_iter", m.n_iter_, "coef", m.coef_, "icpt", m.intercept_, "gap", m.dual_gap_)
m = BayesianRidge().fit(X, y); print("BR n_iter", m.n_iter_, "coef", m.coef_, "alpha", m.alpha_, "lambda", m.lambda_, "ratio", m.lambda_/m.alpha_)
m = Ridge(random_state=42).fit(X, y); print("Ridge solver_", m.solver_, "coef", m.coef_, "r(T-1)/T", np.corrcoef(X[:,0], y)[0,1]*255/256)
print("## shared_envelope identical pair")
for T in [64, 4096]:
    d = mk(np.load(f"{D}shared_envelope_T{T}.npz")["x"])
    for mn in ["Ridge","Lasso","ElasticNet","BayesianRidge"]:
        A = LinearModel(mn).multivariate(d); print(T, mn, "A[0,2]=%.4e" % A[0,2], "ridge-analytic %.4e" % ((T-1)/T**3), "en 4/9-ish %.4f" % ((T-1)/T*(1-((T-1)/T-0.5)/((T-1)/T+0.5))**2))
print("## raw scaled_offset T1024")
x = np.load(f"{D}scaled_offset_T1024.npz")["x"]; d = mk(x, normalise=False); v0 = x.var(axis=1); print("var0", v0, "cov0", np.cov(x, bias=True).round(3).tolist())
for mn in ["Lasso", "Ridge"]:
    A = LinearModel(mn).multivariate(d); print(mn); print(np.array2string(A, precision=4))
    if mn == "Lasso": print("entries == var0(target) (col):", [(i, j, A[i,j] == v0[j]) for i in range(4) for j in range(4) if i != j])
    if mn == "Ridge":
        T = 1024; xc = x[2]-x[2].mean(); yc = x[3]-x[3].mean(); sxx = xc@xc; cov0 = (xc@yc)/T; print("Ridge (2,3) formula", v0[3] - cov0**2*T*(sxx+2)/(sxx+1)**2, "pyspi", A[2,3])
