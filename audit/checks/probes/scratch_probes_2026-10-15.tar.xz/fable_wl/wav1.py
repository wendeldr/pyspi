import warnings, io, contextlib
import numpy as np
warnings.simplefilter("ignore")
import mne_connectivity as mnec
from mne.time_frequency import morlet
from mne.time_frequency.tfr import cwt
from scipy.stats import zscore
from pyspi.data import Data
from pyspi.statistics import wavelet as W
DATA = "/media/dan/Data/git/pyspi/audit/checks/data/"
f = np.linspace(0.2, 0.5, 125)
print("## 1. morlet with n_cycles=f/7")
Ws = morlet(1.0, f, n_cycles=f/7.0, zero_mean=True)
print("n", len(Ws), "lengths", sorted(set(w.size for w in Ws)), "values", np.unique(np.array([w[0] for w in Ws])))
print("sigma_t", 1/(14*np.pi), "5sigma", 5/(14*np.pi), "arange", np.arange(0, 5/(14*np.pi), 1.0))
print("sqrt2", np.sqrt(2), "W==sqrt2 exactly?", all(w[0] == np.sqrt(2) for w in Ws))
W7 = morlet(1.0, f, n_cycles=7.0, zero_mean=True); print("n_cycles=7 lengths", min(w.size for w in W7), max(w.size for w in W7))
print("## 2. grid")
print("n<=0.25", np.sum(f <= 0.25), "n>=0.25", np.sum(f >= 0.25), "f[20]", f[20], "step", f[1]-f[0])
for T in (16, 24, 25): print("T", T, "kept", np.sum((f >= 5/T) & (f <= 0.5)))
print("## 3. raw iid_gaussian T=256")
x = zscore(np.load(DATA+"iid_gaussian_T256.npz")["x"], axis=1, ddof=1)
z = x[None]
def run(meth, **kw):
    a = dict(data=z, method=meth, mode="cwt_morlet", sfreq=1, mt_adaptive=True, fmin=5/256, fmax=0.5, cwt_freqs=f, cwt_n_cycles=f/7.0, verbose="WARNING"); a.update(kw)
    c = mnec.spectral_connectivity_epochs(**a); return c.get_data(output="dense"), c
C = cwt(x, Ws, use_fft=True, mode="same")
print("max|ReC - sqrt2 x|", np.max(np.abs(C.real - np.sqrt(2)*x[:, None, :])), "max|ImC|", np.max(np.abs(C.imag)), "frac ImC==0", np.mean(C.imag == 0), "spread", np.max(np.abs(C - C[:, :1])))
csd = C[1]*C[0].conj()
print("frac Im(csd10)==0", np.mean(csd.imag == 0), "of", csd.size)
pli, _ = run("pli"); print("pli[1,0] mean", pli[1,0].mean(), "1-frac", 1-np.mean(csd.imag == 0), "equal?", pli[1,0].mean() == 1-np.mean(csd.imag == 0), "max", pli[1,0].max())
coh, c = run("coh"); print("coh unique", np.unique(coh[1,0]), "n_epochs_used", c.n_epochs_used if hasattr(c,'n_epochs_used') else c.attrs.get("n_epochs_used"))
cohy, _ = run("cohy"); v = cohy[1,0]
print("cohy real unique (first 5)", np.unique(v.real)[:5], "n unique real", len(np.unique(v.real)))
ang = np.angle(v)
print("angles: exactly 0:", np.sum(ang == 0), " exactly +pi:", np.sum(ang == np.pi), " exactly -pi:", np.sum(ang == -np.pi), " other:", np.sum((ang != 0) & (np.abs(ang) != np.pi)), "of", ang.size)
print("   |ang| not in {0,pi} max deviation from nearest:", np.max(np.minimum(np.abs(ang), np.abs(np.pi - np.abs(ang)))))
fp, fm = np.mean(ang > 1), np.mean(ang < -1)
print("   mean angle", repr(ang.mean()), " pi*(frac+ - frac-)", repr(np.pi*(fp-fm)), " diff", ang.mean() - np.pi*(fp-fm), " max angle", repr(ang.max()), "== pi?", ang.max() == np.pi)
print("   counts near -pi/0/+pi:", np.sum(ang < -1), np.sum(np.abs(ang) < 1), np.sum(ang > 1))
# signed zero analysis
imz = csd.imag == 0
print("   Im csd exactly zero:", imz.sum(), " of which Re<0:", np.sum(imz & (csd.real < 0)), " signbit of those zeros (neg zero count):", np.sum(np.signbit(csd.imag[imz & (csd.real<0)])))
ppc, _ = run("ppc"); v = ppc[1,0]; print("ppc -inf", np.isneginf(v).sum(), "+inf", np.isposinf(v).sum(), "nan", np.isnan(v).sum(), "finite", np.isfinite(v).sum())
d, _ = run("pli2_unbiased"); v = d[1,0]; print("pli2_unbiased -inf", np.isneginf(v).sum(), "nan", np.isnan(v).sum(), "finite", np.isfinite(v).sum())
im, _ = run("imcoh"); print("imcoh max abs", np.abs(im[1,0]).max())
w2, _ = run("wpli2_debiased"); print("wpli2_debiased unique", np.unique(w2[1,0]))
wp, _ = run("wpli"); print("wpli == pli bitwise", np.array_equal(wp, pli))
a, _ = run("cohy", mt_adaptive=False); print("mt_adaptive cohy bitwise", np.array_equal(a, cohy))
p2, _ = run("pli", mt_adaptive=False); print("mt_adaptive pli bitwise", np.array_equal(p2, pli))
print("## 4. pyspi pipeline")
classes = [W.CoherenceMagnitude, W.CoherencePhase, W.ImaginaryCoherence, W.PhaseLockingValue, W.PairwisePhaseConsistency, W.PhaseLagIndex, W.DebiasedSquaredWeightedPhaseLagIndex, W.weighted_PhaseLagIndex, W.debiased_weighted_squared_PhaseLagIndex]
bands = [dict(fs=1), dict(fmin=0, fmax=0.25), dict(fmin=0.25, fmax=0.5), dict(fmin=0, fmax=0.5, statistic="max"), dict(fmin=0, fmax=0.25, statistic="max"), dict(fmin=0.25, fmax=0.5, statistic="max")]
for name, T in [("iid_gaussian", 256), ("narrowband_f0-0.1", 256), ("delayed_noise", 1024), ("shared_envelope", 64)]:
    xx = np.load(f"{DATA}{name}_T{T}.npz")["x"]
    with contextlib.redirect_stdout(io.StringIO()): dd = Data(xx, dim_order="ps")
    print("=====", name, T, xx.shape)
    res = {}
    for Cl in classes:
        outs = [Cl(**b).multivariate(dd) for b in bands]
        res[Cl.__name__] = outs
        iu = np.triu_indices(xx.shape[0], 1)
        s = Cl()
        print(f"{s.identifier:6s} {s._measure:15s} A01/band", np.array([o[0,1] for o in outs]).round(5), "sym", all(np.array_equal(o, o.T, equal_nan=True) for o in outs), "allbands-same", all(np.array_equal(outs[0], o, equal_nan=True) for o in outs[:3]), "offdiag uniq", np.unique(outs[0][iu])[:4])
    print("wspli==pli bitwise all bands", all(np.array_equal(a, b, equal_nan=True) for a, b in zip(res["weighted_PhaseLagIndex"], res["PhaseLagIndex"])))
    conn, fr = dd.mne["coh"]; print("conn", conn.shape, "freq", fr.min(), fr.max(), len(fr), "upper zero", np.all(conn[0,1] == 0), "lower nz", np.any(conn[1,0] != 0))
    ph = res["CoherencePhase"]; print("phase max variant == pi exactly?", [bool(np.all(o[iu] == np.pi)) for o in ph[3:]], "phase max values", ph[3][iu])
    print("cache keys", list(dd.mne.keys()))
