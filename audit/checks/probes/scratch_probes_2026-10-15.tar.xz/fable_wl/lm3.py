import warnings, io, contextlib
import numpy as np
warnings.filterwarnings("ignore")
from sklearn.linear_model import ElasticNet
from scipy.stats import zscore
print("## ElasticNet dead zone from tol-based initial exit; synthetic pairs with controlled r")
rng = np.random.default_rng(0)
for T in [64, 256, 1024, 4096]:
    base = rng.standard_normal(T); noise = rng.standard_normal(T)
    base = (base - base.mean())/base.std(ddof=1); noise -= noise @ base / (base @ base) * base; noise = (noise - noise.mean())/noise.std(ddof=1)
    first_nonzero = None; maxgap = 0
    for r in np.arange(0.49, 0.60, 0.0005):
        y = r*base + np.sqrt(1-r*r)*noise; y = zscore(y, ddof=1); x = zscore(base, ddof=1)
        rr = np.corrcoef(x, y)[0,1]; c = (T-1)/T
        w_closed = np.sign(rr)*max(abs(rr)*c-0.5, 0)/(c+0.5); mse_closed = c*(1-2*w_closed*rr+w_closed**2)
        m = ElasticNet(random_state=42).fit(x[:, None], y); mse = np.mean((m.predict(x[:, None]) - y)**2)
        if w_closed > 0 and m.coef_[0] == 0: maxgap = max(maxgap, mse - mse_closed); last_zero_r = rr
        if m.coef_[0] != 0 and first_nonzero is None: first_nonzero = rr
    print(f"T={T}: closed-form threshold |r|=0.5T/(T-1)={0.5*T/(T-1):.5f}; sklearn first nonzero coef at |r|~{first_nonzero:.4f}; max MSE gap (closed vs sklearn) in dead zone {maxgap:.2e}")
