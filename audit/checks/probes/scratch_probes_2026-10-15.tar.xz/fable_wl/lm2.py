import warnings, io, contextlib
import numpy as np
warnings.filterwarnings("ignore")
from sklearn.linear_model import ElasticNet, SGDRegressor
from pyspi.data import Data
from pyspi.statistics.misc import LinearModel
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()): return Data(x, dim_order="ps", normalise=True)
names = ["iid_gaussian","bivariate_gaussian","delayed_noise","nonlinear_dependence","anm","sparse_precision","var2_bivariate","gauss_ar1_pair","narrowband_f0-0.25","contaminated","cointegrated","trending","logistic_maps","shared_envelope"]
def en_closed(x, y, n):
    xc = x - x.mean(); yc = y - y.mean(); sxx = xc@xc; sxy = xc@yc
    w = np.sign(sxy)*max(abs(sxy)-0.5*n, 0)/(sxx+0.5*n); return w, np.mean((yc-w*xc)**2)
for nm in names:
    for T in [64,256,1024,4096]:
        d = mk(np.load(f"{D}{nm}_T{T}.npz")["x"]); z = d.to_numpy(squeeze=True); P = z.shape[0]
        A = LinearModel("ElasticNet").multivariate(d)
        worst = (0, None)
        for i in range(P):
            for j in range(P):
                if i == j: continue
                w, m = en_closed(z[i], z[j], T); dd = abs(A[i,j]-m)
                if dd > worst[0]: worst = (dd, (i, j, w, m, A[i,j], np.corrcoef(z[i], z[j])[0,1]))
        if worst[0] > 1e-12:
            i, j, w, m, a, r = worst[1]
            mdl = ElasticNet(random_state=42).fit(z[i][:, None], z[j])
            print(f"EN mismatch {nm} T={T} pair ({i},{j}) r={r:.6f} closed w={w:.6f} mse={m:.6f} pyspi={a:.6f} sk coef={mdl.coef_[0]:.6f} n_iter={mdl.n_iter_} gap={mdl.dual_gap_:.3e} tol*yy={1e-4*(z[j]-z[j].mean())@(z[j]-z[j].mean()):.3e}")
        As = LinearModel("SGDRegressor").multivariate(d); asym = np.nanmax(np.abs(As-As.T))
        if asym > 4e-4: print(f"SGD asym {nm} T={T}: {asym:.3e}")
