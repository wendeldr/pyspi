import warnings, io, contextlib, json
import numpy as np
warnings.simplefilter("ignore")
import mne_connectivity as mnec
from mne.time_frequency import morlet
from mne.time_frequency.tfr import cwt
from scipy.stats import zscore
from pyspi.data import Data
from pyspi.statistics import wavelet as W
DATA = "/media/dan/Data/git/pyspi/audit/checks/data/"
f = np.linspace(0.2, 0.5, 125)
print("## channel order")
for nm, T in (("narrowband_f0-0.25", 256), ("delayed_noise", 256)):
    x = np.load(f"{DATA}{nm}_T{T}.npz")["x"]
    res = {}
    for order in ("fwd", "rev"):
        xx = x if order == "fwd" else x[::-1]
        with contextlib.redirect_stdout(io.StringIO()): d = Data(xx, dim_order="ps")
        for Cl in (W.CoherencePhase, W.PhaseLagIndex, W.ImaginaryCoherence):
            A = Cl().multivariate(d)
            if order == "rev": A = A[::-1, ::-1]
            res[(Cl.__name__, order)] = A
    for Cn in ("CoherencePhase", "PhaseLagIndex", "ImaginaryCoherence"):
        a, b = res[(Cn, "fwd")], res[(Cn, "rev")]
        print(nm, Cn, "fwd A01", repr(a[0,1]), "rev", repr(b[0,1]), "sum", a[0,1]+b[0,1], "max|a-b|", np.nanmax(np.abs(a-b)), "max|a+b|", np.nanmax(np.abs(a+b)))
    # explanation: exact +0.0 Im points with Re<0 keep +pi under reversal
    z = zscore(x, axis=1, ddof=1); Ws = morlet(1.0, f, n_cycles=f/7.0, zero_mean=True)
    C = cwt(z, Ws, use_fft=True, mode="same")
    csd = C[1]*C[0].conj(); csdr = C[0]*C[1].conj()
    print("   csd_rev == conj(csd) bitwise (incl. signed zero)?", np.array_equal(csdr, np.conj(csd)), " equal values?", np.array_equal(csdr, np.conj(csd)) , " n Im==0 & Re<0:", np.sum((csd.imag==0)&(csd.real<0)), " neg-zero among them:", np.sum(np.signbit(csd.imag[(csd.imag==0)&(csd.real<0)])), " rev neg-zero:", np.sum(np.signbit(csdr.imag[(csdr.imag==0)&(csdr.real<0)])))
    ang = np.angle(csd); angr = np.angle(csdr)
    print("   mean ang fwd", ang.mean(), " rev", angr.mean(), " predicted rev = -fwd + 2pi*frac(+0 & Re<0):", -ang.mean() + 2*np.pi*np.mean((csd.imag==0)&(csd.real<0)&~np.signbit(csd.imag)))
print("## p4 variants")
rng = np.random.default_rng(3); T, R = 256, 8
s = rng.standard_normal((T + 5, R))
raw = np.stack([s[5:], s[:-5] + 0.3*rng.standard_normal((T, R)), rng.standard_normal((T, R))])
with contextlib.redirect_stdout(io.StringIO()): d = Data(raw, dim_order="psr")
for Cl in (W.CoherenceMagnitude, W.ImaginaryCoherence, W.PhaseLagIndex, W.weighted_PhaseLagIndex, W.PairwisePhaseConsistency, W.CoherencePhase):
    A = Cl().multivariate(d); print("psr R=8:", Cl().identifier, np.round(A[0,1],6), np.round(A[0,2],6))
conn, fr = d.mne["coh"]; print("coh (R=8) spread across freqs:", np.abs(conn[1,0] - conn[1,0,:1]).max(), "n_epochs?", )
x = rng.standard_normal((1, 3, 1024))
for meth in ("coh", "plv", "pli", "wpli", "imcoh", "ppc", "pli2_unbiased", "wpli2_debiased"):
    c = mnec.spectral_connectivity_epochs(data=x, method=meth, mode="cwt_morlet", sfreq=1, fmin=5/1024, fmax=0.5, cwt_freqs=f, cwt_n_cycles=7.0, verbose="WARNING").get_data(output="dense")[1,0]
    print(f"n_cycles=7 1ep {meth:15s} mean {np.nanmean(c): .4g} min {np.nanmin(c): .4g} max {np.nanmax(c): .4g} nnan {np.isnan(c).sum()} ninf {np.isinf(c).sum()}")
print("## sweep T=64, 1024: cohmag_mean, phase_max, pli_mean ceilings, ppc, dspli, dwspli, icoh")
m = json.load(open(DATA + "MANIFEST.json")); names = sorted({ff["name"] for ff in m["files"]})
for T in (64, 1024):
    allc, allpm, plis, ppcs, dsp, dws, ico = [], [], [], [], [], [], []
    for nm in names:
        try: x = np.load(f"{DATA}{nm}_T{T}.npz")["x"]
        except FileNotFoundError: continue
        with contextlib.redirect_stdout(io.StringIO()): d = Data(x, dim_order="ps")
        iu = np.triu_indices(x.shape[0], 1)
        allc += list(W.CoherenceMagnitude().multivariate(d)[iu]); allpm += [(nm, v) for v in W.CoherencePhase(statistic="max").multivariate(d)[iu]]
        plis += list(W.PhaseLagIndex().multivariate(d)[iu]); ppcs += list(W.PairwisePhaseConsistency().multivariate(d)[iu]); dsp += list(W.DebiasedSquaredWeightedPhaseLagIndex().multivariate(d)[iu]); dws += list(W.debiased_weighted_squared_PhaseLagIndex().multivariate(d)[iu]); ico += list(W.ImaginaryCoherence().multivariate(d)[iu])
    print(T, "n datasets", len(names), "cohmag unique", np.unique(allc), "pli min/max", min(plis), max(plis), "ppc unique", np.unique(ppcs), "dspli unique", np.unique(dsp), "dwspli unique", np.unique(dws), "icoh max abs", np.max(np.abs(ico)))
    pm = np.array([v for _, v in allpm]); print("   phase_max: n==pi", np.sum(pm == np.pi), "n other", np.sum(pm != np.pi), "others:", [(n, v) for n, v in allpm if v != np.pi][:5])
