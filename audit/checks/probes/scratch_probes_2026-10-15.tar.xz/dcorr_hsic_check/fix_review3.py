import re
R = '/media/dan/Data/git/pyspi/audit/records/'
def sub(path, old, new):
    s = open(path).read()
    assert s.count(old) == 1, (path, old[:60], s.count(old))
    open(path, 'w').write(s.replace(old, new))

CLASS = ("REVIEW M7 (docs/storage_comparison/REVIEW.md:189-193, negative debiased dspli/dswpli/ppc estimates are valid; metadata "
         "should separate an unsigned population target from the estimator range), REVIEW M8 (REVIEW.md:197, pec/pec_log negative despite "
         "unsigned) and EEG_OPTIMIZATION_NOTES.md:169 (review topic ''legitimate negative estimates'')")

# dcorr unbiased
p = R + 'distance.dcorr.biased-False.yaml'
sub(p, "  already_documented: 'no'\n",
    "  already_documented: 'partly: the class ''unsigned label on a legitimately negative bias-corrected estimator'' is documented for other SPIs in "
    + CLASS + "; none of them names dcorr. The double work of the generic Undirected path is EEG_OPTIMIZATION_NOTES.md:132. The scale mismatch, "
    "the double-centring wording and the zero clamp are not in KNOWN_ISSUES.md'\n")
sub(p, "unbiased estimator; the issue is the label/range description, which REVIEW M7 documents for dspli/dswpli/ppc but not for dcorr'",
    "unbiased estimator; the issue is the label/range description. Already-documented class: " + CLASS +
    "; dcorr is not named there, so this is a new instance of a documented class, not a new mechanism'")

# hsic unbiased
p = R + 'distance.hsic.biased-False.yaml'
sub(p, "  already_documented: 'no'\n",
    "  already_documented: 'partly: the class ''unsigned label on a legitimately negative bias-corrected estimator'' is documented for other SPIs in "
    + CLASS + "; none of them names hsic. The double work of the generic Undirected path is EEG_OPTIMIZATION_NOTES.md:132. The order dependence, "
    "the undocumented normalisation and the scale mismatch are not in KNOWN_ISSUES.md'\n")
sub(p, "Not in KNOWN_ISSUES for hsic (REVIEW M7 covers dspli/dswpli/ppc)'",
    "Already-documented class: " + CLASS + "; hsic is not named there, so this is a new instance of a documented class, not a new mechanism'")

# dcorr biased: score 10 -> 9
p = R + 'distance.dcorr.biased-True.yaml'
sub(p, "  score_0_10: 10\n", "  score_0_10: 9\n")
sub(p, "  what_changed: 'None for the estimator: the Szekely",
    "  what_changed: 'Score 9, not 10 (anchor 9: matches canonical up to a convention; anchor 10 also requires matching the supplement description, which"
    " this does not): the supplement omits the centring step and presents dcorr/dcorr_biased as biased/unbiased versions of one statistic"
    " although they are on different scales. None for the estimator: the Szekely")
