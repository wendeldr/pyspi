import json
U = {"dcorr": "distance.dcorr.biased-False", "dcorr_biased": "distance.dcorr.biased-True",
     "hsic": "distance.hsic.biased-False", "hsic_biased": "distance.hsic.biased-True"}
PROBE = {"module": "probes/dcorr_hsic_probes.py", "function": "unmirrored"}
runs = []
def add(ident, ds, T, path, tag, processes=None, probe=None):
    u = U[ident]
    runs.append(dict(run_id=f"{u}|{ds}|{T}|{path}|{tag}", unit_id=u, identifier=ident, dataset=ds, T=T,
                     path=path, processes=processes, seed=42, probe=probe))
for ident in U:
    is_d = ident.startswith("dcorr")
    biased = ident.endswith("biased")
    Ts_bg = (64, 256, 1024, 4096) if is_d else (64, 256, 1024)
    kern = [("bivariate_gaussian", T) for T in Ts_bg] + [(d, 1024) for d in ("nonlinear_dependence", "anm", "contaminated")] + [("iid_gaussian", 256)]
    for ds, T in kern:
        add(ident, ds, T, "kernel", "scratch")
        if is_d:
            add(ident, ds, T, "kernel", "dcor")
    add(ident, "bivariate_gaussian", 1024, "pipeline", "scratch")
    if not is_d:
        add(ident, "scaled_offset", 1024, "kernel", "scratch")
        for ds in ("bivariate_gaussian", "nonlinear_dependence", "anm", "contaminated", "scaled_offset"):
            add(ident, ds, 1024, "kernel", "dhsic")
        if not biased:
            for ds in ("bivariate_gaussian", "nonlinear_dependence"):
                add(ident, ds, 64, "kernel", "eq3")
    # affine invariance / pipeline on scaled_offset
    add(ident, "scaled_offset", 1024, "pipeline", "affine")
    if is_d:
        add(ident, "scaled_offset", 1024, "kernel", "affine")
    # unmirrored (both orientations) probes
    add(ident, "scaled_offset", 1024, "kernel", "unmirrored", probe=PROBE)
    for ds in ("nonlinear_dependence", "anm") + (() if is_d else ("contaminated",)):
        add(ident, ds, 1024, "pipeline", "unmirrored", probe=PROBE)
    # reversed process order
    for ds in ("nonlinear_dependence",) + (() if is_d else ("anm",)):
        add(ident, ds, 1024, "pipeline", "reversed", processes=[3, 2, 1, 0])
    # null level vs T
    Ts_null = (64, 256, 1024, 4096) if is_d else (64, 256, 1024)
    for T in Ts_null:
        add(ident, "iid_gaussian", T, "pipeline", "null")
    add(ident, "iid_gaussian", 64, "pipeline", "null-trend")
    # convergence to the population value
    Ts_tr = (256, 1024, 4096) if is_d else (256, 1024)
    for T in Ts_tr:
        add(ident, "bivariate_gaussian", T, "pipeline", "truth-p01", processes=[0, 1])
        add(ident, "bivariate_gaussian", T, "pipeline", "truth-p23", processes=[2, 3])
    add(ident, "bivariate_gaussian", 256, "pipeline", "popcheck", processes=[2, 3])
    # nonlinear dependence detected
    for T in (256, 1024):
        add(ident, "nonlinear_dependence", T, "pipeline", "detected")
    # detrend
    add(ident, "trending", 1024, "pipeline-detrend", "detrend")
    add(ident, "trending", 1024, "pipeline", "trend-contrast")
    if biased:
        add(ident, "bivariate_gaussian", 4096 if is_d else 1024, "kernel" if is_d else "pipeline", "scale")
ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids))
json.dump({"family": "dcorr_hsic", "runs": runs}, open("/media/dan/Data/git/pyspi/audit/checks/manifest/dcorr_hsic.json", "w"), indent=1)
print(len(runs))
