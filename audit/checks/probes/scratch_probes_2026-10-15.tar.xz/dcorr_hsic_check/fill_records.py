import yaml
from pathlib import Path
R = Path('/media/dan/Data/git/pyspi/audit/records')
REF = 'audit/checks/refs/dcorr_hsic.py'
KD = 'audit/checks/refs/_kernels_distance.py'
PRB = 'audit/checks/probes/dcorr_hsic_probes.py'
SCR = '/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/dcorr_hsic_check'
CALC = 'pyspi/calculator.py:329 Calculator.compute calls self._spis[spi].multivariate(self.dataset); :332 np.fill_diagonal(S, nan) (lines at HEAD a42ebc1, unchanged since a1f20c7; the trace cited the pre-a1f20c7 lines 294/297)'

def rids(u, specs):
    return [f"{u}|{s}" for s in specs]

def fix_trace(c):
    c['implementation_trace'] = [CALC if t.startswith('pyspi/calculator.py:294') else t for t in c['implementation_trace']]

U = {}
# ---------------------------------------------------------------- dcorr (unbiased)
u = 'distance.dcorr.biased-False'
U[u] = dict(
 check_method='external-pkg',
 check_reference=(f'{REF}:chk_dcor (dcor==0.7 u_distance_correlation_sqr, method naive; does not import hyppo); {REF}:chk_scratch -> {KD}:dcorr / dcorr_from_dist '
   f'(U-centring, Szekely & Rizzo 2014 Sec. 3); {REF}:chk_truth (Szekely, Rizzo & Bakirov 2007 Thm 7(ii) closed form dcor2_closed, cross-checked by '
   f'quadrature dcor2_quad and a 10 x 65536 U-statistic Monte Carlo in chk_popcheck; se = Monte Carlo SD at T); {REF}:chk_null / chk_null_trend (Monte Carlo null); '
   f'{REF}:chk_unmirrored ({PRB}:unmirrored), chk_reversed, chk_affine, chk_detrend, chk_trend_contrast, chk_detected (200-permutation null)'),
 check_data='bivariate_gaussian T64/T256/T1024/T4096 (kernel), T1024 (pipeline), pairs (0,1)/(2,3) at T256/T1024/T4096; nonlinear_dependence T256/T1024; anm T1024; contaminated T1024; iid_gaussian T64/T256/T1024/T4096; scaled_offset T1024 (kernel and pipeline); trending T1024 (pipeline-detrend and pipeline)',
 agreement_criterion='exact: rtol 1e-10, atol 1e-12 (kernel, pipeline, affine, unmirrored, reversed); tolerance 1e-10 for pipeline-detrend; statistical: |pyspi - population dCor^2| <= 2 Monte Carlo SD at T; null: |mean over 10 pairs - Monte Carlo mean| <= 2 Monte Carlo SD of that mean; detection: value > max of 200 time permutations and z > 5 against both nulls',
 closeness=('dcor package u_distance_correlation_sqr: 8/8 exact runs pass, max_abs <= 7.2e-14 (bivariate_gaussian|4096|kernel|dcor 7.18e-14, max_rel 1.2e-11); the unsquared form sqrt(R*_n) is 0.068-0.250 away (ref_maxabs_vs_other_form). '
   'From-scratch U-centring: 9/9 pass, max_abs <= 7.4e-14 (ref_maxabs_vs_dcor2 = max_abs, ref_maxabs_vs_dcor 0.067-0.250), so the stored value is the SQUARED bias-corrected form R*_n. '
   'Population dCor^2 (rho=0.3 0.072362, rho=0.8 0.569869; closed form = quadrature to 3e-15, big Monte Carlo 0.073086 +- 0.000753 / 0.569129 +- 0.000753): '
   'pyspi (0,1)/(2,3) = 0.07474/0.59984 at T256, 0.05846/0.57756 at T1024, 0.07584/0.55453 at T4096; |pyspi - pop| 0.0024/0.0300, 0.0139/0.0077, 0.0035/0.0153; all 6 within 2 SD (max_z 1.63); Monte Carlo SD 0.031/0.039 -> 0.0069/0.0094. '
   'Null iid_gaussian: mean over 10 pairs -0.00802 (T64, z -1.03), -0.00368 (T256, z -2.03, FAIL), 1.3e-5 (T1024, z -0.01), -3.6e-6 (T4096, z 0.04); 60-90% of null pairs negative (min -0.0277 at T64); null SD shrinks with log-log slope -0.91 (Monte Carlo -1.00). '
   'nonlinear_dependence (Pearson 0.015/-0.039): 0.2294/0.0390 at T1024 (z vs permutation null 175/25), 0.2480/0.0362 at T256 (48/8.1). Symmetry/order: unmirrored max|A - A.T| = 0.0, reversed order 1.7e-15. scaled_offset kernel (raw) = bivariate_gaussian to 2.8e-14; detrend equality 2.6e-14.'),
 verdict='matches', score_0_10=9,
 what_changed=('Matches the bias-corrected squared distance correlation R*_n (Szekely & Rizzo 2013/2014) to <= 7.4e-14, external package and from-scratch. '
   'Score 9 (anchor: squared vs not): the SPI returns dCor^2, not dCor, and this is not documented; together with dcorr_biased (unsquared dCor_n) the biased/unbiased pair are on different scales: dcorr_biased^2 - dcorr = 0.00073/0.00038 on bivariate_gaussian T4096 while dcorr_biased - dcorr = 0.20/0.19. '
   'Documentation: the supplement says the unbiased estimator is obtained by double-centring; the code U-centres (the double-centred ratio is dcorr_biased^2, e.g. 0.08592 vs 0.07474 at T256). Labelled unsigned, returns negative values (9 of 10 null pairs at T256). '
   'Constant input returns 0, not NaN (only reachable with normalise=False). Finite-sample spread, not bias: the estimator is centred on the population value (Monte Carlo bias <= 0.0019).'),
 new_finding=True, definition_under_review=False,
 check_cost='moderate: 0.9 s per pyspi run at P=4, T=1024; 22 s at T=4096 (O(T^2) dense distance matrices, both triangles computed); iid_gaussian P=5 T=4096 39.5 s; family total 454 s on a shared machine',
 symmetry_observed='sym: stored max|A - A.T| = 0.0 on every run; the kernel itself is exactly symmetric (unmirrored probe max|A - A.T| = 0.0 on nonlinear_dependence, anm, raw scaled_offset)',
 direction_observed='undirected: A[i,j] = A[j,i] = bias-corrected dCor^2(x_i, x_j), independent of argument order and of process order (reversed-order run equal to 1.7e-15); no directional content on anm (A[0,1] = A[1,0])',
 candidate_resolutions=[
  dict(candidate='scale mismatch: dcorr is the squared bias-corrected R*_n while dcorr_biased is unsquared dCor_n', outcome='confirmed',
       evidence='distance.dcorr.biased-False|bivariate_gaussian|4096|kernel|scratch (ref_maxabs_vs_dcor2 7.4e-14, ref_maxabs_vs_dcor 0.200); distance.dcorr.biased-True|bivariate_gaussian|4096|kernel|scale (biased^2 - unbiased 0.00073/0.00038 vs biased - unbiased 0.201/0.190) and |nonlinear_dependence|1024|kernel|scale (0.0021/0.0018 vs 0.252/0.163); counted as a finding here, not on dcorr_biased'),
  dict(candidate="'unsigned' label but negative values", outcome='confirmed',
       evidence='distance.dcorr.biased-False|iid_gaussian|{64,256,1024,4096}|pipeline|null: 90%/90%/80%/60% of null pairs negative, min -0.0277 (T64), -0.0075 (T256); |nonlinear_dependence|1024|kernel|scratch 2 negative pairs (min -0.00092). Valid behaviour of an unbiased estimator; the issue is the label/range description, which REVIEW M7 documents for dspli/dswpli/ppc but not for dcorr'),
  dict(candidate="documentation: unbiased estimator described as 'double-centering'; code U-centres", outcome='confirmed',
       evidence='distance.dcorr.biased-False|*|kernel|scratch: U-centred formula matches to <= 7.4e-14; the double-centred ratio is dcorr_biased^2 (bivariate_gaussian T256 pair (0,1): 0.08592 = 0.293121^2 vs stored 0.07474)'),
  dict(candidate='edge case: returns 0 rather than NaN when a U-centred variance <= 0', outcome='confirmed',
       evidence=f'{SCR}/probe_edge.py: hyppo Dcorr(bias=False).statistic(constant, y) = 0.0; pyspi DistanceCorrelation.bivariate with normalise=False and a constant row = 0.0; with the default pipeline Data raises ValueError (NaN after z-scoring) first. Low impact'),
 ],
 checks_run=[
  dict(run_ids=rids(u, ['bivariate_gaussian|64|kernel|dcor', 'bivariate_gaussian|256|kernel|dcor', 'bivariate_gaussian|1024|kernel|dcor', 'bivariate_gaussian|4096|kernel|dcor', 'nonlinear_dependence|1024|kernel|dcor', 'anm|1024|kernel|dcor', 'contaminated|1024|kernel|dcor', 'iid_gaussian|256|kernel|dcor']),
       reference=f'{REF}:chk_dcor (dcor==0.7 u_distance_correlation_sqr)', outcome='8/8 pass; max_abs <= 7.2e-14'),
  dict(run_ids=rids(u, ['bivariate_gaussian|64|kernel|scratch', 'bivariate_gaussian|256|kernel|scratch', 'bivariate_gaussian|1024|kernel|scratch', 'bivariate_gaussian|4096|kernel|scratch', 'nonlinear_dependence|1024|kernel|scratch', 'anm|1024|kernel|scratch', 'contaminated|1024|kernel|scratch', 'iid_gaussian|256|kernel|scratch', 'bivariate_gaussian|1024|pipeline|scratch']),
       reference=f'{REF}:chk_scratch ({KD}:dcorr biased=False)', outcome='9/9 pass; max_abs <= 7.4e-14; distance to unsquared form 0.067-0.250'),
  dict(run_ids=rids(u, ['bivariate_gaussian|256|pipeline|truth-p01', 'bivariate_gaussian|256|pipeline|truth-p23', 'bivariate_gaussian|1024|pipeline|truth-p01', 'bivariate_gaussian|1024|pipeline|truth-p23', 'bivariate_gaussian|4096|pipeline|truth-p01', 'bivariate_gaussian|4096|pipeline|truth-p23', 'bivariate_gaussian|256|pipeline|popcheck']),
       reference=f'{REF}:chk_truth, chk_popcheck (Thm 7(ii) closed form, quadrature, big Monte Carlo)', outcome='7/7 pass; max_z 1.63; closed form = quadrature to 3e-15'),
  dict(run_ids=rids(u, ['iid_gaussian|64|pipeline|null', 'iid_gaussian|256|pipeline|null', 'iid_gaussian|1024|pipeline|null', 'iid_gaussian|4096|pipeline|null', 'iid_gaussian|64|pipeline|null-trend']),
       reference=f'{REF}:chk_null, chk_null_trend', outcome='4/5 pass; T256 null fails (z -2.03): the same draw sits at the 0.15% lower tail of its own permutation null (scratchpad probe_null256.py), so all four units fail it together; T64/T1024/T4096 z -1.03/-0.01/0.04; spread slope -0.91 vs Monte Carlo -1.00'),
  dict(run_ids=rids(u, ['nonlinear_dependence|1024|pipeline|unmirrored', 'anm|1024|pipeline|unmirrored', 'scaled_offset|1024|kernel|unmirrored', 'nonlinear_dependence|1024|pipeline|reversed']),
       reference=f'{REF}:chk_unmirrored ({PRB}:unmirrored), chk_reversed', outcome='4/4 pass; unmirrored asymmetry 0.0; reversed order 1.7e-15'),
  dict(run_ids=rids(u, ['scaled_offset|1024|pipeline|affine', 'scaled_offset|1024|kernel|affine', 'trending|1024|pipeline-detrend|detrend', 'trending|1024|pipeline|trend-contrast']),
       reference=f'{REF}:chk_affine, chk_detrend, chk_trend_contrast', outcome='4/4 pass; affine 2.8e-14 (raw) / 7.3e-15; detrend 2.6e-14; without detrending trended pairs read 0.96-0.99'),
  dict(run_ids=rids(u, ['nonlinear_dependence|256|pipeline|detected', 'nonlinear_dependence|1024|pipeline|detected']),
       reference=f'{REF}:chk_detected (200 permutations + iid Monte Carlo null)', outcome='2/2 pass; z_perm 48/8.1 (T256), 175/25 (T1024)'),
 ])

# ---------------------------------------------------------------- dcorr_biased
u = 'distance.dcorr.biased-True'
U[u] = dict(
 check_method='external-pkg',
 check_reference=(f'{REF}:chk_dcor (dcor==0.7 distance_correlation, method naive; does not import hyppo); {REF}:chk_scratch -> {KD}:dcorr / dcorr_from_dist (double centring, '
   f'Szekely, Rizzo & Bakirov 2007 Sec. 2.2); {REF}:chk_truth (sqrt of Thm 7(ii) dCor^2, quadrature- and Monte-Carlo-checked in chk_popcheck); {REF}:chk_null / chk_null_trend; '
   f'{REF}:chk_unmirrored ({PRB}:unmirrored), chk_reversed, chk_affine, chk_detrend, chk_trend_contrast, chk_detected, chk_scale'),
 check_data=U['distance.dcorr.biased-False']['check_data'],
 agreement_criterion=U['distance.dcorr.biased-False']['agreement_criterion'].replace('population dCor^2', 'population dCor') + '; null additionally requires every value > 0',
 closeness=('dcor package distance_correlation: 8/8 exact runs pass, max_abs <= 9.3e-14 (bivariate_gaussian|4096|kernel|dcor 9.34e-14); distance_correlation_sqr is 0.10-0.25 away (ref_maxabs_vs_other_form). '
   'From-scratch double centring: 9/9 pass, max_abs <= 9.3e-14 (ref_maxabs_vs_dcor = max_abs, ref_maxabs_vs_dcor2 0.103-0.246), so hyppo returns the UNSQUARED dCor_n. '
   'Population dCor (rho=0.3 0.269001, rho=0.8 0.754897): pyspi (0,1)/(2,3) = 0.29312/0.77809 at T256, 0.24778/0.76085 at T1024, 0.27670/0.74492 at T4096; |pyspi - pop| 0.024/0.023, 0.021/0.0060, 0.0077/0.0100; all 6 within 2 SD (max_z 1.51); Monte Carlo bias +0.018 at T256 (rho 0.3) shrinking to <= 0.0006 at T4096. '
   'Null iid_gaussian: every value > 0; mean 0.1944 (T64, z -1.41), 0.0903 (T256, z -2.60, FAIL), 0.0541 (T1024, z -0.06), 0.0274 (T4096, z 0.17); log-log slope of the mean -0.46 (Monte Carlo -0.50, i.e. T^-1/2). '
   'nonlinear_dependence: 0.4811/0.2019 at T1024 (z_perm 37/11); at T256 0.5066/0.2082, the circle pair exceeds all 200 permutations (max 0.20804) but z vs the iid null is 4.37 < 5 (FAIL of the pre-set margin). '
   'Symmetry/order: unmirrored asymmetry 0.0, reversed order 1.1e-14. scaled_offset raw = bivariate_gaussian to 1.3e-14; detrend equality 4.4e-15.'),
 verdict='matches', score_0_10=10,
 what_changed=('None for the estimator: the Szekely, Rizzo & Bakirov 2007 sample distance correlation dCor_n (V-statistic, double centring, unsquared), fp-exact against the dcor package and a from-scratch implementation; converges to the Theorem 7(ii) population value. '
   'Positive V-statistic bias under independence (mean 0.19 at T64 to 0.027 at T4096, ~T^-1/2) is estimator behaviour, not incorrectness. '
   "The supplement's wording ('summing over the entry-wise product of Euclidean distance matrices') omits the centring: read literally (uncentred, normalised) it gives 0.814 (sqrt) / 0.662 where the stored value is 0.2478 (scratchpad probe_edge.py). "
   'The scale mismatch with dcorr (unbiased, squared) is counted on distance.dcorr.biased-False. new_finding is false: both confirmed candidates are counted on the dcorr record.'),
 new_finding=False, definition_under_review=False,
 check_cost='moderate: 1.3 s per pyspi run at P=4, T=1024; 41 s at T=4096; iid_gaussian P=5 T=4096 72.9 s on a loaded machine (above the ~60 s guide; O(T^2) memory and time, both triangles computed)',
 symmetry_observed=U['distance.dcorr.biased-False']['symmetry_observed'],
 direction_observed='undirected: A[i,j] = A[j,i] = dCor_n(x_i, x_j) (unsquared), independent of argument and process order (reversed-order run equal to 1.1e-14)',
 candidate_resolutions=[
  dict(candidate='scale mismatch with dcorr: dcorr_biased is sqrt of the normalised V-statistic, dcorr is not square-rooted', outcome='confirmed',
       evidence='distance.dcorr.biased-True|bivariate_gaussian|4096|kernel|scale (biased^2 - unbiased 0.00073/0.00038, biased - unbiased 0.201/0.190), |nonlinear_dependence|1024|kernel|scale (0.0021/0.0018 vs 0.252/0.163); counted as a finding on distance.dcorr.biased-False'),
  dict(candidate='documentation omits the centring step', outcome='confirmed',
       evidence=f'distance.dcorr.biased-True|*|kernel|scratch: the double-centred formula matches to <= 9.3e-14; {SCR}/probe_edge.py: the literal uncentred reading gives 0.814 vs stored 0.2478 on bivariate_gaussian T1024 pair (0,1). Documentation wording, counted with the dcorr documentation finding'),
 ],
 checks_run=[
  dict(run_ids=rids(u, ['bivariate_gaussian|64|kernel|dcor', 'bivariate_gaussian|256|kernel|dcor', 'bivariate_gaussian|1024|kernel|dcor', 'bivariate_gaussian|4096|kernel|dcor', 'nonlinear_dependence|1024|kernel|dcor', 'anm|1024|kernel|dcor', 'contaminated|1024|kernel|dcor', 'iid_gaussian|256|kernel|dcor']),
       reference=f'{REF}:chk_dcor (dcor==0.7 distance_correlation)', outcome='8/8 pass; max_abs <= 9.3e-14'),
  dict(run_ids=rids(u, ['bivariate_gaussian|64|kernel|scratch', 'bivariate_gaussian|256|kernel|scratch', 'bivariate_gaussian|1024|kernel|scratch', 'bivariate_gaussian|4096|kernel|scratch', 'nonlinear_dependence|1024|kernel|scratch', 'anm|1024|kernel|scratch', 'contaminated|1024|kernel|scratch', 'iid_gaussian|256|kernel|scratch', 'bivariate_gaussian|1024|pipeline|scratch']),
       reference=f'{REF}:chk_scratch ({KD}:dcorr biased=True)', outcome='9/9 pass; max_abs <= 9.3e-14; distance to squared form 0.103-0.246'),
  dict(run_ids=rids(u, ['bivariate_gaussian|256|pipeline|truth-p01', 'bivariate_gaussian|256|pipeline|truth-p23', 'bivariate_gaussian|1024|pipeline|truth-p01', 'bivariate_gaussian|1024|pipeline|truth-p23', 'bivariate_gaussian|4096|pipeline|truth-p01', 'bivariate_gaussian|4096|pipeline|truth-p23', 'bivariate_gaussian|256|pipeline|popcheck']),
       reference=f'{REF}:chk_truth, chk_popcheck', outcome='7/7 pass; max_z 1.51'),
  dict(run_ids=rids(u, ['iid_gaussian|64|pipeline|null', 'iid_gaussian|256|pipeline|null', 'iid_gaussian|1024|pipeline|null', 'iid_gaussian|4096|pipeline|null', 'iid_gaussian|64|pipeline|null-trend']),
       reference=f'{REF}:chk_null, chk_null_trend', outcome='4/5 pass; T256 fails (z -2.60, same draw as the other three units; every value > 0); mean slope -0.46 vs Monte Carlo -0.50'),
  dict(run_ids=rids(u, ['nonlinear_dependence|1024|pipeline|unmirrored', 'anm|1024|pipeline|unmirrored', 'scaled_offset|1024|kernel|unmirrored', 'nonlinear_dependence|1024|pipeline|reversed']),
       reference=f'{REF}:chk_unmirrored ({PRB}:unmirrored), chk_reversed', outcome='4/4 pass; unmirrored asymmetry 0.0'),
  dict(run_ids=rids(u, ['scaled_offset|1024|pipeline|affine', 'scaled_offset|1024|kernel|affine', 'trending|1024|pipeline-detrend|detrend', 'trending|1024|pipeline|trend-contrast']),
       reference=f'{REF}:chk_affine, chk_detrend, chk_trend_contrast', outcome='4/4 pass; affine 1.3e-14 (raw); detrend 4.4e-15; trended pairs read 0.98-1.00 without detrending'),
  dict(run_ids=rids(u, ['nonlinear_dependence|256|pipeline|detected', 'nonlinear_dependence|1024|pipeline|detected']),
       reference=f'{REF}:chk_detected', outcome='1/2 pass; T1024 z_perm 37/11; T256 circle pair above all 200 permutations but z vs iid null 4.37 < 5'),
  dict(run_ids=rids(u, ['bivariate_gaussian|4096|kernel|scale', 'nonlinear_dependence|1024|kernel|scale']),
       reference=f'{REF}:chk_scale (pyspi dcorr_biased vs pyspi dcorr, same draw)', outcome='2/2 pass; dcorr_biased^2 - dcorr <= 0.0021 while dcorr_biased - dcorr 0.16-0.25'),
 ])

# ---------------------------------------------------------------- hsic (unbiased)
u = 'distance.hsic.biased-False'
HS_DATA = 'bivariate_gaussian T64/T256/T1024 (kernel), T1024 (pipeline), pairs (0,1)/(2,3) at T256/T1024; nonlinear_dependence T64/T256/T1024; anm T1024; contaminated T1024; iid_gaussian T64/T256/T1024; scaled_offset T1024 (kernel and pipeline); trending T1024 (pipeline-detrend and pipeline). T <= 1024 (O(T^2) memory)'
U[u] = dict(
 check_method='independent-impl',
 check_reference=(f'{REF}:chk_scratch -> hsic_stats (Song et al. 2012 eq. 5 HSIC_u, extended-precision reductions, normalised; Gaussian kernel with {KD}:median_gamma of the first argument for both kernels); '
   f'{REF}:chk_eq3 (Gretton et al. 2007 eq. 3 brute force); {REF}:chk_dhsic + audit/checks/r/dcorr_hsic.R (R re-implementation of eq. 5 on dHSIC==2.2 Gram matrices; dHSIC::dhsic raw HSIC_b recorded); '
   f'{REF}:chk_gamma ({PRB}:gamma_used, gamma hyppo applies to y); {REF}:chk_truth (population normalised HSIC, closed form det(I + A Sigma)^-1/2, checked by 2-D quadrature and a 10 x 2e6 quadruple Monte Carlo in chk_popcheck); '
   f'{REF}:chk_unmirrored, chk_reversed, chk_null, chk_null_trend, chk_affine, chk_detrend, chk_trend_contrast, chk_detected'),
 check_data=HS_DATA,
 agreement_criterion='exact: rtol 1e-10, atol 1e-12; gamma: rtol 1e-8; statistical: |pyspi - population normalised HSIC| <= 2 Monte Carlo SD at T; null and detection as for dcorr',
 closeness=('Normalised Song eq. 5 with x-only median bandwidth: 9/9 scratch runs pass, max_abs <= 2.6e-14 (also = hyppo-route replica to 2.6e-14); Gretton 2007 eq. 3 brute force 2/2 pass (3.2e-14, 6.8e-14); R/dHSIC Gram route 5/5 pass (max_abs <= 2.6e-14), dHSIC::dhsic raw HSIC_b = python raw to <= 1.5e-16. '
   'Stored value vs raw HSIC_u: ratio 8.4-18.8 on z-scored data (bivariate_gaussian T1024 pipeline: stored 0.03335/0.48776 vs raw 0.00258/0.03769; population factor 1/HSIC(X,X) = 1/0.07724 = 12.9); stored = normalised HSIC_u to 2.4e-14. '
   'Bandwidth (gamma probe): hyppo applies gamma of the FIRST argument to y on every ordered pair, rtol 4.6e-16 (nonlinear_dependence, anm, raw scaled_offset; distance to the per-variable gamma up to 31% on anm, 2471x on raw scaled_offset). '
   'Order dependence: unmirrored A[0,1]/A[1,0] = 0.3164/0.3330 (nonlinear_dependence, pipeline), 0.4489/0.4229 (anm); reversing the process order changes stored values by up to 0.0166 (nonlinear) and 0.0260 (anm, 5.8%); raw scaled_offset 0.0073 vs 0.0549 (pair (0,1)) and 0.3683 vs 0.5129 (pair (2,3)), z-scored 0.0334/0.4878. '
   'Population normalised HSIC (sigma = 0.95387; rho=0.3 0.045528, rho=0.8 0.473935; quadrature equal, big Monte Carlo 0.045722 +- 0.001318 / 0.473045 +- 0.000992): pyspi 0.05033/0.49968 at T256, 0.03335/0.48776 at T1024; all 4 within 2 SD (max_z 1.20). '
   'Null: means -0.0094 (T64, z -1.18), -0.0038 (T256, z -2.18, FAIL), -0.00017 (T1024, z -0.44); 70-90% negative; SD slope -0.72 (Monte Carlo -1.00). nonlinear_dependence z_perm 230/43 (T1024), 67/14 (T256).'),
 verdict='variant', score_0_10=6,
 what_changed=('Computes HSIC_u(K,L)/sqrt(HSIC_u(K,K) HSIC_u(L,L)) (an unbiased centred-kernel-alignment / normalised HSIC, on the squared scale, can be negative) rather than HSIC, with a Gaussian bandwidth from the median distance of the FIRST argument applied to both variables. '
   'The unbiased centring itself is exact (Song eq. 5 = Gretton eq. 3). Score 6 (anchor: deviates from canonical HSIC and from the supplement description in an interpretable way): neither the normalisation nor the shared x-bandwidth is documented; the normalisation is a pair-dependent factor (8-19x), so values are not monotone in raw HSIC across pairs; '
   'the shared bandwidth makes the kernel asymmetric and the stored value depends on process order (up to 5.8% relative on anm after z-scoring). Under the default z-scoring pure scale differences cancel; with normalise=False the value depends on the relative scale of y (raw scaled_offset pair (0,1) 0.0073 vs 0.0334 z-scored).'),
 new_finding=True, definition_under_review=True,
 check_cost='moderate: 2.2 s per pyspi run at P=4, T=1024 (dense T x T Gram matrices, O(T^2) memory; both triangles computed); family runs kept at T <= 1024',
 symmetry_observed='sym (stored): max|A - A.T| = 0.0 on every run (lower triangle mirrored); the kernel is asymmetric: unmirrored max|A - A.T| = 0.0166 (nonlinear_dependence pipeline), 0.0260 (anm pipeline), 0.0020 (contaminated), 0.1446 (raw scaled_offset)',
 direction_observed='undirected by mirroring only: A[i,j] = A[j,i] = f(x = process min(i,j), y = process max(i,j)) with the bandwidth of the lower-index process (unmirrored/reversed runs match this rule to <= 2.1e-14); the asymmetry is a bandwidth artefact, not a causal direction (anm cause->effect pair: A[0,1] 0.4489 > A[1,0] 0.4229, while on nonlinear_dependence A[0,1] 0.3164 < A[1,0] 0.3330)',
 candidate_resolutions=[
  dict(candidate='order dependence: bandwidth from the first argument only, reused for the second', outcome='confirmed',
       evidence='distance.hsic.biased-False|nonlinear_dependence|1024|pipeline|gamma, |anm|1024|pipeline|gamma, |scaled_offset|1024|kernel|gamma (gamma(y kernel) = gamma(x) to 4.6e-16); |nonlinear_dependence|1024|pipeline|reversed (stored values change by up to 0.0166) and |anm|1024|pipeline|reversed (0.0260, 5.8%)'),
  dict(candidate='normalisation not documented: stored value is normalised HSIC', outcome='confirmed',
       evidence='distance.hsic.biased-False|bivariate_gaussian|1024|pipeline|scratch: stored = HSIC_u(K,L)/sqrt(HSIC_u(K,K)HSIC_u(L,L)) to 2.4e-14, ratio stored/raw 12.7-13.1 (0.03335 vs raw 0.00258); |nonlinear_dependence|1024|kernel|scratch ratio 8.4-18.8'),
  dict(candidate='scale mismatch with hsic_biased (no square root for bias=False)', outcome='confirmed',
       evidence='distance.hsic.biased-True|bivariate_gaussian|1024|pipeline|scale (hsic_biased^2 - hsic 0.0024/0.0014 vs hsic_biased - hsic 0.156/0.212) and |nonlinear_dependence|1024|kernel|scale (0.0011/0.0014 vs 0.245/0.196); counted here'),
  dict(candidate='relative-scale dependence when normalise=False', outcome='confirmed',
       evidence='distance.hsic.biased-False|scaled_offset|1024|kernel|unmirrored and |scratch: raw pair (0,1) 0.0073 (x scale 0.2), (2,3) 0.3683, vs 0.0334 / 0.4878 on z-scored rows (ref_zscored01/23); |scaled_offset|1024|pipeline|affine shows the default pipeline removes it (2.4e-14)'),
  dict(candidate="'unsigned' label but negative values", outcome='confirmed',
       evidence='distance.hsic.biased-False|iid_gaussian|{64,256,1024}|pipeline|null: 80%/90%/70% of null pairs negative, min -0.0246 (T64); |nonlinear_dependence|1024|kernel|scratch 2 negative pairs. Not in KNOWN_ISSUES for hsic (REVIEW M7 covers dspli/dswpli/ppc)'),
 ],
 checks_run=[
  dict(run_ids=rids(u, ['bivariate_gaussian|64|kernel|scratch', 'bivariate_gaussian|256|kernel|scratch', 'bivariate_gaussian|1024|kernel|scratch', 'nonlinear_dependence|1024|kernel|scratch', 'anm|1024|kernel|scratch', 'contaminated|1024|kernel|scratch', 'iid_gaussian|256|kernel|scratch', 'bivariate_gaussian|1024|pipeline|scratch', 'scaled_offset|1024|kernel|scratch']),
       reference=f'{REF}:chk_scratch (hsic_stats norm_u)', outcome='9/9 pass; max_abs <= 2.6e-14'),
  dict(run_ids=rids(u, ['bivariate_gaussian|64|kernel|eq3', 'nonlinear_dependence|64|kernel|eq3']),
       reference=f'{REF}:chk_eq3 (Gretton et al. 2007 eq. 3)', outcome='2/2 pass; max_abs 6.8e-14'),
  dict(run_ids=rids(u, ['bivariate_gaussian|1024|kernel|dhsic', 'nonlinear_dependence|1024|kernel|dhsic', 'anm|1024|kernel|dhsic', 'contaminated|1024|kernel|dhsic', 'scaled_offset|1024|kernel|dhsic']),
       reference=f'{REF}:chk_dhsic, audit/checks/r/dcorr_hsic.R (dHSIC==2.2 Gram matrices, R eq. 5)', outcome='5/5 pass; max_abs <= 2.6e-14; dhsic raw HSIC_b = python to 1.5e-16'),
  dict(run_ids=rids(u, ['nonlinear_dependence|1024|pipeline|gamma', 'anm|1024|pipeline|gamma', 'scaled_offset|1024|kernel|gamma']),
       reference=f'{REF}:chk_gamma ({PRB}:gamma_used)', outcome='3/3 pass; gamma(y kernel) = gamma(x) to 6.2e-16 relative'),
  dict(run_ids=rids(u, ['nonlinear_dependence|1024|pipeline|unmirrored', 'anm|1024|pipeline|unmirrored', 'contaminated|1024|pipeline|unmirrored', 'scaled_offset|1024|kernel|unmirrored', 'nonlinear_dependence|1024|pipeline|reversed', 'anm|1024|pipeline|reversed']),
       reference=f'{REF}:chk_unmirrored ({PRB}:unmirrored), chk_reversed', outcome='6/6 pass (after the reference switched to extended-precision sums; float64 Song eq. 5 had lost 1.1e-12 on raw scaled_offset A[3,0]); kernel asymmetry up to 0.026 (pipeline), 0.145 (raw)'),
  dict(run_ids=rids(u, ['bivariate_gaussian|256|pipeline|truth-p01', 'bivariate_gaussian|256|pipeline|truth-p23', 'bivariate_gaussian|1024|pipeline|truth-p01', 'bivariate_gaussian|1024|pipeline|truth-p23', 'bivariate_gaussian|256|pipeline|popcheck']),
       reference=f'{REF}:chk_truth, chk_popcheck', outcome='5/5 pass; max_z 1.20'),
  dict(run_ids=rids(u, ['iid_gaussian|64|pipeline|null', 'iid_gaussian|256|pipeline|null', 'iid_gaussian|1024|pipeline|null', 'iid_gaussian|64|pipeline|null-trend']),
       reference=f'{REF}:chk_null, chk_null_trend', outcome='3/4 pass; T256 fails (z -2.18, same draw as the other units)'),
  dict(run_ids=rids(u, ['scaled_offset|1024|pipeline|affine', 'trending|1024|pipeline-detrend|detrend', 'trending|1024|pipeline|trend-contrast', 'nonlinear_dependence|256|pipeline|detected', 'nonlinear_dependence|1024|pipeline|detected']),
       reference=f'{REF}:chk_affine, chk_detrend, chk_trend_contrast, chk_detected', outcome='5/5 pass; affine 2.4e-14; detrend 1.9e-15; z_perm >= 14'),
 ])

# ---------------------------------------------------------------- hsic_biased
u = 'distance.hsic.biased-True'
U[u] = dict(
 check_method='external-pkg',
 check_reference=(f'{REF}:chk_dhsic + audit/checks/r/dcorr_hsic.R (dHSIC==2.2 dhsic(kernel gaussian.fixed, bandwidth = median(dist(x)) for both); value sqrt(dhsic(x,y)/sqrt(dhsic(x,x) dhsic(y,y)))); '
   f'{REF}:chk_scratch -> hsic_stats (HSIC_b = tr(KHLH)/n^2, Gretton et al. 2005, extended-precision reductions, x-only median bandwidth via {KD}:median_gamma); '
   f'{REF}:chk_truth (sqrt of population normalised HSIC, chk_popcheck); {REF}:chk_unmirrored, chk_reversed, chk_null, chk_null_trend, chk_affine, chk_detrend, chk_trend_contrast, chk_detected, chk_scale'),
 check_data=HS_DATA.replace('nonlinear_dependence T64/T256/T1024', 'nonlinear_dependence T256/T1024'),
 agreement_criterion=U['distance.hsic.biased-False']['agreement_criterion'].replace('gamma: rtol 1e-8; ', '') + '; null additionally requires every value > 0',
 closeness=('dHSIC: 5/5 runs pass, max_abs <= 2.3e-14 (stored value rebuilt from dhsic(x,y), dhsic(x,x), dhsic(y,y)); dhsic raw HSIC_b equals the python HSIC_b to <= 1.5e-16. From-scratch: 9/9 pass, max_abs <= 2.3e-14 (= hyppo-route replica). '
   'Stored value = sqrt of normalised HSIC_b (bivariate_gaussian T1024 pipeline: 0.18913/0.69937, normalised 0.03577/0.48911, raw HSIC_b 0.00276/0.03782; stored/raw 18-438). '
   'Order dependence: unmirrored A[0,1]/A[1,0] 0.5637/0.5783 (nonlinear_dependence), 0.6711/0.6515 (anm); reversed process order changes stored values by up to 0.0146 / 0.0195 (anm 10% on pair (1,3)); raw scaled_offset 0.1198 vs 0.2375 (pair (0,1)), z-scored 0.1891. '
   'Population sqrt normalised HSIC (rho=0.3 0.213374, rho=0.8 0.688429): pyspi 0.24371/0.71089 at T256, 0.18913/0.69937 at T1024; all 4 within 2 SD (max_z 1.02); Monte Carlo bias +0.019 (T256, rho 0.3). '
   'Null: every value > 0; means 0.1630 (T64, z -1.73), 0.0727 (T256, z -2.85, FAIL), 0.0456 (T1024, z -0.67); mean slope -0.46 (Monte Carlo -0.49). nonlinear_dependence z_perm 37/14 (T1024), 19/7.2 (T256).'),
 verdict='variant', score_0_10=6,
 what_changed=('Computes sqrt(HSIC_b(K,L)/sqrt(HSIC_b(K,K) HSIC_b(L,L))) (square root of centred kernel alignment) rather than HSIC_b, with the Gaussian bandwidth of the first argument used for both kernels. The HSIC_b itself agrees with dHSIC::dhsic to 1.5e-16. '
   'Score 6 (anchor: deviates from canonical HSIC and from the supplement description in an interpretable way): normalisation, square root and the shared x-bandwidth are undocumented; the bandwidth rule makes the kernel asymmetric and the stored value process-order dependent (up to 0.0195 absolute on anm after z-scoring). Positive V-statistic bias under independence (~T^-1/2) is estimator behaviour.'),
 new_finding=True, definition_under_review=True,
 check_cost='moderate: 2.8 s per pyspi run at P=4, T=1024 (dense T x T Gram matrices, O(T^2) memory; both triangles computed); family runs kept at T <= 1024',
 symmetry_observed='sym (stored): max|A - A.T| = 0.0 on every run; kernel asymmetric: unmirrored max|A - A.T| = 0.0146 (nonlinear_dependence pipeline), 0.0195 (anm pipeline), 0.0011 (contaminated), 0.1177 (raw scaled_offset)',
 direction_observed=U['distance.hsic.biased-False']['direction_observed'].replace('0.4489 > A[1,0] 0.4229', '0.6711 > A[1,0] 0.6515').replace('A[0,1] 0.3164 < A[1,0] 0.3330', 'A[0,1] 0.5637 < A[1,0] 0.5783').replace('2.1e-14', '4.1e-14'),
 candidate_resolutions=[
  dict(candidate='order dependence: bandwidth from the first argument only', outcome='confirmed',
       evidence='distance.hsic.biased-True|nonlinear_dependence|1024|pipeline|reversed (up to 0.0146), |anm|1024|pipeline|reversed (up to 0.0195), |*|unmirrored; mechanism shown by distance.hsic.biased-False|*|gamma (shared hyppo compute_kern)'),
  dict(candidate='normalisation and square root not documented', outcome='confirmed',
       evidence='distance.hsic.biased-True|bivariate_gaussian|1024|pipeline|scratch: stored 0.18913 = sqrt(normalised 0.03577), raw HSIC_b 0.00276 (max ratio stored/raw 431); |*|kernel|dhsic agrees with sqrt(dhsic(x,y)/sqrt(dhsic(x,x) dhsic(y,y))) to <= 2.3e-14'),
  dict(candidate='relative-scale dependence when normalise=False', outcome='confirmed',
       evidence='distance.hsic.biased-True|scaled_offset|1024|kernel|unmirrored: raw pair (0,1) 0.1198, (2,3) 0.6086 vs z-scored 0.1891 / 0.6994; |scaled_offset|1024|pipeline|affine equals bivariate_gaussian to 3.8e-15 (default pipeline removes it)'),
 ],
 checks_run=[
  dict(run_ids=rids(u, ['bivariate_gaussian|1024|kernel|dhsic', 'nonlinear_dependence|1024|kernel|dhsic', 'anm|1024|kernel|dhsic', 'contaminated|1024|kernel|dhsic', 'scaled_offset|1024|kernel|dhsic']),
       reference=f'{REF}:chk_dhsic, audit/checks/r/dcorr_hsic.R (dHSIC==2.2 dhsic)', outcome='5/5 pass; max_abs <= 2.3e-14'),
  dict(run_ids=rids(u, ['bivariate_gaussian|64|kernel|scratch', 'bivariate_gaussian|256|kernel|scratch', 'bivariate_gaussian|1024|kernel|scratch', 'nonlinear_dependence|1024|kernel|scratch', 'anm|1024|kernel|scratch', 'contaminated|1024|kernel|scratch', 'iid_gaussian|256|kernel|scratch', 'bivariate_gaussian|1024|pipeline|scratch', 'scaled_offset|1024|kernel|scratch']),
       reference=f'{REF}:chk_scratch (hsic_stats stored_b)', outcome='9/9 pass; max_abs <= 2.3e-14'),
  dict(run_ids=rids(u, ['nonlinear_dependence|1024|pipeline|unmirrored', 'anm|1024|pipeline|unmirrored', 'contaminated|1024|pipeline|unmirrored', 'scaled_offset|1024|kernel|unmirrored', 'nonlinear_dependence|1024|pipeline|reversed', 'anm|1024|pipeline|reversed']),
       reference=f'{REF}:chk_unmirrored ({PRB}:unmirrored), chk_reversed', outcome='6/6 pass; kernel asymmetry up to 0.0195 (pipeline), 0.118 (raw)'),
  dict(run_ids=rids(u, ['bivariate_gaussian|256|pipeline|truth-p01', 'bivariate_gaussian|256|pipeline|truth-p23', 'bivariate_gaussian|1024|pipeline|truth-p01', 'bivariate_gaussian|1024|pipeline|truth-p23', 'bivariate_gaussian|256|pipeline|popcheck']),
       reference=f'{REF}:chk_truth, chk_popcheck', outcome='5/5 pass; max_z 1.02'),
  dict(run_ids=rids(u, ['iid_gaussian|64|pipeline|null', 'iid_gaussian|256|pipeline|null', 'iid_gaussian|1024|pipeline|null', 'iid_gaussian|64|pipeline|null-trend']),
       reference=f'{REF}:chk_null, chk_null_trend', outcome='3/4 pass; T256 fails (z -2.85, same draw); every value > 0; mean slope -0.46'),
  dict(run_ids=rids(u, ['scaled_offset|1024|pipeline|affine', 'trending|1024|pipeline-detrend|detrend', 'trending|1024|pipeline|trend-contrast', 'nonlinear_dependence|256|pipeline|detected', 'nonlinear_dependence|1024|pipeline|detected', 'bivariate_gaussian|1024|pipeline|scale', 'nonlinear_dependence|1024|kernel|scale']),
       reference=f'{REF}:chk_affine, chk_detrend, chk_trend_contrast, chk_detected, chk_scale', outcome='7/7 pass; affine 3.8e-15; detrend 1.6e-14; z_perm >= 7.2; hsic_biased^2 - hsic <= 0.0024'),
 ])

for uid, fields in U.items():
    p = R / f'{uid}.yaml'
    d = yaml.safe_load(p.read_text())
    d['status'] = 'checked'
    c = d['correctness']
    fix_trace(c)
    c.update(fields)
    p.write_text(yaml.safe_dump(d, sort_keys=False, width=130, allow_unicode=True))
    print('wrote', p)
