import time, numpy as np, sys
from hyppo.independence import Dcorr, Hsic
rng=np.random.default_rng(0)
for T in (1024,4096):
    x=rng.standard_normal((T,1)); y=rng.standard_normal((T,1))
    for b in (False,True):
        Dcorr(bias=b).statistic(x[:64],y[:64])
        t=time.perf_counter(); Dcorr(bias=b).statistic(x,y); print('dcorr',T,b,time.perf_counter()-t)
        if T<=1024 or len(sys.argv)>1:
            t=time.perf_counter(); Hsic(bias=b).statistic(x,y); print('hsic',T,b,time.perf_counter()-t)
