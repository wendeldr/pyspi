import sys, json
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np, importlib.util
spec=importlib.util.spec_from_file_location('r','/media/dan/Data/git/pyspi/audit/checks/refs/dcorr_hsic.py'); r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
kd=r.kd
# (c) arithmetic on raw scaled_offset, ordered pair x=3, y=0
S=np.load('/media/dan/Data/git/pyspi/audit/checks/out/pyspi/distance.hsic.biased-False|scaled_offset|1024|kernel|unmirrored.npz')['value']
X=r.load_x({'dataset':'scaled_offset','T':1024})
def sk_stat(a,b,biased=False):
    g=kd.median_gamma(a, sklearn_arith=True)
    K=np.exp(-g*kd._sk_sqdist(a)); L=np.exp(-g*kd._sk_sqdist(b))
    f=r.hsic_b_from_gram if biased else r.hsic_u_from_gram
    v=f(K,L)/np.sqrt(f(K,K)*f(L,L)); return np.sqrt(v) if biased else v
for i,j in [(3,0),(0,3),(2,3),(3,2),(1,0)]:
    ex=r.stat('hsic',X[i],X[j]); sk=sk_stat(X[i],X[j]); rep=kd.hyppo_hsic_replica(X[i],X[j],biased=False)
    print(i,j,'pyspi',S[i,j],'exact-diff',ex,'sk-arith',sk,'replica',rep, 'd_exact',S[i,j]-ex,'d_sk',S[i,j]-sk,'d_rep',S[i,j]-rep)
# (a) null draw at T=256: other measures on the same draw
x=r.zscore(r.load_x({'dataset':'iid_gaussian','T':256}))
P=5; pr=r.pairs_upper(P)
r2=np.mean([np.corrcoef(x[i],x[j])[0,1]**2 for i,j in pr])
rng=np.random.default_rng(1); mc=[]
for _ in range(4000):
    z=rng.standard_normal((5,256)); mc.append(np.mean([np.corrcoef(z[i],z[j])[0,1]**2 for i,j in pr]))
mc=np.array(mc); print('mean r^2 over pairs', r2, 'MC mean', mc.mean(), 'sd', mc.std(), 'z', (r2-mc.mean())/mc.std(), 'frac<=', (mc<=r2).mean())
c=json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/exchange/dcorr_hsic/mc_cache_v2.json'))
import dcor
v=np.mean([dcor.u_distance_correlation_sqr(x[i],x[j]) for i,j in pr])
# empirical lower-tail fraction for dcorr null mean at 256 with fresh MC
rng=np.random.default_rng(2); m=[]
for _ in range(2000):
    z=r.zscore(rng.standard_normal((5,256))); m.append(np.mean([dcor.u_distance_correlation_sqr(z[i],z[j],method='avl') for i,j in pr]))
m=np.array(m); print('dcorr null mean pyspi-draw', v, 'MC2000 mean', m.mean(), 'sd', m.std(ddof=1), 'frac<=', (m<=v).mean())
