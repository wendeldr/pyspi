import sys
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np, importlib.util
spec=importlib.util.spec_from_file_location('r','/media/dan/Data/git/pyspi/audit/checks/refs/dcorr_hsic.py'); r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
kd=r.kd
print(np.finfo(np.longdouble))
S=np.load('/media/dan/Data/git/pyspi/audit/checks/out/pyspi/distance.hsic.biased-False|scaled_offset|1024|kernel|unmirrored.npz')['value']
X=r.load_x({'dataset':'scaled_offset','T':1024})
def ld_stat(a,b):
    a=np.asarray(a,np.longdouble); b=np.asarray(b,np.longdouble)
    da=np.abs(a[:,None]-a[None,:]); med=np.median(da[~np.eye(len(a),dtype=bool)])
    g=np.longdouble(1)/(2*med*med)
    K=np.exp(-g*(a[:,None]-a[None,:])**2); L=np.exp(-g*(b[:,None]-b[None,:])**2)
    def hu(K,L):
        n=K.shape[0]; K=K.copy(); L=L.copy(); np.fill_diagonal(K,0); np.fill_diagonal(L,0)
        return (np.sum(K*L)+K.sum()*L.sum()/((n-1)*(n-2))-2/np.longdouble(n-2)*np.dot(K.sum(1),L.sum(1)))/(n*(n-3))
    return hu(K,L)/np.sqrt(hu(K,K)*hu(L,L))
for i,j in [(3,0),(3,1),(2,0),(1,0),(0,3)]:
    ld=ld_stat(X[i],X[j]); print(i,j,'pyspi-ld',float(S[i,j]-ld),'f64song-ld',float(r.stat('hsic',X[i],X[j])-ld))
