import sys
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np
import importlib.util
spec=importlib.util.spec_from_file_location('r','/media/dan/Data/git/pyspi/audit/checks/refs/dcorr_hsic.py'); r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
for rho in (0.3,0.8,1.0):
    print(rho, r.dcor2_closed(rho), r.dcor2_quad(rho), r.hsic_pop_closed(rho))
print(r.SIGMA_POP)
# hsic population: rho -> 0 limit should be 0 and normalised(1)=1
print(r.hsic_pop_closed(0.0))
# sanity: n=3000 sample with population sigma, U-stat normalised
rng=np.random.default_rng(3)
for rho in (0.3,0.8):
    v=[]
    for _ in range(5):
        z=rng.standard_normal((2,3000)); x=z[0]; y=rho*z[0]+np.sqrt(1-rho**2)*z[1]
        g=1/(2*r.SIGMA_POP**2); K=r._gram(x,g); L=r._gram(y,g)
        v.append(r.hsic_u_from_gram(K,L)/np.sqrt(r.hsic_u_from_gram(K,K)*r.hsic_u_from_gram(L,L)))
    print(rho, np.mean(v), np.std(v)/np.sqrt(5))
