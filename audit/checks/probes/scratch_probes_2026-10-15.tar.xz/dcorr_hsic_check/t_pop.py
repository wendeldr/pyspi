import sys, time
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs")
import importlib.util, numpy as np
spec = importlib.util.spec_from_file_location("ref", "/media/dan/Data/git/pyspi/audit/checks/refs/dcorr_hsic.py")
ref = importlib.util.module_from_spec(spec); spec.loader.exec_module(ref)
for rho in (0.3, 0.8, 1.0):
    print(rho, ref.dcor2_closed(rho), ref.dcor2_quad(rho))
t=time.time()
for rho in (0.3, 0.8):
    print(rho, ref.hsic_pop_closed(rho), ref.hsic_pop_quad(rho))
print('quad time', time.time()-t)
t=time.time(); print(ref.hsic_pop_mc(0.3, n=500000, reps=4)); print(time.time()-t)
rng=np.random.default_rng(1); x=rng.standard_normal(40); y=x**2+0.3*rng.standard_normal(40)
g=ref.kd.median_gamma(x); K,L=ref._gram(x,g),ref._gram(y,g)
print(ref.hsic_u_eq3(K,L), ref.hsic_u_from_gram(K,L))
h=ref.hsic_stats(x,y); print(h['stored_u'], ref.kd.hyppo_hsic_replica(x,y,False), h['stored_b'], ref.kd.hyppo_hsic_replica(x,y,True))
