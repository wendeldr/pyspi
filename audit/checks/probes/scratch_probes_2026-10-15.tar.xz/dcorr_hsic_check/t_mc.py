import numpy as np
from scipy import stats
s = np.sqrt(2)*stats.norm.ppf(0.75)
rng = np.random.default_rng(3)
rho=0.3
k = lambda a,b: np.exp(-(a-b)**2/(2*s*s))
acc=[]
for r in range(10):
    n=2_000_000
    z = rng.standard_normal((4,2,n)); xs=z[:,0]; ys=rho*z[:,0]+np.sqrt(1-rho*rho)*z[:,1]
    k12=k(xs[0],xs[1])
    t1=np.mean(k12*k(ys[0],ys[1])); t2=np.mean(k12*k(ys[2],ys[3])); t3=np.mean(k12*k(ys[0],ys[2]))
    acc.append((t1,t2,t3,t1+t2-2*t3))
acc=np.array(acc); print(acc.mean(0), acc.std(0,ddof=1)/np.sqrt(10))
A=np.eye(2)/s**2
print(np.linalg.det(np.eye(2)+A@(2*np.array([[1,rho],[rho,1]])))**-0.5, (1+2/s**2)**-1, np.linalg.det(np.eye(2)+A@np.array([[2,rho],[rho,2]]))**-0.5)
