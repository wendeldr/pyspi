"""T=256 iid_gaussian null draw: is the low mean dCor^2 a property of the draw? Permutation null preserving each series'
marginal (each row permuted independently in time), and the same z for the T=64/1024/4096 draws."""
import sys
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np, importlib.util, dcor
from scipy import stats
spec=importlib.util.spec_from_file_location('r','/media/dan/Data/git/pyspi/audit/checks/refs/dcorr_hsic.py'); r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
pr=r.pairs_upper(5)
f=lambda z: np.mean([dcor.u_distance_correlation_sqr(z[i],z[j],method='avl') for i,j in pr])
for T in (64,256,1024):
    x=r.zscore(r.load_x({'dataset':'iid_gaussian','T':T})); v=f(x)
    rng=np.random.default_rng(5); m=np.array([f(np.array([row[rng.permutation(T)] for row in x])) for _ in range(2000)])
    print(T,'mean dCor^2',v,'perm mean',m.mean(),'sd',m.std(ddof=1),'z',(v-m.mean())/m.std(ddof=1),'frac<=',(m<=v).mean())
x=r.load_x({'dataset':'iid_gaussian','T':256})
print('Shapiro p per row', [round(stats.shapiro(row).pvalue,3) for row in x], 'lag1 acf', [round(np.corrcoef(row[:-1],row[1:])[0,1],3) for row in x])
