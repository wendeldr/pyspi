p = '/media/dan/Data/git/pyspi/audit/notes/dcorr_hsic.md'
s = open(p).read()
def sub(old, new):
    global s
    assert s.count(old) == 1, (old[:70], s.count(old))
    s = s.replace(old, new)

sub("2. `pyspi/calculator.py:294` calls `multivariate`.",
    "2. `pyspi/calculator.py:329` (HEAD a42ebc1, unchanged since a1f20c7) calls `multivariate`, and `:332` sets the diagonal to NaN.")

sub("""## Independence of references

- `dcor` 0.7 is installed""",
"""## Independence of references

*Trace-stage text, partly superseded by the check stage:* R `dHSIC` 2.2 was later installed in `~/R/audit-lib` and used as the
external package for both HSIC units (see "Checks" and open question 6 below). The second bullet describes the situation at trace time only.

- `dcor` 0.7 is installed""")

sub("""### dcorr_biased (`distance.dcorr.biased-True`): matches, score 10
""", """### dcorr_biased (`distance.dcorr.biased-True`): matches, score 9 (anchor 9: matches canonical; not 10 because the supplement description does not match)
""")
sub("""- `new_finding: false`. Both confirmed candidates are counted on the dcorr record.
""", """- **Score.** The estimator is fp-exact against `dcor` and the from-scratch double centring, but anchor 10 also requires matching the supplement description. The supplement omits the centring (literal reading 0.814 vs stored 0.248) and presents dcorr/dcorr_biased as biased/unbiased versions of one statistic on different scales. Score 9, as for `distance.hhg` in `hhg_mgc`, where a supplement-text mismatch also gave 9. (Changed from 10 after review.)
- `new_finding: false`. Both confirmed candidates are counted on the dcorr record.
""")
sub("""  - The "unsigned" label with negative values. REVIEW M7 documents this kind of behaviour for dspli/dswpli/ppc, not for dcorr.
""", """  - The "unsigned" label with negative values. This is a new instance of an already-documented class: REVIEW M7 (negative debiased dspli/dswpli/ppc estimates are valid), REVIEW M8 (pec/pec_log negative despite "unsigned") and EEG_OPTIMIZATION_NOTES.md:169 (review topic "legitimate negative estimates"). None of them names dcorr; the record's `already_documented` now cites them.
""")
sub("""and the "unsigned" label with negative values.
- `new_finding: true`. `definition_under_review: true`""",
"""and the "unsigned" label with negative values. The last is a new instance of the class already documented in REVIEW M7/M8 and EEG_OPTIMIZATION_NOTES.md:169 (none names hsic); `already_documented` now cites them.
- `new_finding: true`. `definition_under_review: true`""")
sub("""- No other trace field was refuted.
""", """- No other trace field was refuted.
- After review: `already_documented` on dcorr and hsic changed from "no" to "partly", citing REVIEW M7, REVIEW M8 and EEG_OPTIMIZATION_NOTES.md:169 for the unsigned-but-negative class and EEG_OPTIMIZATION_NOTES.md:132 for the double work of the generic Undirected path. The mgc, dcorrx and mgcx sign items belong to the `hhg_mgc` and `lagged_dcorr_mgc` families and are not edited here.
""")
sub("""This needs the same metadata decision as M7/M9. It is recorded as a confirmed but low-severity finding for these two SPIs.""",
"""This needs the same metadata decision as M7/M8/M9 and the EEG_OPTIMIZATION_NOTES.md:169 topic "legitimate negative estimates". It is recorded as a confirmed, low-severity new instance of that documented class for these two SPIs.""")
sub("""7. **Both triangles computed; fast dCor path unused.** This is unchanged and belongs to the optimisation stage.""",
"""7. **Both triangles computed; fast dCor path unused.** This is unchanged and belongs to the optimisation stage. The double work is already documented (EEG_OPTIMIZATION_NOTES.md:132).""")
open(p, 'w').write(s)
