"""dcorr_hsic edge probe (PROJECT venv). (1) hyppo Dcorr/Hsic on a constant series (zero clamp vs NaN), and what pyspi
does with a constant row on the kernel path (normalise=False) and on the default pipeline. (2) The 'sum of entry-wise
products of Euclidean distance matrices' read literally (no centring), normalised, vs the stored dcorr_biased value."""
import sys, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
import numpy as np
from hyppo.independence import Dcorr, Hsic
import make_data
rng = np.random.default_rng(0)
y = rng.standard_normal((200, 1)); c = np.ones((200, 1))
for b in (False, True):
    print('Dcorr bias', b, 'const,y ->', Dcorr(bias=b).statistic(c, y), '| Hsic bias', b, '->', Hsic(bias=b).statistic(c, y))
from pyspi.data import Data
from pyspi.statistics.distance import DistanceCorrelation, HilbertSchmidtIndependenceCriterion
X = np.vstack([rng.standard_normal(200), np.ones(200)])
for norm in (False, True):
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            d = Data(X.copy(), dim_order='ps', normalise=norm)
        print('normalise', norm, 'dcorr', DistanceCorrelation(biased=False).bivariate(d, i=0, j=1),
              'hsic', HilbertSchmidtIndependenceCriterion(biased=False).bivariate(d, i=0, j=1))
    except Exception as e:
        print('normalise', norm, 'raises', repr(e)[:200])
# (2) uncentred reading on bivariate_gaussian T=1024 pair (0,1), z-scored
x = make_data.load('bivariate_gaussian', 1024)['x']
z = (x - x.mean(1, keepdims=True)) / x.std(1, ddof=1, keepdims=True)
a = np.abs(z[0][:, None] - z[0][None, :]); bb = np.abs(z[1][:, None] - z[1][None, :])
unc = np.sum(a * bb) / np.sqrt(np.sum(a * a) * np.sum(bb * bb))
print('uncentred normalised sum', unc, 'sqrt', np.sqrt(unc), 'stored dcorr_biased', Dcorr(bias=True).statistic(z[0][:, None], z[1][:, None]))
