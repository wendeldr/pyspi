"""200-seed bias of the independent igci_ref on X ~ U(0,1), Y = X^3 (seeds 1000..1199), vs -C^G = 0.88320."""
import sys
import numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import _kernels_distance as kd
A = -((np.log(3) - 2) + np.log(1 / np.sqrt(12)) - 0.5 * np.log(1 / 7 - 1 / 16))
for T in (256, 1024, 4096, 16384, 65536):
    v = []
    for s in range(1000, 1200):
        u = np.random.default_rng(s).uniform(0.0, 1.0, T)
        v.append(kd.igci_ref(u, u ** 3))
    v = np.array(v); se = v.std(ddof=1) / np.sqrt(len(v))
    m20 = v[:20].mean(); se20 = v[:20].std(ddof=1) / np.sqrt(20)
    print(f"T={T}: mean200 {v.mean():.5f} bias {v.mean()-A:+.5f} se {se:.5f} z {(v.mean()-A)/se:+.2f} | first-20 mean {m20:.5f} se {se20:.5f}")
