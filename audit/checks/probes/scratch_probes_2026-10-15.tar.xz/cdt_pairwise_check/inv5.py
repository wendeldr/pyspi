import os; os.environ['OMP_NUM_THREADS']='1'; os.environ['OPENBLAS_NUM_THREADS']='1'
import sys, numpy as np, scipy
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import _kernels_distance as kd
from scipy.linalg import cho_factor, cho_solve
O='/media/dan/Data/git/pyspi/audit/checks/out/pyspi/'
def ld(r): z=np.load(O+r+'.npz'); return z['value'], z['input']
def lml(x,y,c,l,a=1e-10):
    K=c*np.exp(-0.5*kd._sqdiff_scaled(x,l)); cf=cho_factor(K+a*np.eye(len(x)),lower=True); al=cho_solve(cf,y)
    return -0.5*y@al-np.log(np.diag(cf[0])).sum()-0.5*len(x)*np.log(2*np.pi)
for ds in sys.argv[1:]:
    S, inp = ld(f'causal.anm|{ds}|256|pipeline|replica-theta'); th,_=ld(f'causal.anm|{ds}|256|pipeline|theta')
    P=S.shape[0]
    for i in range(P):
      for j in range(P):
        if i==j: continue
        c,l=np.exp(th[:,i,j]); c2,l2=kd.gp_fit_hyperparameters(inp[i],inp[j])
        r=kd.anm_replica(inp[i],inp[j],c,l)
        print(scipy.__version__, ds,i,j,f"rep {abs(r-S[i,j])/S[i,j]:.1e} sk l={l:.3e} c={c:.4f} own l={l2:.3e} c={c2:.4f} lml_sk={lml(inp[i],inp[j],c,l):.6f} lml_own={lml(inp[i],inp[j],c2,l2):.6f}")
