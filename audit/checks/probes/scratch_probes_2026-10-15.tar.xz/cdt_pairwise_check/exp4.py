import sys
import numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
from _kernels_distance import igci_ref
an = -((np.log(3) - 2) + np.log(1/np.sqrt(12)) - 0.5*np.log(1/7 - 1/16))
print('analytic', an)
for T in (256, 1024, 4096, 16384, 65536):
    v = []
    for s in range(20):
        rng = np.random.default_rng(1000 + s)
        x = rng.uniform(0, 1, T); y = x ** 3
        v.append(igci_ref(x, y))
    v = np.array(v)
    print(T, v.mean(), v.std(ddof=1)/np.sqrt(20), (v.mean()-an)/(v.std(ddof=1)/np.sqrt(20)))
