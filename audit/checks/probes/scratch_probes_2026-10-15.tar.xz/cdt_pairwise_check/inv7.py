import sys, numpy as np
O='/media/dan/Data/git/pyspi/audit/checks/out/'
for rid in ['causal.cds|anm|256|kernel|paper-variant','causal.cds|anm|1024|kernel|paper-variant','causal.cds|nonlinear_dependence|256|kernel|paper-variant']:
    S=np.load(O+'pyspi/'+rid+'.npz')['value']; V=np.load(O+'ref/'+rid+'.npz')['value']
    P=S.shape[0]
    print(rid, [(i,j, round(S[i,j]-S[j,i],4), round(V[i,j]-V[j,i],4)) for i in range(P) for j in range(i+1,P) if np.sign(S[i,j]-S[j,i])!=np.sign(V[i,j]-V[j,i])])
