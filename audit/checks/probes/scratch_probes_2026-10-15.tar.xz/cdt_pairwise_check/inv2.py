import sys, numpy as np, scipy
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import _kernels_distance as kd
O='/media/dan/Data/git/pyspi/audit/checks/out/pyspi/'
def ld(r): z=np.load(O+r+'.npz'); return z['value'], z['input']
S, inp = ld('causal.anm|nonlinear_dependence|256|pipeline|replica-theta')
th,_ = ld('causal.anm|nonlinear_dependence|256|pipeline|theta')
res = {}
for (i,j) in [(0,1),(1,3),(3,1),(2,3)]:
    c,l=np.exp(th[:,i,j])
    r = kd.gp_posterior_mean(inp[i], inp[j], c, l) - inp[j]
    res[(i,j)] = r
    a=kd.anm_replica(inp[i],inp[j],c,l)
    print(scipy.__version__, i,j, abs(a-S[i,j])/S[i,j])
np.save(f'inv2_r_{scipy.__version__}.npy', np.array([res[k] for k in sorted(res)]))
