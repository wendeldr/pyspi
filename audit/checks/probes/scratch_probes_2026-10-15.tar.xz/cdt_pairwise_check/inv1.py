import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import _kernels_distance as kd
from scipy.linalg import cholesky, cho_solve
from scipy.spatial.distance import pdist, cdist, squareform
O='/media/dan/Data/git/pyspi/audit/checks/out/pyspi/'
def ld(r): z=np.load(O+r+'.npz'); return z['value'], z['input']
def sk_rep(x, y, c, l, alpha=1e-10):
    X = x.reshape(-1,1); Y = y.reshape(-1,1)
    d = pdist(X / l, metric='sqeuclidean'); K = np.exp(-.5*d); K = squareform(K); np.fill_diagonal(K, 1)
    K = np.full((len(x),len(x)), c) * K
    K[np.diag_indices_from(K)] += alpha
    L = cholesky(K, lower=True, check_finite=False)
    a = cho_solve((L, True), Y, check_finite=False)
    Kt = np.full((len(x),len(x)), c) * np.exp(-.5*cdist(X/l, X/l, metric='sqeuclidean'))
    ym = Kt @ a
    r = ym.reshape(-1,1) - Y
    zs=lambda v:(v-v.mean())/v.std()
    return kd.cdt_fast_hsic_gamma(zs(r), zs(X))
S, inp = ld('causal.anm|nonlinear_dependence|256|pipeline|replica-theta')
th,_ = ld('causal.anm|nonlinear_dependence|256|pipeline|theta')
P=S.shape[0]
for i in range(P):
  for j in range(P):
    if i==j: continue
    c,l=np.exp(th[:,i,j])
    a=kd.anm_replica(inp[i],inp[j],c,l); b=sk_rep(inp[i],inp[j],c,l)
    print(i,j,f"l={l:.2e}", abs(a-S[i,j])/S[i,j], abs(b-S[i,j])/S[i,j])
