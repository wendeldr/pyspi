import sys, numpy as np, warnings
warnings.filterwarnings('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import _kernels_distance as kd
from cdt.causality.pairwise.ANM import normalized_hsic
from sklearn.gaussian_process import GaussianProcessRegressor
O='/media/dan/Data/git/pyspi/audit/checks/out/pyspi/'
def ld(r): z=np.load(O+r+'.npz'); return z['value'], z['input']
S, inp = ld('causal.anm|nonlinear_dependence|256|pipeline|replica-theta')
th,_ = ld('causal.anm|nonlinear_dependence|256|pipeline|theta')
zs=lambda v:(v-v.mean())/v.std()
for (i,j) in [(0,1),(1,3),(2,3),(3,1)]:
    c,l=np.exp(th[:,i,j])
    x, y = inp[i][:,None], inp[j][:,None]
    gp = GaussianProcessRegressor(random_state=42).fit(x, y)
    rs = gp.predict(x).reshape(-1,1) - y
    rr = (kd.gp_posterior_mean(inp[i], inp[j], c, l) - inp[j])[:,None]
    print(i,j,'theta same', np.array_equal(gp.kernel_.theta, th[:,i,j]), 'resid rel diff', np.abs(rs-rr).max()/np.abs(rs).max(),
      'cdt(rs)', abs(normalized_hsic(rs, x)-S[i,j])/S[i,j], 'kd(rs)', abs(kd.cdt_fast_hsic_gamma(zs(rs), zs(x))-S[i,j])/S[i,j],
      'cdt(rr)', abs(normalized_hsic(rr, x)-S[i,j])/S[i,j])
