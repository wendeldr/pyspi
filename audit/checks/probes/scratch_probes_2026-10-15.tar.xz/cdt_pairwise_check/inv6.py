import os; os.environ['OMP_NUM_THREADS']='1'
import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import _kernels_distance as kd
O='/media/dan/Data/git/pyspi/audit/checks/out/'
for rid in ['causal.anm|contaminated|64|pipeline|rawhsic','causal.anm|contaminated|256|pipeline|rawhsic','causal.anm|nonlinear_dependence|64|pipeline|rawhsic']:
    S=np.load(O+'pyspi/'+rid+'.npz')['value']; inp=np.load(O+'pyspi/'+rid+'.npz')['input']; H=np.load(O+'ref/'+rid+'.npz')['value']
    print(rid); print(np.round(S,4)); print(np.round(H,4))
    P=S.shape[0]
    for i in range(P):
      for j in range(P):
        if i!=j:
          c,l=kd.gp_fit_hyperparameters(inp[i],inp[j]); r=kd.gp_posterior_mean(inp[i],inp[j],c,l)-inp[j]
          d=np.diff(np.sort(inp[i])); print(i,j,f"l={l:.2e} rstd/ystd={r.std()/inp[j].std():.2e} min spacing x={d.min():.2e} n spacings<3l={np.sum(d<3*l)}")
