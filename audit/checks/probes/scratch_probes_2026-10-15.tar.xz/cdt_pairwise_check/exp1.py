import sys, time, warnings, json
import numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import make_data
from pyspi.data import Data
from sklearn.gaussian_process import GaussianProcessRegressor
from pyspi.statistics.causal import AdditiveNoiseModel
from _kernels_distance import anm_replica
warnings.filterwarnings('ignore')
ds, T = sys.argv[1], int(sys.argv[2])
x = make_data.load(ds, T)['x']
d = Data(np.array(x, dtype=float, copy=True), dim_order='ps')
z = d.to_numpy()
P = z.shape[0]
spi = AdditiveNoiseModel()
out = {}
for i in range(P):
    for j in range(P):
        if i == j: continue
        t0 = time.perf_counter()
        a = spi.bivariate(d, i=i, j=j)
        dt = time.perf_counter() - t0
        gp = GaussianProcessRegressor(random_state=42).fit(z[i], z[j])
        th = gp.kernel_.theta
        c, l = np.exp(th)
        r = anm_replica(z[i], z[j], c, l)
        out[(i, j)] = (a, th.tolist(), r)
        print(i, j, f"{dt:.2f}s", a, r, abs(a - r) / a, np.exp(th))
np.save(f'exp1_{ds}_{T}.npy', np.array([[i, j, v[0], v[1][0], v[1][1], v[2]] for (i, j), v in out.items()]))
