import json, sys
r = json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/results/cdt_pairwise.json'))
pat = sys.argv[1] if len(sys.argv) > 1 else ''
only_fail = '--fail' in sys.argv
for k, v in r.items():
    if pat not in k: continue
    if only_fail and v.get('pass'): continue
    ex = {kk: vv for kk, vv in v.items() if kk.startswith('ref_') or kk in ('max_abs','max_rel','direction_agreement','max_z','error')}
    print(('PASS' if v.get('pass') else 'FAIL'), k, v.get('criterion'), json.dumps(ex, default=str)[:900])
