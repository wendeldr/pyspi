import sys, warnings
import numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import make_data
from scipy.stats import zscore
from sklearn.gaussian_process import GaussianProcessRegressor
from _kernels_distance import anm_replica, cdt_fast_hsic_gamma
warnings.filterwarnings('ignore')
ds, T = sys.argv[1], int(sys.argv[2])
x = make_data.load(ds, T)['x']
z = zscore(x, axis=1, ddof=1)
E = np.load(f'exp1_{ds}_{T}.npy')
for row in E:
    i, j, a, lc, ll, r_proj = row; i, j = int(i), int(j)
    gp = GaussianProcessRegressor(random_state=42).fit(z[i][:, None], z[j][:, None])
    th = gp.kernel_.theta
    s = anm_replica(z[i], z[j], *np.exp(th))
    # sensitivity: one-ulp change of c
    c, l = np.exp([lc, ll])
    s_ulp = anm_replica(z[i], z[j], np.nextafter(c, 2), l)
    print(i, j, f"sk118 rel {abs(a-s)/a:.2e} dth {th[0]-lc:.1e} {th[1]-ll:.1e} | 1-ulp c rel {abs(a-s_ulp)/a:.2e}")
