"""Generates audit/checks/manifest/cdt_pairwise.json (kept in scratch; the JSON is the artifact)."""
import json
runs = []
PROBE = "probes/cdt_pairwise_probes.py"


def add(unit, ident, ds, T, path, tag, processes=None, probe=None):
    rid = f"causal.{unit}|{ds}|{T}|{path}|{tag}"
    runs.append(dict(run_id=rid, unit_id=f"causal.{unit}", identifier=ident, dataset=ds, T=T, path=path,
                     processes=processes, seed=42,
                     probe=None if probe is None else {"module": PROBE, "function": probe}))


P01, P23 = [0, 1], [2, 3]
# ------------------------------------------------------------------ anm
# A1 exact replica at sklearn's fitted theta (theta exported by a probe run with the same spec)
for ds, T, path, pr, sfx in [("anm", 64, "pipeline", None, ""), ("anm", 256, "pipeline", None, ""),
                             ("anm", 256, "kernel", None, ""), ("iid_gaussian", 256, "pipeline", None, ""),
                             ("bivariate_gaussian", 256, "pipeline", None, ""),
                             ("nonlinear_dependence", 256, "pipeline", None, ""),
                             ("contaminated", 256, "pipeline", None, ""),
                             ("anm", 1024, "pipeline", P01, "p01-"), ("anm", 1024, "pipeline", P23, "p23-")]:
    add("anm", "anm", ds, T, path, sfx + "theta", pr, "anm_theta")
    add("anm", "anm", ds, T, path, sfx + "replica-theta", pr)
for ds in ("nonlinear_dependence", "anm"):
    add("anm", "anm", ds, 256, "pipeline", "replica-projectenv", None, "anm_replica_projectenv")
# A2 replica with the reference's own L-BFGS-B fit
for ds, T in [("anm", 64), ("anm", 256), ("iid_gaussian", 256), ("bivariate_gaussian", 256), ("nonlinear_dependence", 256)]:
    add("anm", "anm", ds, T, "pipeline", "replica-ownfit")
# A3 GP collapse (qualitative)
for ds, T, pr, sfx in [("anm", 64, None, ""), ("anm", 256, None, ""), ("iid_gaussian", 256, None, ""),
                       ("bivariate_gaussian", 256, None, ""), ("nonlinear_dependence", 256, None, ""),
                       ("contaminated", 256, None, ""), ("anm", 1024, P01, "p01-")]:
    add("anm", "anm", ds, T, "pipeline", sfx + "collapse", pr, "anm_collapse")
# A4 anm vs plain m*HSIC_b of the raw pair (qualitative)
for ds in ["iid_gaussian", "bivariate_gaussian", "anm", "nonlinear_dependence", "contaminated"]:
    for T in (64, 256):
        add("anm", "anm", ds, T, "pipeline", "rawhsic")
add("anm", "anm", "anm", 1024, "pipeline", "p01-rawhsic", P01)
add("anm", "anm", "anm", 1024, "pipeline", "p23-rawhsic", P23)
add("anm", "anm", "bivariate_gaussian", 1024, "pipeline", "p23-rawhsic", P23)
# A5 direction on the anm dataset vs ground truth (canonical Hoyer reference as value)
add("anm", "anm", "anm", 256, "pipeline", "direction", None, "pairdiff")
add("anm", "anm", "anm", 1024, "pipeline", "p01-direction", P01, "pairdiff")
add("anm", "anm", "anm", 1024, "pipeline", "p23-direction", P23, "pairdiff")
# A6 200-point subsample effect
add("anm", "anm", "anm", 1024, "pipeline", "p01-subsample", P01)
add("anm", "anm", "anm", 1024, "pipeline", "p23-subsample", P23)
# A7 lagged direction datasets: orientation vs the reference of the same estimator
add("anm", "anm", "var2_bivariate", 1024, "pipeline", "orientation", None, "pairdiff")
add("anm", "anm", "logistic_maps_chaotic", 1024, "pipeline", "orientation", None, "pairdiff")
# A8-A10 random_state, global patch, labels
add("anm", "anm", "anm", 64, "pipeline", "random-state", None, "anm_random_state")
add("anm", "anm", "anm", 64, "pipeline", "patch-global", None, "anm_patch_global")
add("anm", "anm", "anm", 64, "pipeline", "labels", None, "anm_labels")
# A11 SciPy 1.18 drift mechanism (sklearn in the comparison venv: same-lineage)
add("anm", "anm", "anm", 256, "pipeline", "scipy118-drift")
# A12 input scale / detrend
add("anm", "anm", "scaled_offset", 256, "kernel", "scale")
add("anm", "anm", "trending", 256, "pipeline-detrend", "detrend")

# ------------------------------------------------------------------ cds
for ds in ["anm", "nonlinear_dependence", "iid_gaussian", "contaminated", "bivariate_gaussian"]:
    for T in (64, 256, 1024, 4096):
        add("cds", "cds", ds, T, "kernel", "exact")
add("cds", "cds", "anm", 1024, "pipeline", "exact")
add("cds", "cds", "iid_gaussian", 64, "pipeline", "exact")
add("cds", "cds", "anm", 1024, "pipeline-detrend", "exact")
for ds in ["anm", "nonlinear_dependence"]:
    for T in (256, 1024):
        add("cds", "cds", ds, T, "kernel", "paper-variant")
for T in (256, 1024, 4096):
    add("cds", "cds", "anm", T, "pipeline", "direction", None, "pairdiff")
add("cds", "cds", "var2_bivariate", 1024, "pipeline", "orientation", None, "pairdiff")
add("cds", "cds", "logistic_maps_chaotic", 1024, "pipeline", "orientation", None, "pairdiff")
for ds in ["iid_gaussian", "anm", "gauss_ar1_pair", "narrowband_f0-0.25"]:
    add("cds", "cds", ds, 64, "pipeline", "zero-predicate")
for T in (256, 1024):
    add("cds", "cds", "iid_gaussian", T, "pipeline", "spike-zero", None, "cds_spike")
for T in (256, 1024):
    add("cds", "cds", "scaled_offset", T, "kernel", "invariance")
    add("cds", "cds", "trending", T, "pipeline-detrend", "detrend")

# ------------------------------------------------------------------ reci
for ds in ["anm", "nonlinear_dependence", "iid_gaussian", "delayed_noise", "contaminated"]:
    for T in (64, 256, 1024, 4096):
        add("reci", "reci", ds, T, "kernel", "exact")
for ds in ["anm", "iid_gaussian"]:
    add("reci", "reci", ds, 1024, "pipeline", "exact")
    add("reci", "reci", ds, 1024, "pipeline-detrend", "exact")
for T in (256, 1024, 4096):
    add("reci", "reci", "anm", T, "pipeline", "direction", None, "pairdiff")
add("reci", "reci", "var2_bivariate", 1024, "pipeline", "orientation", None, "pairdiff")
add("reci", "reci", "logistic_maps_chaotic", 1024, "pipeline", "orientation", None, "pairdiff")
for T in (256, 1024):
    add("reci", "reci", "scaled_offset", T, "kernel", "invariance")
    add("reci", "reci", "trending", T, "pipeline-detrend", "detrend")

# ------------------------------------------------------------------ igci
for ds in ["anm", "nonlinear_dependence", "iid_gaussian", "delayed_noise", "contaminated"]:
    for T in (64, 256, 1024, 4096):
        add("igci", "igci", ds, T, "kernel", "exact")
for ds in ["anm", "iid_gaussian"]:
    add("igci", "igci", ds, 1024, "pipeline", "exact")
for T in (256, 1024, 4096):
    add("igci", "igci", "iid_gaussian", T, "pipeline", "cubic-analytic", None, "igci_cubic")
for ds in ["iid_gaussian", "anm", "nonlinear_dependence", "logistic_maps", "var2_bivariate"]:
    add("igci", "igci", ds, 1024, "pipeline", "antisym")
for T in (256, 1024, 4096):
    add("igci", "igci", "anm", T, "pipeline", "direction")
add("igci", "igci", "var2_bivariate", 1024, "pipeline", "orientation")
add("igci", "igci", "logistic_maps_chaotic", 1024, "pipeline", "orientation")
add("igci", "igci", "iid_gaussian", 64, "pipeline", "raw-bivariate", None, "igci_raw_bivariate")
add("igci", "igci", "iid_gaussian", 64, "pipeline", "labels", None, "igci_labels")

ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids)), [i for i in ids if ids.count(i) > 1]
json.dump({"family": "cdt_pairwise", "runs": runs}, open("/media/dan/Data/git/pyspi/audit/checks/manifest/cdt_pairwise.json", "w"), indent=1)
print(len(runs), "runs")
