import sys, warnings
import numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import make_data
from scipy.stats import zscore
from _kernels_distance import anm_replica, gp_fit_hyperparameters
warnings.filterwarnings('ignore')
ds, T = sys.argv[1], int(sys.argv[2])
x = make_data.load(ds, T)['x']
z = zscore(x, axis=1, ddof=1)
E = np.load(f'exp1_{ds}_{T}.npy')
for row in E:
    i, j, a, lc, ll, r_proj = row; i, j = int(i), int(j)
    r = anm_replica(z[i], z[j], np.exp(lc), np.exp(ll))
    c2, l2 = gp_fit_hyperparameters(z[i], z[j])
    r2 = anm_replica(z[i], z[j], c2, l2)
    print(i, j, a, r, f"rel {abs(a-r)/a:.2e}", f"ownfit rel {abs(a-r2)/a:.2e}", f"dlogc {np.log(c2)-lc:.2e} dlogl {np.log(l2)-ll:.2e}")
