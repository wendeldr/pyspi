import yaml
R = "/media/dan/Data/git/pyspi/audit/records/"
REF = "refs/cdt_pairwise.py"
PRB = "probes/cdt_pairwise_probes.py"


def load(u):
    return yaml.safe_load(open(R + u + ".yaml"))


def save(u, d):
    with open(R + u + ".yaml", "w") as f:
        yaml.safe_dump(d, f, sort_keys=False, width=135, allow_unicode=True, default_flow_style=False)


# ============================================================================================ anm
d = load("causal.anm"); c = d["correctness"]; d["status"] = "checked"
c["implemented_as"] = c["implemented_as"].replace(
    "so the score is essentially m*HSIC_b(y, x) of the raw pair.",
    "so the score is essentially m*HSIC_b(y, x) of the raw pair. Exactly, r = K(K + alpha I)^-1 y - y = -alpha (K + alpha I)^-1 y, so "
    "the score is m*HSIC_b(x, standardised (K + alpha I)^-1 y); it equals m*HSIC_b(x, y) when K ~ c I (no x-spacings below the "
    "fitted length scale) and departs from it where near-coincident x values are smoothed together (check stage: contaminated, "
    "nonlinear_dependence_T64).")
c["units_and_range"] = c["units_and_range"].replace("observed 0.09-0.35 on independent pairs", "observed 0.078-0.35 on independent pairs (check stage)")
c.update({
    "check_method": "independent-impl",
    "check_reference": f"{REF}:run_anm -> _kernels_distance.anm_replica, gp_fit_hyperparameters, gp_posterior_mean, cdt_fast_hsic_gamma "
        "(numpy/scipy; no sklearn, no cdt) and anm_canonical (Hoyer et al. 2009: GP C*RBF + White by type-II ML, full-sample m*HSIC_b, "
        f"gamma p-value); {PRB} (anm_theta, anm_collapse, pairdiff, anm_random_state, anm_patch_global, anm_labels, "
        "anm_replica_projectenv); the scipy118-drift run uses sklearn==1.9.1 under scipy==1.18.1 (same-lineage, mechanism only)",
    "check_data": "anm T64/256 (P=4) and T1024 (process pairs 0-1, 2-3); iid_gaussian T64/256; bivariate_gaussian T64/256 and T1024 "
        "(pair 2-3); nonlinear_dependence T64/256; contaminated T64/256; var2_bivariate T1024; logistic_maps_chaotic T1024; "
        "scaled_offset T256 (kernel path, raw scale); trending T256 (pipeline-detrend)",
    "agreement_criterion": "replica at sklearn's fitted theta: exact (rtol 1e-10, atol 1e-12); replica with the reference's own L-BFGS-B "
        "fit: rtol 1e-5 (one-ulp sensitivity of the score is ~2e-6); theta: atol 1e-3 in log theta; collapse: std(r)/std(y) < 1e-8 in "
        "sklearn's and the independent fit; raw-pair HSIC: median |A - H|/H < 0.1 and max < 0.3; direction: sign of A.T - A against "
        "ground truth (anm) or against the same-estimator reference (lagged datasets); random_state: exactly 0",
    "closeness": "replica at sklearn's theta: max rel <= 1.6e-15 on 8 of 9 runs (anm T64/T256 pipeline and kernel, anm T1024 both pairs "
        "0.0, iid_gaussian, bivariate_gaussian, contaminated T256); nonlinear_dependence_T256 7.5e-8 (one pair) in the comparison venv "
        "but 6.6e-16 when the same replica runs in the project venv (|replica-projectenv), i.e. scipy 1.18.1 vs 1.17.1 LAPACK roundoff. "
        "Own fit: anm_T64 9.9e-7, anm_T256 9.5e-7, nonlinear_dependence_T256 4.7e-6, bivariate_gaussian_T256 1.05e-5 (fails rtol 1e-5; "
        "lml gap 3.5e-6, flat optimum), iid_gaussian_T256 1.17e-2 (fails; pair (1,2): sklearn's L-BFGS-B stops at lml -362.672, the "
        "independent fit from the same start reaches -362.457, lml_ref_minus_sklearn_max 0.215; theta run |dlog l| 0.498). Theta: 8 of 9 "
        "runs within 1e-3 in log (max 2.6e-4). Collapse 7/7: std(r)/std(y) <= 1.3e-9 in both fits, max length scale 8.3e-4 (anm_T64), "
        "1e-5 bound on anm_T1024 0-1, median r/(-(alpha/c) y) within 1 +- 3e-6. Raw-pair HSIC 12/15 pass (median rel 2.5e-7..0.084); "
        "fails contaminated_T64 (median 0.30, max 0.52), contaminated_T256 (0.12, 0.21), nonlinear_dependence_T64 (median 1.2e-6, max 0.85). "
        "Direction vs ground truth: anm_T256 0.5 (D23 = -2.13), anm_T1024 pair 0-1 0.0 (D01 = -0.299), pair 2-3 1.0 (D23 = 1.22); "
        "canonical Hoyer reference 1.0 on all three (T1024 0->1 0.265 p 0.60 vs 1->0 8.88 p 4e-65). Subsample: 200-point replica "
        "reproduces pyspi to 3.9e-7; full-sample statistic 4.66-4.97x larger, pyspi decisions unchanged. random_state 0.0. SciPy 1.18.1 "
        "sklearn fit: max rel 1.95e-6 (dlog theta 4.1e-6); one-ulp change of c: 2.2e-6. scaled_offset raw: own fit 4.5e-4 (fails), pyspi "
        "moves 15% vs normalised bivariate_gaussian; trending detrend 3.0e-6 (pass), 17% vs trend-free.",
    "verdict": "related-quantity",
    "score_0_10": 4,
    "what_changed": "The GP has no noise term, so the marginal-likelihood fit interpolates (length scale at or near the 1e-5 bound) and "
        "the 'residual' is r = -alpha (K + alpha I)^-1 y ~ -(alpha/c) y. The score is therefore m*HSIC_b(x, (K + alpha I)^-1 y), a "
        "near-symmetric dependence score between x and y, not the residual-independence statistic of Hoyer et al.; it ranks the cubic "
        "anm pair wrongly at T=1024 and the tanh pair at T=256 where a canonical ANM (noise kernel) recovers both. The statistic is "
        "m*HSIC_b with m = min(T, 200) on a stride subsample. The value is defined only to ~1e-6 relative (one ulp of the fitted "
        "constant, BLAS thread count, SciPy build) and to the optimiser's end point (1.2% on iid_gaussian_T256).",
    "new_finding": True,
    "definition_under_review": False,
    "check_cost": "expensive: O(T^3) per likelihood evaluation; 1.5 s per P=4 matrix at T=256 and 17 s per 2-process matrix at T=1024 "
        "in this run; T=4096 not run (about 64x T=1024 per pair)",
    "symmetry_observed": "asym by construction but near-symmetric in practice: max|A - A.T| = 2.24 (contaminated_T256, 10.6 vs 12.9); "
        "relative asymmetry max|A - A.T|/A per run 0.014 (bivariate_gaussian_T1024 pair 2-3) to 0.85 (nonlinear_dependence_T64); never "
        "antisymmetric (max|A + A.T| = 45.1); no off-diagonal NaN or zero",
    "direction_observed": "A[i, j] = score for the hypothesis i -> j (x = process i regressed on, y = process j), lower = more "
        "consistent with i -> j: the orientation runs (A.T - A vs the independent replica) agree 1.0 on var2_bivariate and "
        "logistic_maps_chaotic. Against ground truth the decision A[j, i] - A[i, j] > 0 is unreliable: anm_T256 recovers x0 -> x1 but "
        "not x2 -> x3, anm_T1024 recovers x2 -> x3 but not x0 -> x1; logistic_maps_chaotic x -> y recovered, var2_bivariate x -> y not.",
    "candidate_resolutions": [
        {"candidate": "GP collapse makes anm a near-symmetric HSIC(x, y) dependence score", "outcome": "confirmed",
         "evidence": "causal.anm|*|collapse (7/7: std(r)/std(y) <= 1.3e-9 in sklearn's and the independent fit); causal.anm|*|rawhsic "
                     "(12/15 within median 0.1 / max 0.3 of plain m*HSIC_b; the 3 exceptions are where the fitted length scale exceeds "
                     "some x-spacings, explained exactly by r = -alpha (K + alpha I)^-1 y)"},
        {"candidate": "wrong causal ranking as a consequence", "outcome": "confirmed",
         "evidence": "causal.anm|anm|256|pipeline|direction (agreement 0.5, D23 = -2.13), causal.anm|anm|1024|pipeline|p01-direction "
                     "(0.0, D01 = -0.299); canonical C*RBF + White reference agreement 1.0 in both"},
        {"candidate": "mechanism for the documented SciPy 1.18 drift", "outcome": "confirmed",
         "evidence": "causal.anm|anm|256|pipeline|scipy118-drift (sklearn under scipy 1.18.1: max rel 1.95e-6 vs documented 1.25e-6; "
                     "one-ulp change of the fitted constant 2.2e-6; replica at pyspi's theta under scipy 1.18.1 6.6e-16); "
                     "causal.anm|nonlinear_dependence|256|pipeline|replica-theta vs |replica-projectenv (7.5e-8 vs 6.6e-16); scratch probe "
                     "cdt_pairwise_check/inv4.py: multi-threaded OpenBLAS changes sklearn's theta by up to 5.6e-7 (log) vs the "
                     "single-thread fit pyspi gets from pyspi/__init__.py:4"},
        {"candidate": "random_state=42 is a no-op", "outcome": "confirmed",
         "evidence": "causal.anm|anm|64|pipeline|random-state (max |score(7 or None) - score(42)| = 0.0 on 12 pairs)"},
        {"candidate": "label metadata says linear", "outcome": "confirmed",
         "evidence": "causal.anm|anm|64|pipeline|labels (flags [1, 0, 1]: 'linear' in class labels, 'nonlinear' only in config.yaml)"},
        {"candidate": "global side effect of the class-body monkeypatch", "outcome": "confirmed",
         "evidence": "causal.anm|anm|64|pipeline|patch-global (flags [1, 1, 1])"},
        {"candidate": "T-dependent scale (m*HSIC_b, m = min(T, 200), stride subsample)", "outcome": "confirmed",
         "evidence": "causal.anm|bivariate_gaussian|{64,256,1024}|pipeline|*rawhsic (rho 0.8 pair 3.24 at T64, 8.81 at T256, 8.45 at "
                     "T1024); causal.anm|anm|1024|pipeline|p01/p23-subsample (full-sample/200-point ratio 4.66-4.97); replica-theta "
                     "runs exact with the 1/m form"},
    ],
    "checks_run": [
        {"run_ids": ["causal.anm|*|theta", "causal.anm|*|replica-theta", "causal.anm|*|replica-projectenv"],
         "reference": f"{REF}:run_anm -> _kernels_distance.anm_replica / gp_fit_hyperparameters",
         "outcome": "replica-theta 8/9 pass (<= 1.6e-15), nonlinear_dependence_T256 fail 7.5e-8 (comparison-venv LAPACK; project-venv "
                    "replica 6.6e-16 pass); theta 8/9 pass, iid_gaussian_T256 fail (0.498 in log l, sklearn end point 0.215 nats below)"},
        {"run_ids": ["causal.anm|*|replica-ownfit"], "reference": f"{REF}:run_anm -> anm_replica with gp_fit_hyperparameters",
         "outcome": "3/5 pass (<= 4.7e-6); bivariate_gaussian_T256 1.05e-5 and iid_gaussian_T256 1.17e-2 fail (optimiser end points)"},
        {"run_ids": ["causal.anm|*|collapse"], "reference": f"{REF}:run_anm[collapse]", "outcome": "pass 7/7 (std(r)/std(y) <= 1.3e-9)"},
        {"run_ids": ["causal.anm|*|rawhsic"], "reference": f"{REF}:run_anm[rawhsic] -> cdt_fast_hsic_gamma",
         "outcome": "12/15 pass; contaminated T64/T256 and nonlinear_dependence_T64 fail (max rel 0.52, 0.21, 0.85)"},
        {"run_ids": ["causal.anm|anm|256|pipeline|direction", "causal.anm|anm|1024|pipeline|p01-direction",
                     "causal.anm|anm|1024|pipeline|p23-direction"], "reference": f"{REF}:anm_canonical",
         "outcome": "1 of 3 pass (agreement 0.5, 0.0, 1.0); canonical reference recovers the truth in all three"},
        {"run_ids": ["causal.anm|anm|1024|pipeline|p01-subsample", "causal.anm|anm|1024|pipeline|p23-subsample"],
         "reference": f"{REF}:run_anm[subsample]", "outcome": "pass 2/2 (200-point replica within 3.9e-7)"},
        {"run_ids": ["causal.anm|var2_bivariate|1024|pipeline|orientation", "causal.anm|logistic_maps_chaotic|1024|pipeline|orientation"],
         "reference": f"{REF}:run_anm[orientation]", "outcome": "pass 2/2 (agreement 1.0)"},
        {"run_ids": ["causal.anm|anm|64|pipeline|random-state", "causal.anm|anm|64|pipeline|patch-global", "causal.anm|anm|64|pipeline|labels"],
         "reference": f"{REF}:run_anm", "outcome": "pass 3/3 (0.0; [1, 1, 1]; [1, 0, 1])"},
        {"run_ids": ["causal.anm|anm|256|pipeline|scipy118-drift"], "reference": f"{REF}:run_anm[scipy118-drift] (same-lineage sklearn)",
         "outcome": "pass (max rel 1.95e-6 at rtol 1e-5)"},
        {"run_ids": ["causal.anm|scaled_offset|256|kernel|scale", "causal.anm|trending|256|pipeline-detrend|detrend"],
         "reference": f"{REF}:run_anm[scale/detrend]", "outcome": "detrend pass (3.0e-6); scale fail (4.5e-4, optimiser end point on raw-scale data)"},
    ],
})
save("causal.anm", d)

# ============================================================================================ cds
d = load("causal.cds"); c = d["correctness"]; d["status"] = "checked"
c.update({
    "check_method": "independent-impl",
    "check_reference": f"{REF}:run_cds -> _kernels_distance.cds_ref (numpy, no cdt/pandas); cds_variant (Fonollosa 2016 Sec. 2.1/2.3 "
        f"with sfactor 3 and ddof 1); cds_bins/cds_pmfs for the zero predicate; {PRB} (pairdiff, cds_spike)",
    "check_data": "kernel path: anm, nonlinear_dependence, iid_gaussian, contaminated, bivariate_gaussian at T64/256/1024/4096; pipeline: "
        "anm T1024, iid_gaussian T64; pipeline-detrend anm T1024; direction anm T256/1024/4096; orientation var2_bivariate and "
        "logistic_maps_chaotic T1024; zero predicate iid_gaussian, anm, gauss_ar1_pair, narrowband_f0-0.25 at T64; inline spike-heavy "
        "pair at T256/1024; scaled_offset (kernel) and trending (pipeline-detrend) at T256/1024",
    "agreement_criterion": "exact (rtol 1e-10, atol 1e-12) for the replica, invariance and detrend runs; direction: sign of A.T - A vs "
        "ground truth (anm) or the same-estimator reference (lagged); zero predicate: A == 0.0 wherever process i has <= 1 qualifying "
        "x-bin, |A| < 1e-15 iff the full predicate holds; paper variant: no ordering flips (qualitative)",
    "closeness": "exact 23/23 runs, max abs 2.8e-17 (pipeline input identical to pyspi's, max abs 0.0); direction anm 3/3 agreement 1.0 "
        "(D01 = 0.0215/0.0865/0.0963 and D23 = 0.0020/0.0268/0.0264 at T256/1024/4096); orientation 2/2 (truth also recovered); zero "
        "predicate 6/6: anm_T64 12 exact zeros = 12 count-part entries (qualifying bins per process [0, 1, 1, 1]), iid_gaussian_T64 8/8, "
        "gauss_ar1_pair_T64 2/2, narrowband_f0-0.25_T64 1 exact zero with no count-part entry (identical pmfs), spike input T256 and "
        "T1024 A[0,1] = 0.0 with one qualifying bin; invariance (scaled_offset raw vs reference on the unscaled draw) 2/2 max abs 1.4e-17; "
        "detrend 2/2 exact (detrending moves values by <= 0.011). Paper variant (sfactor 3, ddof 1): max rel 0.36-0.58 (sfactor alone "
        "0.39-0.50, ddof alone 0.08-0.12); orderings flip on 2-3 of 6 pairs in 3 of 4 runs, all on independent pairs or the symmetric "
        "circle pair; the causal anm pairs keep their ordering.",
    "verdict": "variant",
    "score_0_10": 7,
    "what_changed": "cdt's CDS = Fonollosa's sqrt(mean_k var_x P[:, k]) with ffactor 2 (13 levels of 0.5 SD) instead of the sfactor 3 the "
        "paper states for most measures, population variance (ddof 0), minimum 13 samples per x-bin; one direction only; returns 0.0 "
        "whenever at most one x-bin qualifies (any T: spike input at T1024), which reads as maximal causal evidence. The supplement's "
        "'standard deviation of the conditional distribution of y given x' does not describe the across-bin variability computed.",
    "new_finding": True,
    "definition_under_review": False,
    "check_cost": "cheap: 0.5 s for a P=4 matrix at T=4096",
    "symmetry_observed": "asym: max|A - A.T| = 0.160 (narrowband_f0-0.25_T64); whole rows are exactly 0.0 when process i has <= 1 "
        "qualifying x-bin (67 exact zeros of 412 entries across the runs, all at T64 or on the spike input); no NaN",
    "direction_observed": "A[i, j] = CDS(x = process i, y = process j), lower = more consistent with i -> j: A[1,0] > A[0,1] and "
        "A[3,2] > A[2,3] on anm at T256/1024/4096 (truth agreement 1.0); var2_bivariate and logistic_maps_chaotic also give "
        "A[1,0] > A[0,1] for x -> y (D01 = 0.0062, 0.0347)",
    "candidate_resolutions": [
        {"candidate": "degenerate exact zero when at most one x-bin qualifies (or identical pmfs)", "outcome": "confirmed",
         "evidence": "causal.cds|{iid_gaussian,anm,gauss_ar1_pair,narrowband_f0-0.25}|64|pipeline|zero-predicate (6/6 predicate "
                     "holds) and causal.cds|iid_gaussian|{256,1024}|pipeline|spike-zero (A[0,1] = 0.0 at T1024 with one qualifying bin)"},
        {"candidate": "supplement wording does not describe the computed quantity", "outcome": "confirmed",
         "evidence": "causal.cds|*|kernel|exact (pyspi equals cds_ref, the std of the column-centred pmf matrix across x-bins, to 2.8e-17)"},
        {"candidate": "ffactor=2 vs the paper's sfactor=3", "outcome": "inconclusive",
         "evidence": "causal.cds|{anm,nonlinear_dependence}|{256,1024}|kernel|paper-variant quantify the effect (max rel 0.39-0.50 from "
                     "sfactor alone, ordering flips only on independent or symmetric pairs); whether the original jarfo code used 2 for "
                     "CDS was not established (needs the original features.py)"},
    ],
    "checks_run": [
        {"run_ids": ["causal.cds|*|exact"], "reference": f"{REF}:run_cds -> _kernels_distance.cds_ref", "outcome": "pass 23/23 (max abs 2.8e-17)"},
        {"run_ids": ["causal.cds|anm|{256,1024,4096}|pipeline|direction", "causal.cds|{var2_bivariate,logistic_maps_chaotic}|1024|pipeline|orientation"],
         "reference": f"{REF}:run_cds", "outcome": "pass 5/5 (agreement 1.0)"},
        {"run_ids": ["causal.cds|*|zero-predicate", "causal.cds|*|spike-zero"], "reference": f"{REF}:run_cds (cds_bins, cds_pmfs)",
         "outcome": "pass 6/6"},
        {"run_ids": ["causal.cds|*|invariance", "causal.cds|*|detrend"], "reference": f"{REF}:run_cds", "outcome": "pass 4/4 (exact)"},
        {"run_ids": ["causal.cds|*|paper-variant"], "reference": f"{REF}:cds_variant",
         "outcome": "1/4 pass; 3 runs flip the ordering of 2-3 non-causal pairs (max rel 0.36-0.58)"},
    ],
})
save("causal.cds", d)

# ============================================================================================ reci
d = load("causal.reci"); c = d["correctness"]; d["status"] = "checked"
c.update({
    "check_method": "independent-impl",
    "check_reference": f"{REF}:run_reci -> _kernels_distance.reci_ref (numpy lstsq on [1, x^3] after min-max scaling, no sklearn/cdt); "
        f"reci_canonical (Bloebaum et al. 2018: MON family n = 2..9, held-out MSE over 20 splits); {PRB}:pairdiff",
    "check_data": "kernel path: anm, nonlinear_dependence, iid_gaussian, delayed_noise, contaminated at T64/256/1024/4096; pipeline and "
        "pipeline-detrend: anm, iid_gaussian T1024; direction anm T256/1024/4096; orientation var2_bivariate, logistic_maps_chaotic "
        "T1024; scaled_offset (kernel) and trending (pipeline-detrend) T256/1024",
    "agreement_criterion": "exact (rtol 1e-10, atol 1e-12) for replica, invariance and detrend runs; direction: sign of A.T - A vs ground "
        "truth (anm) or the same-estimator reference (lagged)",
    "closeness": "exact 24/24 runs (kernel, pipeline, pipeline-detrend), max abs 5.6e-17; invariance (raw scaled_offset vs the reference on "
        "the unscaled draw) 2/2 max abs 6.9e-18; detrend 2/2 exact (detrending moves values by <= 1.0e-3); direction anm: T256 and T4096 "
        "agreement 1.0, T1024 0.5 (tanh pair D23 = -0.00026, while the canonical MON-family held-out RECI gives +0.0007); cubic pair D01 = "
        "0.0283/0.0291/0.0285 (canonical 0.0213/0.0237/0.0231); orientation 2/2 (var2_bivariate truth recovered, logistic_maps_chaotic "
        "not, identical in the reference)",
    "verdict": "variant",
    "score_0_10": 7,
    "what_changed": "Matches the supplement ('MSE of the linear regression of the cubic (plus constant) of x with y') exactly; differs from "
        "canonical RECI by using one fixed monomial a*x^3 + b instead of a selected function class, in-sample instead of held-out MSE, "
        "and returning only MSE_{i->j} (the comparison with MSE_{j->i} is left to the user). The fixed cubic misranks the tanh anm pair "
        "at T1024 where the canonical form does not.",
    "new_finding": False,
    "definition_under_review": False,
    "check_cost": "cheap: 0.03 s for a P=4 matrix at T=4096",
    "symmetry_observed": "asym: max|A - A.T| = 0.069 (nonlinear_dependence_T4096); values 0.0095-0.130 (within the 0.25 bound); no NaN or zero",
    "direction_observed": "A[i, j] = in-sample MSE of predicting min-max-scaled z_j from (scaled z_i)^3, lower = more consistent with i -> j: "
        "A[1,0] > A[0,1] on the cubic anm pair at every T; the tanh pair is a near-tie (wrong sign at T1024); var2_bivariate x -> y "
        "recovered (D01 = 0.0024), logistic_maps_chaotic not (D01 = -0.040)",
    "candidate_resolutions": [
        {"candidate": "fixed odd monomial a*x^3 + b only (not a general nonlinear regression error)", "outcome": "confirmed",
         "evidence": "causal.reci|anm|1024|pipeline|direction (pyspi D23 = -0.00026 equals the cdt-form reference; canonical MON-family "
                     "RECI +0.0007); behaviour documented in supplement Sec. 1.3.4, so not counted as a new finding"},
    ],
    "checks_run": [
        {"run_ids": ["causal.reci|*|exact"], "reference": f"{REF}:run_reci -> _kernels_distance.reci_ref", "outcome": "pass 24/24 (max abs 5.6e-17)"},
        {"run_ids": ["causal.reci|*|invariance", "causal.reci|*|detrend"], "reference": f"{REF}:run_reci", "outcome": "pass 4/4 (exact)"},
        {"run_ids": ["causal.reci|anm|{256,1024,4096}|pipeline|direction"], "reference": f"{REF}:reci_canonical",
         "outcome": "2/3 pass; T1024 fails on the tanh pair (D23 = -0.00026)"},
        {"run_ids": ["causal.reci|{var2_bivariate,logistic_maps_chaotic}|1024|pipeline|orientation"], "reference": f"{REF}:run_reci",
         "outcome": "pass 2/2"},
    ],
})
save("causal.reci", d)

# ============================================================================================ igci
d = load("causal.igci"); c = d["correctness"]; d["status"] = "checked"
c["units_and_range"] = c["units_and_range"].replace(
    "observed -0.49..+0.49 on test data;",
    "observed -0.52..+0.52 on the continuous check data and -6.35..+6.35 on logistic_maps_T1024 (period-4 y with repeated values: "
    "zero spacings are skipped while the divisor stays m-1);")
c.update({
    "check_method": "analytic",
    "check_reference": f"{REF}:run_igci -> _kernels_distance.igci_ref (Daniusis et al. 2010 eq. 12, Gaussian reference; numpy/scipy, "
        "no cdt/sklearn); analytic -C^G = 0.88320 for X ~ U(0,1), Y = X^3; analytic antisymmetry; "
        f"{PRB} (igci_cubic, igci_raw_bivariate, igci_labels)",
    "check_data": "kernel path: anm, nonlinear_dependence, iid_gaussian, delayed_noise, contaminated at T64/256/1024/4096; pipeline anm, "
        "iid_gaussian T1024; inline U(0,1) -> x^3 pair, 20 seeds at T256/1024/4096; antisymmetry on iid_gaussian, anm, "
        "nonlinear_dependence, logistic_maps, var2_bivariate T1024; direction anm T256/1024/4096; orientation var2_bivariate, "
        "logistic_maps_chaotic T1024; raw two-array path on the cubic pair T1024",
    "agreement_criterion": "exact (rtol 1e-10, atol 1e-12); antisymmetry bit-exact (rtol = atol = 0); analytic: |mean over 20 seeds - "
        "0.88320| <= 2 se; direction: sign of A vs ground truth (anm) or the reference (lagged)",
    "closeness": "exact 22/22 runs, max abs 3.0e-14 (max rel 1.5e-11 on near-zero entries); antisymmetry 5/5 max|A + A.T| = 0.0; analytic "
        "3/3: pyspi mean 0.8746/0.8742/0.8741 at T256/1024/4096 vs 0.8832 (|z| = 0.36/0.93/1.51, se 0.024/0.0097/0.0060); raw two-array "
        "path gap A[0,1] + A[1,0] = 7.59e-9 reproduced to 1.5e-14 by the reference on (zscore(first), raw second), 0.0 with both "
        "z-scored; direction anm agreement 0.5 at every T (cubic pair A01 = -0.200/-0.088/-0.151 in pyspi and in the reference, tanh "
        "pair A23 = +0.187/+0.123/+0.049); orientation 2/2 (truth recovered: A01 = 0.021, 0.946)",
    "verdict": "matches",
    "score_0_10": 9,
    "what_changed": "Matches Daniusis et al. eq. (12) with the Gaussian reference measure up to the sign convention: A[i, j] = -C_{i->j} "
        "(positive = i -> j, cdt's convention, undocumented in pyspi). The output is signed and exactly antisymmetric but the class, "
        "config and supplement label it 'unsigned'. Zero spacings (tied data) are skipped with divisor m-1, giving large values on "
        "repeated-value data (logistic_maps +-6.35).",
    "new_finding": True,
    "definition_under_review": False,
    "check_cost": "cheap: 0.12 s for a P=4 matrix at T=4096",
    "symmetry_observed": "antisym exactly: max|A + A.T| = 0.0 on all 5 antisymmetry runs (multivariate path); max|A - A.T| = 12.69 "
        "(logistic_maps_T1024); the raw two-array bivariate path departs by 7.59e-9",
    "direction_observed": "A[i, j] = S(z_i) - S(z_j) = -C_{i->j}; positive = i -> j: the deterministic U(0,1) -> x^3 pair gives +0.874 "
        "(analytic +0.883), var2_bivariate and logistic_maps_chaotic give A[0,1] > 0 for x -> y; on the noisy anm pairs the tanh pair is "
        "positive and the cubic pair negative (method limit shared by the reference)",
    "candidate_resolutions": [
        {"candidate": "signed output labelled unsigned", "outcome": "confirmed",
         "evidence": "causal.igci|iid_gaussian|64|pipeline|labels (flags [1, 0, 1]); exact runs pyspi range -0.52..+0.52; antisym runs "
                     "max|A + A.T| = 0.0"},
        {"candidate": "undocumented sign convention (positive = i -> j = -C)", "outcome": "confirmed",
         "evidence": "causal.igci|iid_gaussian|{256,1024,4096}|pipeline|cubic-analytic (+0.874 vs -C^G = +0.883)"},
        {"candidate": "raw two-array bivariate path not exactly antisymmetric (owned by preproc.two_array_api)", "outcome": "confirmed",
         "evidence": "causal.igci|iid_gaussian|64|pipeline|raw-bivariate (pyspi gap 7.5885e-9, reference on (zscore(first), raw second) "
                     "7.5885e-9, both z-scored 0.0)"},
    ],
    "checks_run": [
        {"run_ids": ["causal.igci|*|exact"], "reference": f"{REF}:run_igci -> _kernels_distance.igci_ref", "outcome": "pass 22/22 (max abs 3.0e-14)"},
        {"run_ids": ["causal.igci|iid_gaussian|{256,1024,4096}|pipeline|cubic-analytic"], "reference": "analytic -C^G = 0.88320",
         "outcome": "pass 3/3 (|z| <= 1.51)"},
        {"run_ids": ["causal.igci|*|antisym"], "reference": "analytic antisymmetry", "outcome": "pass 5/5 (0.0)"},
        {"run_ids": ["causal.igci|anm|{256,1024,4096}|pipeline|direction"], "reference": f"{REF}:run_igci",
         "outcome": "0/3 pass (agreement 0.5: cubic pair reversed in pyspi and the reference alike)"},
        {"run_ids": ["causal.igci|{var2_bivariate,logistic_maps_chaotic}|1024|pipeline|orientation", "causal.igci|iid_gaussian|64|pipeline|raw-bivariate",
                     "causal.igci|iid_gaussian|64|pipeline|labels"], "reference": f"{REF}:run_igci", "outcome": "pass 4/4"},
    ],
})
save("causal.igci", d)
print("ok")
