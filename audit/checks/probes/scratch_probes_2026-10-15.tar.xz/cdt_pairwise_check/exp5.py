import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/probes')
from cdt_pairwise_probes import spike_input
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
from _kernels_distance import _cds_discretize, cds_ref
from scipy.stats import zscore
for T in (256, 512, 1024):
    X = spike_input(T)
    z = zscore(X, axis=1, ddof=1)
    xd = _cds_discretize(z[0], 2, 3)
    u, c = np.unique(xd, return_counts=True)
    print(T, dict(zip(u, c)), cds_ref(z[0], z[1]), cds_ref(z[1], z[0]))
