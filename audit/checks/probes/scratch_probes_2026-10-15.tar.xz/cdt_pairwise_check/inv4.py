import sys, numpy as np, warnings, os
warnings.filterwarnings('ignore')
from sklearn.gaussian_process import GaussianProcessRegressor
O='/media/dan/Data/git/pyspi/audit/checks/out/pyspi/'
z=np.load(O+'causal.anm|nonlinear_dependence|256|pipeline|replica-theta.npz'); inp=z['input']
th=np.load(O+'causal.anm|nonlinear_dependence|256|pipeline|theta.npz')['value']
for rep in range(3):
    out=[]
    for (i,j) in [(0,1),(1,3),(2,3),(3,1),(0,2)]:
        gp = GaussianProcessRegressor(random_state=42).fit(inp[i][:,None], inp[j][:,None])
        out.append(np.abs(gp.kernel_.theta - th[:,i,j]).max())
    print(os.environ.get('OPENBLAS_NUM_THREADS'), rep, ['%.1e'%v for v in out])
