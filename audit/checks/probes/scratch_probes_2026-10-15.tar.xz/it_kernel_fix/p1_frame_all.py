import sys, io, contextlib, copy, numpy as np, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
warnings.filterwarnings('ignore')
import jpype as jp
from pyspi.calculator import Calculator, CalculatorFrame
import pyspi.statistics.infotheory as it
cfg = sys.argv[1]
for ds in ['bivariate_gaussian_T256', 'var2_bivariate_T256']:
    x = np.load('/media/dan/Data/git/pyspi/audit/checks/data/%s.npz' % ds)['x']
    with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
        c = Calculator(dataset=x, configfile=cfg); c.compute()
        f = CalculatorFrame(datasets=[x], names=['a'], labels=[['l']], configfile=cfg); f.compute()
    cf = f.calculators.iloc[0, 0]
    print('==', ds)
    for k in c.spis:
        a = c.table[k].to_numpy(); b = cf.table[k].to_numpy()
        s0 = c.spis[k]; s = cf.spis[k]; cal = getattr(s, '_calc', None)
        print('%-24s A01 Calc=%.10f Frame=%.10f diff=%.3e | A10 diff=%.3e | orig entKW=%s frame entKW=%s frame calcKW=%s same_obj=%s' % (
            k, a[0,1], b[0,1], a[0,1]-b[0,1], a[1,0]-b[1,0], s0._entropy_calc.getProperty('KERNEL_WIDTH'),
            s._entropy_calc.getProperty('KERNEL_WIDTH'), None if cal is None else cal.getProperty('KERNEL_WIDTH'),
            s._entropy_calc is s0._entropy_calc))
# mechanism: deepcopy of a single SPI and of the bare Java object
je = it.JointEntropy(estimator='kernel')
print('orig KW', je._entropy_calc.getProperty('KERNEL_WIDTH'), 'NOISE_SEED', je._entropy_calc.getProperty('NOISE_SEED'))
jc = copy.deepcopy(je._entropy_calc)
print('deepcopy(java obj): class', jc.getClass().getName(), 'KW', jc.getProperty('KERNEL_WIDTH'), 'NOISE_SEED', jc.getProperty('NOISE_SEED'), 'is same', jc is je._entropy_calc)
je2 = copy.deepcopy(je)
print('deepcopy(SPI): id', je2.identifier, '_kernel_width', je2._kernel_width, 'entropy KW', je2._entropy_calc.getProperty('KERNEL_WIDTH'))
# direct W-0.25 JE value on bivariate_gaussian
x = np.load('/media/dan/Data/git/pyspi/audit/checks/data/bivariate_gaussian_T256.npz')['x']
from pyspi.data import Data
with contextlib.redirect_stdout(io.StringIO()):
    d = Data(x, dim_order='ps', normalise=True)
    print_ = (it.JointEntropy(estimator='kernel', kernel_width=0.25).bivariate(d, i=0, j=1),
              it.ConditionalEntropy(estimator='kernel', kernel_width=0.25).bivariate(d, i=0, j=1))
print('direct je W-0.25 A01=%.10f ce W-0.25 A01=%.10f' % print_)
