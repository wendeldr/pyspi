import sys
from pathlib import Path
sys.path.insert(0, '/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/it_kernel_fix')
f = Path('/media/dan/Data/git/pyspi/audit/records/infotheory.est.kernel.yaml'); t = f.read_text()
def rep(old, new):
    global t
    if t.count(old) != 1: sys.exit(f'count {t.count(old)} for {old[:70]!r}')
    t = t.replace(old, new)
rep("""    no bias correction. Bins of width w_d""", """    no bias correction (the JIDT kernel classes have no bias-correction option). Bins of width w_d""")
rep("""    pyspi properties BIAS_CORRECTION='false' and NOISE_SEED='42' are not recognised by these classes and have no
    effect.""", """    pyspi's BIAS_CORRECTION='false' is not a property of any kernel class and is ignored. NOISE_SEED='42' is stored
    by EntropyCalculatorMultiVariateKernel (via EntropyCalculatorMultiVariateCommon) and by MutualInfoCalculatorMultiVariateKernel
    (via MutualInfoMultiVariateCommon), but noise is added only when NOISE_LEVEL_TO_ADD is non-zero and pyspi leaves
    it at the default 0, so the seed has no numerical effect; TransferEntropyCalculatorKernel ignores NOISE_SEED.
    Copy path: JIDTBase.__deepcopy__ resets the JIDT calculators to their defaults (KERNEL_WIDTH 0.25), so a CalculatorFrame
    computes every W-0.5 kernel SPI at width 0.25 under its W-0.5 identifier; the W-0.25 SPIs are unchanged only because
    0.25 is JIDT's default.""")
rep("""  - >-
    Candidate (no-op properties): pyspi's BIAS_CORRECTION='false' and NOISE_SEED='42' (infotheory.py:90-91) are
    ignored by the kernel calculators (probe: TransferEntropyCalculatorKernel.getProperty returns None for both
    after setProperty); JIDT's kernel default width is 0.25 while JIDTBase's default is 0.5.
""", """  - >-
    Candidate (inert properties): pyspi's BIAS_CORRECTION='false' (infotheory.py:90) is not a property of any kernel
    class (getProperty returns None on all three) and is ignored. NOISE_SEED='42' (infotheory.py:91) is stored but
    numerically inert in the entropy and MI kernel classes, because NOISE_LEVEL_TO_ADD defaults to 0 (EntropyCalculatorMultiVariateCommon
    L70-74, L200-211; MutualInfoMultiVariateCommon L627-642), and is ignored by TransferEntropyCalculatorKernel. Probe
    it_kernel_fix/p2_props.py: EntropyCalculatorMultiVariateKernel (superclass EntropyCalculatorMultiVariateCommon)
    and MutualInfoCalculatorMultiVariateKernel (superclass MutualInfoMultiVariateCommon) read NOISE_SEED '42', NOISE_LEVEL_TO_ADD
    '0.0'; TransferEntropyCalculatorKernel reads None for both; on 300 N(0,1) samples the kernel entropy changes by
    0 with NOISE_SEED alone and by -1.5e-9 bits with NOISE_LEVEL_TO_ADD=1e-8 and seed 42, and BIAS_CORRECTION=true
    changes entropy and MI by 0. JIDT's kernel default width is 0.25 while JIDTBase's default is 0.5.
  - >-
    Candidate (copy path, confirmed by probe): a CalculatorFrame computes every W-0.5 kernel SPI with width 0.25
    while the identifier still reads W-0.5. JIDTBase.__deepcopy__ (infotheory.py:77-82) builds type(self)() and deep-copies
    each attribute; copy.deepcopy of the JPype proxy returns a new Java object of the same class in its default state
    (KERNEL_WIDTH 0.25, NOISE_SEED 'NONE') and _setup is not re-run. CalculatorFrame.init_from_list deep-copies the
    base Calculator for every dataset (calculator.py:556-562). Probe it_kernel_fix/p1_frame_all.py, bivariate_gaussian
    T=256, A[0,1] Calculator vs CalculatorFrame: je 3.9822833545 vs 3.7487119189 (= direct W-0.25 je), ce 1.9366210046
    vs 1.7266038499 (= direct W-0.25 ce), cce 3.4050629409 vs -1.7929180304, xme_k1 1.9814677814 vs 1.7793580942,
    xme_k10 0.0037640804 vs -0.9962359196, di 5.8235130138 vs 8.6877200525, si 0.9962347218 vs 3.2876894572; mi,
    tlmi and te (W-0.25) identical, only because 0.25 is JIDT's default. Same pattern on var2_bivariate T=256. A pickle
    round trip keeps the width (__setstate__ :71-75 re-applies _setup; probe it_kernel_fix/p4_pickle.py). The effect
    is larger than the kraskov TE copy bug and also breaks the [0, log2 N] range of the W-0.5 entropies (negative
    cce and xme_k10 values in the frame).
""")
TRACE = """  - >-
    pyspi/statistics/infotheory.py:60-82 JIDTBase.__getstate__/__setstate__/__deepcopy__ (copy path; not used by
    Calculator.compute): pickling drops _entropy_calc and _calc (:60-69) and __setstate__ (:71-75; MutualInfo :262,
    TimeLaggedMutualInfo :295, TransferEntropy :369 also rebuild _calc) rebuilds them with _getcalc, which re-applies
    _setup; __deepcopy__ (:77-82) builds type(self)() and then deep-copies every attribute, and copy.deepcopy of the
    JPype proxy returns a new Java object of the same class in its default state without _setup (probe it_kernel_fix/p1_frame_all.py:
    KERNEL_WIDTH 0.25, NOISE_SEED 'NONE'); pyspi/calculator.py:556-562 CalculatorFrame.init_from_list deep-copies
    the base Calculator for every dataset (copy.deepcopy at :559)
"""
ANCHOR = "NOISE_LEVEL_TO_ADD stays 0, and TransferEntropyCalculatorKernel ignores it (see infotheory.est.kernel)\n"
rep(ANCHOR, ANCHOR + TRACE)
t = t.rstrip('\n') + '\n' + """  - datasets:
    - bivariate_gaussian
    - var2_bivariate
    path: pipeline
    reference: >-
      CalculatorFrame (deepcopy, calculator.py:559) vs Calculator on the same data and config for all ten kernel
      SPIs, plus getProperty('KERNEL_WIDTH') and getProperty('NOISE_SEED') on the copied calculators and a pickle round
      trip of each SPI
    reference_kind: same-lineage
    criterion: exact
    expected_outcome: >-
      Differs for the seven W-0.5 SPIs (frame value = W-0.25 value; copied calculators read KERNEL_WIDTH 0.25, NOISE_SEED
      'NONE'); identical for mi/tlmi/te; pickle round trip keeps KERNEL_WIDTH 0.5. Documents the copy bug.
  - datasets:
    - iid_gaussian
    path: kernel
    reference: >-
      property read-back and perturbation on the three JIDT kernel classes: getProperty of NOISE_SEED, NOISE_LEVEL_TO_ADD
      and BIAS_CORRECTION after pyspi's _setup; entropy and MI with NOISE_SEED alone, with NOISE_LEVEL_TO_ADD=1e-8
      plus seed, and with BIAS_CORRECTION=true
    reference_kind: same-lineage
    criterion: exact
    expected_outcome: >-
      Entropy and MI classes read NOISE_SEED '42', NOISE_LEVEL_TO_ADD '0.0'; TE class reads None; seed alone and BIAS_CORRECTION
      change nothing (diff 0); a non-zero noise level changes the value (probe -1.5e-9 bits), showing the seeded
      noise path is live but unused.
"""
f.write_text(t)
print('ok')
