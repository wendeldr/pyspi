import re, sys
from pathlib import Path
R = Path('/media/dan/Data/git/pyspi/audit/records')
units = ['je.kernel','ce.kernel','cce.kernel','xme.kernel_k1','xme.kernel_k10','di.kernel','si.kernel','mi.kernel','tlmi.kernel','te.kernel_k-1_kt-1_l-1_lt-1','est.kernel']
W05 = ['je.kernel','ce.kernel','cce.kernel','xme.kernel_k1','xme.kernel_k10','di.kernel','si.kernel']
texts = {u: (R / f'infotheory.{u}.yaml').read_text() for u in units}

def rep(u, old, new, count=1):
    t = texts[u]
    n = t.count(old)
    if n != count:
        sys.exit(f'{u}: expected {count} of {old[:80]!r}, found {n}')
    texts[u] = t.replace(old, new)

# 1. Entropy-kernel trace entry: v1.6.1 lines -> shipped build a9b6b3e
OLD_ENT = """  - >-
    JIDT v1.6.1 https://raw.githubusercontent.com/jlizier/jidt/v1.6.1/java/source/infodynamics/measures/continuous/kernel/EntropyCalculatorMultiVariateKernel.java:
    initialise(int) L115-136 (uses kernelWidth set by setProperty L247-270; unknown properties ignored), setObservations
    L139-155, computeAverageLocalOfObservations L157-170 = -(1/N) sum_b ln p(x_b) / ln 2 (bits)
"""
NEW_ENT = """  - >-
    JIDT master commit a9b6b3e (2024-04-20; the build shipped in pyspi/lib/jidt/infodynamics.jar, see infotheory.est.kernel
    delegate_lib) java/source/infodynamics/measures/continuous/kernel/EntropyCalculatorMultiVariateKernel.java (rewritten
    after the v1.6.1 tag): extends EntropyCalculatorMultiVariateCommon (L47-48); default kernelWidth 0.25 (DEFAULT_EPSILON
    L57, field L61); setProperty L195-220 sets kernelWidth for KERNEL_WIDTH/EPSILON and passes every other name to
    EntropyCalculatorMultiVariateCommon.setProperty; initialise(int) L81-83 -> initialise(int, double) L96-100 (Common.initialise
    L107-113 resets isComputed, then mvke.initialise); setObservations is inherited (Common L215-219 / L229-233: startAddObservations,
    addObservations, finaliseAddObservations) and the override finaliseAddObservations L102-106 hands the stored
    observations to mvke.setObservations; computeAverageLocalOfObservations L108-125 = -(1/N) sum_b ln p(x_b) / ln
    2 (bits), returned from the isComputed memo on repeat calls
  - >-
    JIDT master a9b6b3e java/source/infodynamics/measures/continuous/EntropyCalculatorMultiVariateCommon.java (the
    file does not exist at the v1.6.1 tag): setProperty L115-148 stores NORMALISE (L122-123), NOISE_LEVEL_TO_ADD
    (L124-132) and NOISE_SEED (L133-139) and ignores any other name such as BIAS_CORRECTION (L140-142); defaults addNoise
    = false, noiseLevel = 0 (L70-74); finaliseAddObservations L178-212 adds Gaussian noise from a Random seeded with
    noiseSeed only when addNoise is true (L200-211), so pyspi's NOISE_SEED='42' is stored but changes nothing while
    NOISE_LEVEL_TO_ADD stays at its default 0
"""
for u in W05 + ['est.kernel']:
    rep(u, OLD_ENT, NEW_ENT)

# 2. Byte-identical files: keep v1.6.1 line numbers, state identity with the shipped build
IDENT = ['kernel/KernelEstimatorMultiVariate.java', 'utils/MatrixUtils.java', 'kernel/MutualInfoCalculatorMultiVariateKernel.java',
         'kernel/TransferEntropyCalculatorKernel.java', 'kernel/KernelEstimatorTransferEntropy.java', 'TransferEntropyCommon.java']
for u in units:
    t = texts[u]
    def sub(m):
        path = m.group(1)
        if not any(path.endswith(f) for f in IDENT):
            return m.group(0)
        return (f'JIDT v1.6.1 tag https://raw.githubusercontent.com/jlizier/jidt/v1.6.1/java/source/infodynamics/{path}'
                ' (byte-identical to master a9b6b3e, the shipped build; line numbers valid for both):')
    texts[u] = re.sub(r'JIDT v1\.6\.1 https://raw\.githubusercontent\.com/jlizier/jidt/v1\.6\.1/java/source/infodynamics/(\S+?\.java):', sub, t)

# 3. MutualInfoMultiVariateCommon entries (file differs between v1.6.1 and the shipped build)
NEW_MIC_TAIL = """JIDT master a9b6b3e java/source/infodynamics/measures/continuous/MutualInfoMultiVariateCommon.java (differs from
    the v1.6.1 tag): setProperty L245-280 stores TIME_DIFF, NORMALISE, NOISE_LEVEL_TO_ADD (L255-264) and NOISE_SEED
    (L265-271) and ignores any other name such as BIAS_CORRECTION; getProperty L282-302 returns '42' for NOISE_SEED
    after pyspi's setProperty; finaliseAddObservations L574-643 calls normaliseData when normalise (L622-624; a no-op
    for the kernel class, MutualInfoCalculatorMultiVariateKernel L166-171) and adds seeded Gaussian noise only when
    NOISE_LEVEL_TO_ADD was set (L627-642; default 0, so no noise)"""
rep('mi.kernel', """JIDT v1.6.1 https://raw.githubusercontent.com/jlizier/jidt/v1.6.1/java/source/infodynamics/measures/continuous/MutualInfoMultiVariateCommon.java:
    setProperty L201-229 (noise off unless NOISE_LEVEL_TO_ADD set; NOISE_SEED unknown -> ignored), finaliseAddObservations
    L477-532 (timeDiff 0)""", NEW_MIC_TAIL + ', timeDiff 0')
rep('est.kernel', """JIDT v1.6.1 https://raw.githubusercontent.com/jlizier/jidt/v1.6.1/java/source/infodynamics/measures/continuous/MutualInfoMultiVariateCommon.java:
    setProperty L201-229 (NOISE_LEVEL_TO_ADD default 0; unknown names such as NOISE_SEED/BIAS_CORRECTION ignored)""", NEW_MIC_TAIL)

# 4. _setup trace line (all ten SPI records + est)
OLD_SETUP = """and NOISE_SEED='42' (no effect on the kernel calculators, see infotheory.est.kernel)"""
NEW_SETUP = ("""and NOISE_SEED='42'. BIAS_CORRECTION is not a property of any kernel class and is ignored; NOISE_SEED is stored
    by EntropyCalculatorMultiVariateKernel and MutualInfoCalculatorMultiVariateKernel but has no numerical effect because
    NOISE_LEVEL_TO_ADD stays 0, and TransferEntropyCalculatorKernel ignores it (see infotheory.est.kernel)""")
for u in units:
    rep(u, OLD_SETUP, NEW_SETUP)

# 5. delegate_lib provenance
PROV = ('JIDT jar pyspi/lib/jidt/infodynamics.jar (labelled 1.6.1 by pyspi/lib/jidt/version-1.6.1.txt; contents match '
        'post-1.6.1 master a9b6b3e, see infotheory.est.kernel)')
for u in units:
    if u == 'est.kernel':
        continue
    rep(u, 'JIDT infodynamics.jar 1.6.1', PROV)
rep('est.kernel', 'JIDT infodynamics.jar 1.6.1 (pyspi/lib/jidt/infodynamics.jar) via JPype:',
    """JIDT jar pyspi/lib/jidt/infodynamics.jar, labelled 1.6.1 by pyspi/lib/jidt/version-1.6.1.txt but built from
    post-1.6.1 master: all entries are dated 2024-04-21 (unzip -l), the jar contains EntropyCalculatorMultiVariateCommon.class,
    which does not exist at the v1.6.1 tag, and the runtime superclass of EntropyCalculatorMultiVariateKernel is EntropyCalculatorMultiVariateCommon
    with NOISE_SEED stored (probe it_kernel_fix/p2_props.py); this matches master commit a9b6b3e of 2024-04-20 ('Adding
    property to set random seed for noise addition to EntropyMultiVariate estimators'), the same provenance as infotheory.est.ksg1.
    Of the kernel-path sources, EntropyCalculatorMultiVariateKernel.java and MutualInfoMultiVariateCommon.java differ
    from the v1.6.1 tag, while KernelEstimatorMultiVariate, MutualInfoCalculatorMultiVariateKernel, TransferEntropyCalculatorKernel,
    KernelEstimatorTransferEntropy, TransferEntropyCommon and MatrixUtils are byte-identical. Called via JPype 1.7.1:""")

# 6. Version wording in documented fields
rep('je.kernel', 'JIDT v1.5 (§1.4) while the bundled jar and GitBook say v1.6.1.',
    'JIDT v1.5 (§1.4) while the GitBook and the jar label (version-1.6.1.txt) say v1.6.1; the jar contents are a post-1.6.1 master build (a9b6b3e, see infotheory.est.kernel).')
rep('est.kernel', 'says v1.5, jar and GitBook v1.6.1. Otherwise as documented.',
    'says v1.5, the GitBook and the jar label (version-1.6.1.txt) v1.6.1, and the jar contents are post-1.6.1 master a9b6b3e. Otherwise as documented.')

for u, t in texts.items():
    (R / f'infotheory.{u}.yaml').write_text(t)
print('ok')
