# Gaussian plug-in of pyspi's DI target term R = sum_{m=1..5} H(Y^m)/m versus H(Y^5), AR(1) target; isolates the definitional gap from any kernel effect
import numpy as np
def Hg(Z):
    C = np.atleast_2d(np.cov(Z, rowvar=False)); d = C.shape[0]
    return 0.5*np.log2((2*np.pi*np.e)**d*np.linalg.det(C))
def emb(y, m):
    T = len(y); return np.column_stack([y[m-1-k:T-k] for k in range(m)])
rng = np.random.default_rng(7)
for phi in [0.0, 0.5, 0.9]:
    T = 200000; e = rng.standard_normal(T+1000); y = np.zeros_like(e)
    for t in range(1, len(e)): y[t] = phi*y[t-1] + e[t]
    y = y[1000:]; y = (y - y.mean())/y.std(ddof=1)
    R = sum(Hg(emb(y, m))/m for m in range(1, 6)); H5 = Hg(emb(y, 5))
    print('phi=%.1f  R-H(Y^5) plug-in=%.4f  theory=%.4f' % (phi, R-H5, -0.5*(1/2+1/3+1/4+1/5)*np.log2(1-phi**2)))
