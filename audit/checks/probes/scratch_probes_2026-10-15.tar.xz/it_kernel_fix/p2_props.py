import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
import jpype as jp
import pyspi.statistics.infotheory as it
K = jp.JPackage('infodynamics.measures.continuous.kernel')
spis = {'je': it.JointEntropy(estimator='kernel'),
        'mi': it.MutualInfo(estimator='kernel', kernel_width=0.25),
        'tlmi': it.TimeLaggedMutualInfo(estimator='kernel', kernel_width=0.25),
        'te': it.TransferEntropy(estimator='kernel', kernel_width=0.25, k_history=1, l_history=1)}
def g(c, p):
    v = c.getProperty(p); return None if v is None else str(v)
for name, s in spis.items():
    for cname in ['_entropy_calc', '_calc']:
        c = getattr(s, cname, None)
        if c is None: continue
        print(name, cname, c.getClass().getSimpleName(), 'super=', c.getClass().getSuperclass().getSimpleName(),
              {p: g(c, p) for p in ['NOISE_SEED', 'NOISE_LEVEL_TO_ADD', 'BIAS_CORRECTION', 'KERNEL_WIDTH']})
x = np.random.default_rng(0).standard_normal(300); y = 0.5*x + np.random.default_rng(1).standard_normal(300)
J = lambda a: jp.JArray(jp.JDouble, 1)(a)
def H(**props):
    c = K.EntropyCalculatorMultiVariateKernel()
    for k, v in props.items(): c.setProperty(k, v)
    c.initialise(1); c.setObservations(J(x)); return c.computeAverageLocalOfObservations()
def M(**props):
    c = K.MutualInfoCalculatorMultiVariateKernel()
    for k, v in props.items(): c.setProperty(k, v)
    c.initialise(1, 1); c.setObservations(J(x), J(y)); return c.computeAverageLocalOfObservations()
base = H(KERNEL_WIDTH='0.5')
print('H: seed only - base =', H(KERNEL_WIDTH='0.5', NOISE_SEED='42') - base,
      '; level 1e-8 + seed 42 - base =', H(KERNEL_WIDTH='0.5', NOISE_SEED='42', NOISE_LEVEL_TO_ADD='1e-8') - base,
      '; BIAS_CORRECTION true - base =', H(KERNEL_WIDTH='0.5', BIAS_CORRECTION='true') - base)
mb = M(KERNEL_WIDTH='0.25')
print('MI: seed only - base =', M(KERNEL_WIDTH='0.25', NOISE_SEED='42') - mb,
      '; level 1e-8 + seed 42 - base =', M(KERNEL_WIDTH='0.25', NOISE_SEED='42', NOISE_LEVEL_TO_ADD='1e-8') - mb,
      '; BIAS_CORRECTION true - base =', M(KERNEL_WIDTH='0.25', BIAS_CORRECTION='true') - mb)
