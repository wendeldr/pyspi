import sys, pickle
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
import pyspi.statistics.infotheory as it
for s in [it.JointEntropy(estimator='kernel'), it.MutualInfo(estimator='kernel', kernel_width=0.25), it.StochasticInteraction(estimator='kernel')]:
    p = pickle.loads(pickle.dumps(s))
    print(p.identifier, 'pickle round-trip entropy KW', p._entropy_calc.getProperty('KERNEL_WIDTH'), 'calc KW', None if getattr(p, '_calc', None) is None else p._calc.getProperty('KERNEL_WIDTH'))
