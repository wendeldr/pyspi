import sys
from pathlib import Path
R = Path('/media/dan/Data/git/pyspi/audit/records')
P = 'it_kernel_fix/p1_frame_all.py'
# A[0,1] Calculator vs CalculatorFrame (bivariate_gaussian T=256 ; var2_bivariate T=256)
vals = {
 'je.kernel':      ('je_kernel_W-0.5', '3.9822833545', '3.7487119189', '3.9458115241', '3.6838644230', ' (the frame value equals a direct JointEntropy(kernel_width=0.25) call, 3.7487119189)'),
 'ce.kernel':      ('ce_kernel_W-0.5', '1.9366210046', '1.7266038499', '1.9000371826', '1.6579346797', ' (the frame value equals a direct ConditionalEntropy(kernel_width=0.25) call, 1.7266038499)'),
 'cce.kernel':     ('cce_kernel_W-0.5', '3.4050629409', '-1.7929180304', '3.4217337550', '-1.8121804385', '; the frame values are negative because the W-0.25 box volume is 0.5^d < 1'),
 'xme.kernel_k1':  ('xme_kernel_W-0.5_k1', '1.9814677814', '1.7793580942', '1.7098662848', '1.4347407598', ''),
 'xme.kernel_k10': ('xme_kernel_W-0.5_k10', '0.0037640804', '-0.9962359196', '0.0282161172', '-0.9799139641', '; the frame values are negative because the W-0.25 box volume is below 1'),
 'di.kernel':      ('di_kernel_W-0.5', '5.8235130138', '8.6877200525', '5.6887745078', '8.7087942114', ''),
 'si.kernel':      ('si_kernel_W-0.5_k-1', '0.9962347218', '3.2876894572', '1.0032756909', '3.0317800434', ''),
}
TRACE = """  - >-
    pyspi/statistics/infotheory.py:60-82 JIDTBase.__getstate__/__setstate__/__deepcopy__ (copy path; not used by
    Calculator.compute): pickling drops _entropy_calc and _calc (:60-69) and __setstate__ (:71-75) rebuilds _entropy_calc
    with _getcalc, which re-applies _setup (probe it_kernel_fix/p4_pickle.py: KERNEL_WIDTH 0.5 kept after a pickle
    round trip); __deepcopy__ (:77-82) builds type(self)() and then deep-copies every attribute, and copy.deepcopy
    of the JPype proxy returns a new Java object of the same class in its default state without _setup (probe it_kernel_fix/p1_frame_all.py:
    KERNEL_WIDTH 0.25, NOISE_SEED 'NONE'); pyspi/calculator.py:556-562 CalculatorFrame.init_from_list deep-copies
    the base Calculator for every dataset (copy.deepcopy at :559)
"""
ANCHOR = "NOISE_LEVEL_TO_ADD stays 0, and TransferEntropyCalculatorKernel ignores it (see infotheory.est.kernel)\n"
def insert_after(t, anchor, add, u):
    if t.count(anchor) != 1: sys.exit(f'{u}: anchor count {t.count(anchor)}')
    return t.replace(anchor, anchor + add)
def insert_before(t, anchor, add, u):
    if t.count(anchor) != 1: sys.exit(f'{u}: anchor count {t.count(anchor)} for {anchor!r}')
    return t.replace(anchor, add + anchor)
for u, (ident, c1, f1, c2, f2, extra) in vals.items():
    f = R / f'infotheory.{u}.yaml'; t = f.read_text()
    t = insert_after(t, ANCHOR, TRACE, u)
    cand = f"""  - >-
    Candidate (copy path, confirmed by probe): a CalculatorFrame computes {ident} with kernel width 0.25 while the
    identifier still reads W-0.5. JIDTBase.__deepcopy__ (infotheory.py:77-82) copies _entropy_calc with copy.deepcopy,
    which yields an EntropyCalculatorMultiVariateKernel in its default state (JIDT default KERNEL_WIDTH 0.25) without
    re-running _setup, and CalculatorFrame.init_from_list deep-copies the base Calculator (calculator.py:556-562).
    Probe {P}, A[0,1]: bivariate_gaussian T=256 Calculator {c1} vs CalculatorFrame {f1}; var2_bivariate T=256 Calculator
    {c2} vs CalculatorFrame {f2}{extra}. A pickle round trip keeps width 0.5 (__setstate__ re-applies _setup). Not
    in the already-documented list; the kraskov TE records describe the same copy mechanism for TE embedding settings.
"""
    t = insert_before(t, "  proposed_checks:\n", cand, u)
    chk = f"""  - datasets:
    - bivariate_gaussian
    - var2_bivariate
    path: pipeline
    reference: >-
      CalculatorFrame (deepcopy, calculator.py:559) vs Calculator on the same data and config, plus a direct call
      of the same SPI class with kernel_width=0.25 and getProperty('KERNEL_WIDTH') on the copied _entropy_calc
    reference_kind: same-lineage
    criterion: exact
    expected_outcome: >-
      Differs: the CalculatorFrame value equals the W-0.25 value and the copied calculator reads KERNEL_WIDTH 0.25
      (probe A[0,1] bivariate_gaussian {c1} vs {f1}); documents the copy bug
"""
    t = t.rstrip('\n') + '\n' + chk
    f.write_text(t)
# scope notes for the W-0.25 units
for u, ident in [('mi.kernel', 'mi_kernel_W-0.25'), ('tlmi.kernel', 'tlmi_kernel_W-0.25'), ('te.kernel_k-1_kt-1_l-1_lt-1', 'te_kernel_W-0.25_k-1')]:
    f = R / f'infotheory.{u}.yaml'; t = f.read_text()
    cand = f"""  - >-
    Candidate (scope note, copy path): JIDTBase.__deepcopy__ (infotheory.py:77-82) resets the copied JIDT calculators
    to their defaults (see infotheory.est.kernel), but {ident} is unchanged in a CalculatorFrame only because its
    configured width 0.25 equals JIDT's default kernel width. Probe {P}: Calculator and CalculatorFrame A[0,1] and
    A[1,0] identical on bivariate_gaussian and var2_bivariate T=256; the copied calculator reads KERNEL_WIDTH 0.25.
"""
    t = insert_before(t, "  proposed_checks:\n", cand, u)
    f.write_text(t)
print('ok')
