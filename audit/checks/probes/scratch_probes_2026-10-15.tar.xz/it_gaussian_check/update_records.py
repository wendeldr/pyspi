"""Fill the check-stage block of the it_gaussian records (run with the project venv)."""
import json
from pathlib import Path

import yaml

AUDIT = Path("/media/dan/Data/git/pyspi/audit")
REC = AUDIT / "records"
MAN = json.loads((AUDIT / "checks/manifest/it_gaussian.json").read_text())
RES = json.loads((AUDIT / "checks/out/results/it_gaussian.json").read_text())
REF = "audit/checks/refs/it_gaussian.py"
KER = "audit/checks/refs/_kernels_infotheory.py"
PRB = "audit/checks/probes/it_gaussian_probes.py"


class NoAlias(yaml.SafeDumper):
    def ignore_aliases(self, data):
        return True


def rids(unit, pred):
    return [r["run_id"] for r in MAN["runs"] if r["unit_id"] == unit and pred(r["run_id"].split("|")[-1], r)]


def outcome_of(ids):
    p = sum(bool(RES[i].get("pass")) for i in ids)
    return f"{p}/{len(ids)} pass"


def group(unit, pred, reference, outcome):
    ids = rids(unit, pred)
    assert ids, (unit, reference)
    return {"run_ids": ids, "reference": reference, "outcome": f"{outcome_of(ids)}; {outcome}"}


T = lambda *tags: (lambda t, r: t in tags)
STARTS = lambda *p: (lambda t, r: t.startswith(p))

DEGEN = "infotheory.est.gaussian|shared_envelope|256|pipeline|degenerate"
U = {}

# ------------------------------------------------------------------------------------- je
u = "infotheory.je.gaussian"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_joint_entropy (slogdet of the ddof=1 covariance, no JIDT); {REF}:chk_truth_pair (analytic (1+ln 2pi) + 0.5 ln(1-rho^2), Monte Carlo SE from 300 numpy draws); {REF}:chk_equals_d2; {REF}:chk_identity_mi (same-lineage identity je = 2 H1 - mi_gaussian)",
    check_data="bivariate_gaussian T1024 (pipeline) and T4096 pairs (0,1)/(2,3); var2_bivariate T1024; iid_gaussian T256; contaminated T1024; delayed_noise T64; scaled_offset T1024 (kernel and pipeline); shared_envelope T256 (degenerate contract, run under infotheory.est.gaussian)",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12 on every off-diagonal entry; statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD per entry",
    closeness="Numpy closed form: 6/6 exact runs pass, max_abs <= 3.6e-15 (je|var2_bivariate|1024|pipeline|numpy 4.4e-16; je|scaled_offset|1024|kernel|numpy on raw data 3.6e-15). Identity je = 2*1.4189385332 - mi_gaussian: max_abs 4.4e-16 (je|bivariate_gaussian|1024|pipeline|identity-mi). z-scored scaled_offset equals bivariate_gaussian (same draw): 1.3e-15. Analytic at T=4096: rho=0.3 population 2.79072, |pyspi - population| 0.0029 (max_z 0.71); rho=0.8 population 2.32705, 0.0116 (max_z 0.85).",
    verdict="matches",
    score_0_10=9,
    what_changed="Nothing in the formula: plug-in Gaussian joint entropy in nats. Convention: ddof=1 covariance (a ddof=0 estimate would be lower by 0.5*d*ln(N/(N-1)) per entropy, e.g. 1.41698 instead of 1.41894 for one z-scored variable at T=256). Under the default z-scoring the value carries no marginal-scale information and is exactly 2*1.4189385332 - mi_gaussian (affine in mi_gaussian).",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.02 s per pyspi run at T=1024 (1.7 s for the first run, JVM warm-up); references are closed forms plus a 300-draw Monte Carlo (seconds)",
    symmetry_observed="sym: max|A - A.T| = 0.0 on all 6 numpy runs and the identity run (Undirected mirrors the upper triangle)",
    direction_observed="undirected: A[i,j] = A[j,i] = H(x_i, x_j) (pipeline: of the z-scored rows)",
    candidate_resolutions=[
        dict(candidate="je_gaussian is an exact affine transform of mi_gaussian under default z-scoring", outcome="confirmed",
             evidence="infotheory.je.gaussian|bivariate_gaussian|1024|pipeline|identity-mi: pyspi je equals 2*1.4189385332046727 - pyspi mi_gaussian to max_abs 4.4e-16; infotheory.est.gaussian|*|entropy-constant: every univariate entropy is 1.4189385332 (<= 4.4e-16)"),
        dict(candidate="exact collinearity raises NonPositiveDefiniteMatrixException and Calculator blanks the whole je matrix", outcome="confirmed",
             evidence=f"{DEGEN}: je_gaussian raises NonPositiveDefiniteMatrixException on the bit-identical pair (0,2); a real Calculator restricted to je_gaussian + mi_gaussian returns an all-NaN je table and a 'failed' metric report (calculator_je_all_nan = 1, calculator_je_report_failed = 1; pyspi/calculator.py:336-338 at HEAD a1f20c7)"),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy ({KER}:gaussian_joint_entropy)", "max_abs <= 3.6e-15"),
        group(u, T("equals-d2"), f"{REF}:chk_equals_d2", "max_abs 1.3e-15"),
        group(u, T("identity-mi"), f"{REF}:chk_identity_mi (same-lineage)", "max_abs 4.4e-16"),
        group(u, STARTS("truth"), f"{REF}:chk_truth_pair (analytic + Monte Carlo SE)", "max_z 0.71 / 0.85"),
    ],
)

# ------------------------------------------------------------------------------------- ce
u = "infotheory.ce.gaussian"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_conditional_entropy(x_j, x_i) (H(x_i,x_j) - H(x_i), slogdet, ddof=1); {REF}:chk_order (raw scaled_offset: A[i,j]-A[j,i] = ln(sd_j/sd_i)); {REF}:chk_identity_mi (same-lineage ce = H1 - mi_gaussian); {REF}:chk_truth_pair (analytic 0.5 ln(2 pi e (1-rho^2)), Monte Carlo SE)",
    check_data="bivariate_gaussian T1024 and T4096 pairs; var2_bivariate T1024; iid_gaussian T256; contaminated T1024; delayed_noise T64; scaled_offset T1024 kernel (raw, Data normalise=False)",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12; statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD; qualitative order check: antisymmetric part equals ln(sd_j/sd_i) to 1e-10 and the reversed orientation H(x_i|x_j) is rejected",
    closeness="Numpy closed form: 6/6 exact runs pass, max_abs <= 3.6e-15 (ce|scaled_offset|1024|kernel|numpy on raw data 3.6e-15). Conditioning order (ce|scaled_offset|1024|kernel|order): A[0,1] = 2.07866 = H(x1|x0), A[1,0] = -0.23733, A[0,1]-A[1,0] = 2.3159931 = ln(sd_1/sd_0) (error 1.3e-15; ln 10 = 2.3025851); the reversed orientation differs by up to 3.91. Identity ce = 1.4189385332 - mi_gaussian: 3.3e-16 (bivariate_gaussian), 0.0 (var2_bivariate). Analytic T=4096: rho=0.3 population 1.37178, |pyspi - population| 0.0029 (max_z 0.72); rho=0.8 population 0.90811, 0.0116 (max_z 1.01).",
    verdict="matches",
    score_0_10=9,
    what_changed="Formula is H(x_j | x_i) exactly (ddof=1 plug-in, nats). Under the default z-scoring H(x_i) is the same constant 1.4189385332 for every channel, so A[i,j] = A[j,i] = 1.4189385332 - mi_gaussian: the Directed class has no effect on values and the SPI carries the same information as mi_gaussian and je_gaussian. With Data(normalise=False) the matrix is asymmetric by ln(sd_j/sd_i).",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.02 s per pyspi run at T=1024",
    symmetry_observed="sym under the default pipeline: max|A - A.T| <= 2.0e-15 on the 5 z-scored numpy runs (0.0 on var2_bivariate); asym on raw data: max|A - A.T| = 3.91 on scaled_offset kernel",
    direction_observed="A[i,j] = H(x_j | x_i): row i is the conditioning process, column j the process whose uncertainty is measured (raw scaled_offset: A[0,1] = 2.0787 = H(x1|x0), A[1,0] = -0.2373; ce|scaled_offset|1024|kernel|order). On var2_bivariate (z-scored) A[0,1] = A[1,0] = 1.40007, so no direction information survives the default pipeline.",
    candidate_resolutions=[
        dict(candidate="ce_gaussian is exactly symmetric under default z-scoring, so 'directed' carries no information", outcome="confirmed",
             evidence="infotheory.ce.gaussian|*|pipeline|numpy: max|A - A.T| <= 2.0e-15 on 5 datasets; infotheory.ce.gaussian|scaled_offset|1024|kernel|order: asymmetric (3.91) only without normalisation"),
        dict(candidate="ce_gaussian = 1.4189385332 - mi_gaussian exactly under z-scoring (ce, je, mi mutually affine)", outcome="confirmed",
             evidence="infotheory.ce.gaussian|bivariate_gaussian|1024|pipeline|identity-mi (3.3e-16) and infotheory.ce.gaussian|var2_bivariate|1024|pipeline|identity-mi (0.0)"),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy ({KER}:gaussian_conditional_entropy)", "max_abs <= 3.6e-15"),
        group(u, T("order"), f"{REF}:chk_order", "antisymmetry error 1.3e-15; reversed orientation off by 3.91"),
        group(u, T("identity-mi"), f"{REF}:chk_identity_mi (same-lineage)", "max_abs <= 3.3e-16"),
        group(u, STARTS("truth"), f"{REF}:chk_truth_pair (analytic + Monte Carlo SE)", "max_z 0.72 / 1.01"),
    ],
)

# ------------------------------------------------------------------------------------- mi
u = "infotheory.mi.gaussian"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_mi (0.5 ln(det Sx det Sy / det Sxy), slogdet, no JIDT); {REF}:chk_invariance; {REF}:chk_truth_pair (analytic true_mi_nats, Monte Carlo SE); {REF}:chk_null (Monte Carlo of the mean over pairs on iid data, analytic chi-square(1)/(2N)); {REF}:chk_linear_only ({KER}:mi_ksg1 as dependence witness)",
    check_data="bivariate_gaussian T256/T1024 and pairs (0,1)/(2,3) at T256/T1024/T4096; var2_bivariate T1024 (pipeline and kernel); iid_gaussian T256/T1024; contaminated T1024; delayed_noise T64; nonlinear_dependence T1024; trending T1024 (pipeline-detrend); scaled_offset T1024 (kernel)",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12; statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD; null: |mean over pairs - Monte Carlo mean| <= 2 Monte Carlo SD and no negative value",
    closeness="Gaussian MI closed form agrees with JIDT to <= 1e-10 (final verification item): mi|var2_bivariate|1024|pipeline|numpy max_abs 1.6e-16; all 10 exact runs pass with max_abs <= 4.7e-15 (kernel 5.0e-16, pipeline-detrend 2.9e-15, scaled_offset kernel vs MI of the unscaled rows 4.7e-15). Convergence to true_mi_nats (pairs (0,1) rho=0.3, 0.0471553 / (2,3) rho=0.8, 0.5108256): pyspi 0.04721 / 0.56078 at T=256, 0.04112 / 0.50528 at T=1024, 0.05004 / 0.49923 at T=4096; |pyspi - truth| 5.6e-5 / 0.0500, 0.0060 / 0.0055, 0.0029 / 0.0116; all 6 runs within 2 Monte Carlo SD (max_z <= 1.07). Null iid_gaussian: mean over 10 pairs 0.00126 at T=256 (analytic 1/(2N) 0.00195, Monte Carlo 0.00199 +- 0.00088, z -0.83) and 0.00063 at T=1024 (analytic 0.00049, z 0.64); minimum 3.9e-6 (never negative). nonlinear_dependence: pyspi 1.1e-4 / 7.7e-4 nats on the (0,1)/(2,3) pairs while KSG gives 1.61 / 3.25 nats.",
    verdict="matches",
    score_0_10=10,
    what_changed="None: canonical Gaussian MI -0.5 ln(1-r^2) in nats, fp-exact; ddof cancels. Plug-in without bias correction (mean 1/(2N) under independence, as observed); captures only linear dependence (consistent with the 'linear' instance label; the supplement keyword 'nonlinear' describes the MI family, not this estimator).",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.02 s per pyspi run at T=4096",
    symmetry_observed="sym: max|A - A.T| = 0.0 on all 9 numpy runs (lower triangle mirrored)",
    direction_observed="undirected: A[i,j] = A[j,i] = I(x_i; x_j) at zero lag",
    candidate_resolutions=[
        dict(candidate="mi_gaussian is monotone in r^2 and je/ce Gaussian are exact affine functions of it under z-scoring (rank-equivalent)", outcome="confirmed",
             evidence="infotheory.je.gaussian|bivariate_gaussian|1024|pipeline|identity-mi (4.4e-16), infotheory.ce.gaussian|bivariate_gaussian|1024|pipeline|identity-mi (3.3e-16), infotheory.ce.gaussian|var2_bivariate|1024|pipeline|identity-mi (0.0)"),
        dict(candidate="no bias correction: expected value about 1/(2N) under independence", outcome="confirmed",
             evidence="infotheory.mi.gaussian|iid_gaussian|256|pipeline|null and |1024|pipeline|null: mean 0.00126 / 0.00063 vs analytic 0.00195 / 0.00049, consistent with the Monte Carlo distribution (z -0.83 / 0.64). This is the documented plug-in behaviour (README: finite-sample bias is not incorrectness), not a defect."),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy ({KER}:gaussian_mi)", "max_abs <= 2.9e-15"),
        group(u, T("invariance"), f"{REF}:chk_invariance", "max_abs 4.7e-15"),
        group(u, STARTS("truth"), f"{REF}:chk_truth_pair (analytic true_mi_nats + Monte Carlo SE), T 256/1024/4096", "max_z <= 1.07"),
        group(u, T("null"), f"{REF}:chk_null", "z -0.83 (T256), 0.64 (T1024)"),
        group(u, T("linear-only"), f"{REF}:chk_linear_only ({KER}:mi_ksg1)", "Gaussian MI 1.1e-4 / 7.7e-4 vs KSG 1.61 / 3.25 nats"),
    ],
)

# ------------------------------------------------------------------------------------- tlmi
u = "infotheory.tlmi.gaussian"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_tlmi (gaussian_mi(x_i[:-1], x_j[1:])); {REF}:chk_tlmi_truth (analytic 0.5 ln 101 on delayed_noise, Sigma_XY-based lagged correlation on gauss_ar1_pair, Monte Carlo SE); {REF}:chk_direction",
    check_data="var2_bivariate T1024; delayed_noise T1024 and pair (0,1) T4096; gauss_ar1_pair T1024/T4096; iid_gaussian T256",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12; statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD; direction: A[0,1] > A[1,0] for x0 -> x1",
    closeness="Numpy closed form: 4/4 exact runs pass, max_abs <= 5.8e-14. delayed_noise T=4096 (tlmi|delayed_noise|4096|pipeline|truth-p01): population I(x0(t); x1(t+1)) = 0.5 ln 101 = 2.30756 and 0 in reverse, |pyspi - population| <= 0.0158 (max_z 0.96). gauss_ar1_pair T=4096: population 0.12664 (0->1) / 0.17382 (1->0), |pyspi - population| <= 0.0160 (max_z 1.48). Direction: delayed_noise T1024 A[0,1] = 2.2707 vs A[1,0] = 1.6e-5; var2_bivariate A[0,1] = 0.1666 vs A[1,0] = 0.0028.",
    verdict="matches",
    score_0_10=10,
    what_changed="None: lag-one Gaussian MI I(x_i(t); x_j(t+1)) on T-1 aligned samples, fp-exact, converging to the analytic population values.",
    new_finding=False,
    definition_under_review=False,
    check_cost="cheap: <= 0.01 s per pyspi run (0.49 s for the first, JVM warm-up)",
    symmetry_observed="asym: max|A - A.T| = 0.164 (var2_bivariate T1024), 2.27 (delayed_noise T1024), 0.077 (gauss_ar1_pair T1024), 0.0042 (iid_gaussian T256)",
    direction_observed="A[i,j] = I(x_i(t); x_j(t+1)): row i leads by one sample. delayed_noise (x1 = x0 delayed by 1): A[0,1] = 2.2707 vs A[1,0] = 1.6e-5; var2_bivariate (x0 -> x1): A[0,1] = 0.1666 vs A[1,0] = 0.0028 (tlmi|*|1024|pipeline|direction)",
    candidate_resolutions=[
        dict(candidate="documentation is internally inconsistent: supplement 1.4.4 says 'undirected', GitBook says 'directed', the code is Directed and asymmetric", outcome="confirmed",
             evidence="supplement.txt:467-474 ('an undirected measure', keyword 'undirected') vs GitBook information-theory.md:243 ('a directed measure'); asymmetry measured in tlmi|*|numpy (max|A - A.T| up to 2.27). The asymmetry itself is REVIEW M8 ('tlmi is asymmetric by construction'), so this is recorded as an elaboration of an already documented issue, not a new finding."),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy ({KER}:gaussian_tlmi)", "max_abs <= 5.8e-14"),
        group(u, STARTS("truth"), f"{REF}:chk_tlmi_truth (analytic + Monte Carlo SE)", "max_z 0.96 / 1.48"),
        group(u, T("direction"), f"{REF}:chk_direction", "A[0,1] > A[1,0] on both"),
    ],
)

# ------------------------------------------------------------------------------------- gc k1
u = "infotheory.te.gaussian_k-1_kt-1_l-1_lt-1"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_te (covariance/CMI form); {REF}:chk_ols -> {KER}:gaussian_te_ols (0.5 ln(RSS_r/RSS_f), OLS with intercept); {REF}:chk_gc_truth (population TE k=l=1 of the VAR(2) from companion-form Lyapunov Gamma(0), Gamma(1); Monte Carlo SE); {REF}:chk_null; {REF}:chk_direction",
    check_data="var2_bivariate T64/T1024/T4096; gauss_ar1_pair T1024; delayed_noise T1024; iid_gaussian T256/T1024; logistic_maps_chaotic T1024; logistic_maps T1024; scaled_offset T1024 (kernel); trending T1024 (pipeline-detrend)",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12; statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD; null: mean over 20 ordered pairs within 2 Monte Carlo SD of the Monte Carlo mean; direction: A[0,1] > A[1,0]",
    closeness="Covariance form: 9/9 exact runs pass, max_abs <= 5.7e-14 (kernel scaled_offset 1.8e-15, pipeline-detrend trending 1.2e-15). OLS log-ratio form: max_abs 0.0 (var2_bivariate) and 1.7e-14 (delayed_noise); covariance vs OLS form 1.0e-15 / 4.0e-14; pyspi / Geweke F = 0.5 exactly (var2_bivariate F(0->1) = 0.29665, pyspi 0.14833). VAR(2) population at T=4096: TE(0->1) = 0.13258, TE(1->0) = 0.01052 (non-zero because the lag-1 model is misspecified), |pyspi - population| 0.0060 (max_z 0.77). Null iid_gaussian T1024: mean 3.6e-4 (analytic 1/(2(T-1)) = 4.9e-4, Monte Carlo 5.0e-4 +- 1.6e-4, z -0.92), minimum 1.4e-8.",
    verdict="variant",
    score_0_10=8,
    what_changed="Returns Gaussian transfer entropy = F/2, half of the Geweke log residual-variance ratio F that the supplement names ('the log-ratio of residual variance for the two models'); pyspi/F = 0.5 exactly. A constant factor, so rankings are unchanged. Otherwise canonical (Barnett, Barrett & Seth 2009) with one target and one source lag.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.03 s per pyspi run at T=1024",
    symmetry_observed="asym: max|A - A.T| = 0.136 (var2_bivariate T1024), 2.27 (delayed_noise T1024), 0.050 (gauss_ar1_pair), 0.0038 (iid_gaussian T256)",
    direction_observed="A[i,j] = TE(x_i -> x_j) (i source, j target). var2_bivariate T1024: A[0,1] = 0.1483 vs A[1,0] = 0.0127; delayed_noise T1024: A[0,1] = 2.2704 vs A[1,0] = 1.3e-5 (gc|*|1024|pipeline|direction)",
    candidate_resolutions=[
        dict(candidate="gc_gaussian returns TE = F/2, not the documented log-ratio F", outcome="confirmed",
             evidence="infotheory.te.gaussian_k-1_kt-1_l-1_lt-1|var2_bivariate|1024|pipeline|ols and |delayed_noise|1024|pipeline|ols: pyspi equals 0.5 ln(RSS_r/RSS_f) to <= 1.7e-14, ref_pyspi_over_F = 0.5"),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy ({KER}:gaussian_te)", "max_abs <= 5.7e-14"),
        group(u, T("ols"), f"{REF}:chk_ols ({KER}:gaussian_te_ols)", "max_abs <= 1.7e-14; pyspi/F = 0.5"),
        group(u, T("truth"), f"{REF}:chk_gc_truth (analytic + Monte Carlo SE)", "max_z 0.77"),
        group(u, T("null"), f"{REF}:chk_null", "z -0.92"),
        group(u, T("direction"), f"{REF}:chk_direction", "A[0,1] > A[1,0] on both"),
    ],
)

# ------------------------------------------------------------------------------------- gc auto
u = "infotheory.te.gaussian_auto-MAX_CORR_AIS_kmax-10_taumax-2"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:ais_select (from-scratch MAX_CORR_AIS: Gaussian AIS minus k/(2N) with the candidate's own N, k <= 10, tau <= 2, tau loop skipped at k = 1, strict '>') + {KER}:gaussian_te; {PRB}:te_auto_params (JIDT getProperty k_HISTORY/k_TAU/l_HISTORY/l_TAU after each bivariate call); {REF}:chk_direction",
    check_data="var2_bivariate T64/T256/T1024/T4096; iid_gaussian T256/T1024/T4096; delayed_noise T256/T1024; gauss_ar1_pair T1024; logistic_maps_chaotic T1024",
    agreement_criterion="exact: values rtol 1e-10, atol 1e-12; selected embeddings bitwise equal (rtol = atol = 0); direction: A[0,1] > A[1,0]",
    closeness="Values: 5/5 exact runs pass, max_abs <= 5.3e-14. Selected (k, k_tau, l, l_tau) identical for every ordered pair on 9/9 probe runs (max_abs 0). Selected orders (ref_sel_k_x*): var2_bivariate x0 (a true AR(2)) k = 3, 10, 9, 8 at T = 64, 256, 1024, 4096 and x1 k = 4, 5, 2, 5; iid_gaussian white channels at T=4096 k = 6, 1, 7, 8, 10 (tau 2 for x4), at T=1024 k = 8, 1, 5, 6, 10; delayed_noise T256 white x0 k = 7, its delayed copies k = 10, 10, 7. Direction: var2_bivariate A[0,1] = 0.1631 vs A[1,0] = 0.0011; delayed_noise T1024 A[0,1] = 2.2669, A[0,2] = 2.2821, A[0,3] = 2.2957 vs reverse <= 0.0032.",
    verdict="variant",
    score_0_10=7,
    what_changed="Value is Gaussian TE = F/2 (as the fixed-lag unit) with JIDT-specific embeddings: target and source orders are each chosen from that process's own penalised AIS (k/(2N) penalty, N per candidate), searched again for every ordered pair. The selection is reproduced exactly but is unstable: over-long orders (k = 7-10) for white noise and k = 3-10 for a true AR(2) across T. It matches the supplement's MAX_CORR_AIS description but not the documented log-ratio F, and differs from a Geweke GC with an information-criterion model order.",
    new_finding=True,
    definition_under_review=False,
    check_cost="moderate: 11.1 s for the P=5, T=4096 probe (20 pairs x 2 searches x 19 Gaussian MI fits); 0.2-3 s per run at T <= 1024; 24 s for the unit",
    symmetry_observed="asym: max|A - A.T| = 0.162 (var2_bivariate T1024), 0.203 (T64), 2.28 (delayed_noise T256), 0.056 (gauss_ar1_pair), 0.251 (logistic_maps_chaotic)",
    direction_observed="A[i,j] = TE(x_i -> x_j) with per-pair embeddings. var2_bivariate T1024: A[0,1] = 0.1631 vs A[1,0] = 0.0011. delayed_noise T1024: A[0,k] = 2.267, 2.282, 2.296 for k = 1, 2, 3 vs A[k,0] <= 0.0032; the large source order chosen for white x0 reaches the lag-3 and lag-5 couplings that fixed k=l=1 misses.",
    candidate_resolutions=[
        dict(candidate="value is Gaussian TE = Geweke F/2, not the documented log-ratio F", outcome="confirmed",
             evidence="infotheory.te.gaussian_auto-MAX_CORR_AIS_kmax-10_taumax-2|*|numpy reproduce pyspi with the covariance TE (= 0.5 ln(RSS_r/RSS_f), cov vs OLS 1e-15 in infotheory.te.gaussian_k-1_kt-1_l-1_lt-1|var2_bivariate|1024|pipeline|ols)"),
        dict(candidate="MAX_CORR_AIS selection is unstable (nearly flat penalised AIS curves)", outcome="confirmed",
             evidence="infotheory.te.gaussian_auto-MAX_CORR_AIS_kmax-10_taumax-2|var2_bivariate|{64,256,1024,4096}|pipeline|params (x0 k = 3, 10, 9, 8) and |iid_gaussian|{256,1024,4096}|pipeline|params (white channels k from 1 to 10, tau 1 or 2)"),
        dict(candidate="target/source AIS searches are recomputed in every bivariate call although P searches suffice (value-neutral efficiency)", outcome="confirmed",
             evidence="params runs: the JIDT selection for every ordered pair equals a per-process selection computed once (refs/it_gaussian.py:chk_params), so caching per process is bit-identical; the search runs inside TransferEntropyCalculatorViaCondMutualInfo.preFinaliseAddObservations (a9b6b3e :701-850) on every setObservations"),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy (ais_select + {KER}:gaussian_te)", "max_abs <= 5.3e-14"),
        group(u, T("params"), f"{REF}:chk_params vs {PRB}:te_auto_params", "selections bitwise equal"),
        group(u, T("direction"), f"{REF}:chk_direction", "A[0,1] > A[1,0] on both"),
    ],
)

# ------------------------------------------------------------------------------------- te symbolic
u = "infotheory.te.symbolic"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_te(k=1 or 10, l=1); {REF}:chk_identity_gc1 (same-lineage, bitwise); {REF}:ste (from-scratch Staniek & Lehnertz 2008 symbolic TE, m=3) with {PRB}:te_symbolic_monotone; {PRB}:instance_labels",
    check_data="var2_bivariate T64/T1024; logistic_maps_chaotic T1024; delayed_noise T1024; anm T1024",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12 against Gaussian TE; identity with gc_gaussian_k-1 at rtol = atol = 0; qualitative: STE invariant under exp(x) while pyspi changes",
    closeness="te_symbolic_k-1 equals Gaussian TE (k=l=1) to max_abs <= 5.7e-14 (3 runs) and is bitwise equal to gc_gaussian_k-1_kt-1_l-1_lt-1 (2 runs, max_abs 0.0); te_symbolic_k-10 equals Gaussian TE with 10 target lags and 1 source lag to <= 8.9e-14 (3 runs; var2_bivariate A[0,1] = 0.138939). Monotone-transform test: STE changes by 0.0 under exp(x), pyspi te_symbolic changes by up to 185% (anm) and 29% (logistic_maps_chaotic). logistic_maps_chaotic T1024: STE(0->1) = 0.0942, STE(1->0) = 0.0014 vs pyspi 0.0062 / 8.6e-5.",
    verdict="wrong",
    score_0_10=1,
    what_changed="No symbolisation happens: estimator='symbolic' falls through to JIDT TransferEntropyCalculatorGaussian, so the values are linear-Gaussian TE (= F/2) with k = 1 or 10 target lags, not Staniek-Lehnertz symbolic TE. Already documented as tests/README.md bug 1; this check quantifies it.",
    new_finding=False,
    definition_under_review=False,
    check_cost="cheap: <= 0.9 s per pyspi run at T=1024 (k=10); the from-scratch STE is milliseconds",
    symmetry_observed="asym: max|A - A.T| = 0.136 (k-1, var2_bivariate T1024), 0.139 (k-10, var2_bivariate), 2.27 (delayed_noise k-1 and k-10), 0.0061 (k-1, logistic_maps_chaotic), 0.127 (k-10, logistic_maps_chaotic)",
    direction_observed="A[i,j] = Gaussian TE(x_i -> x_j), as gc_gaussian. var2_bivariate T1024: k-1 A[0,1] = 0.1483 vs A[1,0] = 0.0127; k-10 A[0,1] = 0.1389 vs A[1,0] = 1.5e-6; delayed_noise k-10 A[0,1] = 2.2752 vs A[1,0] = 0.0015",
    candidate_resolutions=[
        dict(candidate="instance labels carry 'symbolic' and omit 'linear', so label-based grouping misclassifies a linear Gaussian measure", outcome="confirmed",
             evidence="infotheory.te.symbolic|var2_bivariate|64|pipeline|k1-labels: te_symbolic_k-1 and k-10 labels have symbolic=1, linear=0, while gc_gaussian_k-1 has linear=1 (infotheory.py:45-52 returns before the 'linear' label). A metadata consequence of the symbolic branch of tests/README.md bug 1, so new_finding stays false."),
    ],
    checks_run=[
        group(u, T("k1-numpy", "k10-numpy"), f"{REF}:chk_numpy ({KER}:gaussian_te k=1 / k=10)", "max_abs <= 8.9e-14"),
        group(u, T("k1-identity-gc1"), f"{REF}:chk_identity_gc1 (same-lineage)", "bitwise equal"),
        group(u, T("k1-monotone"), f"{REF}:chk_monotone ({REF}:ste)", "STE invariant, pyspi not"),
        group(u, T("k1-labels"), f"{REF}:chk_labels ({PRB}:instance_labels)", "symbolic=1, linear=0"),
    ],
)

# ------------------------------------------------------------------------------------- xme k1
u = "infotheory.xme.gaussian_k1"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_xme(k=1) (H(y_t, x_{{t-1}}) - H(x_{{t-1}}), slogdet); {REF}:chk_xme_truth (analytic delayed_noise conditional entropies, Monte Carlo SE); {REF}:chk_k2_numpy and chk_k2_equals_k1_shifted with {PRB}:xme_k2; {REF}:chk_shift_numpy / chk_shift_pattern with {PRB}:xme_shift_stack",
    check_data="var2_bivariate T1024; delayed_noise T1024 and pairs (0,1)/(0,3) at T4096; gauss_ar1_pair T1024; iid_gaussian T256 and T4096 (constructed shift data [u, u(t-9)+0.1v1, u(t-10)+0.1v2])",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12; statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD; qualitative pattern on the shift data",
    closeness="Numpy: 4/4 exact runs pass, max_abs <= 5.5e-14. delayed_noise T=4096: A[0,1] population H1 + 0.5 ln(1 - 1/1.01) = -0.88862, |pyspi - population| 0.0159 (max_z 0.97); pair (0,3) (lag 5, not used) population 1.41894, 6.1e-5 (max_z 0.54). history_length=2 equals history_length=1 on samples t = 2..T-1 to 6.7e-16 (var2_bivariate) and 3.1e-14 (delayed_noise); var2_bivariate 0->1: k=1 1.25161, k=2 1.25208 (max difference 4.7e-4, one dropped sample). Shift data: u -> u(t-9) 1.4179, u -> u(t-10) 1.4186 (both approx H1 = 1.4189: only lag 1 is used).",
    verdict="related-quantity",
    score_0_10=5,
    what_changed="No documented definition exists; the code computes H(x_j(t) | x_i(t-1)) under the Gaussian model, without conditioning on the target's own past, and is unrelated to cross mapping. Computed exactly as the code states. history_length=1 and =2 use the same lag set {1}.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.45 s per pyspi run (first run includes JVM warm-up), typically 0.01 s",
    symmetry_observed="asym: max|A - A.T| = 0.164 (var2_bivariate T1024), 2.27 (delayed_noise T1024), 0.078 (gauss_ar1_pair), 0.0069 (iid_gaussian T256)",
    direction_observed="A[i,j] = H(x_j(t) | x_i(t-1)): row i is the lagged source, column j the target; lower = more predictable. delayed_noise T1024: A[0,1] = -0.851 vs A[1,0] = 1.418; var2_bivariate: A[0,1] = 1.2516 vs A[1,0] = 1.4158",
    candidate_resolutions=[
        dict(candidate="documentation gap: no definition, keywords or reference for xme", outcome="confirmed",
             evidence="supplement.txt section 1.4 (lines 405-565) and GitBook information-theory.md have no xme entry; only GitBook table-of-spis.md:73 lists 'Cross-Map Entropy' (documentation reading)"),
        dict(candidate="range(2, k) makes history_length=1 and =2 use the same lag set, differing by one sample", outcome="confirmed",
             evidence="infotheory.xme.gaussian_k1|var2_bivariate|1024|pipeline|k2-equals-k1-shifted (6.7e-16) and |delayed_noise|1024|pipeline|k2-equals-k1-shifted (3.1e-14); infotheory.xme.gaussian_k1|var2_bivariate|1024|pipeline|k2-numpy (k1 1.25161 vs k2 1.25208)"),
        dict(candidate="the target's own past is not conditioned on, so A[i,j] mixes target autocorrelation and common drive and is not TE-like", outcome="confirmed",
             evidence="infotheory.xme.gaussian_k1|*|numpy: the reference with source lags only and no target past reproduces pyspi to <= 5.5e-14; delayed_noise truth runs match the population values of H(x_j(t) | x_i(t-1)) (max_z <= 0.97)"),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy ({KER}:gaussian_xme k=1)", "max_abs <= 5.5e-14"),
        group(u, STARTS("truth"), f"{REF}:chk_xme_truth (analytic + Monte Carlo SE)", "max_z 0.97 / 0.54"),
        group(u, STARTS("k2"), f"{REF}:chk_k2_numpy / chk_k2_equals_k1_shifted ({PRB}:xme_k2)", "max_abs <= 3.1e-14"),
        group(u, STARTS("shift"), f"{REF}:chk_shift_numpy / chk_shift_pattern ({PRB}:xme_shift_stack)", "max_abs 1.7e-13; both shifts approx H1"),
        group(u, T("direction"), f"{REF}:chk_direction", "A[0,1] < A[1,0]"),
    ],
)

# ------------------------------------------------------------------------------------- xme k10
u = "infotheory.xme.gaussian_k10"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_xme(k=10) (source lags 1..9); {REF}:chk_xme_truth (analytic, Monte Carlo SE); {REF}:chk_shift_numpy / chk_shift_pattern with {PRB}:xme_shift_stack; {REF}:chk_degenerate (shared_envelope, under infotheory.est.gaussian)",
    check_data="var2_bivariate T1024; delayed_noise T1024 and pairs (0,1)/(0,3) at T4096; gauss_ar1_pair T1024; iid_gaussian T256 and T4096 (constructed shift data); shared_envelope T256",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12; statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD; qualitative pattern on the shift data",
    closeness="Numpy with lags 1..9: 4/4 exact runs pass, max_abs <= 8.5e-14 (shift data 1.7e-13). delayed_noise T=4096: A[0,1] (lag 1) and A[0,3] (lag 5) population -0.88862, |pyspi - population| 0.0156 (max_z 1.09) and 0.0226 (max_z 1.56). Shift data (xme|iid_gaussian|4096|pipeline|shift-pattern): u -> u(t-9) = -0.8957 (analytic -0.8886), u -> u(t-10) = 1.4146 (approx H1 = 1.4189): a coupling at lag 10 is invisible to history_length=10.",
    verdict="related-quantity",
    score_0_10=4,
    what_changed="No documented definition; the code computes H(x_j(t) | x_i(t-1..t-9)) (Gaussian, no target past). history_length=10 uses 9 source lags because the loop is range(2, k); the identifier's history length therefore does not describe the lag set. On noise-free narrowband sources the 9-lag covariance is singular and the SPI raises, blanking the matrix.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.31 s per pyspi run at T=4096",
    symmetry_observed="asym: max|A - A.T| = 0.174 (var2_bivariate T1024), 2.30 (delayed_noise T1024), 0.098 (gauss_ar1_pair), 0.057 (iid_gaussian T256)",
    direction_observed="A[i,j] = H(x_j(t) | x_i(t-1..t-9)): row i = lagged source, column j = target. delayed_noise T1024: A[0,1] = -0.857, A[0,2] = -0.863, A[0,3] = -0.882 (lags 1, 3, 5 all inside 1..9), A[1,2] = -0.530 (lag 2 between copies) vs A[k,0] approx 1.417",
    candidate_resolutions=[
        dict(candidate="history_length=10 uses source lags 1..9, not 1..10; a lag-10 coupling is invisible", outcome="confirmed",
             evidence="infotheory.xme.gaussian_k10|iid_gaussian|4096|pipeline|shift-pattern: u -> u(t-9) -0.8957, u -> u(t-10) 1.4146; infotheory.xme.gaussian_k10|*|numpy reproduce pyspi with lags 1..9 (<= 8.5e-14)"),
        dict(candidate="documentation gap: no definition, keywords or reference", outcome="confirmed",
             evidence="supplement.txt section 1.4 (lines 405-565) and GitBook information-theory.md have no xme entry; only GitBook table-of-spis.md:73 (documentation reading)"),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy ({KER}:gaussian_xme k=10)", "max_abs <= 8.5e-14"),
        group(u, STARTS("truth"), f"{REF}:chk_xme_truth (analytic + Monte Carlo SE)", "max_z 1.09 / 1.56"),
        group(u, STARTS("shift"), f"{REF}:chk_shift_numpy / chk_shift_pattern ({PRB}:xme_shift_stack)", "max_abs 1.7e-13; lag 9 seen, lag 10 not"),
        group(u, T("direction"), f"{REF}:chk_direction", "A[0,1] < A[1,0]"),
        {"run_ids": [DEGEN], "reference": f"{REF}:chk_degenerate ({PRB}:degenerate_contract)",
         "outcome": "pass; xme_gaussian_k10 raises NonPositiveDefiniteMatrixException for every narrowband source row (0, 1, 2), independent of the duplicate pair; numpy Cholesky of the same 9-lag covariance also fails (ref_lag9_cov_row0_pd = 0)"},
    ],
)

# ------------------------------------------------------------------------------------- cce
u = "infotheory.cce.gaussian"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_cce(n=5) (sum_m H(y_t | y lags 1..m-1, x lags 0..m-1), sliding-window samples); {REF}:chk_truth_pair (analytic 5 (H1 + 0.5 ln(1-rho^2))); {REF}:chk_cce_truth (population from Gamma(h) = A^h Sigma_X, Monte Carlo SE); {REF}:chk_n10 with {PRB}:cce_n10; {REF}:chk_configured_n with {PRB}:configured_history",
    check_data="var2_bivariate T64/T1024; delayed_noise T256/T1024; gauss_ar1_pair T1024/T4096; iid_gaussian T256; bivariate_gaussian T1024 and pairs at T4096",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12; statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD; direction: A[0,1] < A[1,0] for x0 -> x1",
    closeness="Numpy: 5/5 exact runs pass, max_abs <= 2.3e-14; n = 10 probe vs numpy n = 10: max_abs 0.0. Analytic T=4096: white pairs population 6.85892 (rho=0.3) / 4.54056 (rho=0.8), |pyspi - population| 0.0183 (max_z 0.57) / 0.0555 (max_z 0.99); gauss_ar1_pair population 5.81321 (0->1) / 5.56278 (1->0), 0.147 (max_z 1.75). Configured n = 5 for cce_gaussian and di_gaussian (documented 10). var2_bivariate T1024: n = 5 gives 6.1247 / 6.6309, n = 10 gives 11.9494 / 13.1081. iid_gaussian T256 values 6.97-7.06 (5 H1 = 7.0947).",
    verdict="variant",
    score_0_10=7,
    what_changed="Kramer's causally conditioned entropy H(Y^5 || X^5) computed exactly (stationary sliding-window terms, present x included in each term, nats), but with n = 5 terms where the supplement and GitBook document a history length of 10; the n = 10 value is about twice as large (11.95 vs 6.12 on var2_bivariate 0->1). The output is a 5-term block sum, not a per-sample entropy.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.66 s per pyspi run (P=5, T=256; 10 Gaussian entropies per ordered pair)",
    symmetry_observed="asym: max|A - A.T| = 0.506 (var2_bivariate T1024), 9.01 (delayed_noise T256), 0.204 (gauss_ar1_pair), 0.0054 (bivariate_gaussian white pairs), 0.079 (iid_gaussian)",
    direction_observed="A[i,j] = H(x_j^5 || x_i^5): column j = target whose uncertainty is measured, row i = causally conditioning source. var2_bivariate T1024: A[0,1] = 6.125 < A[1,0] = 6.631; delayed_noise T1024: A[0,1] = -1.997 < A[1,0] = 7.083",
    candidate_resolutions=[
        dict(candidate="CausalEntropy uses n = 5 while the supplement and GitBook say 10", outcome="confirmed",
             evidence="infotheory.cce.gaussian|var2_bivariate|64|pipeline|configured-n (cce_n = 5, di_n = 5); infotheory.cce.gaussian|var2_bivariate|1024|pipeline|n10 (n = 10: 11.949 / 13.108 vs n = 5: 6.125 / 6.631)"),
        dict(candidate="every term conditions on the present x(t), matching Kramer's X^n but not the supplement's 'past of x'", outcome="confirmed",
             evidence="infotheory.cce.gaussian|*|numpy: the reference with x lags 0..m-1 ({KER}:cce_embedding) reproduces pyspi to <= 2.3e-14".replace("{KER}", KER)),
        dict(candidate="the value is a 5-term block sum, not a per-sample conditional entropy", outcome="confirmed",
             evidence="infotheory.cce.gaussian|bivariate_gaussian|4096|pipeline|truth-p01/p23 match 5 (H1 + 0.5 ln(1-rho^2)) = 6.859 / 4.541; iid_gaussian T256 values 6.97-7.06 vs 5 H1 = 7.09"),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy ({KER}:gaussian_cce n=5)", "max_abs <= 2.3e-14"),
        group(u, STARTS("truth"), f"{REF}:chk_truth_pair / chk_cce_truth (analytic + Monte Carlo SE)", "max_z <= 1.75"),
        group(u, T("direction"), f"{REF}:chk_direction", "A[0,1] < A[1,0] on both"),
        group(u, T("n10"), f"{REF}:chk_n10 ({PRB}:cce_n10)", "max_abs 0.0"),
        group(u, T("configured-n"), f"{REF}:chk_configured_n ({PRB}:configured_history)", "n = 5"),
    ],
)

# ------------------------------------------------------------------------------------- di
u = "infotheory.di.gaussian"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_di(form='pyspi') (sum_m H(Y^m)/m - CCE_5); {REF}:chk_massey ({KER}:gaussian_di(form='massey'), Massey 1990 eq. 6) and chk_massey_identity ({KER}:di_block_term); {REF}:chk_truth_pair; {REF}:chk_indep_numpy / chk_indep_truth with {PRB}:di_independent_pair (analytic block-entropy excess of the AR(2) target, Monte Carlo SE); {REF}:chk_n10 with {PRB}:di_n10",
    check_data="var2_bivariate T1024/T4096; gauss_ar1_pair T1024; delayed_noise T256/T1024; iid_gaussian T256; bivariate_gaussian T1024 and pairs at T4096; constructed independent pair [iid_gaussian row 0, var2_bivariate row 0] at T4096",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12 against the code form; tolerance rtol 1e-6, atol 1e-8 against Massey's form (expected to fail: it quantifies the deviation); statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD",
    closeness="Code form: 7/7 exact runs pass, max_abs <= 2.3e-14 (incl. n = 10 probe 1.8e-15 and independent pair 8.9e-16). Massey's directed information on var2_bivariate T1024 (di|var2_bivariate|1024|pipeline|massey, fails by design): 0.64825 (0->1) / 0.03690 (1->0) vs pyspi 0.77460 / 0.19589, max_abs 0.159; pyspi - Massey = block term B(target) (0.12635 for target x1, 0.15899 for target x0) to 8.9e-16. Independent white source -> AR(2) target (T=4096): pyspi A[0,1] = 0.1742 vs population excess B = 0.17660 (max_z 1.72), Massey form 0.0017; reverse -8.8e-5 (population 0). White pairs at T=4096: population 5 MI = 0.23578 / 2.55413, |pyspi - population| 0.0153 / 0.0565 (max_z <= 0.95). n = 10: 1.6751 / 0.3133 vs n = 5: 0.7746 / 0.1959.",
    verdict="related-quantity",
    score_0_10=4,
    what_changed="First term is sum_{m=1..5} H(Y^m)/m (block entropy per symbol), not H(Y^5) = sum_m H(Y_m | Y^{m-1}); the value equals Massey's DI_5 plus B(target) = sum_m H(Y^m)/m - H(Y^5) >= 0, which depends only on the target's autocorrelation. An independent source therefore gets positive DI into any autocorrelated target (0.174 nats for the var2_bivariate AR(2) row). Also n = 5 instead of the documented 10.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.77 s per pyspi run (P=5, T=256)",
    symmetry_observed="asym: max|A - A.T| = 0.579 (var2_bivariate T1024), 9.01 (delayed_noise T256), 0.208 (gauss_ar1_pair), 0.0117 (bivariate_gaussian), 0.062 (iid_gaussian)",
    direction_observed="A[i,j] = DI(x_i -> x_j) as pyspi defines it (block term of the target j minus cce(i -> j)). var2_bivariate T1024: A[0,1] = 0.775 > A[1,0] = 0.196; delayed_noise T1024: A[0,1] = 9.093 > A[1,0] = 0.012. The reverse entry on var2_bivariate is mostly the target block term (0.159 of 0.196).",
    candidate_resolutions=[
        dict(candidate="_compute_entropy_rates sums block entropies divided by block length instead of H(Y^n)", outcome="confirmed",
             evidence="infotheory.di.gaussian|var2_bivariate|1024|pipeline|massey (pyspi 0.7746 vs Massey 0.6483, max_abs 0.159) and |massey-identity (pyspi - Massey = B to 8.9e-16)"),
        dict(candidate="spurious directed information from an independent source into an autocorrelated target", outcome="confirmed",
             evidence="infotheory.di.gaussian|var2_bivariate|4096|pipeline|indep-truth: pyspi 0.1742 vs analytic excess 0.1766 (max_z 1.72), Massey form 0.0017 (|indep-numpy)"),
        dict(candidate="n = 5 vs documented 10", outcome="confirmed",
             evidence="infotheory.cce.gaussian|var2_bivariate|64|pipeline|configured-n (di_n = 5); infotheory.di.gaussian|var2_bivariate|1024|pipeline|n10 (1.675 vs 0.775)"),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy ({KER}:gaussian_di form='pyspi')", "max_abs <= 2.3e-14"),
        group(u, T("massey"), f"{REF}:chk_massey ({KER}:gaussian_di form='massey')", "fails by design, max_abs 0.159"),
        group(u, T("massey-identity"), f"{REF}:chk_massey_identity", "identity to 8.9e-16"),
        group(u, STARTS("truth"), f"{REF}:chk_truth_pair (analytic + Monte Carlo SE)", "max_z <= 0.95"),
        group(u, STARTS("indep"), f"{REF}:chk_indep_numpy / chk_indep_truth ({PRB}:di_independent_pair)", "exact 8.9e-16; max_z 1.72"),
        group(u, T("direction"), f"{REF}:chk_direction", "A[0,1] > A[1,0] on both"),
        group(u, T("n10"), f"{REF}:chk_n10 ({PRB}:di_n10)", "max_abs 1.8e-15"),
    ],
)

# ------------------------------------------------------------------------------------- si
u = "infotheory.si.gaussian"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_numpy -> {KER}:gaussian_si (H(x1|x0) + H(y1|y0) - H(xy1|xy0)); {REF}:chk_si_truth (analytic 0.5 ln(prod_v var(x_v(t+1)|x_v(t)) / det Sigma_E), Monte Carlo SE); {REF}:chk_truth_pair (white pairs: SI = contemporaneous MI); {REF}:chk_null",
    check_data="var2_bivariate T1024; gauss_ar1_pair T1024/T4096; delayed_noise T256; iid_gaussian T256/T1024; bivariate_gaussian pairs T4096; shared_envelope T256 (degenerate, under infotheory.est.gaussian)",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12; statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD; null: mean over 10 pairs within 2 Monte Carlo SD",
    closeness="Numpy: 4/4 exact runs pass, max_abs <= 8.9e-16. gauss_ar1_pair T=4096: population 0.09992, |pyspi - population| 0.0021 (max_z 0.45). White pairs T=4096: SI equals the contemporaneous MI 0.04716 / 0.51083 within 0.0029 / 0.0118 (max_z 0.50 / 0.98). Null iid_gaussian T1024: mean 0.00132 vs analytic chi-square(3)/(2N) = 0.00147 (Monte Carlo 0.00145 +- 0.00038, z -0.35), minimum 1.8e-4.",
    verdict="matches",
    score_0_10=10,
    what_changed="None: Ay's stochastic interaction with one-step Markov kernels under the Gaussian model, fp-exact (ddof cancels) and converging to the analytic value. The code returns individual minus joint conditional entropies (the non-negative orientation); the supplement prose names the terms in the opposite order.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.41 s per pyspi run (P=5, T=1024)",
    symmetry_observed="sym: max|A - A.T| = 0.0 on all 4 numpy runs (lower triangle mirrored)",
    direction_observed="undirected: A[i,j] = A[j,i] = SI(x_i, x_j)",
    candidate_resolutions=[
        dict(candidate="exactly redundant channels make the joint conditional covariance singular; JIDT raises and Calculator blanks the si matrix", outcome="confirmed",
             evidence=f"{DEGEN}: si_gaussian_k-1 raises NonPositiveDefiniteMatrixException (raised_si = 1); Calculator turns a raising SPI into an all-NaN table (calculator_je_all_nan = 1 for the same mechanism; pyspi/calculator.py:336-338)"),
        dict(candidate="SI includes contemporaneous innovation correlation, so it is non-zero for independent dynamics with correlated innovations", outcome="confirmed",
             evidence="infotheory.si.gaussian|bivariate_gaussian|4096|pipeline|truth-p01/p23: for serially white pairs SI equals the contemporaneous MI (0.0472 / 0.5108). This follows Ay's definition; it is a documentation point, not a deviation."),
    ],
    checks_run=[
        group(u, T("numpy"), f"{REF}:chk_numpy ({KER}:gaussian_si)", "max_abs <= 8.9e-16"),
        group(u, STARTS("truth"), f"{REF}:chk_si_truth / chk_truth_pair (analytic + Monte Carlo SE)", "max_z <= 0.98"),
        group(u, T("null"), f"{REF}:chk_null", "z -0.35"),
        {"run_ids": [DEGEN], "reference": f"{REF}:chk_degenerate ({PRB}:degenerate_contract)", "outcome": "pass; si raises on the duplicate pair"},
    ],
)

# ------------------------------------------------------------------------------------- est
u = "infotheory.est.gaussian"
U[u] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_direct_jidt -> {KER}:gaussian_joint_entropy / gaussian_mi / gaussian_cmi on the raw lag matrix, driving pyspi's own JIDT calculators through {PRB}:est_direct_jidt; {REF}:chk_entropy_constant (analytic 0.5(1+ln 2pi)); {REF}:chk_normalise; {REF}:chk_jar_provenance; {REF}:chk_degenerate (numpy Cholesky of the same covariances)",
    check_data="var2_bivariate T64/T1024; sparse_precision T1024; iid_gaussian T256; bivariate_gaussian T64; shared_envelope T256",
    agreement_criterion="exact: rtol 1e-10, atol 1e-12 on every JIDT call; qualitative contract checks for NORMALISE, provenance and degenerate inputs",
    closeness="Direct JIDT calls: 72 calls (3 runs x 24 tasks: entropies of dimension 1-10, MI up to 1x6 and 2x2, CMI with up to 5 conditioning dimensions) agree with the numpy closed forms to max_abs <= 5.5e-15 (est|iid_gaussian|256|kernel|direct-jidt 5.5e-15, est|var2_bivariate|1024|kernel|direct-jidt 3.7e-15, est|sparse_precision|1024|kernel|direct-jidt 4.4e-15); a ddof=0 covariance would differ by up to 0.0199 nats (T=256). Cached univariate entropies after z-scoring are 1.4189385332046727 to <= 4.4e-16 (3 runs). NORMALISE: entropy calculator 'true', MI and TE 'false'; H(10 x) - H(x) = 2.302585092994045 = ln 10 (no normalisation applied).",
    verdict="matches",
    score_0_10=9,
    what_changed="Canonical Gaussian entropy/MI/CMI from sample covariances in nats. Conventions: ddof=1 covariance (affects entropies, cancels in MI/CMI/TE), no bias correction, input z-scored by pyspi with ddof=1, so every univariate entropy is the constant 0.5(1+ln 2pi).",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.05 s per direct-JIDT probe; 3.9 s for the degenerate-contract probe (13 SPIs plus a real Calculator)",
    symmetry_observed="n/a (estimator layer); the symmetric SPIs built on it (je, mi, si) are exactly symmetric, ce is symmetric to 2e-15 under z-scoring",
    direction_observed="n/a (estimator layer); argument order (source, dest) is set by the calling SPI",
    candidate_resolutions=[
        dict(candidate="the bundled infodynamics.jar is not a build of tag v1.6.1", outcome="confirmed",
             evidence="infotheory.est.gaussian|var2_bivariate|64|kernel|jar-provenance: gaussian.EntropyCalculatorMultiVariateGaussian has superclass infodynamics.measures.continuous.EntropyCalculatorMultiVariateCommon, a class absent from the v1.6.1 tree. The exact upstream commit is not established (no byte-level rebuild); no value impact: every Gaussian call matches the closed forms (direct-jidt runs)."),
        dict(candidate="NORMALISE defaults differ (entropy true, MI/TE false) but have no effect on values", outcome="confirmed",
             evidence="infotheory.est.gaussian|var2_bivariate|1024|kernel|normalise: flags 1/0/0, H(10x) - H(x) = ln 10 exactly; infotheory.est.gaussian|*|entropy-constant: 1.4189385332 to <= 4.4e-16"),
        dict(candidate="a single linearly redundant pair makes every entropy-based Gaussian SPI raise and Calculator blanks the whole matrix", outcome="confirmed",
             evidence=f"{DEGEN}: je, ce, cce, di, si raise NonPositiveDefiniteMatrixException; mi returns +inf at (0,2); gc_k1, gc auto and te_symbolic return 0 at (0,2); tlmi and xme_gaussian_k1 stay finite; a real Calculator gives an all-NaN je table with a 'failed' report. Correction to the trace: xme_gaussian_k10 also raises on this dataset, for every narrowband source row and independently of the duplicate pair (noise-free sums of sinusoids have a singular 9-lag covariance; numpy Cholesky also fails)."),
        dict(candidate="BIAS_CORRECTION and NOISE_SEED set by pyspi do nothing on the Gaussian entropy calculator", outcome="confirmed",
             evidence="infotheory.est.gaussian|var2_bivariate|64|kernel|jar-provenance: entropy getProperty('BIAS_CORRECTION') is None; NOISE_SEED is stored (42) but no noise is added (direct-jidt entropies match the noise-free closed form to 5.5e-15)"),
    ],
    checks_run=[
        group(u, T("direct-jidt"), f"{REF}:chk_direct_jidt ({PRB}:est_direct_jidt)", "max_abs <= 5.5e-15 over 72 calls"),
        group(u, T("entropy-constant"), f"{REF}:chk_entropy_constant ({PRB}:est_entropy_cache)", "max_abs <= 4.4e-16"),
        group(u, T("normalise"), f"{REF}:chk_normalise ({PRB}:est_normalise)", "flags 1/0/0, shift ln 10"),
        group(u, T("jar-provenance"), f"{REF}:chk_jar_provenance ({PRB}:est_jar_provenance)", "superclass EntropyCalculatorMultiVariateCommon"),
        group(u, T("degenerate"), f"{REF}:chk_degenerate ({PRB}:degenerate_contract)", "contract as described; xme_k10 also raises"),
    ],
)

ORDER = ["check_method", "check_reference", "check_data", "agreement_criterion", "closeness", "verdict", "score_0_10",
         "what_changed", "new_finding", "definition_under_review", "check_cost", "symmetry_observed", "direction_observed",
         "candidate_resolutions", "checks_run"]

CORRECT = {
    "infotheory.est.gaussian": [
        ("new_finding_candidates", 2,
         "'CANDIDATE (robustness): a single linearly redundant pair (e.g. duplicated channel) makes every entropy-based Gaussian SPI raise. Probe on shared_envelope_T256 rows 0 and 2 (bit-identical): je, ce, cce, di and si raise infodynamics.utils.NonPositiveDefiniteMatrixException; mi returns inf; gc_k1 returns 0.0; tlmi and xme stay finite. Calculator.compute (calculator.py:301-303) then replaces the whole P x P matrix for je/ce/cce/di/si with NaN, not only the offending pair.'",
         "CANDIDATE (robustness): a single linearly redundant pair (e.g. duplicated channel) makes every entropy-based Gaussian SPI raise. Probe on shared_envelope_T256 rows 0 and 2 (bit-identical): je, ce, cce, di and si raise infodynamics.utils.NonPositiveDefiniteMatrixException; mi returns inf; gc_k1 returns 0.0; tlmi and xme_gaussian_k1 stay finite (check stage: xme_gaussian_k10 also raises on this dataset, for a different reason: singular 9-lag covariance of the noise-free narrowband rows). Calculator.compute (calculator.py:336-338 at HEAD a1f20c7) then replaces the whole P x P matrix for je/ce/cce/di/si with NaN, not only the offending pair."),
    ],
}

for uid, fields in U.items():
    p = REC / f"{uid}.yaml"
    rec = yaml.safe_load(p.read_text())
    c = rec["correctness"]
    assert len(fields["candidate_resolutions"]) == len(c.get("new_finding_candidates") or []), uid
    for key, idx, _old, new in CORRECT.get(uid, []):
        c[key][idx] = new
    if uid == "infotheory.xme.gaussian_k10":
        if "raises NonPositiveDefinite" not in c["units_and_range"]:
            c["units_and_range"] += "; raises NonPositiveDefiniteMatrixException (whole matrix NaN in Calculator) when the 9-lag source covariance is singular, e.g. noise-free narrowband sources (check stage, shared_envelope)"
    for k in ORDER:
        c[k] = fields[k]
    rec["status"] = "checked"
    p.write_text(yaml.dump(rec, Dumper=NoAlias, sort_keys=False, allow_unicode=True, width=200, default_flow_style=False))
    print("updated", uid)
