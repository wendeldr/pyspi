p = "/media/dan/Data/git/pyspi/audit/notes/it_gaussian.md"
s = open(p).read()

def rep(old, new):
    global s
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)

rep("The manifest `audit/checks/manifest/it_gaussian.json` has 154 runs.",
    "The manifest `audit/checks/manifest/it_gaussian.json` has 158 runs (154 from the first pass plus 4 added after the review: `est|scaled_offset|…|entropy-shift`, `est|scaled_offset|…|norm-invariance`, `je|scaled_offset|…|shift-d2` and `cce|iid_gaussian|4096|…|truth-iid`).")
rep("**153 pass, 1 fail, 0 without reference**", "**157 pass, 1 fail, 0 without reference**")
rep("Run time on the pyspi side is 45 s for the whole family. The longest run is the P=5, T=4096 auto-embedding probe at 11.1 s. Every other run takes ≤ 1 s.",
    "Run time on the pyspi side depends on machine load. Three forced runs of the family took 45 s, 24.3 s and 31.3 s (the last with the 4 added runs; sums of `time_s` in `out/pyspi/index/it_gaussian.json`). The longest run is always the P=5, T=4096 auto-embedding probe (`gc auto|iid_gaussian|4096|pipeline|params`): 11.1 s, 3.6 s and 5.7 s. The next longest are the degenerate-contract probe (3.7 s) and the normalise-invariance probe (1.6 s). Every other run takes ≤ 1.4 s.")

rep("- **Candidates.** All four are confirmed: provenance (exact commit still unknown), NORMALISE (no effect on values), robustness, and the no-op properties.",
    "- **Scale behaviour on scaled_offset** (raw rows, x = s·D2 + c with s = 0.2, 2, 5, 10; added after the review, which noted that the proposed check had been run on one channel only):\n"
    "  - `est|scaled_offset|1024|kernel|entropy-shift`: pyspi's cached univariate entropies with normalise=False shift by exactly ln s relative to the unscaled D2 rows: −1.6094379, 0.6931472, 1.6094379, 2.3025851, to max_abs 6.7e-16.\n"
    "  - `est|scaled_offset|1024|kernel|norm-invariance`: mi_gaussian, tlmi_gaussian and gc_gaussian_k-1 computed with normalise=True and with normalise=False differ by at most 1.4e-15 (mi), 3.3e-16 (tlmi) and 4.4e-16 (gc_k1); both slots equal the numpy closed forms on z-scored rows to max_abs 3.3e-15.\n"
    "- **Candidates.** All four are confirmed: provenance (exact commit still unknown), NORMALISE (no effect on values), robustness, and the no-op properties. The robustness finding (one duplicated channel makes je, ce, cce, di and si raise and blanks their matrices) is counted once, here, and not again on the individual SPI records.")

rep("- **Identity.** je = 2·1.4189385332 − mi_gaussian holds to 4.4e-16 (`je|bivariate_gaussian|1024|pipeline|identity-mi`).",
    "- **Identity.** je = 2·1.4189385332 − mi_gaussian holds to 4.4e-16 (`je|bivariate_gaussian|1024|pipeline|identity-mi`).\n"
    "- **Scale shift** (`je|scaled_offset|1024|kernel|shift-d2`, added after the review). With normalise=False, je(scaled_offset) − je(D2) = ln(s_i s_j) on every pair to 1.4e-15 (for example ln(0.2·2) = −0.91629 and ln(5·10) = 3.91202).")

rep("- **Candidates.** Both are confirmed: je is affine in mi (redundancy), and an exactly collinear pair blanks the whole je matrix (robustness).",
    "- **Candidates.** Both are confirmed: je is affine in mi (redundancy), and an exactly collinear pair blanks the whole je matrix (robustness). `new_finding` rests on the redundancy; the robustness mechanism is counted under est.gaussian.")

rep("- **Candidates.** Redundancy is confirmed. Bias is confirmed as plug-in behaviour, which is not a defect.",
    "- **Candidates.** Redundancy is confirmed. Bias is confirmed as plug-in behaviour, which is not a defect.\n"
    "- **new_finding: false** (changed after the review). mi_gaussian is itself the canonical quantity. The affinity of je and ce to mi is counted on the je and ce records, the SPIs it makes redundant, and is not counted a third time here.")

rep("### gc_gaussian_k-1_kt-1_l-1_lt-1: variant, score 8 (anchor 8: constant factor)",
    "### gc_gaussian_k-1_kt-1_l-1_lt-1: matches, score 9 (anchor 9: trivial documented convention; changed from variant, 8 after the review)\n\n"
    "The record's own canonical definition is Gaussian TE = F/2, and the code equals it to floating-point precision. The only mismatch is the supplement naming the statistic \"the log-ratio of residual variance\" (Geweke F) while also stating its equivalence to Gaussian TE. F = 2·TE is a documented identity (Barnett, Barrett & Seth 2009), a convention of the same kind as log base. Anchor 8 (published variant of canonical) does not fit, because the code is canonical TE, not a variant of it. The documentation mismatch remains a confirmed finding.\n")

rep("### gc_gaussian_k-max-10_tau-max-2: variant, score 7 (anchor 7: matches the supplement's MAX_CORR_AIS description, value-changing against canonical, plus the factor ½)",
    "### gc_gaussian_k-max-10_tau-max-2: variant, score 7 (anchor 7: matches the supplement's MAX_CORR_AIS description, value-changing against canonical)\n\n"
    "The score comes from the embedding selection. The factor ½ is the same documented convention as in the fixed-lag unit (anchor 9 on its own) and does not lower the score further.\n")

rep("- **Candidates.** All three are confirmed: n = 5, the present x included in every term, and the output being a block sum.",
    "- **Independent white pair at T=4096** (`cce|iid_gaussian|4096|pipeline|truth-iid`, added after the review; it replaces the earlier quotation of the T=256 exact-run values 6.97–7.06 as evidence). The population value is 5·H1 = 7.09469. The Monte Carlo mean is 7.09162 (SD 0.00180). pyspi gives 7.09433 (0→1) and 7.09321 (1→0): |pyspi − pop| = 0.0015, max_z 1.51, pass.\n"
    "- **Candidates.** All three are confirmed: n = 5, the present x included in every term, and the output being a block sum.")

rep("- **Candidates.** Both are confirmed. Robustness: si raises on the duplicate pair. Interpretation: innovation correlation counts toward SI. The interpretation point is a property of Ay's definition, not a deviation.",
    "- **Candidates.** Both are confirmed. Robustness: si raises on the duplicate pair. Interpretation: innovation correlation counts toward SI. The interpretation point is a property of Ay's definition, not a deviation.\n"
    "- **new_finding: false** (changed after the review). The robustness mechanism is counted once under est.gaussian, and the interpretation point is a documentation note, not a defect.")

rep("### Corrections to trace-stage fields\n",
    "### Changes after the adversarial review\n\n"
    "- **new_finding.** Set to false on `infotheory.si.gaussian` and `infotheory.mi.gaussian`. Each finding is now counted once: robustness on est.gaussian, and the je/ce/mi affinity on je and ce.\n"
    "- **Coverage.** Three probe runs complete the proposed scaled_offset checks: per-channel entropy shifts for all four scales, mi/tlmi/gc_k1 invariance between normalise=True and normalise=False, and the je ln(s_i s_j) shift. A statistical run replaces the cce iid sanity range.\n"
    "- **Score.** gc_gaussian_k-1 changes from variant, 8 to matches, 9.\n"
    "- **Timing.** The gc auto `check_cost` now quotes all three measured timings and gives the per-pair cost relative to the fixed-lag unit (about 200× at P=5, T=1024) as the basis for `moderate`.\n\n"
    "### Corrections to trace-stage fields\n")
open(p, "w").write(s)
print("ok")
