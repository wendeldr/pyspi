"""Writes audit/checks/manifest/it_gaussian.json (deterministic)."""
import json
from pathlib import Path

U = {
    "je": ("infotheory.je.gaussian", "je_gaussian"),
    "ce": ("infotheory.ce.gaussian", "ce_gaussian"),
    "mi": ("infotheory.mi.gaussian", "mi_gaussian"),
    "tlmi": ("infotheory.tlmi.gaussian", "tlmi_gaussian"),
    "gc1": ("infotheory.te.gaussian_k-1_kt-1_l-1_lt-1", "gc_gaussian_k-1_kt-1_l-1_lt-1"),
    "gca": ("infotheory.te.gaussian_auto-MAX_CORR_AIS_kmax-10_taumax-2", "gc_gaussian_k-max-10_tau-max-2"),
    "sym1": ("infotheory.te.symbolic", "te_symbolic_k-1_kt-1_l-1_lt-1"),
    "sym10": ("infotheory.te.symbolic", "te_symbolic_k-10_kt-1_l-1_lt-1"),
    "xme1": ("infotheory.xme.gaussian_k1", "xme_gaussian_k1"),
    "xme10": ("infotheory.xme.gaussian_k10", "xme_gaussian_k10"),
    "cce": ("infotheory.cce.gaussian", "cce_gaussian"),
    "di": ("infotheory.di.gaussian", "di_gaussian"),
    "si": ("infotheory.si.gaussian", "si_gaussian_k-1"),
    "est": ("infotheory.est.gaussian", None),
}
PROBE = "probes/it_gaussian_probes.py"
runs = []


def add(key, ds, T, path, tag, processes=None, probe=None, ident_override=None):
    unit, ident = U[key]
    if probe is not None:
        ident = None
    if ident_override:
        ident = ident_override
    # te_symbolic has two identifiers in one unit: keep them apart in the tag
    if key in ("sym1", "sym10"):
        tag = f"{key[3:]}-{tag}" if not tag.startswith(("k1", "k10")) else tag
        tag = ("k" + tag) if not tag.startswith("k") else tag
    rid = f"{unit}|{ds}|{T}|{path}|{tag}"
    runs.append(dict(run_id=rid, unit_id=unit, identifier=ident, dataset=ds, T=T, path=path,
                     processes=processes, seed=42,
                     probe=None if probe is None else {"module": PROBE, "function": probe}))


base5 = [("bivariate_gaussian", 1024), ("var2_bivariate", 1024), ("iid_gaussian", 256),
         ("contaminated", 1024), ("delayed_noise", 64)]
# ---------------- je
for ds, T in base5:
    add("je", ds, T, "pipeline", "numpy")
add("je", "scaled_offset", 1024, "kernel", "numpy")
add("je", "scaled_offset", 1024, "pipeline", "equals-d2")
add("je", "bivariate_gaussian", 1024, "pipeline", "identity-mi")
add("je", "bivariate_gaussian", 4096, "pipeline", "truth-p01", [0, 1])
add("je", "bivariate_gaussian", 4096, "pipeline", "truth-p23", [2, 3])
# ---------------- ce
for ds, T in base5:
    add("ce", ds, T, "pipeline", "numpy")
add("ce", "scaled_offset", 1024, "kernel", "numpy")
add("ce", "scaled_offset", 1024, "kernel", "order")
add("ce", "bivariate_gaussian", 1024, "pipeline", "identity-mi")
add("ce", "var2_bivariate", 1024, "pipeline", "identity-mi")
add("ce", "bivariate_gaussian", 4096, "pipeline", "truth-p01", [0, 1])
add("ce", "bivariate_gaussian", 4096, "pipeline", "truth-p23", [2, 3])
# ---------------- mi
for ds, T in base5 + [("bivariate_gaussian", 256), ("nonlinear_dependence", 1024)]:
    add("mi", ds, T, "pipeline", "numpy")
add("mi", "var2_bivariate", 1024, "kernel", "numpy")
add("mi", "trending", 1024, "pipeline-detrend", "numpy")
add("mi", "scaled_offset", 1024, "kernel", "invariance")
for T in (256, 1024, 4096):
    add("mi", "bivariate_gaussian", T, "pipeline", "truth-p01", [0, 1])
    add("mi", "bivariate_gaussian", T, "pipeline", "truth-p23", [2, 3])
for T in (256, 1024):
    add("mi", "iid_gaussian", T, "pipeline", "null")
add("mi", "nonlinear_dependence", 1024, "pipeline", "linear-only")
# ---------------- tlmi
for ds, T in [("var2_bivariate", 1024), ("delayed_noise", 1024), ("gauss_ar1_pair", 1024), ("iid_gaussian", 256)]:
    add("tlmi", ds, T, "pipeline", "numpy")
add("tlmi", "delayed_noise", 4096, "pipeline", "truth-p01", [0, 1])
add("tlmi", "gauss_ar1_pair", 4096, "pipeline", "truth")
add("tlmi", "delayed_noise", 1024, "pipeline", "direction")
add("tlmi", "var2_bivariate", 1024, "pipeline", "direction")
# ---------------- gc k=1
for ds, T in [("var2_bivariate", 64), ("var2_bivariate", 1024), ("gauss_ar1_pair", 1024), ("delayed_noise", 1024),
              ("iid_gaussian", 256), ("logistic_maps_chaotic", 1024), ("logistic_maps", 1024)]:
    add("gc1", ds, T, "pipeline", "numpy")
add("gc1", "var2_bivariate", 1024, "pipeline", "ols")
add("gc1", "delayed_noise", 1024, "pipeline", "ols")
add("gc1", "scaled_offset", 1024, "kernel", "numpy")
add("gc1", "trending", 1024, "pipeline-detrend", "numpy")
add("gc1", "var2_bivariate", 4096, "pipeline", "truth")
add("gc1", "iid_gaussian", 1024, "pipeline", "null")
add("gc1", "var2_bivariate", 1024, "pipeline", "direction")
add("gc1", "delayed_noise", 1024, "pipeline", "direction")
# ---------------- gc auto
for ds, T in [("var2_bivariate", 64), ("var2_bivariate", 1024), ("delayed_noise", 256), ("gauss_ar1_pair", 1024),
              ("logistic_maps_chaotic", 1024)]:
    add("gca", ds, T, "pipeline", "numpy")
for ds, T in [("var2_bivariate", 64), ("var2_bivariate", 256), ("var2_bivariate", 1024), ("var2_bivariate", 4096),
              ("iid_gaussian", 256), ("iid_gaussian", 1024), ("iid_gaussian", 4096), ("delayed_noise", 256),
              ("gauss_ar1_pair", 1024)]:
    add("gca", ds, T, "pipeline", "params", probe="te_auto_params")
add("gca", "var2_bivariate", 1024, "pipeline", "direction")
add("gca", "delayed_noise", 1024, "pipeline", "direction")
# ---------------- te_symbolic
for key in ("sym1", "sym10"):
    for ds, T in [("var2_bivariate", 1024), ("logistic_maps_chaotic", 1024), ("delayed_noise", 1024)]:
        add(key, ds, T, "pipeline", "numpy")
for ds in ("var2_bivariate", "logistic_maps_chaotic"):
    add("sym1", ds, 1024, "pipeline", "identity-gc1")
for ds in ("logistic_maps_chaotic", "anm"):
    add("sym1", ds, 1024, "pipeline", "monotone", probe="te_symbolic_monotone")
# ---------------- xme
for key in ("xme1", "xme10"):
    for ds, T in [("var2_bivariate", 1024), ("delayed_noise", 1024), ("gauss_ar1_pair", 1024), ("iid_gaussian", 256)]:
        add(key, ds, T, "pipeline", "numpy")
    add(key, "delayed_noise", 4096, "pipeline", "truth-p01", [0, 1])
    add(key, "delayed_noise", 4096, "pipeline", "truth-p03", [0, 3])
    add(key, "delayed_noise", 1024, "pipeline", "direction")
    add(key, "iid_gaussian", 4096, "pipeline", "shift-numpy", probe="xme_shift_stack")
    add(key, "iid_gaussian", 4096, "pipeline", "shift-pattern", probe="xme_shift_stack")
add("xme1", "var2_bivariate", 1024, "pipeline", "k2-numpy", probe="xme_k2")
add("xme1", "var2_bivariate", 1024, "pipeline", "k2-equals-k1-shifted", probe="xme_k2")
add("xme1", "delayed_noise", 1024, "pipeline", "k2-equals-k1-shifted", probe="xme_k2")
# ---------------- cce
cce_ds = [("var2_bivariate", 1024), ("delayed_noise", 256), ("gauss_ar1_pair", 1024), ("iid_gaussian", 256),
          ("bivariate_gaussian", 1024)]
for ds, T in cce_ds:
    add("cce", ds, T, "pipeline", "numpy")
add("cce", "bivariate_gaussian", 4096, "pipeline", "truth-p01", [0, 1])
add("cce", "bivariate_gaussian", 4096, "pipeline", "truth-p23", [2, 3])
add("cce", "gauss_ar1_pair", 4096, "pipeline", "truth")
add("cce", "var2_bivariate", 1024, "pipeline", "direction")
add("cce", "delayed_noise", 1024, "pipeline", "direction")
add("cce", "var2_bivariate", 1024, "pipeline", "n10", probe="cce_n10")
add("cce", "var2_bivariate", 64, "pipeline", "configured-n", probe="configured_history")
# ---------------- di
for ds, T in cce_ds:
    add("di", ds, T, "pipeline", "numpy")
add("di", "var2_bivariate", 1024, "pipeline", "massey")
add("di", "var2_bivariate", 1024, "pipeline", "massey-identity")
add("di", "bivariate_gaussian", 4096, "pipeline", "truth-p01", [0, 1])
add("di", "bivariate_gaussian", 4096, "pipeline", "truth-p23", [2, 3])
add("di", "var2_bivariate", 4096, "pipeline", "indep-numpy", probe="di_independent_pair")
add("di", "var2_bivariate", 4096, "pipeline", "indep-truth", probe="di_independent_pair")
add("di", "var2_bivariate", 1024, "pipeline", "direction")
add("di", "delayed_noise", 1024, "pipeline", "direction")
add("di", "var2_bivariate", 1024, "pipeline", "n10", probe="di_n10")
# ---------------- si
for ds, T in [("var2_bivariate", 1024), ("gauss_ar1_pair", 1024), ("delayed_noise", 256), ("iid_gaussian", 256)]:
    add("si", ds, T, "pipeline", "numpy")
add("si", "gauss_ar1_pair", 4096, "pipeline", "truth")
add("si", "bivariate_gaussian", 4096, "pipeline", "truth-p01", [0, 1])
add("si", "bivariate_gaussian", 4096, "pipeline", "truth-p23", [2, 3])
add("si", "iid_gaussian", 1024, "pipeline", "null")
# ---------------- estimator layer
for ds, T in [("iid_gaussian", 256), ("var2_bivariate", 1024), ("bivariate_gaussian", 64)]:
    add("est", ds, T, "pipeline", "entropy-constant", probe="est_entropy_cache")
for ds, T in [("var2_bivariate", 1024), ("sparse_precision", 1024), ("iid_gaussian", 256)]:
    add("est", ds, T, "kernel", "direct-jidt", probe="est_direct_jidt")
add("est", "var2_bivariate", 1024, "kernel", "normalise", probe="est_normalise")
add("est", "shared_envelope", 256, "pipeline", "degenerate", probe="degenerate_contract")
add("est", "var2_bivariate", 64, "kernel", "jar-provenance", probe="est_jar_provenance")
add("sym1", "var2_bivariate", 64, "pipeline", "labels", probe="instance_labels")

ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids)), [i for i in ids if ids.count(i) > 1]
out = Path("/media/dan/Data/git/pyspi/audit/checks/manifest/it_gaussian.json")
out.write_text(json.dumps({"family": "it_gaussian", "runs": runs}, indent=1) + "\n")
print(len(runs), "runs")
