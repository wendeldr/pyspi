import yaml
R = "/media/dan/Data/git/pyspi/audit/records/"

def load(u):
    return yaml.safe_load(open(R + u + ".yaml"))

def save(u, d):
    open(R + u + ".yaml", "w").write(yaml.safe_dump(d, sort_keys=False, width=200, allow_unicode=True))

# ---- si
u = "infotheory.si.gaussian"; d = load(u); c = d["correctness"]
c["new_finding"] = False
c["what_changed"] += (" new_finding is false: the duplicate-channel raise is one estimator-level mechanism shared by je, ce, cce, di and si and is counted once,"
                      " under infotheory.est.gaussian; the innovation-correlation candidate is confirmed as a property of Ay's definition (a documentation note, not a defect).")
c["candidate_resolutions"][0]["evidence"] += "; counted as a finding under infotheory.est.gaussian, not again on this unit"
c["candidate_resolutions"][1]["evidence"] += " Not counted as a finding."
save(u, d)

# ---- mi
u = "infotheory.mi.gaussian"; d = load(u); c = d["correctness"]
c["new_finding"] = False
c["what_changed"] += (" new_finding is false: mi_gaussian is itself the canonical quantity; the je/ce/mi affinity is counted as a finding on infotheory.je.gaussian and"
                      " infotheory.ce.gaussian (the SPIs it makes redundant), and the missing bias correction is plug-in behaviour, not a defect.")
c["candidate_resolutions"][0]["evidence"] += "; counted as a finding on infotheory.je.gaussian and infotheory.ce.gaussian, not on mi_gaussian"
save(u, d)

# ---- est
u = "infotheory.est.gaussian"; d = load(u); c = d["correctness"]
c["check_data"] += "; scaled_offset T1024 (raw rows, probes)"
c["closeness"] += (" scaled_offset with normalise=False: cached univariate entropy shifts H(scaled row p) - H(D2 row p) = ln 0.2, ln 2, ln 5, ln 10"
                   " (-1.6094379, 0.6931472, 1.6094379, 2.3025851) to max_abs 6.7e-16 (est|scaled_offset|1024|kernel|entropy-shift);"
                   " mi_gaussian, tlmi_gaussian and gc_gaussian_k-1 with normalise=True vs normalise=False differ by at most 1.4e-15 and both equal the numpy"
                   " closed forms on z-scored rows to max_abs 3.3e-15 (est|scaled_offset|1024|kernel|norm-invariance).")
c["checks_run"].append({"run_ids": ["infotheory.est.gaussian|scaled_offset|1024|kernel|entropy-shift"],
                        "reference": "audit/checks/refs/it_gaussian.py:chk_entropy_shift (analytic ln|s|; audit/checks/probes/it_gaussian_probes.py:est_scaled_shift)",
                        "outcome": "1/1 pass; max_abs 6.7e-16 for scales 0.2, 2, 5, 10"})
c["checks_run"].append({"run_ids": ["infotheory.est.gaussian|scaled_offset|1024|kernel|norm-invariance"],
                        "reference": "audit/checks/refs/it_gaussian.py:chk_norm_invariance (audit/checks/probes/it_gaussian_probes.py:norm_invariance)",
                        "outcome": "1/1 pass; max_abs 3.3e-15 vs numpy; normalise True vs False max 1.4e-15 (mi), 3.3e-16 (tlmi), 4.4e-16 (gc_k1)"})
c["check_cost"] = "cheap: <= 0.05 s per direct-JIDT probe; 0.7-1.6 s for the scaled_offset probes; 3.7 s for the degenerate-contract probe (13 SPIs plus a real Calculator)"
save(u, d)

# ---- je
u = "infotheory.je.gaussian"; d = load(u); c = d["correctness"]
c["closeness"] += (" Raw scaled_offset minus raw bivariate_gaussian (same draw, normalise=False) equals ln(s_i s_j) on every pair to max_abs 1.4e-15"
                   " (je|scaled_offset|1024|kernel|shift-d2; e.g. ln(0.2*2) = -0.91629, ln(5*10) = 3.91202).")
c["checks_run"].append({"run_ids": ["infotheory.je.gaussian|scaled_offset|1024|kernel|shift-d2"],
                        "reference": "audit/checks/refs/it_gaussian.py:chk_je_shift (analytic ln(s_i s_j); audit/checks/probes/it_gaussian_probes.py:je_scaled_shift)",
                        "outcome": "1/1 pass; max_abs 1.4e-15"})
save(u, d)

# ---- cce
u = "infotheory.cce.gaussian"; d = load(u); c = d["correctness"]
c["check_data"] = c["check_data"].replace("iid_gaussian T256;", "iid_gaussian T256 and pair (0,1) at T4096;")
old = "iid_gaussian T256 values 6.97-7.06 (5 H1 = 7.0947)."
assert old in c["closeness"]
c["closeness"] = c["closeness"].replace(old,
    "Independent white pair (iid_gaussian x0, x1, T=4096): population 5 H1 = 7.09469, Monte Carlo mean 7.09162 (SD 0.00180), pyspi 7.09433 (0->1) / 7.09321 (1->0),"
    " |pyspi - population| 0.0015 (max_z 1.51) (cce|iid_gaussian|4096|pipeline|truth-iid); the T=256 exact-run values 6.97-7.06 are a sanity range only.")
for e in c["checks_run"]:
    if any("truth" in r for r in e["run_ids"]):
        e["run_ids"].append("infotheory.cce.gaussian|iid_gaussian|4096|pipeline|truth-iid")
        e["reference"] = "audit/checks/refs/it_gaussian.py:chk_truth_pair / chk_cce_truth / chk_cce_iid (analytic + Monte Carlo SE)"
        e["outcome"] = "4/4 pass; max_z <= 1.75 (iid pair: 1.51)"
save(u, d)

# ---- gc k1
u = "infotheory.te.gaussian_k-1_kt-1_l-1_lt-1"; d = load(u); c = d["correctness"]
c["verdict"] = "matches"
c["score_0_10"] = 9
c["what_changed"] = ("Nothing against the canonical Gaussian transfer entropy I(X_t; Y_t+1 | Y_t) (Barnett, Barrett & Seth 2009), fp-exact. The supplement names the statistic"
                     " 'the log-ratio of residual variance' (Geweke F) while stating its equivalence to Gaussian TE; the returned value is TE = F/2 (pyspi/F = 0.5 exactly),"
                     " the documented F = 2 TE convention, so the score is rubric anchor 9 (trivial documented convention of the log-base kind) rather than 10."
                     " Rankings are unchanged. One target lag and one source lag.")
save(u, d)

# ---- gc auto
u = "infotheory.te.gaussian_auto-MAX_CORR_AIS_kmax-10_taumax-2"; d = load(u); c = d["correctness"]
c["check_cost"] = ("moderate: the P=5, T=4096 params probe (20 ordered pairs x 2 searches x 19 Gaussian MI fits) took 11.1 s, 3.6 s and 5.7 s in three forced runs"
                   " (machine-load dependent); at P=5, T=1024 the auto unit takes 1.4 s against 0.0065 s for the fixed-lag gc_gaussian_k-1 on the same size"
                   " (about 200x, from the per-pair AIS searches); 0.2-0.6 s per run otherwise; 11.7 s for the unit in the latest run")
save(u, d)
print("ok")
