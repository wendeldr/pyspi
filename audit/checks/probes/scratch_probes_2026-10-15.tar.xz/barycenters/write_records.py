import yaml
from pathlib import Path
OUT = Path('/media/dan/Data/git/pyspi/audit/records')
TS = '.venv/lib/python3.12/site-packages/tslearn'

DOC = ('supplement §1.2.10, p.7 (supplement.txt lines 321-335): "A barycenter (or Fréchet mean) [21, 22] is a (univariate) '
       'time series that minimizes the sum of squared distances between MTS ... For each pair of (bivariate) time series ... we compute '
       'the raw barycenters then summarize them by taking their mean (modifier mean) and maximum (max), yielding seven SPIs" '
       '(keywords: undirected, nonlinear, unsigned, bivariate, time-dependent). GitBook distance-similarity.md:41-75 repeats this, adds '
       '"timepoint at which the maximum occurs (max_time)" and lists 12 identifiers bary_{euclidean,dtw,softdtw,sgddtw}_{mean,max,max_time}; '
       'neither source documents the squared (bary-sq_*) variants.')

PY_COMMON = [
    "pyspi/statistics/distance.py:4-9 imports euclidean_barycenter, dtw_barycenter_averaging, dtw_barycenter_averaging_subgradient, softdtw_barycenter from tslearn.barycenters",
    "pyspi/statistics/distance.py:211-215 class Barycenter(Directed, Signed); class labels ['distance','signed','undirected','temporal','nonlinear']",
    None,  # mode line
    "pyspi/statistics/distance.py:230-234 squared=True sets preproc x**2 and identifier prefix 'bary-sq'",
    "pyspi/statistics/distance.py:236-243 statistic: mean -> np.nanmean(preproc(bc)); max -> np.nanmax(preproc(bc)); max_time -> np.argmax(preproc(bc)) (not in any config)",
    "pyspi/statistics/distance.py:245 identifier suffix _{mode}_{statistic}",
    "pyspi/statistics/distance.py:247-263 bivariate: looks up data.barycenter[mode][(i,j)]; on miss z = data.to_numpy(squeeze=True); bc = self._fn(z[[i, j]]) with library defaults; caches bc under (i,j) AND (j,i) (line 261); returns statfn(bc)",
    "pyspi/base.py:27-48 parse_bivariate (wraps raw arrays in a Data object, default normalise=True)",
    "pyspi/base.py:85-94 Directed.multivariate: j outer, i inner, A[i,j] = bivariate(i, j); the first call for pair {a<b} is (i=b, j=a), so the cached barycenter is computed from z[[b, a]] and reused for A[a,b]",
    "pyspi/data.py:59-71 Data defaults detrend=False, normalise=True; pyspi/data.py:184-195 optional scipy detrend then zscore(axis=1, ddof=1)",
    "pyspi/data.py:108-116 to_numpy(squeeze=True) -> (P, T) array",
    "pyspi/calculator.py:238-244 configs instantiated as Barycenter(**params); spi.labels come from the class (config labels at pyspi/config.yaml:256-261 are not applied); pyspi/calculator.py:289-294 every SPI's multivariate() receives the same self.dataset, so all statistics/squared variants of one mode share one cached barycenter per pair",
    "pyspi/config.yaml:255-311 Barycenter configs: 4 modes x {mean,max} x {squared False, True} = 16 identifiers",
    f"{TS}/barycenters/utils.py:7-13 _set_weights(None, 2) -> numpy.ones(2) (unnormalised uniform weights)",
    f"{TS}/utils/utils.py:215 to_time_series_dataset: (2, T) -> (2, T, 1)",
]

def common(mode_line):
    t = list(PY_COMMON); t[2] = mode_line; return t

LABEL_DEV = ('Documented keyword "unsigned", but the class is Signed (issigned() True, class label "signed"); the config labels '
             '(undirected, nonlinear, unsigned, bivariate, time-dependent) are never attached to the SPI (calculator.py:238-244 uses class labels). '
             'Documented "undirected", but the class inherits Directed; symmetry comes only from the per-Data cache writing (j,i) = (i,j) (distance.py:261), '
             'not from Undirected.multivariate mirroring. Supplement says "seven SPIs" (lists euclidean_max, dtw_mean/max, softdtw_mean/max, sgddtw_mean/max); '
             'config computes 16, including bary_euclidean_mean and all eight bary-sq_* variants, none of which are documented; GitBook lists max_time variants '
             'that exist in code (distance.py:240-241) but are absent from every config.')

def check(datasets, path, reference, kind, criterion, expected):
    return dict(datasets=datasets, path=path, reference=reference, reference_kind=kind, criterion=criterion, expected_outcome=expected)

SYM_CHECK = lambda mode: check(["var2_bivariate", "delayed_noise", "logistic_maps"], "pipeline",
    f"numpy comparison of A and A.T from Calculator-style Barycenter(mode='{mode}').multivariate(Data(x)) plus a cold-cache call bivariate(Data(x), i=0, j=1) vs bivariate(Data(x), i=1, j=0) on fresh Data objects (direction convention)",
    "analytic", "direction",
    "A[i,j] == A[j,i] bit-identically in multivariate (cache, distance.py:261); establishes that A[i,j] carries no direction; cold-cache swapped-order calls equal for deterministic modes (euclidean, dtw, softdtw) and possibly unequal for sgddtw")

records = {}

# ---------------- Euclidean -----------------
records['distance.bary.euclidean'] = dict(
    metric_name_standard='Summary (time-mean or time-max) of the Euclidean Fréchet mean (pointwise average (x+y)/2) of two z-scored series; squared variant summarises ((x+y)/2)^2',
    canonical_ref='Fréchet 1948, Ann. Inst. Henri Poincaré 10(4):215-310 (Fréchet mean); for squared Euclidean distance the Fréchet mean of {x_k} is the arithmetic mean (e.g. Petitjean et al. 2011, Pattern Recognit. 44:678, §2). The scalar mean/max summary is a pyspi construction (Cliff et al. 2023, Nat. Comput. Sci., supplement §1.2.10) with no literature counterpart.',
    canonical_definition='b* = argmin_b sum_k ||b - x_k||^2 = (x + y)/2; SPI = mean_t b*(t) or max_t b*(t); squared: mean_t b*(t)^2 or max_t b*(t)^2',
    documented_definition=DOC,
    delegate_lib='tslearn==0.9.0 tslearn.barycenters.euclidean_barycenter (numpy.average over axis 0, uniform weights)',
    implemented_as=('Each process z-scored (scipy zscore, ddof=1; detrend only if requested); b = numpy.average(z[[i,j]] as (2,T,1), axis=0) = (z_i + z_j)/2, shape (T,1); '
                    'statistic = nanmean/nanmax of b or of b**2. Consequences on z-scored input: mean(b) = (mean z_i + mean z_j)/2 = 0 up to rounding; '
                    'mean(b**2) = (1 + r)(T-1)/(2T) with r the Pearson correlation; max(b) = max_t (z_i+z_j)/2 >= 0; max(b**2) = (max_t |z_i+z_j|/2)^2. '
                    'Cached per pair on the Data object and mirrored, so A is exactly symmetric.'),
    implementation_trace=common("pyspi/statistics/distance.py:218-219 mode 'euclidean' -> self._fn = euclidean_barycenter") + [
        f"{TS}/barycenters/euclidean.py:9 euclidean_barycenter(X, weights=None)",
        f"{TS}/barycenters/euclidean.py:42-44 X_ = to_time_series_dataset(X); weights = _set_weights(weights, 2); return numpy.average(X_, axis=0, weights=weights)",
    ],
    deviation_from_documented=LABEL_DEV + ' bary_euclidean_mean (in config and in the EEG selection) is not among the supplement\'s seven SPIs; on the default z-scored input it is structurally zero (probe: |A| <= 1.8e-17 on bivariate_gaussian T=256).',
    deviation_from_canonical=('Barycenter itself matches the canonical Euclidean Fréchet mean exactly (numpy.average with equal weights). The summaries are pyspi-defined: '
                              'bary_euclidean_mean is identically 0 (degenerate) under normalise=True; bary-sq_euclidean_mean is an affine function of Pearson r, '
                              '(1+r)(T-1)/(2T), i.e. a rescaled correlation rather than a distance; the max variants are extreme-value statistics of x+y and depend on tail behaviour and T.'),
    units_and_range=('z-score units (dimensionless after normalisation). mean: 0 up to ~1e-16 rounding, either sign. max: >= 0 (max of a zero-mean series), grows with T for Gaussian data. '
                     'sq-mean: in [0, (T-1)/T]. sq-max: >= sq-mean, >= 0. Never NaN for finite input. Labelled signed. Symmetric.'),
    direction_convention='undirected: A[i,j] = A[j,i] bit-identical (shared cached barycenter); the barycenter is computed once from z[[max(i,j), min(i,j)]] and the Euclidean average is order-invariant anyway',
    symmetry_expected='sym',
    already_documented='tests/README.md:128 tolerance table notes "bary_euclidean_mean ~1e-16" rounding noise (atol absorbs it); not listed in KNOWN_ISSUES.md; label/config discrepancies otherwise no',
    new_finding_candidates=[
        'Candidate: bary_euclidean_mean is structurally zero (not merely small) on the default pipeline, so it carries no information although it is in config.yaml and the EEG selection. Evidence: probe1 on bivariate_gaussian T=256 gives off-diagonal values -1.04e-17 .. 1.73e-17; z-scored rows have mean ~1e-17; numpy.average of two zero-mean rows has zero mean. The supplement\'s seven-SPI list omits it (hypothesis: deliberately).',
        'Candidate: bary-sq_euclidean_mean equals (1+r)(T-1)/(2T) exactly, so it is a monotone transform of Pearson r and redundant with it. Evidence: probe1 pyspi matrix [0.647546, 0.479399, 0.477355, 0.489262, 0.465147, 0.907001] equals the formula to 6 decimals on bivariate_gaussian T=256.',
        'Candidate: label inconsistency, class is Directed+Signed with label "signed" while supplement/GitBook/config say "unsigned"; signed is the accurate label for the mean statistic (values of either sign), max statistics are non-negative here. Evidence: probe1 prints labels [..., "signed", ...] and issigned() True.',
        'Candidate: statistic "max_time" exists (distance.py:240-241) and is documented by GitBook but is absent from all configs; it returns numpy.int64 argmax (probe1: 229 for pair (0,1)), uses np.argmax not a nan-aware argmax, and is a time index rather than a dependence value.',
        'Candidate: under normalise=False the mean statistic becomes (mean x + mean y)/2, i.e. it measures offsets, not coupling (follows from euclidean.py:44); to be shown on scaled_offset with normalise=False.',
    ],
    proposed_checks=[
        check(["iid_gaussian", "bivariate_gaussian", "scaled_offset", "trending"], "pipeline",
              "analytic: mean of (z_i + z_j)/2 with z from scipy-free numpy z-scoring (ddof=1) is 0", "analytic", "tolerance",
              "bary_euclidean_mean |A[i,j]| < 1e-12 for every pair, every T (degenerate constant zero)"),
        check(["bivariate_gaussian", "sparse_precision", "iid_gaussian", "contaminated"], "pipeline",
              "analytic: (1 + r)(T-1)/(2T) with r = numpy.corrcoef of the raw rows", "analytic", "tolerance",
              "bary-sq_euclidean_mean matches the formula to rtol 1e-12 for all pairs and T"),
        check(["bivariate_gaussian", "delayed_noise", "narrowband_f0-0.25", "nonlinear_dependence"], "kernel",
              "from-scratch numpy: z = (x - x.mean())/x.std(ddof=1); b = (z_i + z_j)/2; nanmax(b), nanmax(b**2), nanmean(b**2)", "independent-impl", "tolerance",
              "all four identifiers agree with pyspi to rtol 1e-12 / atol 1e-14"),
        check(["trending", "scaled_offset"], "pipeline-detrend",
              "from-scratch numpy: linear least-squares detrend then z-score (ddof=1), b = (z_i+z_j)/2", "independent-impl", "tolerance",
              "detrend=True results match to rtol 1e-12; scaled_offset gives the same values as bivariate_gaussian (same draw) because z-scoring removes scale and offset"),
        check(["bivariate_gaussian"], "pipeline",
              "analytic population value: E[sq_mean] -> (1 + rho)/2 with rho in {0.3, 0.8}", "analytic", "statistical",
              "at T=4096 bary-sq_euclidean_mean within 3 standard errors of 0.65 (pair 0,1) and 0.90 (pair 2,3)"),
        SYM_CHECK('euclidean'),
    ],
)

# ---------------- DTW (DBA, MM) -----------------
records['distance.bary.dtw'] = dict(
    metric_name_standard='Summary (time-mean or time-max) of the DTW barycenter (DBA / Fréchet mean under DTW) of two z-scored series; squared variant summarises its square',
    canonical_ref='Petitjean, Ketterlin & Gançarski 2011, Pattern Recognit. 44(3):678-693 (DBA, §4 Alg. 5); Schultz & Jain 2018, Pattern Recognit. 74:340-358 (Fréchet function, MM algorithm Alg. 2). Mean/max summary: pyspi construction (supplement §1.2.10).',
    canonical_definition='b* in argmin_b F(b) = (1/n) sum_k DTW(b, x_k)^2 with DTW(b,x)^2 = min over warping paths of sum (b_t - x_s)^2 (unconstrained); DBA/MM iterate: align each x_k to b by DTW, set b_t = average of all x_k samples aligned to t; non-convex, returns a local minimiser. SPI = mean_t b(t) or max_t b(t) (squared: of b(t)^2).',
    documented_definition=DOC + ' Mode dtw is documented as "alignment via expectation maximization".',
    delegate_lib='tslearn==0.9.0 tslearn.barycenters.dtw_barycenter_averaging (Majorize-Minimize variant; defaults n_init=1, max_iter=30, tol=1e-5, barycenter_size=T, init=None, metric_params=None) with numba 0.68.0 _njit_dtw_path',
    implemented_as=('z-scored pair (ddof=1). Init b0 = nanmean of the two series = Euclidean barycenter (dba.py:23-25, 707). Up to 30 iterations: DTW path of b against each x_k '
                    '(squared-Euclidean local cost, no global constraint), cost = mean_k DTW^2 (weights ones/2); valence V = sum of path counts per barycenter index, '
                    'b <- diag(1/V) sum_k W_k x_k (Petitjean averaging); stop when |cost_prev - cost| < 1e-5 (absolute) or the cost increases (ConvergenceWarning). '
                    'The returned b is the update after the last assignment step. Single initialisation; deterministic; input order irrelevant (probe2 order-diff 0). '
                    'Then nanmean/nanmax of b or b**2.'),
    implementation_trace=common("pyspi/statistics/distance.py:220-221 mode 'dtw' -> self._fn = dtw_barycenter_averaging") + [
        f"{TS}/barycenters/dba.py:485-496 dtw_barycenter_averaging signature (max_iter=30, tol=1e-5, n_init=1)",
        f"{TS}/barycenters/dba.py:599-618 n_init loop keeps the lowest-loss barycenter (one init here)",
        f"{TS}/barycenters/dba.py:621-631 dtw_barycenter_averaging_one_init; 702-707 to_time_series_dataset, _set_weights, _init_avg",
        f"{TS}/barycenters/dba.py:23-25 _init_avg: numpy.nanmean(X, axis=0) when barycenter_size == T",
        f"{TS}/barycenters/dba.py:715-736 MM loop: _mm_assignment, _mm_valence_warping, _mm_update_barycenter; 729-734 stopping (abs change < tol, or increase -> warning + break)",
        f"{TS}/barycenters/dba.py:229-305 _mm_assignment: _njit_dtw_path(barycenter, X[i]) per series, cost += dist^2 * w_i, cost /= sum(w)",
        f"{TS}/barycenters/dba.py:308-352 _subgradient_valence_warping (W_k path indicator, V_k = row sums); 355-397 _mm_valence_warping sums V_k",
        f"{TS}/barycenters/dba.py:400-434 _mm_update_barycenter: diag(1/sum V_k) . sum_k W_k x_k",
        f"{TS}/metrics/_dtw.py:325-344 _njit_accumulated_matrix: local cost sum_d (s1-s2)^2, recursion min of three predecessors",
        f"{TS}/metrics/_dtw.py:415-443 _njit_dtw_path: mask, accumulated matrix, path; returns sqrt(cum_sum[-1,-1]) (line 435)",
        f"{TS}/metrics/utils.py:18-50 _njit_compute_path backtracking of the optimal warping path",
    ],
    deviation_from_documented=LABEL_DEV + ' "Expectation maximization" is loose wording: tslearn runs the Majorize-Minimize mean algorithm (Schultz & Jain 2018 Alg. 2), whose update equals the DBA averaging step; the tslearn docstring itself says "Expectation-Maximization". bary-sq_dtw_* undocumented.',
    deviation_from_canonical=('Algorithm matches DBA/MM. Differences from Petitjean 2011 practice: initialised at the Euclidean mean (Petitjean initialises from a selected input sequence), one initialisation, '
                              'max_iter 30 and absolute tol 1e-5, so the result is a local minimiser near the Euclidean mean. Probe2: on narrowband_f0-0.25 (phase-shifted sinusoids) the final cost equals the cost of the Euclidean init '
                              '(9.5464, 37.6819, 151.2988 at T=64/256/1024) after 2 iterations, i.e. DBA did not move; on bivariate_gaussian it lowers the cost (65.13 -> 44.69 at T=256). '
                              'The mean/max summaries are pyspi-defined.'),
    units_and_range='z-score units. mean: near 0 but not structurally zero (probe2: 0.0334 at T=64, -0.0052 at T=256 bivariate_gaussian; 0.0199 delayed_noise T=256), either sign. max: typically positive, of order max of the inputs. sq variants >= 0. Finite for finite input. Symmetric.',
    direction_convention='undirected: A[i,j] = A[j,i] bit-identical via the cache; DBA with mean init is invariant to input order (probe2 max|b(x,y) - b(y,x)| = 0)',
    symmetry_expected='sym',
    already_documented='no',
    new_finding_candidates=[
        'Candidate: for some pairs DBA returns its Euclidean initialisation unchanged, so bary_dtw_* equals bary_euclidean_* there. Evidence: probe2 narrowband_f0-0.25 pair (1,0): DBA epochs=2, cost == cost_init_eu (37.6819 at T=256), mean 0.0000; hypothesis: the initial DTW path from the mean is the diagonal, a fixed point of the MM update.',
        'Candidate: bary_dtw_mean is near-degenerate (close to zero), inheriting the zero mean of the Euclidean init; it only departs from 0 through warping-induced duplicated samples. Evidence: probe2 |mean| <= 0.034 across bivariate_gaussian/delayed_noise/narrowband at T=64..1024.',
        'Candidate: the label inconsistencies (Signed vs documented unsigned; Directed base vs "undirected") and the undocumented bary-sq_dtw_* identifiers, see deviation_from_documented.',
        'Candidate: DBA is a local optimiser started at a fixed point; the returned barycenter may not be the Fréchet mean, so values depend on the init rule (to be quantified by the optimality check).',
    ],
    proposed_checks=[
        check(["bivariate_gaussian", "delayed_noise", "narrowband_f0-0.25", "logistic_maps"], "kernel",
              "from-scratch numpy DBA: O(T^2) DTW dynamic programme with squared local cost and the same tie-breaking order as the tslearn backtrack, Petitjean averaging, init (x+y)/2, max_iter 30, tol 1e-5 absolute, same stopping rule", "independent-impl", "tolerance",
              "barycenter and all four statistics match pyspi to atol 1e-10 at T=64 and 256 (ties in path backtracking may cause isolated differences; report them)"),
        check(["bivariate_gaussian", "delayed_noise", "narrowband_f0-0.25"], "kernel",
              "Fréchet cost F(b) = mean_k DTW(b,x_k)^2 from the from-scratch DTW; compare pyspi barycenter vs Euclidean mean, vs each input series, and vs best of 20 random/medoid-initialised from-scratch DBA runs", "independent-impl", "optimality",
              "F(pyspi) <= F(Euclidean mean) always; report relative gap to the best multi-start solution (expected small for bivariate_gaussian, possibly large for narrowband where DBA does not move)"),
        check(["iid_gaussian"], "kernel",
              "analytic: DBA of (x, x) is x (Fréchet mean of identical series)", "analytic", "exact",
              "barycenter equals x exactly; bary_dtw_mean = mean(x) = 0, bary_dtw_max = max(x) (probe3 confirmed max|b-x| = 0 for one case)"),
        check(["delayed_noise", "narrowband_f0-0.25"], "pipeline",
              "pyspi bary_euclidean_* on the same pairs", "same-lineage", "qualitative",
              "for delayed copies bary_dtw_max > bary_euclidean_max (warping re-aligns the delayed copy); for narrowband pairs equality is expected if DBA stays at its init"),
        SYM_CHECK('dtw'),
    ],
)

# ---------------- SGD DTW -----------------
records['distance.bary.sgddtw'] = dict(
    metric_name_standard='Summary (time-mean or time-max) of the DTW barycenter of two z-scored series estimated by stochastic subgradient descent; squared variant summarises its square',
    canonical_ref='Schultz & Jain 2018, Pattern Recognit. 74:340-358 (stochastic subgradient mean algorithm, Alg. 1) for the DTW Fréchet function; Petitjean et al. 2011, Pattern Recognit. 44:678 (DBA). Mean/max summary: pyspi construction.',
    canonical_definition='b* in argmin_b F(b) = (1/n) sum_k DTW(b, x_k)^2; SSG: for k in a random order, b <- b - eta * 2 (V_k b - W_k x_k) with (V_k, W_k) from the optimal warping path of x_k to b, step size decreasing; SPI = mean_t b(t) or max_t b(t) (squared: of b(t)^2).',
    documented_definition=DOC + ' Mode sgddtw is documented as "alignment via a subgradient descent algorithm".',
    delegate_lib='tslearn==0.9.0 tslearn.barycenters.dtw_barycenter_averaging_subgradient (defaults max_iter=30, initial_step_size=0.05, final_step_size=0.005, tol=1e-5, random_state=None -> numpy global RandomState via sklearn 1.9.1 check_random_state)',
    implemented_as=('z-scored pair (ddof=1). Init b0 = (x+y)/2. Each epoch: rng.permutation(2) from the global numpy RNG; for each series k: DTW path b->x_k, b <- b - 2*eta*(V_k*b - W_k x_k) (wi.sum() = 1). '
                    'eta decreases by (0.05-0.005)/2 after each sample during epoch 0 only, then stays 0.005. After each epoch the variable "cost" holds only the LAST processed series\' '
                    'dist^2 * weights[0]/sum(weights) (half its squared DTW); stop if |cost_prev - cost| < 1e-5 or cost > cost_prev (ConvergenceWarning). Result depends on the global '
                    'numpy RNG state and on input order; within a Calculator run the four sgddtw identifiers share one cached barycenter per pair. Then nanmean/nanmax of b or b**2.'),
    implementation_trace=common("pyspi/statistics/distance.py:222-223 mode 'sgddtw' -> self._fn = dtw_barycenter_averaging_subgradient (no random_state passed)") + [
        f"{TS}/barycenters/dba.py:740-752 signature (max_iter=30, initial_step_size=.05, final_step_size=.005, tol=1e-5, random_state=None)",
        f"{TS}/barycenters/dba.py:838 rng = check_random_state(random_state)",
        ".venv/lib/python3.12/site-packages/sklearn/utils/validation.py:1455,1477-1478 check_random_state(None) returns np.random.mtrand._rand (global RNG)",
        f"{TS}/barycenters/dba.py:841-846 to_time_series_dataset, _set_weights, init b0 = _init_avg (Euclidean mean)",
        f"{TS}/barycenters/dba.py:857-858 epoch loop, shuffled_indices = rng.permutation(n)",
        f"{TS}/barycenters/dba.py:860-863 _mm_assignment(Xi, barycenter, weights, metric_params): single series but full weights vector, cost = dist^2*weights[0]/weights.sum()",
        f"{TS}/barycenters/dba.py:864-868 _subgradient_valence_warping(list_p_k, T, wi)",
        f"{TS}/barycenters/dba.py:871-873 _subgradient_update_barycenter(Xi, V, W, wi.sum(), barycenter, eta)",
        f"{TS}/barycenters/dba.py:437-482 update: delta = V_k*b - W_k x_k; b -= (2*eta/weights_sum)*delta (in place)",
        f"{TS}/barycenters/dba.py:874-875 step size decreases only while it == 0",
        f"{TS}/barycenters/dba.py:876-883 stopping on last-sample cost: abs change < tol -> break; increase -> ConvergenceWarning and break",
        f"{TS}/barycenters/dba.py:229-305 _mm_assignment; {TS}/metrics/_dtw.py:325-344, 415-443 DTW path (squared local cost)",
    ],
    deviation_from_documented=LABEL_DEV + ' Undocumented: results are stochastic (global numpy RNG, no seed exposed). bary-sq_sgddtw_* undocumented.',
    deviation_from_canonical=('Update rule matches SSG (Schultz & Jain 2018 Alg. 1) with a step size falling 0.05 -> 0.005 over the first epoch then constant. The stopping rule is not a test on F(b): it compares the per-sample cost of '
                              'whichever series happened to be processed last in two consecutive epochs, so any increase in that noisy quantity stops the descent. Probe4: bivariate_gaussian T=256 stops after 4 epochs '
                              '(last-sample costs 35.05, 28.16, 27.89, 31.23) with F(b)=57.77, while 30 uninterrupted epochs reach 50.26 and MM-DBA reaches 44.69; delayed_noise T=1024 stops with F=331.46 vs 185.01 uninterrupted and 135.86 for MM-DBA. '
                              'The barycenter is therefore an under-converged estimate of the DTW Fréchet mean. Mean/max summaries are pyspi-defined.'),
    units_and_range='z-score units. mean: near 0, either sign (probe2 |mean| <= 0.0162). max: typically positive. sq variants >= 0. Run-to-run variability without seeding (probe3: unseeded repeat max|ΔA| = 1.1e-3 for the mean statistic; probe2 seed 0 vs seed 1 barycenters differ by up to 1.18 pointwise). Symmetric within one call.',
    direction_convention='undirected: A[i,j] = A[j,i] bit-identical via the cache; the underlying routine is NOT order-invariant for a fixed RNG draw (probe3: swapped input order, same seed, max|Δb| = 0.177), the cache hides this',
    symmetry_expected='sym',
    already_documented='tests/README.md:115 and :127 (bary*_sgddtw_* draw from the global numpy RNG, marked stochastic and skipped in the end-to-end Calculator comparison); not listed in KNOWN_ISSUES.md; stopping-rule under-convergence: no',
    new_finding_candidates=[
        'Candidate: premature stopping makes sgddtw an under-converged DTW barycenter. Evidence: dba.py:862-863 computes cost for the single series Xi; dba.py:876-883 compares that last-sample cost across epochs and breaks on any increase; probe4 F(b) 57.77 (tslearn stop) vs 50.26 (30 epochs, no stop) vs 44.69 (MM-DBA) on bivariate_gaussian T=256 pair (1,0); 331.46 vs 185.01 vs 135.86 on delayed_noise T=1024. Probe2 shows ConvergenceWarning "DBA loss is increasing" in all 9 probe runs (one of them only after reaching max_iter=30).',
        'Candidate: value depends on the global RNG state consumed by SPIs computed earlier in the same Calculator run, and on which sgddtw identifier runs first (the others reuse the cached barycenter). Evidence: dba.py:838 + validation.py:1477-1478; probe3 cache keys [\'sgddtw\'] with 12 cached pairs after the mean SPI and no RNG consumption by the max SPI. (Global-RNG use itself is in tests/README.md:115/127.)',
        'Candidate: input-order dependence for a fixed RNG draw (probe3: max|Δb| = 0.177, mean difference 6.1e-4), hidden by the cache; with the Directed loop the barycenter for pair {a<b} is computed from z[[b, a]].',
        'Candidate: the cost passed back by _mm_assignment uses weights[0]/weights.sum() regardless of which series is processed (dba.py:862 passes the full weights vector); harmless for pyspi\'s uniform weights.',
    ],
    proposed_checks=[
        check(["bivariate_gaussian", "delayed_noise", "narrowband_f0-0.25"], "kernel",
              "from-scratch numpy SSG (own DTW DP + path, same init, same step schedule, same last-sample stopping rule) driven by numpy.random.RandomState(seed).permutation draws identical to the global RNG after np.random.seed(seed)", "independent-impl", "tolerance",
              "barycenter and statistics match pyspi (with np.random.seed(seed) set before the call) to atol 1e-10 at T=64 and 256"),
        check(["bivariate_gaussian", "delayed_noise", "logistic_maps"], "kernel",
              "Fréchet cost F(b) from the from-scratch DTW, comparing pyspi sgddtw output with from-scratch MM-DBA and with from-scratch SSG run 30 epochs without early stopping", "independent-impl", "optimality",
              "F(sgddtw) > F(30-epoch SSG) > F(MM-DBA) in most pairs; report the relative gaps (probe4 suggests 15-80%)"),
        check(["bivariate_gaussian", "iid_gaussian"], "pipeline",
              "repeat pyspi computation under 50 different np.random.seed values; numpy summary of the spread", "analytic", "statistical",
              "non-zero spread for all four identifiers; report SD of bary_sgddtw_mean (expected ~1e-3) and bary_sgddtw_max (expected ~1e-1) relative to the between-pair range"),
        check(["iid_gaussian"], "kernel",
              "analytic: SSG on (x, x) from init x has zero subgradient (V b - W x = 0 on the diagonal path)", "analytic", "exact",
              "barycenter equals x exactly (probe3 max|b-x| = 0)"),
        SYM_CHECK('sgddtw'),
    ],
)

# ---------------- Soft-DTW -----------------
records['distance.bary.softdtw'] = dict(
    metric_name_standard='Summary (time-mean or time-max) of the soft-DTW barycenter (gamma = 1) of two z-scored series; squared variant summarises its square',
    canonical_ref='Cuturi & Blondel 2017, ICML, PMLR 70:894-903 (soft-DTW, §2 eq. 1-2 and barycenter §4 eq. 4, Alg. 1-2 forward/backward recursions); bias of soft-DTW (sdtw_gamma(x,x) != 0): Blondel, Mensch & Vert 2021, AISTATS, PMLR 130:3853-3861. Mean/max summary: pyspi construction.',
    canonical_definition='b* in argmin_b sum_k lambda_k dtw_gamma(b, x_k), dtw_gamma(b,x) = -gamma log sum_{A in paths} exp(-<A, Delta(b,x)>/gamma), Delta_ts = (b_t - x_s)^2; smooth and differentiable, recovers the DTW barycenter as gamma -> 0; SPI = mean_t b(t) or max_t b(t) (squared: of b(t)^2).',
    documented_definition=DOC + ' Mode softdtw is documented as "alignment via a differential loss function"; supplement §1.2.9 (p.6-7) gives the soft-DTW default gamma = 1.',
    delegate_lib='tslearn==0.9.0 tslearn.barycenters.softdtw_barycenter (defaults gamma=1.0, weights=None -> ones, method="L-BFGS-B", tol=1e-3, max_iter=50, init = Euclidean barycenter) via scipy==1.17.1 scipy.optimize.minimize, numba soft-DTW kernels',
    implemented_as=('z-scored pair (ddof=1). Init b0 = (x+y)/2. Objective f(b) = sum_k sdtw_1(D(b,x_k)) with D squared Euclidean and unit (unnormalised) weights; gradient by the soft-DTW backward recursion '
                    'and Jacobian 2(b_t - x_s)E_ts; scipy L-BFGS-B with ftol = gtol = 1e-3 and maxiter 50; res.x returned without checking res.success. gamma = 1 is fixed (pyspi exposes no parameter). '
                    'Deterministic and order-invariant (probe2 order-diff 0). Then nanmean/nanmax of b or b**2.'),
    implementation_trace=common("pyspi/statistics/distance.py:224-225 mode 'softdtw' -> self._fn = softdtw_barycenter") + [
        f"{TS}/barycenters/softdtw.py:38-39 softdtw_barycenter(X, gamma=1.0, weights=None, method='L-BFGS-B', tol=1e-3, max_iter=50, init=None)",
        f"{TS}/barycenters/softdtw.py:94-99 to_time_series_dataset, _set_weights -> ones, init = euclidean_barycenter",
        f"{TS}/barycenters/softdtw.py:106-115 minimize(f, b0, method, jac=True, tol=tol, options=dict(maxiter=max_iter)); returns res.x (no success check)",
        f"{TS}/barycenters/softdtw.py:19-35 _softdtw_func: obj = sum_i w_i SoftDTW(SquaredEuclidean(Z, X_i), gamma).compute(); G = sum_i w_i D.jacobian_product(sdtw.grad())",
        f"{TS}/metrics/softdtw_variants.py:1068-1135 SoftDTW.__init__/compute (R_[m, n] from _njit_soft_dtw)",
        f"{TS}/metrics/softdtw_variants.py:1137-1173 SoftDTW.grad (_njit_soft_dtw_grad, returns E[1:-1, 1:-1])",
        f"{TS}/metrics/softdtw_variants.py:1176-1216 SquaredEuclidean.compute = pairwise_euclidean_distances(X, Y)**2; 1218-1240 jacobian_product",
        f"{TS}/metrics/soft_dtw_fast.py:15-39 _njit_softmin3 (soft-min with gamma); 101-125 _njit_soft_dtw forward recursion R[i,j] = D[i-1,j-1] + softmin(R[i-1,j], R[i-1,j-1], R[i,j-1])",
        f"{TS}/metrics/soft_dtw_fast.py:205-234 _njit_soft_dtw_grad backward recursion for E",
        f"{TS}/metrics/soft_dtw_fast.py:318-340 _njit_jacobian_product_sq_euc: G[i,k] += E[i,j]*2*(X[i,k]-Y[j,k])",
        ".venv/lib/python3.12/site-packages/scipy/optimize/_minimize.py:677-681 tol -> options ftol and gtol for L-BFGS-B",
    ],
    deviation_from_documented=LABEL_DEV + ' gamma = 1 is the stated soft-DTW default (§1.2.9) and is used here. bary-sq_softdtw_* undocumented.',
    deviation_from_canonical=('Objective and gradient follow Cuturi & Blondel 2017. Practical deviations: gamma = 1 is large relative to the per-sample squared differences of z-scored data, so the barycenter is strongly smoothed '
                              'and shrunk toward 0; soft-DTW is not a divergence (sdtw_gamma(x,x) < 0, != 0), so the barycenter of identical series is not that series. Probe3: softdtw barycenter of (x, x) has max|b-x| = 1.249, '
                              'var(b) = 0.704 vs var(x) = 0.996 (DBA returns x exactly). Probe2 narrowband_f0-0.25: max(b) = 0.83-0.86 vs 1.31-1.34 for DBA. Optimiser tolerance 1e-3 (relative function reduction) is loose; '
                              'in probes all runs converged (nit 4-13, success True). Mean/max summaries are pyspi-defined.'),
    units_and_range='z-score units. mean: small, either sign (probe2 -0.0243 .. 0.0036 across 9 runs). max: positive, systematically smaller than the DBA/Euclidean max. sq variants >= 0. Objective values negative (probe2 -84 .. -1669). Finite for finite input. Symmetric.',
    direction_convention='undirected: A[i,j] = A[j,i] bit-identical via the cache; the routine is order-invariant (Euclidean init and symmetric objective; probe2 order-diff 0)',
    symmetry_expected='sym',
    already_documented='no (tests/README.md bug 3 concerns the SoftDynamicTimeWarping distance class ignoring global_constraint, not this barycenter; Barycenter exposes no constraint)',
    new_finding_candidates=[
        'Candidate: with gamma = 1 on z-scored data the soft-DTW barycenter is biased (shrunk/smoothed), so bary_softdtw_max is systematically lower than the DTW-barycenter max and the barycenter of two identical series differs from the series. Evidence: probe3 max|b-x| = 1.249, var(b) 0.704 vs 0.996; probe2 narrowband max 0.834 (T=64) vs DBA 1.336; consistent with Blondel et al. 2021 (soft-DTW is not a divergence).',
        'Candidate: optimiser tolerance tol=1e-3 (ftol/gtol) and max_iter=50 with no success check (softdtw.py:113-115) could return a non-converged barycenter for long series; not observed in probes (success True, nit <= 13 for T <= 1024), to be checked at T=4096.',
        'Candidate: cost: each objective evaluation is O(T^2) per series; probe2 timing 2.5-3.3 s per pair at T=1024, which makes this the dominant barycenter cost (relevant to optimisation stage).',
        'Candidate: label inconsistencies and undocumented bary-sq_softdtw_* identifiers, see deviation_from_documented.',
    ],
    proposed_checks=[
        check(["bivariate_gaussian", "delayed_noise", "narrowband_f0-0.25"], "kernel",
              "from-scratch numpy soft-DTW (forward recursion with log-sum-exp soft-min, backward E recursion per Cuturi & Blondel 2017 Alg. 2) + scipy.optimize.minimize L-BFGS-B with identical init, tol 1e-3, maxiter 50", "independent-impl", "tolerance",
              "objective and gradient at b0 match tslearn to rtol 1e-10; final barycenter statistics match pyspi to rtol 1e-6 at T=64 and 256 (optimiser path sensitivity may cause small differences)"),
        check(["bivariate_gaussian", "iid_gaussian"], "kernel",
              "central finite differences of the from-scratch soft-DTW objective", "independent-impl", "tolerance",
              "analytic gradient used by tslearn agrees with finite differences to rtol 1e-6 (validates the optimised objective)"),
        check(["bivariate_gaussian", "delayed_noise", "narrowband_f0-0.25"], "kernel",
              "re-optimise from the pyspi barycenter with the from-scratch objective, L-BFGS-B tol 1e-12, maxiter 2000", "independent-impl", "optimality",
              "relative objective decrease <= 1e-3 and change in bary_softdtw_mean/max small (report); at T=1024/4096 report whether pyspi stopped short"),
        check(["iid_gaussian", "narrowband_f0-0.25"], "kernel",
              "analytic contrast: Fréchet mean of (x, x) under any divergence is x; compare with from-scratch soft-DTW barycenter for gamma in {1, 0.1, 0.01}", "analytic", "qualitative",
              "gamma = 1 barycenter deviates from x (shrinkage, var(b) < var(x)); deviation decreases as gamma -> 0, documenting the bias"),
        SYM_CHECK('softdtw'),
    ],
)

for uid, corr in records.items():
    rec = dict(unit_id=uid, status='traced', correctness=corr)
    (OUT / f'{uid}.yaml').write_text(yaml.safe_dump(rec, sort_keys=False, allow_unicode=True, width=1000))
    print('wrote', uid)
