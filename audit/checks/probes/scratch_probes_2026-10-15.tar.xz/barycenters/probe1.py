import warnings, numpy as np, inspect
from scipy.stats import zscore, pearsonr
from pyspi.statistics.distance import Barycenter
from pyspi.data import Data
import tslearn
from tslearn.barycenters import dtw_barycenter_averaging, dtw_barycenter_averaging_subgradient, softdtw_barycenter, euclidean_barycenter
print("tslearn", tslearn.__version__)
d = np.load('/media/dan/Data/git/pyspi/audit/checks/data/bivariate_gaussian_T256.npz')
print(list(d.keys()))
X = d['x']
print(X.shape)
data = Data(X, normalise=True)
Z = data.to_numpy(squeeze=True)
print("Z means", Z.mean(1), "Z ddof1 std", Z.std(1, ddof=1))
T = Z.shape[1]
for sq in (False, True):
  for stat in ("mean","max","max_time"):
    s = Barycenter(mode="euclidean", squared=sq, statistic=stat)
    A = s.multivariate(Data(X, normalise=True))
    print(s.identifier, s.labels, s.issigned(), "\n", np.array2string(A, precision=6))
r = np.corrcoef(Z)
print("predicted sq-mean (1+r)(T-1)/(2T):\n", np.array2string((1+r)*(T-1)/(2*T), precision=6))
print("predicted max (x+y)/2:", np.max((Z[0]+Z[1])/2), " sq-max:", np.max(((Z[0]+Z[1])/2)**2))
