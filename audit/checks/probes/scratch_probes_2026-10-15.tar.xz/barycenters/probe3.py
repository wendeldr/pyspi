import warnings, numpy as np
warnings.simplefilter("ignore")
from pyspi.statistics.distance import Barycenter
from pyspi.data import Data
from tslearn.barycenters import dtw_barycenter_averaging, dtw_barycenter_averaging_subgradient, softdtw_barycenter
base='/media/dan/Data/git/pyspi/audit/checks/data/'
X = np.load(f'{base}bivariate_gaussian_T256.npz')['x']
# (a) sgddtw unseeded repeat
s = Barycenter(mode="sgddtw")
A1 = s.multivariate(Data(X, normalise=True)); A2 = s.multivariate(Data(X, normalise=True))
print("sgddtw repeat (unseeded) max|A1-A2| =", np.nanmax(np.abs(A1-A2)))
np.random.seed(5); A3 = s.multivariate(Data(X, normalise=True)); np.random.seed(5); A4 = s.multivariate(Data(X, normalise=True))
print("sgddtw repeat (seeded 5) max|A3-A4| =", np.nanmax(np.abs(A3-A4)), " symmetric:", np.allclose(A3, A3.T, equal_nan=True))
# cache sharing across statistics on the same Data
d = Data(X, normalise=True)
np.random.seed(5); m = Barycenter(mode="sgddtw", statistic="mean").multivariate(d)
st = np.random.get_state()[2]
mx = Barycenter(mode="sgddtw", statistic="max").multivariate(d)
print("cache keys:", list(d.barycenter.keys()), "n pairs cached:", len(d.barycenter['sgddtw']), " RNG pos after mean:", st, "after max:", np.random.get_state()[2])
# (b) order dependence of sgddtw with same seed
Z = d.to_numpy(squeeze=True)
np.random.seed(0); a = dtw_barycenter_averaging_subgradient(Z[[1,0]])
np.random.seed(0); b = dtw_barycenter_averaging_subgradient(Z[[0,1]])
print("sgddtw same seed, swapped order: max|diff| =", np.max(np.abs(a-b)), " mean diff", a.mean()-b.mean())
# (c) Frechet mean of {x,x}
x = Z[0]
for nm, f in [("dtw", dtw_barycenter_averaging), ("sgddtw", dtw_barycenter_averaging_subgradient), ("softdtw", softdtw_barycenter)]:
    bb = f(np.stack([x, x]))
    print(f"{nm}: bary of (x,x): max|b-x| = {np.max(np.abs(bb.ravel()-x)):.4f}  mean(b)={bb.mean():.4f} max(b)={bb.max():.4f} vs max(x)={x.max():.4f}; var(b)={bb.var():.4f}")
# (d) max_time and NaN
st = Barycenter(mode="euclidean", statistic="max_time")
print("max_time value type:", type(st.bivariate(Z[0], Z[1])), st.bivariate(Z[0], Z[1]), "argmax check", np.argmax((Z[0]+Z[1])/2))
# (e) multivariate computation order: first computed key
d2 = Data(X[:3], normalise=True); Barycenter(mode="dtw").multivariate(d2)
print("insertion order of cache keys:", list(d2.barycenter['dtw'].keys()))
