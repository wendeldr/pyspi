import warnings, io, contextlib, numpy as np, time
from pyspi.statistics.distance import Barycenter
from pyspi.data import Data
import tslearn.barycenters.softdtw as sdmod
from tslearn.barycenters import dtw_barycenter_averaging, dtw_barycenter_averaging_subgradient, softdtw_barycenter
from tslearn.metrics import dtw, soft_dtw
captured = []
_orig = sdmod.minimize
def spy(*a, **k):
    r = _orig(*a, **k); captured.append(r); return r
sdmod.minimize = spy
base='/media/dan/Data/git/pyspi/audit/checks/data/'
for name in ["bivariate_gaussian", "delayed_noise", "narrowband_f0-0.25"]:
  for T in (64, 256, 1024):
    X = np.load(f'{base}{name}_T{T}.npz')['x']
    Z = Data(X, normalise=True).to_numpy(squeeze=True)
    i, j = 1, 0
    xy = Z[[i, j]]; yx = Z[[j, i]]
    # DBA
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        b1 = dtw_barycenter_averaging(xy, verbose=True)
    n_ep = buf.getvalue().count("[DBA]")
    b2 = dtw_barycenter_averaging(yx)
    cost = np.mean([dtw(b1, z)**2 for z in xy])
    eu = (xy[0]+xy[1])/2
    cost_eu = np.mean([dtw(eu[:,None], z)**2 for z in xy])
    print(f"{name} T={T} DBA epochs={n_ep} warns={[str(x.message)[:40] for x in w]} order-diff={np.max(np.abs(b1-b2)):.3g} cost={cost:.4f} cost_init_eu={cost_eu:.4f} mean={b1.mean():.4f} max={b1.max():.4f}")
    # SGD
    buf = io.StringIO()
    np.random.seed(0)
    with contextlib.redirect_stdout(buf), warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        s1 = dtw_barycenter_averaging_subgradient(xy, verbose=True)
    n_ep = buf.getvalue().count("[DBA]") // 2
    np.random.seed(0); s1b = dtw_barycenter_averaging_subgradient(xy)
    np.random.seed(1); s2 = dtw_barycenter_averaging_subgradient(xy)
    costs = np.mean([dtw(s1, z)**2 for z in xy])
    print(f"   SGD epochs={n_ep} warns={[str(x.message)[:40] for x in w]} same-seed-diff={np.max(np.abs(s1-s1b)):.3g} seed0-vs-seed1 diff={np.max(np.abs(s1-s2)):.3g} mean diff={abs(s1.mean()-s2.mean()):.3g} cost={costs:.4f} mean={s1.mean():.4f}")
    # softdtw
    captured.clear()
    t0=time.time(); sb = softdtw_barycenter(xy); dt=time.time()-t0
    r = captured[-1]
    sb2 = softdtw_barycenter(yx)
    print(f"   SOFT success={r.success} nit={r.nit} nfev={r.nfev} msg={str(r.message)[:50]} obj={r.fun:.4f} order-diff={np.max(np.abs(sb-sb2)):.3g} mean={sb.mean():.4f} max={sb.max():.4f} t={dt:.2f}s")
