import warnings, io, contextlib, numpy as np
warnings.simplefilter("ignore")
from pyspi.data import Data
from tslearn.barycenters import dtw_barycenter_averaging_subgradient as ssg
from tslearn.barycenters.dba import _mm_assignment, _subgradient_valence_warping, _subgradient_update_barycenter
from tslearn.metrics import dtw
base='/media/dan/Data/git/pyspi/audit/checks/data/'
for name,T in [("bivariate_gaussian",256),("delayed_noise",1024)]:
    Z = Data(np.load(f'{base}{name}_T{T}.npz')['x'], normalise=True).to_numpy(squeeze=True)
    X = Z[[1,0]][:,:,None]
    np.random.seed(0)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf): b = ssg(Z[[1,0]], verbose=True)
    lines = [float(l.split("cost: ")[1]) for l in buf.getvalue().splitlines()]
    print(name, T, "per-sample costs logged (2 per epoch):", [round(v,2) for v in lines])
    # no-stop SSG for 30 epochs, same schedule
    rng = np.random.RandomState(0); bar = X.mean(0).copy(); eta = .05; w = np.ones(2)
    fc = []
    for it in range(30):
        for idx in rng.permutation(2):
            p, c = _mm_assignment(X[idx:idx+1], bar, w, None)
            v, W = _subgradient_valence_warping(p, T, w[idx:idx+1])
            bar = _subgradient_update_barycenter(X[idx:idx+1], v, W, 1., bar, eta)
            if it == 0: eta -= (.05-.005)/2
        fc.append(np.mean([dtw(bar, z)**2 for z in X]))
    print("  tslearn-stopped Frechet cost:", round(np.mean([dtw(b, z)**2 for z in X]),3), " no-stop 30-epoch cost trajectory:", [round(v,2) for v in fc[::5]], "final", round(fc[-1],3))
