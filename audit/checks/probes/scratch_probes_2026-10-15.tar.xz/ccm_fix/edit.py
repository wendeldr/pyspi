import yaml
R='/media/dan/Data/git/pyspi/audit/records/causal.ccm.%s.yaml'
TIE_IMPL=(' Neighbour ties: when the (E+1)-th neighbour distance is tied, cppEDM keeps every tied library row and splits'
 ' the boundary weight over them (EDM_Neighbors.cc L276-345, Simplex.cc L90-157), and exactly-zero distances get weight 1'
 ' with all others at the 1e-6 floor (Simplex.cc L57-70), so the neighbour set can exceed E+1. On logistic_maps the embedded'
 ' process 1 (period-4 driver, 4 distinct values) has tied neighbours at every prediction row (probe fable_dt3/fm2.py, T=256,'
 ' full library: 256 of 256 rows at E=1, 247 of 247 at E=10), so the whole ccmf[1,0] curve on that dataset comes from the'
 ' tie-expansion path, not from an ordinary E+1-neighbour simplex.')
SIMPLEX_TRACE=('https://github.com/SugiharaLab/cppEDM/blob/v1.15.2/src/Simplex.cc#L34-L167 weights exp(-d/d_min); minWeight'
 ' 1e-6 (L44) applied as a floor (L76-80); all-zero-distance special case (L57-70: weight 1 for zero distance, minWeight'
 ' otherwise); tie expansion (L90-157: neighbour set extended to all rows tied with the knn-th distance, flagged in'
 ' EDM_Neighbors.cc L276-345, weights from the first tie onward scaled by tieFactor); prediction = sum(w*target[nn+Tp])/sum(w), Tp = 0')
def ref0(E):
    return ('from-scratch numpy simplex cross-map (Sugihara 2012 SOM: E+1 nearest neighbours by Euclidean distance on tau=1'
     ' delay vectors, self excluded, weights exp(-d/d_min) floored at 1e-6, Tp=0, Pearson rho over prediction rows E-1..N-1)'
     ' with the full deterministic library; compared with pyEDM.CCM(random=False, libSizes=str(N-E+1)) at E=%s; T in {256,'
     ' 1024}. To cover tied neighbours the reference must also implement cppEDM tie handling (zero-distance weights,'
     ' Simplex.cc L57-70; tie detection EDM_Neighbors.cc L276-345; tie expansion and tieFactor, Simplex.cc L90-157);'
     ' a plain E+1 argsort reference is valid only for tie-free columns' % E)
def exp0(E, num):
    return ('max |rho_scratch - rho_pyEDM| < 1e-12 for every tie-free column: both columns of nonlinear_dependence and'
     ' var2_bivariate and logistic_maps proc0:proc1 (probe fable_dt3/fm2.py, T=256: |diff| <= 3.3e-16, 0 tied rows; the'
     ' earlier trace probe matched to ~1e-16 for E=1 and E=3 on a tie-free toy x1=x0^2 pair). logistic_maps proc1:proc0'
     ' (embedding of the period-4 process 1, ties at every prediction row) is expected to match only if the reference'
     ' implements the cppEDM tie handling; a plain E+1 reference differs (probe at E=%s: %s). Report the tied column separately'
     ' from the tie-free columns. Establishes that "col:target" = predict target from the embedding of col' % (E, num))
NUM={'1':'pyEDM 0.258036085716451 vs plain reference 0.016209343992146, diff 0.24',
     '10':'pyEDM 0.412996812927705 vs plain reference 0.408547833137669, diff 4.4e-3'}
DIR_ADD=(' Second caveat: on logistic_maps the A[1,0] curve (embedding of the period-4 process 1) is produced entirely by'
 ' cppEDM tie expansion (ties at every prediction row), so no plain E+1-neighbour reference reproduces that column'
 ' (probe fable_dt3/fm2.py); this further favours the chaotic-driver dataset for the direction check')
for u in ('E-None','E-1','E-10'):
    p=R%u; d=yaml.safe_load(open(p)); c=d['correctness']
    assert TIE_IMPL not in c['implemented_as']
    if u=='E-None':
        old='knn = E+1 = 11, no exclusion radius'
        assert old in c['implemented_as']
        c['implemented_as']=c['implemented_as'].replace(old,'knn = E+1 = 11 (more with ties, see below), no exclusion radius')
    elif u=='E-1':
        old='knn = 2, Tp = 0'; assert old in c['implemented_as']
        c['implemented_as']=c['implemented_as'].replace(old,'knn = 2 (more with ties, see below), Tp = 0')
    else:
        old='knn = 11, Tp = 0'; assert old in c['implemented_as']
        c['implemented_as']=c['implemented_as'].replace(old,'knn = 11 (more with ties, see below), Tp = 0')
    c['implemented_as']=c['implemented_as'].rstrip()+TIE_IMPL
    tr=c['implementation_trace']; k=[i for i,t in enumerate(tr) if 'Simplex.cc#L34-L167' in t]; assert len(k)==1
    tr[k[0]]=SIMPLEX_TRACE
    Ev='10' if u=='E-None' else u[2:]
    pc=c['proposed_checks']
    assert pc[0]['criterion']=='exact' and 'from-scratch numpy simplex cross-map' in pc[0]['reference']
    pc[0]['reference']=ref0(Ev); pc[0]['expected_outcome']=exp0(Ev, NUM[Ev])
    assert pc[3]['criterion']=='direction'
    pc[3]['expected_outcome']=pc[3]['expected_outcome'].rstrip().rstrip('.')+'.'+DIR_ADD
    if u=='E-None':
        old_dc=c['deviation_from_canonical']
        a=old_dc.index('(1)'); b=old_dc.index('(2)')
        c['deviation_from_canonical']=old_dc[:a]+('(1) E is fixed at 10 instead of chosen by simplex forecast skill. The'
          ' documented rule (one E = max(E_i, E_j) for both directions) is attributed by the supplement (p.9) to the Sugihara'
          ' 2012 Supplementary Materials and the pyEDM documentation, and pyEDM/cppEDM take one E per CCM call; whether each'
          ' direction should instead use the E of the variable being embedded is an interpretation, not a sourced canonical'
          ' rule (no Sugihara 2012 passage prescribing per-direction E was located). ')+old_dc[b:]
        nf=c['new_finding_candidates']
        w=[i for i,t in enumerate(nf) if t.startswith('CANDIDATE wasted work')]; assert len(w)==1
        del nf[w[0]]
        q=[i for i,t in enumerate(nf) if t.startswith('CANDIDATE intended-design question')]; assert len(q)==1
        nf[q[0]]=('CANDIDATE intended-design question (interpretation, not a sourced deviation): even the documented rule'
          ' applies max(E_i, E_j) to both cross-map directions (causal.py:123), and EmbedDimension uses lib == pred (rows'
          ' 10..N-10) with leave-one-out only. Each direction reconstructs a different variable\'s shadow manifold, so a'
          ' per-direction E is a possible alternative; the supplement (p.9) attributes the max rule to the Sugihara 2012'
          ' Supplementary Materials and pyEDM uses one E per CCM call, so this is a question for the maintainers, not a'
          ' deviation from a cited canonical rule.')
        c['already_documented']=c['already_documented'].rstrip()+('. Elaboration of bug 2 (not a new candidate): the'
          ' EmbedDimension runs (10 simplex fits per process, causal.py:102-111) are computed and their rho discarded, and'
          ' the three ccm_E-None_* outputs are bitwise equal to ccm_E-10_* (probe p7, var2_bivariate T=256); a fix (argmax'
          ' rho) should be tested against the documented intent rather than against the snapshot goldens; the cost of the'
          ' discarded EmbedDimension runs belongs to the optimisation stage.')
    open(p,'w').write(yaml.safe_dump(d,sort_keys=False,width=120,allow_unicode=True))
    print('ok',u)
