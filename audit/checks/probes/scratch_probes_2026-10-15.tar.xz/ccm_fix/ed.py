import numpy as np, pandas as pd, pyEDM, warnings
warnings.simplefilter('ignore')
from scipy.stats import zscore
x=zscore(np.load('/media/dan/Data/git/pyspi/audit/checks/data/logistic_maps_T256.npz')['x'][:2],axis=1,ddof=1); N=x.shape[1]
df=pd.DataFrame(np.c_[np.arange(N),x.T],columns=['index','proc0','proc1'])
def simplex(s,E,lo,hi):
    # lib = pred = rows lo..hi (1-based inclusive in cppEDM), Tp=1
    idx=np.arange(lo-1,hi)  # 0-based
    idx=idx[idx>=E-1]; idx=idx[idx+1<N]
    emb=np.stack([s[idx-k] for k in range(E)],1); pred=np.empty(len(idx)); nt=0
    for a in range(len(idx)):
        d=np.sqrt(((emb-emb[a])**2).sum(1)); d[a]=np.inf
        o=np.argsort(d,kind='stable'); dk=d[o]
        if np.any(np.abs(dk[E+1:]-dk[E])<1e-12): nt+=1
        o=o[:E+1]; dk=dk[:E+1]
        w=np.exp(-dk/dk[0]) if dk[0]>0 else (dk==0).astype(float)
        w=np.maximum(w,1e-6); pred[a]=(w*s[idx[o]+1]).sum()/w.sum()
    return np.corrcoef(s[idx+1],pred)[0,1],nt
for c in ('proc0','proc1'):
    ed=pyEDM.EmbedDimension(dataFrame=df,lib=f"10 {N-10}",pred=f"10 {N-10}",columns=c,target=c,showPlot=False)
    s=x[int(c[-1])]
    for E in (1,2,5,10):
        r,nt=simplex(s,E,10,N-10)
        print(c,E,'pyEDM',ed.loc[ed.E==E,'rho'].values[0],'scratch',r,'tierows',nt)
