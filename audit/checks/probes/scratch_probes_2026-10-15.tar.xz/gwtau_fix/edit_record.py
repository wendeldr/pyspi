p='/media/dan/Data/git/pyspi/audit/records/distance.gwtau.yaml'
s=open(p,encoding='utf8').read()
def rep(old,new):
    global s
    assert s.count(old)==1, old[:60]
    s=s.replace(old,new)

rep("""(PMC10326159): Def. 1 Eq. 5,
    Def. 2 Eqs. 6, 8, 10, closed forms Eqs. 11-12, Prop. 1(a) GWτ = W_p of root-distance push-forwards,
    Prop. 1(b) GW <= GWτ.""",
"""(PMC10326159): Def. 1 Eq. 5 (GWτ, general case);
    Def. 2 Eqs. 6-7 (point sets X, Y), Eqs. 8-9 (polygonal arc length d_X, d_Y), Eq. 10 (empirical GWτ),
    with the uniform measures mu_X, mu_Y given as an unnumbered display after Eq. 9; closed forms Eqs. 11
    (equal sizes) and 12 (unequal sizes, lambda_ij weights) in the proof of Prop. 1(e); Prop. 1(a) GWτ =
    W_p of root-distance push-forwards, Prop. 1(b) GW <= GWτ. Equation labels read from the Europe PMC
    JATS full text (ebi.ac.uk/europepmc/webservices/rest/PMC10326159/fullTextXML, <label> of Equ1-Equ12;
    the measure display Equ16 has no label); the journal PDF was not separately consulted.""")

rep("""uniform measure mu_X = sum_{i=1}^n (1/n) delta_{x_i}; intrinsic""",
"""uniform measure mu_X = sum_{i=1}^n (1/n) delta_{x_i} (unnumbered display in Def. 2); intrinsic""")

rep("""(1) Documented keyword "unordered" (distance.py:271, config.yaml:314-320, GitBook line 166) is
    inconsistent with the computation: the value depends on the temporal order of samples through the
    increments x_{t+1}-x_t (probe: jointly permuting both series with one permutation changed the value
    from 13.527 to 5.126 at T=256); in pyspi's label scheme comparable order-dependent distances (dtw,
    dcorrx, mgcx, bary, xcorr) carry "temporal".""",
"""(1) Keyword "unordered" (distance.py:271, config.yaml:314-320, GitBook line 166): neither
    "unordered" nor "temporal" is defined anywhere in the documentation. The GitBook keyword table
    (spis/glossary-of-terms.md:21) defines Undirected, Directed, Linear, Nonlinear, Signed, Univariate,
    Bivariate, Multivariate, Contemporaneous, Time-dependent, Frequency-dependent and Time-frequency
    dependent only, and development/development/incorporating-new-spis.md:430,546 describes labels only
    as "descriptive keywords" used for filtering (that page uses gwtau's own label list as its worked
    example, lines 441, 516, 558). There is therefore no documented definition to deviate from. The
    inconsistency is with sibling usage: the value depends on the temporal order of samples through the
    increments x_{t+1}-x_t (probe: jointly permuting both series with one permutation changed the value
    from 13.527 to 5.126 at T=256), while the order-dependent distances in the same file carry "temporal"
    (dcorrx distance.py:119, mgcx :139, dtw family :156, bary :215; xcorr in basic.py likewise). Read
    as the opposite of "temporal", "unordered" does not describe the computation.""")

rep("""(3) GitBook "robust to shifts" is not
    generally true on sampled data (see candidates: phase shift of a sampled sinusoid at f0=0.25 gives a
    distance growing ∝ T). Otherwise the computation matches the GitBook prose.""",
"""(3) GitBook "robust to shifts" does not say
    what is shifted (time, phase, amplitude). For time shifts it contradicts the cited source paper,
    whose design intent is the opposite: Kravtsova et al. 2023, section "Empirical Results on Synthetic,
    Model-Based, and Publicly Available Real-World Data": "GWτ is able to distinguish between shifts since
    a shifted version of a trajectory has a different distribution of intrinsic distances, and the larger
    the shift, the easier it is for GWτ to distinguish between the trajectories", and "successfully
    capturing time shifts as class indicators is a desirable property". The paper's only robustness
    statement is narrower: for oscillations with "slight phase shifts within the class", "Slightly shifted
    versions of qualitatively similar trajectories will be matched by an optimal transport routine
    producing a small distance". Separately, on sampled data even that narrower statement fails for a
    phase shift relative to the sampling grid (see candidates: sampled sinusoid at f0=0.25 shifted by
    pi/4 gives a distance growing ∝ T). The constant offset x -> x + c is the one shift the value is
    exactly invariant to (z-scoring removes it, and gwtau(z, z + c) ~ 1e-14 without z-scoring). Otherwise
    the computation matches the GitBook prose.""")

rep("""      Candidate (label): "unordered" label is wrong for gwtau; the statistic depends on temporal order.
      Evidence: probe1 joint permutation of both z-scored series (same permutation) changed gwtau
      13.527087919699273 -> 5.126367497972419 (T=256, seed 0); computation uses np.diff along time
      (distance.py:275). Order-dependent siblings in distance.py carry "temporal" (lines 119, 139, 156, 215).""",
"""      Candidate (label): "unordered" label is inconsistent with sibling usage for gwtau; the statistic
      depends on temporal order. Neither "unordered" nor "temporal" is defined in the GitBook keyword
      table (spis/glossary-of-terms.md:21) or the development docs (incorporating-new-spis.md:430,546), so
      this is a labelling inconsistency, not a deviation from a documented definition. Evidence: probe1
      joint permutation of both z-scored series (same permutation) changed gwtau 13.527087919699273 ->
      5.126367497972419 (T=256, seed 0); computation uses np.diff along time (distance.py:275).
      Order-dependent siblings in distance.py carry "temporal" (lines 119, 139, 156, 215).""")

rep("""      Candidate (doc claim "robust to shifts"): on sampled sinusoids the arc length depends on phase
      relative to the sampling grid, so two phase-shifted copies of the same oscillation can get a distance
      growing ∝ T.""",
"""      Candidate (doc claim "robust to shifts"): two separate points. (i) Time-shift sensitivity is
      intended by the source paper, so the GitBook sentence contradicts Kravtsova et al. 2023 regardless
      of sampling: "GWτ is able to distinguish between shifts since a shifted version of a trajectory has
      a different distribution of intrinsic distances, and the larger the shift, the easier it is for GWτ
      to distinguish" (section "Empirical Results on Synthetic, Model-Based, and Publicly Available
      Real-World Data"). (ii) The paper does claim small distances for "slightly shifted versions" of
      oscillations; on sampled sinusoids the arc length depends on phase relative to the sampling grid,
      so two phase-shifted copies of the same oscillation can get a distance growing ∝ T.""")

rep("""      drift 0.114 per step gives RMS ~ 0.114*T/sqrt(3) ~ 270 at T=4096, matching 267.9. Property of the
      canonical construction on discrete data.""",
"""      drift 0.114 per step gives RMS ~ 0.114*T/sqrt(3) ~ 269.6 at T=4096, matching 267.9. Noise-free
      probe (gwtau_fix/probe_shift.py: z-scored cos(pi t/2) vs cos(pi t/2 + pi/4)): 16.50 at T=256 and
      269.27 at T=4096 (prediction 16.85 / 269.63); the -pi/2 copy gives ~1e-13 / ~2e-11. Point (ii) is an
      additional effect of the canonical construction on discrete data, separate from point (i).""")
open(p,'w',encoding='utf8').write(s)
