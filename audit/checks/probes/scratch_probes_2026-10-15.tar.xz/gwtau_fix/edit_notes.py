p='/media/dan/Data/git/pyspi/audit/notes/gwtau.md'
s=open(p,encoding='utf8').read()
def rep(old,new):
    global s
    assert s.count(old)==1, old[:60]
    s=s.replace(old,new)
rep("""- A 1-D series becomes the planar trajectory f(t) = (t, h(t)) with points x_i = f(t_i), i = 1..n.
- Each point has uniform mass 1/n (Def. 2, Eq. 6).
- The intrinsic distance is the polygonal arc length d_X(x_i, x_j) = Σ_{k=i}^{j-1} ‖f(t_{k+1}) − f(t_k)‖
  (Eq. 8).""",
"""- A 1-D series becomes the planar trajectory f(t) = (t, h(t)) with points x_i = f(t_i), i = 1..n
  (Def. 2, Eqs. 6-7).
- Each point has uniform mass 1/n. In Def. 2 this measure is an unnumbered display after Eq. 9.
- The intrinsic distance is the polygonal arc length d_X(x_i, x_j) = Σ_{k=i}^{j-1} ‖f(t_{k+1}) − f(t_k)‖
  (Eqs. 8-9).""")
rep("""- Closed forms: Eq. 11 (equal sizes, sorted matching) and Eq. 12 (unequal sizes, quantile-overlap
  weights λ_ij).""",
"""- Closed forms: Eq. 11 (equal sizes, sorted matching) and Eq. 12 (unequal sizes, quantile-overlap
  weights λ_ij), both in the proof of Prop. 1(e).

Equation labels were read from the Europe PMC JATS full text of PMC10326159 (the `<label>` of each
display formula; the measure display has none). The journal PDF was not consulted separately.""")
rep("""- *"unordered" label (candidate).* The statistic depends on temporal order through Δx_t.
  - Probe: one common random permutation of both series changes the value from 13.527 to 5.126
    (T = 256).
  - The order-dependent distance SPIs in the same file carry the label "temporal"
    (`distance.py:119, 139, 156, 215`).""",
"""- *"unordered" label (candidate).* No documentation defines either "unordered" or "temporal".
  - The GitBook keyword table (`spis/glossary-of-terms.md:21`) defines 12 keywords, including
    Contemporaneous and Time-dependent, but neither of these two.
  - `development/development/incorporating-new-spis.md:430,546` describes labels only as descriptive
    keywords used for filtering. That page uses gwtau's own labels as its worked example.
  - So this is not a deviation from a documented definition. It is an inconsistency with how sibling
    SPIs use the labels.
  - The statistic depends on temporal order through Δx_t. Probe: one common random permutation of both
    series changes the value from 13.527 to 5.126 (T = 256).
  - The order-dependent distance SPIs carry the label "temporal": `distance.py:119` (dcorrx), `:139`
    (mgcx), `:156` (dtw, lcss, softdtw), `:215` (bary), and `basic.py:78` (xcorr).""")
rep("""- *"robust to shifts" (candidate).* Delayed white noise stays small compared with independent pairs:
  3.6-6.5 vs 22-53 at T = 4096. A phase-shifted sampled sinusoid does not.""",
"""- *"robust to shifts" (candidate).* The GitBook does not say what kind of shift it means. There are
  two separate points.
  - **The claim contradicts the source paper for time shifts.** Kravtsova et al. (2023), section
    "Empirical Results on Synthetic, Model-Based, and Publicly Available Real-World Data", say: "GWτ is
    able to distinguish between shifts since a shifted version of a trajectory has a different
    distribution of intrinsic distances, and the larger the shift, the easier it is for GWτ to
    distinguish between the trajectories". They call capturing time shifts "a desirable property".
    Shift sensitivity is intended behaviour, whatever the sampling.
  - **The paper's narrower claim fails on sampled data.** The paper's only robustness statement is that
    "slightly shifted versions" of oscillations "will be matched by an optimal transport routine
    producing a small distance". A phase shift relative to the sampling grid breaks this.
  - The only shift the value is exactly invariant to is a constant offset x → x + c.
  - Delayed white noise stays small compared with independent pairs: 3.6-6.5 vs 22-53 at T = 4096. A
    phase-shifted sampled sinusoid does not.""")
rep("""  - This linear drift predicts about 0.114·T/√3 ≈ 270 at T = 4096. It is a property of the canonical
    construction on sampled data, not a porting error.""",
"""  - This linear drift predicts about 0.114·T/√3 ≈ 269.6 at T = 4096.
  - Noise-free probe (`gwtau_fix/probe_shift.py`): the z-scored phase-0 and π/4 cosines give 16.50 at
    T = 256 and 269.27 at T = 4096, against predictions of 16.85 and 269.63. The −π/2 copy gives about
    1e-13.
  - This grid effect comes from the canonical construction on sampled data, not from a porting error.
    It is separate from the paper's intended sensitivity to time shifts.""")
open(p,'w',encoding='utf8').write(s)
