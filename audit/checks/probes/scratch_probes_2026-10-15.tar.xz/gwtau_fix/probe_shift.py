import numpy as np, scipy.stats as st
from pyspi.statistics.distance import GromovWasserstainTau
g=GromovWasserstainTau()
for T in (256,4096):
    t=np.arange(T)
    a=st.zscore(np.cos(np.pi*t/2),ddof=1); b=st.zscore(np.cos(np.pi*t/2+np.pi/4),ddof=1); c=st.zscore(np.cos(np.pi*t/2-np.pi/2),ddof=1)
    d=(2*np.sqrt(3)-1-np.sqrt(5))/2
    print(T, g.gwtau(a[:,None],b[:,None]), g.gwtau(a[:,None],c[:,None]), 'pred', d*np.sqrt(np.mean(np.arange(1,T)**2)), d*T/np.sqrt(3))
