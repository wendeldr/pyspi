import sys, re
from xml.etree import ElementTree as ET
p = sys.argv[1]
raw = open(p, encoding='utf-8').read()
ns = {'m': 'http://www.w3.org/1998/Math/MathML', 'xlink': 'http://www.w3.org/1999/xlink'}
root = ET.fromstring(raw)
def txt(el):
    return ''.join(el.itertext())
# (a) disp-formulas in document order with labels and the nearest ancestor sec title / preceding text
body = root.find('.//body')
parent = {c: p for p in root.iter() for c in p}
def sec_title(el):
    e = el
    while e in parent:
        e = parent[e]
        if e.tag == 'sec':
            t = e.find('title')
            return txt(t).strip() if t is not None else '?'
        if e.tag == 'statement':
            lab = e.find('label'); ti = e.find('title')
            return 'STATEMENT ' + (txt(lab).strip() if lab is not None else '') + ' ' + (txt(ti).strip() if ti is not None else '')
    return '?'
# Build a flat text with markers to get preceding context
flat = []
def walk(e):
    if e.tag == 'disp-formula':
        flat.append(('F', e.get('id'), (e.find('label').text if e.find('label') is not None else 'NO LABEL'), sec_title(e)))
        return
    if e.text: flat.append(('T', e.text))
    for c in e:
        walk(c)
        if c.tail: flat.append(('T', c.tail))
walk(body)
text_so_far = ''
for item in flat:
    if item[0] == 'T':
        text_so_far += item[1]
    else:
        ctx = re.sub(r'\s+', ' ', text_so_far[-160:])
        print(f'{item[1]:6s} label={item[2]!s:9s} sec={item[3][:60]!r}  ...{ctx}')
print('=====')
# (b) statements (definitions/propositions) with their formula ids
for st in root.iter('statement'):
    lab = st.find('label'); ti = st.find('title')
    ids = [f.get('id') for f in st.iter('disp-formula')]
    print('STATEMENT', (txt(lab).strip() if lab is not None else ''), (txt(ti).strip() if ti is not None else ''), ids)
print('=====')
# (c) sentences with shift / desirable in the Empirical Results section
for sec in root.iter('sec'):
    t = sec.find('title')
    if t is not None and 'Empirical Results' in txt(t):
        full = re.sub(r'\s+', ' ', txt(sec))
        sents = re.split(r'(?<=[.!?])\s+', full)
        for s in sents:
            if re.search(r'shift|desirable', s, re.I):
                print('--', s)
        break
