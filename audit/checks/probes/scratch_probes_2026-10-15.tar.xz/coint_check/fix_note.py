p = '/media/dan/Data/git/pyspi/audit/notes/coint.md'
s = open(p).read()
reps = [
("""- **Candidates.** Six, all confirmed (details in the records):
  - stationarity confound;
  - collinear robustness;""",
"""- **Candidates.** Six, all confirmed as observed behaviour (details in the records). The first is an interpretation note, not a finding (see Findings):
  - stationarity confound;
  - collinear robustness;"""),
("""- **Candidates.** Seven, all confirmed. The new one is the det_order-1 scheme itself, refined as above.""",
"""- **Candidates.** Seven, all confirmed as observed behaviour. The new one is the det_order-1 scheme itself, refined as above. The stationarity confound is an interpretation note, not a finding (see Findings)."""),
("""- **Candidates.** Seven, all confirmed.

### Symmetry""",
"""- **Candidates.** Seven, all confirmed as observed behaviour. The stationarity confound is an interpretation note, not a finding (see Findings).

### Symmetry"""),
("""4. **aeg −inf.** aeg returns −inf for collinear pairs.
5. **Stationarity confound.** Independent stationary pairs score as strongly as, or more strongly than, a truly cointegrated pair, for both methods.
6. **Metadata and documentation.**""",
"""4. **aeg −inf.** aeg returns −inf for collinear pairs.
5. **Metadata and documentation.**"""),
("""The complex-dtype note is value-neutral (max |imag| = 0).""",
"""The complex-dtype note is value-neutral (max |imag| = 0).

**Interpretation note (not a finding): stationarity confound.** Independent stationary pairs score as strongly as, or more strongly than, a truly cointegrated pair, for both methods (`confound` runs). This is the standard behaviour of cointegration tests applied to I(0) series: every linear combination of two stationary series is stationary, so the Johansen r = 0 hypothesis and the Engle-Granger unit-root hypothesis are rejected regardless of coupling. It is an applicability limit for z-scored stationary data such as EEG, not a value defect, and it does not support `new_finding` in any record. `new_finding` stays true on the findings above: the collinear-pair defects for every unit, the det_order-1 scheme for order 1, and the orientation dependence and −inf for aeg. The candidate resolutions keep outcome "confirmed" for the observed behaviour, and their evidence says it is an interpretation note."""),
("""1. **Were the values identical in statsmodels 0.12.0?** Not executed. Only a source comparison was possible.""",
"""1. **Were the values identical in statsmodels 0.12.0?** Inconclusive, not answered: no execution against 0.12.0 was possible. The source reading below is circumstantial.
   - The source diff is not stored under `audit/`. It exists only in the session scratchpad (`coint_check/sm012/`), so it cannot be re-inspected from the audit tree."""),
("""   - Running 0.12.0 would settle it; it was not installed, as the task forbids installs.""",
"""   - Running 0.12.0 on the same inputs and comparing with the stored outputs would settle it. It was not installed, as the task forbids installs. Until then the question stays open; the scores do not depend on it, because every check compares with the installed 0.15.0."""),
]
for a, b in reps:
    assert s.count(a) == 1, a[:60]
    s = s.replace(a, b)
open(p, 'w').write(s)
print('ok')
