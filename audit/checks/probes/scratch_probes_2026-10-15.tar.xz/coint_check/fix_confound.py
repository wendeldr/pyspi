import yaml, sys
R = '/media/dan/Data/git/pyspi/audit/records/'
joh = (' Interpretation note, not a finding: this is the standard behaviour of a cointegration test applied to I(0) series'
       ' (every linear combination of two stationary series is stationary, so r = 0 is rejected); it is an applicability'
       ' limit of the method, not a value defect, and does not support new_finding, which rests on {}.')
aeg = (' Interpretation note, not a finding: this is the standard behaviour of the Engle-Granger test applied to I(0) series'
       ' (the regression residual of two stationary series is stationary, so the ADF test rejects a unit root); it is an'
       ' applicability limit of the method, not a value defect, and does not support new_finding, which rests on the'
       ' orientation dependence and the -inf output for collinear pairs.')
units = {
 'misc.coint.johansen_order-0_ardiff-1': joh.format('the collinear-pair robustness defects (duplicated channel blanks the matrix; silent out-of-range values)'),
 'misc.coint.johansen_order-0_ardiff-10': joh.format('the collinear-pair robustness defects (duplicated channel blanks the matrix; silent out-of-range values)'),
 'misc.coint.johansen_order-1_ardiff-1': joh.format('the det_order-1 pre-detrending scheme and the collinear-pair robustness defects'),
 'misc.coint.johansen_order-1_ardiff-10': joh.format('the det_order-1 pre-detrending scheme and the collinear-pair robustness defects'),
 'misc.coint.aeg': aeg,
}
for u, ins in units.items():
    p = R + u + '.yaml'
    s = open(p).read()
    if 'Interpretation note, not a finding' in s:
        print('already', u); continue
    a = s.index("  - candidate: 'stationarity confound")
    b = s.index("\n  - candidate:", a + 10)
    block = s[a:b]
    assert block.rstrip().endswith("'"), u
    q = a + len(block.rstrip()) - 1
    s2 = s[:q] + ins + s[q:]
    d = yaml.safe_load(s2)
    cr = [c for c in d['correctness']['candidate_resolutions'] if c['candidate'].startswith('stationarity confound')][0]
    assert cr['evidence'].endswith(ins.strip()), u
    open(p, 'w').write(s2)
    print('ok', u)
