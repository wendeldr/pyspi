import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
import coint as C
for Tm, slope in ((1000, 0.001), (4000, 0.001), (4000, 0.0)):
    rng = np.random.default_rng(5); tt = np.arange(Tm); st = []
    for r in range(1500):
        e = rng.standard_normal((2, Tm)) + np.array([[0.3], [-0.2]]) + slope * tt
        st.append(C.rrr_case(np.cumsum(e, axis=1), 1, 5)[:2])
    st = np.array(st)
    print(Tm, slope, 'trace q90/95/99', np.round(np.quantile(st[:, 1], [.9, .95, .99]), 3), 'maxeig', np.round(np.quantile(st[:, 0], [.9, .95, .99]), 3))
