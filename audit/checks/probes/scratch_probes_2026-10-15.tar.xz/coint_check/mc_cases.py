import sys, time, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
import coint as C
T, M = 1000, 1500
rng = np.random.default_rng(7)
res = {k: [] for k in ("c2_nodrift", "c3_nodrift", "c3_drift", "c4_drift", "c5_quaddrift", "c5_drift", "sm1_nodrift", "sm0_nodrift")}
t0 = time.time()
for r in range(M):
    e = rng.standard_normal((2, T))
    w0 = np.cumsum(e, axis=1)
    wd = np.cumsum(e + np.array([[0.3], [-0.2]]), axis=1)
    tt = np.arange(T)
    wq = np.cumsum(e + np.array([[0.3], [-0.2]]) + 0.001 * tt, axis=1)
    res["c2_nodrift"].append(C.rrr_case(w0, 1, 2)[1])
    res["c3_nodrift"].append(C.rrr_case(w0, 1, 3)[1])
    res["c3_drift"].append(C.rrr_case(wd, 1, 3)[1])
    res["c4_drift"].append(C.rrr_case(wd, 1, 4)[1])
    res["c5_drift"].append(C.rrr_case(wd, 1, 5)[1])
    res["c5_quaddrift"].append(C.rrr_case(wq, 1, 5)[1])
    res["sm1_nodrift"].append(C.kjoh(w0[1], w0[0], 1, 1)[1])
    res["sm0_nodrift"].append(C.kjoh(w0[1], w0[0], 0, 1)[1])
for k, v in res.items():
    v = np.array(v); q = np.quantile(v, 0.95)
    print(f"{k:14s} trace q95 {q:7.3f}  rej@15.494 {np.mean(v>15.4943):.3f} rej@18.3985 {np.mean(v>18.3985):.3f} rej@25.87 {np.mean(v>25.87):.3f}")
print(time.time() - t0)
