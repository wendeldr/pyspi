"""Write audit/checks/manifest/coint.json (check stage, coint family)."""
import json

runs = []


def add(unit, ident, ds, T, path, tag, processes=None, probe=None):
    rid = f"{unit}|{ds}|{T}|{path}|{tag}"
    if processes is not None:
        rid += "-p" + "".join(map(str, processes))
    runs.append(dict(run_id=rid, unit_id=unit, identifier=ident, dataset=ds, T=T, path=path,
                     processes=processes, seed=42, probe=probe))


PROBE = "probes/coint_probes.py"


def pr(fn):
    return dict(module=PROBE, function=fn)


for d in (0, 1):
    for k in (1, 10):
        u = f"misc.coint.johansen_order-{d}_ardiff-{k}"
        ME = f"coint_johansen_max_eig_stat_order-{d}_ardiff-{k}"
        TR = f"coint_johansen_trace_stat_order-{d}_ardiff-{k}"
        for ident, s in ((ME, "me"), (TR, "tr")):
            # kernel: exact vs the shared kernel (statsmodels placement of deterministic terms)
            for ds in ("cointegrated", "iid_gaussian"):
                for T in (256, 1024, 4096):
                    add(u, ident, ds, T, "kernel", f"own-{s}")
            # canonical textbook RRR (case 3 for d=0, case 4 for d=1), convergence of the gap
            for T in (256, 1024, 4096):
                add(u, ident, "cointegrated", T, "kernel", f"canon-{s}")
            add(u, ident, "iid_gaussian", 1024, "kernel", f"canon-{s}")
            # R urca ca.jo
            for ds in ("cointegrated", "iid_gaussian"):
                for T in (256, 1024):
                    add(u, ident, ds, T, "kernel", f"urca-{s}")
                    if d == 1:
                        add(u, ident, ds, T, "kernel", f"urcadt-{s}")
            # truth on cointegrated (critical values from the crit probe)
            for T in (64, 256, 1024, 4096):
                add(u, ident, "cointegrated", T, "pipeline", f"stat-{s}")
            add(u, ident, "cointegrated", 1024, "pipeline", f"perm-{s}", processes=[3, 2, 1, 0])
            add(u, ident, "trending", 1024, "pipeline-detrend", f"own-{s}")
        for ds in ("trending", "var2_bivariate", "gauss_ar1_pair"):
            add(u, TR, ds, 1024, "kernel", "own-tr")
        add(u, TR, "cointegrated", 1024, "pipeline", "own-tr")
        add(u, TR, "cointegrated", 1024, "pipeline-detrend", "own-tr")
        for ds in ("cointegrated", "iid_gaussian"):
            add(u, TR, ds, 1024, "kernel", "ident-tr")
        add(u, TR, "cointegrated", 256, "pipeline", "onefit", probe=pr("onefit"))
        for T in (256, 1024, 4096):
            add(u, TR, "iid_gaussian", T, "pipeline", "confound-tr")
        add(u, ME, "iid_gaussian", 1024, "pipeline", "confound-me")
        for ds in ("delayed_noise", "var2_bivariate"):
            add(u, TR, ds, 1024, "pipeline", "confound-tr")
        add(u, TR, "scaled_offset", 1024, "kernel", "affine-tr")
        add(u, TR, "trending", 1024, "kernel", "trendinv-tr")
        for T in (256, 1024):
            add(u, TR, "shared_envelope", T, "pipeline", "calc", probe=pr("calc"))
        add(u, TR, "cointegrated", 256, "pipeline", "collinear", probe=pr("collinear"))
        add(u, TR, "cointegrated", 256, "pipeline", "cplx", probe=pr("cplx"))
        add(u, None, "cointegrated", 256, "pipeline", "meta", probe=pr("meta"))
        add(u, TR, "cointegrated", 256, "pipeline", "crit", probe=pr("crit"))
        for T in (256, 1024):
            add(u, TR, "cointegrated", T, "pipeline", "size", probe=pr("size"))
        if k == 1:
            add(u, TR, "cointegrated", 256, "pipeline", "cvmc", probe=pr("crit"))

u = "misc.coint.aeg"
IDS = {"c": "coint_aeg_tstat_trend-c_autolag-aic_maxlag-10",
       "cta": "coint_aeg_tstat_trend-ct_autolag-aic_maxlag-10",
       "ctb": "coint_aeg_tstat_trend-ct_autolag-bic_maxlag-10"}
for s, ident in IDS.items():
    for ds in ("cointegrated", "iid_gaussian"):
        for T in (256, 1024, 4096):
            add(u, ident, ds, T, "kernel", f"own-{s}")
    add(u, ident, "cointegrated", 64, "kernel", f"own-{s}")
    for ds in ("trending", "var2_bivariate", "delayed_noise"):
        add(u, ident, ds, 1024, "kernel", f"own-{s}")
    add(u, ident, "cointegrated", 1024, "pipeline", f"own-{s}")
    add(u, ident, "trending", 1024, "pipeline-detrend", f"own-{s}")
    for ds in ("cointegrated", "iid_gaussian"):
        for T in (256, 1024):
            add(u, ident, ds, T, "kernel", f"urca-{s}")
    # reverse orientation (y0 = lower index): quantifies the regression asymmetry
    for ds, T in (("cointegrated", 256), ("cointegrated", 1024), ("iid_gaussian", 256),
                  ("trending", 4096), ("var2_bivariate", 1024), ("delayed_noise", 1024)):
        add(u, ident, ds, T, "kernel", f"rev-{s}")
    for T in (64, 256, 1024, 4096):
        add(u, ident, "cointegrated", T, "pipeline", f"stat-{s}")
    for T in (256, 1024):
        add(u, ident, "cointegrated", T, "pipeline", f"perm-{s}", processes=[3, 2, 1, 0])
        add(u, ident, "cointegrated", T, "pipeline", f"orderdep-{s}", processes=[3, 2, 1, 0])
    add(u, ident, "scaled_offset", 1024, "kernel", f"affine-{s}")
    add(u, ident, "trending", 1024, "kernel", f"trendinv-{s}")
    for T in (256, 1024):
        add(u, ident, "shared_envelope", T, "pipeline", f"degen-{s}")
    add(u, ident, "cointegrated", 256, "pipeline", f"collinear-{s}", probe=pr("collinear"))
    add(u, ident, "cointegrated", 256, "pipeline", f"crit-{s}", probe=pr("crit"))
    for T in (256, 1024):
        add(u, ident, "cointegrated", T, "pipeline", f"size-{s}", probe=pr("size"))
for T in (256, 1024, 4096):
    add(u, IDS["c"], "iid_gaussian", T, "pipeline", "confound-c")
for ds in ("delayed_noise", "var2_bivariate"):
    add(u, IDS["c"], ds, 1024, "pipeline", "confound-c")
add(u, IDS["c"], "trending", 4096, "pipeline", "api-c", processes=[0, 3], probe=pr("api"))
add(u, None, "cointegrated", 256, "pipeline", "meta", probe=pr("meta"))

ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids)), [i for i in ids if ids.count(i) > 1]
json.dump({"family": "coint", "runs": runs},
          open("/media/dan/Data/git/pyspi/audit/checks/manifest/coint.json", "w"), indent=1)
print(len(runs))
