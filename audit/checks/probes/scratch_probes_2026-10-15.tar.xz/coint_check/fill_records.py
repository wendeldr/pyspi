"""Fill the check-stage block of the five coint records (project venv: needs PyYAML)."""
import yaml
from pathlib import Path

REC = Path("/media/dan/Data/git/pyspi/audit/records")
REF = "audit/checks/refs/coint.py"
J = "misc.coint.johansen_order-{d}_ardiff-{k}"

NUM = {
    (0, 1): dict(
        own="19/19 exact pass, max_rel 1.35e-12 (cointegrated T=4096), column-swap max_rel <= 2.2e-13",
        canon="8/8 pass vs textbook case 3, max_rel 5.2e-14; pyspi vs case 2 (restricted constant) 0.13/0.21 (max-eig/trace, T=256) to 0.37/0.45 (T=4096) on cointegrated; vs case 4 0.49-0.60 on cointegrated (0.0072-0.0083 on iid)",
        urca="8/8 pass vs ca.jo(ecdet='none', K=2), max_rel 3.3e-13; spec 'longrun' gives the same values as 'transitory'; [x_lo, x_hi] equals [x_hi, x_lo]; ecdet 'const' differs by 5.2e-6 (iid) to 0.21 (cointegrated) relative, 'trend' by 0.0072-0.60",
        stat="cointegrated (0,1) max-eig 40.38 / 105.29 / 383.6 / 1626.8 and trace 43.33 / 111.01 / 386.05 / 1628.1 at T = 64 / 256 / 1024 / 4096 vs tabulated 95% values 14.26 / 15.49; largest null-pair trace 14.42 / 16.42 / 14.18 / 7.64 (one null pair rejects at T=256); 8/8 pass",
        size="driftless independent random walks, 400 reps: rejection at the tabulated 5% value max-eig 0.0625 / 0.070 and trace 0.100 / 0.135 at T = 256 / 1024 (binomial se 0.011); Monte Carlo 95% trace quantile 17.47 / 18.14 vs table 15.49; per-replicate values exact (max_rel 5.1e-14)",
        cvmc="statsmodels det_order-0 table vs Monte Carlo of textbook case 3 on drifting walks (T=4000, 2000 reps): trace 95% 15.494 vs 15.516 (se 0.33), max-eig 14.264 vs 14.270; max z 1.07, pass (run misc.coint.johansen_order-0_ardiff-1|cointegrated|256|pipeline|cvmc)",
        confound="independent white noise (iid_gaussian) trace median 224.4 / 864.5 / 3303.2 at T = 256 / 1024 / 4096 (median / m = 0.88 / 0.85 / 0.81), 2.02 / 2.24 / 2.03 times the cointegrated (0,1) value; every iid pair exceeds the 95% value (min 196.45 at T=256); delayed_noise median 944.1 (2.45x), var2_bivariate 858.7 (2.22x); max-eig iid T=1024 median 456.6 (1.19x)",
        ident="trace - max_eig = -m ln(1 - lambda_2) exact (max_rel 3.6e-16); min(trace - max_eig) 0.478 (cointegrated) / 395.0 (iid)",
        perm="reversed channel order: kernel on the permuted data max_rel 1.0e-13; pyspi(reversed) vs pyspi relabelled max_abs 4.0e-13",
        trendinv="EXPECTED TO DIFFER: trending (D2 + slope t) vs D2 gap 416.6 (no trend term in det_order 0)",
        detrend="pipeline-detrend on trending matches the kernel on detrended z-scored data (max_abs 2.0e-12); pipeline detrending changes the trending trace values from 403-424 (kernel path) to 822.5-843.6",
        collinear="[z, 3z+1] over 16 cases: 9 raise (3 'Singular matrix', 6 'Matrix is not positive definite'), 7 return, 5 of them out of range (returned values -1338.9 to 269.3)",
        cost="cheap: <= 0.03 s per plain pyspi run at T=4096; family probes <= 10 s",
    ),
    (0, 10): dict(
        own="19/19 exact pass, max_rel 2.5e-13, column-swap max_rel <= 5.2e-12 (T=4096)",
        canon="8/8 pass vs textbook case 3, max_rel 2.0e-12; pyspi vs case 2 0.088/0.17 (T=256) to 0.30/0.41 (T=4096) on cointegrated; vs case 4 0.52-0.72 on cointegrated (0.039-0.061 on iid)",
        urca="8/8 pass vs ca.jo(ecdet='none', K=11), max_rel 3.5e-12; 'longrun' = 'transitory'; [x_lo, x_hi] = [x_hi, x_lo]; ecdet 'const' differs by 6.8e-5-0.17 relative, 'trend' by 0.039-0.72",
        stat="cointegrated (0,1) max-eig 12.81 / 27.48 / 99.34 / 342.22 and trace 12.92 / 35.16 / 101.76 / 343.45 at T = 64 / 256 / 1024 / 4096 vs 95% values 14.26 / 15.49; FAILS at T=64 (m = 53: the true pair does not reach the 95% value), passes at T >= 256 (largest null trace 18.20 at T=256 with 2 null pairs rejecting, 14.61 at 1024, 7.77 at 4096)",
        size="driftless walks, 400 reps: rejection max-eig 0.0675 / 0.105 and trace 0.1225 / 0.150 at T = 256 / 1024 (se 0.011); Monte Carlo 95% trace quantile 18.21 / 19.08 vs 15.49; per-replicate values exact (max_rel 2.8e-14)",
        cvmc="tables shared with ardiff-1: case-3 Monte Carlo reproduces the det_order-0 table (run misc.coint.johansen_order-0_ardiff-1|cointegrated|256|pipeline|cvmc, max z 1.07)",
        confound="iid trace median 43.55 / 177.68 / 714.69 at T = 256 / 1024 / 4096 (median / m = 0.178 / 0.175 / 0.175), 1.24 / 1.75 / 2.08 times the cointegrated (0,1) value; every iid pair exceeds the 95% value (min 26.94 at T=256); delayed_noise 202.5 (1.99x), var2_bivariate 192.9 (1.90x); max-eig iid T=1024 median 95.18 (0.96x)",
        ident="exact (max_rel 1.1e-15); min(trace - max_eig) 0.725 (cointegrated) / 74.36 (iid)",
        perm="reversed order: max_rel 4.5e-13 vs kernel; pyspi relabelled max_abs 7.6e-12",
        trendinv="EXPECTED TO DIFFER: trending vs D2 gap 105.1",
        detrend="pipeline-detrend on trending matches the kernel (max_abs 3.7e-13); values change from 76.5-100.9 (kernel path) to 167.0-198.5",
        collinear="[z, 3z+1] over 16 cases: 4 raise (1 'Singular matrix', 3 not positive definite), 12 return, 6 out of range (returned values -58.5 to 17401)",
        cost="cheap: <= 0.4 s per plain pyspi run at T=4096; probes <= 8 s",
    ),
    (1, 1): dict(
        own="19/19 exact pass vs the statsmodels-placement kernel, max_rel 2.3e-13",
        urcadt="8/8 pass vs ca.jo(ecdet='none', K=2) on full-sample OLS-detrended levels, max_rel 9.6e-14",
        urca="EXPECTED TO DIFFER, 0/8: vs the closest native ecdet ('trend', restricted trend) max_rel max-eig/trace 0.025/0.124 (cointegrated T=256), 0.018/0.085 (T=1024), 1.2e-3/7.1e-4 (iid T=256), 1.5e-5 (iid T=1024); ecdet 'none' + dumvar t (case 5) 4.0e-3/2.0e-3 (T=256) and 3.2e-4/1.2e-3 (T=1024); ecdet 'none'/'const' on raw levels >= 0.91 on cointegrated",
        canon="EXPECTED TO DIFFER, 0/8 vs textbook case 4: max_rel max-eig 0.025 / 0.018 / 0.26 and trace 0.124 / 0.085 / 0.34 at T = 256 / 1024 / 4096 (mean_rel trace 0.072 / 0.043 / 0.20), i.e. no convergence on the non-cointegrated pairs (T=4096 pair (0,2) trace: pyspi 7.89, case 4 10.91, case 5 7.89); vs case 5 max_rel max-eig 4.0e-3 / 3.2e-4 / 1.2e-3, trace 2.0e-3 / 1.2e-3 / 4.8e-4; textbook case 3 on pre-detrended levels reproduces pyspi (<= 1.6e-14)",
        cvmc="statsmodels det_order-1 table vs Monte Carlo of textbook case 5 on walks with a quadratic trend (T=4000, 2000 reps): trace 95% 18.3985 vs 18.727 (se 0.36), max-eig 17.148 vs 17.579 (se 0.33); max z 1.31, pass (run misc.coint.johansen_order-1_ardiff-1|cointegrated|256|pipeline|cvmc)",
        stat="cointegrated (0,1) max-eig 40.15 / 105.35 / 384.73 / 1628.8 and trace 43.25 / 109.65 / 389.41 / 1628.8 at T = 64 / 256 / 1024 / 4096 vs 95% values 17.15 / 18.40; 8/8 pass; null pairs rejecting at 5% (trace) 1 / 1 / 4 of 5 / 0",
        size="driftless walks, 400 reps: rejection max-eig 0.060 / 0.0675 and trace 0.190 / 0.2125 at T = 256 / 1024 (se 0.011); Monte Carlo 95% trace quantile 23.45 / 23.93 vs table 18.40; per-replicate values exact (max_rel 1.6e-14)",
        confound="iid trace median 225.4 / 865.9 / 3303.8 at T = 256 / 1024 / 4096 (2.06 / 2.22 / 2.03 times cointegrated (0,1)); every iid pair exceeds the 95% value; delayed_noise 944.2 (2.42x), var2_bivariate 861.5 (2.21x); max-eig iid T=1024 median 457.5 (1.19x)",
        ident="exact (max_rel 5.8e-16); min(trace - max_eig) 4.66 (cointegrated) / 395.1 (iid)",
        perm="reversed order: max_rel 8.9e-15; pyspi relabelled max_abs 1.1e-13",
        trendinv="pass: trending (D2 + slope t) equals D2 (max_rel 1.7e-15): det_order 1 removes linear trends",
        detrend="pipeline-detrend on trending matches the kernel (max_abs 1.9e-12) and leaves the values unchanged (822.5-843.6 on both paths)",
        collinear="[z, 3z+1] over 16 cases: 9 raise (1 'Singular matrix', 8 not positive definite), 7 return, 6 out of range (returned values -2149.5 to 1930.9)",
        cost="cheap: <= 0.03 s per plain pyspi run at T=4096; probes <= 9 s",
    ),
    (1, 10): dict(
        own="19/19 exact pass, max_rel 3.0e-12 (cointegrated T=4096)",
        urcadt="8/8 pass vs ca.jo(ecdet='none', K=11) on OLS-detrended levels, max_rel 7.6e-14",
        urca="EXPECTED TO DIFFER, 0/8: vs ecdet 'trend' max_rel max-eig/trace 0.012/0.195 (cointegrated T=256), 0.019/0.053 (T=1024), 0.010/0.0079 (iid T=256), 4.6e-4/3.9e-4 (iid T=1024); ecdet 'none' + dumvar t (case 5) 0.012/0.024 (T=256), 1.8e-3/5.7e-3 (T=1024)",
        canon="EXPECTED TO DIFFER, 0/8 vs textbook case 4: max_rel max-eig 0.012 / 0.019 / 0.28 and trace 0.195 / 0.053 / 0.38 at T = 256 / 1024 / 4096 (mean_rel trace 0.117 / 0.028 / 0.246); T=256 pair (1,0): pyspi max-eig 27.186 / trace 32.915 vs case 4 27.512 / 35.644; vs case 5 max_rel trace 0.024 / 5.7e-3 / 7.1e-3; textbook case 3 on pre-detrended levels reproduces pyspi (<= 7.1e-12)",
        cvmc="tables shared with ardiff-1: the det_order-1 table matches textbook case 5 (run misc.coint.johansen_order-1_ardiff-1|cointegrated|256|pipeline|cvmc, max z 1.31)",
        stat="cointegrated (0,1) max-eig 24.07 / 27.19 / 100.59 / 343.87 and trace 25.08 / 32.92 / 104.99 / 343.88 at T = 64 / 256 / 1024 / 4096 vs 95% values 17.15 / 18.40; 8/8 pass; but 2 of 5 null pairs reject at T=256 (largest null trace 28.85) and 4 of 5 (trace) at T=1024",
        size="driftless walks, 400 reps: rejection max-eig 0.0925 / 0.0975 and trace 0.210 / 0.2225 at T = 256 / 1024 (se 0.011); Monte Carlo 95% trace quantile 23.24 / 24.08 vs 18.40; per-replicate values exact (max_rel 1.6e-14)",
        confound="iid trace median 44.69 / 181.52 / 715.36 at T = 256 / 1024 / 4096 (1.36 / 1.73 / 2.08 times cointegrated (0,1)); every iid pair exceeds the 95% value; delayed_noise 203.8 (1.94x), var2_bivariate 196.2 (1.87x); max-eig iid T=1024 median 98.66 (0.98x)",
        ident="exact (max_rel 2.2e-15); min(trace - max_eig) 4.02 (cointegrated) / 74.37 (iid)",
        perm="reversed order: max_rel 3.5e-13; pyspi relabelled max_abs 1.5e-11",
        trendinv="pass: trending equals D2 (max_rel 1.3e-15)",
        detrend="pipeline-detrend on trending matches the kernel (max_abs 8.8e-13) and leaves the values unchanged (167.0-198.5 on both paths)",
        collinear="[z, 3z+1] over 16 cases: 6 raise (2 'Singular matrix', 4 not positive definite), 10 return, 3 out of range (returned values -7.18 to 9575.6)",
        cost="cheap: <= 0.2 s per plain pyspi run at T=4096; probes <= 8 s",
    ),
}


def johansen(d, k):
    u = J.format(d=d, k=k)
    n = NUM[(d, k)]
    shared_probe = (f"{u}|shared_envelope|256|pipeline|calc and |1024|pipeline|calc: Calculator reports the SPI failed "
                    "('Singular matrix') and stores an all-NaN matrix (all four Johansen configs x 2 identifiers = 8 of "
                    "the 11 coint SPIs fail; the aeg SPIs return -inf for the pair instead)")
    cands = []
    if d == 1:
        cands.append(dict(
            candidate="det_order=1 matches no standard Johansen deterministic case (pre-detrended levels)",
            outcome="confirmed",
            evidence=(f"{u}|cointegrated|{{256,1024,4096}}|kernel|canon-{{me,tr}} and |iid_gaussian|1024|kernel|canon-*: "
                      + n["canon"] + f"; {u}|*|kernel|urca-* vs ca.jo ecdet 'trend': " + n["urca"]
                      + f"; exact reproduction only by ecdet 'none' on OLS-detrended levels ({u}|*|kernel|urcadt-*: "
                      + n["urcadt"] + "). Refinement of the trace text: the gap to case 4 does not shrink with T on "
                      "non-cointegrated pairs; the statistic approaches the unrestricted-trend case 5, whose asymptotic "
                      "quantiles statsmodels tabulates for det_order 1 (" + n["cvmc"] + ")")))
    cands += [
        dict(candidate="stationarity confound: on stationary inputs the r=0 statistics are large, grow ~linearly in T and do not measure coupling",
             outcome="confirmed",
             evidence=f"{u}|iid_gaussian|{{256,1024,4096}}|pipeline|confound-tr, |iid_gaussian|1024|pipeline|confound-me, "
                      f"|delayed_noise|1024|pipeline|confound-tr, |var2_bivariate|1024|pipeline|confound-tr: " + n["confound"]),
        dict(candidate="exactly collinear pairs: input-dependent LinAlgError (whole matrix NaN) or silently out-of-range values",
             outcome="confirmed",
             evidence=shared_probe + f"; {u}|cointegrated|256|pipeline|collinear: " + n["collinear"]
                      + " (the trace probe counted 29/64 raises over the four configs calling coint_johansen on [z, 3z+1]; "
                        "through the SPI the first-visited column order is [3z+1, z] and the four configs give 28/64)"),
        dict(candidate="numpy 2.5.4 eig returns complex128 (ComplexWarning, imaginary part dropped); value-neutral",
             outcome="confirmed",
             evidence=f"{u}|cointegrated|256|pipeline|cplx: 58/58 eig results complex128, max |imag| 0.0, 232 ComplexWarnings, "
                      "no other warnings (value-neutral; recorded as a numerics note, not a defect)"),
        dict(candidate="class label 'nonlinear' vs documented/config 'linear'",
             outcome="confirmed",
             evidence=f"{u}|cointegrated|256|pipeline|meta: [has nonlinear, has linear, issigned, Johansen-spelling code, "
                      "AEG-spelling code] = [1, 0, 0, 1, 1]"),
        dict(candidate="documentation: 'maximum eigenvalue'/'trace of the VECM' are the rank-0 LR statistics; citation [81] is Pesaran & Shin (ARDL)",
             outcome="confirmed",
             evidence=f"{u}|*|kernel|own-*: pyspi equals -m ln(1 - lambda_1) and -m sum ln(1 - lambda_i) (" + n["own"]
                      + f"); {u}|*|kernel|ident-tr: " + n["ident"] + "; the citation is a reading of supplement reference [81] (no numeric check)"),
        dict(candidate="__init__ branches on 'johansen' but _from_cache on 'aeg': other spellings fail with AttributeError (latent)",
             outcome="confirmed",
             evidence=f"{u}|cointegrated|256|pipeline|meta: Cointegration(method='Johansen') and (method='AEG') both raise "
                      "AttributeError naming _det_order (code 1); not reachable from the shipped configs"),
    ]
    runs = [
        dict(run_ids=[f"{u}|cointegrated|{{256,1024,4096}}|kernel|own-{{me,tr}}", f"{u}|iid_gaussian|{{256,1024,4096}}|kernel|own-{{me,tr}}",
                      f"{u}|{{trending,var2_bivariate,gauss_ar1_pair}}|1024|kernel|own-tr", f"{u}|cointegrated|1024|pipeline|own-tr",
                      f"{u}|cointegrated|1024|pipeline-detrend|own-tr", f"{u}|trending|1024|pipeline-detrend|own-{{me,tr}}"],
             reference=f"{REF}:handle_johansen own -> audit/checks/refs/_kernels_basic_misc.py:johansen",
             outcome="pass 19/19; " + n["own"]),
        dict(run_ids=[f"{u}|cointegrated|{{256,1024,4096}}|kernel|canon-{{me,tr}}", f"{u}|iid_gaussian|1024|kernel|canon-{{me,tr}}"],
             reference=f"{REF}:rrr_case (case {3 if d == 0 else 4})",
             outcome=("pass 8/8; " if d == 0 else "fail 0/8 (expected; the gap is the measurement); ") + n["canon"]),
        dict(run_ids=[f"{u}|{{cointegrated,iid_gaussian}}|{{256,1024}}|kernel|urca-{{me,tr}}"],
             reference="audit/checks/r/coint.R jo (urca 1.3.3 ca.jo)",
             outcome=("pass 8/8; " if d == 0 else "fail 0/8 (expected); ") + n["urca"]),
    ]
    if d == 1:
        runs.append(dict(run_ids=[f"{u}|{{cointegrated,iid_gaussian}}|{{256,1024}}|kernel|urcadt-{{me,tr}}"],
                         reference="audit/checks/r/coint.R jo variant none_dt", outcome="pass 8/8; " + n["urcadt"]))
    runs += [
        dict(run_ids=[f"{u}|cointegrated|{{64,256,1024,4096}}|pipeline|stat-{{me,tr}}", f"{u}|cointegrated|256|pipeline|crit"],
             reference=f"{REF}:handle_johansen stat (make_data is_cointegrated + statsmodels tables via probe crit)",
             outcome=("pass 6/8 (T=64 fails: power); " if (d, k) == (0, 10) else "pass 8/8; ") + n["stat"]),
        dict(run_ids=[f"{u}|cointegrated|{{256,1024}}|pipeline|size"] + ([f"{u}|cointegrated|256|pipeline|cvmc"] if k == 1 else []),
             reference=f"{REF}:handle_johansen size / cvmc (probe size: pyspi on 400 independent random-walk pairs)",
             outcome="pass; " + n["size"] + ("; " + n["cvmc"] if k == 1 else "")),
        dict(run_ids=[f"{u}|iid_gaussian|{{256,1024,4096}}|pipeline|confound-tr", f"{u}|iid_gaussian|1024|pipeline|confound-me",
                      f"{u}|{{delayed_noise,var2_bivariate}}|1024|pipeline|confound-tr"],
             reference=f"{REF}:handle_johansen confound", outcome="pass 6/6 (proposition holds); " + n["confound"]),
        dict(run_ids=[f"{u}|cointegrated|1024|pipeline|perm-{{me,tr}}-p3210"], reference=f"{REF}:handle_johansen perm",
             outcome="pass 2/2; " + n["perm"]),
        dict(run_ids=[f"{u}|{{cointegrated,iid_gaussian}}|1024|kernel|ident-tr", f"{u}|cointegrated|256|pipeline|onefit"],
             reference=f"{REF}:handle_johansen ident / onefit",
             outcome="pass 3/3; " + n["ident"] + "; onefit: 6 coint_johansen calls for the max-eig SPI (6 pairs), 0 more for the trace SPI on the same Data, fresh-Data difference 0"),
        dict(run_ids=[f"{u}|scaled_offset|1024|kernel|affine-tr", f"{u}|trending|1024|kernel|trendinv-tr"],
             reference=f"{REF}:handle_johansen affine / trendinv",
             outcome=("affine pass; trendinv fail (expected); " if d == 0 else "pass 2/2; ") + n["trendinv"]),
        dict(run_ids=[f"{u}|shared_envelope|{{256,1024}}|pipeline|calc", f"{u}|cointegrated|256|pipeline|collinear",
                      f"{u}|cointegrated|256|pipeline|cplx", f"{u}|cointegrated|256|pipeline|meta"],
             reference=f"{REF}:handle_johansen calc / collinear / cplx / meta", outcome="pass 5/5 (propositions hold); " + n["collinear"]),
    ]
    stat_name = "lambda-max and trace statistics for r = 0"
    if d == 0:
        upd = dict(
            check_method="independent-impl",
            check_reference=(f"{REF}:rrr_case case 3 (textbook Johansen RRR, scipy.linalg.eigh); "
                             f"{REF}:handle_johansen own -> audit/checks/refs/_kernels_basic_misc.py:johansen; "
                             "audit/checks/r/coint.R jo (R urca 1.3.3 ca.jo, external-pkg); statsmodels critical-value tables via "
                             "audit/checks/probes/coint_probes.py:crit (literature-only) cross-checked by Monte Carlo (cvmc)"),
            agreement_criterion="exact rtol 1e-10 / atol 1e-12 (kernel); tolerance rtol 1e-9 (textbook case 3) and 1e-8 (urca); qualitative propositions for truth, confound and robustness; statistical (2 bootstrap se) for the table Monte Carlo",
            verdict="matches",
            score_0_10=9,
            what_changed=(f"Value: none. pyspi stores the Johansen {stat_name} with an unrestricted constant (Johansen-Juselius H1, "
                          "urca ecdet='none'), fp-exact against the textbook RRR, the kernel and R urca. Conventions: 'ardiff' counts "
                          "lagged differences (VAR order k+1) where the supplement says 'autoregressive lags'; 'maximum eigenvalue' and "
                          "'trace' name the LR statistics. Interpretation limits (not value defects): the statistic is large for any "
                          "pair of stationary series (confound runs) and its null distribution on driftless walks is not the tabulated "
                          "case-3 one (size runs); pyspi discards the critical values anyway. Robustness defects: a duplicated channel "
                          "blanks the whole matrix; an exactly collinear pair can return silent out-of-range values."),
            new_finding=True,
        )
    else:
        upd = dict(
            check_method="external-pkg",
            check_reference=(f"audit/checks/r/coint.R jo (R urca 1.3.3 ca.jo: ecdet 'none' on OLS-detrended levels reproduces pyspi; "
                             f"native ecdet 'trend' and ecdet 'none' + dumvar t quantify the gaps); {REF}:rrr_case cases 4 and 5 "
                             f"(textbook RRR); {REF}:handle_johansen own -> audit/checks/refs/_kernels_basic_misc.py:johansen; "
                             "statsmodels tables via audit/checks/probes/coint_probes.py:crit, cross-checked by Monte Carlo (cvmc)"),
            agreement_criterion="exact rtol 1e-10 (kernel); tolerance rtol 1e-8 (urca on detrended levels); tolerance rtol 1e-6 for the canonical cases 4 (expected to differ: gap measured) and 5 (extra key); qualitative propositions; statistical (2 bootstrap se) for the table Monte Carlo",
            verdict="variant",
            score_0_10=7,
            what_changed=("det_order=1 is LeSage's/statsmodels' scheme: the levels are detrended by full-sample OLS on [1, t] and the "
                          "VECM is then fitted with an unrestricted constant (reproduced exactly by ca.jo ecdet='none' on detrended "
                          "levels). It is not Johansen's restricted-trend case 4 (urca ecdet='trend'): relative gaps up to 0.195 (trace, "
                          "k=10, T=256) that persist at T=4096 (0.26-0.38 on non-cointegrated pairs). It approaches the "
                          "unrestricted-trend case 5 (gap <= 1.2e-3 for k=1 and <= 1.1e-2 for k=10 at T=4096), and statsmodels' "
                          "det_order-1 critical values are case-5 quantiles (cvmc). So the supplement's 'constant and linear trend' "
                          "is implemented as a finite-sample approximation of case 5. On driftless walks the case-5 tables over-reject "
                          "(trace 0.19-0.22 at the 5% value). Same robustness and confound limits as the order-0 units."),
            new_finding=True,
        )
    sym = ("sym: max|A - A.T| = 0.0 over every plain SPI run of the unit (bit-exact mirror, NaN diagonal); "
           "column order of the delegate call changes the value by <= 5.2e-12 relative (own-* swap_max_rel), "
           "channel reversal by <= 1.5e-11 absolute (perm-* relabel_max_abs). This agrees with base.pair_handling's "
           "visiting-order measurement of <= 2.6e-13 (run base.pair_handling|iid_gaussian|256|pipeline|upper-misc.Cointegration)")
    direc = ("undirected: A[i,j] = A[j,i] = the statistic of coint_johansen([z_hi, z_lo]), invariant to the column order; on "
             "var2_bivariate (x0 -> x1) and delayed_noise the matrix is symmetric (confound runs), so no direction is encoded")
    upd.update(
        check_data="cointegrated T64/256/1024/4096 (kernel, pipeline, pipeline-detrend, reversed channels); iid_gaussian T256/1024/4096; trending, var2_bivariate, gauss_ar1_pair, delayed_noise, scaled_offset T1024; shared_envelope T256/1024; simulated independent random walks (400 per T in the size probe; 2000 at T=4000 in the table Monte Carlo)",
        closeness="; ".join([n["own"], n["canon"], n["urca"]] + ([n["urcadt"]] if d == 1 else []) + [n["stat"], n["size"], n["confound"], n["ident"], n["perm"], n["trendinv"], n["detrend"]]),
        definition_under_review=False,
        check_cost=n["cost"],
        symmetry_observed=sym,
        direction_observed=direc,
        candidate_resolutions=cands,
        checks_run=runs,
    )
    return u, upd


def aeg():
    u = "misc.coint.aeg"
    own = "36/36 exact pass (cointegrated T64-4096, iid_gaussian T256-4096, trending/var2_bivariate/delayed_noise T1024, pipeline and pipeline-detrend), max_rel 1.6e-13 (max_abs 4.0e-13)"
    urca = ("12/12 pass vs R lm residuals + urca ur.df(type='none', selectlags='Fixed') at the lag the statsmodels rule selects, max_rel 6.5e-14; "
            "urca's own selectlags AIC/BIC differs from pyspi by up to 10.63 (iid T=1024) and picks another lag in 2-10 of the 6-10 pairs, because ur.df "
            "searches lags 1..10 only (never 0) on the common sample and does not re-fit")
    rev = ("reverse orientation (y0 = lower index) differs from the stored value: cointegrated T=256 max_abs 1.53 / 1.10 / 0.93 (c / ct-aic / ct-bic), "
           "T=1024 1.04 / 1.23 / 1.23; iid_gaussian T=256 7.414 / 7.415 / 1.710 (the values base.pair_handling measured); trending T=4096 60.87 / 27.17 / 3.19; "
           "var2_bivariate 0.33; delayed_noise 0.32")
    orderdep = "channel order reversed on cointegrated: pyspi(reversed) vs pyspi relabelled max_abs 1.53 / 1.10 / 0.93 at T=256 and 1.04 / 1.23 / 1.23 at T=1024, all 6 pairs differ"
    stat = ("cointegrated (0,1) c: -8.24 / -16.25 / -30.22 / -63.63 at T = 64 / 256 / 1024 / 4096 vs MacKinnon 5% values -3.43 / -3.36 / -3.34 / -3.34; "
            "ct: -8.34 / -15.92 / -30.05 / -63.65 vs -3.93 / -3.82 / -3.79 / -3.78; 12/12 pass (the (0,1) entry is the most negative; null pairs "
            "rejecting at 5%: up to 2 of 5 at T <= 256, none at T >= 1024)")
    size = "driftless walks, 400 reps: rejection at the MacKinnon 5% value 0.0525 / 0.0525 (c), 0.075 / 0.040 (ct-aic), 0.065 / 0.040 (ct-bic) at T = 256 / 1024 (se 0.011); per-replicate values exact (max_rel 3.2e-13)"
    confound = ("iid_gaussian c: median -11.24 / -28.14 / -63.10 at T = 256 / 1024 / 4096 (median / sqrt(T) = -0.70 / -0.88 / -0.99), every pair below the 5% value "
                "(least negative -9.97 / -20.12 / -45.85), vs the cointegrated (0,1) entry -16.25 / -30.22 / -63.63; delayed_noise median -32.93 "
                "(more negative than the cointegrated pair), var2_bivariate -25.18")
    api = "trending T=4096 channels (0,3): bivariate(D) -61.239 (y0 = z0) vs multivariate(D)[0,1] = [1,0] -0.3646 (y0 = z3), gap 60.875; after bivariate on the same Data, multivariate returns -61.239"
    cands = [
        dict(candidate="index-order dependence: the higher index is the dependent variable (loop order + two-key cache), so the value depends on channel order",
             outcome="confirmed",
             evidence=(f"{u}|cointegrated|{{256,1024}}|pipeline|orderdep-{{c,cta,ctb}}-p3210: " + orderdep
                       + f"; {u}|cointegrated|{{256,1024}}|pipeline|perm-{{c,cta,ctb}}-p3210 pass exactly with the rule 'y0 = higher permuted index' (max_rel 4.7e-15); "
                       + f"{u}|*|kernel|rev-*: " + rev + "; first measured by base.pair_handling|iid_gaussian|256|pipeline|upper-misc.Cointegration (max_abs 7.41)")),
        dict(candidate="API inconsistency: bivariate(D) and multivariate(D)[0,1] give different values for the same pair",
             outcome="confirmed",
             evidence=f"{u}|trending|4096|pipeline|api-c-p03 (exact pass of the reference vector): " + api),
        dict(candidate="sign/metadata: Unsigned class and 'negative t-statistic' comment vs the raw (negative) t-statistic returned; orientation opposite to Johansen",
             outcome="confirmed",
             evidence=(f"{u}|cointegrated|256|pipeline|meta: issigned() = 0; {u}|*|kernel|own-*: pyspi equals the raw ADF t-ratio (no sign flip), "
                       "all observed values negative (cointegrated T=1024 c: -30.22 to -1.65), more negative = stronger evidence")),
        dict(candidate="stationarity confound: on stationary inputs the statistic reflects residual stationarity, not coupling",
             outcome="confirmed",
             evidence=f"{u}|iid_gaussian|{{256,1024,4096}}|pipeline|confound-c, |delayed_noise|1024|pipeline|confound-c, |var2_bivariate|1024|pipeline|confound-c: " + confound),
        dict(candidate="exactly collinear pairs return -inf",
             outcome="confirmed",
             evidence=(f"{u}|shared_envelope|{{256,1024}}|pipeline|degen-{{c,cta,ctb}}: A[0,2] = A[2,0] = -inf, all other entries finite (6/6); "
                       f"{u}|cointegrated|256|pipeline|collinear-{{c,cta,ctb}}: 16/16 cases of [z, 3z+1] return -inf without raising")),
        dict(candidate="class label 'nonlinear' vs documented/config 'linear'",
             outcome="confirmed", evidence=f"{u}|cointegrated|256|pipeline|meta: [1, 0, 0, 1, 1]"),
        dict(candidate="misspelt method (e.g. 'AEG') builds an AEG identifier and then fails in the Johansen path",
             outcome="confirmed",
             evidence=f"{u}|cointegrated|256|pipeline|meta: Cointegration(method='AEG').bivariate -> AttributeError naming _det_order (code 1); not reachable from the shipped configs"),
    ]
    runs = [
        dict(run_ids=[f"{u}|{{cointegrated,iid_gaussian}}|{{256,1024,4096}}|kernel|own-{{c,cta,ctb}}", f"{u}|cointegrated|64|kernel|own-{{c,cta,ctb}}",
                      f"{u}|{{trending,var2_bivariate,delayed_noise}}|1024|kernel|own-*", f"{u}|cointegrated|1024|pipeline|own-*", f"{u}|trending|1024|pipeline-detrend|own-*"],
             reference=f"{REF}:handle_aeg own -> audit/checks/refs/_kernels_basic_misc.py:engle_granger_tstat", outcome="pass 36/36; " + own),
        dict(run_ids=[f"{u}|{{cointegrated,iid_gaussian}}|{{256,1024}}|kernel|urca-{{c,cta,ctb}}"], reference="audit/checks/r/coint.R df (urca 1.3.3 ur.df)",
             outcome="pass 12/12; " + urca),
        dict(run_ids=[f"{u}|{{cointegrated|256,cointegrated|1024,iid_gaussian|256,trending|4096,var2_bivariate|1024,delayed_noise|1024}}|kernel|rev-{{c,cta,ctb}}"],
             reference=f"{REF}:handle_aeg rev", outcome="fail 18/18 (expected; the gap is the asymmetry); " + rev),
        dict(run_ids=[f"{u}|cointegrated|{{256,1024}}|pipeline|orderdep-{{c,cta,ctb}}-p3210", f"{u}|cointegrated|{{256,1024}}|pipeline|perm-{{c,cta,ctb}}-p3210"],
             reference=f"{REF}:handle_aeg orderdep (same-lineage) / perm (independent)", outcome="orderdep fail 6/6 (expected), perm pass 6/6; " + orderdep),
        dict(run_ids=[f"{u}|cointegrated|{{64,256,1024,4096}}|pipeline|stat-{{c,cta,ctb}}", f"{u}|cointegrated|256|pipeline|crit-{{c,cta,ctb}}"],
             reference=f"{REF}:handle_aeg stat (make_data is_cointegrated + MacKinnon 2010 via probe crit)", outcome="pass 15/15; " + stat),
        dict(run_ids=[f"{u}|cointegrated|{{256,1024}}|pipeline|size-{{c,cta,ctb}}"], reference=f"{REF}:handle_aeg size", outcome="pass 6/6; " + size),
        dict(run_ids=[f"{u}|iid_gaussian|{{256,1024,4096}}|pipeline|confound-c", f"{u}|{{delayed_noise,var2_bivariate}}|1024|pipeline|confound-c"],
             reference=f"{REF}:handle_aeg confound", outcome="pass 5/5 (proposition holds); " + confound),
        dict(run_ids=[f"{u}|scaled_offset|1024|kernel|affine-{{c,cta,ctb}}", f"{u}|trending|1024|kernel|trendinv-{{c,cta,ctb}}"],
             reference=f"{REF}:handle_aeg affine / trendinv",
             outcome="affine pass 3/3 (max_abs 1.1e-13); trendinv ct pass 2/2 (4.4e-16), c fail (expected, gap 32.45: trend 'c' has no trend term)"),
        dict(run_ids=[f"{u}|shared_envelope|{{256,1024}}|pipeline|degen-{{c,cta,ctb}}", f"{u}|cointegrated|256|pipeline|collinear-{{c,cta,ctb}}",
                      f"{u}|trending|4096|pipeline|api-c-p03", f"{u}|cointegrated|256|pipeline|meta"],
             reference=f"{REF}:handle_aeg degen / collinear / api / meta", outcome="pass 11/11; " + api),
    ]
    upd = dict(
        check_method="independent-impl",
        check_reference=(f"{REF}:handle_aeg own -> audit/checks/refs/_kernels_basic_misc.py:engle_granger_tstat (numpy OLS + ADF, statsmodels lag rule mirrored); "
                         "audit/checks/r/coint.R df (R lm + urca 1.3.3 ur.df, external-pkg); MacKinnon (2010) values via audit/checks/probes/coint_probes.py:crit (literature-only)"),
        check_data="cointegrated T64/256/1024/4096 (kernel, pipeline, reversed channels); iid_gaussian T256/1024/4096; trending T1024/4096; var2_bivariate, delayed_noise, scaled_offset T1024; shared_envelope T256/1024; 400 simulated independent random-walk pairs per T (size probe)",
        agreement_criterion="exact rtol 1e-10 / atol 1e-12 (kernel); tolerance rtol 1e-8 (urca at the selected lag); tolerance 1e-9 for the reverse-orientation and visiting-order runs (expected to differ: the gap is the measurement); qualitative propositions for truth, confound, degenerate input and API",
        closeness="; ".join([own, urca, rev, orderdep, stat, size, confound, api]),
        verdict="variant",
        score_0_10=6,
        what_changed=("The kernel is the canonical Engle-Granger ADF t-ratio (fp-exact against the numpy kernel and R urca at the selected lag; "
                      "lag search on the common sample with re-fit, as statsmodels). The SPI is documented and labelled undirected, but EG is "
                      "asymmetric and pyspi fixes the regressand by channel index (the higher index is y0 under multivariate, the first argument "
                      "under bivariate). Reordering channels changes entries by up to 1.53 on cointegrated data (T=256), 7.41 on iid data and "
                      "60.9 on trending data (trend 'c'). The raw t-statistic is returned (negative, more negative = stronger) although the class "
                      "is Unsigned and the comment says 'negative t-statistic'. Interpretation limit: stationary unrelated pairs score like or "
                      "beyond the cointegrated pair. Collinear pairs give -inf."),
        new_finding=True,
        definition_under_review=False,
        check_cost="cheap: <= 0.6 s per plain pyspi run at T=4096 (3 configs); probes <= 10 s",
        symmetry_observed="sym (by mirroring): max|A - A.T| = 0.0 over every plain SPI run (107 runs, -inf pairs excluded), NaN diagonal; the underlying statistic is asymmetric (rev-* runs: up to 60.87 between orientations)",
        direction_observed=("A[i,j] = A[j,i] = EG t-statistic with y0 = z_max(i,j) regressed on z_min(i,j); the orientation follows the channel index, "
                            "not causality: var2_bivariate (x0 -> x1) stored -25.18 (y0 = x1) vs reverse -24.85; delayed_noise (x0 leads x1) stored -31.99 vs "
                            "reverse -32.06 (rev-c runs), i.e. no consistent directional meaning"),
        candidate_resolutions=cands,
        checks_run=runs,
    )
    return u, upd


ITEMS = [johansen(0, 1), johansen(0, 10), johansen(1, 1), johansen(1, 10), aeg()]

# trace-stage corrections refuted/refined by the checks (appended, so the trace text stays readable)
CORR = {
    J.format(d=1, k=1): ("deviation_from_canonical", " CHECK-STAGE CORRECTION: 'Differences shrink with T' holds for the cointegrated pair only. On non-cointegrated pairs the gap to case 4 persists (max_rel 0.26 max-eig / 0.34 trace at T=4096), while the gap to the unrestricted-trend case 5 shrinks to <= 1.2e-3; statsmodels' det_order-1 tables are case-5 quantiles (runs misc.coint.johansen_order-1_ardiff-1|cointegrated|*|kernel|canon-* and |cvmc)."),
    J.format(d=1, k=10): ("deviation_from_canonical", " CHECK-STAGE CORRECTION: 'Differences shrink with T' holds for the cointegrated pair only. On non-cointegrated pairs the gap to case 4 persists (max_rel 0.28 max-eig / 0.38 trace at T=4096), while the gap to the unrestricted-trend case 5 is <= 1.1e-2; statsmodels' det_order-1 tables are case-5 quantiles (runs misc.coint.johansen_order-1_ardiff-10|cointegrated|*|kernel|canon-* and misc.coint.johansen_order-1_ardiff-1|cointegrated|256|pipeline|cvmc)."),
}

for u, upd in ITEMS:
    p = REC / f"{u}.yaml"
    doc = yaml.safe_load(p.read_text())
    c = doc["correctness"]
    for k, v in upd.items():
        c[k] = v
    if u in CORR:
        f, txt = CORR[u]
        if "CHECK-STAGE CORRECTION" not in c[f]:
            c[f] = c[f] + txt
    doc["status"] = "checked"
    p.write_text(yaml.safe_dump(doc, sort_keys=False, allow_unicode=True, width=200, default_flow_style=False))
    print("wrote", p)
