# Probe C: PLI direction convention, antisymmetry, max-variant asymmetry, identical channels, wPLI eps floor
import numpy as np, warnings, contextlib, io, sys, json
warnings.filterwarnings('ignore')
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi.statistics import spectral as S
from pyspi._spectral_compat import spectral_connectivity as sc
from pyspi.data import Data
DATA='/media/dan/Data/git/pyspi/audit/checks/data'
def mk(x, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, dim_order='ps', **kw)
man = json.load(open(f'{DATA}/MANIFEST.json'))
def ent(name,T):
    for e in (man if isinstance(man,list) else man.get('datasets', man.values())):
        if isinstance(e,dict) and e.get('name')==name and e.get('T')==T: return e
    return None
e = ent('delayed_noise',1024); print('delayed_noise manifest params/desc:', e.get('params') if e else None, '|', e.get('description') if e else None)
D = np.load(f'{DATA}/delayed_noise_T1024.npz'); x=D['x']; print('files', D.files)
xz = (x - x.mean(1,keepdims=True))/x.std(1,ddof=1,keepdims=True)
c = sc.Connectivity.from_multitaper(sc.Multitaper(xz.T, sampling_frequency=1)); f=c.frequencies
pli = c.phase_lag_index()[0]; wpli = c.weighted_phase_lag_index()[0]
delays = e['params'].get('delays', e['params'].get('delay')) if e else [1,3,5]
print('delays', delays)
for j,dl in zip(range(1,x.shape[0]), list(delays)[1:] if len(list(delays))==x.shape[0] else delays):
    pred = np.sign(np.sin(2*np.pi*f*dl)); agree = np.mean(np.sign(pli[1:,0,j])==pred[1:])
    print(f'ch{j} delay {dl}: sign(PLI[0,j]) == sign(sin 2pi f d) on {agree:.3f} of non-DC bins; band mean {pli[:,0,j].mean():.4f} vs mean|PLI| {np.abs(pli[:,0,j]).mean():.4f}; wPLI band mean {wpli[:,0,j].mean():.4f}')
# pure delay, no noise
r = np.random.default_rng(5); x0 = r.standard_normal(1025); x1 = x0[:-1]; x0 = x0[1:]
c2 = sc.Connectivity.from_multitaper(sc.Multitaper(np.c_[x0,x1], sampling_frequency=1)); p2 = c2.phase_lag_index()[0]
print('pure delay x1(t)=x0(t-1): fraction non-DC bins PLI[0,1] == +1:', np.mean(p2[1:,0,1]==1), ' PLI[1,0] == -1:', np.mean(p2[1:,1,0]==-1))
# pyspi matrices on delayed_noise T=1024
d = mk(x)
for cls,nm in [(S.PhaseLagIndex,'pli'),(S.WeightedPhaseLagIndex,'wpli')]:
    Am = cls(statistic='mean').multivariate(d); Ax = cls(statistic='max').multivariate(d)
    print(nm, 'mean: max|A+A^T|=', np.nanmax(np.abs(Am+Am.T)), 'A[0,1]=',Am[0,1].round(4), '| max: max|A+A^T|=', np.nanmax(np.abs(Ax+Ax.T)).round(4), 'max|A-A^T|=', np.nanmax(np.abs(Ax-Ax.T)).round(4))
    per = (pli if nm=='pli' else wpli)
    print('   max-variant identity A[1,0] == -min_f L_01(f):', Ax[1,0], -per[:,0,1].min(), ' A[0,1] == max_f L_01:', Ax[0,1], per[:,0,1].max())
# shared_envelope
for T in [256,1024]:
    x = np.load(f'{DATA}/shared_envelope_T{T}.npz')['x']; d = mk(x); print(f'shared_envelope T={T} x2==x0', np.array_equal(x[2],x[0]))
    for cls,nm in [(S.PhaseLockingValue,'plv'),(S.PhaseLagIndex,'pli'),(S.WeightedPhaseLagIndex,'wpli'),(S.DebiasedSquaredPhaseLagIndex,'dspli'),(S.DebiasedSquaredWeightedPhaseLagIndex,'dswpli'),(S.PairwisePhaseConsistency,'ppc')]:
        Am = cls(statistic='mean').multivariate(d); Ax = cls(statistic='max').multivariate(d)
        print(f'   {nm}: mean A[0,2]={Am[0,2]} max A[0,2]={Ax[0,2]}  max A[0,1]={Ax[0,1]:.4f} A[1,0]={Ax[1,0]:.4f}')
# wPLI eps floor sweep
x = np.load(f'{DATA}/delayed_noise_T256.npz')['x']
for s in [1.0, 1e-6, 1e-7, 1e-8, 1e-10]:
    out=[]
    for cls,nm in [(S.WeightedPhaseLagIndex,'wpli'),(S.DebiasedSquaredWeightedPhaseLagIndex,'dswpli'),(S.PhaseLagIndex,'pli'),(S.PhaseLockingValue,'plv')]:
        A = cls().multivariate(mk(x*s, normalise=False)); out.append(f'{nm}={A[0,1]:.6f}')
    xs = x*s; cc = sc.Connectivity.from_multitaper(sc.Multitaper(xs.T, sampling_frequency=1)); wmean = np.abs(cc._cross_spectral_matrix[0,0,:,:,0,1].imag).mean(0)
    print('scale', s, ' '.join(out), '| mean_k|Im S| median over bins %.2e, eps=%.2e'%(np.median(wmean), np.finfo(float).eps))
