import numpy as np, sys, logging
logging.disable(logging.WARNING)
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi._spectral_compat import spectral_connectivity as sc
import spectral_connectivity.connectivity as C
import spectral_connectivity.minimum_phase_decomposition as M
def ct(a): return np.conj(np.swapaxes(a,-1,-2))
d = np.load('/media/dan/Data/git/pyspi/audit/checks/data/var2_bivariate_T1024.npz'); A1,A2,Sig = d['A1'],d['A2'],d['Sigma']
n=1024; f=np.fft.fftfreq(n); z=np.exp(-2j*np.pi*f)
Abar = np.eye(2)[None] - A1[None]*z[:,None,None] - A2[None]*(z**2)[:,None,None]; H=np.linalg.inv(Abar); S=H@Sig@ct(H)
for tol in [1e-8, 1e-12]:
    Psi = M.minimum_phase_decomposition(S[None], tolerance=tol, max_iterations=200)
    Sl = C._estimate_noise_covariance(Psi)[0]; Hl = C._estimate_transfer_function(Psi)[0][:(n+1)//2]
    print(f'tol={tol}: max|Sigma_lib-Sigma|={np.abs(Sl-Sig).max():.2e}  max|H_lib-H|={np.abs(Hl-H[:(n+1)//2]).max():.2e}  resid={np.abs(Psi@ct(Psi)-S[None]).max():.2e}')
# EEG band bin counts at T=512 and 1024 with exact k/2048 edges and .3g-rounded edges, inclusive rule
bands=[(1,4),(4,8),(8,12),(12,30),(30,70),(70,150),(150,250)]
for T in [512,1024]:
    fr=np.arange(T//2)/T; row=[]
    for lo,hi in bands:
        le,he=lo/2048,hi/2048; lr,hr=float(f'{le:.3g}'),float(f'{he:.3g}')
        row.append(f'{lo}-{hi}:{int(np.sum((fr>=le)&(fr<=he)))}/{int(np.sum((fr>=lr)&(fr<=hr)))}')
    print('T',T,'bins exact/rounded:',' '.join(row),' W=3/T ->',round(3/T*2048,2),'Hz at 2048Hz')
