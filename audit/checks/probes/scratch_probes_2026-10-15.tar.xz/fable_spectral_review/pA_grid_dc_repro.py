# Probe A: grid, DC bin, independent reproduction (scipy dpss + numpy fft), closed vs pairwise dspli
import numpy as np, warnings, contextlib, io, sys
warnings.filterwarnings('ignore')
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi._spectral_compat import spectral_connectivity as sc
from scipy.fft import next_fast_len
from scipy.signal.windows import dpss
DATA='/media/dan/Data/git/pyspi/audit/checks/data'
np.set_printoptions(precision=6, suppress=True, linewidth=160)
for T in [64,100,7,30]:
    x = np.random.default_rng(0).standard_normal((2,T))
    c = sc.Connectivity.from_multitaper(sc.Multitaper(x.T, sampling_frequency=1))
    f = c.frequencies
    print(f'T={T} n_fft={next_fast_len(T)} nbins={len(f)} first={f[0]} last={f[-1]:.6f} 0.25_on_grid={bool(np.any(f==0.25))} n_tapers={c.fourier_coefficients.shape[2]} n_obs={c.n_observations}',
          '| inclusive counts low/high/full', int(np.sum((f>=0)&(f<=0.25))), int(np.sum((f>=0.25)&(f<=0.5))), int(np.sum((f>=0)&(f<=0.5))),
          '| strict counts', int(np.sum((f>0)&(f<0.25))), int(np.sum((f>0.25)&(f<0.5))), int(np.sum((f>0)&(f<0.5))))
# DC bin
x = np.load(f'{DATA}/delayed_noise_T256.npz')['x']
xz = (x - x.mean(1,keepdims=True))/x.std(1,ddof=1,keepdims=True)
c = sc.Connectivity.from_multitaper(sc.Multitaper(xz.T, sampling_frequency=1))
Scsm = c._cross_spectral_matrix
print('Im S at DC max abs over tapers/pairs', np.abs(Scsm[0,0,:,0].imag).max(), ' | DC coefficient imag max', np.abs(c.fourier_coefficients[0,0,:,0].imag).max())
print('DC values [0,1]: PLV', c.phase_locking_value()[0,0,0,1], 'PLI', c.phase_lag_index()[0,0,0,1], 'wPLI', c.weighted_phase_lag_index()[0,0,0,1],
      'dspli', c.debiased_squared_phase_lag_index()[0,0,0,1], 'dswpli', c.debiased_squared_weighted_phase_lag_index()[0,0,0,1], 'ppc', c.pairwise_phase_consistency()[0,0,0,1])
# independent reproduction
T=256; P=xz.shape[0]
tap, eig = dpss(T, 3, 5, return_ratios=True)
xd = xz - xz.mean(1, keepdims=True)
X = np.fft.fft(xd[:,None,:]*tap[None,:,:], n=T, axis=-1)[:,:,:T//2]
Sk = X[:,None]*np.conj(X[None,:])            # (P,P,5,F)
plv_ref = np.abs((Sk/np.abs(Sk)).mean(2))
pli_ref = np.sign(Sk.imag).mean(2)
w = np.abs(Sk.imag).mean(2); w2 = np.where(w<np.finfo(float).eps,1,w)
wpli_ref = Sk.imag.mean(2)/w2
ppc_ref = (np.abs((Sk/np.abs(Sk)).sum(2))**2 - 5)/20
dspli_ref = (5*pli_ref**2-1)/4
im = Sk.imag; sgn = np.sign(im)
pair_pli2 = ((sgn.sum(2))**2 - (sgn**2).sum(2))/20
num = im.sum(2)**2 - (im**2).sum(2); den = np.abs(im).sum(2)**2 - (im**2).sum(2)
dswpli_ref = np.where(den==0, np.nan, num/np.where(den==0,1,den))
# PPC pairwise cosine form, explicit loop
th = np.angle(Sk); ppc_pair = np.zeros_like(ppc_ref)
for j in range(5):
    for k in range(j+1,5):
        ppc_pair += np.cos(th[:,:,j]-th[:,:,k])
ppc_pair *= 2/(5*4)
lib = {k: np.moveaxis(getattr(c,k)()[0], 0, -1) for k in ['phase_locking_value','phase_lag_index','weighted_phase_lag_index','debiased_squared_phase_lag_index','debiased_squared_weighted_phase_lag_index','pairwise_phase_consistency']}
print('scipy dpss eigenvalues', eig)
for name, ref in [('phase_locking_value',plv_ref),('phase_lag_index',pli_ref),('weighted_phase_lag_index',wpli_ref),('debiased_squared_phase_lag_index',dspli_ref),('debiased_squared_weighted_phase_lag_index',dswpli_ref),('pairwise_phase_consistency',ppc_ref)]:
    d = np.nanmax(np.abs(lib[name]-ref)); print(f'independent reproduction {name:45s}: max|lib-ref| = {d:.2e}  nan-pattern equal={np.array_equal(np.isnan(lib[name]), np.isnan(ref))}')
print('PPC pairwise-cosine explicit loop vs lib: max diff', np.nanmax(np.abs(lib['pairwise_phase_consistency']-ppc_pair)))
print('closed-form dspli vs pairwise form: max |diff| on non-DC bins', np.abs(dspli_ref[:,:,1:]-pair_pli2[:,:,1:]).max(), ' | at DC closed=', dspli_ref[0,1,0], 'pairwise=', pair_pli2[0,1,0])
print('DC PLV values over pairs', np.unique(np.round(lib['phase_locking_value'][:,:,0],6)), ' PPC DC values', np.unique(np.round(lib['pairwise_phase_consistency'][:,:,0],6)))
print('per-bin PLI value set (non-DC)', np.unique(np.round(lib['phase_lag_index'][:,:,1:],6)))
