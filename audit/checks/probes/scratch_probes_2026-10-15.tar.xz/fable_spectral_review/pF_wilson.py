# Probe F: NumPy-2 fallback, singular pair, Wilson call counts, residual vs padding, convergence, channel order, bias floor, ddtf scaling, dcoh bound
import numpy as np, warnings, contextlib, io, sys, logging
warnings.filterwarnings('ignore')
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi.statistics import spectral as S
from pyspi._spectral_compat import spectral_connectivity as sc
import spectral_connectivity.connectivity as C
import spectral_connectivity.minimum_phase_decomposition as M
from pyspi.data import Data
DATA='/media/dan/Data/git/pyspi/audit/checks/data'
np.set_printoptions(precision=4, suppress=True, linewidth=160)
def mk(x, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, dim_order='ps', **kw)
def ct(a): return np.conj(np.swapaxes(a,-1,-2))
def z(x): return (x-x.mean(1,keepdims=True))/x.std(1,ddof=1,keepdims=True)
print('numpy', np.__version__, 'hasattr(np.linalg,"linalg")', hasattr(np.linalg,'linalg'))
try:
    np.linalg.cholesky(np.array([[1.0,1.0],[1.0,1.0]]))
except Exception as e: print('cholesky of singular raises', type(e).__name__)
try:
    M._get_intial_conditions(np.ones((1,8,2,2),complex))
except Exception as e: print('_get_intial_conditions on singular CSM raises', type(e).__name__, str(e)[:80])
x = np.load(f'{DATA}/shared_envelope_T256.npz')['x']
try:
    A = S.DirectedTransferFunction().multivariate(mk(x)); print('shared_envelope dtf', A.round(3).tolist())
except Exception as e: print('shared_envelope DirectedTransferFunction.multivariate raised', type(e).__name__, str(e)[:80])
# Wilson call counts
orig = C.minimum_phase_decomposition; calls=[0]
def wrapped(*a, **k): calls[0]+=1; return orig(*a, **k)
C.minimum_phase_decomposition = wrapped
x = z(np.load(f'{DATA}/var2_bivariate_T256.npz')['x'])
con = sc.Connectivity.from_multitaper(sc.Multitaper(x.T, sampling_frequency=1))
for m in ['directed_transfer_function','directed_coherence','partial_directed_coherence','generalized_partial_directed_coherence','direct_directed_transfer_function']:
    calls[0]=0; getattr(con,m)(); print('Wilson runs per call', m, calls[0])
C.minimum_phase_decomposition = orig
# residual vs padding
logging.disable(logging.WARNING)
x = z(np.load(f'{DATA}/var2_bivariate_T1024.npz')['x'])
for nfft in [1024, 2048]:
    con = sc.Connectivity.from_multitaper(sc.Multitaper(x.T, sampling_frequency=1, n_fft_samples=nfft))
    Sx = con._expectation_cross_spectral_matrix(); Psi = M.minimum_phase_decomposition(Sx)
    R = Psi@ct(Psi) - Sx; rel = np.abs(R).max()/np.abs(Sx).max()
    lagR = np.abs(np.fft.ifft(R, axis=-3)[0]).max(axis=(1,2)); top = np.argsort(lagR)[::-1][:4]
    tot = lagR.sum(); print(f'n_fft={nfft}: rel resid {rel:.2e}; top residual lags {top.tolist()} share of lag-sum at top lag {lagR[top[0]]/tot:.2f}; DTF[1,0] mean f>0 {con.directed_transfer_function()[0][1:,1,0].mean():.4f}')
logging.disable(logging.NOTSET)
# convergence capture
class Cap(logging.Handler):
    def __init__(s): super().__init__(); s.msgs=[]
    def emit(s, r): s.msgs.append(r.getMessage())
cap = Cap(); lg = logging.getLogger('spectral_connectivity.minimum_phase_decomposition'); lg.addHandler(cap); lg.setLevel(logging.WARNING)
for name,T in [('logistic_maps',1024),('logistic_maps',4096),('narrowband_f0-0.25',1024),('var2_bivariate',1024)]:
    cap.msgs.clear(); x = z(np.load(f'{DATA}/{name}_T{T}.npz')['x'][:2])
    con = sc.Connectivity.from_multitaper(sc.Multitaper(x.T, sampling_frequency=1)); Sx = con._expectation_cross_spectral_matrix(); Psi = M.minimum_phase_decomposition(Sx)
    rel = np.abs(Psi@ct(Psi)-Sx).max()/np.abs(Sx).max()
    print(f'{name} T={T}: warnings={cap.msgs[:1]} rel resid {rel:.3f}')
lg.removeHandler(cap); logging.disable(logging.WARNING)
# channel order dependence
x = z(np.load(f'{DATA}/var2_bivariate_T1024.npz')['x'])
L01 = sc.Connectivity.from_multitaper(sc.Multitaper(x.T, sampling_frequency=1)).directed_transfer_function()[0][:,0,1]
L10 = sc.Connectivity.from_multitaper(sc.Multitaper(x[[1,0]].T, sampling_frequency=1)).directed_transfer_function()[0][:,1,0]
print('channel-order: max|DTF01(x0,x1) - DTF10(x1,x0)| per bin', np.abs(L01-L10).max(), ' band-mean diff', abs(L01[1:].mean()-L10[1:].mean()))
# bias floor on iid pairs, library direct
for T in [64,256,1024,4096,16384]:
    vals=[]
    for seed in range(4):
        x = np.random.default_rng(seed).standard_normal((2,T)); con = sc.Connectivity.from_multitaper(sc.Multitaper(z(x).T, sampling_frequency=1))
        L = con.directed_transfer_function()[0][1:]; vals += [L[:,0,1].mean(), L[:,1,0].mean()]
    print(f'iid null DTF band mean T={T}: {np.mean(vals):.4f} (sd over 8 values {np.std(vals):.4f})')
# ddtf scaling
for T in [256,1024,4096]:
    x = z(np.load(f'{DATA}/var2_bivariate_T{T}.npz')['x']); con = sc.Connectivity.from_multitaper(sc.Multitaper(x.T, sampling_frequency=1))
    dd = con.direct_directed_transfer_function()[0][1:]; print(f'ddtf T={T}: mean[1,0]={dd[:,1,0].mean():.5f} x sqrt(T/2)={dd[:,1,0].mean()*np.sqrt(T/2):.4f}')
# dcoh bound
x = np.load(f'{DATA}/logistic_maps_T4096.npz')['x']; A = S.DirectedCoherence().multivariate(mk(x)); print('logistic_maps T=4096 dcoh', A.round(3).tolist())
