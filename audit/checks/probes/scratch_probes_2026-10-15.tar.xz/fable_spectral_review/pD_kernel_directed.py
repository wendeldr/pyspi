# Probe D: exact-spectrum kernel: library direction, DTF/PDC/gPDC canonical, dcoh and ddtf formulas
import numpy as np, sys, logging
logging.disable(logging.WARNING)
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi._spectral_compat import spectral_connectivity as sc
import spectral_connectivity.connectivity as C
np.set_printoptions(precision=5, suppress=True, linewidth=160)
def ct(a): return np.conj(np.swapaxes(a,-1,-2))
def run(A_list, Sig, n=1024, label=''):
    P = Sig.shape[0]; f = np.fft.fftfreq(n); z = np.exp(-2j*np.pi*f)
    Abar = np.eye(P)[None].astype(complex)
    for k,A in enumerate(A_list, start=1): Abar = Abar - A[None]*(z**k)[:,None,None]
    H = np.linalg.inv(Abar); S = H @ Sig @ ct(H)
    class Exact(C.Connectivity):
        def _expectation_cross_spectral_matrix(self, fcn=None, dtype=None): return S[None]
    con = Exact(fourier_coefficients=np.zeros((1,1,1,n,P),complex), frequencies=f)
    nn=(n+1)//2; Hn=H[:nn]; An=Abar[:nn]; sig2=np.diag(Sig)
    Hl = con._transfer_function[0]; Sl = con._noise_covariance[0]
    print(f'--- {label}: max|H_lib-H_true|={np.abs(Hl-Hn).max():.2e} max|Sigma_lib-Sigma|={np.abs(Sl-Sig).max():.2e}')
    lib = {m: getattr(con,m)()[0] for m in ['directed_transfer_function','directed_coherence','partial_directed_coherence','generalized_partial_directed_coherence','direct_directed_transfer_function']}
    DTF = np.abs(Hn)**2/(np.abs(Hn)**2).sum(-1,keepdims=True)
    PDC = np.abs(An)**2/(np.abs(An)**2).sum(-2,keepdims=True)
    gPDC = (np.abs(An)**2/sig2[:,None])/((np.abs(An)**2/sig2[:,None]).sum(-2,keepdims=True))
    DC = (sig2[None,:]*np.abs(Hn)**2)/((sig2[None,:]*np.abs(Hn)**2).sum(-1,keepdims=True))
    M = np.linalg.inv(S[:nn]); Mii = np.real(np.einsum('fii->fi',M))
    pcoh2 = np.abs(M)**2/(Mii[:,:,None]*Mii[:,None,:])
    F2 = np.abs(Hn)**2/(np.abs(Hn)**2).sum(axis=(0,2),keepdims=True)
    print('  DTF lib vs canonical |H_ij|^2/sum_m|H_im|^2 :', np.abs(lib['directed_transfer_function']-DTF).max())
    print('  PDC lib vs canonical |A_ij|^2/sum_k|A_kj|^2 :', np.abs(lib['partial_directed_coherence']-PDC).max())
    print('  gPDC lib vs canonical squared gPDC          :', np.abs(lib['generalized_partial_directed_coherence']-gPDC).max())
    print('  DC lib vs canonical squared DC (source var) :', np.abs(lib['directed_coherence']-DC).max(), '| vs |H|^2/sqrt(sum_k|H_ik|^2):', np.abs(lib['directed_coherence']-np.abs(Hn)**2/np.sqrt((np.abs(Hn)**2).sum(-1,keepdims=True))).max(), '| lib DC max', lib['directed_coherence'].max())
    print('  dDTF lib vs F^2*C^2 (K2003)                 :', np.abs(lib['direct_directed_transfer_function']-F2*pcoh2).max(), '| vs |F|*|PDC|:', np.abs(lib['direct_directed_transfer_function']-np.sqrt(F2)*np.sqrt(PDC)).max())
    print('  off-diag DTF vs PDC (lib):', np.abs((lib['directed_transfer_function']-lib['partial_directed_coherence'])[:,0,1]).max() if P==2 else 'n/a P>2')
    for m,L in lib.items():
        print(f'  {m[:34]:34s} mean f>0 matrix:', L[1:].mean(0).round(4).tolist())
    print('  truth nonzero (source->target):', [(j,i) for i in range(P) for j in range(P) if i!=j and any(A[i,j]!=0 for A in A_list)])
# toy VAR(1): x1 <- x0
run([np.array([[0.5,0.0],[0.4,0.3]])], np.eye(2), label='toy VAR(1) x0->x1 (A[1,0]=0.4)')
d = np.load('/media/dan/Data/git/pyspi/audit/checks/data/var2_bivariate_T1024.npz'); print('var2_bivariate A1', d['A1'].tolist(), 'A2', d['A2'].tolist(), 'Sigma', d['Sigma'].tolist())
run([d['A1'], d['A2']], d['Sigma'], label='var2_bivariate exact')
d = np.load('/media/dan/Data/git/pyspi/audit/checks/data/var2_chain_T1024.npz'); print('var2_chain A1', d['A1'].tolist(), 'A2', d['A2'].tolist())
run([d['A1'], d['A2']], d['Sigma'], label='var2_chain exact (3-channel)')
