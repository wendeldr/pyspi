import numpy as np, sys, warnings
warnings.filterwarnings('ignore'); sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi._spectral_compat import spectral_connectivity as sc
from scipy.signal.windows import dpss
x = np.load('/media/dan/Data/git/pyspi/audit/checks/data/delayed_noise_T256.npz')['x']
xz = (x - x.mean(1,keepdims=True))/x.std(1,ddof=1,keepdims=True)
c = sc.Connectivity.from_multitaper(sc.Multitaper(xz.T, sampling_frequency=1))
T=256; tap,_ = dpss(T,3,5,return_ratios=True)
xd = xz - xz.mean(1,keepdims=True)
X = np.fft.fft(xd[:,None,:]*tap[None,:,:], n=T, axis=-1)[:,:,:T//2]
Sk = X[:,None]*np.conj(X[None,:])
pli_ref = np.sign(Sk.imag).mean(2)                     # (P,P,F)
pli_lib = np.moveaxis(c.phase_lag_index()[0],0,-1)
D = np.abs(pli_lib-pli_ref); idx = np.unravel_index(np.argmax(D), D.shape); i,j,f = idx
print('max diff', D.max(), 'at (i,j,f)=', idx, 'n bins with diff>1e-9:', int((D>1e-9).sum()), 'of', D.size)
print('lib per-taper Im S:', c._cross_spectral_matrix[0,0,:,f,i,j].imag)
print('ref per-taper Im S:', Sk[i,j,:,f].imag)
print('lib tapers vs scipy tapers max|diff| (allowing sign):', min(np.abs(c_t - s_t).max() for c_t, s_t in [(np.asarray(sc.Multitaper(xz.T, sampling_frequency=1).tapers), tap), (np.asarray(sc.Multitaper(xz.T, sampling_frequency=1).tapers), -tap)]))
lt = np.asarray(sc.Multitaper(xz.T, sampling_frequency=1).tapers)
print('per-taper max|lib_taper - scipy_taper| (sign-aligned):', [float(min(np.abs(lt[k]-tap[k]).max(), np.abs(lt[k]+tap[k]).max())) for k in range(5)])
# which (i,j,f) differ and are they diagonal / DC?
where = np.argwhere(D>1e-9); print('differing entries (i,j,f) first 10:', where[:10].tolist(), '| all on diagonal?', bool(np.all(where[:,0]==where[:,1])), '| any at DC?', bool(np.any(where[:,2]==0)))
# near-zero |Im S| at non-DC off-diagonal bins in lib (sign-tie risk)
im = c._cross_spectral_matrix[0,0,:,1:T//2].imag; off = ~np.eye(4,dtype=bool)
print('lib min |Im S| over tapers, non-DC bins, off-diagonal pairs:', np.abs(im[:,:,off]).min(), ' count < 1e-12:', int((np.abs(im[:,:,off])<1e-12).sum()))
