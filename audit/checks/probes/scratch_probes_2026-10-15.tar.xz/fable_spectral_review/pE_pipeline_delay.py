# Probe E: pipeline direction on var2_bivariate/logistic_maps, delayed-copy inversion, OLS VAR reference, more tapers
import numpy as np, warnings, contextlib, io, sys, json, logging
warnings.filterwarnings('ignore'); logging.disable(logging.WARNING)
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi.statistics import spectral as S
from pyspi._spectral_compat import spectral_connectivity as sc
from pyspi.data import Data
DATA='/media/dan/Data/git/pyspi/audit/checks/data'
np.set_printoptions(precision=4, suppress=True, linewidth=160)
def mk(x, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, dim_order='ps', **kw)
man = json.load(open(f'{DATA}/MANIFEST.json'))
items = man if isinstance(man,list) else (man.get('datasets') if isinstance(man.get('datasets'),list) else list(man.values()))
for e in items:
    if isinstance(e,dict) and e.get('name') in ('logistic_maps','var2_bivariate','delayed_noise','var2_chain') and e.get('T')==4096:
        print('MANIFEST', e['name'], 'params', e.get('params'), '| desc', e.get('description'))
for name in ['var2_bivariate','logistic_maps','var2_chain']:
    x = np.load(f'{DATA}/{name}_T4096.npz')['x']; d = mk(x)
    A = S.DirectedTransferFunction().multivariate(d); G = S.GeneralizedPartialDirectedCoherence().multivariate(d); Dc = S.DirectedCoherence().multivariate(d); Pd = S.PartialDirectedCoherence().multivariate(d)
    print(name, 'dtf', A.round(4).tolist(), '| gpdcoh', G.round(4).tolist(), '| dcoh', Dc.round(4).tolist(), '| max|dtf-pdcoh| offdiag', np.nanmax(np.abs(A-Pd)))
x = np.load(f'{DATA}/delayed_noise_T4096.npz')['x']; d = mk(x)
A = S.DirectedTransferFunction().multivariate(d); G = S.GeneralizedPartialDirectedCoherence().multivariate(d)
print('delayed_noise T=4096 dtf', A.round(3).tolist(), '| gpdcoh', G.round(3).tolist())
# delayed copy with controlled noise, OLS VAR(2) reference DTF
def ols_var_dtf(x, p=2, nf=512):
    P,T = x.shape; Y = x[:,p:].T; Z = np.hstack([x[:,p-k:T-k].T for k in range(1,p+1)])
    B = np.linalg.lstsq(Z, Y, rcond=None)[0]  # (P*p, P): Y = Z B
    A_list = [B[(k*P):(k+1)*P,:].T for k in range(p)]
    f = np.arange(1,nf)/(2*nf); z = np.exp(-2j*np.pi*f)
    Abar = np.eye(P)[None].astype(complex)
    for k,A in enumerate(A_list, start=1): Abar = Abar - A[None]*(z**k)[:,None,None]
    H = np.linalg.inv(Abar); DTF = np.abs(H)**2/(np.abs(H)**2).sum(-1,keepdims=True)
    return DTF.mean(0)
for s in [0.1, 0.5, 1.0]:
    for seed in [0,1,2]:
        r = np.random.default_rng(seed); x0 = r.standard_normal(4097); x1 = x0[:-1] + s*r.standard_normal(4096); x0 = x0[1:]
        xx = np.c_[x0,x1]; xx = (xx-xx.mean(0))/xx.std(0,ddof=1)
        out=[]
        for NW in [3, 12]:
            m = sc.Multitaper(xx, sampling_frequency=1, time_halfbandwidth_product=NW); con = sc.Connectivity.from_multitaper(m)
            L = con.directed_transfer_function()[0][1:]; Gp = con.generalized_partial_directed_coherence()[0][1:]
            out.append(f'NW={NW}(K={m.n_tapers}) DTF[0,1]={L[:,0,1].mean():.3f} [1,0]={L[:,1,0].mean():.3f} gPDC[0,1]={Gp[:,0,1].mean():.3f} [1,0]={Gp[:,1,0].mean():.3f}')
        O = ols_var_dtf(xx.T); out.append(f'OLS-VAR(2) DTF[0,1]={O[0,1]:.3f} [1,0]={O[1,0]:.3f}')
        print(f's={s} seed={seed}:', ' | '.join(out))
