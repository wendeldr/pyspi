# Probe B: null levels, max-variant saturation across many seeds, plv_max growth
import numpy as np, warnings, contextlib, io, sys
warnings.filterwarnings('ignore')
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi.statistics import spectral as S
from pyspi.data import Data
DATA='/media/dan/Data/git/pyspi/audit/checks/data'
def mk(x, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, dim_order='ps', **kw)
K=5
rng=np.random.default_rng(1); th=rng.uniform(0,2*np.pi,(2000000,K)); R=np.abs(np.exp(1j*th).mean(1))
print('MC E|R_5| uniform phases', R.mean().round(5), 'sqrt(pi/(4K))', np.sqrt(np.pi/(4*K)).round(5))
# DC null: |mean of 5 iid signs|
s = rng.choice([-1,1], size=(2000000,5)).mean(1); print('E|mean of 5 signs| (DC PLV null)', np.abs(s).mean().round(5))
classes=[(S.PhaseLockingValue,'plv'),(S.PhaseLagIndex,'pli'),(S.WeightedPhaseLagIndex,'wpli'),(S.DebiasedSquaredPhaseLagIndex,'dspli'),(S.DebiasedSquaredWeightedPhaseLagIndex,'dswpli'),(S.PairwisePhaseConsistency,'ppc')]
for T in [64,256,1024,4096]:
    x = np.load(f'{DATA}/iid_gaussian_T{T}.npz')['x']; P=x.shape[0]; iu=np.triu_indices(P,1); d=mk(x)
    row=[]
    for cls,nm in classes:
        Am = cls(statistic='mean').multivariate(d); Ax = cls(statistic='max').multivariate(d)
        row.append(f'{nm}: mean={np.nanmean(Am[iu]):.4f} max_mean={np.nanmean(Ax[iu]):.4f} max_min={np.nanmin(Ax[iu]):.3f} frac_sat={np.mean(Ax[iu]>=1-1e-12):.2f}')
    print(f'T={T} P={P}', ' | '.join(row))
# saturation across 30 fresh iid seeds, P=5, T in {64,256,1024}
for T in [64,256,1024]:
    frac={nm:[] for _,nm in classes}
    for seed in range(30):
        x = np.random.default_rng(1000+seed).standard_normal((5,T)); d=mk(x); iu=np.triu_indices(5,1)
        for cls,nm in classes:
            Ax = cls(statistic='max').multivariate(d)
            frac[nm].append(np.mean(Ax[iu]>=1-1e-12))
    print(f'T={T} fraction of pairs with max==1 over 30 seeds x 10 pairs:', {k:(round(float(np.mean(v)),3), 'min per-seed', round(float(np.min(v)),2)) for k,v in frac.items()})
