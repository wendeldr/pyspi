import yaml
f='/media/dan/Data/git/pyspi/audit/records/distance.hhg.yaml'
d=yaml.safe_load(open(f)); c=d['correctness']
c['check_reference'] += ('; audit/checks/refs/hhg_mgc.py:ref_perm (per-pair conditional permutation null, 200 permutations of y on exact distances; '
  'trace proposed check [4]); calibration probes scratchpad hhg_mgc_check/p_perm_ks_calibration.py, p_perm_other_draws.py, p_null_marginals.py')
c['check_data'] += '; iid_gaussian and gauss_ar1_pair T64/T256 kernel (per-pair permutation null)'
c['agreement_criterion'] += ('; qualitative per-pair permutation null (200 permutations of y): iid_gaussian pass = KS of the 10 pair percentiles vs U(0,1) '
  'p >= 0.05 and no upper-tail permutation p < 0.05/10; gauss_ar1_pair pass = upper-tail p < 0.025 (detection only, permutation ignores autocorrelation)')
c['closeness'] += (' Permutation null (|perm, 200 permutations per pair): iid_gaussian|64|kernel|perm FAILS the uniformity criterion (KS p 0.0109, '
  'percentiles 0.085 to 0.695, mean 0.309; smallest upper-tail p 0.308, so no pair is flagged as dependent); |256|kernel|perm passes (KS p 0.124, '
  'percentiles 0.0 to 0.74, smallest upper-tail p 0.264). Both failures and near-failures are in the LOWER tail (pyspi below its own permutation null). '
  'The pooled permutation-null mean equals the analytic E[T] within MC error: z = -0.60 (iid T64), 1.08 (iid T256), -1.12 and 1.21 (gauss_ar1_pair T64, T256). '
  'gauss_ar1_pair|64|kernel|perm and |256|kernel|perm pass: pyspi 7945.2 and 315100.7 above all 200 permutations (percentile 1.0, p_upper 0.005; '
  'permutation means 3768.3 and 65778.0). Calibration probe (scratchpad hhg_mgc_check/p_perm_ks_calibration.py, 400 fresh 5 x 64 iid draws): the KS '
  'criterion fails on 5.75% of null draws and reaches KS p <= 0.012 on 0.75%; the mean pair percentile is 0.4955 (SD 0.093) and is <= 0.31 on 2.0% of draws.')
c['check_cost'] = ('expensive: O(T^3) per ordered pair. pyspi def-p23 (two ordered calls at T=1024) took 28.9 s in the first run (14.4 s per call) and 17.7 s '
  'in the forced re-run (machine load differs); T=4096 not run (trace estimate about 6 min per call); the 48 runs took 63.9 s of pyspi time in the re-run. '
  'Reference side: the T=256 Monte Carlo null (2000 draws) about 4 min; the per-pair permutation null 212.5 s for iid_gaussian T=256 (10 pairs x 200) and '
  '17.9 s for gauss_ar1_pair T=256. The trace proposed check [4] (200-permutation null per pair on iid_gaussian and gauss_ar1_pair, kernel) was run as '
  'proposed (|perm runs); the analytic E[T] with a Monte Carlo SD (|null runs) and the Monte Carlo quantile band (|order runs) are additional, not a '
  'replacement. Not run: T=1024 permutation nulls (about 2000 x 2 s) and any KS pooling across T')
c['checks_run'].append(dict(
  run_ids=['distance.hhg|iid_gaussian|64|kernel|perm','distance.hhg|iid_gaussian|256|kernel|perm','distance.hhg|gauss_ar1_pair|64|kernel|perm','distance.hhg|gauss_ar1_pair|256|kernel|perm'],
  reference='audit/checks/refs/hhg_mgc.py:ref_perm (200 permutations per pair of hhg_from_dist on exact distances; KS vs U(0,1))',
  outcome=('pass 3/4, fail 1/4: iid_gaussian T64 fails the KS uniformity criterion (p 0.0109, lower tail; no upper-tail rejection); iid_gaussian T256 '
           'passes (KS p 0.124); gauss_ar1_pair T64/T256 pass (percentile 1.0). Permutation-null mean vs analytic E[T]: |z| <= 1.21 on all four')))
for cr in c['candidate_resolutions']:
    if cr['candidate'].startswith('pyspi returns the raw permutation statistic'):
        cr['evidence'] += ('; permutation-null means 3829.6 (n=64) and 64881.0 (n=256) equal the analytic E[T] within MC error '
                           '(distance.hhg|iid_gaussian|{64,256}|kernel|perm, z -0.60 and 1.08)')
open(f,'w').write(yaml.safe_dump(d,sort_keys=False,width=200,allow_unicode=True,default_flow_style=False))
