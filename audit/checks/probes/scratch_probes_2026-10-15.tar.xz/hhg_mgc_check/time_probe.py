import sys, time, numpy as np, warnings
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import make_data
from hyppo.independence import HHG, MGC
for T in [256, 1024]:
    x = make_data.load('bivariate_gaussian', T)['x']
    a, b = x[2][:,None], x[3][:,None]
    t0=time.perf_counter(); HHG().statistic(a,b); t1=time.perf_counter()
    MGC().statistic(a,b); t2=time.perf_counter()
    print(T, 'hhg', round(t1-t0,2), 'mgc', round(t2-t1,2))
x = make_data.load('bivariate_gaussian', 4096)['x']
t0=time.perf_counter(); MGC().statistic(x[2][:,None],x[3][:,None]); print(4096,'mgc',time.perf_counter()-t0)
