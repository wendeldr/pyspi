import sys, time, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import hhg_mgc as H
rng=np.random.default_rng(0)
for n in (256,1024):
    a,b=rng.standard_normal(n),rng.standard_normal(n)
    t=time.time(); H.hhg_from_dist(H._pdist(a),H._pdist(b)); print('hhg',n,time.time()-t)
for n in (256,1024,4096):
    a,b=rng.standard_normal(n),rng.standard_normal(n)
    t=time.time(); H.mgc_from_dist(H._pdist(a),H._pdist(b)); print('mgc',n,time.time()-t)
