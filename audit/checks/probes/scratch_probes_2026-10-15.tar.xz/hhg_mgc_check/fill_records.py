import yaml
R = "/media/dan/Data/git/pyspi/audit/records/"
REF = "audit/checks/refs/hhg_mgc.py"
PROBE = "audit/checks/probes/hhg_mgc_probes.py"

def rid(u, ds, T, path, tag):
    return f"{u}|{ds}|{T}|{path}|{tag}"

# ------------------------------------------------------------------ HHG
H = "distance.hhg"
doc = yaml.safe_load(open(R + H + ".yaml"))
c = doc["correctness"]
c["deviation_from_canonical"] += (
    " Check-stage addition: on the raw (kernel-path) logistic_maps rows the rounding effect is larger, 4.9% relative at T=256"
    " (distance.hhg|logistic_maps|256|kernel|exact: pyspi 858472.24 vs exact-distance 818546.71), against 1.4% after z-scoring"
    " (|pipeline|exact: 825361.34 vs 813945.24). For the bit-identical copy shared_envelope (0,2) on raw rows at T=64, pyspi gives"
    " 242110 = N(N-2)(N-3) + (N-2), one more non-zero-margin table than the analytic maximum 242048 that exact distances reproduce.")
c["units_and_range"] += (
    " Check-stage addition: under independence (continuous data) the exact null mean is E[T] = n(n-2)(n-3)/(n-1), derived from the"
    " hypergeometric table (E[S | margins > 0] = N/(N-1), N = n-2) and P(no zero margin) = ((n-3)/(n-1))^2: 3842.0 at n=64 and"
    " 64514.0 at n=256 (Monte Carlo of 2000 iid pairs at n=256: 64814 +- 318 SE, skewness 0.98).")
c.update({
    "check_method": "independent-impl",
    "check_reference": (f"{REF}:hhg_from_dist (Heller, Heller & Gorfine 2013 Sec. 2 from scratch: exact |x_a - x_b|, '<=' indicators over"
        f" k not in {{i,j}}, zero-margin rule, cumulative-histogram counts; cross-validated in --selftest against"
        f" audit/checks/refs/_kernels_distance.py:hhg, including tied data); {REF}:ref_copies and ref_dup (analytic N(N-2)(N-3) for identical"
        f" rankings); {REF}:ref_null (analytic E[T] = n(n-2)(n-3)/(n-1) with Monte Carlo SD); {REF}:mc_quantile_band (exact rank null by"
        f" Monte Carlo, 2000 draws); {REF}:ref_hyppo_exact with probe {PROBE}:hyppo_exact (same-lineage attribution aid: hyppo HHG fed exact"
        f" distances); {PROBE}:copies"),
    "check_data": ("iid_gaussian, bivariate_gaussian, nonlinear_dependence, anm, contaminated, var2_bivariate T64/T256 kernel; bivariate_gaussian"
        " processes (2,3) T1024 kernel; bivariate_gaussian T256 pipeline; logistic_maps and shared_envelope T64/T256 kernel and T256 pipeline"
        " (tied-data attribution); iid_gaussian copies T64/T256; shared_envelope (0,2) T64; var2_bivariate, logistic_maps_chaotic, delayed_noise,"
        " gauss_ar1_pair T256 pipeline (direction); iid_gaussian T64/T256 pipeline (null); nonlinear_dependence, bivariate_gaussian, anm T256"
        " (ordering); scaled_offset T256; trending T256 pipeline and pipeline-detrend"),
    "agreement_criterion": ("tolerance rtol 1e-12 against the from-scratch statistic on exact distances (continuous data) or on sklearn-mirrored"
        " distances (tied data); exact rtol/atol 1e-12 against the analytic identical-ranking value; statistical |pyspi - E[T]| <= z_(1-0.025/m)"
        " Monte Carlo SD; qualitative: dependent pairs above and independent pairs inside the empirical family-wise null band"
        " [q(0.025/6), q(1-0.025/6)] of 2000 Monte Carlo draws"),
    "closeness": ("Continuous data: all 14 def runs (6 datasets x T64/T256 kernel, bivariate_gaussian T256 pipeline, bivariate_gaussian (2,3) T1024)"
        " max_abs 0.0, i.e. pyspi equals the from-scratch Heller et al. statistic bit for bit; dir runs (var2_bivariate, logistic_maps_chaotic,"
        " delayed_noise, gauss_ar1_pair T256 pipeline) max_abs 0.0; scaled_offset|256|pipeline|scaleinv 0.0; trending trend/detrend 0.0. Analytic:"
        " iid_gaussian|64|kernel|copies and |256|kernel|copies give exactly N(N-2)(N-3) = 242048 and 16451072 on the copy and affine-copy pairs"
        " (max_abs 0.0); shared_envelope|64|pipeline|dup 242048 exactly. Tied data against EXACT distances (expected fails, rounding candidate):"
        " logistic_maps|256|kernel|exact max_rel 4.88e-2 (858472.24 vs 818546.71), |256|pipeline|exact 1.40e-2, |64|kernel|exact 9.9e-3;"
        " shared_envelope|256|kernel|exact 3.73e-3 (abs 8128 = 32 x 254), |256|pipeline|exact 4.32e-3, |64|kernel|exact abs 62 = n-2; the same"
        " pairs match the reference on sklearn-mirrored distances (4 skdist runs, max_abs 0.0) and hyppo fed exact distances matches the"
        " exact-distance reference (4 hyppo-exact runs, max_abs 0.0). Null: iid_gaussian|64|pipeline|null mean over pairs 3290.4 vs E[T] 3842.0"
        " (max_z 0.96), |256|pipeline|null 53204.2 vs 64514.0 (max_z 1.44). Ordering (T256): band [38512, 118786]; nonlinear_dependence (0,1)"
        " 3286900.5 and (2,3) 1620054.8, anm 2510927.2 / 5409301.4, bivariate_gaussian rho=0.8 1940899.5 > rho=0.3 150648.4, all independent"
        " pairs inside the band (largest anm (0,3) 103653.7, null upper tail 0.0165). Trend: (1,2) 2086441.8 and (1,3) 5532123.2 without detrend,"
        " 61082.4 and 49758.8 after detrend."),
    "verdict": "matches",
    "score_0_10": 9,
    "what_changed": ("The computation is the canonical Heller, Heller & Gorfine (2013) sum of Pearson chi-square statistics, reproduced bit for bit on"
        " continuous data, so not 10 only because the supplement/GitBook text misdescribes it ('RKHS-based statistic that uses the ranks of"
        " random variables to obtain sample kernel matrices') and labels it undirected while the class is Directed (rubric 9: matches canonical"
        " up to a documented-convention issue). Two input conventions change values on tied or near-tied data only: ranks are taken over"
        " sklearn dot-product distances, so exact ties and near-ties are resolved by rounding (up to 4.9% relative on raw logistic_maps T=256,"
        " root cause REVIEW M2); and pyspi returns the raw T, whose null mean n(n-2)(n-3)/(n-1) grows like T^2, so values are not comparable"
        " across window lengths."),
    "new_finding": True,
    "definition_under_review": False,
    "check_cost": ("expensive: O(T^3) per ordered pair; pyspi 28.9 s for the two ordered calls at T=1024 (14.4 s per call); T=4096 not run"
        " (trace estimate about 6 min per call); 44 runs took 79 s of pyspi time; the T=256 Monte Carlo null (2000 draws) took about 4 min"),
    "symmetry_observed": ("sym: max|A - A.T| = 0.0 on every HHG run (all def, dir, exact, skdist, trend and scaleinv runs report"
        " ref_pyspi_asym 0.0), although the class is Directed and computes both orders"),
    "direction_observed": ("No direction information. A[i,j] = A[j,i] bit for bit on var2_bivariate (x0 -> x1; 123220.1 both orders),"
        " logistic_maps_chaotic (x -> y; 213720.7), gauss_ar1_pair (315100.7) and delayed_noise at T=256 (distance.hhg|*|256|pipeline|dir);"
        " A[i,j] = HHG(process i, process j) equals the from-scratch value for both argument orders (max_abs 0.0). delayed_noise pairs are at"
        " null level (e.g. (0,1) 74162.8, null upper tail 0.22) because HHG is contemporaneous and the delayed copies are lagged white noise."),
    "candidate_resolutions": [
        {"candidate": "HHG is exactly symmetric but implemented as Directed with a 'directed' label, contradicting config.yaml and the supplement ('undirected')",
         "outcome": "confirmed",
         "evidence": ("distance.hhg|{var2_bivariate,logistic_maps_chaotic,delayed_noise,gauss_ar1_pair}|256|pipeline|dir: ref_pyspi_asym 0.0 and"
                      " match to the from-scratch statistic for both orders; every other HHG run also reports max|A - A.T| = 0.0. Not in"
                      " KNOWN_ISSUES (REVIEW M9 is a general label-structure discussion that does not name hhg)")},
        {"candidate": "Documentation describes an RKHS/kernel statistic on ranks of the variables; the code computes chi-square statistics of rank-of-distance 2x2 tables",
         "outcome": "confirmed",
         "evidence": ("All 14 def runs equal the from-scratch Heller et al. 2013 statistic (refs/hhg_mgc.py:hhg_from_dist, no kernel) with"
                      " max_abs 0.0, e.g. distance.hhg|bivariate_gaussian|1024|kernel|def-p23; supplement.txt:272-278 and GitBook"
                      " distance-similarity.md:184-199 carry the RKHS wording")},
        {"candidate": "Ranks are taken over sklearn dot-product distances, so ties and near-ties are resolved by rounding (percent-level change on tied data)",
         "outcome": "confirmed",
         "evidence": ("distance.hhg|logistic_maps|256|kernel|exact max_rel 4.88e-2, |256|pipeline|exact 1.40e-2, |64|kernel|exact 9.9e-3;"
                      " distance.hhg|shared_envelope|256|kernel|exact 3.73e-3, |256|pipeline|exact 4.32e-3, |64|kernel|exact abs 62 = n-2 (all fail"
                      " against exact distances); the same pairs pass at max_abs 0.0 against sklearn-mirrored distances (|skdist) and hyppo"
                      " fed exact distances reproduces the exact-distance reference (|hyppo-exact, max_abs 0.0), so the distance arithmetic is the"
                      " whole cause. Root cause REVIEW M2 (dot-product distances); the consequence for a rank statistic is new")},
        {"candidate": "HYPOTHESIS: int64 overflow of the numerator in hyppo _pearson_stat for n >= 10812 (silent wrap on near-identical series)",
         "outcome": "inconclusive",
         "evidence": ("Not run: an end-to-end HHG at n >= 10812 is O(n^3) (about 1.3e12 table updates; pyspi took 14.4 s per call at n=1024)"
                      " and outside the audit's T <= 4096. The trace-stage numba replica of the numerator (p_hhg_int3.py) wraps, but the full"
                      " statistic was not computed. Settling it needs one hyppo HHG call on two identical series of length about 1.1e4")},
        {"candidate": "pyspi returns the raw permutation statistic T, whose null level grows like N(N-1), so values are not comparable across series lengths",
         "outcome": "confirmed",
         "evidence": ("distance.hhg|iid_gaussian|64|pipeline|null mean 3290.4 vs |256|pipeline|null mean 53204.2 (analytic E[T] 3842.0 and"
                      " 64514.0, both runs within the Monte Carlo band); identical-copy value 242048 at T=64 vs 16451072 at T=256"
                      " (distance.hhg|iid_gaussian|{64,256}|kernel|copies). An interpretation finding, not a computation error")},
    ],
    "checks_run": [
        {"run_ids": [rid(H, d, T, "kernel", "def") for T in (64, 256) for d in ("iid_gaussian", "bivariate_gaussian", "nonlinear_dependence", "anm", "contaminated", "var2_bivariate")]
                    + [rid(H, "bivariate_gaussian", 1024, "kernel", "def-p23"), rid(H, "bivariate_gaussian", 256, "pipeline", "def")],
         "reference": f"{REF}:ref_def -> hhg_from_dist on exact distances",
         "outcome": "pass 14/14; max_abs 0.0 (T64, T256, T1024 pair (2,3))"},
        {"run_ids": [rid(H, d, T, "kernel", t) for d in ("logistic_maps", "shared_envelope") for T in (64, 256) for t in ("exact", "skdist", "hyppo-exact")]
                    + [rid(H, d, 256, "pipeline", "exact") for d in ("logistic_maps", "shared_envelope")],
         "reference": f"{REF}:ref_def (exact and sklearn-mirrored distances), {REF}:ref_hyppo_exact with probe {PROBE}:hyppo_exact",
         "outcome": "exact: fail 6/6 as the rounding candidate predicts (max_rel 4.88e-2 logistic_maps T256 kernel, 4.32e-3 shared_envelope T256 pipeline); skdist pass 4/4 and hyppo-exact pass 4/4 at max_abs 0.0"},
        {"run_ids": [rid(H, "iid_gaussian", 64, "kernel", "copies"), rid(H, "iid_gaussian", 256, "kernel", "copies"), rid(H, "shared_envelope", 64, "pipeline", "dup")],
         "reference": f"{REF}:ref_copies, ref_dup (analytic N(N-2)(N-3)) with probe {PROBE}:copies",
         "outcome": "pass 3/3; 242048 and 16451072 exactly"},
        {"run_ids": [rid(H, d, 256, "pipeline", "dir") for d in ("var2_bivariate", "logistic_maps_chaotic", "delayed_noise", "gauss_ar1_pair")],
         "reference": f"{REF}:ref_dir (from-scratch, both argument orders)",
         "outcome": "pass 4/4; max_abs 0.0, max|A - A.T| = 0.0"},
        {"run_ids": [rid(H, "iid_gaussian", 64, "pipeline", "null"), rid(H, "iid_gaussian", 256, "pipeline", "null")],
         "reference": f"{REF}:ref_null (analytic E[T] = n(n-2)(n-3)/(n-1), Monte Carlo SD)",
         "outcome": "pass 2/2; max_z 0.96 (T64), 1.44 (T256)"},
        {"run_ids": [rid(H, d, 256, "pipeline", "order") for d in ("nonlinear_dependence", "bivariate_gaussian", "anm")],
         "reference": f"{REF}:ref_order with {REF}:mc_quantile_band (2000 draws)",
         "outcome": "pass 3/3; dependent pairs 150648 to 5409301 above the band [38512, 118786], independent pairs inside, rho=0.8 > rho=0.3"},
        {"run_ids": [rid(H, "scaled_offset", 256, "pipeline", "scaleinv"), rid(H, "trending", 256, "pipeline", "trend"), rid(H, "trending", 256, "pipeline-detrend", "detrend"), rid(H, "trending", 256, "pipeline-detrend", "trendqual")],
         "reference": f"{REF}:ref_scaleinv, ref_def (own z-score / detrend), ref_trendqual",
         "outcome": "pass 4/4; scaleinv and trend/detrend max_abs 0.0; trending independent pairs 2.09e6 and 5.53e6 without detrend, 61082 and 49759 after"},
    ],
})
doc["status"] = "checked"
yaml.safe_dump(doc, open(R + H + ".yaml", "w"), sort_keys=False, allow_unicode=True, width=200, default_flow_style=False)

# ------------------------------------------------------------------ MGC
M = "distance.mgc"
doc = yaml.safe_load(open(R + M + ".yaml"))
c = doc["correctness"]
c["deviation_from_canonical"] += (
    " Check-stage correction to (c): the SciPy region rule DOES change values on continuous data. At T=256 (required region 6n) the r-mgc rule"
    " 2*min(m,n) and the paper rule 2n accept local regions that SciPy rejects: anm pair (1,3), independent by construction, gives 0.0319 under"
    " the r-mgc rule vs pyspi 0.0051 (global fallback), and narrowband_f0-0.1 pair (1,2) gives 0.5364 vs pyspi 0.4751"
    " (distance.mgc|anm|256|kernel|rmgc, distance.mgc|narrowband_f0-0.1|256|kernel|rmgc). On logistic_maps the r-mgc rule coincides with"
    " SciPy's (map 64 x 8: ceil(0.02*64)*8 = 16 = 2*min(m,n); identical values at T=64 and T=256), so the 0.3157 value is the paper's 2n rule"
    " only, not r-mgc's.")
c.update({
    "check_method": "independent-impl",
    "check_reference": (f"{REF}:mgc_from_dist (from scratch in numpy: Shen, Priebe & Vogelstein 2020 eq. 6 column centring, dense column ranks,"
        f" rank-binned 2-D cumulative local covariances, Corollary 3 Beta threshold via scipy.stats.beta.ppf, largest 4-connected component via"
        f" scipy.ndimage.label; does not import hyppo or scipy.stats.multiscale_graphcorr; constants selectable: SciPy (n^2, n-1,"
        f" ceil(0.02 max)min), paper (n(n-1), n, 2n), r-mgc (n^2, n-1, 2 min)); {REF}:mgc_global (analytic global-scale identity);"
        f" audit/checks/refs/_kernels_distance.py:dcorr_from_dist (U-centred dCor^2, related quantity); {REF}:dcor2_gauss (population dCor^2,"
        f" Szekely, Rizzo & Bakirov 2007 Thm 7); {REF}:mc_quantile_band; probes {PROBE}:optscale (hyppo's compute_dist + multiscale_graphcorr"
        f" with mgc_dict exported), ordered, copies, small_n, hyppo_exact (same-lineage attribution aid). The definition itself is"
        f" literature-only (Shen et al. 2020; Vogelstein et al. 2019 eLife 8:e41690); no implementation outside the hyppo/SciPy/r-mgc lineage exists"
        f" in the environment, so the SciPy constants were mirrored from the SciPy code"),
    "check_data": ("iid_gaussian, bivariate_gaussian, nonlinear_dependence, anm, narrowband_f0-0.1, contaminated T64/T256/T1024 kernel; bivariate_gaussian"
        " T256 pipeline; nonlinear_dependence, logistic_maps, narrowband_f0-0.1, anm T64/T256 (paper and r-mgc constants); logistic_maps and"
        " shared_envelope T64/T256 kernel and T256 pipeline (tied-data attribution); iid_gaussian and bivariate_gaussian T64/T256/T1024 (global"
        " identity, U-centred dCor); optimal-scale probe on bivariate_gaussian T64/T256/T1024 and iid_gaussian, nonlinear_dependence,"
        " narrowband_f0-0.1, logistic_maps T256; iid_gaussian, var2_bivariate, logistic_maps_chaotic, delayed_noise T256 pipeline (symmetry);"
        " iid_gaussian T64/T256/T1024 (null); shared_envelope (0,2) T64/T256; iid_gaussian copies T64/T256; ordering T256; scaled_offset"
        " T256/T1024; trending T256; bivariate_gaussian T64/T256/T1024 (population dCor^2); n = 4/5 edge"),
    "agreement_criterion": ("tolerance atol 1e-10 against the from-scratch statistic with SciPy's constants on exact distances (continuous data) or"
        " sklearn-mirrored distances (tied data); exact rtol 1e-10/atol 1e-12 for the global-scale identity, the optimal scale and the copy value 1;"
        " related quantity: atol 1/n against the U-centred bias-corrected dCor^2; statistical |pyspi - target| <= z_(1-0.025/m) Monte Carlo SD;"
        " qualitative ordering inside/above the empirical family-wise null band (2000 draws); paper constants atol 2e-3 and r-mgc constants atol"
        " 1e-10 as deviation measurements"),
    "closeness": ("SciPy-constant reference: all 19 def runs pass (6 datasets x T64/T256/T1024 kernel plus bivariate_gaussian T256 pipeline), max_abs"
        " <= 5.8e-14 (distance.mgc|anm|1024|kernel|def); dir/ordered/trend/detrend/scaleinv max_abs <= 8.6e-14. Global-scale identity: every"
        " bivariate_gaussian and iid_gaussian pair falls back to the global scale at T64/T256/T1024 (optscale probe: 12/12 and 20/20 pairs at"
        " opt_scale (n,n); scale and global map value match the reference, max_abs <= 2.9e-14), and pyspi equals the column-centred dCorr^{n,n}"
        " sum A_ab B_ba / sqrt(sum A_ab A_ba sum B_ab B_ba) to max_abs 1.3e-15 / 1.0e-14 / 3.8e-14 (|global runs). It is NOT equal to the U-centred"
        " unbiased dCor^2 that hyppo's Dcorr returns: max |global - udcorr| 1.79e-3 / 1.64e-4 / 1.23e-5 on bivariate_gaussian and 1.39e-3 /"
        " 1.55e-4 / 3.24e-5 on iid_gaussian at T64/T256/T1024 (within the O(1/n) tolerance). Local scales chosen: nonlinear_dependence T256"
        " (42,89) and (5,5), narrowband_f0-0.1 (65,26) and (50,48), logistic_maps (249,6). Population: |pop runs max_z 0.86 / 0.64 / 0.72; Monte"
        " Carlo means 0.0723 (rho=0.3) and 0.5674 (rho=0.8) at T1024 against dCor^2 0.0724 and 0.5699. Anchors: shared_envelope (0,2) = 1.0"
        " exactly at T64/T256; copies = 1 within 2.2e-15; nonlinear_dependence (0,1) 0.524 and (2,3) 0.477 at T256 against the null band"
        " [-0.0072, 0.0373]. Null: |null max_z 0.67 / 0.75 / 1.98; 90% / 90% / 80% of pyspi iid values negative, minimum -0.0264 (T64). Paper"
        " constants: max_abs 1.5e-3 (nonlinear_dependence T64), 5.2e-4 (T256), 2.4e-3 (narrowband T64), 0.0564 (logistic_maps T64), 0.0464"
        " (T256), 0.0610 (narrowband T256), 0.0269 (anm T256); r-mgc constants: 0.0 where the region rule does not bind, 0.0613 (narrowband"
        " T256) and 0.0269 (anm T256) where it does. Tied data against EXACT distances: shared_envelope|256|pipeline|exact max_abs 6.14e-2"
        " (0.708 vs 0.769), |256|kernel|exact 4.99e-2, logistic_maps|256|pipeline|exact 4.47e-3; skdist and hyppo-exact runs pass at <= 1.2e-14."),
    "verdict": "variant",
    "score_0_10": 6,
    "what_changed": ("pyspi computes SciPy's multiscale_graphcorr statistic exactly as SciPy's code states. That statistic deviates from the"
        " Shen et al. 2020 text in an interpretable way: the minimum region size ceil(0.02*max(m,n))*min(m,n) is SciPy's own rule, matching"
        " neither the paper (2n) nor the authors' r-mgc code (2*min(m,n)), and it changes values by up to 0.061 at T=256 on continuous data;"
        " the centring term n^2 and threshold size n-1 follow r-mgc, not the paper (<= 2.4e-3). It also deviates from the supplement:"
        " the label 'unsigned' (and the glossary's 'distance correlation (defined in the range [0,1])') is contradicted by negative values"
        " on 80-90% of independent pairs, and 'unbiased estimator (as in hyppo)' is inaccurate because the global fallback is the"
        " column-centred dCorr^{n,n}, not hyppo's U-centred dCor^2. Rubric 6: deviates from both the supplement and the canonical text in"
        " an interpretable way. This also equals the same-lineage cap, since the full-statistic constants could only be taken from the"
        " SciPy/r-mgc lineage. Separately, sklearn dot-product distances move values by up to 0.061 on tied data (root cause REVIEW M2)."),
    "new_finding": True,
    "definition_under_review": True,
    "check_cost": ("moderate: 0.28 s per pyspi call at T=1024 and 16.6 s at T=4096 (timed probe, T=4096 not in the manifest); the 95 MGC runs"
        " took 123 s of pyspi time in total"),
    "symmetry_observed": ("sym: the published matrix has max|A - A.T| = 0.0 on every run (Undirected mirror). Unmirrored"
        " Directed.multivariate (probe 'ordered') gives max|MGC(i,j) - MGC(j,i)| = 1.07e-14 (iid_gaussian), 5.8e-15 (delayed_noise), 5.4e-15"
        " (var2_bivariate), 5.6e-17 (logistic_maps_chaotic) at T=256"),
    "direction_observed": ("No direction information. A[i,j] = A[j,i] = MGC(process min(i,j), process max(i,j)): var2_bivariate (x0 -> x1) 0.0476 and"
        " logistic_maps_chaotic (x -> y) 0.0670 in both orders; delayed_noise pairs are at null level (|values| <= 0.0037), as expected for a"
        " contemporaneous measure on lagged white noise (distance.mgc|*|256|pipeline|dir and |ordered)."),
    "candidate_resolutions": [
        {"candidate": "'unsigned' label (supplement, config.yaml, GitBook glossary-of-terms.md:21) but negative outputs when the statistic falls back to the global scale",
         "outcome": "confirmed",
         "evidence": ("distance.mgc|iid_gaussian|{64,256,1024}|pipeline|null: pyspi_frac_neg 0.9 / 0.9 / 0.8, minimum -0.0264 (T64); the"
                      " from-scratch null is negative in 61-68% of draws (mc_frac_neg 0.675 / 0.617 / 0.667; 61% of the 2000 draws at T=256);"
                      " independent pairs negative in the order runs (e.g. bivariate_gaussian (1,2) -0.0057). Not in KNOWN_ISSUES (M7/M8 do not"
                      " list mgc)")},
        {"candidate": "SciPy's minimum-region rule differs from the paper (2n) and from r-mgc (2*min(m,n))",
         "outcome": "confirmed",
         "evidence": ("distance.mgc|anm|256|kernel|rmgc max_abs 0.0269 (independent pair (1,3): 0.0319 under r-mgc vs pyspi 0.0051),"
                      " distance.mgc|narrowband_f0-0.1|256|kernel|rmgc 0.0613 (0.5364 vs 0.4751); paper rule on logistic_maps|64|kernel|paper"
                      " 0.0564. Scope correction to the trace: the rule also changes continuous-data values at T=256, and on logistic_maps"
                      " the r-mgc rule equals SciPy's (logistic_maps|{64,256}|kernel|rmgc max_abs <= 6.3e-15), so only the paper rule"
                      " gives about 0.316 there")},
        {"candidate": "Subtractive centring term divides by n^2 (r-mgc convention) rather than the paper's n(n-1)",
         "outcome": "confirmed",
         "evidence": ("The paper-constant variant (n(n-1), threshold with n, region 2n) differs from pyspi by 1.5e-3"
                      " (nonlinear_dependence|64|kernel|paper), 5.2e-4 (|256|kernel|paper) and 2.4e-3 (narrowband_f0-0.1|64|kernel|paper) where"
                      " the region rule does not bind, while the r-mgc constants (n^2, n-1) reproduce pyspi to <= 3e-15 there"
                      " (|rmgc runs). A paper-vs-author-code discrepancy, not a pyspi defect")},
        {"candidate": "sklearn dot-product distance rounding changes nearest-neighbour ranks and hence the local correlation map",
         "outcome": "confirmed",
         "evidence": ("distance.mgc|shared_envelope|256|pipeline|exact max_abs 6.14e-2 (0.708 vs 0.769), |256|kernel|exact 4.99e-2,"
                      " |64|kernel|exact 5.9e-3; distance.mgc|logistic_maps|256|pipeline|exact 4.47e-3, |256|kernel|exact 1.44e-3; the"
                      " skdist runs (sklearn-mirrored distances) and the hyppo-exact runs (SciPy fed exact distances) all pass at <= 1.2e-14."
                      " Root cause REVIEW M2; the consequence is new")},
        {"candidate": "Supplement 'unbiased estimator (as in hyppo)' does not match the column-centred global-scale estimator; GitBook key-reference link points to an LCSS paper",
         "outcome": "confirmed",
         "evidence": ("distance.mgc|{iid_gaussian,bivariate_gaussian}|{64,256,1024}|kernel|global pass at <= 3.8e-14 (column-centred"
                      " dCorr^{n,n}) while |udcorr shows the U-centred dCor^2 differs by up to 1.79e-3 (T64), 1.64e-4 (T256), 3.24e-5 (T1024):"
                      " near-equal at O(1/n), not equal. GitBook distance-similarity.md:257 links"
                      " researchgate 3943235_Discovering_similar_multidimensional_trajectories (re-read at check stage)")},
    ],
    "checks_run": [
        {"run_ids": [rid(M, d, T, "kernel", "def") for T in (64, 256, 1024) for d in ("iid_gaussian", "bivariate_gaussian", "nonlinear_dependence", "anm", "narrowband_f0-0.1", "contaminated")]
                    + [rid(M, "bivariate_gaussian", 256, "pipeline", "def")],
         "reference": f"{REF}:ref_def -> mgc_from_dist (SciPy constants, exact distances)",
         "outcome": "pass 19/19; max_abs <= 5.8e-14"},
        {"run_ids": [rid(M, d, T, "kernel", t) for T in (64, 256) for d in ("nonlinear_dependence", "logistic_maps", "narrowband_f0-0.1", "anm") for t in ("paper", "rmgc")],
         "reference": f"{REF}:ref_variant (mgc_from_dist with paper / r-mgc constants, sklearn-mirrored distances)",
         "outcome": "deviation measurement: paper pass 3/8 (<= 1.5e-3), fail 5/8 (up to 0.061); r-mgc pass 6/8 (<= 6.3e-15), fail 2/8 (anm T256 0.027, narrowband T256 0.061)"},
        {"run_ids": [rid(M, d, T, "kernel", t) for d in ("logistic_maps", "shared_envelope") for T in (64, 256) for t in ("exact", "skdist", "hyppo-exact")]
                    + [rid(M, d, 256, "pipeline", "exact") for d in ("logistic_maps", "shared_envelope")],
         "reference": f"{REF}:ref_def (exact and sklearn-mirrored distances), {REF}:ref_hyppo_exact with probe {PROBE}:hyppo_exact",
         "outcome": "exact: fail 6/6 as the rounding candidate predicts (up to 6.14e-2); skdist pass 4/4, hyppo-exact pass 4/4 (<= 1.2e-14)"},
        {"run_ids": [rid(M, d, T, "kernel", t) for T in (64, 256, 1024) for d in ("iid_gaussian", "bivariate_gaussian") for t in ("global", "udcorr")],
         "reference": f"{REF}:ref_global (analytic column-centred dCorr^(n,n)), ref_udcorr (_kernels_distance.dcorr_from_dist U-centred)",
         "outcome": "pass 12/12; global identity <= 3.8e-14; U-centred dCor^2 differs by 1.2e-5 to 1.8e-3 (related quantity, within 1/n)"},
        {"run_ids": [rid(M, "bivariate_gaussian", T, "kernel", "optscale") for T in (64, 256, 1024)] + [rid(M, d, 256, "kernel", "optscale") for d in ("iid_gaussian", "nonlinear_dependence", "narrowband_f0-0.1", "logistic_maps")],
         "reference": f"{REF}:ref_optscale with probe {PROBE}:optscale",
         "outcome": "pass 7/7; optimal scale and global map value match; bivariate_gaussian and iid_gaussian all pairs at the global scale"},
        {"run_ids": [rid(M, d, 256, "pipeline", t) for d in ("iid_gaussian", "var2_bivariate", "logistic_maps_chaotic", "delayed_noise") for t in ("dir", "ordered")],
         "reference": f"{REF}:ref_dir (both argument orders) with probe {PROBE}:ordered",
         "outcome": "pass 8/8; published max|A - A.T| 0.0, unmirrored <= 1.07e-14"},
        {"run_ids": [rid(M, "iid_gaussian", T, "pipeline", "null") for T in (64, 256, 1024)] + [rid(M, "bivariate_gaussian", T, "pipeline", "pop") for T in (64, 256, 1024)],
         "reference": f"{REF}:ref_null (Monte Carlo null), ref_pop (dcor2_gauss + Monte Carlo SD)",
         "outcome": "pass 6/6; null max_z 0.67 / 0.75 / 1.98; population max_z 0.86 / 0.64 / 0.72"},
        {"run_ids": [rid(M, "shared_envelope", T, "pipeline", "dup") for T in (64, 256)] + [rid(M, "iid_gaussian", T, "kernel", "copies") for T in (64, 256)]
                    + [rid(M, d, 256, "pipeline", "order") for d in ("nonlinear_dependence", "bivariate_gaussian", "anm")] + [rid(M, "iid_gaussian", 64, "kernel", "smalln")],
         "reference": f"{REF}:ref_dup, ref_copies (analytic 1), ref_order with mc_quantile_band, ref_smalln with probe {PROBE}:small_n",
         "outcome": "pass 8/8; copies exactly 1 (<= 2.2e-15); dependent pairs 0.075 to 0.913 above the band [-0.0072, 0.0373]; ValueError at n=4, n=5 value -0.34544 matches"},
        {"run_ids": [rid(M, "scaled_offset", T, "pipeline", "scaleinv") for T in (256, 1024)] + [rid(M, "trending", 256, "pipeline", "trend"), rid(M, "trending", 256, "pipeline-detrend", "detrend"), rid(M, "trending", 256, "pipeline-detrend", "trendqual")],
         "reference": f"{REF}:ref_scaleinv, ref_def (own preprocessing), ref_trendqual",
         "outcome": "pass 5/5; scaleinv <= 8.6e-14; trending independent pairs 0.634 and 0.908 without detrend, -0.0054 and -0.0042 after"},
    ],
})
doc["status"] = "checked"
yaml.safe_dump(doc, open(R + M + ".yaml", "w"), sort_keys=False, allow_unicode=True, width=200, default_flow_style=False)
print("ok")
