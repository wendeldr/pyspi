"""Does the HHG null distribution (iid independent pairs) depend on the marginal law, or on n alone?"""
import sys, time
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks"); sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs")
import numpy as np
from scipy import stats
import hhg_mgc as H
n, reps = 64, 3000
rng = np.random.default_rng(99)
gens = {"gauss": lambda: rng.standard_normal(n), "expo": lambda: rng.exponential(size=n),
        "unif": lambda: rng.uniform(size=n), "cauchy": lambda: rng.standard_cauchy(n)}
out = {}
for k, g in gens.items():
    v = np.array([H.hhg_from_dist(H.dist(g(), "exact"), H.dist(g(), "exact")) for _ in range(reps)])
    out[k] = v
    print(k, "mean %.1f sd %.1f q95 %.1f q99 %.1f" % (v.mean(), v.std(ddof=1), *np.quantile(v, [0.95, 0.99])), "E[T]", H.hhg_null_mean(n))
for k in ("expo", "unif", "cauchy"):
    print("KS gauss vs", k, stats.ks_2samp(out["gauss"], out[k]))
    print("  sd ratio", out[k].std() / out["gauss"].std())
