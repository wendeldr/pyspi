"""Permutation percentiles (200 perms, from-scratch statistic, exact distances, raw rows) of independent pairs in
other draws: iid_gaussian T1024 (MGC only; HHG too slow) and bivariate_gaussian cross pairs (0,2),(0,3),(1,2),(1,3)
at T64/T256 (both units). The from-scratch statistic equals pyspi bit for bit / to 1e-13 on these rows (def runs)."""
import sys, json
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks"); sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs")
import numpy as np
from multiprocessing import Pool
from scipy import stats
import make_data
import hhg_mgc as H

def job(a):
    unit, ds, T, i, j = a
    x = np.asarray(make_data.load(ds, T)["x"], float)
    fn = H.stat_fn(unit)
    dx, dy = H.dist(x[i], "exact"), H.dist(x[j], "exact")
    obs = fn(dx, dy)
    rng = np.random.default_rng([4242, T, i, j])
    v = np.array([fn(dx, dy[np.ix_(p, p)]) for p in (rng.permutation(T) for _ in range(200))])
    return a, float(((v < obs).sum() + 0.5 * (v == obs).sum()) / 200)

if __name__ == "__main__":
    jobs = [("distance.mgc", "iid_gaussian", 1024, i, j) for (i, j) in H.pair_list(5)]
    for u in ("distance.hhg", "distance.mgc"):
        for T in (64, 256):
            jobs += [(u, "bivariate_gaussian", T, i, j) for (i, j) in ((0, 2), (0, 3), (1, 2), (1, 3))]
    with Pool(30) as pool:
        res = pool.map(job, jobs)
    groups = {}
    for (u, ds, T, i, j), pct in res:
        groups.setdefault(f"{u}|{ds}|{T}", []).append(pct)
    for k, us in groups.items():
        print(k, "percentiles", [round(u, 3) for u in us], "mean %.3f" % np.mean(us), "KS p %.3f" % stats.kstest(us, "uniform").pvalue)
    allb = [p for k, us in groups.items() if "bivariate" in k for p in us]
    print("all bivariate cross pairs (16, dependent: same draws reused across units):", "mean %.3f" % np.mean(allb))
