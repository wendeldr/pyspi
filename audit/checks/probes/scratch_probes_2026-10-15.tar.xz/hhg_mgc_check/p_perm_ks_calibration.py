"""Calibration of the ref_perm iid criterion: on fresh 5 x T iid N(0,1) draws (same structure as iid_gaussian: 10 pairs
from 5 processes, so the pair percentiles are dependent), how often is the KS p of the 10 permutation percentiles < 0.05
and < 0.012? Usage: python p_perm_ks_calibration.py <unit> <T> <draws> <perms>"""
import sys, json
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks"); sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs")
import numpy as np
from multiprocessing import Pool
from scipy import stats
import hhg_mgc as H

unit, T, D, R = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])

def one(d):
    rng = np.random.default_rng([777, T, d, 1 if unit == "distance.hhg" else 2])
    x = rng.standard_normal((5, T))
    fn = H.stat_fn(unit)
    Dm = [H.dist(r, "exact") for r in x]
    us = []
    for (i, j) in H.pair_list(5):
        obs = fn(Dm[i], Dm[j])
        v = np.empty(R)
        for r in range(R):
            p = rng.permutation(T)
            v[r] = fn(Dm[i], Dm[j][np.ix_(p, p)])
        us.append(((v < obs).sum() + 0.5 * (v == obs).sum()) / R)
    return float(stats.kstest(us, "uniform").pvalue), float(np.mean(us))

if __name__ == "__main__":
    with Pool(12) as pool:
        res = pool.map(one, range(D))
    ks = np.array([r[0] for r in res]); mu = np.array([r[1] for r in res])
    out = dict(unit=unit, T=T, draws=D, perms=R, frac_ks_lt_0p05=float((ks < 0.05).mean()),
               frac_ks_le_0p012=float((ks <= 0.012).mean()), mean_pct_mean=float(mu.mean()), mean_pct_sd=float(mu.std(ddof=1)),
               frac_mean_pct_le_0p31=float((mu <= 0.31).mean()), frac_mean_pct_le_0p29=float((mu <= 0.2915).mean()))
    print(json.dumps(out))
