import json
runs = []
PR = "probes/hhg_mgc_probes.py"
def add(unit, ident, ds, T, path, tag, processes=None, probe=None):
    rid = f"{unit}|{ds}|{T}|{path}|{tag}"
    runs.append(dict(run_id=rid, unit_id=unit, identifier=(None if probe else ident), dataset=ds, T=T, path=path,
                     processes=processes, seed=42, probe=(dict(module=PR, function=probe) if probe else None)))

# ---------------- HHG
U, I = "distance.hhg", "hhg"
for T in (64, 256):
    for ds in ("iid_gaussian", "bivariate_gaussian", "nonlinear_dependence", "anm", "contaminated", "var2_bivariate"):
        add(U, I, ds, T, "kernel", "def")
add(U, I, "bivariate_gaussian", 1024, "kernel", "def-p23", processes=[2, 3])
add(U, I, "bivariate_gaussian", 256, "pipeline", "def")
for ds in ("logistic_maps", "shared_envelope"):
    for T in (64, 256):
        add(U, I, ds, T, "kernel", "exact")
        add(U, I, ds, T, "kernel", "skdist")
        add(U, I, ds, T, "kernel", "hyppo-exact", probe="hyppo_exact")
    add(U, I, ds, 256, "pipeline", "exact")
for T in (64, 256):
    add(U, I, "iid_gaussian", T, "kernel", "copies", probe="copies")
add(U, I, "shared_envelope", 64, "pipeline", "dup", processes=[0, 2])
for ds in ("var2_bivariate", "logistic_maps_chaotic", "delayed_noise", "gauss_ar1_pair"):
    add(U, I, ds, 256, "pipeline", "dir")
for T in (64, 256):
    add(U, I, "iid_gaussian", T, "pipeline", "null")
for ds in ("nonlinear_dependence", "bivariate_gaussian", "anm"):
    add(U, I, ds, 256, "pipeline", "order")
add(U, I, "scaled_offset", 256, "pipeline", "scaleinv")
add(U, I, "trending", 256, "pipeline", "trend")
add(U, I, "trending", 256, "pipeline-detrend", "detrend")
add(U, I, "trending", 256, "pipeline-detrend", "trendqual")

# ---------------- MGC
U, I = "distance.mgc", "mgc"
for T in (64, 256, 1024):
    for ds in ("iid_gaussian", "bivariate_gaussian", "nonlinear_dependence", "anm", "narrowband_f0-0.1", "contaminated"):
        add(U, I, ds, T, "kernel", "def")
add(U, I, "bivariate_gaussian", 256, "pipeline", "def")
for T in (64, 256):
    for ds in ("nonlinear_dependence", "logistic_maps", "narrowband_f0-0.1", "anm"):
        add(U, I, ds, T, "kernel", "paper")
        add(U, I, ds, T, "kernel", "rmgc")
for ds in ("logistic_maps", "shared_envelope"):
    for T in (64, 256):
        add(U, I, ds, T, "kernel", "exact")
        add(U, I, ds, T, "kernel", "skdist")
        add(U, I, ds, T, "kernel", "hyppo-exact", probe="hyppo_exact")
    add(U, I, ds, 256, "pipeline", "exact")
for T in (64, 256, 1024):
    for ds in ("iid_gaussian", "bivariate_gaussian"):
        add(U, I, ds, T, "kernel", "global")
        add(U, I, ds, T, "kernel", "udcorr")
for T in (64, 256, 1024):
    add(U, I, "bivariate_gaussian", T, "kernel", "optscale", probe="optscale")
for ds in ("iid_gaussian", "nonlinear_dependence", "narrowband_f0-0.1", "logistic_maps"):
    add(U, I, ds, 256, "kernel", "optscale", probe="optscale")
for ds in ("iid_gaussian", "var2_bivariate", "logistic_maps_chaotic", "delayed_noise"):
    add(U, I, ds, 256, "pipeline", "dir")
    add(U, I, ds, 256, "pipeline", "ordered", probe="ordered")
for T in (64, 256, 1024):
    add(U, I, "iid_gaussian", T, "pipeline", "null")
for T in (64, 256):
    add(U, I, "shared_envelope", T, "pipeline", "dup", processes=[0, 2])
    add(U, I, "iid_gaussian", T, "kernel", "copies", probe="copies")
for ds in ("nonlinear_dependence", "bivariate_gaussian", "anm"):
    add(U, I, ds, 256, "pipeline", "order")
for T in (256, 1024):
    add(U, I, "scaled_offset", T, "pipeline", "scaleinv")
add(U, I, "trending", 256, "pipeline", "trend")
add(U, I, "trending", 256, "pipeline-detrend", "detrend")
add(U, I, "trending", 256, "pipeline-detrend", "trendqual")
for T in (64, 256, 1024):
    add(U, I, "bivariate_gaussian", T, "pipeline", "pop")
add(U, I, "iid_gaussian", 64, "kernel", "smalln", probe="small_n")

ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids))
json.dump({"family": "hhg_mgc", "runs": runs}, open("/media/dan/Data/git/pyspi/audit/checks/manifest/hhg_mgc.json", "w"), indent=1)
print(len(runs), sum(r["unit_id"] == "distance.hhg" for r in runs))
