import sys, numpy as np, warnings
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import make_data
from hyppo.tools import compute_dist
from hyppo.independence import Dcorr
from scipy.stats import multiscale_graphcorr
from scipy.stats import zscore
for name in ['bivariate_gaussian','iid_gaussian','nonlinear_dependence','anm','narrowband_f0-0.1','contaminated','delayed_noise','var2_bivariate','logistic_maps_chaotic','trending']:
  for T in [64,256,1024]:
    x = zscore(make_data.load(name, T)['x'],axis=1,ddof=1); P=x.shape[0]
    out=[]
    for i in range(P):
      for j in range(i+1,P):
        dx,dy=compute_dist(x[i][:,None],x[j][:,None])
        with warnings.catch_warnings():
            warnings.simplefilter('ignore'); r=multiscale_graphcorr(dx,dy,compute_distance=None,reps=0)
        mp=r.mgc_dict['mgc_map']; os_=r.mgc_dict['opt_scale']
        g=mp[-1,-1]; u=Dcorr().statistic(x[i][:,None],x[j][:,None])
        out.append(f"({i},{j}) s={r.stat:.5f} opt={list(os_)} glob={'Y' if r.stat==g else 'n'} g-u={g-u:.2e}")
    print(name,T,'; '.join(out))
