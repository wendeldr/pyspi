import yaml
f='/media/dan/Data/git/pyspi/audit/records/distance.hhg.yaml'
d=yaml.safe_load(open(f)); c=d['correctness']
old='|256|kernel|perm passes (KS p 0.124, percentiles 0.0 to 0.74, smallest upper-tail p 0.264).'
assert old in c['closeness']
c['closeness']=c['closeness'].replace(old,'|256|kernel|perm passes (KS p 0.124, percentiles 0.0 to 0.74, mean 0.2805, smallest upper-tail p 0.264).')
open(f,'w').write(yaml.safe_dump(d,sort_keys=False,width=200,allow_unicode=True,default_flow_style=False))

f='/media/dan/Data/git/pyspi/audit/records/distance.mgc.yaml'
d=yaml.safe_load(open(f)); c=d['correctness']
c['check_reference'] += ('; audit/checks/refs/hhg_mgc.py:ref_perm (per-pair conditional permutation null, 200 permutations of y on exact distances; trace proposed check [5]); '
  'calibration probes scratchpad hhg_mgc_check/p_perm_ks_calibration.py and p_perm_other_draws.py')
c['check_data'] += '; iid_gaussian T64/T256 kernel (per-pair permutation null)'
c['agreement_criterion'] += ('; qualitative per-pair permutation null (200 permutations of y): pass = KS of the 10 pair percentiles vs U(0,1) p >= 0.05 '
  'and no upper-tail permutation p < 0.05/10')
c['closeness'] += (' Permutation null (|perm, 200 permutations per pair, iid_gaussian kernel): T64 passes (KS p 0.288, mean percentile 0.411, smallest '
  'upper-tail p 0.114); T256 FAILS the uniformity criterion (KS p 0.0122, mean percentile 0.2475, lower tail; smallest upper-tail p 0.134, so no pair is '
  'flagged as dependent). Sign: 63.3% (T64) and 62.6% (T256) of the 2000 permutation-null values are negative and 90% of the pyspi values are negative '
  'in both runs. Calibration probe (400 fresh 5 x 64 iid draws): the KS criterion fails on 4.25% of null draws and reaches KS p <= 0.012 on 1.0%; a fresh '
  'MGC iid_gaussian T1024 draw gives KS p 0.180 (probe p_perm_other_draws.py).')
c['check_cost'] = ('moderate: 0.28 s per pyspi call at T=1024 and 16.6 s at T=4096 (timed probe, T=4096 not in the manifest); the 97 MGC runs took '
  '109.2 s of pyspi time in the forced re-run (123 s for 95 runs in the first run). Reference side: the per-pair permutation null took 24.9 s at T=256 '
  '(10 pairs x 200). The trace proposed check [5] (200-permutation null per pair, iid_gaussian kernel, percentiles and sign) was run as proposed at '
  'T64/T256 (|perm runs); the Monte Carlo null (|null runs) is additional, not a replacement. Not run: the permutation null at T=1024 in the manifest '
  '(about 40 min serial; one parallel probe draw only)')
c['checks_run'].append(dict(
  run_ids=['distance.mgc|iid_gaussian|64|kernel|perm','distance.mgc|iid_gaussian|256|kernel|perm'],
  reference='audit/checks/refs/hhg_mgc.py:ref_perm (200 permutations per pair of mgc_from_dist on exact distances; KS vs U(0,1))',
  outcome=('pass 1/2, fail 1/2: T64 passes (KS p 0.288); T256 fails the KS uniformity criterion (p 0.0122, lower tail; no upper-tail rejection). '
           '62.6-63.3% of permutation-null values negative, 90% of pyspi values negative')))
for cr in c['candidate_resolutions']:
    if 'nsigned' in cr['candidate'] or 'negative' in cr['candidate']:
        cr['evidence'] += ('; per-pair permutation nulls: 63.3% (T64) and 62.6% (T256) of null values negative, 90% of pyspi values negative '
                           '(distance.mgc|iid_gaussian|{64,256}|kernel|perm)')
        print('updated', cr['candidate'][:80])
open(f,'w').write(yaml.safe_dump(d,sort_keys=False,width=200,allow_unicode=True,default_flow_style=False))
