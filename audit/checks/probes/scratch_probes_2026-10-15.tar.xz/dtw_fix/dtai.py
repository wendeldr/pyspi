import numpy as np, dtaidistance.dtw as ddtw
for T,s in [(50,0),(80,5)]:
    r=np.random.default_rng(s); x=r.standard_normal(T); y=r.standard_normal(T)
    print(T,s,'dtai',repr(ddtw.distance(x,y,use_c=False)))
for T,s in [(50,0),(80,5)]:
    r=np.random.default_rng(s); x=r.standard_normal(T); y=r.standard_normal(T)
    print(T,s,'dtai window=2',repr(ddtw.distance(x,y,use_c=False,window=2)),'window=1',repr(ddtw.distance(x,y,use_c=False,window=1)))
