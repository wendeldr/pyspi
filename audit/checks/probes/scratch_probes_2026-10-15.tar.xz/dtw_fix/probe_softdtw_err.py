import numpy as np
from sklearn.metrics.pairwise import euclidean_distances
mx=[]; ab=[]
for s in range(20):
    r=np.random.default_rng(s); x=r.standard_normal(256); y=x+1e-3*r.standard_normal(256)
    D=euclidean_distances(x[:,None],y[:,None])**2; E=(x[:,None]-y[None,:])**2
    rel=np.abs(np.diag(D)-np.diag(E))/np.diag(E); mx.append(rel.max()); ab.append(np.abs(D-E).max())
print('diag rel max over 20 seeds: min %.2e median %.2e max %.2e; abs max %.2e'%(min(mx),np.median(mx),max(mx),max(ab)))
