import numpy as np
from tslearn.metrics import dtw
for T,s in [(50,0),(80,5)]:
    r=np.random.default_rng(s); x=r.standard_normal(T); y=r.standard_normal(T)
    print(T,s,'tslearn',repr(dtw(x,y)))
for T,s in [(50,0),(80,5)]:
    r=np.random.default_rng(s); x=r.standard_normal(T); y=r.standard_normal(T)
    print(T,s,'tslearn sc r1',repr(dtw(x,y,global_constraint='sakoe_chiba')))
