import pathlib
p = pathlib.Path('/media/dan/Data/git/pyspi/audit/notes/dtw_family.md'); t = p.read_text()
def sub(old, new):
    global t
    assert t.count(old) == 1, old[:70]
    t = t.replace(old, new)

sub("""  normalisation. The probe agrees with a from-scratch DP exactly (6.566820109835115). dtaidistance 2.5.1 (audit venv,
  no tslearn import) gives the same value (5.972081410007747), and `window=2` reproduces the radius-1 band.""",
"""  normalisation. On a T=50 seed-0 iid pair, tslearn equals a from-scratch DP exactly (6.566820109835115).
  dtaidistance 2.5.1 `dtw.distance(use_c=False)` (audit comparison venv, no tslearn import) gives the same value on that
  pair and on a second pair, T=80 seed 5 (5.972081410007747 for both, difference 0.0). dtaidistance `window=2` equals the
  tslearn radius-1 band on both pairs (8.061528067978553 and 8.12914957772889). `window=1` gives 10.13 and 11.37.""")

sub("""**Candidate new finding (confirmed by probes, not in KNOWN_ISSUES)**: in tslearn 0.9.0 the numpy LCSS path ignores the
global constraint.

- `np.isfinite(False)` is `True`, so every cell is evaluated.
- In tslearn v0.5.2 (WebFetch of the tag) masks were float arrays with 0 inside and inf outside, so the same test
  worked. Hypothesis: this is a library regression introduced when masks became boolean. pyspi originally required
  `tslearn>=0.5.2` and now pins `>=0.9,<0.10` (commit a2c3300). If so, the constrained LCSS values changed with the
  migration.""",
"""**Candidate new finding (confirmed by probes, not in KNOWN_ISSUES)**: in tslearn 0.8.0, 0.8.1 and 0.9.0 the numpy LCSS
path ignores the global constraint.

- `np.isfinite(False)` is `True`, so every cell is evaluated.
- Release range (WebFetch of the GitHub tags). In v0.5.2, v0.6.4 and v0.7.0 the masks are float arrays
  (`numpy.full(..., numpy.inf)`, admissible cells 0.0), so the same `isfinite` test excludes masked cells. In v0.8.0
  the masks move to `tslearn/metrics/_masks.py` and become boolean (`backend.full((sz1, sz2), False)`), while v0.8.0,
  v0.8.1 and v0.9.0 keep the `isfinite` test. tslearn `main` now tests `if mask[i - 1, j - 1]:` in
  `njit_lcss_accumulated_matrix`. The bug is therefore fixed upstream, but v0.9.0 is still the latest tag.
- pyspi requirement history (git): ef478a8 (2021-11-29) `tslearn>=0.5.2`; e66057f (2022-02-10) `tslearn==0.5.2`;
  0943868 (2024-05-18) bare `tslearn` (`requirements.txt:20`, `setup.py:29` at a2c3300^); a2c3300 changes the bare
  `tslearn` to `tslearn>=0.9,<0.10` (`pyproject.toml:41`). The test lock `tests/requirements-test-lock.txt` already held
  `tslearn==0.9.0` when it was created (30556b9, line 66, before a2c3300). The migration therefore did not change the
  locked tslearn version, and the snapshot goldens were already produced with the ignored mask.
- The tslearn version behind published pyspi results cannot be read from the pins. Under the `==0.5.2` pin
  (2022-02-10 to 2024-05-18) the mask is honoured. An install from the unpinned period could resolve to whatever
  release was current (0.8.0 or later ignores the mask). Hypothesis only: published `lcss_constraint-*` values may
  differ between installs.""")

sub("""- Candidate (Itakura, intended behaviour, if the mask were honoured): the last row and column of the parallelogram
  admit only the corner cell, and masked cells stay 0. The score is then 0 whenever the final samples differ by more
  than eps. Probe: 50% of iid pairs at T=128 score exactly 0, and the rest average 0.786.""",
"""- Candidate (Itakura, intended behaviour, if the mask were honoured): at T=128 the first row of tslearn's parallelogram
  admits only column 0, and the last row and last column admit only the corner cell. Masked cells stay 0, so the score
  is exactly 0 iff the final samples differ by more than eps. A from-scratch masked DP confirmed this on all 400 seeded
  independent pairs. If the final z-scored samples are approximately N(0,1), their difference is approximately N(0,2),
  so P(score = 0) = 1 − (2Φ(1/√2) − 1) = 0.48. Sampled fractions scatter around this value (30-pair runs: 50% and 43%;
  400-pair run: 47%).""")

sub("""- Numerical (minor): the cost matrix uses the dot-product expansion. Probe: diagonal-cell relative error 2.9e-6 for
  near-equal samples, and an absolute error of 2.9e-8 with a 1e4 offset when normalise=False.""",
"""- Numerical (minor): the cost matrix uses the dot-product expansion. The absolute cell error is of order 1e-14 on
  unit-scale data (1.07e-14 on z-scored data) and 2.9e-8 with a 1e4 offset when normalise=False. The relative error of
  a cell is that absolute error divided by (x_i − y_j)², so it is unbounded as a cell approaches 0. For y = x + 1e-3
  noise at T=256, the maximum diagonal relative error ranged from 1.2e-7 to 2.1e-3 across 20 seeds.""")

sub("""1. Which tslearn version produced the published pyspi results (the original requirement was `>=0.5.2`)? If it was
   below the boolean-mask change, `lcss_constraint-*` values in published work were constrained, and the migration
   changed them. The exact tslearn release that switched to boolean masks is not yet identified.""",
"""1. Which tslearn version produced the published pyspi results? The requirement was `>=0.5.2` (2021-11), `==0.5.2`
   (2022-02 to 2024-05), then unpinned until a2c3300. If it was below 0.8.0, `lcss_constraint-*` values in published
   work were constrained. The in-repo test lock already held `tslearn==0.9.0` before a2c3300, so the migration did not
   change the locked version. The boolean-mask change is in v0.8.0, and the fix is on tslearn `main` but unreleased.""")

sub("""Delegate: tslearn 0.9.0 (`tslearn/__init__.py:2`), numpy/numba backend. Probe scripts:
`/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/dtw_family/probe{1..6}.py`.""",
"""Delegate: tslearn 0.9.0 (`tslearn/__init__.py:2`), numpy/numba backend. Probe scripts:
`/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/dtw_family/probe{1..6}.py`;
review fixes in `.../scratchpad/dtw_fix/probe_fix.py`, `tsl.py` and `dtai.py`.""")
p.write_text(t); print('ok')
