import numpy as np
from scipy.stats import norm, zscore
from sklearn.metrics.pairwise import euclidean_distances
from tslearn.metrics._masks import compute_mask
#
from tslearn.metrics import dtw as tdtw
# 2) Itakura mask rows at T=128
m=compute_mask(128,128,1)
print('first row cols',np.where(m[0])[0],'last row cols',np.where(m[-1])[0],'last col rows',np.where(m[:,-1])[0], 'row T-2 cols', np.where(m[-2])[0])
# analytic
p=2*norm.cdf(1/np.sqrt(2))-1; print('P(|d|<=1), d~N(0,2) = %.4f; P(score=0) = %.4f'%(p,1-p))
# masked from-scratch LCSS on many pairs
def lcss_m(a,b,mask,eps=1.0):
    T=len(a); acc=np.zeros((T+1,T+1),int)
    for i in range(1,T+1):
        for j in range(1,T+1):
            if mask[i-1,j-1]:
                acc[i,j]=1+acc[i-1,j-1] if abs(a[i-1]-b[j-1])<=eps else max(acc[i,j-1],acc[i-1,j])
    return acc[T,T]/T
r=np.random.default_rng(123); vals=[]
for k in range(400):
    z=zscore(r.standard_normal((2,128)),axis=1,ddof=1)
    vals.append((lcss_m(z[0],z[1],m), abs(z[0,-1]-z[1,-1])<=1))
v=np.array([a for a,_ in vals]); match=np.array([b for _,b in vals])
print('400 pairs: frac zero %.3f; zero iff last mismatch: %s'%((v==0).mean(), np.array_equal(v==0, ~match)))
