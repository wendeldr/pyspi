import re, pathlib
R = pathlib.Path('/media/dan/Data/git/pyspi/audit/records')

def sub(text, old, new, count=1):
    assert text.count(old) == count, (old[:80], text.count(old))
    return text.replace(old, new)

def q(s):  # single-quoted YAML scalar
    return "'" + s.replace("'", "''") + "'"

def wrap(s, indent='    ', first='  - ', width=150):
    words = s.split(' '); lines = []; cur = first
    for w in words:
        if len(cur) + 1 + len(w) > width and cur.strip() not in ('-', ''):
            lines.append(cur); cur = indent + w
        else:
            cur = cur + ('' if cur.endswith(' ') else ' ') + w
    lines.append(cur)
    return '\n'.join(lines) + '\n'

# ---------- LCSS constrained units ----------
LCSS_OLD_START = "  - 'Candidate NEW finding (tslearn 0.9.0 regression, not in KNOWN_ISSUES)"
LCSS_NEW = ("Candidate NEW finding (upstream tslearn bug in releases 0.8.0, 0.8.1 and 0.9.0; not in KNOWN_ISSUES): the numpy/numba LCSS path "
 "ignores the global constraint. dtw_variants.py:2259 tests 'numpy.isfinite(mask[i-1, j-1])' but the mask from _masks.compute_mask is "
 "boolean, and np.isfinite(False) is True, so every cell is evaluated. Release range (WebFetch of the GitHub tags): v0.5.2, v0.6.4 and v0.7.0 "
 "build float masks (numpy.full(..., numpy.inf), admissible cells 0.0), so the same isfinite test excluded masked cells; v0.8.0 "
 "(tslearn/metrics/_masks.py, backend.full((sz1, sz2), False)), v0.8.1 and v0.9.0 pair boolean masks with the isfinite test; tslearn main "
 "now tests 'if mask[i - 1, j - 1]:' in njit_lcss_accumulated_matrix, so the bug is fixed upstream but v0.9.0 is the latest tag. "
 "Probe: delayed series T=60 -> tslearn lcss = 0.9167 for None, itakura and sakoe_chiba alike, while a from-scratch masked LCSS gives "
 "0.9167 / 0.0 / 0.70 and tslearn's torch backend (which uses 'if mask[...]', line 2306) gives the masked values (T=64: itakura 0.797 torch "
 "vs 0.8125 numpy; sakoe_chiba 0.766 torch vs 0.8125 numpy). pyspi end-to-end (4x128): lcss, lcss_constraint-itakura and "
 "lcss_constraint-sakoe-chiba matrices are bit-identical; the regression snapshot files (tests/regression/goldens small/full) also hold "
 "identical matrices for the three identifiers (a snapshot observation only). pyspi requirement history (git): ef478a8 (2021-11-29) setup.py "
 "'tslearn>=0.5.2'; e66057f (2022-02-10) 'tslearn==0.5.2'; 0943868 (2024-05-18) bare unpinned 'tslearn' (requirements.txt:20, setup.py:29 "
 "at a2c3300^); a2c3300 changes the bare 'tslearn' to 'tslearn>=0.9,<0.10' (pyproject.toml:41). The test lock tests/requirements-test-lock.txt "
 "already held tslearn==0.9.0 when it was created (30556b9, line 66), before a2c3300, so the migration did not change the locked tslearn "
 "version and the snapshot goldens already reflect the ignored mask. The version behind published pyspi results is not known from the pins: "
 "the ==0.5.2 pin (2022-02-10 to 2024-05-18) honours the mask, and an install from the unpinned period could resolve to any release current "
 "at install time (0.8.0 or later ignores it). Hypothesis only: published lcss_constraint-* values may differ between installs.")
LCSS_TRACE_ANCHOR = "    j - 1])'' test in njit_lcss_accumulated_matrix (WebFetch of the v0.5.2 tag)'\n"
LCSS_TRACE_ADD = wrap(q("https://raw.githubusercontent.com/tslearn-team/tslearn/{v0.6.4,v0.7.0,v0.8.0,v0.8.1,main}/tslearn/metrics/dtw_variants.py "
 "and v0.8.0 tslearn/metrics/_masks.py (WebFetch): v0.6.4 and v0.7.0 float inf/0 masks with 'if numpy.isfinite(mask[i - 1, j - 1]):'; "
 "v0.8.0 _masks.py builds masks with backend.full((sz1, sz2), False) and v0.8.0/v0.8.1 keep the isfinite test (ignored mask); main "
 "njit_lcss_accumulated_matrix uses 'if mask[i - 1, j - 1]:' (fixed upstream, no tag after v0.9.0)"))

for uid in ['distance.lcss.constraint-sakoe_chiba', 'distance.lcss.constraint-itakura']:
    p = R / f'{uid}.yaml'; t = p.read_text()
    i = t.index(LCSS_OLD_START); j = t.index("\n  - '", i + 5)
    t = t[:i] + wrap(q(LCSS_NEW)).rstrip('\n') + t[j:]
    t = sub(t, LCSS_TRACE_ANCHOR, LCSS_TRACE_ANCHOR + LCSS_TRACE_ADD)
    if uid.endswith('itakura'):
        i = t.index("  - 'Candidate (intended-behaviour degeneracy"); j = t.index("\n  - '", i + 5)
        new = ("Candidate (intended-behaviour degeneracy, relevant if the mask is ever honoured): tslearn's Itakura mask at T=128 admits only "
               "column 0 in the first row and only column 127 in the last row and last column (row 126 admits columns 125-126; probe "
               "compute_mask(128, 128, 1)). Masked cells stay 0 in the LCSS DP, so the corner value is exactly 0 iff the final samples "
               "differ by more than eps (|z_x[T] - z_y[T]| > 1); a from-scratch masked DP confirmed this equivalence on all 400 seeded "
               "z-scored independent pairs at T=128. For independent pairs whose final z-scored samples are approximately N(0,1), the "
               "difference is approximately N(0,2), so P(score = 0) = 1 - (2 Phi(1/sqrt(2)) - 1) = 0.48 (P(final match) = 0.52). Sampled "
               "fractions scatter around this value (30-pair runs: 50% and 43%; 400-pair run: 47%). The tslearn torch backend reproduces "
               "the masked value on the probe pair.")
        t = t[:i] + wrap(q(new)).rstrip('\n') + t[j:]
    p.write_text(t)

# ---------- softdtw ----------
p = R / 'distance.softdtw.yaml'; t = p.read_text()
i = t.index("  - 'Candidate (numerical, minor)"); j = t.index("\n  - '", i + 5)
new = ("Candidate (numerical, minor): the squared-Euclidean cost comes from sklearn's |x|^2+|y|^2-2xy expansion followed by sqrt and "
       "re-squaring, which adds an absolute error of order 1e-14 per cell on unit-scale data (probe: 1.07e-14 max on z-scored data; "
       "1.4e-14 max over 20 seeds of y = x + 1e-3 noise, T=256) and 2.9e-8 with a 1e4 offset when normalise=False. The relative error of "
       "a cell is that absolute error divided by (x_i - y_j)^2, so it is unbounded as the cell approaches 0: for y = x + 1e-3 noise the "
       "maximum diagonal relative error ranged from 1.2e-7 to 2.1e-3 across 20 seeds, and no single relative figure characterises it. "
       "Expected impact on the final value < 1e-10 relative for z-scored data (hypothesis, to be measured by the from-scratch check).")
t = t[:i] + wrap(q(new)).rstrip('\n') + t[j:]
p.write_text(t)

# ---------- dtw None ----------
p = R / 'distance.dtw.constraint-None.yaml'; t = p.read_text()
old = "of most ML libraries (tslearn docstring _dtw.py:41-46; dtaidistance gives the identical value)."
assert old in t.replace('\n    ', ' '), 'dtw old'
flat_start = t.index("  deviation_from_canonical: 'Three convention")
flat_end = t.index("\n  already_documented:", flat_start)
blk = t[flat_start:flat_end].replace('\n    ', ' ')
blk = blk.replace("dtaidistance gives the identical value)", "dtaidistance 2.5.1 dtw.distance(use_c=False), audit comparison venv without tslearn, "
    "gives the identical value on the same T=50 seed-0 pair, 6.566820109835115, and on a second pair, T=80 seed 5, 5.972081410007747 for both "
    "(difference 0.0); dtaidistance window=2 equals tslearn sakoe_chiba radius 1 on both pairs, 8.061528067978553 and 8.12914957772889)")
assert blk.startswith("  deviation_from_canonical: ")
body = blk[len("  deviation_from_canonical: "):]
t = t[:flat_start] + wrap(body, first='  deviation_from_canonical: ').rstrip('\n') + t[flat_end:]
t = t.replace("expected_outcome: relative difference <= 1e-12 (a seeded T=80 probe gave identical values)",
              "expected_outcome: relative difference <= 1e-12 (seeded probes T=50 seed 0 and T=80 seed 5 gave identical values)")
p.write_text(t)
print('ok')
