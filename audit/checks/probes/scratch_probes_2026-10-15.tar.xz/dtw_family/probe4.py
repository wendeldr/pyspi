import numpy as np, warnings, sys
warnings.filterwarnings("ignore")
sys.path.insert(0, '.')
from lref import *
from tslearn.metrics import _masks
import tslearn.metrics as tm
try:
    import torch; print("torch", torch.__version__)
except ImportError: print("torch not installed")
rng = np.random.default_rng(3)
T=128; res=[]
mI=_masks.compute_mask(T,T,1); mS=_masks.compute_mask(T,T,2)
print("itakura last row allowed cols", np.where(mI[-1])[0], "first row", np.where(mI[0])[0])
for k in range(30):
    x=rng.standard_normal(T); y=rng.standard_normal(T)
    res.append((lcss_ref(x,y,mask=mI), lcss_ref(x,y,mask=mS), lcss_ref(x,y), tm.lcss(x,y,global_constraint="itakura")))
res=np.array(res)
print("intended itakura LCSS: frac zero", (res[:,0]==0).mean(), "nonzero mean", res[res[:,0]>0,0].mean())
print("intended SC LCSS mean", res[:,1].mean(), "unconstrained mean", res[:,2].mean(), "tslearn itakura==unconstrained", np.allclose(res[:,3],res[:,2]))
x=rng.standard_normal(64); y=rng.standard_normal(64)
for gc in ("itakura","sakoe_chiba"):
    m=_masks.compute_mask(64,64,_masks.GLOBAL_CONSTRAINT_CODE[gc])
    print(gc, "torch-backend lcss", tm.lcss(torch.tensor(x), torch.tensor(y), global_constraint=gc, be="pytorch"), "numpy-backend", tm.lcss(x,y,global_constraint=gc), "ref masked", lcss_ref(x,y,mask=m))
