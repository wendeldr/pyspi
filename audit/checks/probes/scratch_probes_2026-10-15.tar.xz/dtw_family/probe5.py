import numpy as np, warnings
warnings.filterwarnings("ignore")
import tslearn.metrics as tm
from tslearn.metrics.softdtw_variants import SquaredEuclidean
rng = np.random.default_rng(4)
for T in (64,256,1024):
    x=rng.standard_normal(T); y=rng.standard_normal(T)
    z=lambda a:(a-a.mean())/a.std(ddof=1); x=z(x); y=z(y)
    print(T, "softdtw x,x", round(tm.soft_dtw(x,x),3), "x,y indep", round(tm.soft_dtw(x,y),3), "x,-x", round(tm.soft_dtw(x,-x),3),
          "| dtw x,y", round(tm.dtw(x,y),3), "x,-x", round(tm.dtw(x,-x),3), "SC x,y", round(tm.dtw(x,y,global_constraint='sakoe_chiba'),3), "euclid", round(np.linalg.norm(x-y),3))
# cost-matrix precision: sklearn expansion vs direct
x = 1e4 + rng.standard_normal(200); y = x + 1e-6*rng.standard_normal(200)
D = SquaredEuclidean(x, y).compute(); Dd = (x[:,None]-y[None,:])**2
print("offset 1e4: max abs D err", np.abs(D-Dd).max(), "diag direct max", np.diag(Dd).max(), "diag sklearn", np.diag(D)[:5])
x = rng.standard_normal(200); y = x + 1e-3*rng.standard_normal(200)
D = SquaredEuclidean(x, y).compute(); Dd = (x[:,None]-y[None,:])**2
print("z-scored: max abs D err", np.abs(D-Dd).max(), "max rel diag err", np.max(np.abs(np.diag(D)-np.diag(Dd))/np.diag(Dd)))
