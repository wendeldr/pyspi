import numpy as np, warnings, sys
warnings.filterwarnings("ignore")
rng=np.random.default_rng(5); x=rng.standard_normal(80); y=rng.standard_normal(80)
import tslearn.metrics as tm
print("tslearn dtw", tm.dtw(x,y), "SC", tm.dtw(x,y,global_constraint="sakoe_chiba"), "lcss", tm.lcss(x,y))
try:
    from dtaidistance import dtw as ddtw
    print("dtaidistance", ddtw.distance(x,y, use_c=False), "window=2", ddtw.distance(x,y,window=2,use_c=False))
except Exception as e: print("dtaidistance err", e)
try:
    import sktime.distances as sd, sktime
    print("sktime", sktime.__version__, "dtw", sd.dtw_distance(x,y), "sqrt", np.sqrt(sd.dtw_distance(x,y)))
    print("sktime lcss eps1", sd.lcss_distance(x,y,epsilon=1.0))
except Exception as e: print("sktime err", type(e).__name__, e)
