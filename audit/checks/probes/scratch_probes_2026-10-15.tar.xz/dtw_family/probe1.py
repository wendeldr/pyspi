import numpy as np, warnings
warnings.filterwarnings("ignore")
import tslearn, tslearn.metrics as tm
from tslearn.metrics import _dtw, dtw_variants, _masks
from pyspi.statistics.distance import DynamicTimeWarping, LongestCommonSubsequence, SoftDynamicTimeWarping
print("tslearn", tslearn.__version__)
for cls in (DynamicTimeWarping, LongestCommonSubsequence, SoftDynamicTimeWarping):
    for gc in (None, "itakura", "sakoe_chiba"):
        o = cls(global_constraint=gc)
        print(cls.__name__, o.name, o.identifier, o._global_constraint, getattr(o, "_simfn", None))
print("dtw is", tm.dtw.__module__, "lcss is", tm.lcss.__module__, "soft_dtw", tm.soft_dtw.__module__)

# from-scratch DTW
def dtw_ref(x, y, mask=None, cost=lambda a,b:(a-b)**2):
    n, m = len(x), len(y)
    R = np.full((n+1, m+1), np.inf); R[0,0]=0
    for i in range(n):
        for j in range(m):
            if mask is None or mask[i,j]:
                R[i+1,j+1] = cost(x[i],y[j]) + min(R[i,j], R[i,j+1], R[i+1,j])
    return R[n,m]
rng = np.random.default_rng(0)
x = rng.standard_normal(50); y = rng.standard_normal(50)
print("dtw tslearn", tm.dtw(x,y), "ref sqrt(sum sq)", np.sqrt(dtw_ref(x,y)), "ref abs-sum", dtw_ref(x,y,cost=lambda a,b:abs(a-b)))
print("euclid", np.linalg.norm(x-y))
print("SC mask 6x6 default:\n", _masks.compute_mask(6,6,2).astype(int))
print("Itakura mask 8x8 default:\n", _masks.compute_mask(8,8,1).astype(int))
for gc in ("sakoe_chiba","itakura"):
    m = _masks.compute_mask(50,50,_masks.GLOBAL_CONSTRAINT_CODE[gc])
    print(gc, "dtw tslearn", tm.dtw(x,y,global_constraint=gc), "ref", np.sqrt(dtw_ref(x,y,m)), "cells", m.sum())
# SC radius=1 band in T=1024 fraction
for T in (64,256,1024,4096):
    m = _masks.compute_mask(T,T,2); mi = _masks.compute_mask(T,T,1)
    print(T, "SC band frac", m.sum()/T**2, "itakura frac", mi.sum()/T**2)
