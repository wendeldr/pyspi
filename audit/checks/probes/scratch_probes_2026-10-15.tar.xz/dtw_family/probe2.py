import numpy as np, warnings
warnings.filterwarnings("ignore")
import tslearn.metrics as tm
from tslearn.metrics import _masks, dtw_variants
def lcss_ref(x, y, eps=1.0, mask=None, strict=False):
    n, m = len(x), len(y)
    L = np.zeros((n+1, m+1), dtype=np.int64)
    for i in range(1, n+1):
        for j in range(1, m+1):
            if mask is None or mask[i-1,j-1]:
                d = abs(x[i-1]-y[j-1])
                ok = d < eps if strict else d <= eps
                if ok: L[i,j] = 1 + L[i-1,j-1]
                else: L[i,j] = max(L[i,j-1], L[i-1,j])
    return L[n,m] / min(n,m)
# shifted sequence: y = x delayed by 5 samples
rng = np.random.default_rng(1)
x = rng.standard_normal(60); y = np.r_[rng.standard_normal(5)*5+20, x[:-5]]
for gc in (None, "itakura", "sakoe_chiba"):
    m = _masks.compute_mask(60, 60, _masks.GLOBAL_CONSTRAINT_CODE[gc])
    print(gc, "tslearn", tm.lcss(x, y, global_constraint=gc), "ref-masked", lcss_ref(x,y,mask=m), "ref-unmasked", lcss_ref(x,y))
print("isfinite(False)=", np.isfinite(False))
# independent gaussian saturation
for T in (64, 256, 1024):
    xs = rng.standard_normal(T); ys = rng.standard_normal(T)
    xs=(xs-xs.mean())/xs.std(ddof=1); ys=(ys-ys.mean())/ys.std(ddof=1)
    print(T, "lcss indep", tm.lcss(xs, ys), "lcss(x,-x)", tm.lcss(xs,-xs), "lcss(x,x)", tm.lcss(xs,xs), "lcss SC indep", tm.lcss(xs,ys,global_constraint="sakoe_chiba"), "ref SC", lcss_ref(xs,ys,mask=_masks.compute_mask(T,T,2)) if T<=256 else None)
# tie at eps boundary
print("boundary eps==dist:", tm.lcss([0.,0.],[1.,1.]), "strict ref", lcss_ref(np.array([0.,0.]),np.array([1.,1.]),strict=True))
