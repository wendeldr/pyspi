import numpy as np
def lcss_ref(x, y, eps=1.0, mask=None, strict=False):
    n, m = len(x), len(y)
    L = np.zeros((n+1, m+1), dtype=np.int64)
    for i in range(1, n+1):
        for j in range(1, m+1):
            if mask is None or mask[i-1,j-1]:
                d = abs(x[i-1]-y[j-1])
                ok = d < eps if strict else d <= eps
                if ok: L[i,j] = 1 + L[i-1,j-1]
                else: L[i,j] = max(L[i,j-1], L[i-1,j])
    return L[n,m] / min(n,m)
