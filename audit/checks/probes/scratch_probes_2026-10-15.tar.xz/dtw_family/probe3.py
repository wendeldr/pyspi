import numpy as np, warnings
warnings.filterwarnings("ignore")
import tslearn.metrics as tm
from tslearn.metrics import _masks
from pyspi.data import Data
from pyspi.statistics.distance import DynamicTimeWarping, LongestCommonSubsequence, SoftDynamicTimeWarping
def softmin(a, g):
    a = np.asarray(a)/-g; m = a.max(); return -g*(np.log(np.exp(a-m).sum())+m)
def sdtw_ref(x, y, g=1.0):
    n, m = len(x), len(y)
    R = np.full((n+1, m+1), np.inf); R[0,0]=0
    for i in range(1,n+1):
        for j in range(1,m+1):
            R[i,j] = (x[i-1]-y[j-1])**2 + softmin([R[i-1,j],R[i-1,j-1],R[i,j-1]], g)
    return R[n,m]
rng = np.random.default_rng(2)
x = rng.standard_normal(40); y = rng.standard_normal(40)
print("softdtw tslearn", tm.soft_dtw(x,y), "ref", sdtw_ref(x,y), "dtw^2", tm.dtw(x,y)**2)
print("softdtw(x,x)", tm.soft_dtw(x,x), "ref", sdtw_ref(x,x))
try:
    tm.soft_dtw(x, y, global_constraint="itakura")
except TypeError as e: print("soft_dtw kwarg:", e)
# pyspi end-to-end on 4 processes
Z = rng.standard_normal((4, 128)); Z[1] = np.roll(Z[0], 3) + 0.3*rng.standard_normal(128)
d = Data(Z.copy(), dim_order="ps")
z = d.to_numpy(squeeze=True)
for cls in (DynamicTimeWarping, LongestCommonSubsequence, SoftDynamicTimeWarping):
    mats = {}
    for gc in (None, "itakura", "sakoe_chiba"):
        A = cls(global_constraint=gc).multivariate(d)
        mats[gc] = A
    print(cls.__name__, "A[0,1]:", {k: round(v[0,1],6) for k,v in mats.items()},
          "diag nan", np.isnan(np.diag(mats[None])).all(), "sym", np.array_equal(mats[None], mats[None].T, equal_nan=True))
    print("   itakura==None", np.array_equal(mats[None], mats["itakura"], equal_nan=True), "SC==None", np.array_equal(mats[None], mats["sakoe_chiba"], equal_nan=True))
# raw-lib asymmetry before mirror
print("softdtw raw (0,1)-(1,0)", tm.soft_dtw(z[0],z[1]) - tm.soft_dtw(z[1],z[0]))
print("dtw raw (0,1)-(1,0) itakura", tm.dtw(z[0],z[1],global_constraint="itakura") - tm.dtw(z[1],z[0],global_constraint="itakura"))
m = _masks.compute_mask(128,128,1); print("itakura mask symmetric (equal len)", np.array_equal(m, m.T))
# which half is kept
A = SoftDynamicTimeWarping().multivariate(d)
print("A[1,0]==softdtw(z0,z1)", A[1,0]==tm.soft_dtw(z[0],z[1]), "A[1,0]==softdtw(z1,z0)", A[1,0]==tm.soft_dtw(z[1],z[0]))
# zscore check
print("data mean/std", z.mean(1).round(12), z.std(1, ddof=1).round(12))
# parse_bivariate with raw arrays: normalisation of second process?
a = 5+3*rng.standard_normal(64); b = 5+3*rng.standard_normal(64)
dd = Data(); dd.add_process(a); dd.add_process(b)
zz = dd.to_numpy(squeeze=True); print("raw-array path means", zz.mean(1).round(3), "stds", zz.std(1,ddof=1).round(3))
