import yaml, pathlib
OUT = pathlib.Path("/media/dan/Data/git/pyspi/audit/records")
TS = ".venv/lib/python3.12/site-packages/tslearn"

COMMON_PRE = [
    "pyspi/calculator.py:294 Calculator.compute calls self._spis[spi].multivariate(self.dataset)",
    "pyspi/data.py:184-195 Data.set_data: scipy.signal.detrend(axis=1) only if detrend=True (default False), then scipy.stats.zscore(axis=1, nan_policy='omit', ddof=1) if normalise=True (default True)",
    "pyspi/base.py:132-138 Undirected.multivariate: A = Directed.multivariate(data); A[tril(-1)] = A.T[tril(-1)] (lower triangle overwritten by the upper triangle, so A[i,j] = bivariate(min(i,j), max(i,j)))",
    "pyspi/base.py:84-94 Directed.multivariate: A filled with NaN, bivariate(data, i, j) for every ordered pair i != j (both orders computed, diagonal stays NaN)",
    "pyspi/base.py:27-49 parse_bivariate: a raw (x, y) call builds Data() and add_process(x), add_process(y) (pyspi/data.py:219-240)",
]
TW_BIV = [
    "pyspi/statistics/distance.py:154-163 TimeWarping.__init__: identifier += '_constraint-' + global_constraint.replace('_','-'); self._global_constraint stored",
    "pyspi/statistics/distance.py:174-177 TimeWarping.bivariate: z = data.to_numpy(squeeze=True) (pyspi/data.py:108-118); return self._simfn(z[i], z[j], global_constraint=self._global_constraint)",
]
DTW_TRACE = TW_BIV + [
    "pyspi/statistics/distance.py:180-187 DynamicTimeWarping: self._simfn = tslearn.metrics.dtw",
    f"{TS}/metrics/__init__.py:20-27 tslearn.metrics.dtw is tslearn.metrics._dtw.dtw (tslearn==0.9.0 per tslearn/__init__.py:2)",
    f"{TS}/metrics/_dtw.py:30-37 dtw(s1, s2, global_constraint=None, sakoe_chiba_radius=None, itakura_max_slope=None, be=None)",
    f"{TS}/metrics/_dtw.py:145-147 instantiate_backend (numpy for ndarray inputs); to_time_series(remove_nans=True) reshapes to (T,1) and strips trailing all-NaN rows ({TS}/utils/utils.py:154-212, _ts_size 511-518)",
    f"{TS}/metrics/_dtw.py:157-163 global_constraint mapped via GLOBAL_CONSTRAINT_CODE ({TS}/metrics/_masks.py:10: None->0, itakura->1, sakoe_chiba->2) and passed to _njit_dtw",
    f"{TS}/metrics/_dtw.py:383-412 __make_dtw/_dtw_generic: mask = _njit_compute_mask(sz1, sz2, code, radius, slope); cum_sum = _njit_accumulated_matrix(s1, s2, mask); return sqrt(cum_sum[-1, -1]) (line 400)",
    f"{TS}/metrics/_masks.py:310-361 _compute_mask_generic: code 2 -> radius None replaced by 1 (339-341); code 1 -> max_slope None replaced by 2.0 (346-348); code 0 -> all-True mask (350)",
    f"{TS}/metrics/_dtw.py:324-344 _njit_accumulated_matrix: cell cost = sum_d (s1[i,d]-s2[j,d])**2; cum[i+1,j+1] = cost + min(cum[i,j+1], cum[i+1,j], cum[i,j]) (equal weights on all three moves, masked cells stay +inf)",
]
SC_TRACE = [f"{TS}/metrics/_masks.py:13-29 _sakoe_chiba_mask_generic: for equal lengths width = radius; row i allowed columns max(0,i-radius) .. min(T,i+radius) inclusive, i.e. |i-j| <= radius = 1"]
IT_TRACE = [f"{TS}/metrics/_masks.py:89-140 _itakura_mask_generic: slopes in [1/max_slope, max_slope] = [0.5, 2] scaled by sz1/sz2; lower/upper bounds from both corners, rounded to 2 decimals (102-103, 113-114), ceil/floor; raises RuntimeWarning if any row/column is empty (122-138)"]
LCSS_TRACE = TW_BIV + [
    "pyspi/statistics/distance.py:190-197 LongestCommonSubsequence: self._simfn = tslearn.metrics.lcss (eps not passed, library default used)",
    f"{TS}/metrics/__init__.py:44-55 tslearn.metrics.lcss is tslearn.metrics.dtw_variants.lcss (tslearn==0.9.0)",
    f"{TS}/metrics/dtw_variants.py:2383-2391 lcss(s1, s2, eps=1.0, global_constraint=None, sakoe_chiba_radius=None, itakura_max_slope=None, be=None)",
    f"{TS}/metrics/dtw_variants.py:2485-2496 to_time_series(remove_nans=True); mask = compute_mask_(...) where compute_mask_ is tslearn.metrics._masks.compute_mask (import at dtw_variants.py:11), which returns a BOOLEAN mask ({TS}/metrics/_masks.py:199-307, 310-361; same defaults radius 1 / slope 2.0)",
    f"{TS}/metrics/dtw_variants.py:2497-2498 numpy backend -> _njit_lcss(s1, s2, eps, mask)",
    f"{TS}/metrics/dtw_variants.py:2321-2345 _njit_lcss: acc = njit_lcss_accumulated_matrix(...); return float(acc[-1][-1]) / min(l1, l2)",
    f"{TS}/metrics/dtw_variants.py:2232-2267 njit_lcss_accumulated_matrix: integer DP; line 2259 'if numpy.isfinite(mask[i - 1, j - 1]):' (True for both True and False boolean entries); line 2260 match if sqrt(squared dist) <= eps -> 1 + acc[i-1][j-1], else max(acc[i][j-1], acc[i-1][j])",
    f"{TS}/metrics/dtw_variants.py:2270-2318 lcss_accumulated_matrix (non-numpy backends only): line 2306 'if mask[i - 1, j - 1]:' honours the boolean mask",
    "https://raw.githubusercontent.com/tslearn-team/tslearn/v0.5.2/tslearn/metrics/dtw_variants.py compute_mask/sakoe_chiba_mask/itakura_mask: mask = numpy.full((sz1, sz2), numpy.inf) with admissible cells set to 0. (float 0/inf mask), and the same 'if numpy.isfinite(mask[i - 1, j - 1])' test in njit_lcss_accumulated_matrix (WebFetch of the v0.5.2 tag)",
]
SOFT_TRACE = [
    "pyspi/statistics/distance.py:154-163 TimeWarping.__init__ (inherited): identifier gets '_constraint-itakura' / '_constraint-sakoe-chiba'; self._global_constraint stored but never read by SoftDynamicTimeWarping",
    "pyspi/statistics/distance.py:200-208 SoftDynamicTimeWarping: name = 'Dynamic time warping'; bivariate overrides TimeWarping.bivariate and returns tslearn.metrics.soft_dtw(z[i], z[j]) with no constraint and default gamma",
    f"{TS}/metrics/__init__.py:57-67 tslearn.metrics.soft_dtw is tslearn.metrics.softdtw_variants.soft_dtw (tslearn==0.9.0)",
    f"{TS}/metrics/softdtw_variants.py:530 soft_dtw(ts1, ts2, gamma=1.0, be=None, compute_with_backend=False) (no constraint parameter exists; probe: TypeError on global_constraint=)",
    f"{TS}/metrics/softdtw_variants.py:624-628 be.array; if math.isclose(gamma, 0.0) return dtw(ts1, ts2)**2 (not taken, gamma=1)",
    f"{TS}/metrics/softdtw_variants.py:629-638 SoftDTW(SquaredEuclidean(_to_time_series(ts1, True), _to_time_series(ts2, True)), gamma=1.0).compute()",
    f"{TS}/metrics/softdtw_variants.py:1176-1216 SquaredEuclidean.compute: be.pairwise_euclidean_distances(X, Y) ** 2",
    f"{TS}/backend/numpy_backend.py:19,70 pairwise_euclidean_distances = sklearn.metrics.pairwise.euclidean_distances",
    ".venv/lib/python3.12/site-packages/sklearn/metrics/pairwise.py:268 euclidean_distances -> 376-426 _euclidean_distances (scikit-learn 1.9.1): float64 path -2*X@Y.T + |X|^2 + |Y|^2, clamped at 0, then sqrt (squared again by tslearn)",
    f"{TS}/metrics/softdtw_variants.py:1068-1135 SoftDTW.__init__/compute: D cast to float64, R_ zeros (m+2, n+2); _njit_soft_dtw(D, R_, gamma); return R_[m, n]",
    f"{TS}/metrics/soft_dtw_fast.py:100-125 _njit_soft_dtw: R[:m+1,0] = R[0,:n+1] = DBL_MAX, R[0,0] = 0; R[i,j] = D[i-1,j-1] + softmin3(R[i-1,j], R[i-1,j-1], R[i,j-1], gamma)",
    f"{TS}/metrics/soft_dtw_fast.py:14-48 _njit_softmin3 (numba fastmath=True): -gamma * (log(sum exp(-a/gamma - max)) + max)",
]

PARSE_CAND = ("Cross-family (infrastructure) candidate, affects direct two-array calls only: parse_bivariate (pyspi/base.py:33-36) builds Data() "
              "(normalise=True) and calls add_process(x) then add_process(y); the first call goes through set_data and is z-scored, the second is "
              "np.append-ed raw (pyspi/data.py:230-234). Probe with x, y ~ 5 + 3 N(0,1), T=64: stored means [0.0, 4.783], stds [1.0, 2.995]. "
              "So spi.bivariate(x, y) compares z-scored x with raw y. Calculator/multivariate paths are unaffected.")

def check(datasets, path, reference, kind, criterion, outcome):
    return dict(datasets=datasets, path=path, reference=reference, reference_kind=kind, criterion=criterion, expected_outcome=outcome)

DIR_CHECK = lambda f: check(["delayed_noise", "iid_gaussian"], "pipeline",
    f"from-scratch numpy {f} applied to the ddof=1 z-scored rows z_i, z_j (no tslearn import)", "independent-impl", "direction",
    "Direction/symmetry convention: A == A.T exactly (np.array_equal with equal_nan), diagonal all NaN, and A[i,j] == A[j,i] == reference(z_min(i,j), z_max(i,j)) "
    "within tolerance; reference(z_i, z_j) and reference(z_j, z_i) agree to <= 1e-12 relative, so the undirected label carries no hidden order.")

DTW_CANON_REF = ("Sakoe H, Chiba S 1978, IEEE Trans. Acoust. Speech Signal Process. 26(1):43-49, symmetric DP-equation (Table I / eq. for P=0) "
                 "and adjustment window |i-j| <= r; global path constraints also in Itakura F 1975, IEEE Trans. ASSP 23(1):67-72 (slope limits 1/2..2)")
DTW_CANON_DEF = ("g(1,1)=2d(1,1); g(i,j)=min{g(i,j-1)+d(i,j), g(i-1,j-1)+2d(i,j), g(i-1,j)+d(i,j)}; D(A,B)=g(I,J)/(I+J), "
                 "with d(i,j)=||a_i-b_j|| a (non-squared) distance; constrained variants restrict (i,j) to a window/parallelogram")
DTW_DEV_CANON_BASE = ("Three convention differences from the Sakoe-Chiba 1978 symmetric form: (1) local cost is the SQUARED difference and the result is "
    "sqrt of the minimal accumulated squared cost (Euclidean-over-path DTW), not the sum of |a_i-b_j|; (2) step pattern is 'symmetric1' "
    "(diagonal move weight 1, not 2); (3) no normalisation by I+J (or by path length), so the value grows with T (about sqrt(T) for "
    "independent noise). Probe (T=50 iid N(0,1)): tslearn 6.5668 == from-scratch sqrt(min sum sq) 6.5668; abs-cost unweighted DP 36.674. "
    "This is the convention of most ML libraries (tslearn docstring _dtw.py:41-46; dtaidistance gives the identical value).")

DTW_DOC = ("supplement §1.2.7, p.6-7 (pack lines 286-301) and GitBook distance-similarity.md 'Dynamic Time Warping': \"DTW finds the minimum "
           "distance between two time series through alignment (shifting and dilating of the sequences)... the Sakoe-Chiba band [17] and the "
           "Itakura parallelogram [18] global constraints... computed using the tslearn package for the three global constraints\"; keywords "
           "undirected, nonlinear, unsigned, bivariate, time-dependent. No constraint width/slope is documented.")
NAMING_DEV = ("Identifier spelling: the code produces '{base}_constraint-sakoe-chiba' (distance.py:161 replaces '_' by '-'), the supplement and GitBook list "
              "'{base}_constraint-sakoe_chiba' (cosmetic).")

def rec(uid, c):
    return {"unit_id": uid, "status": "traced", "correctness": c}

records = []

# ---------------- DTW ----------------
dtw_common = dict(
    metric_name_standard="Dynamic time warping distance (Euclidean-over-path DTW, symmetric1 step pattern)",
    canonical_ref=DTW_CANON_REF,
    canonical_definition=DTW_CANON_DEF,
    documented_definition=DTW_DOC,
    delegate_lib="tslearn==0.9.0 tslearn.metrics.dtw (_dtw.py:30) -> numba _njit_dtw",
    units_and_range=("Same units as the (z-scored, hence dimensionless) input; >= 0; 0 iff an admissible warping aligns the series exactly; "
                     "unnormalised, grows with T; symmetric in its two arguments for equal-length inputs; finite for finite input (an infeasible "
                     "Itakura mask raises instead of returning NaN). Diagonal of the pyspi matrix is NaN."),
    direction_convention="Undirected: A[i,j] = A[j,i] = dtw(z_min(i,j), z_max(i,j)) (Undirected.multivariate mirrors the upper triangle); both orders are computed and the function is argument-symmetric, so the copy only removes last-bit differences; diagonal NaN.",
    symmetry_expected="sym",
)

uid = "distance.dtw.constraint-None"
c = dict(dtw_common)
c.update(
    implemented_as=("z-score each row (ddof=1, Calculator default; optional detrend first), then for each pair: unconstrained DTW over the full "
                    "T x T grid with squared pointwise cost, three equal-weight moves (match, insertion, deletion), result sqrt(accumulated cost "
                    "at (T,T)); trailing NaN rows stripped by tslearn (none present after pyspi's NaN check)."),
    implementation_trace=COMMON_PRE + DTW_TRACE,
    deviation_from_documented=("none in substance (tslearn, no constraint); the documentation does not say that the cost is squared+sqrt or that the "
                               "value is unnormalised by length."),
    deviation_from_canonical=DTW_DEV_CANON_BASE,
    already_documented="no",
    new_finding_candidates=[
        ("Candidate (interpretation, low discriminative range on noise): on z-scored independent noise unconstrained DTW barely separates "
         "independent from anti-correlated pairs. Probe (seeded, single draws): T=256 dtw(x,y)=11.02 vs dtw(x,-x)=12.31; T=1024 21.95 vs 22.24; "
         "Euclidean distance 21.90 / 45.63. Hypothesis: with unconstrained warping any two noise series align closely, so the SPI mostly "
         "reflects T and marginal shape. To be quantified on iid_gaussian vs bivariate_gaussian."),
        PARSE_CAND,
    ],
    proposed_checks=[
        check(["iid_gaussian", "delayed_noise", "narrowband_f0-0.25", "logistic_maps"], "kernel",
              "from-scratch numpy DP: R[0,0]=0, R[i,j]=(x_i-y_j)^2+min(R[i-1,j-1],R[i-1,j],R[i,j-1]), value sqrt(R[T,T]) (anti-diagonal vectorised for T=4096)",
              "independent-impl", "tolerance", "max relative difference <= 1e-12 at T in {64,256,1024} (4096 optional, O(T^2))"),
        check(["iid_gaussian", "delayed_noise"], "kernel",
              "dtaidistance==2.5.1 dtw.distance(x, y, use_c=False) in the audit comparison venv (no tslearn import; squared cost + sqrt convention)",
              "external-pkg", "tolerance", "relative difference <= 1e-12 (a seeded T=80 probe gave identical values)"),
        check(["delayed_noise", "iid_gaussian"], "kernel",
              "Sakoe-Chiba 1978 symmetric form from scratch (|a-b| cost, diagonal weight 2, divide by 2T)", "independent-impl", "qualitative",
              "Documents the convention gap: pyspi value is NOT equal to the 1978 normalised form; report the ratio and rank correlation across pairs (expected high rank agreement, different scale)."),
        check(["delayed_noise", "iid_gaussian", "narrowband_f0-0.25"], "kernel",
              "analytic bounds: dtw(x,x)=0; dtw(x,y) <= ||x-y||_2 (identity path admissible); dtw >= sqrt(sum_i min_j (x_i-y_j)^2)",
              "analytic", "optimality",
              "all bounds hold exactly; on delayed_noise dtw(x0, x_k) << ||x0-x_k|| for k=1,3,5 because warping absorbs the delay"),
        check(["scaled_offset", "bivariate_gaussian"], "pipeline",
              "pyspi output on bivariate_gaussian (same draw; z-scoring removes per-process scale and offset)", "analytic", "tolerance",
              "A(scaled_offset) == A(bivariate_gaussian) to <= 1e-10 relative"),
        check(["trending"], "pipeline-detrend", "from-scratch DP on scipy.signal.detrend then zscore(ddof=1) rows", "independent-impl", "tolerance",
              "matches reference to 1e-12; values differ from the non-detrended pipeline (trend dominates DTW)"),
        DIR_CHECK("DTW DP"),
    ],
)
records.append(rec(uid, c))

uid = "distance.dtw.constraint-sakoe_chiba"
c = dict(dtw_common)
c.update(
    metric_name_standard="Dynamic time warping distance with Sakoe-Chiba band (radius 1 sample)",
    implemented_as=("As dtw, but the DP is restricted to |i-j| <= 1 (tslearn default radius 1 because pyspi passes no sakoe_chiba_radius). "
                    "The admissible band is 3T-2 cells, i.e. 4.6% of the grid at T=64, 0.29% at T=1024, 0.073% at T=4096 (probe)."),
    implementation_trace=COMMON_PRE + DTW_TRACE + SC_TRACE,
    deviation_from_documented=("The band width is undocumented; it is fixed at 1 sample for every T (tslearn default, _masks.py:339-341). "
                               + NAMING_DEV.format(base="dtw")),
    deviation_from_canonical=(DTW_DEV_CANON_BASE + " Band: Sakoe-Chiba define the adjustment window r as a tunable parameter (the canonical practice "
                              "is a width proportional to series length); a fixed r=1 allows at most a one-sample local shift, so the measure stays close "
                              "to the lock-step Euclidean distance. Probe (T=50): dtw_SC 8.06 vs unconstrained 6.57 vs Euclidean 10.13."),
    already_documented="no",
    new_finding_candidates=[
        ("Candidate (parameterisation): the 'sakoe_chiba' SPI is DTW with a 1-sample band at all T (pyspi distance.py:177 passes only "
         "global_constraint; tslearn _masks.py:339-341 sets radius=1). Delays > 1 sample cannot be absorbed: hypothesis that on delayed_noise "
         "dtw_SC(x0,x1) is small while dtw_SC(x0,x3) and dtw_SC(x0,x5) are near the Euclidean distance."),
        PARSE_CAND,
    ],
    proposed_checks=[
        check(["iid_gaussian", "delayed_noise", "narrowband_f0-0.25"], "kernel",
              "from-scratch numpy DP restricted to |i-j| <= 1 (independent band construction)", "independent-impl", "tolerance",
              "relative difference <= 1e-12 at T in {64,256,1024,4096} (band DP is O(T))"),
        check(["iid_gaussian", "delayed_noise"], "kernel",
              "dtaidistance==2.5.1 dtw.distance(x, y, window=2, use_c=False) (dtaidistance window w admits |i-j| < w; a seeded probe matched tslearn radius 1)",
              "external-pkg", "tolerance", "relative difference <= 1e-12"),
        check(["delayed_noise", "iid_gaussian"], "kernel",
              "analytic ordering: dtw_unconstrained <= dtw_SC <= ||x-y||_2 (nested admissible sets)", "analytic", "optimality",
              "ordering holds for every pair"),
        check(["delayed_noise"], "pipeline", "known delays 1, 3, 5 samples (MANIFEST truth.delay)", "analytic", "qualitative",
              "dtw_SC(x0,x1) is much smaller than dtw_SC(x0,x3) and dtw_SC(x0,x5); the latter two are close to the Euclidean distance, confirming the 1-sample band"),
        DIR_CHECK("band-1 DTW DP"),
    ],
)
records.append(rec(uid, c))

uid = "distance.dtw.constraint-itakura"
c = dict(dtw_common)
c.update(
    metric_name_standard="Dynamic time warping distance with Itakura parallelogram (max slope 2)",
    implemented_as=("As dtw, but the DP is restricted to tslearn's Itakura parallelogram with max_slope 2.0 (default, pyspi passes none): "
                    "cells whose path from (0,0) and to (T-1,T-1) can keep slopes within [1/2, 2]; bounds rounded to 2 decimals then ceil/floor. "
                    "Covers ~1/3 of the grid for every T (probe: 0.3335 at T=64, 0.33333 at T=4096); the corner rows/columns admit only the corner cell."),
    implementation_trace=COMMON_PRE + DTW_TRACE + IT_TRACE,
    deviation_from_documented="The slope parameter (2) is undocumented; otherwise none.",
    deviation_from_canonical=(DTW_DEV_CANON_BASE + " Constraint: Itakura 1975 imposes LOCAL slope constraints (no two consecutive horizontal moves, "
                              "slopes 1/2..2), whose reachable region is the parallelogram; tslearn imposes only the GLOBAL parallelogram with ordinary "
                              "symmetric1 local moves, so arbitrarily long horizontal/vertical runs are allowed inside the region (common 'Itakura window' "
                              "practice, e.g. R dtw itakuraWindow)."),
    already_documented="no",
    new_finding_candidates=[
        ("Candidate (minor, boundary rounding): tslearn rounds the parallelogram bounds to 2 decimals before ceil/floor (_masks.py:101-116); at "
         "large T a cell whose exact bound is within 0.005 of an integer can be admitted or excluded differently from an exact-arithmetic mask. "
         "To be measured by cell-by-cell comparison with an exact rational mask at T in {64,256,1024,4096}."),
        PARSE_CAND,
    ],
    proposed_checks=[
        check(["iid_gaussian", "delayed_noise", "narrowband_f0-0.25"], "kernel",
              "from-scratch exact-rational parallelogram mask {(i,j): j/2 <= i <= 2j and (T-1-j)/2 <= T-1-i <= 2(T-1-j)} plus numpy DP",
              "independent-impl", "tolerance",
              "masks agree cell-by-cell (report any boundary differences); DTW values agree to <= 1e-12 relative where masks agree"),
        check(["iid_gaussian", "delayed_noise"], "kernel",
              "analytic ordering: dtw_unconstrained <= dtw_itakura <= ||x-y||_2", "analytic", "optimality", "ordering holds for every pair"),
        check(["iid_gaussian"], "kernel", "Itakura 1975 local-slope DP (no two consecutive horizontal/vertical moves) from scratch",
              "independent-impl", "qualitative",
              "documents the global-vs-local constraint gap: pyspi value <= local-slope-constrained value; report differences"),
        DIR_CHECK("parallelogram-masked DTW DP"),
    ],
)
records.append(rec(uid, c))

# ---------------- LCSS ----------------
LCSS_DOC = ("supplement §1.2.8, p.7 (pack lines 302-311) and GitBook 'Longest Common Subsequence': \"measuring the similarity between continuous "
            "subsections of time series... subject to distance thresholds and alignment constraints. We use the default threshold from the tslearn "
            "package (eps = 1), and include the three global constraints\"; keywords undirected, nonlinear, unsigned.")
LCSS_REF = ("Vlachos M, Kollios G, Gunopulos D 2002, Proc. 18th ICDE pp. 673-684, definitions of LCSS_{delta,eps} and "
            "similarity S1 = LCSS/min(n,m) (Sec. 2; definition numbering not re-checked against the PDF; the paper states the eps test per coordinate for 2-D trajectories)")
LCSS_DEF = ("LCSS(A,B) = 0 if A or B empty; 1+LCSS(Head(A),Head(B)) if |a_n-b_m| < eps and |n-m| <= delta; else max(LCSS(Head(A),B), "
            "LCSS(A,Head(B))); similarity S1 = LCSS_{delta,eps}(A,B)/min(n,m)")
LCSS_DEV_CANON = ("Match test uses <= eps (dtw_variants.py:2260) instead of the strict < eps of Vlachos et al. (only matters on exact ties; probe: "
                  "lcss([0,0],[1,1]) = 1.0 vs 0.0 under the strict rule). Normalisation by min(n,m) matches S1. eps = 1 is absolute, applied after "
                  "z-scoring, i.e. one standard deviation.")
MASK_CAND = ("Candidate NEW finding (tslearn 0.9.0 regression, not in KNOWN_ISSUES): the numpy/numba LCSS path ignores the global constraint. "
             "dtw_variants.py:2259 tests 'numpy.isfinite(mask[i-1, j-1])' but the mask from _masks.compute_mask is boolean, and np.isfinite(False) "
             "is True, so every cell is evaluated. In tslearn v0.5.2 (pyspi originally required tslearn>=0.5.2; pyproject.toml now pins >=0.9,<0.10 "
             "since commit a2c3300) masks were float 0/inf, so the same test worked. Probe: delayed series T=60 -> tslearn lcss = 0.9167 for None, "
             "itakura and sakoe_chiba alike, while a from-scratch masked LCSS gives 0.9167 / 0.0 / 0.70 and tslearn's torch backend (which uses "
             "'if mask[...]', line 2306) gives the masked values (T=64: itakura 0.797 torch vs 0.8125 numpy; sakoe_chiba 0.766 torch vs 0.8125 numpy). "
             "pyspi end-to-end (4x128): lcss, lcss_constraint-itakura and lcss_constraint-sakoe-chiba matrices are bit-identical; the regression "
             "snapshot files (tests/regression/goldens small/full) also hold identical matrices for the three identifiers (a snapshot observation only).")
SAT_CAND = ("Candidate (low dynamic range): with eps = 1 on z-scored data the unconstrained score saturates near 0.8 for unrelated series. Probe: "
            "independent N(0,1) T=64/256/1024 -> 0.797/0.805/0.809; x vs -x -> 0.828/0.797/0.807; x vs x -> 1.0. Hypothesis: lcss cannot "
            "distinguish independence from perfect anti-correlation and spans roughly [0.8, 1] in practice (snapshot small/full matrices span 0.84-0.97).")
lcss_common = dict(
    metric_name_standard="Longest common subsequence similarity (LCSS, eps-matching, normalised by the shorter length)",
    canonical_ref=LCSS_REF,
    canonical_definition=LCSS_DEF,
    documented_definition=LCSS_DOC,
    delegate_lib="tslearn==0.9.0 tslearn.metrics.lcss (dtw_variants.py:2383) -> numba _njit_lcss",
    units_and_range=("Dimensionless similarity in [0, 1] (count of matched pairs / min(n, m)); 1 = every point matched; higher = more similar "
                     "(a similarity, despite the 'distance' module); symmetric in its arguments; quantised in steps of 1/T."),
    direction_convention="Undirected: A[i,j] = A[j,i] = lcss(z_min(i,j), z_max(i,j)) via Undirected.multivariate mirroring; diagonal NaN.",
    symmetry_expected="sym",
    already_documented="no",
)

uid = "distance.lcss.constraint-None"
c = dict(lcss_common)
c.update(
    implemented_as=("z-score rows (ddof=1); integer LCSS DP over the full grid with match rule |x_i - y_j| <= 1 (no time window, delta = infinity); "
                    "score = LCSS length / min(T, T) = LCSS / T."),
    implementation_trace=COMMON_PRE + LCSS_TRACE,
    deviation_from_documented="none (eps = 1 as documented; no constraint).",
    deviation_from_canonical=LCSS_DEV_CANON + " Unconstrained means delta = infinity (Vlachos et al. use a finite matching window delta).",
    new_finding_candidates=[SAT_CAND, PARSE_CAND],
)
records.append(rec(uid, c))

for gc, name, extra_dev, extra_impl in [
    ("sakoe_chiba", "Sakoe-Chiba band (radius 1)", "",
     "Intended: matches allowed only for |i-j| <= 1 (tslearn default radius 1), which equals Vlachos delta = 1."),
    ("itakura", "Itakura parallelogram (max slope 2)", "",
     "Intended: matches allowed only inside tslearn's parallelogram (slope 2)."),
]:
    uid = f"distance.lcss.constraint-{gc}"
    c = dict(lcss_common)
    cands = [MASK_CAND, SAT_CAND]
    if gc == "itakura":
        cands.append("Candidate (intended-behaviour degeneracy, relevant if the mask is ever honoured): with the Itakura mask the last row/column admit "
                     "only the corner cell (probe T=128: last row allowed columns [127]), and masked cells stay 0 in the LCSS DP, so the corner value is "
                     "0 unless the final samples match within eps. Probe with a from-scratch masked DP on 30 independent N(0,1) pairs, T=128: 50% of "
                     "pairs score exactly 0, the rest average 0.786 (matches P(|x_T - y_T| <= 1) ~ 0.52). The tslearn torch backend reproduces the "
                     "masked value on the probe pair.")
    cands.append(PARSE_CAND)
    c.update(
        metric_name_standard=f"Longest common subsequence similarity with {name}",
        implemented_as=(f"{extra_impl} Actual (numpy backend, tslearn 0.9.0): the boolean mask is computed and passed but njit_lcss_accumulated_matrix "
                        "tests numpy.isfinite(mask) which is True for every boolean entry, so the full grid is used and the value equals unconstrained lcss "
                        "exactly. Score = LCSS / T with match rule |x_i - y_j| <= 1 on z-scored rows."),
        implementation_trace=COMMON_PRE + LCSS_TRACE + (SC_TRACE if gc == "sakoe_chiba" else IT_TRACE),
        deviation_from_documented=(f"Documented as LCSS with the {gc} global constraint; the constraint has no effect (output identical to lcss). "
                                   + (NAMING_DEV.format(base="lcss") if gc == "sakoe_chiba" else "")),
        deviation_from_canonical=(LCSS_DEV_CANON + " The time-window restriction (delta / parallelogram) that defines the constrained variant is not applied."),
        new_finding_candidates=cands,
        proposed_checks=[
            check(["delayed_noise", "iid_gaussian", "narrowband_f0-0.25"], "kernel",
                  f"from-scratch numpy LCSS DP with an independently built {gc} mask (masked cells hold 0), eps = 1, <= rule, divided by min(n,m)",
                  "independent-impl", "exact",
                  "pyspi value DIFFERS from the masked reference and EQUALS the unconstrained reference exactly on most pairs (confirms the ignored-mask candidate)"),
            check(["delayed_noise", "iid_gaussian"], "pipeline",
                  "pyspi lcss (unconstrained) matrix on the same data", "same-lineage", "exact",
                  f"lcss_constraint-{gc.replace('_','-')} matrix is bit-identical to the lcss matrix at every T"),
            check(["delayed_noise"], "kernel",
                  "tslearn.metrics.lcss with torch tensors and be='pytorch' (same library, mask-honouring branch dtw_variants.py:2306)",
                  "same-lineage", "exact", "torch-backend value equals the from-scratch masked reference, numpy-backend value does not"),
            DIR_CHECK(f"{gc}-masked LCSS DP"),
        ],
    )
    records.append(rec(uid, c))

# proposed checks for lcss None (after loop to keep order)
records[3]["correctness"]["proposed_checks"] = [
    check(["iid_gaussian", "delayed_noise", "narrowband_f0-0.25", "logistic_maps"], "kernel",
          "from-scratch numpy LCSS DP (Vlachos Def. 2 with delta = infinity, eps = 1, <= rule) divided by min(n,m)",
          "independent-impl", "exact", "identical rational values (integer count / T) at T in {64,256,1024}"),
    check(["iid_gaussian"], "kernel", "same from-scratch DP with strict < eps (Vlachos et al. literal rule)", "independent-impl", "exact",
          "identical to the <= variant for continuous data (ties have probability zero); documents the tie convention only"),
    check(["iid_gaussian", "bivariate_gaussian", "delayed_noise"], "pipeline",
          "analytic: lcss(x,x) = 1; null distribution from iid_gaussian pairs", "analytic", "statistical",
          "iid pairs give ~0.8 (saturation candidate); bivariate_gaussian rho=0.8 pair scores above rho=0.3 pair only modestly; quantify the dynamic range"),
    check(["scaled_offset", "bivariate_gaussian"], "pipeline", "pyspi output on bivariate_gaussian (z-scoring invariance)", "analytic", "exact",
          "A(scaled_offset) == A(bivariate_gaussian) unless a pair sits within 1e-12 of the eps boundary"),
    DIR_CHECK("LCSS DP"),
]

# ---------------- softdtw ----------------
uid = "distance.softdtw"
c = dict(
    metric_name_standard="Soft-DTW discrepancy (Cuturi-Blondel soft-min DTW value, gamma = 1, squared Euclidean cost); not the soft-DTW divergence",
    canonical_ref="Cuturi M, Blondel M 2017, Soft-DTW: a Differentiable Loss Function for Time-Series, ICML (PMLR 70:894-903), eq. (1)-(2) and Algorithm 1",
    canonical_definition=("dtw_gamma(x,y) = min^gamma { <A, Delta(x,y)> : A in A_{n,m} }, min^gamma(a_1..a_k) = -gamma log sum_i exp(-a_i/gamma), "
                          "Delta_ij = ||x_i - y_j||^2; computed by r_ij = Delta_ij + min^gamma(r_{i-1,j-1}, r_{i-1,j}, r_{i,j-1}), r_00 = 0, borders +inf"),
    documented_definition=("supplement §1.2.9, p.7 (pack lines 312-320) and GitBook 'Soft Dynamic Time Warping': \"uses a smoothed formulation of DTW "
                           "to optimize the minimal-cost alignment as a differentiable loss function... computed via the tslearn package (with the default "
                           "hyperparameter, gamma = 1), and includes the same global constraints as DTW\" (identifiers softdtw, softdtw_constraint-itakura, "
                           "softdtw_constraint-sakoe_chiba)."),
    delegate_lib="tslearn==0.9.0 tslearn.metrics.soft_dtw (softdtw_variants.py:530) -> SoftDTW/_njit_soft_dtw; cost matrix via scikit-learn==1.9.1 euclidean_distances",
    implemented_as=("z-score rows (ddof=1); D_ij = (sklearn euclidean_distances(x, y))^2 = clamp(x_i^2 + y_j^2 - 2 x_i y_j, 0); soft-DTW recursion "
                    "with gamma = 1 (numba fastmath softmin with max-shift); value R[T,T]. No global constraint for any of the three identifiers."),
    implementation_trace=COMMON_PRE + SOFT_TRACE,
    deviation_from_documented=("The documented Sakoe-Chiba and Itakura variants are not implemented: SoftDynamicTimeWarping.bivariate "
                               "(distance.py:205-208) never passes the constraint and tslearn.soft_dtw has no constraint argument, so the three identifiers "
                               "are identical (probe: bit-identical 4x128 matrices). gamma = 1 matches the documentation. "
                               "Class name 'Dynamic time warping' duplicates the DTW name (distance.py:202, cosmetic). "
                               + NAMING_DEV.format(base="softdtw")),
    deviation_from_canonical=("none for the value itself: matches Cuturi-Blondel Algorithm 1 with squared Euclidean cost and gamma = 1 (probe T=40: "
                              "tslearn -2.205017147170598 vs from-scratch -2.2050171471705955). The cost matrix uses the dot-product expansion "
                              "(last-bit cancellation; probe: max abs cell error 1.1e-14 on z-scored data, 2.9e-8 with offset 1e4) and softmin uses "
                              "numba fastmath."),
    units_and_range=("Real-valued, NOT non-negative despite the 'unsigned'/'distance' labels: includes an entropic term down to about "
                     "-gamma*log(number of alignment paths); soft_dtw(x,x) != 0 (probe T=40: -31.28; T=1024: -717.3); scale grows with T; "
                     "symmetric in its arguments. Units: squared data units (z-scored -> dimensionless)."),
    direction_convention="Undirected: A[i,j] = A[j,i] = soft_dtw(z_min(i,j), z_max(i,j)) via Undirected.multivariate mirroring; diagonal NaN (probe: raw soft_dtw(z0,z1) - soft_dtw(z1,z0) = 0.0).",
    symmetry_expected="sym",
    already_documented="tests/README.md bug 3 (SoftDynamicTimeWarping ignores global_constraint; locked in tests/unit/test_known_bugs.py:111-131)",
    new_finding_candidates=[
        ("Candidate (interpretation): pyspi reports the soft-DTW VALUE, not the soft-DTW divergence D(x,y) = sdtw(x,y) - (sdtw(x,x)+sdtw(y,y))/2 "
         "(Blondel, Mensch, Vert 2021, AISTATS; tslearn offers cdist_soft_dtw_normalized). Values are mostly negative and dominated by a "
         "length-dependent entropic term: probe (z-scored, seeded) T=64: sdtw(x,x) = -41.4, independent -9.07, x vs -x +2.84; T=1024: -717.3, "
         "-189.1, -188.4. So at T=1024 it does not separate independent from anti-correlated pairs; snapshot small/full matrices contain both "
         "signs (min -16.96, max 2.31 for small)."),
        ("Candidate (numerical, minor): the squared-Euclidean cost comes from sklearn's |x|^2+|y|^2-2xy expansion followed by sqrt and re-squaring, "
         "losing relative precision on near-equal samples (probe: 2.9e-6 relative error on diagonal cells for y = x + 1e-3 noise; 2.9e-8 absolute "
         "with a 1e4 offset when normalise=False). Expected impact on the final value < 1e-10 relative for z-scored data."),
        PARSE_CAND,
    ],
    proposed_checks=[
        check(["iid_gaussian", "delayed_noise", "narrowband_f0-0.25", "logistic_maps"], "kernel",
              "from-scratch numpy soft-DTW (Cuturi-Blondel Algorithm 1, direct (x_i-y_j)^2 cost, scipy.special.logsumexp softmin, gamma = 1)",
              "independent-impl", "tolerance", "relative difference <= 1e-10 at T in {64,256,1024} (4096 with an anti-diagonal vectorised reference)"),
        check(["delayed_noise", "iid_gaussian"], "pipeline", "pyspi softdtw matrix", "same-lineage", "exact",
              "softdtw_constraint-itakura and softdtw_constraint-sakoe-chiba matrices are bit-identical to softdtw (known bug 3, re-confirmed)"),
        check(["iid_gaussian"], "kernel", "from-scratch soft-DTW with gamma -> 1e-3 vs from-scratch hard DTW squared", "analytic", "tolerance",
              "reference satisfies dtw^2 - gamma*log(number of alignment paths) <= sdtw <= dtw^2 and converges to dtw^2 as gamma -> 0 (sanity of the reference)"),
        check(["iid_gaussian", "bivariate_gaussian", "delayed_noise"], "pipeline",
              "analytic properties: sdtw(x,x) != 0 and typically < sdtw(x,y); divergence D(x,y) >= 0 computed from-scratch", "analytic", "qualitative",
              "pyspi values are negative for most pairs and the soft-DTW divergence ranks pairs differently from the raw value; document dynamic range vs T"),
        DIR_CHECK("soft-DTW recursion"),
    ],
)
records.append(rec(uid, c))

for r in records:
    p = OUT / f"{r['unit_id']}.yaml"
    p.write_text(yaml.safe_dump(r, sort_keys=False, width=140, allow_unicode=True))
    print("wrote", p)
