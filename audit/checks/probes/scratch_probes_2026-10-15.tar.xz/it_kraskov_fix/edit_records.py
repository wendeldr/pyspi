import yaml
R='/media/dan/Data/git/pyspi/audit/records/'
P='scratchpad it_kraskov_fix/'
def load(u): return yaml.safe_load(open(R+u+'.yaml'))
def save(u,d): open(R+u+'.yaml','w').write(yaml.safe_dump(d,sort_keys=False,allow_unicode=True,width=200))
TE=['infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4','infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4',
    'infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1','infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1','infotheory.te.kraskov_k-1_kt-1_l-1_lt-1']
MIU=['infotheory.mi.kraskov','infotheory.mi.kraskov_DCE','infotheory.tlmi.kraskov','infotheory.tlmi.kraskov_DCE']
TRACE=("pyspi/statistics/infotheory.py:60-82 and :369-374, the two copy paths, which differ. Pickle: JIDTBase.__getstate__ (:60-69) drops _calc and _entropy_calc; "
 "TransferEntropy.__setstate__ (:369-374) rebuilds _calc with self._getcalc('TransferEntropy'), which applies only _setup (:84-93: k = prop_k, BIAS_CORRECTION, NOISE_SEED 42), so the AUTO_EMBED_METHOD, "
 "k_SEARCH_MAX, TAU_SEARCH_MAX, k_HISTORY, k_TAU, l_HISTORY and l_TAU properties set in __init__ (:344-367) are lost but k and NOISE_SEED are kept. Deepcopy: JIDTBase.__deepcopy__ (:77-82) builds "
 "type(self)() and then sets every attribute to copy.deepcopy of the original's; copy.deepcopy of the JPype calculator returns a new Java object with JIDT constructor defaults and none of the "
 "properties pyspi set, so every pyspi property is lost: NOISE_SEED 'NONE' (jitter unseeded), k = JIDT default 4 whatever prop_k is, AUTO_EMBED_METHOD 'NONE', k_HISTORY 1 (probe "+P+"p_te_copy.py "
 "reads these back). _setup is not involved on this path. CalculatorFrame.init_from_list deep-copies the base Calculator (pyspi/calculator.py:556-563, copy.deepcopy at :559). See new_finding_candidates.")
COPY_TE=("CANDIDATE (new, confirmed by probe): copying a TransferEntropy SPI silently changes its configuration while keeping the identifier, and pickle and deepcopy lose different things. "
 "Pickle (TransferEntropy.__setstate__, infotheory.py:369-374) rebuilds the calculator through _getcalc/_setup, keeping k = prop_k and NOISE_SEED 42 but dropping AUTO_EMBED_METHOD and k_HISTORY/l_HISTORY "
 "(probe p9: k_HISTORY '1', AUTO_EMBED_METHOD 'NONE'). Deepcopy (JIDTBase.__deepcopy__, :77-82) deep-copies the JPype object, which yields a fresh Java calculator with JIDT constructor defaults: in addition "
 "to the embedding it loses NOISE_SEED ('NONE', so the 1e-8 jitter is unseeded) and prop_k (JIDT default 4; harmless for these NN-4 units, not for NN-k with k != 4). CalculatorFrame.init_from_list "
 "deep-copies the base Calculator (calculator.py:556-563, deepcopy at :559), so a CalculatorFrame computes unseeded fixed k=1 TE under these identifiers. Probe p10 (repeated in "+P+"p_te_copy.py), "
 "var2_bivariate T=256, A[0,1]: te_kraskov_NN-4_k-max-10_tau-max-4 Calculator 0.060599 vs CalculatorFrame/deepcopy/pickle 0.133643 (= te_k1 0.133643); te_kraskov_NN-4_DCE_k-2_kt-1_l-1_lt-1 Calculator "
 "0.159244 vs deepcopy/pickle 0.134372. On tied input the deepcopy is also not reproducible: logistic_maps T=256 pair 1->0 te_auto original 0.101410 on every run, pickle 0.115063, three deep copies "
 "0.114476/0.109197/0.111046 ("+P+"p_tied_dce.py). MI, TLMI and k=l=1 TE keep their values under pickle; under deepcopy they keep them only on tie-free data, because the lost NOISE_SEED then does not "
 "move any neighbour count (var2_bivariate diff 0.0). Cross-family: the same deepcopy path resets KERNEL_WIDTH to 0.25 for kernel SPIs (probe "+P+"r4_deepcopy.py: je_kernel_W-0.5 3.982283 -> 3.748712), "
 "for it_kernel to record.")
def copy_k1(dce):
    vals = "0.078301 on every run, three deep copies 0.083693/0.079346/0.080654 (probe "+P+"p_tied_dce.py)" if dce else \
           "0.115063 on every run, three deep copies 0.113357/0.111490/0.114040 (probe "+P+"r6_tied.py; the review's run of the same probe gave 0.116042/0.111294/0.106424)"
    return ("CANDIDATE (scope note): under pickle and deepcopy this unit keeps its embedding only because the copy's JIDT defaults are k_HISTORY = l_HISTORY = 1 (probe p10: identical in Calculator and "
     "CalculatorFrame on var2_bivariate). Deepcopy, the path CalculatorFrame uses (calculator.py:559), still loses NOISE_SEED (copy reads 'NONE') and prop_k, so on tied input the copied unit runs with "
     "unseeded jitter and is not reproducible: logistic_maps T=256 pair 1->0 original "+vals+". Pickle keeps NOISE_SEED and reproduces the original. On tie-free data the deepcopy value is unchanged "
     "(var2_bivariate diff 0.0). See the copy candidate in infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4.")
TIED={'infotheory.mi.kraskov':"mi 0.226622 on every run, three deep copies 0.230475/0.236390/0.237750 (probe "+P+"r6_tied.py; the review's run gave 0.234155/0.233200/0.231582)",
 'infotheory.tlmi.kraskov':"tlmi 0.278902 on every run, three deep copies 0.270293/0.274896/0.279048 (probe "+P+"r6_tied.py; the review's run gave 0.278590/0.272750/0.280136)",
 'infotheory.mi.kraskov_DCE':"mi_DCE 0.603752 on every run, three deep copies 0.592057/0.606156/0.603638 (probe "+P+"p_tied_dce.py)",
 'infotheory.tlmi.kraskov_DCE':"tlmi_DCE 0.650270 on every run, three deep copies 0.648670/0.645450/0.650404 (probe "+P+"p_tied_dce.py)"}
def copy_mi(u):
    return ("CANDIDATE (new, confirmed by probe): a deep copy of this SPI loses NOISE_SEED and prop_k. JIDTBase.__deepcopy__ (infotheory.py:77-82) deep-copies the JPype calculator, which yields a fresh Java "
     "object with JIDT constructor defaults (NOISE_SEED 'NONE', k 4). CalculatorFrame.init_from_list deep-copies the base Calculator (calculator.py:556-563, deepcopy at :559), so CalculatorFrame runs this "
     "SPI with unseeded jitter. On tie-free data the value is unchanged (var2_bivariate T=256 diff 0.0, probe "+P+"p_te_copy.py). On tied input it is not reproducible: logistic_maps T=256 pair 1->0 "
     "(channel 1 has 4 distinct values) "+TIED[u]+". The k reset is harmless at NN-4 but changes any NN-k with k != 4: mi_kraskov_NN-6 on bivariate_gaussian T=256 (0,1) 0.039668 -> 0.028352 after deepcopy "
     "(probe "+P+"r4_deepcopy.py). Pickle (JIDTBase.__setstate__ via _getcalc/_setup) keeps NOISE_SEED and prop_k and reproduces the original.")
changed=[]
for u in TE:
    d=load(u); c=d['correctness']
    tr=c['implementation_trace']; idx=[i for i,s in enumerate(tr) if s.startswith('pyspi/statistics/infotheory.py:71-82 and :369-374')]
    assert len(idx)==1,u; tr[idx[0]]=TRACE
    nf=c['new_finding_candidates']
    ic=[i for i,s in enumerate(nf) if s.startswith('CANDIDATE (new, confirmed by probe): copying a TransferEntropy SPI')]
    ik=[i for i,s in enumerate(nf) if s.startswith('CANDIDATE (scope note): fixed-embedding TE units keep')]
    if ic: assert len(ic)==1; nf[ic[0]]=COPY_TE
    elif ik: assert len(ik)==1; nf[ik[0]]=copy_k1('DCE' in u)
    else: raise SystemExit('no copy cand '+u)
    for pc in c['proposed_checks']:
        if 'CalculatorFrame (deepcopy)' in str(pc.get('reference','')):
            pc['reference']='CalculatorFrame (deepcopy, calculator.py:559) vs Calculator on the same data and config, plus getProperty read-back of NOISE_SEED, k, k_HISTORY and AUTO_EMBED_METHOD on the copied calculator'
            if 'auto' in u: pc['expected_outcome']="differs: CalculatorFrame returns the fixed k=1 TE (probe p10 A[0,1] 0.133643 vs Calculator 0.060599) and its calculator reads NOISE_SEED 'NONE', AUTO_EMBED_METHOD 'NONE'; documents the copy bug"
            else: pc['expected_outcome']="differs: CalculatorFrame returns the k=1 DCE TE (probe p10 A[0,1] 0.134372 vs Calculator 0.159244) and its calculator reads NOISE_SEED 'NONE', k_HISTORY '1'; documents the copy bug"
    save(u,d); changed.append(u)
for u in MIU:
    d=load(u); c=d['correctness']; c['new_finding_candidates'].append(copy_mi(u)); 
    if u.startswith('infotheory.mi.'):
        c['direction_convention']=("Undirected: A[i, j] = A[j, i]. Directed.multivariate (base.py:88-94, called via super) computes bivariate(i, j) for every ordered pair i != j, lower triangle included; "
          "Undirected.multivariate (base.py:134-137) then overwrites the lower triangle with the transpose, so A[i, j] = A[j, i] = bivariate(min(i,j), max(i,j)) and the bivariate(max, min) result is computed and discarded. "
          "KSG1 itself is symmetric (probe p2: bivariate(0,1) = bivariate(1,0) = 0.033251782902)"+("; the DCE window matrix is symmetric (infotheory.py:208-211)" if 'DCE' in u else ""))
        tr=c['implementation_trace']
        for i,s in enumerate(tr):
            if s.startswith('pyspi/base.py:132-138 Undirected.multivariate'):
                tr[i]=("pyspi/base.py:132-138 Undirected.multivariate: A = super().multivariate(data) (all ordered pairs i != j computed), li = tril_indices(-1); A[li] = A.T[li] "
                       "(the upper triangle bivariate(i<j) is kept and mirrored; the lower-triangle bivariate(i>j) values are computed and overwritten)")
        if 'The matrix is the upper triangle bivariate(i<j) mirrored.' in c['implemented_as']:
            c['implemented_as']=c['implemented_as'].replace('The matrix is the upper triangle bivariate(i<j) mirrored.',
              'bivariate runs for every ordered pair i != j; the upper triangle bivariate(i<j) is kept and mirrored, the lower-triangle results are discarded.')
        c['new_finding_candidates'].append("CANDIDATE (efficiency, correctness-neutral): every unordered pair is estimated twice. Directed.multivariate (base.py:88-94) runs bivariate for all P(P−1) ordered pairs and "
          "Undirected.multivariate (base.py:134-137) discards the lower triangle, so half of the KSG runs are thrown away; KSG1 MI is symmetric (probe p2), so computing i<j only would give the same matrix at half the cost.")
    save(u,d); changed.append(u)
# provenance
PROV_OLD="the property arrives in master commit 2a18cd0 (2024-04-16) and the jar entries are dated 2024-04-21 (last master commit before that: a9b6b3e, 2024-04-20)."
PROV_NEW=("the jar contains EntropyCalculatorMultiVariateCommon.class (entry dated 2024-04-21 06:42, like all 337 entries, unzip -l). That content is the primary evidence: NOISE_SEED for MI/CMI arrives in master "
 "commit 2a18cd0 ('Adding property to allow used to set random seed for noise addition to data in MI, CMI and wrapped estimators', closes issue #99), EntropyCalculatorMultiVariateCommon in 3d1f3fe "
 "('Gathering common functionality of EntropyMultiVariate estimators into a Common class'), and NOISE_SEED for the entropy estimators in a9b6b3e. Commit dates come from the GitHub REST API "
 "(https://api.github.com/repos/jlizier/jidt/commits/<sha>, commit.author.date = committer date): 2a18cd0 2024-04-16T04:08:04Z, 3d1f3fe 2024-04-20T07:57:38Z, a9b6b3e 2024-04-20T08:52:10Z; the master "
 "listing for 2024-04-15 to 2024-05-31 contains only these three commits, so a9b6b3e is the last master commit before the jar's entry date. The commit HTML pages show hashes and messages but not dates.")
for u in ['infotheory.est.ksg1','infotheory.mi.kraskov']:
    d=load(u); nf=d['correctness']['new_finding_candidates']; n=0
    for i,s in enumerate(nf):
        if PROV_OLD in s: nf[i]=s.replace(PROV_OLD,PROV_NEW); n+=1
    assert n==1,u
    if u=='infotheory.est.ksg1':
        tr=d['correctness']['implementation_trace']
        for i,s in enumerate(tr):
            if s.startswith("pyspi/lib/jidt/version-1.6.1.txt:8-10"):
                tr[i]=s+"; all 337 jar entries dated 2024-04-21 (unzip -l), including infodynamics/measures/continuous/EntropyCalculatorMultiVariateCommon.class"
    save(u,d)
    if u not in changed: changed.append(u)
print(changed)
