import sys, io, contextlib, copy, pickle, numpy as np, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
warnings.filterwarnings('ignore')
import jpype as jp
import pyspi.statistics.infotheory as it
from pyspi.data import Data
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()): return Data(x, dim_order='ps', normalise=True)
x = np.load(DD+'bivariate_gaussian_T256.npz')['x']
# what does copy.deepcopy do to a JIDT object?
K = jp.JPackage('infodynamics.measures.continuous.kernel')
c = K.EntropyCalculatorMultiVariateKernel(); c.setProperty('KERNEL_WIDTH','0.5'); c.setProperty('NOISE_SEED','42')
cc = copy.deepcopy(c)
print('deepcopy(JIDT obj): type', type(cc), 'same?', cc is c, 'KERNEL_WIDTH copy=%s orig=%s' % (cc.getProperty('KERNEL_WIDTH'), c.getProperty('KERNEL_WIDTH')), 'NOISE_SEED copy=%s' % cc.getProperty('NOISE_SEED'))
print('JObject has __reduce__/__deepcopy__/__copy__:', [a for a in ('__reduce__','__reduce_ex__','__deepcopy__','__copy__','__getstate__') if hasattr(c, a)])
# kraskov MI: two deepcopies vs original at full precision (seed lost => jitter unseeded?)
mi = it.MutualInfo(estimator='kraskov', prop_k=4); a = mi.bivariate(mk(x), i=0, j=1)
m1 = copy.deepcopy(mi); m2 = copy.deepcopy(mi)
b1 = m1.bivariate(mk(x), i=0, j=1); b2 = m2.bivariate(mk(x), i=0, j=1)
print('mi kraskov orig %.17g deepcopy1 %.17g deepcopy2 %.17g  d1=%.2e d2=%.2e d12=%.2e' % (a,b1,b2,a-b1,a-b2,b1-b2), 'copy NOISE_SEED', m1._calc.getProperty('NOISE_SEED'), 'copy k', m1._calc.getProperty('k'))
# prop_k != default survives deepcopy?
mi6 = it.MutualInfo(estimator='kraskov', prop_k=6); m6 = copy.deepcopy(mi6)
print('mi prop_k=6: id', m6.identifier, 'orig k', mi6._calc.getProperty('k'), 'deepcopy k', m6._calc.getProperty('k'), 'values orig %.6f copy %.6f' % (mi6.bivariate(mk(x),i=0,j=1), m6.bivariate(mk(x),i=0,j=1)))
# kernel SPIs: W-0.5 after deepcopy?
for name, s in [('je', it.JointEntropy(estimator='kernel')), ('ce', it.ConditionalEntropy(estimator='kernel')), ('si', it.StochasticInteraction(estimator='kernel')), ('mi_kernel', it.MutualInfo(estimator='kernel', kernel_width=0.25)), ('te_kernel', it.TransferEntropy(estimator='kernel', kernel_width=0.25))]:
    a = s.bivariate(mk(x), i=0, j=1); cpy = copy.deepcopy(s); b = cpy.bivariate(mk(x), i=0, j=1)
    pk = pickle.loads(pickle.dumps(s)); pv = pk.bivariate(mk(x), i=0, j=1)
    ec = cpy._entropy_calc; cal = getattr(cpy, '_calc', None)
    print('%-9s id=%s orig=%.6f deepcopy=%.6f pickle=%.6f | copy entropy KERNEL_WIDTH=%s calc KW=%s | W-0.25 direct=%.6f' % (name, s.identifier, a, b, pv, ec.getProperty('KERNEL_WIDTH'), None if cal is None else cal.getProperty('KERNEL_WIDTH'),
          type(s)(estimator='kernel', kernel_width=0.25).bivariate(mk(x),i=0,j=1) if name in ('je','ce','si') else float('nan')))
