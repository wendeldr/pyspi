import sys, io, contextlib, copy, pickle, numpy as np, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
warnings.filterwarnings('ignore')
import pyspi.statistics.infotheory as it
from pyspi.data import Data
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()): return Data(x, dim_order='ps', normalise=True)
x = np.load(DD+'var2_bivariate_T256.npz')['x']
P=['k','NOISE_SEED','k_HISTORY','k_TAU','l_HISTORY','l_TAU','AUTO_EMBED_METHOD','k_SEARCH_MAX','TAU_SEARCH_MAX','DYN_CORR_EXCL']
specs={'te_auto':dict(estimator='kraskov',prop_k=4,auto_embed_method='MAX_CORR_AIS',k_search_max=10,tau_search_max=4),
 'te_DCE_k2':dict(estimator='kraskov',prop_k=4,dyn_corr_excl='AUTO',k_history=2,k_tau=1,l_history=1,l_tau=1),
 'te_k1':dict(estimator='kraskov',prop_k=4,k_history=1,k_tau=1,l_history=1,l_tau=1)}
for n,kw in specs.items():
    s=it.TransferEntropy(**kw); d=copy.deepcopy(s); p=pickle.loads(pickle.dumps(s))
    for lab,o in [('orig',s),('deepcopy',d),('pickle',p)]:
        print(n,lab,o.identifier,{q:str(o._calc.getProperty(q)) for q in P}, 'A01=%.6f'%o.bivariate(mk(x),i=0,j=1))
for n,kw in [('mi',dict(estimator='kraskov',prop_k=4)),('tlmi',None)]:
    s=it.MutualInfo(estimator='kraskov',prop_k=4) if n=='mi' else it.TimeLaggedMutualInfo(estimator='kraskov',prop_k=4)
    p=pickle.loads(pickle.dumps(s)); d=copy.deepcopy(s)
    print(n,'orig seed',s._calc.getProperty('NOISE_SEED'),'pickle seed',p._calc.getProperty('NOISE_SEED'),'deepcopy seed',d._calc.getProperty('NOISE_SEED'), 'vals %.17g %.17g %.17g'%(s.bivariate(mk(x),i=0,j=1),p.bivariate(mk(x),i=0,j=1),d.bivariate(mk(x),i=0,j=1)))
