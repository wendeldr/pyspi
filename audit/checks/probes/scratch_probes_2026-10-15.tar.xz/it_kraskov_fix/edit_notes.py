p='/media/dan/Data/git/pyspi/audit/notes/it_kraskov.md'; t=open(p).read()
def rep(old,new):
    global t; assert t.count(old)==1, old[:80]; t=t.replace(old,new)
rep("The property arrived on JIDT master in commit 2a18cd0 (2024-04-16). The common class came in 3d1f3fe (2024-04-20). The jar entries are dated 2024-04-21, and the last master commit before that date is a9b6b3e (2024-04-20).",
"The jar's content is the main evidence. The property arrived on JIDT master in commit 2a18cd0, whose message reads \"Adding property to allow used to set random seed for noise addition to data in MI, CMI and wrapped estimators\". The common class came in 3d1f3fe (\"Gathering common functionality of EntropyMultiVariate estimators into a Common class\"), and a9b6b3e added `NOISE_SEED` to the entropy estimators. All 337 jar entries are dated 2024-04-21 (`unzip -l`). The commit HTML pages give hashes and messages but no dates. The dates come from the GitHub REST API (`https://api.github.com/repos/jlizier/jidt/commits/<sha>`, where author date = committer date): 2a18cd0 is 2024-04-16T04:08:04Z, 3d1f3fe is 2024-04-20T07:57:38Z and a9b6b3e is 2024-04-20T08:52:10Z. The master listing from 2024-04-15 to 2024-05-31 contains only these three commits, so a9b6b3e is the last master commit before the jar's entry date.")
rep("3. `Undirected.multivariate` computes the upper triangle as `bivariate(i<j)` and mirrors it (`base.py:84-94`, `132-138`).",
"3. `Undirected.multivariate` (`base.py:132-138`) first calls `Directed.multivariate` (`base.py:84-94`), which runs `bivariate` for every ordered pair i ≠ j, lower triangle included. It then overwrites the lower triangle with the transpose (`A[li] = A.T[li]`). So A[i,j] = A[j,i] = bivariate(min, max), and each unordered pair is estimated twice with one result thrown away.")
rep("- KSG1 is symmetric (p2: bivariate(0,1) = bivariate(1,0) exactly).",
"- KSG1 is symmetric (p2: bivariate(0,1) = bivariate(1,0) exactly).\n- Candidate (efficiency, correctness-neutral): because of the double computation above, half the KSG runs for MI and MI_DCE are discarded. Computing i<j only would give the same matrix at half the cost.")
s=t.index("## New candidate across the TE units: copies lose the embedding configuration"); e=t.index("## Open questions")
t=t[:s]+"""## New candidate across the family: copies lose the calculator configuration

pickle and `copy.deepcopy` both keep the identifier, but they lose different settings.

- **Pickle.** `JIDTBase.__getstate__` (`infotheory.py:60-69`) drops the JIDT objects. `TransferEntropy.__setstate__` (`:369-374`) rebuilds `_calc` with `_getcalc`, which applies only `_setup` (`:84-93`: k = prop_k, `BIAS_CORRECTION`, `NOISE_SEED` 42). The `AUTO_EMBED_METHOD`, `k_HISTORY` and `l_HISTORY` properties set in `__init__` (`:344-367`) are lost. k and the seed are kept. After a pickle round trip, `getProperty` returns `k_HISTORY = '1'` and `AUTO_EMBED_METHOD = 'NONE'` (p9).
- **Deepcopy.** `JIDTBase.__deepcopy__` (`:77-82`) builds `type(self)()` and then sets every attribute to a deep copy of the original's. A deep copy of a JPype JIDT object is a new Java object with JIDT constructor defaults, not a copy of pyspi's properties, and `_setup` is not run on this path. So the copy also loses `NOISE_SEED` (it reads `'NONE'`, and the 1e-8 jitter is unseeded) and `prop_k` (it reverts to JIDT's default k = 4). `getProperty` read-back on the copies is in `it_kraskov_fix/p_te_copy.py`.

`CalculatorFrame.init_from_list` deep-copies the base Calculator (`calculator.py:556-563`, `copy.deepcopy` at `:559`), so it takes the deepcopy path. Probe p10 and `p_te_copy.py` compare the paths on var2_bivariate at T=256:

| Identifier | Calculator A[0,1] | deepcopy / CalculatorFrame A[0,1] | pickle A[0,1] | Copy computes |
|---|---|---|---|---|
| `te_kraskov_NN-4_k-max-10_tau-max-4` | 0.060599 | 0.133643 | 0.133643 | the k=1 TE (0.133643) |
| `te_kraskov_NN-4_DCE_k-2_kt-1_l-1_lt-1` | 0.159244 | 0.134372 | 0.134372 | k=1 with DCE |

Consequences for the rest of the family:

- **Tie-free data.** MI, TLMI and the k=l=1 TE units give the same values in the copies (diff 0.0 on var2_bivariate). Their embeddings match only because the JIDT defaults happen to be k_HISTORY = l_HISTORY = 1, and the lost seed does not move any neighbour count.
- **Tied data.** The deep copies are unseeded, so their values vary from run to run. Pickle copies reproduce the original. On logistic_maps at T=256, pair 1->0 (channel 1 has 4 distinct values), the original gives the same value on every run, but three deep copies (`r6_tied.py`, `p_tied_dce.py`) give:

  | SPI | original | three deep copies |
  |---|---|---|
  | mi | 0.226622 | 0.230475 / 0.236390 / 0.237750 |
  | tlmi | 0.278902 | 0.270293 / 0.274896 / 0.279048 |
  | te_k1 | 0.115063 | 0.113357 / 0.111490 / 0.114040 |
  | mi_DCE | 0.603752 | 0.592057 / 0.606156 / 0.603638 |
  | tlmi_DCE | 0.650270 | 0.648670 / 0.645450 / 0.650404 |
  | te_DCE_k1 | 0.078301 | 0.083693 / 0.079346 / 0.080654 |
  | te_auto | 0.101410 (pickle 0.115063) | 0.114476 / 0.109197 / 0.111046 |

  The review's run of `r6_tied.py` gave different deep-copy values (for example mi 0.234155 / 0.233200 / 0.231582), as expected without a seed.
- **prop_k ≠ 4.** This does not affect the nine NN-4 units, but any `mi_kraskov_NN-k` with k ≠ 4 changes under deepcopy. `mi_kraskov_NN-6` on bivariate_gaussian at T=256, pair (0,1), goes from 0.039668 to 0.028352 (`r4_deepcopy.py`).

Outside this family, the same deepcopy path changes `gc_gaussian_k-max-10_tau-max-2` (0.16556 → 0.1585) and `te_symbolic_k-10_kt-1_l-1_lt-1` (p14). It also resets `KERNEL_WIDTH` to 0.25 for kernel SPIs (`je_kernel_W-0.5` 3.982283 → 3.748712, `r4_deepcopy.py`). Those belong to it_gaussian and it_kernel and are not checked here beyond these probes. The regression tests use the plain `Calculator` path, which does not copy SPIs, so the goldens are not affected by this, though that does not make them a reference.

"""+t[e:]
rep("1. **Jar provenance.** Which exact commit built the jar? The evidence points to master a9b6b3e (2024-04-20), but this is unconfirmed without a byte-level rebuild.",
"1. **Jar provenance.** Which exact commit built the jar? The jar's content (NOISE_SEED in the MI and entropy Common classes, `EntropyCalculatorMultiVariateCommon.class`) and the API commit dates point to master a9b6b3e (2024-04-20), but this is unconfirmed without a byte-level rebuild.")
rep("7. **Copy bug scope.** Does any user-facing workflow (CalculatorFrame, pickling for multiprocessing, saved calculators) feed EEG results? If so, which stored TE/GC values were produced through a copy?",
"7. **Copy bug scope.** Does any user-facing workflow (CalculatorFrame, pickling for multiprocessing, saved calculators) feed EEG results? If so, which stored values were produced through a copy, and by which path? Through pickle, the auto-embedding and k-2 TE (and GC) values are wrong. Through deepcopy, which CalculatorFrame uses, those values are wrong and, in addition, every mi/tlmi/te kraskov value ran with unseeded jitter, any NN-k with k ≠ 4 ran with k = 4, and kernel SPIs ran with width 0.25. The unseeded jitter matters only if the EEG data contain ties (see question 4).")
open(p,'w').write(t)
