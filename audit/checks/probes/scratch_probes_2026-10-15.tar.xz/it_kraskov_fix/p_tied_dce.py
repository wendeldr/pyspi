import sys, io, contextlib, copy, pickle, numpy as np, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
warnings.filterwarnings('ignore')
import pyspi.statistics.infotheory as it
from pyspi.data import Data
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()): return Data(x, dim_order='ps', normalise=True)
x = np.load(DD+'logistic_maps_T256.npz')['x']
specs=[('mi_DCE',lambda: it.MutualInfo(estimator='kraskov',prop_k=4,dyn_corr_excl='AUTO')),
('tlmi_DCE',lambda: it.TimeLaggedMutualInfo(estimator='kraskov',prop_k=4,dyn_corr_excl='AUTO')),
('te_DCE_k1',lambda: it.TransferEntropy(estimator='kraskov',prop_k=4,dyn_corr_excl='AUTO',k_history=1,k_tau=1,l_history=1,l_tau=1)),
('te_auto',lambda: it.TransferEntropy(estimator='kraskov',prop_k=4,auto_embed_method='MAX_CORR_AIS',k_search_max=10,tau_search_max=4))]
for n,f in specs:
    s=f(); a=[f().bivariate(mk(x),i=1,j=0) for _ in range(2)]
    p=pickle.loads(pickle.dumps(s)).bivariate(mk(x),i=1,j=0)
    d=[copy.deepcopy(s).bivariate(mk(x),i=1,j=0) for _ in range(3)]
    print(f'{n:9s} orig {a[0]:.6f} {a[1]:.6f} pickle {p:.6f} deepcopies '+' '.join(f'{v:.6f}' for v in d))
