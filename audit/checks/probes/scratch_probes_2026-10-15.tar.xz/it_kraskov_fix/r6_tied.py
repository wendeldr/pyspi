import sys, io, contextlib, copy, numpy as np, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
warnings.filterwarnings('ignore')
import pyspi.statistics.infotheory as it
from pyspi.data import Data
DD='/media/dan/Data/git/pyspi/audit/checks/data/'
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()): return Data(x, dim_order='ps', normalise=True)
x = np.load(DD+'logistic_maps_T256.npz')['x']
print('distinct values per channel:', [len(np.unique(np.round(r, 12))) for r in x])
for name, mkspi in [('mi', lambda: it.MutualInfo(estimator='kraskov', prop_k=4)), ('tlmi', lambda: it.TimeLaggedMutualInfo(estimator='kraskov', prop_k=4)), ('te_k1', lambda: it.TransferEntropy(estimator='kraskov', prop_k=4, k_history=1, l_history=1))]:
    s = mkspi(); a1 = s.bivariate(mk(x), i=1, j=0); a2 = mkspi().bivariate(mk(x), i=1, j=0)
    cs = [copy.deepcopy(s) for _ in range(3)]; b = [c.bivariate(mk(x), i=1, j=0) for c in cs]
    print(f'{name:5s} logistic_maps T=256 (1->0): original run1 {a1:.6f} run2 {a2:.6f} | deepcopies {b[0]:.6f} {b[1]:.6f} {b[2]:.6f} | copy NOISE_SEED={cs[0]._calc.getProperty("NOISE_SEED")}')
