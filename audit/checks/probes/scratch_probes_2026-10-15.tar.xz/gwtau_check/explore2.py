import sys
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np
import gwtau as G
from _kernels_distance import wasserstein2_1d
D = 16.0
def rows(fs):
    s = np.arange(int(D*fs)) / fs
    return np.vstack([np.sin(2*np.pi*1.0*s) + 0.5*np.sin(2*np.pi*3.0*s + 1.0), np.sin(2*np.pi*1.3*s + 0.4)])
def realtime(z, dt):
    return np.concatenate([[0.0], np.cumsum(np.sqrt(dt*dt + np.diff(z)**2))])
for fs in (16, 32, 64, 128, 256):
    Z = G.zscore(rows(fs))
    pys = G.k_gwtau(Z[0], Z[1])
    rt = wasserstein2_1d(realtime(Z[0], 1/fs), realtime(Z[1], 1/fs))
    print(fs, Z.shape[1], 'pyspi %.4f  real-time canonical %.5f' % (pys, rt))
