import sys
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np
from scipy import stats
import gwtau as G, make_data
for T in (64, 256, 1024, 4096):
    x = np.asarray(make_data.load('iid_gaussian', T)['x'], float)
    mc = G.mc_mean_m2(T, n=2000)
    A = G.load_pyspi(f'distance.gwtau|iid_gaussian|{T}|kernel|null-m2')
    obs = np.mean(G.upper(A)**2)
    print(T, 'var rows', np.round(x.var(axis=1, ddof=1), 3), 'obs %.1f pct %.4f  MC q[.005,.995]=%s skew %.2f' % (obs, np.mean(mc < obs), np.round(np.quantile(mc, [0.005, 0.995]), 1), stats.skew(mc)))
