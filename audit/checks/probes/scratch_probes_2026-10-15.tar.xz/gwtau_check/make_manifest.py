import json
U = "distance.gwtau"
runs = []
def add(ds, T, path, tag, probe=None, ident="gwtau", processes=None):
    runs.append(dict(run_id=f"{U}|{ds}|{T}|{path}|{tag}", unit_id=U, identifier=None if probe else ident,
                     dataset=ds, T=T, path=path, processes=processes, seed=42,
                     probe=None if probe is None else {"module": "probes/gwtau_probes.py", "function": probe}))
ALL_T = (64, 256, 1024, 4096)
for ds in ("iid_gaussian", "delayed_noise", "var2_bivariate", "narrowband_f0-0.25", "trending"):
    for T in ALL_T:
        add(ds, T, "pipeline", "def")
for ds in ("bivariate_gaussian", "scaled_offset", "var2_chain", "narrowband_f0-0.1", "narrowband_f0-0.4",
           "logistic_maps", "logistic_maps_bidir", "logistic_maps_chaotic", "logistic_maps_sugihara",
           "nonlinear_dependence", "contaminated", "cointegrated", "anm", "sparse_precision",
           "shared_envelope", "gauss_ar1_pair"):
    add(ds, 1024, "pipeline", "def")
for ds in ("iid_gaussian", "bivariate_gaussian", "narrowband_f0-0.25"):
    for T in (256, 4096):
        add(ds, T, "kernel", "def")
add("scaled_offset", 1024, "kernel", "def")
add("trending", 1024, "pipeline-detrend", "def"); add("trending", 4096, "pipeline-detrend", "def")
add("delayed_noise", 1024, "pipeline-detrend", "def")
# external package
for ds, T, path in (("iid_gaussian", 256, "pipeline"), ("iid_gaussian", 4096, "pipeline"),
                    ("bivariate_gaussian", 1024, "kernel"), ("narrowband_f0-0.25", 4096, "pipeline"),
                    ("delayed_noise", 1024, "pipeline")):
    add(ds, T, path, "pot")
# canonical root-included relation
for T in ALL_T:
    add("iid_gaussian", T, "kernel", "canon")
add("bivariate_gaussian", 1024, "kernel", "canon"); add("narrowband_f0-0.25", 1024, "pipeline", "canon")
# same-lineage Octave
add("iid_gaussian", 256, "kernel", "octave"); add("bivariate_gaussian", 1024, "pipeline", "octave")
# unequal-length branch
for tag in ("unequal-quantile", "unequal-pot", "unequal-octave"):
    add("iid_gaussian", 256, "kernel", tag, probe="unequal")
# both orientations unmirrored + symmetry on direction datasets
for ds in ("var2_bivariate", "var2_chain", "delayed_noise", "logistic_maps_chaotic", "anm", "iid_gaussian"):
    add(ds, 1024, "pipeline", "unmirrored", probe="unmirrored")
for ds in ("var2_bivariate", "var2_chain", "delayed_noise", "logistic_maps_chaotic", "anm"):
    add(ds, 1024, "pipeline", "sym")
add("iid_gaussian", 4096, "pipeline", "sym")
# scale / offset / trend
for T in (64, 1024, 4096):
    add("scaled_offset", T, "pipeline", "affine")
add("scaled_offset", 1024, "kernel", "rawunits")
add("trending", 1024, "pipeline-detrend", "detrendinv"); add("trending", 4096, "pipeline-detrend", "detrendinv")
add("trending", 1024, "pipeline", "trend-nodetrend")
add("iid_gaussian", 1024, "kernel", "invar", probe="derived"); add("iid_gaussian", 1024, "pipeline", "invar", probe="derived")
# order dependence
for ds in ("iid_gaussian", "var2_bivariate", "narrowband_f0-0.1"):
    add(ds, 1024, "pipeline", "perm-def", probe="derived"); add(ds, 1024, "pipeline", "perm-change", probe="derived")
add("narrowband_f0-0.1", 1024, "pipeline", "rev", probe="derived")
# null
for T in ALL_T:
    add("iid_gaussian", T, "pipeline", "null")
add("iid_gaussian", 1024, "kernel", "null-m2"); add("iid_gaussian", 4096, "kernel", "null-m2")
add("iid_gaussian", 4096, "pipeline", "slope")
# sinusoids
for T in (256, 4096):
    add("narrowband_f0-0.25", T, "pipeline", "sin-grid25", probe="derived")
    add("narrowband_f0-0.1", T, "pipeline", "sin-freq", probe="derived")
    add("narrowband_f0-0.1", T, "pipeline", "xfreq", probe="xfreq")
add("narrowband_f0-0.25", 4096, "pipeline", "shift")
add("delayed_noise", 1024, "pipeline", "delay"); add("delayed_noise", 4096, "pipeline", "delay")
add("shared_envelope", 1024, "pipeline", "ident")
assert len({r["run_id"] for r in runs}) == len(runs)
json.dump({"family": "gwtau", "runs": runs}, open("/media/dan/Data/git/pyspi/audit/checks/manifest/gwtau.json", "w"), indent=1)
print(len(runs))
