import numpy as np
from scipy import integrate, stats
g = lambda u: np.sqrt(1+u*u)
# U ~ N(0,2)
s = np.sqrt(2)
Eg = integrate.quad(lambda u: g(u)*stats.norm.pdf(u, scale=s), -np.inf, np.inf, epsabs=1e-13)[0]
Eg2 = 1 + 2.0
V0 = Eg2 - Eg**2
# (U0,U1) cov [[2,-1],[-1,2]]
# E[g(U0) g(U1)]: Gauss-Hermite 2-D
n=200
xg, wg = np.polynomial.hermite_e.hermegauss(n); wg = wg/np.sqrt(2*np.pi)
# U0 = a0 + a1 ... use x0,x1,x2 iid: U0 = x1-x0, U1 = x2-x1 ; integrate over x1 inner analytically? do 3D GH is 8e6 points ok
X0,X1,X2 = np.meshgrid(xg,xg,xg, indexing='ij'); W = wg[:,None,None]*wg[None,:,None]*wg[None,None,:]
E01 = np.sum(W*g(X1-X0)*g(X2-X1))
C1 = E01 - Eg**2
print('Eg',Eg,'V0',V0,'C1',C1)
g0, g1 = 2*V0, 2*C1
for T in (64,256,1024,4096):
    pred = g0*T/2 + g1*(T-2)
    rng = np.random.default_rng(1)
    vals=[]; valsz=[]
    for r in range(2000):
        x = rng.standard_normal((2,T))
        L = np.cumsum(g(np.diff(x,axis=1)),axis=1)
        vals.append(np.mean((L[0]-L[1])**2))
        z = (x - x.mean(1,keepdims=True))/x.std(1,ddof=1,keepdims=True)
        Lz = np.cumsum(g(np.diff(z,axis=1)),axis=1)
        valsz.append(np.sqrt(np.mean((Lz[0]-Lz[1])**2)))
    vals=np.array(vals)
    print(T, 'pred E[gw^2]', pred, 'MC raw', vals.mean(), '+-', vals.std()/np.sqrt(len(vals)), ' MC z mean gw', np.mean(valsz), 'sd', np.std(valsz))
