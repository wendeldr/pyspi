import sys
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np
from scipy import stats
import gwtau as G
for T in (64, 256, 1024, 4096):
    v = G.mc_null(T)
    m = 10; a = 0.05 / m
    lo, hi = np.quantile(v, [a/2, 1-a/2])
    mu, sd = v.mean(), v.std(ddof=1); z = stats.norm.ppf(1-0.025/m)
    print(T, 'mean %.3f sd %.3f skew %.2f  sym band [%.3f, %.3f]  emp band [%.3f, %.3f]' % (mu, sd, stats.skew(v), mu-z*sd, mu+z*sd, lo, hi))
# grid effect: mean step over one period for phases
def mean_step(f, phi, q, sdz=1/np.sqrt(2)):
    w = 2*np.pi*f; t = np.arange(q*50)
    dz = 2*np.sin(w/2)*np.cos(w*(t+0.5)+phi)/sdz
    return np.mean(np.sqrt(1+dz*dz))
for f, q in ((0.25,4),(0.2,5),(0.1,10),(0.4,5),(10/256,128),(50/256,256),(12/250,125)):
    s = [mean_step(f, p, q) for p in (0, np.pi/4, -np.pi/2, np.pi/7)]
    print('f=%.4f drift per step vs phase0: %s' % (f, ['%.2e' % (x - s[0]) for x in s[1:]]))
for T in (256, 4096):
    for f in (10/256, 0.2):
        L = [np.cumsum(G.sinusoid_steps(f, p, T)) for p in (0, np.pi/4, -np.pi/2)]
        print(T, f, 'A01 %.4f A02 %.4f' % (np.sqrt(np.mean((L[0]-L[1])**2)), np.sqrt(np.mean((L[0]-L[2])**2))))
