import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import _kernels_infotheory as K
GRID = [0.0, 1.0, 2.0, 3.0, 10.0]
GRID_B = [0.0, 2.0, 1.0, 3.0, 4.0]
GRID2 = [[a, b] for a in (0.0, 1.0, 2.0) for b in (0.0, 2.0, 5.0)]
TE_S = [0.0, 1, 2, 1, 0, 3, 2, 1, 0, 1]
TE_T = [1.0, 0, 1, 2, 1, 0, 3, 2, 1, 0]
q = list(np.arange(31) * 0.1)
tasks=[("H", GRID, 1.0 - 1e-6), ("H", GRID, 1.0), ("H", GRID, 1.0 + 1e-6), ("H", GRID, 2.0),
        ("H", GRID2, 1.0 - 1e-6), ("H", GRID2, 1.0), ("H", GRID2, 2.0),
        ("H", [0.0, 100.0], 0.5),
        ("MI", (GRID, GRID), 1.0), ("MI", (GRID, GRID_B), 1.0), ("MI", (GRID, GRID_B), 1.0 - 1e-6),
        ("TE", (TE_S, TE_T), 1.0), ("TE", (TE_S, TE_T), 1.0 - 1e-6),
        ("H", q, 0.1), ("H", q, 0.1 + 1e-12)]
S=np.load("/media/dan/Data/git/pyspi/audit/checks/out/pyspi/infotheory.est.kernel|iid_gaussian|64|kernel|tie-grid.npz")['value']
for (k,a,w),s in zip(tasks,S):
    if k=='H': v=K.entropy_box_kernel(np.asarray(a),w,normalise=False)
    elif k=='MI': v=K.mi_box_kernel(np.asarray(a[0]),np.asarray(a[1]),w,normalise=False)
    else: v=K.te_box_kernel(np.asarray(a[0]),np.asarray(a[1]),1,w,normalise=False)
    print(k,w,s,v,s-v)
qq=np.arange(31)*0.1
d=np.abs(qq[:,None]-qq[None,:]); print((d<=0.1).sum(1))
