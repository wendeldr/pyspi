import json
U = {"je": ("infotheory.je.kernel", "je_kernel_W-0.5"), "ce": ("infotheory.ce.kernel", "ce_kernel_W-0.5"),
     "cce": ("infotheory.cce.kernel", "cce_kernel_W-0.5"), "xme1": ("infotheory.xme.kernel_k1", "xme_kernel_W-0.5_k1"),
     "xme10": ("infotheory.xme.kernel_k10", "xme_kernel_W-0.5_k10"), "di": ("infotheory.di.kernel", "di_kernel_W-0.5"),
     "si": ("infotheory.si.kernel", "si_kernel_W-0.5_k-1"), "mi": ("infotheory.mi.kernel", "mi_kernel_W-0.25"),
     "tlmi": ("infotheory.tlmi.kernel", "tlmi_kernel_W-0.25"), "te": ("infotheory.te.kernel_k-1_kt-1_l-1_lt-1", "te_kernel_W-0.25_k-1"),
     "est": ("infotheory.est.kernel", None)}
PM = "probes/it_kernel_probes.py"
runs = []
def add(key, ds, T, path, tag, processes=None, probe=None, ident="default"):
    unit, idf = U[key]
    if ident != "default":
        idf = ident
    runs.append(dict(run_id=f"{unit}|{ds}|{T}|{path}|{tag}", unit_id=unit, identifier=idf, dataset=ds, T=T, path=path,
                     processes=processes, seed=42, probe=None if probe is None else {"module": PM, "function": probe}))
NUMPY = {
 "je": [("iid_gaussian", 64), ("iid_gaussian", 256), ("bivariate_gaussian", 1024), ("var2_bivariate", 1024), ("delayed_noise", 1024),
        ("nonlinear_dependence", 1024), ("contaminated", 1024), ("logistic_maps", 1024), ("narrowband_f0-0.25", 1024)],
 "ce": [("iid_gaussian", 64), ("iid_gaussian", 256), ("bivariate_gaussian", 1024), ("var2_bivariate", 1024), ("delayed_noise", 1024),
        ("nonlinear_dependence", 1024), ("logistic_maps", 1024), ("narrowband_f0-0.1", 1024)],
 "mi": [("iid_gaussian", 256), ("bivariate_gaussian", 1024), ("var2_bivariate", 1024), ("delayed_noise", 1024),
        ("nonlinear_dependence", 1024), ("contaminated", 1024), ("logistic_maps", 1024)],
 "tlmi": [("iid_gaussian", 256), ("var2_bivariate", 1024), ("delayed_noise", 1024), ("gauss_ar1_pair", 1024),
          ("logistic_maps", 1024), ("logistic_maps_chaotic", 1024)],
 "te": [("iid_gaussian", 256), ("var2_bivariate", 1024), ("delayed_noise", 1024), ("gauss_ar1_pair", 1024),
        ("logistic_maps", 1024), ("logistic_maps_chaotic", 1024), ("logistic_maps_sugihara", 1024)],
 "xme1": [("iid_gaussian", 256), ("delayed_noise", 1024), ("var2_bivariate", 1024), ("gauss_ar1_pair", 1024),
          ("logistic_maps", 1024), ("logistic_maps_chaotic", 1024)],
 "xme10": [("iid_gaussian", 256), ("iid_gaussian", 1024), ("delayed_noise", 1024), ("var2_bivariate", 1024),
           ("logistic_maps", 1024), ("logistic_maps_chaotic", 1024)],
 "cce": [("iid_gaussian", 256), ("delayed_noise", 1024), ("var2_bivariate", 1024), ("gauss_ar1_pair", 1024),
         ("logistic_maps", 1024), ("logistic_maps_chaotic", 1024)],
 "di": [("iid_gaussian", 256), ("delayed_noise", 1024), ("var2_bivariate", 1024), ("gauss_ar1_pair", 1024),
        ("logistic_maps_chaotic", 1024)],
 "si": [("iid_gaussian", 256), ("gauss_ar1_pair", 1024), ("var2_bivariate", 1024), ("delayed_noise", 1024), ("logistic_maps", 1024)],
}
for key, lst in NUMPY.items():
    for ds, T in lst:
        add(key, ds, T, "pipeline", "numpy")
    Tk = 256 if key in ("cce", "di") else 1024
    add(key, "scaled_offset", Tk, "kernel", "numpy")
    if key in ("je", "mi", "te"):
        add(key, "var2_bivariate", 1024, "kernel", "numpy")
    if key not in ("cce", "di", "xme10"):
        add(key, "trending", 1024, "pipeline-detrend", "numpy")
# affine invariance / NORMALISE
for key in ("je", "ce", "mi"):
    add(key, "scaled_offset", 1024, "pipeline", "equals-d2")
for key in ("je", "ce"):
    add(key, "scaled_offset", 1024, "kernel", "shift")
add("mi", "scaled_offset", 1024, "kernel", "equals-d2")
# bounds
for key in ("je", "ce"):
    add(key, "narrowband_f0-0.25", 1024, "pipeline", "bound")
    add(key, "logistic_maps", 1024, "pipeline", "bound")
    add(key, "iid_gaussian", 64, "pipeline", "bound")
# convergence on Gaussian pairs (statistical vs Monte Carlo of the reference estimator)
for key in ("je", "ce", "mi"):
    for T in (64, 256, 1024):
        add(key, "bivariate_gaussian", T, "pipeline", "truth-p01", processes=[0, 1])
        add(key, "bivariate_gaussian", T, "pipeline", "truth-p23", processes=[2, 3])
for T in (64, 256, 1024):
    add("je", "iid_gaussian", T, "pipeline", "truth-iid", processes=[0, 1, 2])
    for key in ("mi", "tlmi", "te", "si"):
        add(key, "iid_gaussian", T, "pipeline", "null", processes=[0, 1, 2])
    for key in ("xme1", "cce", "di"):
        add(key, "iid_gaussian", T, "pipeline", "truth-iid", processes=[0, 1])
for T in (256, 1024):
    add("xme10", "iid_gaussian", T, "pipeline", "truth-iid", processes=[0, 1])
    add("tlmi", "delayed_noise", T, "pipeline", "truth-p01", processes=[0, 1])
    add("tlmi", "gauss_ar1_pair", T, "pipeline", "truth")
    add("te", "var2_bivariate", T, "pipeline", "truth")
    add("si", "gauss_ar1_pair", T, "pipeline", "truth")
add("te", "gauss_ar1_pair", 1024, "pipeline", "truth")
add("xme1", "gauss_ar1_pair", 1024, "pipeline", "truth")
add("mi", "nonlinear_dependence", 1024, "pipeline", "nonlinear")
add("cce", "gauss_ar1_pair", 1024, "pipeline", "gauss-block")
# direction / symmetry
DIR = {"te": ["var2_bivariate", "delayed_noise", "logistic_maps_chaotic", "logistic_maps_sugihara"],
       "tlmi": ["var2_bivariate", "delayed_noise"],
       "ce": ["var2_bivariate", "delayed_noise", "nonlinear_dependence"],
       "cce": ["var2_bivariate", "delayed_noise", "logistic_maps_chaotic"],
       "di": ["var2_bivariate", "delayed_noise", "logistic_maps_chaotic"],
       "xme1": ["var2_bivariate", "delayed_noise", "logistic_maps_chaotic"],
       "xme10": ["var2_bivariate", "delayed_noise", "logistic_maps_chaotic"]}
for key, lst in DIR.items():
    for ds in lst:
        add(key, ds, 1024, "pipeline", "direction")
add("te", "var2_bivariate", 256, "pipeline", "direction")
for key in ("je", "mi", "si"):
    add(key, "var2_bivariate", 1024, "pipeline", "sym-fresh", probe="sym_fresh")
    add(key, "delayed_noise", 256, "pipeline", "sym-fresh", probe="sym_fresh")
# xme specifics
for ds, T in (("iid_gaussian", 1024), ("delayed_noise", 1024), ("var2_bivariate", 1024)):
    add("xme10", ds, T, "pipeline", "degenerate")
add("xme1", "var2_bivariate", 1024, "pipeline", "k2-numpy", probe="xme_k2", ident=None)
add("xme1", "var2_bivariate", 1024, "pipeline", "k2-equals-k1-shifted", probe="xme_k2", ident=None)
# cce / di specifics
add("cce", "var2_bivariate", 1024, "pipeline", "n10", probe="cce_n10", ident=None)
add("cce", "var2_bivariate", 64, "pipeline", "configured-n", probe="configured_n", ident=None)
add("di", "var2_bivariate", 1024, "pipeline", "n10", probe="di_n10", ident=None)
add("di", "var2_bivariate", 1024, "pipeline", "massey-identity")
add("di", "var2_bivariate", 1024, "pipeline", "indep-numpy", probe="di_indep_pair", ident=None)
add("di", "var2_bivariate", 1024, "pipeline", "indep-gap", probe="di_indep_pair", ident=None)
# te specifics
add("te", "var2_bivariate", 256, "pipeline", "forwarding", probe="te_forwarding", ident=None)
add("te", "var2_bivariate", 256, "pipeline", "forwarding-flags", probe="te_forwarding_flags", ident=None)
# copy path (CalculatorFrame / pickle)
for key in ("je", "ce", "cce", "xme1", "xme10", "di", "si", "mi", "tlmi", "te"):
    add(key, "bivariate_gaussian", 256, "pipeline", "frame", probe="frame")
for key in ("je", "ce"):
    add(key, "var2_bivariate", 256, "pipeline", "frame", probe="frame")
# estimator layer
add("est", "iid_gaussian", 256, "kernel", "direct-jidt", probe="direct_jidt")
add("est", "var2_bivariate", 1024, "kernel", "direct-jidt", probe="direct_jidt")
add("est", "iid_gaussian", 64, "kernel", "tie-grid", probe="tie_grid")
add("est", "iid_gaussian", 256, "pipeline", "props", probe="props")
add("est", "bivariate_gaussian", 256, "pipeline", "copy-props", probe="copy_props")
add("est", "var2_bivariate", 1024, "pipeline", "force-all", probe="force_all")
add("est", "scaled_offset", 256, "kernel", "raw-array", probe="raw_array")
add("est", "scaled_offset", 1024, "kernel", "raw-array", probe="raw_array")
add("est", "iid_gaussian", 256, "pipeline", "entropy-1d-numpy", probe="entropy_1d")
add("est", "nonlinear_dependence", 1024, "pipeline", "entropy-1d-numpy", probe="entropy_1d")
for T in (64, 256, 1024):
    add("est", "iid_gaussian", T, "pipeline", "entropy-1d-truth", probe="entropy_1d")
for T in (256, 1024):
    add("est", "nonlinear_dependence", T, "pipeline", "entropy-1d-uniform", processes=[0], probe="entropy_1d")
ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids)), [i for i in ids if ids.count(i) > 1]
json.dump({"family": "it_kernel", "runs": runs}, open("/media/dan/Data/git/pyspi/audit/checks/manifest/it_kernel.json", "w"), indent=1)
print(len(runs))
