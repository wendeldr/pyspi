import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import it_kernel as R, make_data
rng=np.random.default_rng(1)
v=[];ve=[]
for r in range(50):
    u=R.zs(rng.uniform(-1,1,(1,1024)))[0]
    v.append(R.fa_H(u,0.5)); ve.append(R.ex_H(u,0.5))
print(np.mean(v), np.std(v), np.max(np.abs(np.array(v)-ve)))
x=make_data.load('nonlinear_dependence',1024)['x'][0]
print(x.min(), x.max(), x.mean(), x.std())
print(R.ex_H(R.zs(x[None])[0],0.5))
