"""Fill the check-stage block of the it_kernel records (project venv: needs yaml)."""
import json
from collections import OrderedDict, defaultdict
from pathlib import Path

import yaml

AUDIT = Path("/media/dan/Data/git/pyspi/audit")
REC = AUDIT / "records"
RES = json.loads((AUDIT / "checks/out/results/it_kernel.json").read_text())
MAN = json.loads((AUDIT / "checks/manifest/it_kernel.json").read_text())
R = "audit/checks/refs/it_kernel.py"
KI = "audit/checks/refs/_kernels_infotheory.py"
P = "audit/checks/probes/it_kernel_probes.py"

TAGFN = {
    "numpy": "chk_numpy", "equals-d2": "chk_equals_d2", "shift": "chk_shift", "bound": "chk_bound",
    "truth-iid": "chk_truth_iid", "null": "chk_null", "truth": "chk_truth_model", "truth-p01": "chk_truth_pair / chk_truth_model",
    "truth-p23": "chk_truth_pair", "nonlinear": "chk_nonlinear", "gauss-block": "chk_gauss_block", "direction": "chk_direction",
    "sym-fresh": f"chk_sym_fresh ({P}:sym_fresh)", "degenerate": "chk_degenerate", "k2-numpy": f"chk_k2_numpy ({P}:xme_k2)",
    "k2-equals-k1-shifted": f"chk_k2_equals_k1_shifted ({P}:xme_k2)", "n10": f"chk_n10 ({P}:cce_n10 / di_n10)",
    "configured-n": f"chk_configured_n ({P}:configured_n)", "massey-identity": "chk_massey_identity",
    "indep-numpy": f"chk_indep_numpy ({P}:di_indep_pair)", "indep-gap": f"chk_indep_gap ({P}:di_indep_pair)",
    "forwarding": f"te_forwarding_ref ({P}:te_forwarding)", "forwarding-flags": f"chk_forwarding_flags ({P}:te_forwarding_flags)",
    "frame": f"chk_frame ({P}:frame)", "direct-jidt": f"chk_direct_jidt ({P}:direct_jidt)", "tie-grid": f"chk_tie_grid ({P}:tie_grid)",
    "props": f"chk_props ({P}:props)", "copy-props": f"chk_copy_props ({P}:copy_props)", "force-all": f"chk_force_all ({P}:force_all)",
    "raw-array": f"chk_raw_array ({P}:raw_array)", "entropy-1d-numpy": f"chk_entropy_1d_numpy ({P}:entropy_1d)",
    "entropy-1d-truth": f"chk_entropy_1d_truth ({P}:entropy_1d)", "entropy-1d-uniform": f"chk_entropy_1d_truth ({P}:entropy_1d)",
}


def g(x, n=2):
    return f"{x:.{n}g}"


def checks_run(uid, notes=None):
    notes = notes or {}
    by = defaultdict(list)
    for r in MAN["runs"]:
        if r["unit_id"] == uid:
            by[r["run_id"].split("|")[-1]].append(r["run_id"])
    out = []
    for tag, rids in by.items():
        res = [RES[x] for x in rids]
        npass = sum(bool(v.get("pass")) for v in res)
        crit = sorted({v.get("criterion") for v in res})
        head = f"{npass}/{len(rids)} pass ({', '.join(crit)})"
        mx = [v.get("max_abs") for v in res if v.get("criterion") == "exact" and v.get("max_abs") is not None]
        if mx:
            head += f"; max_abs <= {g(max(mx))}"
        mz = [v.get("max_z") for v in res if v.get("criterion") == "statistical"]
        if mz:
            head += f"; max_z {', '.join(g(z, 3) for z in mz)}"
        if tag in notes:
            head += "; " + notes[tag]
        out.append(OrderedDict(run_ids=rids, reference=f"{R}:{TAGFN[tag]}", outcome=head))
    return out


def res(rid, key):
    return RES[rid][key]


def setfields(uid, fields, trace_fix=None):
    p = REC / f"{uid}.yaml"
    d = yaml.safe_load(p.read_text())
    c = d["correctness"]
    if trace_fix:
        trace_fix(c)
    n = len(c.get("new_finding_candidates") or [])
    assert len(fields["candidate_resolutions"]) == n, (uid, n, len(fields["candidate_resolutions"]))
    for k in ["check_method", "check_reference", "check_data", "agreement_criterion", "closeness", "verdict",
              "score_0_10", "what_changed", "new_finding", "definition_under_review", "check_cost", "symmetry_observed",
              "direction_observed", "candidate_resolutions", "checks_run"]:
        c[k] = fields[k]
    d["status"] = "checked"
    d["correctness"] = c

    def plain(o):
        if isinstance(o, OrderedDict) or isinstance(o, dict):
            return {k: plain(v) for k, v in o.items()}
        if isinstance(o, list):
            return [plain(v) for v in o]
        return o
    p.write_text(yaml.safe_dump(plain(d), sort_keys=False, width=200, allow_unicode=True))


def cr(candidate, outcome, evidence):
    return OrderedDict(candidate=candidate, outcome=outcome, evidence=evidence)


FRAME_NOTE = "Calculator and pickle slices equal the configured-width numpy value; the CalculatorFrame slice equals the width-0.25 numpy value"
CHEAP = "cheap: pyspi <= 5.5 s per SPI run and <= 12 s for the CalculatorFrame probe (P <= 5, T <= 1024); numpy references O(T^2) all-pairs counting, T <= 1024 (the box estimator is O(T^2) on both sides; no T = 4096 runs)"
EXACT_CRIT = "exact: rtol 1e-10, atol 1e-12 (bits); statistical: |pyspi - Monte Carlo mean of the same box estimator under the generating model| <= 2 Monte Carlo SD, population values reported as convergence information only; qualitative: stated rule"


# ------------------------------------------------------------------ est
def est():
    uid = "infotheory.est.kernel"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_direct_jidt -> {KI}:entropy_box_kernel / mi_box_kernel / te_box_kernel (all-pairs counts, |dx| <= w, self included, N-1 SD widths, bits) against direct JIDT kernel calculators "
                            f"({P}:direct_jidt, d = 1..10, MI 1+1 and 2+2, TE k = 1, 2, widths 0.5 and 0.25); {R}:chk_tie_grid (analytic closed-box counts on grids whose counts change at |dx| = w, NORMALISE=false, open-box and no-self variants as extras); "
                            f"{R}:chk_force_all (bin search vs FORCE_KERNEL_COMPARE_TO_ALL vs numpy); {R}:chk_raw_array; {R}:chk_props and chk_copy_props (same-lineage property read-back); "
                            f"{R}:chk_entropy_1d_numpy and chk_entropy_1d_truth (Monte Carlo of the 1-D box entropy, h_box quadrature, uniform edge formula of the _kernels_infotheory selftest)")
    f["check_data"] = ("iid_gaussian T64 (tie-grid harness only), T256 (direct JIDT, properties, 1-D entropies), T64/T256/T1024 (1-D convergence); var2_bivariate T1024 (direct JIDT, bin search); "
                       "bivariate_gaussian T256 (copy path properties); scaled_offset T256/T1024 (raw arrays, kernel path); nonlinear_dependence T256/T1024 (uniform 1-D entropy)")
    f["agreement_criterion"] = "exact: rtol 1e-10, atol 1e-12 (tie grid rtol 0, atol 1e-13); statistical: |pyspi - Monte Carlo mean| <= 2 Monte Carlo SD per entry; qualitative: property tables as stated in the reference"
    f["closeness"] = (
        "Direct JIDT vs numpy, 30 tasks per run (entropy d = 1..10, MI 1+1 and 2+2, TE k = 1, 2, widths 0.5 and 0.25): max_abs 3.6e-14 (iid_gaussian T256) and 2.6e-13 (var2_bivariate T1024); "
        "a ddof=0 width variant differs by 0.0287 / 0.0071 bits and a nats variant by 2.39 / 3.56, so the N-1 SD and bits conventions are discriminated. "
        "Tie grid: 15 JIDT values equal the closed-box counts to 8.9e-16: H([0,1,2,3,10], w=1) = 2.2879430946 (counts [2,3,3,2,1]; open box 3.3219281, max open-box difference 1.19), "
        "H([0,100], w=0.5) = 1.0 bit (self included; without self the isolated point gives infinite entropy), and on the k*0.1 grid at w = 0.1, where float rounding moves pairs across |dx| = w, "
        "JIDT 1.7959839412 equals the numpy closed compare-to-all count (open box 1.9116). Bin search vs compare-to-all: identical (0.0) and equal to numpy (5.0e-16). "
        "Raw-array bivariate(x, y): je and ce shift by exactly log2 sd(y) = 3.305191 (T256) / 3.307281 (T1024), mi/tlmi/te unchanged (<= 2.2e-16), all to <= 8.9e-15 against numpy. "
        "Properties: entropy and MI classes read NOISE_SEED 42 and NOISE_LEVEL_TO_ADD 0, BIAS_CORRECTION is unknown to all three classes, TE knows neither noise property; seed alone and BIAS_CORRECTION change H and MI by 0.0, "
        "noise 1e-8 changes H by 4.1e-10, noise 0.01 by 7.6e-4 (H) and -4.3e-3 (MI). Copy path: copy.deepcopy reads KERNEL_WIDTH 0.25 and NOISE_SEED 'NONE' for all ten SPIs, pickle keeps the configured width. "
        "1-D entropy: numpy exact (2.2e-15, 5.6e-15); N(0,1) means at W-0.5 1.979 / 2.035 / 2.044 at T = 64 / 256 / 1024 vs box limit 2.04935 and truth 2.04710; "
        "uniform 1.929 / 1.893 at T = 256 / 1024 vs box limit 1.92028 (quadrature = edge formula) and truth 1.79248. "
        "Three of five 1-D statistical runs fail the per-entry 2-SD band (max_z 2.93 at iid T64, 2.26 at iid T1024, 2.30 uniform T1024; 10 / 10 / 2 entries); "
        "over all 47 statistical runs of the family 8 of 130 entries exceed 2 SD (5.9 expected) and none exceeds 3 SD (refs/it_kernel.py --calibration).")
    f["verdict"] = "matches"
    f["score_0_10"] = 9
    f["what_changed"] = (
        "Nothing in the estimator: Kantz-Schreiber box kernel with closed max-norm boxes, self-inclusive (resubstitution) counts, half-width = W x N-1 SD of each column passed to JIDT, "
        "p = C / (N prod 2 w_d), averages in bits, no Theiler window, no noise, no bias correction. Conventions (rubric anchor 9): the documented 'kernel width 0.5 standard deviations' is the half-width "
        "(box side 1 SD), sample SD with N-1, bits. Path issues confirmed here (not in the estimator): a CalculatorFrame deep-copies every JIDT calculator into its default state, so all W-0.5 SPIs run "
        "at width 0.25 under their W-0.5 identifiers (the hyperparameter is ignored on that path only); raw-array bivariate(x, y) z-scores only x, shifting kernel entropies by log2 sd(y). "
        "Box-kernel estimates of differential quantities are biased at practical T (convergence runs); the 1-D statistical fails are draws in the tail of the sampling distribution, not mismatches (exact runs reproduce pyspi to <= 2.6e-13).")
    f["new_finding"] = True
    f["definition_under_review"] = False
    f["check_cost"] = CHEAP
    f["symmetry_observed"] = "n/a (estimator); its counts are invariant to column order, so je, mi and si are exactly symmetric: fresh unmirrored fills give max|D - D.T| = 0.0 (see those units)"
    f["direction_observed"] = "n/a (estimator)"
    f["candidate_resolutions"] = [
        cr("closed box (|dx| <= w) and self-inclusion", "confirmed",
           "infotheory.est.kernel|iid_gaussian|64|kernel|tie-grid: 15 JIDT values = closed-box numpy to 8.9e-16; H([0,1,2,3,10], w=1) 2.2879430946 vs open box 3.3219281; isolated point H = 1.0 bit (finite only with self-inclusion); k*0.1 grid at w = 0.1 matches the closed compare-to-all count"),
        cr("half-widths use the N-1 sample SD of each array passed to JIDT", "confirmed",
           "infotheory.est.kernel|iid_gaussian|256|kernel|direct-jidt and |var2_bivariate|1024|kernel|direct-jidt: max_abs 3.6e-14 / 2.6e-13 with N-1 SD; ddof=0 variant off by 0.0287 / 0.0071 bits"),
        cr("BIAS_CORRECTION ignored, NOISE_SEED stored but inert, TE class ignores NOISE_SEED", "confirmed",
           "infotheory.est.kernel|iid_gaussian|256|pipeline|props: BIAS_CORRECTION unknown to all three classes, NOISE_SEED 42 / NOISE_LEVEL_TO_ADD 0 on entropy and MI, both unknown to TE; dH, dMI = 0.0 for seed alone and BIAS_CORRECTION; noise level 1e-8 -> dH 4.1e-10, 0.01 -> 7.6e-4"),
        cr("CalculatorFrame (deepcopy) computes every W-0.5 kernel SPI at width 0.25", "confirmed",
           "infotheory.est.kernel|bivariate_gaussian|256|pipeline|copy-props (deepcopy width 0.25, NOISE_SEED 'NONE'; pickle keeps 0.5) and the per-unit |frame runs: CalculatorFrame slice = numpy width-0.25 value to <= 1.4e-13 for je, ce, cce, xme_k1, xme_k10, di, si"),
        cr("raw-array bivariate(x, y) z-scores only x", "confirmed",
           "infotheory.est.kernel|scaled_offset|256|kernel|raw-array and |1024|kernel|raw-array: je and ce raw - Data = log2 sd(x3) = 3.305191 / 3.307281 (ce is affected too, not only je); mi, tlmi, te unchanged (<= 2.2e-16); numpy reproduces both calls to <= 8.9e-15"),
        cr("bin search (+-1 neighbour bins) is exact", "confirmed",
           "infotheory.est.kernel|var2_bivariate|1024|pipeline|force-all: bins vs FORCE_KERNEL_COMPARE_TO_ALL differ by 0.0 for MI and both TE directions; both equal numpy all-pairs to 5.0e-16"),
    ]
    f["checks_run"] = checks_run(uid)
    setfields(uid, f)


# ------------------------------------------------------------------ je
def je():
    uid = "infotheory.je.kernel"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_numpy -> {KI}:entropy_box_kernel([z_i, z_j], 0.5) (bits); {R}:chk_equals_d2, chk_shift (analytic log2(sd_i sd_j) shift on the kernel path), chk_bound, chk_sym_fresh; "
                            f"{R}:chk_truth_iid and chk_truth_pair (Monte Carlo of the box estimator; Gaussian population and box limit h_box2 by quadrature); {R}:chk_frame")
    f["check_data"] = ("iid_gaussian T64/T256 and processes 0-2 at T64/T256/T1024; bivariate_gaussian T1024 and pairs (0,1)/(2,3) at T64/T256/T1024; var2_bivariate T1024 (pipeline and kernel) and T256 (frame); "
                       "delayed_noise T256/T1024; nonlinear_dependence, contaminated, logistic_maps, narrowband_f0-0.25 T1024; scaled_offset T1024 (pipeline and kernel); trending T1024 (pipeline-detrend)")
    f["agreement_criterion"] = EXACT_CRIT
    f["closeness"] = (
        "Numpy: 12/12 exact runs pass, max_abs <= 4.1e-14 (pipeline, kernel path on scaled_offset 8.9e-15 and var2_bivariate 1.2e-14, pipeline-detrend 6.2e-15, tied logistic_maps 9.8e-15). "
        "scaled_offset pipeline = z-scored D2 (7.1e-15); kernel path on raw scaled_offset = je(z-scored D2) + log2(sd_i sd_j) (7.1e-15). Bounds: every entry in [0, log2 T] (iid T64 3.633-3.945, logistic_maps 2.924, narrowband 2.0). "
        "Convergence (bits): iid pairs mean 3.741 / 3.989 / 4.066 at T = 64 / 256 / 1024 vs box limit 4.0987 and truth 4.0942 (max_z <= 1.86); bivariate_gaussian rho = 0.3: 3.715 / 3.982 / 4.016 vs box limit 4.0319, truth 4.0262; "
        "rho = 0.8: 3.004 / 3.306 / 3.396 vs box limit 3.3980, truth 3.3572 (max_z <= 1.46). CalculatorFrame: 3.7487119189 (bivariate_gaussian) / 3.6838644230 (var2_bivariate) = numpy at width 0.25 "
        "(<= 4.9e-15) vs Calculator 3.9822833545 / 3.9458115241.")
    f["verdict"] = "matches"
    f["score_0_10"] = 9
    f["what_changed"] = (
        "Box-kernel resubstitution estimate of the joint differential entropy in bits, as the code states; conventions only (half-width 0.5 SD, N-1 SD, bits; rubric anchor 9). Under z-scoring the box volume is 1, "
        "so the value is -mean log2(C/T), bounded in [0, log2 T]; it converges from below to the box limit (smoothing bias +0.005 bits at rho = 0 and +0.04 at rho = 0.8 above the Gaussian truth). "
        "CalculatorFrame path: computed at width 0.25 under the W-0.5 identifier (copy path, new finding; rubric anchor 3 would apply to that path only).")
    f["new_finding"] = True
    f["definition_under_review"] = False
    f["check_cost"] = CHEAP
    f["symmetry_observed"] = "sym: max|A - A.T| = 0.0 on all 12 numpy runs; fresh unmirrored fills bivariate(i,j) vs bivariate(j,i) give max|D - D.T| = 0.0 (var2_bivariate T1024, delayed_noise T256)"
    f["direction_observed"] = "undirected: A[i,j] = A[j,i] = H(x_i, x_j) (bits); the estimator itself is symmetric, not only the mirrored matrix"
    f["candidate_resolutions"] = [
        cr("'kernel width 0.5 SD' is the half-width of a closed max-norm box", "confirmed",
           "infotheory.est.kernel|iid_gaussian|64|kernel|tie-grid (closed-box counts, open box off by 1.19); infotheory.est.kernel|*|direct-jidt (half-width = W x N-1 SD to <= 2.6e-13)"),
        cr("volume 1 under z-scoring: value bounded in [0, log2 T], a smoothed plug-in rather than an unbiased differential-entropy estimate", "confirmed",
           "infotheory.je.kernel|*|bound (all entries inside [0, log2 T]); |truth-iid and |truth-p01/p23: approach the box limit 4.0987 / 4.0319 / 3.3980 from below as T grows; property of the documented estimator, not a defect"),
        cr("raw-array bivariate(x, y) shifts je by log2 sd(y)", "confirmed",
           "infotheory.est.kernel|scaled_offset|256|kernel|raw-array: raw - Data = 3.305191 = log2 sd(x3); counted under infotheory.est.kernel (path quirk of Data.add_process), not as a separate finding here"),
        cr("CalculatorFrame computes je at width 0.25 under the W-0.5 identifier", "confirmed",
           "infotheory.je.kernel|bivariate_gaussian|256|pipeline|frame and |var2_bivariate|256|pipeline|frame: frame slice = numpy width 0.25 (3.7487119189 / 3.6838644230) vs Calculator 3.9822833545 / 3.9458115241; pickle slice = Calculator"),
    ]
    f["checks_run"] = checks_run(uid, {"frame": FRAME_NOTE})

    def fix(c):
        old = ("(each frame value equals a direct JointEntropy(kernel_width=0.25) call on the same dataset: 3.7487119189 and 3.6838644230,\n"
               "    probe cleanup/it_kernel/p_direct_w025.py)")
        s = c["new_finding_candidates"][3]
        s2 = s.replace("(each frame value equals a direct JointEntropy(kernel_width=0.25) call on the same dataset: 3.7487119189 and 3.6838644230, probe cleanup/it_kernel/p_direct_w025.py)",
                       "(each frame value equals the width-0.25 value on its own dataset: 3.7487119189 for bivariate_gaussian and 3.6838644230 for var2_bivariate; check runs infotheory.je.kernel|bivariate_gaussian|256|pipeline|frame and infotheory.je.kernel|var2_bivariate|256|pipeline|frame)")
        assert s2 != s or "check runs infotheory.je.kernel" in s, "je trace fix not applied"
        c["new_finding_candidates"][3] = s2
    setfields(uid, f, fix)


# ------------------------------------------------------------------ ce
def ce():
    uid = "infotheory.ce.kernel"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_numpy -> {KI}:entropy_box_kernel([z_i, z_j]) - entropy_box_kernel(z_i) (0.5, bits); {R}:chk_direction (antisymmetric part = H(x_j) - H(x_i) from numpy 1-D box entropies); "
                            f"{R}:chk_equals_d2, chk_shift, chk_bound; {R}:chk_truth_pair (Monte Carlo, Gaussian population, box limit h_box2 - h_box1); {R}:chk_frame")
    f["check_data"] = ("iid_gaussian T64/T256; bivariate_gaussian T1024 and pairs at T64/T256/T1024; var2_bivariate T1024 and T256 (frame); delayed_noise, nonlinear_dependence, logistic_maps, narrowband_f0-0.1 / 0.25 T1024; "
                       "scaled_offset T1024 (pipeline and kernel); trending T1024 (pipeline-detrend)")
    f["agreement_criterion"] = EXACT_CRIT
    f["closeness"] = (
        "Numpy: 10/10 exact runs pass, max_abs <= 3.0e-14 (kernel path on scaled_offset 1.2e-14, pipeline-detrend 9.3e-15). Kernel path on raw scaled_offset = ce(z-scored D2) + log2 sd_j (1.2e-14). "
        "Orientation: A[i,j] - A[j,i] = H(x_j) - H(x_i) to 0.0 on var2_bivariate, delayed_noise and nonlinear_dependence; nonlinear_dependence A[0,1] = 0.8608 < A[1,0] = 0.9217. "
        "Bounds: min 1.62 (iid T64), 0.5 (narrowband), 1.14 (logistic_maps), never negative. Convergence (bits): rho = 0.3: 1.771 / 1.937 / 1.972 at T = 64 / 256 / 1024 vs box limit 1.9826, truth 1.9791; "
        "rho = 0.8: 1.055 / 1.262 / 1.344 vs box limit 1.3486, truth 1.3101 (max_z <= 1.22). CalculatorFrame 1.7266038499 (bivariate_gaussian) / 1.6579346797 (var2_bivariate) = numpy width 0.25 vs Calculator 1.9366210046 / 1.9000371826.")
    f["verdict"] = "matches"
    f["score_0_10"] = 9
    f["what_changed"] = (
        "Box-kernel H(x_j | x_i) = H(x_i, x_j) - H(x_i) in bits as the code states (conditioning order is REVIEW M8); conventions only (rubric anchor 9). With W-0.5 on z-scored data the value is -mean log2(C_xy / C_x) >= 0, "
        "unlike the Gaussian estimator. The asymmetry is entirely the difference of the two marginal box entropies (A[i,j] - A[j,i] = H(x_j) - H(x_i) exactly), so the 'directed' output orders channels by marginal entropy, "
        "not by coupling direction. CalculatorFrame path: width 0.25 under the W-0.5 identifier (copy path, new finding).")
    f["new_finding"] = True
    f["definition_under_review"] = False
    f["check_cost"] = CHEAP
    f["symmetry_observed"] = "asym: max|A - A.T| = 0.0055 (var2_bivariate), 0.0072 (delayed_noise), 0.134 (nonlinear_dependence), 0.285 (logistic_maps), 0.151 (iid T64) on pipeline numpy runs; 5.64 on the raw kernel path (scaled_offset); always equal to |H(x_j) - H(x_i)|"
    f["direction_observed"] = ("A[i,j] = H(x_j | x_i): row i conditions, column j is the target; A[i,j] - A[j,i] = H(x_j) - H(x_i) exactly (0.0 error). var2_bivariate A[0,1] = 1.9964 vs A[1,0] = 2.0020; "
                               "delayed_noise 2.0356 vs 2.0302; nonlinear_dependence 0.8608 vs 0.9217 (x1 = x0^2 + noise has the lower marginal box entropy)")
    f["candidate_resolutions"] = [
        cr("supplement / GitBook list ce as 'undirected' while the class is Directed and asymmetric", "confirmed",
           "infotheory.ce.kernel|*|direction: asymmetric (max|A - A.T| up to 0.285 on pipeline runs), the antisymmetric part equals H(x_j) - H(x_i); documentation label issue overlapping REVIEW M8/M9, recorded as an elaboration, not a new finding"),
        cr("range: ce_kernel_W-0.5 >= 0 (volume term 0 under z-scoring)", "confirmed",
           "infotheory.ce.kernel|*|bound: minimum 0.5 (narrowband), 1.14 (logistic_maps), 1.62 (iid T64); numpy formula -mean log2(C_xy/C_x) exact on 10 runs; a property, not a defect"),
        cr("CalculatorFrame computes ce at width 0.25 under the W-0.5 identifier", "confirmed",
           "infotheory.ce.kernel|bivariate_gaussian|256|pipeline|frame and |var2_bivariate|256|pipeline|frame: frame slice = numpy width 0.25 (1.7266038499 / 1.6579346797) vs Calculator 1.9366210046 / 1.9000371826"),
    ]
    f["checks_run"] = checks_run(uid, {"frame": FRAME_NOTE})

    def fix(c):
        s = c["new_finding_candidates"][2]
        s2 = s.replace("(each frame value equals a direct ConditionalEntropy(kernel_width=0.25) call on the same dataset: 1.7266038499 and 1.6579346797, probe cleanup/it_kernel/p_direct_w025.py)",
                       "(each frame value equals the width-0.25 value on its own dataset: 1.7266038499 for bivariate_gaussian and 1.6579346797 for var2_bivariate; check runs infotheory.ce.kernel|bivariate_gaussian|256|pipeline|frame and infotheory.ce.kernel|var2_bivariate|256|pipeline|frame)")
        assert s2 != s or "check runs infotheory.ce.kernel" in s, "ce trace fix not applied"
        c["new_finding_candidates"][2] = s2
    setfields(uid, f, fix)


# ------------------------------------------------------------------ mi
def mi():
    uid = "infotheory.mi.kernel"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_numpy -> {KI}:mi_box_kernel(z_i, z_j, 0.25) (separate x, y and joint boxes, bits); {R}:chk_equals_d2 (pipeline and kernel path); {R}:chk_sym_fresh; "
                            f"{R}:chk_truth_pair (Monte Carlo, Gaussian population -0.5 log2(1-rho^2), box limit 2 h_box1 - h_box2); {R}:chk_null; {R}:chk_nonlinear; {R}:chk_frame")
    f["check_data"] = ("iid_gaussian T256 and processes 0-2 at T64/T256/T1024; bivariate_gaussian T1024 and pairs at T64/T256/T1024; var2_bivariate T1024 (pipeline, kernel); delayed_noise T256/T1024; "
                       "nonlinear_dependence, contaminated, logistic_maps T1024; scaled_offset T1024 (pipeline, kernel); trending T1024 (pipeline-detrend)")
    f["agreement_criterion"] = EXACT_CRIT + "; null: |mean over pairs - Monte Carlo mean| <= 2 Monte Carlo SD"
    f["closeness"] = (
        "Numpy: 10/10 exact runs pass, max_abs <= 1.6e-15 (kernel path 7.8e-16, pipeline-detrend 7.8e-16); raw scaled_offset on the kernel path = MI of the unscaled D2 rows (6.7e-16). Symmetry: fresh fills max|D - D.T| = 0.0. "
        "Convergence (bits): rho = 0.3: 0.777 / 0.297 / 0.122 at T = 64 / 256 / 1024 vs truth 0.0680 (box limit 0.0679); rho = 0.8: 1.297 / 0.898 / 0.775 vs truth 0.7370 (box limit 0.7338) (max_z <= 1.75). "
        "Null (iid, 3 pairs): 0.693 / 0.242 / 0.099 vs Monte Carlo 0.762 / 0.280 / 0.090 (|z| <= 1.58). nonlinear_dependence: MI(0,1) = 1.646, MI(2,3) = 1.205 vs cross pairs <= 0.032 (Pearson-based Gaussian MI 0.00015 / 0.0011 bits). "
        "CalculatorFrame identical to Calculator (0.0).")
    f["verdict"] = "matches"
    f["score_0_10"] = 9
    f["what_changed"] = (
        "Box-kernel MI <log2(N C_xy / (C_x C_y))> in bits with half-width 0.25 SD per variable (JIDT's MI kernel: normaliseData is a no-op, widths follow each column's N-1 SD), as documented by the identifier; conventions only (anchor 9). "
        "Strong positive small-sample bias (0.69 bits under independence at T = 64, 0.10 at T = 1024), so values are not comparable across T; finite-sample bias is not scored. "
        "new_finding is false: the copy path leaves this SPI unchanged only because 0.25 equals JIDT's default width, and the bare except with a 'Cholesky' message (infotheory.py:279-283) is an error-message issue without value impact.")
    f["new_finding"] = False
    f["definition_under_review"] = False
    f["check_cost"] = CHEAP
    f["symmetry_observed"] = "sym: max|A - A.T| = 0.0 on all 10 numpy runs; fresh unmirrored fills max|D - D.T| = 0.0 (var2_bivariate T1024, delayed_noise T256): the estimator is symmetric"
    f["direction_observed"] = "undirected: A[i,j] = A[j,i] = I(x_i; x_j) at zero lag (bits)"
    f["candidate_resolutions"] = [
        cr("positive small-sample bias under independence comparable to real dependence", "confirmed",
           "infotheory.mi.kernel|iid_gaussian|64/256/1024|pipeline|null: 0.693 / 0.242 / 0.099 bits (Monte Carlo 0.762 / 0.280 / 0.090) vs rho = 0.3 truth 0.068; estimator property (README: finite-sample bias is not incorrectness)"),
        cr("bare except returns NaN with an irrelevant 'Cholesky' message", "confirmed",
           "code reading at HEAD a42ebc1: pyspi/statistics/infotheory.py:279-283 'except:' -> logging.warning('MI calcs failed. Maybe check input data for Cholesky factorisation?') -> NaN; no check run triggered it (no exception on any dataset); no value impact"),
        cr("copy path leaves mi unchanged only because 0.25 is JIDT's default width", "confirmed",
           "infotheory.mi.kernel|bivariate_gaussian|256|pipeline|frame (frame - Calculator 0.0, all slices = numpy) and infotheory.est.kernel|bivariate_gaussian|256|pipeline|copy-props (deepcopy width 0.25)"),
    ]
    f["checks_run"] = checks_run(uid)
    setfields(uid, f)


# ------------------------------------------------------------------ tlmi
def tlmi():
    uid = "infotheory.tlmi.kernel"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_numpy -> {KI}:mi_box_kernel(z_i[:-1], z_j[1:], 0.25) (bits); {R}:chk_direction (ground truth; var2_bivariate against the Gaussian population ordering); "
                            f"{R}:chk_truth_model (Monte Carlo; Gaussian lag-1 MI from Gamma(1) or 0.5 log2(101) for delayed_noise); {R}:chk_null; {R}:chk_frame")
    f["check_data"] = "iid_gaussian T256 and processes 0-2 at T64/T256/T1024; var2_bivariate, delayed_noise, gauss_ar1_pair, logistic_maps, logistic_maps_chaotic T1024; delayed_noise (0,1) and gauss_ar1_pair at T256/T1024; scaled_offset T1024 (kernel); trending T1024 (pipeline-detrend); bivariate_gaussian T256 (frame)"
    f["agreement_criterion"] = EXACT_CRIT + "; null: |mean over pairs - Monte Carlo mean| <= 2 Monte Carlo SD"
    f["closeness"] = (
        "Numpy: 8/8 exact runs pass, max_abs <= 2.2e-15. Direction: delayed_noise A[0,1] = 2.647 vs A[1,0] = 0.064; var2_bivariate 0.305 vs 0.101 (population 0.222 vs 0.0017); logistic_maps_chaotic 0.144 vs 0.032. "
        "Convergence (bits): delayed_noise pair population 3.329 (0.5 log2 101) vs pyspi 2.606 / 2.647 at T = 256 / 1024 (Monte Carlo 2.648 / 2.665: the 0.25-SD box saturates for this near-deterministic pair); "
        "gauss_ar1_pair population 0.183 / 0.251 vs pyspi 0.375 / 0.398 (T256) and 0.228 / 0.363 (T1024). Null (iid): 0.715 / 0.270 / 0.094 vs Monte Carlo 0.771 / 0.280 / 0.091. "
        "Statistical: 3/4 pass; delayed_noise T1024 fails at max_z 2.16 (pyspi 2.647 vs Monte Carlo 2.665; family calibration 8/130 entries beyond 2 SD vs 5.9 expected). CalculatorFrame identical to Calculator.")
    f["verdict"] = "matches"
    f["score_0_10"] = 9
    f["what_changed"] = (
        "Lag-one box-kernel MI I(x_i(t-1); x_j(t)) in bits on T-1 aligned samples, width 0.25 SD; conventions only (anchor 9). The asymmetry is REVIEW M8. Large small-sample bias; for near-deterministic pairs the 0.25-SD box "
        "caps the estimate well below the Gaussian value (2.65 vs 3.33 bits). new_finding false: the supplement/GitBook keyword conflict elaborates M8, the bare except is message-only, the copy path does not change this SPI.")
    f["new_finding"] = False
    f["definition_under_review"] = False
    f["check_cost"] = CHEAP
    f["symmetry_observed"] = "asym: max|A - A.T| = 2.58 (delayed_noise), 0.204 (var2_bivariate), 0.134 (gauss_ar1_pair), 0.112 (logistic_maps_chaotic), 0.093 (iid T256)"
    f["direction_observed"] = "A[i,j] = I(x_i(t-1); x_j(t)): row i lagged source, column j present target. delayed_noise A[0,1] = 2.647 >> A[1,0] = 0.064 (A[0,2], A[0,3] 0.086 / 0.076 at the null level: lags 3, 5 invisible); var2_bivariate 0.305 > 0.101; logistic_maps_chaotic 0.144 > 0.032"
    f["candidate_resolutions"] = [
        cr("supplement 'undirected' vs GitBook 'directed' vs Directed code", "confirmed",
           "infotheory.tlmi.kernel|*|direction (asymmetric, max|A - A.T| up to 2.58); documentation reading supplement 1.4.4 vs GitBook information-theory.md:243; the asymmetry is REVIEW M8, so recorded as an elaboration, not a new finding"),
        cr("bare except returns NaN with an irrelevant 'Cholesky' message", "confirmed",
           "code reading at HEAD a42ebc1: pyspi/statistics/infotheory.py:313-317; no exception occurred in any check run; no value impact"),
        cr("copy path leaves tlmi unchanged only because 0.25 is JIDT's default width", "confirmed",
           "infotheory.tlmi.kernel|bivariate_gaussian|256|pipeline|frame (frame - Calculator 0.0) and infotheory.est.kernel|bivariate_gaussian|256|pipeline|copy-props"),
    ]
    f["checks_run"] = checks_run(uid)
    setfields(uid, f)


# ------------------------------------------------------------------ te
def te():
    uid = "infotheory.te.kernel_k-1_kt-1_l-1_lt-1"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_numpy -> {KI}:te_box_kernel(z_i, z_j, k=1, width=0.25) (next box reuses the past width; own-SD variant as extra); {R}:te_forwarding_ref and chk_forwarding_flags; "
                            f"{R}:chk_direction; {R}:chk_truth_model (Monte Carlo; Gaussian TE from companion-form Lyapunov Gamma(h)); {R}:chk_null; {R}:chk_frame")
    f["check_data"] = "iid_gaussian T256 and processes 0-2 at T64/T256/T1024; var2_bivariate T256/T1024 (pipeline, kernel); delayed_noise, gauss_ar1_pair, logistic_maps, logistic_maps_chaotic, logistic_maps_sugihara T1024; scaled_offset T1024 (kernel); trending T1024 (pipeline-detrend); bivariate_gaussian T256 (frame)"
    f["agreement_criterion"] = EXACT_CRIT + "; null: |mean over pairs - Monte Carlo mean| <= 2 Monte Carlo SD"
    f["closeness"] = (
        "Numpy: 10/10 exact runs pass, max_abs <= 1.3e-15; giving the next-value box its own SD would change values by <= 0.0049 bits. Forwarding: five (l_history, k_tau, l_tau) variants all equal numpy k = l = 1 (3.3e-16), "
        "all five identifiers read te_kernel_W-0.25_k-1, setProperty raises for l_HISTORY / k_TAU / l_TAU, auto-embed gives identifier _k-max-4 with k_HISTORY 1 and the fixed-k value (difference 0.0). "
        "Direction: delayed_noise 2.571 vs 0.501; var2_bivariate 0.577 vs 0.484 (T1024), 1.122 vs 0.851 (T256); logistic_maps_chaotic 0.134 vs 0.018; logistic_maps_sugihara 0.147 vs 0.031. "
        "Convergence (bits): var2_bivariate population 0.191 / 0.015 vs pyspi 0.577 / 0.484 (T1024); gauss_ar1_pair 0.039 / 0.076 vs 0.348 / 0.390. Null (iid): 1.512 / 1.062 / 0.502 at T = 64 / 256 / 1024 vs Monte Carlo 1.396 / 1.051 / 0.502. "
        "Statistical: 2/3 pass; var2_bivariate T256 fails at max_z 2.48 (family calibration 8/130 entries beyond 2 SD vs 5.9 expected). CalculatorFrame identical to Calculator.")
    f["verdict"] = "matches"
    f["score_0_10"] = 9
    f["what_changed"] = (
        "Schreiber transfer entropy with k = l = 1, lag 1, box kernel of half-width 0.25 SD, bits, as JIDT's TransferEntropyCalculatorKernel computes it; conventions only (anchor 9), including JIDT's reuse of the past-value width "
        "for the next-value box (<= 0.005 bits). Null bias dominates at practical T (0.50 bits at T = 1024 vs the 0.19-bit population effect on var2_bivariate). Outside the configured unit: for estimator='kernel' pyspi forwards only "
        "k_history; l_history, k_tau and l_tau are dropped silently and auto_embed_method is accepted but has no effect while the identifier claims _k-max-4 (new finding; no effect on te_kernel_W-0.25_k-1).")
    f["new_finding"] = True
    f["definition_under_review"] = False
    f["check_cost"] = CHEAP
    f["symmetry_observed"] = "asym: max|A - A.T| = 2.07 (delayed_noise), 0.093 (var2_bivariate T1024), 0.042 (gauss_ar1_pair), 0.116 (logistic_maps_chaotic / sugihara), 0.122 (iid T256)"
    f["direction_observed"] = ("A[i,j] = TE(x_i -> x_j): row source, column target. delayed_noise A[0,1] = 2.571 vs A[1,0] = 0.501 (A[0,2], A[0,3] at the null level: k = l = 1 sees only lag 1); var2_bivariate 0.577 > 0.484; "
                               "logistic_maps_chaotic 0.134 > 0.018; logistic_maps_sugihara 0.147 > 0.031")
    f["candidate_resolutions"] = [
        cr("kernel TE forwards only k_HISTORY; l_history, k_tau, l_tau dropped silently", "confirmed",
           "infotheory.te.kernel_k-1_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|forwarding (5 variants = numpy k = l = 1, 3.3e-16) and |forwarding-flags (identifiers identical, setProperty raises for the three names)"),
        cr("auto_embed_method with the kernel estimator is accepted but ignored while the identifier reads _k-max-4", "confirmed",
           "infotheory.te.kernel_k-1_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|forwarding-flags: identifier ends _k-max-4, k_HISTORY 1, value difference to fixed k = 1 0.0 (config entry commented out)"),
        cr("next-value box uses the past-value width", "confirmed",
           "infotheory.te.kernel_k-1_kt-1_l-1_lt-1|*|numpy: reference with w_next = w_past exact (<= 1.3e-15); own-SD variant differs by <= 0.0049 bits (ref_own_next_width_variant_maxabs_diff)"),
        cr("null bias large relative to typical effects", "confirmed",
           "infotheory.te.kernel_k-1_kt-1_l-1_lt-1|iid_gaussian|64/256/1024|pipeline|null: 1.512 / 1.062 / 0.502 bits (Monte Carlo 1.396 / 1.051 / 0.502); estimator property, not scored"),
        cr("copy path leaves te unchanged only because 0.25 is JIDT's default width", "confirmed",
           "infotheory.te.kernel_k-1_kt-1_l-1_lt-1|bivariate_gaussian|256|pipeline|frame (frame - Calculator 0.0); infotheory.est.kernel|bivariate_gaussian|256|pipeline|copy-props"),
    ]
    f["checks_run"] = checks_run(uid)
    setfields(uid, f)


# ------------------------------------------------------------------ xme k1
def xme1():
    uid = "infotheory.xme.kernel_k1"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_numpy -> {KI}:xme_embedding(k=1) + entropy_box_kernel (0.5, bits); {R}:chk_k2_numpy and chk_k2_equals_k1_shifted ({P}:xme_k2); {R}:chk_direction; "
                            f"{R}:chk_truth_iid and chk_truth_model (Monte Carlo; h(N(0,1)) and Gaussian h(x_j(t) | x_i(t-1))); {R}:chk_frame")
    f["check_data"] = "iid_gaussian T256 and pair (0,1) at T64/T256/T1024; delayed_noise, var2_bivariate, gauss_ar1_pair, logistic_maps, logistic_maps_chaotic T1024; scaled_offset T1024 (kernel); trending T1024 (pipeline-detrend); bivariate_gaussian T256 (frame)"
    f["agreement_criterion"] = EXACT_CRIT
    f["closeness"] = (
        "Numpy: 8/8 exact runs pass, max_abs <= 2.7e-14. history_length=2 equals history_length=1 on samples t = 2..T-1 (6.2e-15) and the k = 2 numpy (lag set {1}) (6.2e-15); k2 - k1 <= 3.1e-4, while a genuine two-lag variant "
        "would give 1.746 / 1.923 instead of 1.787 / 2.012. Direction: delayed_noise 0.180 vs 2.024, var2_bivariate 1.787 vs 2.012, logistic_maps_chaotic 1.079 vs 1.801. "
        "Convergence (bits): iid 1.738 / 1.976 / 2.023 at T = 64 / 256 / 1024 vs box limit 2.04935, truth 2.04710 (max_z <= 1.71); gauss_ar1_pair 1.863 / 1.740 vs population 1.864 / 1.796 (max_z 1.62). "
        "CalculatorFrame 1.779358 = numpy width 0.25 vs Calculator 1.981468.")
    f["verdict"] = "related-quantity"
    f["score_0_10"] = 5
    f["what_changed"] = (
        "No documented definition: the code computes the box-kernel conditional entropy H(x_j(t) | x_i(t-1)) in bits (no target past, no cross mapping), exactly as written (rubric anchor 5: non-standard quantity computed as the code states). "
        "history_length = 1 and 2 use the same lag set {1}. CalculatorFrame path: width 0.25 under the W-0.5 identifier (copy path).")
    f["new_finding"] = True
    f["definition_under_review"] = False
    f["check_cost"] = CHEAP
    f["symmetry_observed"] = "asym: max|A - A.T| = 1.84 (delayed_noise), 0.225 (var2_bivariate), 0.124 (gauss_ar1_pair), 0.722 (logistic_maps_chaotic), 0.099 (iid T256)"
    f["direction_observed"] = "A[i,j] = H(x_j(t) | x_i(t-1)): row lagged source, column target; LOW = predictable. delayed_noise A[0,1] = 0.180 vs A[1,0] = 2.024; var2_bivariate 1.787 < 2.012; logistic_maps_chaotic 1.079 < 1.801"
    f["candidate_resolutions"] = [
        cr("undocumented SPI; documented identifiers xme_kernel_k1/k10 differ from the produced ones", "confirmed",
           "documentation reading: no xme entry in supplement 1.4 or GitBook information-theory.md, table-of-spis.md:73 lists xme_kernel_k1 / k10; produced identifier xme_kernel_W-0.5_k1 (units.yaml); same conclusion as infotheory.xme.gaussian_k1"),
        cr("'cross-map entropy' is H(Y_t | X_{t-1}), no cross mapping", "confirmed",
           "infotheory.xme.kernel_k1|*|numpy: reference H([x_i(t-1), x_j(t)]) - H(x_i(t-1)) reproduces pyspi to <= 2.7e-14 on 8 runs"),
        cr("history_length=2 also yields one lag (k1 and k2 differ by one sample)", "confirmed",
           "infotheory.xme.kernel_k1|var2_bivariate|1024|pipeline|k2-equals-k1-shifted (6.2e-15) and |k2-numpy (k2 - k1 <= 3.1e-4; two-lag variant 1.746 vs 1.787)"),
        cr("CalculatorFrame computes xme_k1 at width 0.25 under the W-0.5 identifier", "confirmed",
           "infotheory.xme.kernel_k1|bivariate_gaussian|256|pipeline|frame: frame 1.779358 = numpy width 0.25 vs Calculator 1.981468"),
    ]
    f["checks_run"] = checks_run(uid, {"frame": FRAME_NOTE})
    setfields(uid, f)


# ------------------------------------------------------------------ xme k10
def xme10():
    uid = "infotheory.xme.kernel_k10"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_numpy -> {KI}:xme_embedding(k=10, source lags 1..9) + entropy_box_kernel (0.5, bits), ten-lag variant as extra; {R}:chk_degenerate (fraction of points whose box count is 1); "
                            f"{R}:chk_direction; {R}:chk_truth_iid (Monte Carlo; h(N(0,1))); {R}:chk_frame")
    f["check_data"] = "iid_gaussian T256/T1024 and pair (0,1) at T256/T1024; delayed_noise, var2_bivariate, logistic_maps, logistic_maps_chaotic T1024; scaled_offset T1024 (kernel); bivariate_gaussian T256 (frame)"
    f["agreement_criterion"] = EXACT_CRIT
    f["closeness"] = (
        "Numpy with lags 1..9: 7/7 exact runs pass, max_abs <= 1.2e-12 (kernel path; pipeline <= 3.8e-13); the intended ten-lag variant differs by 0.0 (iid T256: every count is 1, so 9 and 10 lags give the same value), "
        "0.0079-0.0146 (Gaussian data T1024) and 0.060-0.073 (logistic maps). Saturation: fraction of points alone in their 10-D joint box >= 0.990 (delayed_noise), 0.995 (var2_bivariate), 0.998 (iid T1024); "
        "|values| <= 0.024 bits on every stochastic dataset vs truth 2.047 (iid Monte Carlo mean 0.0025 / 0.0068 at T = 256 / 1024). Direction: delayed_noise 0.0058 < 0.0117 (pass, at noise level), var2_bivariate 0.0238 > 0.0094 "
        "(FAIL: reversed), logistic_maps_chaotic 0.977 < 1.777 (pass: low-dimensional deterministic data is not saturated). Statistical: iid T256 fails at max_z 2.05 (family calibration 8/130 beyond 2 SD vs 5.9 expected), T1024 passes. "
        "CalculatorFrame -0.996236 = numpy width 0.25 vs Calculator 0.003764.")
    f["verdict"] = "related-quantity"
    f["score_0_10"] = 4
    f["what_changed"] = (
        "No documented definition; computes H(x_j(t) | x_i(t-1..t-9)) (box kernel, bits): history_length=10 builds 9 source lags (range(2, k)), so the identifier does not describe the lag set (anchor 4, as infotheory.xme.gaussian_k10). "
        "At W-0.5 the 10-D joint and 9-D past boxes contain only the query point for >= 99% of samples at T <= 1024, so on stochastic data the value is ~0 (|v| <= 0.024 bits vs a 2.05-bit truth) whatever the coupling, and the "
        "var2_bivariate ordering is reversed; this saturation is finite-sample behaviour of the configured estimator and is reported as convergence evidence, not as the formula score. CalculatorFrame path: width 0.25 (copy path).")
    f["new_finding"] = True
    f["definition_under_review"] = False
    f["check_cost"] = CHEAP
    f["symmetry_observed"] = "asym but tiny on stochastic data: max|A - A.T| = 0.029 (iid T256), 0.012 (iid T1024), 0.020 (delayed_noise), 0.014 (var2_bivariate); 0.68 / 0.80 on logistic_maps / logistic_maps_chaotic"
    f["direction_observed"] = ("A[i,j] = H(x_j(t) | x_i(t-1..t-9)): row lagged source, column target. No usable direction on stochastic data: delayed_noise A[0,1] = 0.0058 vs A[1,0] = 0.0117, var2_bivariate 0.0238 vs 0.0094 (reversed); "
                               "on logistic_maps_chaotic 0.977 < 1.777 (x -> y recovered)")
    f["candidate_resolutions"] = [
        cr("history_length=10 builds 9 source lags", "confirmed",
           "infotheory.xme.kernel_k10|*|numpy: lags 1..9 reproduce pyspi to <= 1.2e-12 on 7 runs; ten-lag variant differs by up to 0.073 bits (ref_ten_lag_variant_maxabs_diff)"),
        cr("degenerate at W-0.5: counts saturate, value ~0 regardless of dependence", "confirmed",
           "infotheory.xme.kernel_k10|*|degenerate: count-1 fraction >= 0.990 in the joint box, |values| <= 0.024; |truth-iid: pyspi mean -0.0077 / 0.0048 vs truth 2.047; |var2_bivariate|1024|pipeline|direction FAIL (0.0238 > 0.0094)"),
        cr("undocumented SPI / identifier mismatch", "confirmed", "see infotheory.xme.kernel_k1 (documentation reading, table-of-spis.md:73)"),
        cr("CalculatorFrame computes xme_k10 at width 0.25 under the W-0.5 identifier", "confirmed",
           "infotheory.xme.kernel_k10|bivariate_gaussian|256|pipeline|frame: frame -0.996236 = numpy width 0.25 (6.2e-14) vs Calculator 0.003764"),
    ]
    f["checks_run"] = checks_run(uid, {"direction": "var2_bivariate reversed (0.0238 > 0.0094), consistent with count saturation", "frame": FRAME_NOTE})
    setfields(uid, f)


# ------------------------------------------------------------------ cce
def cce():
    uid = "infotheory.cce.kernel"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_numpy -> {KI}:cce_embedding (m = 1..5, x lags 0..m-1, y lags 1..m-1) + entropy_box_kernel (0.5, bits); {R}:chk_n10 ({P}:cce_n10), chk_configured_n; {R}:chk_direction; "
                            f"{R}:chk_truth_iid (Monte Carlo; 5 h(N(0,1)) = 10.235 bits); {R}:chk_gauss_block (Gaussian H(Y^5||X^5) from Lyapunov Gamma(h)); {R}:chk_frame")
    f["check_data"] = "iid_gaussian T256 and pair (0,1) at T64/T256/T1024; delayed_noise, var2_bivariate, gauss_ar1_pair, logistic_maps, logistic_maps_chaotic T1024; var2_bivariate T64 (configured n); scaled_offset T256 (kernel); bivariate_gaussian T256 (frame)"
    f["agreement_criterion"] = EXACT_CRIT
    f["closeness"] = (
        "Numpy: 7/7 exact runs pass, max_abs <= 7.9e-13 (P = 4, T = 1024 sums of 10 box entropies); n = 10 probe = numpy n = 10 (5.7e-13). Configured n = 5 (documented 10); on var2_bivariate n = 10 gives 4.379 / 4.655 vs n = 5 4.384 / 4.659 "
        "(terms 6-10 contribute -0.005). Collapse: iid per-term values at T1024 2.012, 1.702, 0.675, 0.099, 0.012 vs 2.047 each; sums 2.389 / 3.443 / 4.495 at T = 64 / 256 / 1024 vs 10.235 (Monte Carlo 2.470 / 3.493 / 4.484, max_z <= 1.66); "
        "gauss_ar1_pair 4.549 / 4.386 vs Gaussian population 8.387 / 8.025 (kernel terms 1.809, 1.480, 0.962, 0.254, 0.044 vs 1.819, 1.642, 1.642, 1.642, 1.642). Direction: delayed_noise 2.405 < 7.169, var2_bivariate 4.384 < 4.659, "
        "logistic_maps_chaotic 1.361 < 4.184. CalculatorFrame -1.792918 = numpy width 0.25 vs Calculator 3.405063.")
    f["verdict"] = "variant"
    f["score_0_10"] = 7
    f["what_changed"] = (
        "Kramer's causally conditioned entropy H(Y^5 || X^5) with the box kernel in bits, exactly as coded (present x in every term), but with n = 5 terms where the supplement and GitBook document 10 (anchor 7, as infotheory.cce.gaussian). "
        "At W-0.5 the terms of order m >= 3 (6-10-D boxes) collapse towards 0 at T <= 1024, so the value mostly reflects terms 1-2 and grows with T (2.39 -> 4.50 bits for T = 64 -> 1024 against 10.24): finite-sample behaviour reported "
        "as convergence evidence; with n = 10 the extra terms are ~0, so the documented history length would not change the kernel value. CalculatorFrame path: width 0.25, values become negative (copy path).")
    f["new_finding"] = True
    f["definition_under_review"] = False
    f["check_cost"] = "cheap to moderate: pyspi <= 5.5 s per run (P = 5, T = 256; ten box entropies per ordered pair); numpy reference up to ~25 s for P = 4, T = 1024 (O(T^2) counting); T <= 1024"
    f["symmetry_observed"] = "asym: max|A - A.T| = 4.76 (delayed_noise), 0.275 (var2_bivariate), 0.163 (gauss_ar1_pair), 2.82 (logistic_maps_chaotic), 0.169 (iid T256)"
    f["direction_observed"] = "A[i,j] = H(x_j^5 || x_i^5): column j target, row i causally conditioning source; lower = more explained. delayed_noise A[0,1] = 2.405 < A[1,0] = 7.169; var2_bivariate 4.384 < 4.659; logistic_maps_chaotic 1.361 < 4.184"
    f["candidate_resolutions"] = [
        cr("history length 5 in code vs 10 documented", "confirmed",
           "infotheory.cce.kernel|var2_bivariate|64|pipeline|configured-n (n = 5); |var2_bivariate|1024|pipeline|n10 (numpy n = 10 exact; 4.379 vs 4.384)"),
        cr("estimator collapse of terms m >= 3 at W-0.5", "confirmed",
           "infotheory.cce.kernel|iid_gaussian|1024|pipeline|truth-iid (terms 2.012, 1.702, 0.675, 0.099, 0.012 vs 2.047); |gauss_ar1_pair|1024|pipeline|gauss-block (4.549 vs 8.387)"),
        cr("m = 1 term relies on makeDelayEmbeddingVector(targ, 0) returning T+1 zero-width rows", "confirmed",
           "infotheory.cce.kernel|*|numpy: the reference builds the m = 1 term with an empty y-past block (cce_embedding) and reproduces pyspi on 6 runs; works as coded, robustness depends on JIDT accepting k = 0"),
        cr("CalculatorFrame computes cce at width 0.25 under the W-0.5 identifier", "confirmed",
           "infotheory.cce.kernel|bivariate_gaussian|256|pipeline|frame: frame -1.792918 = numpy width 0.25 (1.4e-13) vs Calculator 3.405063"),
    ]
    f["checks_run"] = checks_run(uid, {"frame": FRAME_NOTE})
    setfields(uid, f)


# ------------------------------------------------------------------ di
def di():
    uid = "infotheory.di.kernel"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_numpy -> sum_m entropy_box_kernel(embed(z_j, m))/m - cce ({KI}, 0.5, bits); {R}:chk_massey_identity (box-kernel Massey DI_5 + B(target)); {R}:chk_indep_numpy and chk_indep_gap "
                            f"({P}:di_indep_pair; analytic Gaussian B of the AR(2) target); {R}:chk_n10 ({P}:di_n10); {R}:chk_truth_iid (Monte Carlo; population 0); {R}:chk_direction; {R}:chk_frame")
    f["check_data"] = "iid_gaussian T256 and pair (0,1) at T64/T256/T1024; delayed_noise, var2_bivariate, gauss_ar1_pair, logistic_maps_chaotic T1024; constructed independent pair [iid_gaussian row 0, var2_bivariate row 0] T1024; scaled_offset T256 (kernel); bivariate_gaussian T256 (frame)"
    f["agreement_criterion"] = EXACT_CRIT
    f["closeness"] = (
        "Numpy (pyspi form): 8/8 exact runs pass, max_abs <= 8.0e-13 (incl. n = 10 6.1e-13 and the independent pair 5.3e-13). Identity on var2_bivariate T1024: pyspi = box Massey DI_5 + B(target) to 0.0, Massey 4.317 / 4.015 vs pyspi 5.199 / 4.860, "
        "B = 0.882 (target x1) / 0.846 (target x0). Independent white source -> AR(2) target: pyspi 5.098, box Massey 4.252, B_box 0.846, but B_box of the white source is 0.860 and the Gaussian population B of the AR(2) target is 0.255, "
        "so with this estimator the block-rate excess is swamped by the dimension-dependent box bias (the definitional gap is established analytically in infotheory.di.gaussian|var2_bivariate|4096|pipeline|indep-truth). "
        "Independent white pairs: 5.55 / 5.83 / 5.31 bits at T = 64 / 256 / 1024 vs population 0 (Monte Carlo 5.66 / 5.73 / 5.32, max_z <= 1.29); box Massey form 3.50 / 4.27 / 4.45. n = 10: 11.52 / 11.18 vs n = 5: 5.20 / 4.86. "
        "Direction: delayed_noise 7.419 > 2.647, var2_bivariate 5.199 > 4.860, logistic_maps_chaotic 1.675 > 1.612. CalculatorFrame 8.687720 = numpy width 0.25 vs Calculator 5.823513.")
    f["verdict"] = "related-quantity"
    f["score_0_10"] = 4
    f["what_changed"] = (
        "First term is sum_{m=1..5} H(Y^m)/m (block entropy per symbol), not H(Y^5) (rubric anchor 4, 'DI with block-entropy rate', as infotheory.di.gaussian); history length 5 instead of the documented 10. "
        "With the W-0.5 box kernel the magnitude is dominated by estimator bias: about 5.3-5.8 bits between independent white series at T <= 1024 (truth 0), because the cce terms of order >= 3 collapse while the "
        "block-entropy terms do not; the coupled-vs-reverse ordering survives on delayed_noise, var2_bivariate and logistic_maps_chaotic. CalculatorFrame path: width 0.25 (copy path).")
    f["new_finding"] = True
    f["definition_under_review"] = False
    f["check_cost"] = "cheap to moderate: pyspi <= 2.8 s per SPI run (P <= 5, T <= 1024), 12.1 s for the CalculatorFrame probe; numpy reference up to ~30 s for P = 4, T = 1024 (O(T^2) counting); T <= 1024"
    f["symmetry_observed"] = "asym: max|A - A.T| = 4.77 (delayed_noise), 0.339 (var2_bivariate), 0.113 (gauss_ar1_pair), 0.063 (logistic_maps_chaotic), 0.121 (iid T256)"
    f["direction_observed"] = "A[i,j] = DI(x_i -> x_j) as pyspi defines it (block rate of target j minus cce(i -> j)). delayed_noise A[0,1] = 7.419 > A[1,0] = 2.647; var2_bivariate 5.199 > 4.860; logistic_maps_chaotic 1.675 > 1.612 (all values sit on a ~5-bit bias floor)"
    f["candidate_resolutions"] = [
        cr("target term sum_m H(Y^m)/m instead of H(Y^5)", "confirmed",
           "infotheory.di.kernel|var2_bivariate|1024|pipeline|massey-identity (pyspi = box Massey + B(target) to 0.0, B 0.882 / 0.846); estimator-free confirmation in infotheory.di.gaussian|var2_bivariate|1024|pipeline|massey-identity and |4096|pipeline|indep-truth (it_gaussian family)"),
        cr("history length 5 vs documented 10", "confirmed",
           "infotheory.cce.kernel|var2_bivariate|64|pipeline|configured-n (di_n = 5); infotheory.di.kernel|var2_bivariate|1024|pipeline|n10 (11.52 / 11.18 vs 5.20 / 4.86)"),
        cr("degenerate magnitude: 4.6-5.8 bits between independent white series", "confirmed",
           "infotheory.di.kernel|iid_gaussian|64/256/1024|pipeline|truth-iid: 5.55 / 5.83 / 5.31 bits vs 0 (Monte Carlo 5.66 / 5.73 / 5.32); box Massey form also 3.50-4.45, i.e. mostly cce-term collapse; ordering preserved (|direction runs)"),
        cr("CalculatorFrame computes di at width 0.25 under the W-0.5 identifier", "confirmed",
           "infotheory.di.kernel|bivariate_gaussian|256|pipeline|frame: frame 8.687720 = numpy width 0.25 (1.4e-13) vs Calculator 5.823513"),
    ]
    f["checks_run"] = checks_run(uid, {"frame": FRAME_NOTE})
    setfields(uid, f)


# ------------------------------------------------------------------ si
def si():
    uid = "infotheory.si.kernel"
    f = {}
    f["check_method"] = "independent-impl"
    f["check_reference"] = (f"{R}:chk_numpy -> box H(x_t|x_t-1) + H(y_t|y_t-1) - H(xy_t|xy_t-1) ({KI}:entropy_box_kernel, 0.5, bits); {R}:chk_sym_fresh; {R}:chk_truth_model (Monte Carlo; Ay SI of the Gaussian VAR(1)); "
                            f"{R}:chk_null; {R}:chk_frame")
    f["check_data"] = "iid_gaussian T256 and processes 0-2 at T64/T256/T1024; gauss_ar1_pair T256/T1024; var2_bivariate, delayed_noise, logistic_maps T1024; scaled_offset T1024 (kernel); trending T1024 (pipeline-detrend); bivariate_gaussian T256 (frame)"
    f["agreement_criterion"] = EXACT_CRIT + "; null: |mean over pairs - Monte Carlo mean| <= 2 Monte Carlo SD"
    f["closeness"] = (
        "Numpy: 7/7 exact runs pass, max_abs <= 7.4e-14. Symmetry: fresh fills max|D - D.T| = 0.0 (var2_bivariate T1024, delayed_noise T256). Convergence (bits): gauss_ar1_pair population 0.144 vs pyspi 0.728 / 0.322 at T = 256 / 1024 "
        "(Monte Carlo 0.678 / 0.343, max_z <= 0.94). Null (iid): 1.743 / 0.930 / 0.400 at T = 64 / 256 / 1024 vs Monte Carlo 1.694 / 0.937 / 0.403. CalculatorFrame 3.287689 = numpy width 0.25 vs Calculator 0.996235.")
    f["verdict"] = "matches"
    f["score_0_10"] = 9
    f["what_changed"] = (
        "Ay's stochastic interaction with one-step conditional entropies, box kernel W-0.5, bits, individual minus joint (non-negative orientation); conventions only (anchor 9). Null bias exceeds the population effect "
        "on gauss_ar1_pair until T > 1024. CalculatorFrame path: width 0.25 under the W-0.5 identifier (copy path, new finding).")
    f["new_finding"] = True
    f["definition_under_review"] = False
    f["check_cost"] = CHEAP
    f["symmetry_observed"] = "sym: max|A - A.T| = 0.0 on all 7 numpy runs; fresh unmirrored fills max|D - D.T| = 0.0: the formula is symmetric because max-norm box counts do not depend on column order"
    f["direction_observed"] = "undirected: A[i,j] = A[j,i] = SI(x_i, x_j) (bits)"
    f["candidate_resolutions"] = [
        cr("null bias comparable to coupling effects, T-dependent", "confirmed",
           "infotheory.si.kernel|iid_gaussian|64/256/1024|pipeline|null: 1.743 / 0.930 / 0.400 (Monte Carlo 1.694 / 0.937 / 0.403) vs gauss_ar1_pair population 0.144; estimator property, not scored"),
        cr("'_k-1' suffix denotes the delay tau, not a history length", "confirmed",
           "code reading at HEAD a42ebc1: pyspi/statistics/infotheory.py:519-522 (identifier += f'_k-{delay}'); numpy reference with tau = 1 reproduces all runs; label semantics only"),
        cr("CalculatorFrame computes si at width 0.25 under the W-0.5 identifier", "confirmed",
           "infotheory.si.kernel|bivariate_gaussian|256|pipeline|frame: frame 3.287689 = numpy width 0.25 (2.3e-14) vs Calculator 0.996235"),
    ]
    f["checks_run"] = checks_run(uid, {"frame": FRAME_NOTE})
    setfields(uid, f)


if __name__ == "__main__":
    for fn in (est, je, ce, mi, tlmi, te, xme1, xme10, cce, di, si):
        fn()
    print("records updated")
