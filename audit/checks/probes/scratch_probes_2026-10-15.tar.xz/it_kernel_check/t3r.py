import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import _kernels_infotheory as K
g = [0., 1., 2., 3., 10.]
for w in (1 - 1e-6, 1.0, 1 + 1e-6, 2.0): print('H grid', w, repr(K.entropy_box_kernel(g, w, normalise=False)))
G2 = np.array([[a, b] for a in (0., 1., 2.) for b in (0., 2., 5.)])
for w in (1 - 1e-6, 1.0, 2.0): print('H2 grid', w, repr(K.entropy_box_kernel(G2, w, normalise=False)))
print('MI', repr(K.mi_box_kernel(g, g, 1.0, normalise=False)), repr(K.mi_box_kernel(g, [0., 2., 1., 3., 4.], 1.0, normalise=False)))
s = np.array([0., 1, 2, 1, 0, 3, 2, 1, 0, 1]); t = np.array([1., 0, 1, 2, 1, 0, 3, 2, 1, 0])
print('TE', repr(K.te_box_kernel(s, t, 1, 1.0, normalise=False)), repr(K.te_box_kernel(s, t, 1, 1 - 1e-6, normalise=False)))
q = np.round(np.arange(0, 3.01, 0.1), 10)
print('H 0.1grid', repr(K.entropy_box_kernel(q, 0.1, normalise=False)))
q2 = np.arange(31) * 0.1
print('H 0.1grid arange', repr(K.entropy_box_kernel(q2, 0.1, normalise=False)))
