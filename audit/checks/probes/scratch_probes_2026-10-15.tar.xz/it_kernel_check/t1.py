import sys, time, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import make_data, _kernels_infotheory as K
H=K.entropy_box_kernel
def zs(x):
    m=x.mean(-1,keepdims=True); s=np.sqrt(((x-m)**2).sum(-1,keepdims=True)/(x.shape[-1]-1)); return (x-m)/s
def ce(Y,X,w=0.5): return H(np.hstack([K._as2d(Y),K._as2d(X)]),w)-H(X,w)
def cce(a,b,n=5,w=0.5):
    s=0
    for i in range(1,n+1):
        Yf,Yp,Xp=K.cce_embedding(a,b,i); s+=ce(Yf,np.hstack([Yp,Xp]),w)
    return s
def di(a,b,n=5,w=0.5): return sum(H(K.embed(b,i),w)/i for i in range(1,n+1))-cce(a,b,n,w)
def xme(a,b,k,w=0.5):
    Yf,Xp=K.xme_embedding(a,b,k); return ce(Yf,Xp,w)
def si(a,b,w=0.5):
    a,b=a[:,None],b[:,None]; xy=np.hstack([a,b])
    return ce(a[1:],a[:-1],w)+ce(b[1:],b[:-1],w)-ce(xy[1:],xy[:-1],w)
F={'cce':cce,'di':di,'xme.kernel_k1':lambda a,b:xme(a,b,1),'xme.kernel_k10':lambda a,b:xme(a,b,10),'si':si,
   'te.kernel_k-1_kt-1_l-1_lt-1':lambda a,b:K.te_box_kernel(a,b,1,0.25),'mi':lambda a,b:K.mi_box_kernel(a,b,0.25),
   'tlmi':lambda a,b:K.mi_box_kernel(a[:-1],b[1:],0.25),'je':lambda a,b:H(np.stack([a,b],1),0.5),'ce':lambda a,b:ce(b,a)}
x=make_data.load('var2_bivariate',1024)['x']; z=zs(x)
for u,f in F.items():
    uid = 'infotheory.'+u+('' if ('kernel' in u) else '.kernel')
    S=np.load(f'/media/dan/Data/git/pyspi/audit/checks/out/pyspi/{uid}|var2_bivariate|1024|pipeline|numpy.npz')['value']
    t=time.time(); V=np.array([[np.nan,f(z[0],z[1])],[f(z[1],z[0]),np.nan]]); dt=time.time()-t
    print(u, np.nanmax(np.abs(S-V)), round(dt,2), S[0,1],S[1,0])
