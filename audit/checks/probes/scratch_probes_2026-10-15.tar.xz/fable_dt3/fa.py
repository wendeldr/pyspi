import sys, warnings, numpy as np, time, io, contextlib
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
import pyspi.statistics.causal as C
from cdt.causality.pairwise import ANM
from cdt.causality.pairwise.ANM import normalized_hsic
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel as CK
np.set_printoptions(precision=4, suppress=True, linewidth=150)
base='/media/dan/Data/git/pyspi/audit/checks/data/'
def quiet(f,*a,**k):
    with contextlib.redirect_stdout(io.StringIO()): return f(*a,**k)
print('patched', ANM.anm_score is C.AdditiveNoiseModel.corrected_anm_score)
def hsic_scratch(a,b,maxpnt=200):
    a=a.ravel(); b=b.ravel()
    a=(a-a.mean())/a.std(); b=(b-b.mean())/b.std()
    m=len(a)
    if m>maxpnt:
        idx=np.floor(np.arange(0,m,(m-1)/(maxpnt-1))).astype(int); a=a[idx]; b=b[idx]; m=len(a)
    def K(v):
        D2=(v[:,None]-v[None,:])**2
        iu=np.triu_indices(m,1); dd=D2[iu]; s2=0.5*np.median(dd[dd>0])
        return np.exp(-D2/(2*s2))
    H=np.eye(m)-1.0/m
    return np.sum((H@K(a)@H)*(H@K(b)@H))/m
x=np.load(base+'anm_T256.npz')['x']; D=quiet(Data,x); z=D.to_numpy()
t=time.time(); A=quiet(C.AdditiveNoiseModel().multivariate, D); print('anm_T256 time',round(time.time()-t,1)); print(A)
gp=GaussianProcessRegressor(random_state=42).fit(z[0],z[1]); r=gp.predict(z[0]).reshape(-1,1)-z[1]
print('kernel_',gp.kernel_,'resid std',r.std(),'y std',z[1].std(),'R2',1-r.var()/z[1].var())
c2=gp.kernel_.k1.constant_value
print('median r/(-1e-10 y/c2)',np.median(r.ravel()/(-1e-10*z[1].ravel()/c2)),'corr(r,y)',np.corrcoef(r.ravel(),z[1].ravel())[0,1])
hs=hsic_scratch(r,z[0]); print('scratch hsic(r,x)',repr(hs),'pyspi A01',repr(A[0,1]),'equal',hs==A[0,1])
print('rs effect',np.abs(GaussianProcessRegressor(random_state=7).fit(z[0],z[1]).predict(z[0])-gp.predict(z[0])).max())
print('true pairs: A01 vs A10',A[0,1],A[1,0],' A23 vs A32',A[2,3],A[3,2])
for name,T in [('anm',64),('iid_gaussian',256),('nonlinear_dependence',256)]:
    x=np.load(f'{base}{name}_T{T}.npz')['x']; D=quiet(Data,x); z=D.to_numpy(); P=z.shape[0]
    A=quiet(C.AdditiveNoiseModel().multivariate, D)
    Hm=np.full((P,P),np.nan)
    for i in range(P):
        for j in range(P):
            if i!=j: Hm[i,j]=hsic_scratch(z[j],z[i])
    rel=np.abs(A-Hm)/Hm
    print(name,T,'max rel |A-H|/H',np.nanmax(rel),'equal to 4dp',int(np.sum(np.round(A,4)==np.round(Hm,4))),'of',P*(P-1),'max|A-A.T|',np.nanmax(np.abs(A-A.T)))
    if name=='anm': print(A); print(Hm)
    for i in range(P):
        for j in range(P):
            if i!=j and (name=='anm' or (i,j) in [(0,1),(1,0)]):
                gp=GaussianProcessRegressor(random_state=42).fit(z[i],z[j]); r=gp.predict(z[i]).reshape(-1,1)-z[j]
                print('  ',i,j,gp.kernel_,'corr(r,y)=%.3f'%np.corrcoef(r.ravel(),z[j].ravel())[0,1],'resid std %.2e'%r.std())
x=np.load(base+'anm_T1024.npz')['x']; D=quiet(Data,x); z=D.to_numpy()
t=time.time(); s=C.AdditiveNoiseModel(); a01=quiet(s.bivariate, D,i=0,j=1); a10=quiet(s.bivariate, D,i=1,j=0); print('anm_T1024 A01',a01,'A10',a10,'time',round(time.time()-t,1))
gp=GaussianProcessRegressor(random_state=42).fit(z[0],z[1]); print(' kernel',gp.kernel_)
for T in (64,1024):
    x=np.load(f'{base}anm_T{T}.npz')['x']; z=quiet(Data,x).to_numpy(); out=[]
    for (i,j) in [(0,1),(1,0)]:
        g=GaussianProcessRegressor(kernel=CK()*RBF()+WhiteKernel(),random_state=42).fit(z[i],z[j]); rr=g.predict(z[i]).reshape(-1,1)-z[j]
        out.append((round(float(normalized_hsic(rr,z[i])),4), str(g.kernel_)))
    print('WhiteKernel anm T',T,'0->1 then 1->0:',out)
x=np.load(f'{base}nonlinear_dependence_T256.npz')['x']; z=quiet(Data,x).to_numpy(); out=[]
for (i,j) in [(0,1),(1,0)]:
    g=GaussianProcessRegressor(kernel=CK()*RBF()+WhiteKernel(),random_state=42).fit(z[i],z[j]); rr=g.predict(z[i]).reshape(-1,1)-z[j]
    out.append(round(float(normalized_hsic(rr,z[i])),4))
print('WhiteKernel nonlinear_dependence_T256 0->1,1->0',out)
