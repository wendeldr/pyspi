import sys, warnings, numpy as np, io, contextlib
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
import pyspi.statistics.causal as C
from scipy.special import digamma
np.set_printoptions(precision=5, suppress=True, linewidth=150)
base='/media/dan/Data/git/pyspi/audit/checks/data/'
def quiet(f,*a,**k):
    with contextlib.redirect_stdout(io.StringIO()): return f(*a,**k)
def load(n,T): return np.load(f'{base}{n}_T{T}.npz')['x']
def reci_ref(x,y):
    x=x.ravel(); y=y.ravel(); x=(x-x.min())/(x.max()-x.min()); y=(y-y.min())/(y.max()-y.min())
    X=np.c_[np.ones_like(x),x**3]; b=np.linalg.solve(X.T@X, X.T@y); return np.mean((X@b-y)**2)
def Sh(v):
    v=v.ravel(); v=(v-v.mean())/v.std(); d=np.diff(np.sort(v)); d=d[d!=0]
    return np.sum(np.log(d))/(len(v)-1)+digamma(len(v))-digamma(1)
def cds_ref(x,y,ff=2,md=3,minc=12):
    x=x.ravel(); y=y.ravel()
    xs=(x-x.mean())/x.std(); xf=xs[np.abs(xs)<md]; xs=(xs-xf.mean())/xf.std()
    xd=np.clip(np.round(xs*ff),-ff*md,ff*md); rows=[]
    for a in np.unique(xd):
        m=xd==a
        if m.sum()>minc:
            yx=(y[m]-y[m].mean())/y.std(); yd=np.clip(np.round(yx*ff),-ff*md,ff*md)
            p=np.array([(yd==k).sum() for k in range(-ff*md,ff*md+1)],float); rows.append(p/p.sum())
    if not rows: return 0.0
    P=np.array(rows); P=P-P.mean(0); return np.sqrt(np.mean(P**2))
for name,T in [('anm',64),('anm',256),('anm',1024),('iid_gaussian',64),('nonlinear_dependence',256)]:
    D=quiet(Data,load(name,T)); z=D.to_numpy(); P=z.shape[0]
    print('=====',name,T)
    for cls,ref in [(C.RegressionErrorCausalInference,reci_ref),(C.InformationGeometricConditionalIndependence,lambda a,b:Sh(a)-Sh(b)),(C.ConditionalDistributionSimilarity,cds_ref)]:
        A=quiet(cls().multivariate,D); R=np.full((P,P),np.nan)
        for i in range(P):
            for j in range(P):
                if i!=j: R[i,j]=ref(z[i],z[j])
        print(cls.identifier,'maxdiff',np.nanmax(np.abs(A-R)),'max|A+A.T|',np.nanmax(np.abs(A+A.T)),'min',np.nanmin(A),'max',np.nanmax(A),'zeros',int(np.sum(A==0)))
        if cls.identifier=='cds' or name=='anm': print(A)
for name in ('anm','iid_gaussian'):
    z=quiet(Data,load(name,64)).to_numpy()
    for i in range(z.shape[0]):
        xs=z[i].ravel(); xs=(xs-xs.mean())/xs.std(); xf=xs[np.abs(xs)<3]; xs=(xs-xf.mean())/xf.std(); xd=np.clip(np.round(xs*2),-6,6)
        cnt=np.unique(xd,return_counts=True)[1]; print(name,'T64 proc',i,'max x-bin count',cnt.max(),'-> all-zero row expected',cnt.max()<=12)
for seed in (0,1):
    rng=np.random.default_rng(seed)
    for T in (256,1024,4096):
        x=rng.uniform(0,1,T); y=x**3
        v=quiet(C.InformationGeometricConditionalIndependence().bivariate,x,y); vr=quiet(C.InformationGeometricConditionalIndependence().bivariate,y,x)
        print('igci seed',seed,'T',T,'A[x,y]',v,'A[y,x]',vr,'sum',v+vr)
print('analytic -C^G',-(np.log(3)-2+np.log(1/np.sqrt(12))-np.log(np.sqrt(1/7-1/16))))
x=load('anm',1024); D=quiet(Data,x); z=D.to_numpy()
A=quiet(C.InformationGeometricConditionalIndependence().multivariate,D)
b01=quiet(C.InformationGeometricConditionalIndependence().bivariate,x[0],x[1]); b10=quiet(C.InformationGeometricConditionalIndependence().bivariate,x[1],x[0])
print('igci multivariate A01+A10',A[0,1]+A[1,0],'| raw bivariate b01+b10',b01+b10,'| b01',b01,'A01',A[0,1])
rng=np.random.default_rng(5); xx=rng.uniform(0,1,1024); yy=xx**3
b01=quiet(C.InformationGeometricConditionalIndependence().bivariate,xx,yy); b10=quiet(C.InformationGeometricConditionalIndependence().bivariate,yy,xx)
print('igci raw x^3 T1024 b01',repr(b01),'b10',repr(b10),'gap',b01+b10)
# does the raw path z-score? compare bivariate on raw vs on Data
Dxy=quiet(Data,np.stack([xx,yy])); m=quiet(C.InformationGeometricConditionalIndependence().multivariate,Dxy); print('  via Data: A01',repr(m[0,1]),'A10',repr(m[1,0]),'gap',m[0,1]+m[1,0])
A=quiet(C.ConditionalDistributionSimilarity().multivariate,D); print('cds anm_T1024 A01',A[0,1],'A10',A[1,0],'A23',A[2,3],'A32',A[3,2])
D2=quiet(Data,load('anm',256)); A=quiet(C.RegressionErrorCausalInference().multivariate,D2); print('reci anm_T256 A01',A[0,1],'A10',A[1,0],'A23',A[2,3],'A32',A[3,2])
D3=quiet(Data,load('delayed_noise',256)); A=quiet(C.RegressionErrorCausalInference().multivariate,D3); print('reci delayed_T256 A01',A[0,1],'A10',A[1,0])
for T in (256,1024):
    A=quiet(C.InformationGeometricConditionalIndependence().multivariate,quiet(Data,load('anm',T))); print('igci anm',T,'A01',A[0,1],'A23',A[2,3])
A=quiet(C.InformationGeometricConditionalIndependence().multivariate,quiet(Data,load('iid_gaussian',64))); print('igci iid64 range',np.nanmin(A),np.nanmax(A))
