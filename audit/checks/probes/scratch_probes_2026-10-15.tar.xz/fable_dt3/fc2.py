import sys, warnings, numpy as np, io, contextlib
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
import pyspi.statistics.causal as C
from cdt.causality.pairwise import CDS
base='/media/dan/Data/git/pyspi/audit/checks/data/'
def quiet(f,*a,**k):
    with contextlib.redirect_stdout(io.StringIO()): return f(*a,**k)
def load(n,T): return np.load(f'{base}{n}_T{T}.npz')['x']
def nqual(x,ff=2,md=3,minc=12):
    xs=(x-x.mean())/x.std(); xf=xs[np.abs(xs)<md]; xs=(xs-xf.mean())/xf.std(); xd=np.clip(np.round(xs*ff),-ff*md,ff*md)
    cnt=np.unique(xd,return_counts=True)[1]; return int((cnt>minc).sum()), int(cnt.max())
for name in ('anm','iid_gaussian'):
    D=quiet(Data,load(name,64)); z=D.to_numpy(); A=quiet(C.ConditionalDistributionSimilarity().multivariate,D)
    for i in range(z.shape[0]):
        nq,mx=nqual(z[i].ravel()); print(name,'T64 proc',i,'qualifying bins',nq,'max count',mx,'row all zero:',bool(np.all(np.nan_to_num(A[i])==0)))
# constructed: exactly one qualifying bin -> cds == 0 exactly although a bin has > 12 samples
rng=np.random.default_rng(0); x=np.r_[np.zeros(30), rng.standard_normal(1)*0+3, rng.standard_normal(5)+6]; y=rng.standard_normal(36)
# simpler: x concentrated so only one bin > 12
x=np.r_[rng.normal(0,0.05,20), rng.uniform(-3,3,30)]; y=rng.standard_normal(50)
print('constructed nqual',nqual(x),'cds',CDS().cds_score(x.reshape(-1,1),y.reshape(-1,1)))
x=np.r_[rng.normal(0,0.05,20), rng.normal(1.5,0.05,20), rng.uniform(-3,3,30)]; y=rng.standard_normal(70)
print('constructed two-bin nqual',nqual(x),'cds',CDS().cds_score(x.reshape(-1,1),y.reshape(-1,1)))
# raw bivariate path preprocessing asymmetry
d=Data(); xx=rng.uniform(0,1,100)*5+2; yy=rng.uniform(0,1,100)*3-1
quiet(d.add_process,xx); quiet(d.add_process,yy); z=d.to_numpy()
print('raw path: proc0 mean/std',z[0].mean(),z[0].std(ddof=1),'proc1 mean/std',z[1].mean(),z[1].std(ddof=1),'proc1 equals raw yy:',np.allclose(z[1].ravel(),yy))
