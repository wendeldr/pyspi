import sys, numpy as np, io, contextlib, warnings
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.statistics.distance import GromovWasserstainTau as G
from pyspi.data import Data
from scipy.stats import zscore
base='/media/dan/Data/git/pyspi/audit/checks/data/'
def quiet(f,*a,**k):
    with contextlib.redirect_stdout(io.StringIO()):
        return f(*a,**k)
spi=G()
L=lambda x: np.cumsum(np.sqrt(1+np.diff(x)**2))
T=256
X=np.load(f'{base}iid_gaussian_T{T}.npz')['x']
A=quiet(spi.multivariate, quiet(Data,X))
Z=zscore(X,axis=1,ddof=1)
ref=np.sqrt(np.mean((L(Z[0])-L(Z[1]))**2))
refroot=np.sqrt(np.mean((np.r_[0,L(Z[0])]-np.r_[0,L(Z[1])])**2))
print('T',T,'A01',A[0,1],'ref',ref,'diff',A[0,1]-ref,'root/pyspi',refroot/A[0,1],'sqrt((T-1)/T)',np.sqrt((T-1)/T))
print('A==A.T', np.array_equal(np.nan_to_num(A),np.nan_to_num(A.T)))
d=quiet(Data,X)
print('bivariate(0,1)==(1,0)', quiet(spi.bivariate,d,i=0,j=1)==quiet(spi.bivariate,d,i=1,j=0))
v=G.vec_geo_dist(np.column_stack([np.arange(T),Z[0]]))
print('len v',len(v),'min step',np.diff(np.r_[0,v]).min(), 'strictly inc', np.all(np.diff(v)>0))
print('no-sort formula == A01', ref==A[0,1])
rng=np.random.default_rng(0); Xr=rng.standard_normal((3,256)); Zr=zscore(Xr,axis=1,ddof=1)
p=rng.permutation(256)
print('perm before',G.gwtau(Zr[0],Zr[1]),'after',G.gwtau(Zr[0][p],Zr[1][p]))
print('gwtau(z,-z)',G.gwtau(Zr[0],-Zr[0]),'gwtau(z,z+5)',G.gwtau(Zr[0],Zr[0]+5))
for T in (256,4096):
    X=np.load(f'{base}narrowband_f0-0.25_T{T}.npz')['x']
    A=quiet(spi.multivariate, quiet(Data,X))
    print('narrowband',T,np.round(A[0],3))
    t=np.arange(T); S=np.stack([np.sin(2*np.pi*0.25*t+ph) for ph in (0,np.pi/4,-np.pi/2)])
    Zs=zscore(S,axis=1,ddof=1)
    print('  noise-free |dz| ph0',np.unique(np.round(np.abs(np.diff(Zs[0])),3)),'ph pi/4',np.unique(np.round(np.abs(np.diff(Zs[1])),3)),'ph -pi/2',np.unique(np.round(np.abs(np.diff(Zs[2])),3)))
    print('  noise-free gwtau(0,1)',G.gwtau(Zs[0],Zs[1]),'(0,2)',G.gwtau(Zs[0],Zs[2]),'pred drift*T/sqrt3',(2*np.sqrt(3)-1-np.sqrt(5))/2*T/np.sqrt(3))
for name in ('delayed_noise','iid_gaussian'):
    X=np.load(f'{base}{name}_T4096.npz')['x']; A=quiet(spi.multivariate, quiet(Data,X)); print(name,4096,np.round(A[0],2))
rng=np.random.default_rng(123)
for TT in (64,256,1024,4096):
    vals=[G.gwtau(*zscore(rng.standard_normal((2,TT)),axis=1,ddof=1)) for _ in range(20)]
    print('T',TT,'mean iid gwtau',np.mean(vals))
X=np.load(f'{base}scaled_offset_T1024.npz')['x']; B=np.load(f'{base}bivariate_gaussian_T1024.npz')['x']
A1=quiet(spi.multivariate, quiet(Data,X,normalise=False)); A2=quiet(spi.multivariate, quiet(Data,X)); A3=quiet(spi.multivariate, quiet(Data,B))
print('scaled raw row0',np.round(A1[0],1),'z',np.round(A2[0],2),'bivgauss z',np.round(A3[0],2),'max|A2-A3|',np.nanmax(np.abs(A2-A3)))
try:
    quiet(spi.bivariate, rng.standard_normal(100), rng.standard_normal(80))
except Exception as e: print('unequal:',type(e).__name__,str(e)[:100])
def w2q(a,b):
    a=np.sort(a); b=np.sort(b); n,m=len(a),len(b)
    cuts=np.unique(np.r_[np.arange(n+1)/n,np.arange(m+1)/m]); tot=0.0
    for lo,hi in zip(cuts[:-1],cuts[1:]):
        u=(lo+hi)/2; tot+=(hi-lo)*(a[min(int(u*n),n-1)]-b[min(int(u*m),m-1)])**2
    return np.sqrt(tot)
a=rng.standard_normal(37); b=rng.standard_normal(53)
print('wass_sorted unequal',G.wass_sorted(a,b),'quantile',w2q(a,b))
# descending sort equivalence with ascending
x1=np.sort(L(Zr[0])); x2=np.sort(L(Zr[1])); print('asc formula',np.sqrt(np.mean((x1-x2)**2)),'pyspi',G.gwtau(Zr[0],Zr[1]))
