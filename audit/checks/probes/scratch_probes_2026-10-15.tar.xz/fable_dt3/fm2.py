import sys, numpy as np, pandas as pd, pyEDM, warnings
warnings.simplefilter('ignore')
from scipy.stats import zscore
base='/media/dan/Data/git/pyspi/audit/checks/data/'
def load(n,T): return np.load(f'{base}{n}_T{T}.npz')['x']
def xmap(src,tgt,E):
    N=len(src); rows=np.arange(E-1,N)
    emb=np.stack([src[rows-k] for k in range(E)],1); pred=np.empty(len(rows)); nties=0
    for a in range(len(rows)):
        d=np.sqrt(((emb-emb[a])**2).sum(1)); d[a]=np.inf
        o=np.argsort(d,kind='stable'); dk=d[o]
        if np.any(np.abs(d[o[E+1:]]-dk[E])<1e-12): nties+=1
        o=o[:E+1]; dk=dk[:E+1]
        w=np.exp(-dk/dk[0]) if dk[0]>0 else (dk==0).astype(float)
        w=np.maximum(w,1e-6); pred[a]=(w*tgt[rows[o]]).sum()/w.sum()
    return np.corrcoef(tgt[rows],pred)[0,1], nties
for name in ('logistic_maps','var2_bivariate','iid_gaussian','nonlinear_dependence'):
    x=zscore(load(name,256)[:2],axis=1,ddof=1); N=x.shape[1]
    df=pd.DataFrame(np.c_[np.arange(N),x.T],columns=['index','proc0','proc1'])
    for E in (1,10):
        out=pyEDM.CCM(dataFrame=df,E=E,columns='proc0',target='proc1',libSizes=f"{N-E+1}",random=False)
        r01,t01=xmap(x[0],x[1],E); r10,t10=xmap(x[1],x[0],E)
        print(f'{name} E{E}: p0:p1 pyEDM {out.iloc[0,1]:.15f} scratch {r01:.15f} diff {out.iloc[0,1]-r01:.1e} rows-with-knn-ties {t01} | p1:p0 pyEDM {out.iloc[0,2]:.15f} scratch {r10:.15f} diff {out.iloc[0,2]-r10:.1e} ties {t10}')
    print('  unique values proc1:',len(np.unique(np.round(x[1],12))),'proc0:',len(np.unique(np.round(x[0],12))))
