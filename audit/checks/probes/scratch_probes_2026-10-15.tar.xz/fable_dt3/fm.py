import sys, numpy as np, pandas as pd, pyEDM, io, contextlib, warnings, time
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.statistics.causal import ConvergentCrossMapping as CCM
from pyspi.data import Data
from scipy.stats import zscore
np.set_printoptions(precision=4, suppress=True, linewidth=150)
base='/media/dan/Data/git/pyspi/audit/checks/data/'
def quiet(f,*a,**k):
    with contextlib.redirect_stdout(io.StringIO()): return f(*a,**k)
def load(n,T): return np.load(f'{base}{n}_T{T}.npz')['x']
def xmap(src,tgt,E):
    N=len(src); rows=np.arange(E-1,N)
    emb=np.stack([src[rows-k] for k in range(E)],1); pred=np.empty(len(rows))
    for a in range(len(rows)):
        d=np.sqrt(((emb-emb[a])**2).sum(1)); d[a]=np.inf
        o=np.argsort(d,kind='stable')[:E+1]; dk=d[o]
        w=np.exp(-dk/dk[0]) if dk[0]>0 else (dk==0).astype(float)
        w=np.maximum(w,1e-6); pred[a]=(w*tgt[rows[o]]).sum()/w.sum()
    return np.corrcoef(tgt[rows],pred)[0,1]
rng=np.random.default_rng(3); N=300
x0=rng.uniform(-1,1,N); x1=x0**2+0.05*rng.standard_normal(N)
df=pd.DataFrame(np.c_[np.arange(N),x0,x1],columns=['index','proc0','proc1'])
for E in (1,3,10):
    out=pyEDM.CCM(dataFrame=df,E=E,columns='proc0',target='proc1',libSizes=f"{N-E+1}",random=False)
    print('toy E',E,'pyEDM',{k:repr(v) for k,v in out.iloc[0].to_dict().items()},'| scratch p0:p1',repr(xmap(x0,x1,E)),'p1:p0',repr(xmap(x1,x0,E)))
x=zscore(load('logistic_maps',256),axis=1,ddof=1); N=x.shape[1]
df=pd.DataFrame(np.c_[np.arange(N),x.T],columns=['index','proc0','proc1'])
out=pyEDM.CCM(dataFrame=df,E=10,columns='proc0',target='proc1',libSizes=f"{N-9}",random=False)
print('logistic E10 full-lib pyEDM',out.iloc[0].to_dict(),'scratch p0:p1',xmap(x[0],x[1],10),'p1:p0',xmap(x[1],x[0],10))
D=quiet(Data,load('logistic_maps',256))
for E in (1,2,10):
    m=quiet(CCM(statistic='mean',embedding_dimension=E).multivariate,D); d=quiet(CCM(statistic='diff',embedding_dimension=E).multivariate,D)
    print('logistic T256 E',E,'mean',np.round(m,4).tolist(),'diff',np.round(d,4).tolist())
ccmf=D.ccm[2]; print('diag zero',np.all(ccmf[0,0]==0),'shape',ccmf.shape,'any nan',np.isnan(ccmf).any())
D=quiet(Data,load('var2_bivariate',256))
t=time.time(); m10=quiet(CCM(statistic='mean',embedding_dimension=10).multivariate,D); d10=quiet(CCM(statistic='diff',embedding_dimension=10).multivariate,D)
Dn=quiet(Data,load('var2_bivariate',256)); mN=quiet(CCM(statistic='mean',embedding_dimension=None).multivariate,Dn); dN=quiet(CCM(statistic='diff').multivariate,Dn)
print('var2 E10 mean',np.round(m10,4).tolist(),'diff',np.round(d10,4).tolist(),'E-None==E-10',np.array_equal(m10,mN),np.array_equal(d10,dN),'time',round(time.time()-t,1))
print('diff==mean-mean.T maxabs',np.nanmax(np.abs(d10-(m10-m10.T))))
N=64; z=rng.standard_normal((2,N)); df=pd.DataFrame(np.c_[np.arange(N),z.T],columns=['index','proc0','proc1'])
out=pyEDM.CCM(dataFrame=df,E=10,columns='proc0',target='proc1',libSizes="20 50 1",sample=100,seed=42)
print('"20 50 1" rows',len(out),'first',out.LibSize.values[0],'22nd',out.LibSize.values[21],'last',out.LibSize.values[-1],'cols',list(out.columns))
out=pyEDM.CCM(dataFrame=df,E=1,columns='proc0',target='proc1',libSizes="10 60 2",sample=100,seed=42)
print('"10 60 2" rows',len(out),'22nd',out.LibSize.values[21],'last',out.LibSize.values[-1])
for T in (41,42,50,55,60,61,64):
    x=rng.standard_normal((2,T))
    for E in (1,10):
        try:
            A=quiet(CCM(embedding_dimension=E).multivariate,quiet(Data,x)); print('T',T,'E',E,'ok',np.round(A,3).tolist())
        except Exception as e: print('T',T,'E',E,'EXC',type(e).__name__,str(e)[:90])
for name in ('logistic_maps','iid_gaussian','var2_bivariate'):
    x=zscore(load(name,256)[:2],axis=1,ddof=1); N=x.shape[1]
    df=pd.DataFrame(np.c_[np.arange(N),x.T],columns=['index','proc0','proc1'])
    for c in ('proc0','proc1'):
        ed=pyEDM.EmbedDimension(dataFrame=df,lib=f"10 {N-10}",pred=f"10 {N-10}",columns=c,showPlot=False)
        print(name,c,'max E',ed.max()['E'],'argmax',int(ed.loc[ed.rho.idxmax(),'E']),'rho',np.round(ed.rho.values,3))
N=100; z=np.c_[rng.standard_normal(N), np.ones(N)]; df=pd.DataFrame(np.c_[np.arange(N),z],columns=['index','proc0','proc1'])
try:
    out=pyEDM.CCM(dataFrame=df,E=2,columns='proc0',target='proc1',libSizes="20 80 20",sample=5,seed=42); print('const target rows',out.values[:2].tolist())
except Exception as e: print('const target EXC',e)
cm=pyEDM.CCM(dataFrame=df,E=2,columns='proc0',target='proc1',libSizes="10 50 10",sample=5,seed=42,includeData=True,parameterList=True)
p=cm['parameters']; print({k:p[k] for k in p if k in ('version','knn','tau','Tp','exclusionRadius','randomLib','replacement','seed','subSamples','libSizes','lib','pred')})
