"""Open question 1 (throwaway, comparison venv, no sklearn): in-sample MSE with the documented values held fixed
(theta = 0: c = w = 1, l = 1 or sigma_0 = 1) vs pyspi's fitted value (out/pyspi/<run_id>.npz)."""
import sys
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np, make_data, _kernels_basic_misc as K
from scipy.stats import zscore
OUT = '/media/dan/Data/git/pyspi/audit/checks/out/pyspi/'
for kn, rid, ds, T, pr in [("RBF", "misc.gpfit.RBF|iid_gaussian|256|pipeline|posterior", "iid_gaussian", 256, [0, 1, 2]),
                           ("RBF", "misc.gpfit.RBF|nonlinear_dependence|256|pipeline|posterior", "nonlinear_dependence", 256, None),
                           ("RBF", "misc.gpfit.RBF|shared_envelope|64|pipeline|posterior", "shared_envelope", 64, None),
                           ("DotProduct", "misc.gpfit.DotProduct|bivariate_gaussian|256|pipeline|posterior", "bivariate_gaussian", 256, None)]:
    x = make_data.load(ds, T)["x"]; x = x if pr is None else x[pr]
    X = zscore(x, axis=1, ddof=1); P = np.load(OUT + rid + ".npz")["value"]
    F = np.full_like(P, np.nan)
    for i in range(len(X)):
        for j in range(len(X)):
            if i != j:
                F[i, j] = np.mean((X[j] - K.gp_posterior_mean(X[i], X[j], K._gp_params(kn, np.zeros(3)))) ** 2)
    od = ~np.eye(len(X), dtype=bool)
    print(f"{kn} {ds}_T{T}: fixed min {F[od].min():.4g} max {F[od].max():.4g}; pyspi min {P[od].min():.4g} max {P[od].max():.4g}; "
          f"max|fixed - pyspi| {np.abs(F - P)[od].max():.3g}; A[0,1] fixed {F[0,1]:.4g} pyspi {P[0,1]:.4g}; A[1,0] fixed {F[1,0]:.4g} pyspi {P[1,0]:.4g}")
