import sys, time, importlib.util
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import numpy as np, make_data
spec=importlib.util.spec_from_file_location('gp','/media/dan/Data/git/pyspi/audit/checks/probes/gpfit_probes.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
x=make_data.load('anm',64)['x']
for u in ['misc.gpfit.RBF','misc.gpfit.DotProduct']:
    run=dict(unit_id=u,path='pipeline')
    t=time.time(); o=m.params(x,run); print(u, time.time()-t); np.set_printoptions(precision=5, linewidth=200)
    print(o[0,1]); print(o[1,0])
    t=time.time(); d=m.determinism(x,run); print('det', np.nanmax(np.abs(d-d[0])), time.time()-t)
    w=m.warnings_count(x,run); print('warn', w[...,0][~np.isnan(w[...,0])], w[...,2].max() if True else 0)
