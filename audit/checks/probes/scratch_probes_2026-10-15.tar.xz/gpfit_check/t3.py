import sys, time
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import gpfit as G, numpy as np, make_data
X=G.prep(make_data.load('anm',256)['x'],'pipeline')
t=time.time(); print(G.blr_ml2(X[0],X[1]), time.time()-t, 'pyspi 0.3332562435218984')
t=time.time(); th,v=G.scratch_fit(X[0],X[1],'RBF'); print(th, v, G.mse_at(X[0],X[1],'RBF',th), time.time()-t, 'pyspi 0.21464341259716369')
print(G.resid_identity(X[0],X[1],'RBF',th))
t=time.time(); print(G.multistart(X[0],X[1],'RBF',10,1), time.time()-t)
b=make_data.load('bivariate_gaussian',256)['x']; s=make_data.load('scaled_offset',256)
print(np.max(np.abs(G.prep(b,'pipeline')-G.prep(s['x'],'pipeline'))), s['scale'], s['offset'])
