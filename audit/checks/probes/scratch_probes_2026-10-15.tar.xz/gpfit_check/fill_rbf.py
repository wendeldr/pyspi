import json, yaml
R = "/media/dan/Data/git/pyspi/audit/records/"
man = json.load(open("/media/dan/Data/git/pyspi/audit/checks/manifest/gpfit.json"))["runs"]
def ids(unit, tag, path=None):
    return [r["run_id"] for r in man if r["unit_id"] == unit and r["run_id"].split("|")[-1] == tag
            and (path is None or r["path"] == path)]
u = "misc.gpfit.RBF"
d = yaml.safe_load(open(R + u + ".yaml"))
c = d["correctness"]
d["status"] = "checked"
old = "To be confirmed in the check stage."
if old in c["direction_convention"]:
    c["direction_convention"] = c["direction_convention"].replace(old, "Confirmed in the check stage (misc.gpfit.RBF|*|direction runs).")
c.update({
 "check_method": "independent-impl",
 "check_reference": "audit/checks/refs/gpfit.py:h_posterior and h_postmean -> audit/checks/refs/_kernels_basic_misc.py:gp_posterior_mean + "
   "gp_log_marginal_likelihood (Cholesky, R&W Alg. 2.1 and eqs. 5.8-5.9, no sklearn) at sklearn's fitted theta (probes/gpfit_probes.py:params, :postmean); "
   "audit/checks/refs/gpfit.py:h_scratch -> _kernels_basic_misc.gp_fit (own single L-BFGS-B start from theta = 0 in the sklearn box) + gp_posterior_mean; "
   "h_params (projected gradient and tight polish under the independent LML); h_multistart (own multi-start ML-II, theta = 0 plus 20 (T64) or 10 "
   "(T256) log-uniform starts, plus the interpolation formula (w'/(1 + w'))^2 mean(y^2)); h_identity (residual identity w'^2 |K^-1 y|^2 / T and "
   "LOO R&W eq. 5.12, same-lineage theta); h_gaussexp (analytic ((T-1)/T)(1 - r^2)); h_vsridge (analytic Ridge(alpha=1) MSE, cross-checked with "
   "pyspi's misc.lmfit.Ridge outputs); h_direction; h_affine, h_determinism, h_warnings, h_scipy118 (same-lineage)",
 "check_data": "pipeline: iid_gaussian T64/T256 (P=3)/T1024 (P=2), delayed_noise T64/T256, nonlinear_dependence T64/T256, anm T256/T1024 (P=2), "
   "bivariate_gaussian T256/T1024 (P=2), shared_envelope T64/T256, narrowband_f0-0.1 T64, sparse_precision T256 (P=3)/T1024 (P=2), "
   "gauss_ar1_pair T256/T1024, logistic_maps_chaotic T256, scaled_offset T256, trending T256 (also pipeline-detrend); kernel (raw rows): "
   "iid_gaussian, bivariate_gaussian, anm, nonlinear_dependence, shared_envelope at T64/T256, anm and iid_gaussian T1024 (P=2), scaled_offset T256",
 "agreement_criterion": "exact rtol 1e-8, atol 1e-12 at sklearn's theta (posterior; postmean elementwise atol 1e-10); tolerance rtol 1e-6 vs an own single "
   "start from theta = 0 (scratch); optimality: polish gain <= 1e-3 (params, local) and no multi-start optimum higher by > 1e-3 in LML (multistart, "
   "global); same-lineage exact rtol 1e-10 for the residual identity; analytic Gaussian expectation rtol 0.1 (T256) / 0.05 (T1024); qualitative: "
   "RBF MSE <= Ridge MSE on every pair, orientation and cause -> effect ordering, bit-identical recomputation, warning counts; same-lineage "
   "rtol 1e-6 for SciPy 1.18.1",
 "closeness": "Posterior arithmetic: posterior 12/12 pass, max_rel 4.0e-11 (shared_envelope), <= 9.4e-15 elsewhere; postmean 3/3, f_bar elementwise "
   "<= 1.8e-14, LML difference <= 2.1e-12. Single start: scratch 14/14 within rtol 1e-6, max_rel 2.1e-7 (shared_envelope T64 kernel), <= 5.0e-11 "
   "elsewhere, raw data and trending (pipeline and detrended) included. Local optimality: params 10/12 pass; anm T256 (gain 1.85e-3) and "
   "delayed_noise T256 (1.31e-3) fail, stopped on factr on a near-flat l -> 1e5 plateau with the MSE moving <= 6.7e-6 relative; MSE change under "
   "polish <= 1.2e-4 over all 12 runs; n_restarts_optimizer 0 everywhere. Global optimality: multistart 0/11 pass. Own multi-start finds a higher "
   "LML (> 1e-3) on 99 of 128 ordered pairs (iid_gaussian T64 20/20, T256 6/6; delayed_noise T64 and T256 12/12; nonlinear_dependence T64 and T256 "
   "11/12; anm T256 8/12; bivariate_gaussian T256 8/12; narrowband_f0-0.1 T64 4/6; shared_envelope T64 2/12, T256 5/12), with the value "
   "changing by > 1e-3 on 98. Maximum LML gain 419.4 (shared_envelope T256), 58.4 (narrowband T64 1->0). On 12 best fits with l <= 0.1 x min "
   "input spacing, the MSE equals (w'/(1 + w'))^2 mean(y^2) to <= 5.5e-11 relative. Identity (same-lineage) 4/4, max_rel 2.3e-11. "
   "Gaussian expectation: gaussexp 8/8, max_rel 0.063 (bivariate_gaussian T256) -> 5.1e-4 (T1024), sparse_precision 0.0157 -> 1.6e-3, "
   "gauss_ar1_pair 7.7e-3 -> 2.3e-4, iid_gaussian 1.1e-3 -> 4.5e-5. Versus linear Ridge: vsridge 1/6. RBF exceeds the Ridge(alpha=1) MSE on "
   "iid_gaussian 6/6, bivariate_gaussian 10/12, nonlinear_dependence 8/12, anm T256 4/12 and sparse_precision 2/6 pairs (excess at most 0.0063 "
   "absolute on anm T256, 1.8% relative on bivariate_gaussian T256), and is lower by up to 0.970 on nonlinear_dependence. The Ridge values equal "
   "pyspi's misc.lmfit.Ridge|<dataset>|<T>|pipeline|closedform to <= 2.2e-15. Other: scipy118 5/5 max_rel 2.7e-11; affine 2.4e-12.",
 "verdict": "variant",
 "score_0_10": 6,
 "what_changed": "Given its hyperparameters the posterior mean and MSE are standard (fp-exact on an independent GP), and an independent single "
   "L-BFGS-B start from theta = 0 reproduces pyspi's values to <= 2.1e-7. The statistic nevertheless deviates from both references in an "
   "interpretable way (anchor 6). From the supplement: l, the constant and the noise are fitted, not fixed at 1. From canonical GP regression: "
   "(1) The constant kernel is added, not multiplied, so the RBF amplitude is fixed at 1. With that kernel the ML-II maximum is degenerate on "
   "pairs without strong dependence. The better optimum interpolates (w at 1e-5, l below the input spacing, MSE (w'/(1 + w'))^2 (T-1)/T about "
   "1e-10) with no predictive skill. "
   "(2) pyspi uses a single start, not the ML-II maximum. The value is the fit reached from theta = 0, which is below the multi-start optimum "
   "on 99 of 128 pairs. That fit either sends l to the 1e5 bound and returns (T-1)/T for independent pairs, or misses cross-validated structure "
   "(narrowband_f0-0.1 T64 1->0: 0.483 against 0.023, LOO 0.520 against 0.056). "
   "(3) On noise-free periodic data, the single start itself lands in an interpolating optimum (shared_envelope T64 0->1: A = 1.1e-8, LOO 0.50). "
   "(4) The score is an in-sample MSE, so it is not bounded by the linear fit: on Gaussian and independent pairs it exceeds Ridge by up to 0.0063. "
   "Score 6, not 7: the optimiser unit fails the global optimality check, and local optimality fails marginally on 2 of 12 runs.",
 "new_finding": True,
 "definition_under_review": False,
 "check_cost": "expensive: one sklearn fit takes 0.44 s at T=256 and 5.6 s at T=1024 under concurrent load (O(T^3) per LML evaluation, 6-33 "
   "L-BFGS-B iterations). A P=2 matrix at T=1024 took 14-26 s; the 3-fit params probe at T=1024, P=2 took 70.6 s. Checks used T <= 1024 with P "
   "= 2 at T=1024; T=4096 was not run. Own multi-start references (11-21 starts per pair) were run at T <= 256 only.",
 "symmetry_observed": "asym: max|A - A^T| = 0.970 (nonlinear_dependence T256), 0.552 (nonlinear_dependence T64), 0.539 (shared_envelope T256), "
   "0.099 (anm T256), 0.117 (anm T1024, P=2); 9.3e-9 on iid_gaussian T256, where every entry is (T-1)/T; 97.29 on raw scaled_offset T256",
 "direction_observed": "A[i, j] = MSE of predicting x_j from x_i (lower means x_i predicts x_j better at zero lag). nonlinear_dependence T256 "
   "(x1 = x0^2 + noise): A[0,1] = 0.0260, A[1,0] = 0.9961. anm T256: A[0,1] = 0.2146 < A[1,0] = 0.3140 and A[2,3] = 0.0652 < A[3,2] = 0.0918. "
   "anm T1024: 0.2424 < 0.3595. Raw scaled_offset T256: A[i, j] scales with var(x_j) (A[0,3] = 97.33, A[3,0] = 0.0392). Own oriented fits "
   "agree on every distinguishable pair (anm 12/12, nonlinear_dependence 8/8, scaled_offset 12/12, logistic_maps_chaotic 2/2). The asymmetry "
   "is contemporaneous predictability, not causal direction: on logistic_maps_chaotic T256 (x0 -> x1, lagged) A[1,0] = 0.913 < A[0,1] = 0.975.",
 "candidate_resolutions": [
  {"candidate": "single-start local optimum; the ML-II optimum is degenerate and the better optimum interpolates",
   "outcome": "confirmed",
   "evidence": "misc.gpfit.RBF|*|pipeline|multistart (11 runs): higher LML on 99/128 pairs, value change > 1e-3 on 98; the best fit "
     "interpolates on 72 pairs (e.g. iid_gaussian T256 0->1: 0.996094 -> 2.5e-10, LML +2.89, LOO 0.9946). The single start converges "
     "locally (|params runs, 10/12 pass the polish test). Not in KNOWN_ISSUES.md."},
  {"candidate": "mechanism: fixed-amplitude RBF at tiny length scale acts as signal-labelled white noise, MSE (w'/(1 + w'))^2 (T-1)/T",
   "outcome": "confirmed",
   "evidence": "misc.gpfit.RBF|iid_gaussian|64|pipeline|multistart (7 pairs), |iid_gaussian|256| (1), |nonlinear_dependence|64| (4): own "
     "multi-start optima with l <= 0.1 x min input spacing match (w'/(1 + w'))^2 mean(y^2) to <= 5.5e-11 relative (interp_formula_max_rel). "
     "Throwaway probe scratchpad gpfit_check/oq3_amplitude.py: with C*RBF + White and 10 restarts, 0/24 pairs interpolate, against 20/24 for "
     "pyspi's C + White + RBF."},
  {"candidate": "in-sample MSE ~ 0 without predictive skill, reached by pyspi's own single start (shared_envelope)",
   "outcome": "confirmed",
   "evidence": "misc.gpfit.RBF|shared_envelope|64|pipeline|identity: A[0,1] = 1.106e-8, LOO 0.4995; |shared_envelope|256|pipeline|identity: "
     "5.26e-11, LOO 0.374; |shared_envelope|64|pipeline|multistart: a better optimum (LML +11.49) gives MSE 0.0990, LOO 0.146; "
     "|shared_envelope|64|pipeline|postmean reproduces the 1.106e-8 fit (w = 1e-5, l = 0.00726) to 2.4e-13."},
  {"candidate": "single start misses genuine structure (narrowband_f0-0.1 T64)",
   "outcome": "confirmed",
   "evidence": "misc.gpfit.RBF|narrowband_f0-0.1|64|pipeline|multistart: 1->0 pyspi 0.4828 (LOO 0.5197) vs best 0.02304 (LOO 0.0564), LML "
     "+58.44; 1->2 0.4983 vs 0.02744 (LOO 0.0776), LML +55.7."},
  {"candidate": "independent pairs collapse to (T-1)/T",
   "outcome": "confirmed",
   "evidence": "misc.gpfit.RBF|iid_gaussian|256|pipeline|identity: all 6 entries 0.996094 (min 0.9960937, max|A - A^T| 9.3e-9); "
     "|iid_gaussian|64|pipeline|postmean: 0.98437499997 with l at the 1e5 bound; |iid_gaussian|1024|pipeline|gaussexp within 4.5e-5 of "
     "((T-1)/T)(1 - r^2). Not every T64 entry: iid_gaussian T64 minimum 0.884."},
  {"candidate": "hyperparameter bound warnings hidden",
   "outcome": "confirmed",
   "evidence": "misc.gpfit.RBF|anm|256|pipeline|warnings: sklearn emits 11 bound warnings on 10/12 pairs, 0 escape GPModel.bivariate"},
  {"candidate": "random_state is a no-op; deterministic given data and BLAS",
   "outcome": "confirmed",
   "evidence": "misc.gpfit.RBF|iid_gaussian|256|pipeline|determinism and |shared_envelope|64|pipeline|determinism: bit-identical over 5 "
     "recomputations (random_state 0 and 12345, reseeded numpy/random); params runs: 0 draws from gp._rng, n_restarts_optimizer 0"}],
 "checks_run": [
  {"run_ids": ids(u, "posterior") + ids(u, "postmean"), "reference": "audit/checks/refs/gpfit.py:h_posterior, h_postmean (_kernels_basic_misc.gp_posterior_mean, gp_log_marginal_likelihood)",
   "outcome": "15/15 pass; max_rel 4.0e-11"},
  {"run_ids": ids(u, "scratch"), "reference": "audit/checks/refs/gpfit.py:h_scratch (_kernels_basic_misc.gp_fit single start + gp_posterior_mean)",
   "outcome": "14/14 pass; max_rel 2.1e-7"},
  {"run_ids": ids(u, "params"), "reference": "audit/checks/refs/gpfit.py:h_params (projected gradient, tight polish)",
   "outcome": "10/12 pass; anm T256 gain 1.85e-3 and delayed_noise T256 1.31e-3 fail (MSE change <= 6.7e-6)"},
  {"run_ids": ids(u, "multistart"), "reference": "audit/checks/refs/gpfit.py:h_multistart (own multi-start ML-II)",
   "outcome": "0/11 pass; higher LML on 99/128 pairs, max gain 419.4; interpolation formula 5.5e-11"},
  {"run_ids": ids(u, "identity"), "reference": "audit/checks/refs/gpfit.py:h_identity (same-lineage residual identity + LOO)",
   "outcome": "4/4 pass; max_rel 2.3e-11; LOO 0.4995 at in-sample 1.1e-8 (shared_envelope T64)"},
  {"run_ids": ids(u, "gaussexp"), "reference": "audit/checks/refs/gpfit.py:h_gaussexp (analytic Gaussian expectation)",
   "outcome": "8/8 pass; max_rel 0.063 (T256), <= 1.6e-3 (T1024)"},
  {"run_ids": ids(u, "vsridge"), "reference": "audit/checks/refs/gpfit.py:h_vsridge (analytic Ridge, cites misc.lmfit.Ridge|<ds>|<T>|pipeline|closedform)",
   "outcome": "1/6 pass; RBF > Ridge on 30/50 pairs, excess <= 0.0063"},
  {"run_ids": ids(u, "direction") + ids(u, "affine"), "reference": "audit/checks/refs/gpfit.py:h_direction (gp_fit oriented fits), h_affine (same-lineage)",
   "outcome": "6/6 pass; cause -> effect lower on anm (3/3 pairs) and nonlinear_dependence; orientation agreement 1.0"},
  {"run_ids": ids(u, "determinism") + ids(u, "warnings") + ids(u, "scipy118"), "reference": "audit/checks/refs/gpfit.py:h_determinism, h_warnings, h_scipy118 (same-lineage)",
   "outcome": "8/8 pass; bit-identical; 11 bound warnings, 0 escape; SciPy 1.18.1 max_rel 2.7e-11"}],
})
yaml.safe_dump(d, open(R + u + ".yaml", "w"), sort_keys=False, width=140, allow_unicode=False)
print("wrote", u)
