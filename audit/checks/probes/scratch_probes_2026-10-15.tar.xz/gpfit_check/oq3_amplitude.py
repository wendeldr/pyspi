"""Open question 3 (throwaway, comparison venv): does C*RBF + White (R&W eq. 2.31) remove the
interpolating ML-II optimum that C + White + RBF (pyspi) has?  10 sklearn restarts, random_state 0."""
import sys, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
import numpy as np, make_data
from scipy.stats import zscore
from sklearn.gaussian_process import GaussianProcessRegressor as G, kernels as k
specs = {"pyspi C+W+RBF": lambda: k.ConstantKernel() + k.WhiteKernel() + k.RBF(),
         "C*RBF+W": lambda: k.ConstantKernel() * k.RBF() + k.WhiteKernel()}
for ds, T, pr in [("iid_gaussian", 256, [0, 1, 2]), ("delayed_noise", 256, [0, 1, 2]), ("nonlinear_dependence", 256, [0, 1, 2, 3])]:
    X = zscore(make_data.load(ds, T)["x"][pr], axis=1, ddof=1)
    for name, ker in specs.items():
        mses, interp = [], 0
        for i in range(len(pr)):
            for j in range(len(pr)):
                if i == j: continue
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    gp = G(kernel=ker(), n_restarts_optimizer=10, random_state=0).fit(X[i][:, None], X[j])
                m = float(np.mean((gp.predict(X[i][:, None]) - X[j]) ** 2))
                mses.append(m); interp += m < 1e-6
        print(f"{ds}_T{T} {name:14s} n_pairs={len(mses)} interpolating(<1e-6)={interp} min={min(mses):.3g} max={max(mses):.4g}", flush=True)
