import sys, time, contextlib, io
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import numpy as np, make_data
from pyspi.data import Data
from pyspi.statistics.misc import GPModel
for ds,T,P in [('anm',256,4),('anm',1024,2),('iid_gaussian',1024,2)]:
    x=make_data.load(ds,T)['x'][:P]
    with contextlib.redirect_stdout(io.StringIO()):
        d=Data(np.array(x),dim_order='ps')
    for k in ['DotProduct','RBF']:
        t=time.perf_counter(); A=GPModel(kernel=k).multivariate(d); print(ds,T,P,k,round(time.perf_counter()-t,2),'s', A[0,1],A[1,0])
