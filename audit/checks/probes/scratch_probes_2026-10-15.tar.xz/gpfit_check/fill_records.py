import json, yaml
R = "/media/dan/Data/git/pyspi/audit/records/"
man = json.load(open("/media/dan/Data/git/pyspi/audit/checks/manifest/gpfit.json"))["runs"]
def ids(unit, tag, path=None):
    return [r["run_id"] for r in man if r["unit_id"] == unit and r["run_id"].split("|")[-1] == tag
            and (path is None or r["path"] == path)]

# ------------------------------------------------------------------ DotProduct
u = "misc.gpfit.DotProduct"
d = yaml.safe_load(open(R + u + ".yaml"))
c = d["correctness"]
d["status"] = "checked"
c["direction_convention"] = c["direction_convention"].replace(
    "so the convention is not observable from the values; to be confirmed with the RBF unit and with normalise=False.",
    "so the convention is not observable from the values under z-scoring; confirmed in the check stage on raw data "
    "(misc.gpfit.DotProduct|scaled_offset|256|kernel|direction: A[i, j] scales with var(x_j)).")
c.update({
 "check_method": "analytic",
 "check_reference": "audit/checks/refs/gpfit.py:h_ridgecf -> ridge_cf (closed-form Bayesian linear regression posterior mean = penalised least squares "
   "with slope penalty w' and intercept penalty w'/(c + sigma_0^2), at sklearn's fitted theta from probes/gpfit_probes.py:params); "
   "audit/checks/refs/gpfit.py:h_posterior and h_postmean -> audit/checks/refs/_kernels_basic_misc.py:gp_posterior_mean + gp_log_marginal_likelihood "
   "(Cholesky, R&W Alg. 2.1 and eqs. 5.8-5.9, no sklearn) at sklearn's theta; audit/checks/refs/gpfit.py:h_scratch -> blr_ml2 (weight-space BLR, "
   "global type-II ML over (c + sigma_0^2, w) by grid + L-BFGS-B + Nelder-Mead); audit/checks/refs/gpfit.py:h_single -> _kernels_basic_misc.gp_fit "
   "(own single L-BFGS-B start from theta = 0); audit/checks/refs/gpfit.py:h_closedform (analytic ((T-1)/T)(1 - r^2)); h_params (projected gradient "
   "and tight L-BFGS-B polish of sklearn's theta under the independent LML); h_multistart (theta = 0 plus 10 log-uniform starts); h_direction; "
   "h_affine, h_determinism, h_warnings, h_scipy118 (same-lineage)",
 "check_data": "pipeline: iid_gaussian T64/T256/T1024 (P=3), bivariate_gaussian T64/T256/T1024 (P=3), anm T64/T256, nonlinear_dependence T64/T256, "
   "sparse_precision T64/T256, contaminated T64/T256, trending T64/T256, scaled_offset T256; pipeline-detrend: trending T256/T1024 (P=3); kernel (raw "
   "rows): iid_gaussian, bivariate_gaussian, anm, nonlinear_dependence, cointegrated at T64/T256, iid_gaussian/anm/cointegrated T1024 (P=3), "
   "scaled_offset T256; direction: anm T256 and T1024 (P=2), nonlinear_dependence T256, scaled_offset T256 (kernel)",
 "agreement_criterion": "exact rtol 1e-8, atol 1e-12 (posterior, ridgecf; postmean elementwise atol 1e-10) at sklearn's fitted theta; tolerance rtol 1e-8 "
   "vs the global ML-II optimum (scratch) and rtol 1e-6 vs an own single start from theta = 0 (single); analytic ((T-1)/T)(1 - r^2) with the a-priori "
   "bound rtol 1e-4 at T=64 and 1e-5 at T>=256 (closedform); optimality: LML gain of a tight polish <= 1e-3 (params) and no multi-start optimum "
   "higher by > 1e-3 (multistart); qualitative: max|A - A^T| <= 1e-12 under z-scoring, orientation on raw scaled_offset, bit-identical recomputation, "
   "warning counts",
 "closeness": "Posterior arithmetic: ridgecf 5/5 pass, max_rel 7.4e-15 on z-scored data (anm, bivariate_gaussian, iid_gaussian, nonlinear_dependence T256) "
   "and 2.0e-13 on raw cointegrated T256 where c and sigma_0 matter; posterior 5/5, max_rel <= 7.9e-14; postmean 2/2, f_bar elementwise <= 1.7e-14 "
   "(bivariate_gaussian T256) and 1.25e-12 (cointegrated T256 raw), LML difference 5.7e-14 / 8.0e-13. ML-II on z-scored data: scratch (global BLR "
   "optimum) 8/8 pass, max_rel 2.4e-9; params 4/4, polish gain <= 8.0e-13, projected gradient <= 9.7e-6, every fit stopped on PGTOL; multistart 2/2, "
   "max LML gain 1.5e-12. Raw data (kernel path): scratch 4/13 pass, 9 fail with max_rel 1.35e-4 (anm T256), 1.2e-6 (cointegrated T256), <= 8.6e-7 "
   "elsewhere; single 5/5 pass with max_rel <= 2.4e-9, and the single start's gap to the global optimum equals pyspi's (anm T256: LML 7.5e-5 below, "
   "MSE 1.35e-4 relative; cointegrated T256: 6.0e-6, 1.2e-6); params anm T256 kernel polish gain 7.5e-5, MSE change 1.35e-4 relative; cointegrated "
   "T256 kernel 8/12 fits stopped on the factr test. Closed form: closedform 14/14, max relative difference to ((T-1)/T)(1 - r^2) 5.4e-5 to 6.1e-5 at "
   "T=64, <= 3.8e-6 at T=256, <= 6.9e-8 at T=1024 (trending detrended 6.8e-8). Other: affine scaled_offset vs bivariate_gaussian 1.0e-15; scipy118 "
   "max_rel 1.2e-15.",
 "verdict": "matches",
 "score_0_10": 7,
 "what_changed": "The estimator matches canonical up to the optimiser's stopping point. With Constant + White + DotProduct, the GP is Bayesian linear "
   "regression, and pyspi's value is the in-sample MSE of the posterior mean at the type-II ML hyperparameters. It is reproduced at sklearn's theta to "
   "<= 2.0e-13 (analytic ridge form), and on z-scored data it equals the global ML-II optimum to <= 2.4e-9. Score 7 is the optimiser-unit anchor: "
   "ML-II is not verifiable exactly, but local optimality and multi-start optimality pass. Recorded deviations: "
   "(1) On raw (normalise=False) data, sklearn's single L-BFGS-B start stops on the factr test along the flat c + sigma_0^2 direction, up to 7.5e-5 "
   "below the ML-II maximum, which moves the value by <= 1.35e-4 relative. This does not arise under the default z-scoring, where c and sigma_0 "
   "do not affect the prediction. "
   "(2) The documented values sigma_0 = 1, constant 1 and noise 1 are only starting points. Under z-scoring only the noise matters, so fitting it "
   "instead of fixing it at 1 changes the slope shrinkage by O(1/T). Analytically (not run), fixed noise 1 would reproduce lmfit Ridge(alpha=1). "
   "(3) The labels nonlinear and directed, and the word 'nonparametric', do not describe the computation. The value is ((T-1)/T)(1 - r^2) to "
   "<= 6.1e-5 relative, symmetric to <= 8.1e-15, and blind to x1 = x0^2 (0.995776 both ways). "
   "(4) The score is an in-sample error, not a predictive error.",
 "new_finding": True,
 "definition_under_review": False,
 "check_cost": "moderate: one sklearn fit takes 0.19 s at T=256 and 2.8 s at T=1024 (O(T^3) per LML evaluation, 7-28 L-BFGS-B iterations). pyspi "
   "matrices took 17-31 s for P=3 at T=1024 (out/pyspi/index/gpfit.json, under concurrent load). This check used T <= 1024 with P <= 3 at T=1024; "
   "T=4096 was not run (about 60x the T=1024 cost).",
 "symmetry_observed": "sym under z-scoring: max|A - A^T| <= 8.1e-15 on every pipeline run (8.1e-15 nonlinear_dependence T256, 4.3e-15 trending "
   "T1024 detrended). asym on raw data: max|A - A^T| = 97.26 (scaled_offset T256), 101.58 (cointegrated T256), because A[i, j] is in units of "
   "var(x_j).",
 "direction_observed": "A[i, j] = MSE of predicting x_j (target) from x_i (input). On raw scaled_offset T256, A[i, j] scales with var(x_j): A[0,3] = "
   "97.30, A[3,0] = 0.0392, A[0,1] = 3.640, A[1,0] = 0.0357, and the own oriented BLR fits agree on 12/12 pairs. Under z-scoring there is no "
   "direction information: anm T256 gives A[0,1] = A[1,0] = 0.333256 and A[2,3] = A[3,2] = 0.0926507; anm T1024 gives 0.374282 both ways; "
   "nonlinear_dependence T256 gives 0.995776 both ways.",
 "candidate_resolutions": [
  {"candidate": "DotProduct is a deterministic, symmetric (linear) transform of r^2; the nonlinear/directed labels are nominal",
   "outcome": "confirmed",
   "evidence": "misc.gpfit.DotProduct|*|pipeline|closedform (12 runs) and |trending|*|pipeline-detrend|closedform (2): max_rel_vs_r2 <= 6.1e-5 (T64), "
     "<= 3.8e-6 (T256), <= 6.9e-8 (T1024); |*|pipeline|ridgecf max_rel <= 7.4e-15; direction runs anm T256/T1024 and nonlinear_dependence T256 "
     "symmetric to <= 8.1e-15 with x1 = x0^2 at 0.995776 both ways. Not in KNOWN_ISSUES.md (REVIEW M9 discusses label structure in general)."},
  {"candidate": "bound warnings hidden; documented constant 1.0 and sigma_0 = 1 never apply",
   "outcome": "confirmed",
   "evidence": "misc.gpfit.DotProduct|anm|256|pipeline|warnings: 24 bound warnings on 12/12 pairs, 0 escape GPModel.bivariate. params runs on "
     "z-scored data: c and sigma_0 at the 1e-5 bound in 12/12 (anm, bivariate_gaussian, nonlinear_dependence) and 6/6 (iid_gaussian) pairs. "
     "Refinement: on raw data they are not always at the bound (|cointegrated|256|kernel|params: c at the bound 1/12, sigma_0 3/12; "
     "|anm|256|kernel|params: 5/12, 6/12)."},
  {"candidate": "random_state is a no-op and the fit is deterministic (single effective hyperparameter)",
   "outcome": "confirmed",
   "evidence": "misc.gpfit.DotProduct|iid_gaussian|256|pipeline|determinism: bit-identical over two multivariate calls, random_state 0 and 12345, "
     "and after reseeding numpy/random; params runs: n_restarts_optimizer 0, 0 draws from gp._rng; |multistart runs: no start beats pyspi "
     "(max LML gain 1.5e-12 anm T256, 5.7e-13 iid_gaussian T256)."}],
 "checks_run": [
  {"run_ids": ids(u, "ridgecf"), "reference": "audit/checks/refs/gpfit.py:h_ridgecf (ridge_cf, analytic)", "outcome": "5/5 pass; max_rel 2.0e-13"},
  {"run_ids": ids(u, "posterior") + ids(u, "postmean"), "reference": "audit/checks/refs/gpfit.py:h_posterior, h_postmean (_kernels_basic_misc.gp_posterior_mean, gp_log_marginal_likelihood)",
   "outcome": "7/7 pass; max_rel <= 1.6e-13; f_bar elementwise <= 1.25e-12"},
  {"run_ids": ids(u, "scratch", "pipeline"), "reference": "audit/checks/refs/gpfit.py:h_scratch (blr_ml2)", "outcome": "8/8 pass; max_rel 2.4e-9"},
  {"run_ids": ids(u, "scratch", "kernel"), "reference": "audit/checks/refs/gpfit.py:h_scratch (blr_ml2, global ML-II on raw rows)",
   "outcome": "4/13 pass; 9 fail at max_rel 9.3e-8 to 1.35e-4 (anm T256): sklearn stops short of the global optimum on raw data"},
  {"run_ids": ids(u, "single"), "reference": "audit/checks/refs/gpfit.py:h_single (_kernels_basic_misc.gp_fit single start)",
   "outcome": "5/5 pass; max_rel 2.4e-9; gap to the global optimum identical to pyspi's"},
  {"run_ids": ids(u, "closedform"), "reference": "audit/checks/refs/gpfit.py:h_closedform (analytic ((T-1)/T)(1 - r^2))",
   "outcome": "14/14 pass; max_rel 6.1e-5 (T64), 3.8e-6 (T256), 6.9e-8 (T1024)"},
  {"run_ids": ids(u, "params") + ids(u, "multistart"), "reference": "audit/checks/refs/gpfit.py:h_params, h_multistart",
   "outcome": "8/8 pass; polish gain <= 8.0e-13 on z-scored data, 7.5e-5 on raw anm; multi-start gain <= 1.5e-12"},
  {"run_ids": ids(u, "direction") + ids(u, "affine"), "reference": "audit/checks/refs/gpfit.py:h_direction (blr_ml2 oriented fits), h_affine (same-lineage)",
   "outcome": "5/5 pass; z-scored max|A - A^T| <= 8.1e-15; raw scaled_offset orientation agreement 12/12; affine 1.0e-15"},
  {"run_ids": ids(u, "determinism") + ids(u, "warnings") + ids(u, "scipy118"), "reference": "audit/checks/refs/gpfit.py:h_determinism, h_warnings, h_scipy118 (same-lineage)",
   "outcome": "3/3 pass; bit-identical; 24 bound warnings, 0 escape; SciPy 1.18.1 max_rel 1.2e-15"}],
})
yaml.safe_dump(d, open(R + u + ".yaml", "w"), sort_keys=False, width=140, allow_unicode=False)
print("wrote", u)
