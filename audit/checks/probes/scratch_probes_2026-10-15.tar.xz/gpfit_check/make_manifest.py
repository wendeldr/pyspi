import json
runs = []
PR = "probes/gpfit_probes.py"
def add(kn, ds, T, path, tag, procs=None, probe=None):
    uid = f"misc.gpfit.{kn}"
    runs.append(dict(run_id=f"{uid}|{ds}|{T}|{path}|{tag}", unit_id=uid,
                     identifier=None if probe else f"gpfit_{kn}", dataset=ds, T=T, path=path,
                     processes=procs, seed=42,
                     probe=None if probe is None else {"module": PR, "function": probe}))
P3, P2 = [0, 1, 2], [0, 1]
# ---------------- DotProduct
D = "DotProduct"
for ds in ["iid_gaussian", "bivariate_gaussian", "anm", "nonlinear_dependence", "cointegrated"]:
    for T in (64, 256):
        add(D, ds, T, "kernel", "scratch")
for ds in ["iid_gaussian", "anm", "cointegrated"]:
    add(D, ds, 1024, "kernel", "scratch", P3)
for ds, T in [("iid_gaussian", 64), ("bivariate_gaussian", 64), ("anm", 256), ("cointegrated", 256), ("nonlinear_dependence", 256)]:
    add(D, ds, T, "kernel", "single")
for ds in ["iid_gaussian", "bivariate_gaussian", "anm", "nonlinear_dependence"]:
    for T in (64, 256):
        add(D, ds, T, "pipeline", "scratch")
for ds in ["iid_gaussian", "bivariate_gaussian", "sparse_precision", "contaminated", "trending"]:
    for T in (64, 256):
        add(D, ds, T, "pipeline", "closedform")
add(D, "iid_gaussian", 1024, "pipeline", "closedform", P3)
add(D, "bivariate_gaussian", 1024, "pipeline", "closedform", P3)
add(D, "anm", 256, "kernel", "params", None, "params")
for ds, path, procs in [("anm", "pipeline", None), ("bivariate_gaussian", "pipeline", None),
                        ("nonlinear_dependence", "pipeline", None), ("iid_gaussian", "pipeline", P3),
                        ("cointegrated", "kernel", None)]:
    add(D, ds, 256, path, "params", procs, "params")
    add(D, ds, 256, path, "posterior", procs)
    add(D, ds, 256, path, "ridgecf", procs)
add(D, "bivariate_gaussian", 256, "pipeline", "postmean", None, "postmean")
add(D, "cointegrated", 256, "kernel", "postmean", None, "postmean")
add(D, "iid_gaussian", 256, "pipeline", "multistart", P3)
add(D, "anm", 256, "pipeline", "multistart")
add(D, "anm", 256, "pipeline", "direction")
add(D, "nonlinear_dependence", 256, "pipeline", "direction")
add(D, "anm", 1024, "pipeline", "direction", P2)
add(D, "scaled_offset", 256, "kernel", "direction")
add(D, "scaled_offset", 256, "pipeline", "affine")
add(D, "trending", 256, "pipeline-detrend", "closedform")
add(D, "trending", 1024, "pipeline-detrend", "closedform", P3)
add(D, "iid_gaussian", 256, "pipeline", "determinism", P3, "determinism")
add(D, "anm", 256, "pipeline", "warnings", None, "warnings_count")
add(D, "iid_gaussian", 256, "pipeline", "scipy118", P3)
# ---------------- RBF
R = "RBF"
for ds, procs64, procs256 in [("iid_gaussian", None, P3), ("bivariate_gaussian", None, None), ("anm", None, None),
                              ("nonlinear_dependence", None, None), ("shared_envelope", None, None)]:
    add(R, ds, 64, "kernel", "scratch", procs64)
    add(R, ds, 256, "kernel", "scratch", procs256)
add(R, "anm", 1024, "kernel", "scratch", P2)
add(R, "iid_gaussian", 1024, "kernel", "scratch", P2)
for ds, T, procs in [("iid_gaussian", 64, None), ("iid_gaussian", 256, P3), ("delayed_noise", 64, None),
                     ("delayed_noise", 256, None), ("nonlinear_dependence", 64, None), ("nonlinear_dependence", 256, None),
                     ("anm", 256, None), ("bivariate_gaussian", 256, None), ("shared_envelope", 64, None),
                     ("shared_envelope", 256, None), ("narrowband_f0-0.1", 64, None)]:
    add(R, ds, T, "pipeline", "params", procs, "params")
    add(R, ds, T, "pipeline", "posterior", procs)
    add(R, ds, T, "pipeline", "multistart", procs)
add(R, "anm", 1024, "pipeline", "params", P2, "params")
add(R, "anm", 1024, "pipeline", "posterior", P2)
add(R, "anm", 256, "pipeline", "postmean", None, "postmean")
add(R, "iid_gaussian", 64, "pipeline", "postmean", None, "postmean")
add(R, "shared_envelope", 64, "pipeline", "postmean", None, "postmean")
add(R, "iid_gaussian", 256, "pipeline", "identity", P3)
add(R, "shared_envelope", 64, "pipeline", "identity")
add(R, "shared_envelope", 256, "pipeline", "identity")
add(R, "nonlinear_dependence", 256, "pipeline", "identity")
add(R, "anm", 256, "pipeline", "direction")
add(R, "nonlinear_dependence", 256, "pipeline", "direction")
add(R, "logistic_maps_chaotic", 256, "pipeline", "direction")
add(R, "anm", 1024, "pipeline", "direction", P2)
add(R, "scaled_offset", 256, "kernel", "direction")
add(R, "scaled_offset", 256, "pipeline", "affine")
for ds, p256, p1024 in [("iid_gaussian", P3, P2), ("bivariate_gaussian", None, P2), ("sparse_precision", P3, P2),
                        ("gauss_ar1_pair", None, None)]:
    add(R, ds, 256, "pipeline", "gaussexp", p256)
    add(R, ds, 1024, "pipeline", "gaussexp", p1024)
for ds, T, procs in [("anm", 256, None), ("nonlinear_dependence", 256, None), ("bivariate_gaussian", 256, None),
                     ("iid_gaussian", 256, P3), ("sparse_precision", 256, P3), ("anm", 1024, P2)]:
    add(R, ds, T, "pipeline", "vsridge", procs)
add(R, "trending", 256, "pipeline-detrend", "scratch")
add(R, "trending", 256, "pipeline", "scratch")
add(R, "iid_gaussian", 256, "pipeline", "determinism", P3, "determinism")
add(R, "shared_envelope", 64, "pipeline", "determinism", None, "determinism")
add(R, "anm", 256, "pipeline", "warnings", None, "warnings_count")
for ds, T, procs in [("iid_gaussian", 256, P3), ("delayed_noise", 256, None), ("shared_envelope", 64, None),
                     ("shared_envelope", 256, None), ("narrowband_f0-0.1", 64, None)]:
    add(R, ds, T, "pipeline", "scipy118", procs)
ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids))
json.dump({"family": "gpfit", "runs": runs}, open("/media/dan/Data/git/pyspi/audit/checks/manifest/gpfit.json", "w"), indent=1)
print(len(runs))
