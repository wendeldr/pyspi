import sys, time
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import gpfit as G, numpy as np, make_data
X=G.prep(make_data.load('anm',256)['x'],'pipeline')
t=time.time()
for _ in range(50): G.lml(X[0],X[1],'RBF',np.zeros(3))
print('per eval', (time.time()-t)/50)
rng=np.random.default_rng(1)
for s in rng.uniform(G.LO,G.HI,(5,3)):
    t=time.time(); th,v,r=G.local_fit(X[0],X[1],'RBF',s); print(r.nfev, r.nit, time.time()-t, v, r.message)
