import sys, json, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import gpfit as G, make_data
from threadpoolctl import threadpool_info
runs={r['run_id']:r for r in json.load(open(G.MANIFEST))['runs']}
out={}
for rid in ['misc.gpfit.RBF|shared_envelope|64|pipeline|scipy118','misc.gpfit.RBF|shared_envelope|64|kernel|scratch','misc.gpfit.RBF|shared_envelope|256|pipeline|scipy118']:
    run=runs[rid]; x=np.asarray(make_data.load(run['dataset'],run['T'])['x'],dtype=np.float64)
    if run.get('processes') is not None: x=x[list(run['processes'])]
    tag=rid.split('|')[-1]
    o=G.HANDLERS[tag](run, G.prep(x, run['path']), G.load_npz(rid))
    out[rid]=o['value']
np.savez(sys.argv[1], **{k.replace('|','_'):v for k,v in out.items()})
print(sys.argv[1], [(d['internal_api'], d['num_threads']) for d in threadpool_info()])
