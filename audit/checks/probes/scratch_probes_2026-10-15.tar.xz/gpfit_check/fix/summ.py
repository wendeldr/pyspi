import json, sys
r=json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/results/gpfit.json'))
o=json.load(open('/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/gpfit_check/fix/gpfit.json'))
pat=sys.argv[1] if len(sys.argv)>1 else ''
keys=sys.argv[2].split(',') if len(sys.argv)>2 else None
np_=sum(v.get('pass') is True for v in r.values()); print('n',len(r),'pass',np_,'fail',sum(v.get('pass') is False for v in r.values()), 'other', len(r)-np_-sum(v.get('pass') is False for v in r.values()))
for k in sorted(r):
    if pat in k:
        v=r[k]
        d={kk:vv for kk,vv in v.items() if (keys is None and kk not in ('reference_detail','notes','family','dataset','T','path','identifier','criterion','atol','rtol','nan_mask_equal')) or (keys and kk in keys)}
        ov=o.get(k,{})
        print(k, 'PASS' if v.get('pass') else 'FAIL', json.dumps(d)[:700], '| old max_rel', ov.get('max_rel'))
