p='/media/dan/Data/git/pyspi/audit/notes/gpfit.md'
s=open(p).read()
def rep(old,new):
    global s
    assert old in s, old[:80]
    s=s.replace(old,new)
rep('''- Manifest: `audit/checks/manifest/gpfit.json`, 152 runs (generator: scratchpad `gpfit_check/make_manifest.py`).''',
'''- Manifest: `audit/checks/manifest/gpfit.json`, 163 runs (generator: scratchpad `gpfit_check/make_manifest.py`; the 11 `crossproc`,
  `fixedhp` and `amplitude` runs were appended after the review).''')
rep('''- References: `audit/checks/refs/gpfit.py`, run in the comparison venv. Every correctness reference is numpy/scipy only and uses
  `_kernels_basic_misc` (`gp_posterior_mean`, `gp_log_marginal_likelihood`, `gp_fit`) or its own weight-space Bayesian linear
  regression (`blr_ml2`, `ridge_cf`). None imports scikit-learn, except the `scipy118` runs, which are labelled same-lineage.''',
'''- References: `audit/checks/refs/gpfit.py`, run in the comparison venv. Every correctness reference is numpy/scipy only and uses
  `_kernels_basic_misc` (`gp_posterior_mean`, `gp_log_marginal_likelihood`, `gp_fit`), its own weight-space Bayesian linear
  regression (`blr_ml2`, `ridge_cf`) or its own LML for the C·RBF + W kernel (`amp_lml`, `amp_fit`). None imports scikit-learn, except
  the `scipy118` runs, which are labelled same-lineage.
- Threads: the reference script pins every BLAS to one thread before importing numpy. A first version ran the references with the
  comparison venv's default 64-thread OpenBLAS. At a fixed thread count the reference output is bit-identical across processes, but
  the ill-conditioned shared_envelope fits move with the thread count: the reference values shift by up to 4.7e-9 relative between
  1 and 64 threads (scratchpad `gpfit_check/fix/xp_ref.py`). Two runs at different thread settings therefore gave different
  `scratch` and `scipy118` numbers (e.g. shared_envelope T64 `scipy118` 2.7e-11 vs 4.7e-9). With the pin the numbers below are
  regenerable. The pyspi side needs no pin: `pyspi/__init__.py:4` sets `OMP_NUM_THREADS=1` before `audit/checks/pyspi_outputs.py`
  loads SciPy, so SciPy's OpenBLAS runs on one thread there (measured by `crossproc`, below).''')
rep('''  - `determinism`, `warnings_count`.''','''  - `determinism`, `warnings_count`.
  - `crossproc`: pyspi recomputed in five fresh project-venv processes from the raw rows under different import orders and BLAS
    thread counts.
  - `fixedhp`: sklearn with `optimizer=None`, i.e. the documented hyperparameter values held fixed.
  - `amplitude`: sklearn's standard `ConstantKernel() * RBF() + WhiteKernel()` with 10 restarts (open question 3).''')
rep('''- Results: `audit/checks/out/results/gpfit.json`, **125 pass, 27 fail, 0 without reference**. The 27 failures are findings, not script
  errors:
  - 9 DotProduct `kernel|scratch` runs: raw-data stopping point.
  - 11 RBF `multistart` runs and 2 RBF `params` runs: optimality.
  - 5 RBF `vsridge` runs: RBF above the linear fit.
- Budget: T ≤ 1024, with P ≤ 3 (DotProduct) or P = 2 (RBF) at T = 1024. The pyspi side took about 550 s in total. The longest run was
  `misc.gpfit.RBF|anm|1024|pipeline|params` at 70.6 s, because the probe does three fits per pair. T = 4096 was not run.''',
'''- Results: `audit/checks/out/results/gpfit.json`, **135 pass, 28 fail, 0 without reference**. None of the 28 failures is a script
  error. They fall into three groups:
  - Measurements of pyspi's behaviour (22): 9 DotProduct `kernel|scratch` runs (raw-data stopping point of the optimiser), and 11 RBF
    `multistart` plus 2 RBF `params` runs (optimality).
  - A refuted expectation (5 RBF `vsridge` runs). The record's proposed check expected the RBF MSE never to exceed the linear fit.
    It does exceed it on 30 of 50 pairs. This refutes the expectation; it is not a pyspi defect.
  - An alternative-kernel probe (1 RBF `amplitude` run, nonlinear_dependence). It tests a property of C·RBF + W, not of pyspi's
    kernel. It fails where the input spacing is below the length-scale bound (see below).
- Budget: T ≤ 1024, with P ≤ 3 (DotProduct) or P = 2 (RBF) at T = 1024. The pyspi side took 587 s in total. The longest run was
  `misc.gpfit.RBF|sparse_precision|1024|pipeline|gaussexp` at 42.9 s (under concurrent load). The whole forced re-run took about 18
  minutes wall time. T = 4096 was not run.''')
# DotProduct
rep('''### misc.gpfit.DotProduct: matches, score 7 (anchor 7: optimiser-based unit passing optimality)''',
'''### misc.gpfit.DotProduct: matches, score 9 (anchor 9: matches canonical; the supplement does not describe it)''')
rep('''  - `posterior`: 5/5 pass, max_rel ≤ 7.9e-14.
  - `postmean`: f̄ agrees elementwise to 1.7e-14 (bivariate_gaussian T256) and 1.25e-12 (cointegrated T256 raw). The LML agrees to
    5.7e-14 and 8.0e-13.''','''  - `posterior`: 5/5 pass, max_rel 0 (bit-identical in this run, with the reference BLAS on one thread).
  - `postmean`: f̄, LML and MSE differences are 0 (bivariate_gaussian T256, cointegrated T256 raw).''')
rep('''  - `params`: 4/4 pass. The polish gain is ≤ 8.0e-13, the projected gradient ≤ 9.7e-6, and every fit stopped on PGTOL.
  - `multistart`: 2/2 pass, max LML gain 1.5e-12.''','''  - `params`: 4/4 pass. The polish gain is ≤ 1.8e-12, the projected gradient ≤ 9.7e-6, and every fit stopped on PGTOL.
  - `multistart` (21 starts per pair): 2/2 pass, max LML gain 3.2e-12.''')
rep('''- **Other checks.**
  - `affine` (scaled_offset vs bivariate_gaussian): 1.0e-15.
  - `determinism`: bit-identical.
  - `warnings`: 24 bound warnings on 12/12 pairs, none escape `GPModel.bivariate`.
  - `scipy118`: max_rel 1.2e-15.''','''- **Documented values held fixed** (`fixedhp`, 2/2 pass). The own posterior mean at θ = 0 equals sklearn with `optimizer=None`
  (max_rel 0). On bivariate_gaussian the fixed value differs from pyspi's fitted value by ≤ 9.2e-6 absolute (2.8e-5 relative) at
  T = 256 and ≤ 1.5e-4 (4.7e-4 relative) at T = 64. It equals the ridge (alpha = 1) closed form to ≤ 3.3e-14.
- **Other checks.**
  - `affine` (scaled_offset vs bivariate_gaussian): 1.0e-15.
  - `determinism`: bit-identical within one process.
  - `warnings`: 24 bound warnings on 12/12 pairs, none escape `GPModel.bivariate`.
  - `scipy118`: max_rel 1.7e-15.''')
rep('''- **Score.** Score 7 is the cap stated for ML-II units, which cannot be verified exactly. The posterior is fp-exact (analytic reference)
  and the optimum passes both local and multi-start optimality. `new_finding` is true for candidate 1. It is not in KNOWN_ISSUES.md;
  REVIEW M9 discusses label structure only in general.''','''- **Score.** Score 9. The first version gave 7 and called anchor 7 a cap for ML-II units, but the README states no such cap. Anchor
  7 describes an optimiser unit that is verified only by optimality checks. This unit is verified more strongly. On the default
  (z-scored) path an independent global ML-II (`blr_ml2`, no sklearn) reproduces pyspi to 2.4e-9, and the posterior is fp-exact
  against the analytic ridge form. It is not 10, because the supplement does not describe the computation:
  - the documented values are fitted, not fixed (≤ 9.2e-6 at T = 256, ≤ 1.5e-4 at T = 64, `fixedhp`);
  - "nonparametric", "nonlinear" and "directed" do not fit a symmetric linear function of r².

  This follows the rubric as applied to distance.hhg (9: canonical computation that the supplement misdescribes). The class labels
  are metadata, as for kendalltau and pdist.cosine, so anchor 3 ("label does not describe the computation", used for identifier
  hyperparameters) does not apply. The raw-data stopping point (≤ 1.35e-4 relative, non-default path) is an optimiser tolerance.
  `new_finding` is true for candidate 1. It is not in KNOWN_ISSUES.md; REVIEW M9 discusses label structure only in general.''')
# RBF
rep('''  - `posterior`: 12/12 pass, max_rel 4.0e-11 on shared_envelope, where the values are as small as 5e-11, and ≤ 9.4e-15 elsewhere.
  - `postmean`: 3/3 pass. f̄ agrees elementwise to ≤ 1.8e-14 and the LML to ≤ 2.1e-12.
- **Single start.** `scratch` uses an own L-BFGS-B from θ = 0 in the sklearn box with default options. It passes 14/14 within rtol 1e-6,
  with max_rel 2.1e-7 on shared_envelope T64 raw and ≤ 5.0e-11 elsewhere.''','''  - `posterior`: 12/12 pass. max_rel is 3.1e-11 (T64) and 5.3e-12 (T256) on shared_envelope, where the values are as small as
    5e-11, and ≤ 1.7e-14 elsewhere.
  - `postmean`: 3/3 pass. f̄ agrees elementwise to ≤ 1.9e-14 and the LML to ≤ 2.1e-12.
- **Single start.** `scratch` uses an own L-BFGS-B from θ = 0 in the sklearn box with default options. It passes 14/14 within rtol 1e-6.
  max_rel is 2.1e-7 on shared_envelope T64 raw, 4.3e-9 on shared_envelope T256 raw, and ≤ 1.7e-11 elsewhere.''')
rep('''  - The own multi-start (θ = 0 plus 20 starts at T = 64, 10 at T = 256) finds a higher LML (gain > 1e-3) on **99 of 128** ordered
    pairs. The value changes by > 1e-3 on 98 of them.''','''  - The own multi-start (θ = 0 plus 20 log-uniform starts at every T) finds a higher LML (gain > 1e-3) on **100 of 128** ordered
    pairs. The value changes by > 1e-3 on 99 of them. The trace stage proposed this check on the kernel (raw) path. It was run on the
    pipeline path, which is pyspi's default. A first version used only 10 starts at T = 256; the counts above use 20.''')
rep('''    | shared_envelope | 256 | 5/12 |''','''    | shared_envelope | 256 | 6/12 |''')
rep('''  - The best fit interpolates on 72 pairs (w at 1e-5, l below the input spacing, MSE about 1e-10). For example, iid_gaussian T256 0→1
    goes from 0.996094 to 2.5e-10, with LML +2.89 and LOO 0.9946.''','''  - The best fit interpolates on 71 pairs (w at 1e-5, l below the input spacing, MSE about 1e-10). For example, iid_gaussian T256 0→2
    goes from 0.996094 to 9.96e-11, with LML +2.773 and LOO 0.9961.''')
rep('''- **Other checks.**
  - `affine`: 2.4e-12.
  - `determinism`: bit-identical on iid_gaussian T256 and shared_envelope T64.
  - `warnings`: 11 bound warnings on 10/12 pairs, none escape.
  - `scipy118`: 5/5, max_rel 2.7e-11, with no basin change between SciPy 1.17.1 and 1.18.1.''','''- **Documented values held fixed** (`fixedhp`, 3/3 pass). The own posterior mean at θ = 0 equals sklearn with `optimizer=None`
  (max_rel 0). Fixing the values changes pyspi's output substantially:
  - shared_envelope T64 A[0,1]: 0.661 instead of 1.1e-8;
  - iid_gaussian T256: 0.970-0.992 instead of 0.996094 everywhere (difference up to 0.026);
  - nonlinear_dependence T256 A[0,1]: 0.0387 instead of 0.0260.
- **Standard amplitude kernel** (`amplitude`, C·RBF + W, 2/3 pass). The reference uses its own LML for that kernel. At l = 1e-5 the
  RBF Gram is close to I, so the LML depends on C + w only. It compares the two ends of that ridge: interpolating (w = 1e-5, MSE
  1.0e-10) and white noise (C = 1e-5, MSE 0.996).
  - The two ends tie to ≤ 2.3e-4 in LML on all 12 iid_gaussian and delayed_noise pairs. They also tie (≤ 6.2e-8) on the 6
    nonlinear_dependence pairs whose input is x0 or x1.
  - The run fails on the 6 nonlinear_dependence pairs whose input is x2 or x3 (differences up to 11.2). Those inputs have minimum
    spacings of 6.4e-6 and 6.8e-6, below the 1e-5 length-scale bound, so the Gram at l = 1e-5 is not close to I there.
  - Under pyspi's C + W + RBF, the interpolating mode beats the flat no-signal mode by 2.7733 on every iid_gaussian and delayed_noise
    pair. This is about ½ log T = 2.7726, the Occam cost of the forced unit-amplitude constant on z-scored data.
- **Other checks.**
  - `affine`: 2.4e-12.
  - `determinism`: bit-identical within one process on iid_gaussian T256 and shared_envelope T64.
  - `crossproc` (3/3 pass): five fresh processes on shared_envelope T64 and T256 and iid_gaussian T256.
    - Two processes with `pyspi_outputs.py`'s import order (numpy, then pyspi, then sklearn) reproduce the stored output bit for bit
      (12/12, 12/12, 6/6). So do a process that imports pyspi first and one with `OPENBLAS_NUM_THREADS=1`.
    - When `scipy.linalg` is imported before pyspi, SciPy's OpenBLAS keeps its 64 threads. The values then move by 2.8e-9
      (shared_envelope T64), 4.1e-11 (T256) and 1.0e-15 (iid_gaussian T256) relative, with no basin change.
  - `warnings`: 11 bound warnings on 10/12 pairs, none escape.
  - `scipy118`: 5/5, max_rel 2.7e-11 (shared_envelope T64, 6/12 entries bit-identical), with both sides' SciPy OpenBLAS on one
    thread. There is no basin change between SciPy 1.17.1 and 1.18.1. A SciPy-version effect below about 1e-9 cannot be
    separated from thread-count effects of the same size (`crossproc`).''')
rep('''  7. random_state no-op.''','''  7. random_state no-op. The result is deterministic given the data and the BLAS thread count, and reproducible across processes
     for a fixed import order (`crossproc`).''')
# OQs
rep('''1. **Were the documented values meant to be fixed?** The code and the evidence cannot settle intent. The supplement's "parameters chosen
   from default settings" fits both readings. The checks measure what is at stake (throwaway probe scratchpad `gpfit_check/oq1_fixed.py`,
   own kernels at θ = 0):
   - DotProduct: fixing the values changes bivariate_gaussian T256 by ≤ 9.2e-6. Analytically, fixed noise 1 makes the unit equal to
     lmfit Ridge(alpha = 1) on z-scored data.
   - RBF: fixing them gives a fixed-bandwidth smoother, so the interpolation mode disappears. shared_envelope T64 A[0,1] would be 0.661,
     not 1.1e-8. iid_gaussian T256 entries would range over 0.970-0.992, not sit at (T−1)/T. nonlinear_dependence T256 A[0,1] would be
     0.0387, not 0.0260.''','''1. **Were the documented values meant to be fixed?** The code and the evidence cannot settle intent. The supplement's "parameters chosen
   from default settings" fits both readings. The `fixedhp` runs measure what is at stake: own kernels at θ = 0, equal to sklearn with
   `optimizer=None`.
   - DotProduct (`misc.gpfit.DotProduct|bivariate_gaussian|{64,256}|pipeline|fixedhp`): fixing the values changes the output by
     ≤ 9.2e-6 at T = 256 and ≤ 1.5e-4 at T = 64. The fixed version equals the ridge (alpha = 1) closed form to ≤ 3.3e-14, i.e.
     lmfit Ridge(alpha = 1) on z-scored data.
   - RBF (`misc.gpfit.RBF|{iid_gaussian,nonlinear_dependence}|256|pipeline|fixedhp`, `|shared_envelope|64|pipeline|fixedhp`): fixing
     them gives a fixed-bandwidth smoother, so the interpolation mode disappears. shared_envelope T64 A[0,1] would be 0.661, not 1.1e-8.
     iid_gaussian T256 entries would range over 0.970-0.992, not sit at (T−1)/T. nonlinear_dependence T256 A[0,1] would be 0.0387, not
     0.0260.''')
rep('''3. **Does C·RBF + White remove the degenerate optimum?** In the tested cases, yes (throwaway probe scratchpad
   `gpfit_check/oq3_amplitude.py`, sklearn with 10 restarts, random_state 0). With the amplitude hyperparameter, 0 of 24 pairs
   interpolate (iid_gaussian, delayed_noise and nonlinear_dependence at T256). pyspi's specification interpolates on 20 of 24.
   Multi-start in-sample values on iid pairs still range from 0.487 to 0.996, so an in-sample score stays start-dependent. A predictive
   score (question 2) would still be needed.''','''3. **Does C·RBF + White remove the degenerate optimum?** No. It changes a strict preference into a tie (`amplitude` runs on
   iid_gaussian, delayed_noise and nonlinear_dependence at T256). A first version of this answer said "yes", based on a throwaway sklearn
   probe in which 0 of 24 restarted fits interpolated. That showed only which end of a tie sklearn's restarts reached.
   - In pyspi's C + W + RBF, the interpolating mode beats the flat no-signal mode by 2.7733 in LML (≈ ½ log T), so ML-II strictly
     prefers it.
   - In C·RBF + W, the interpolating fit (MSE 1.0e-10) and pure white noise (MSE 0.996) lie on one LML ridge. They tie to ≤ 2.3e-4
     wherever the input spacing exceeds the 1e-5 length-scale bound (18 of 24 pairs).
   - sklearn's 10 restarts (random_state 0) returned no interpolating fit (0/24, MSE 0.487-0.996 on iid pairs). The own 21-start
     optimum is interpolating on 5 of 24 pairs and beats the tie by more than 1e-3 on 18. sklearn's result is up to 9.0 below the own
     optimum in LML.
   - An in-sample score therefore stays degenerate and start-dependent with the standard kernel too. A predictive (LOO) score
     (question 2) is what removes the problem.''')
rep('''5. **Can SciPy or BLAS versions change the basin?** SciPy 1.17.1 → 1.18.1 does not, on 5 datasets including both shared_envelope sizes
   and narrowband (`scipy118`, max_rel ≤ 2.7e-11). The factr stops on near-flat plateaus (`params`: θ moves up to 5.8 log units under a
   polish) mean that environment changes can move such values at the 1e-6 to 1e-4 level. BLAS builds were not varied.''','''5. **Can SciPy or BLAS versions change the basin?** Not on the tested data.
   - SciPy 1.17.1 → 1.18.1, at matched BLAS thread counts, changes values by ≤ 2.7e-11 on 5 datasets, including both shared_envelope
     sizes and narrowband (`scipy118`).
   - The OpenBLAS thread count changes values by up to 2.8e-9 (`crossproc`). Which count applies depends on import order:
     `pyspi/__init__.py:4` sets `OMP_NUM_THREADS=1`, and this reaches SciPy's OpenBLAS only if `scipy.linalg` was not loaded before
     `import pyspi`.
   - Neither effect moved a value across basins here. The factr stops on near-flat plateaus (`params`: θ moves up to 5.8 log units
     under a polish) mean that environment changes can move such values at the 1e-6 to 1e-4 level. Different BLAS builds were not
     tested.''')
open(p,'w').write(s)
