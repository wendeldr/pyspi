import numpy as np, sys, warnings
from pyspi.statistics.misc import GPModel
from pyspi.data import Data
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); import make_data
O='/media/dan/Data/git/pyspi/audit/checks/out/pyspi/'
rid='misc.gpfit.RBF|shared_envelope|256|pipeline|scipy118'
d=np.load(O+rid+'.npz'); v=d['value']
for name, x in [('stored-input(prepped)', d['input']), ('raw make_data', np.asarray(make_data.load('shared_envelope',256)['x'],dtype=np.float64))]:
    D=Data(x.copy(),dim_order='ps')
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        A=GPModel(kernel='RBF').multivariate(D)
    np.fill_diagonal(A,np.nan)
    print(name, 'max_rel %.2e'%np.nanmax(abs(A-v)/abs(v)), 'nbit', int(np.nansum(A==v)), 'input max|zz - z|', np.max(abs(D.to_numpy(squeeze=True)-d['input'])))
