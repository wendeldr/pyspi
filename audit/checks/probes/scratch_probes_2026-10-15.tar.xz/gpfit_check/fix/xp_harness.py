import sys, warnings
sys.path.insert(0,'/media/dan/Data/git/pyspi/tests'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import numpy as np
from regression import harness
import make_data
from threadpoolctl import threadpool_info
print('a', [(d['internal_api'], d['num_threads'], d['filepath'].split('/')[-1]) for d in threadpool_info()])
if sys.argv[2] == 'jvm':
    harness.ensure_jvm(); harness.import_statistics_modules()
print('b', [(d['internal_api'], d['num_threads'], d['filepath'].split('/')[-1]) for d in threadpool_info()])
from pyspi.statistics.misc import GPModel
from pyspi.data import Data
x = np.asarray(make_data.load('shared_envelope', 256)["x"], dtype=np.float64)
d = Data(x.copy(), dim_order="ps")
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    A = GPModel(kernel="RBF").multivariate(d)
print('c', [(d['internal_api'], d['num_threads'], d['filepath'].split('/')[-1]) for d in threadpool_info()])
np.fill_diagonal(A, np.nan)
st=np.load('/media/dan/Data/git/pyspi/audit/checks/out/pyspi/misc.gpfit.RBF|shared_envelope|256|pipeline|scipy118.npz')['value']
od=~np.eye(len(A),dtype=bool)
print(sys.argv[1], 'nbit vs stored', int(np.sum(A[od]==st[od])), 'max_rel %.2e' % np.max(abs(A[od]-st[od])/abs(st[od])))
