import yaml
R='/media/dan/Data/git/pyspi/audit/records/'
u='misc.gpfit.RBF'
d=yaml.safe_load(open(R+u+'.yaml')); c=d['correctness']
c['check_reference'] = ("audit/checks/refs/gpfit.py:h_posterior and h_postmean -> audit/checks/refs/_kernels_basic_misc.py:gp_posterior_mean + gp_log_marginal_likelihood "
 "(Cholesky, R&W Alg. 2.1 and eqs. 5.8-5.9, no sklearn) at sklearn's fitted theta (probes/gpfit_probes.py:params, :postmean); audit/checks/refs/gpfit.py:h_scratch "
 "-> _kernels_basic_misc.gp_fit (own single L-BFGS-B start from theta = 0 in the sklearn box) + gp_posterior_mean; h_params (projected gradient "
 "and tight polish under the independent LML); h_multistart (own multi-start ML-II, theta = 0 plus 20 log-uniform starts at every T, plus the "
 "interpolation formula (w'/(1 + w'))^2 mean(y^2)); h_identity (residual identity w'^2 |K^-1 y|^2 / T and LOO R&W eq. 5.12, same-lineage theta); "
 "h_gaussexp (analytic ((T-1)/T)(1 - r^2)); h_vsridge (analytic Ridge(alpha=1) MSE, cross-checked with pyspi's misc.lmfit.Ridge outputs); "
 "h_direction; h_fixedhp (own posterior mean at the documented, fixed hyperparameters vs sklearn optimizer=None, probes/gpfit_probes.py:fixedhp); "
 "h_amplitude (own numpy LML for ConstantKernel()*RBF() + WhiteKernel(), amp_lml/amp_fit, vs sklearn with 10 restarts, probes/gpfit_probes.py:amplitude); "
 "h_affine, h_determinism, h_crossproc (probes/gpfit_probes.py:crossproc, fresh processes), h_warnings, h_scipy118 (same-lineage). The reference "
 "process pins every BLAS to one thread (refs/gpfit.py top).")
c['check_data'] = c['check_data'].rstrip() + ("; fixedhp: iid_gaussian T256 (P=3), nonlinear_dependence T256, shared_envelope T64 (pipeline); amplitude: "
 "iid_gaussian and delayed_noise T256 (P=3), nonlinear_dependence T256 (pipeline); crossproc: shared_envelope T64/T256, iid_gaussian T256 (P=3)")
c['agreement_criterion'] = ("exact rtol 1e-8, atol 1e-12 at sklearn's theta (posterior; postmean elementwise atol 1e-10); tolerance rtol 1e-6 vs an "
 "own single start from theta = 0 (scratch); optimality: polish gain <= 1e-3 (params, local) and no multi-start optimum (21 starts) higher by > 1e-3 in "
 "LML (multistart, global); same-lineage exact rtol 1e-10 for the residual identity; analytic Gaussian expectation rtol 0.1 (T256) / 0.05 (T1024); "
 "exact rtol 1e-8 for the fixed-hyperparameter posterior (fixedhp); qualitative: RBF MSE <= Ridge MSE on every pair, orientation and cause -> effect "
 "ordering, bit-identical in-process recomputation, cross-process bit-identity under the pipeline import order and rtol 1e-6 under every import "
 "mode (crossproc), warning counts, |LML(interpolating) - LML(white noise)| <= 1e-3 under C*RBF + W (amplitude); same-lineage rtol 1e-6 for SciPy 1.18.1")
c['closeness'] = ("Posterior arithmetic: posterior 12/12 pass, max_rel 3.1e-11 (shared_envelope T64) and 5.3e-12 (T256), <= 1.7e-14 elsewhere; postmean 3/3, "
 "f_bar elementwise <= 1.9e-14, LML difference <= 2.1e-12. Single start: scratch 14/14 within rtol 1e-6, max_rel 2.1e-7 (shared_envelope T64 "
 "kernel), 4.3e-9 (shared_envelope T256 kernel), <= 1.7e-11 elsewhere, raw data and trending (pipeline and detrended) included. Local optimality: "
 "params 10/12 pass; anm T256 (gain 1.85e-3) and delayed_noise T256 (1.31e-3) fail, stopped on factr on a near-flat l -> 1e5 plateau with the MSE "
 "moving <= 6.7e-6 relative; MSE change under polish <= 1.2e-4 over all 12 runs; n_restarts_optimizer 0 everywhere. Global optimality: multistart "
 "0/11 pass. Own multi-start (21 starts) finds a higher LML (> 1e-3) on 100 of 128 ordered pairs (iid_gaussian T64 20/20, T256 6/6; delayed_noise "
 "T64 and T256 12/12; nonlinear_dependence T64 and T256 11/12; anm T256 8/12; bivariate_gaussian T256 8/12; narrowband_f0-0.1 T64 4/6; "
 "shared_envelope T64 2/12, T256 6/12), with the value changing by > 1e-3 on 99. Maximum LML gain 419.4 (shared_envelope T256), 58.4 (narrowband T64 "
 "1->0). On 12 best fits with l <= 0.1 x min input spacing, the MSE equals (w'/(1 + w'))^2 mean(y^2) to <= 5.5e-11 relative. Identity "
 "(same-lineage) 4/4, max_rel 2.3e-11. Gaussian expectation: gaussexp 8/8, max_rel 0.063 (bivariate_gaussian T256) -> 5.1e-4 (T1024), "
 "sparse_precision 0.0157 -> 1.6e-3, gauss_ar1_pair 7.7e-3 -> 2.3e-4, iid_gaussian 1.1e-3 -> 4.5e-5. Versus linear Ridge: vsridge 1/6. RBF "
 "exceeds the Ridge(alpha=1) MSE on iid_gaussian 6/6, bivariate_gaussian 10/12, nonlinear_dependence 8/12, anm T256 4/12 and sparse_precision 2/6 "
 "pairs (excess at most 0.0063 absolute on anm T256, 1.8% relative on bivariate_gaussian T256), and is lower by up to 0.970 on nonlinear_dependence. "
 "The Ridge values equal pyspi's misc.lmfit.Ridge|<dataset>|<T>|pipeline|closedform to <= 2.2e-15. Documented values held fixed: fixedhp 3/3 "
 "(own vs sklearn optimizer=None max_rel 0); fixed minus fitted up to 0.661 absolute on shared_envelope T64 (A[0,1] 0.661 vs 1.1e-8), 0.026 on "
 "iid_gaussian T256 (fixed range 0.970-0.992 vs 0.996094), 0.0126 on nonlinear_dependence T256 (A[0,1] 0.0387 vs 0.0260). C*RBF + W "
 "(amplitude): 2/3 pass; the interpolating and white-noise ends of the l = 1e-5 ridge tie to <= 2.3e-4 in LML on all 12 iid_gaussian and "
 "delayed_noise pairs and on the 6 nonlinear_dependence pairs with input x0 or x1 (<= 6.2e-8), and differ by up to 11.2 on the 6 pairs with input "
 "x2 or x3, whose minimum spacing (6.4e-6, 6.8e-6) is below the 1e-5 length-scale bound; under pyspi's C + W + RBF the interpolating mode beats "
 "the flat mode by 2.7733 on every iid_gaussian and delayed_noise pair (0.5 log T = 2.7726). Reproducibility: crossproc 3/3, two fresh processes "
 "with the pipeline import order bit-identical to the stored output (12/12, 12/12, 6/6), SciPy's OpenBLAS at 64 instead of 1 thread moves values by "
 "2.8e-9 (shared_envelope T64), 4.1e-11 (T256), 1.0e-15 (iid_gaussian T256) relative; scipy118 5/5, max_rel 2.7e-11 at matched BLAS threads. "
 "Other: affine 2.4e-12.")
c['what_changed'] = c['what_changed'].replace("reproduces pyspi's values to <= 2.1e-7", "reproduces pyspi's values to <= 2.1e-7 (<= 1.7e-11 outside shared_envelope)") \
    .replace("which is below the multi-start optimum\n    on 99 of 128 pairs", "which is below the multi-start optimum on 100 of 128 pairs").replace("on 99 of 128 pairs", "on 100 of 128 pairs")
c['check_cost'] = ("expensive: one sklearn fit takes 0.44 s at T=256 and 5.6 s at T=1024 under concurrent load (O(T^3) per LML evaluation, 6-33 "
 "L-BFGS-B iterations). A P=2 matrix at T=1024 took 14-43 s; the 3-fit params probe at T=1024, P=2 took 36-71 s; the crossproc probe (five fresh "
 "processes) took 18-34 s. Checks used T <= 1024 with P = 2 at T=1024; T=4096 was not run. Own multi-start references (21 starts per pair) were run "
 "at T <= 256 only. Deviation from the proposed multi-start check: it was run on the pipeline (z-scored) path, pyspi's default, instead of the "
 "kernel (raw) path, and on 11 dataset/T combinations including bivariate_gaussian and narrowband_f0-0.1; the proposed 20 log-uniform starts "
 "plus theta = 0 are used at every T. Full family re-run (pyspi side and references): about 18 minutes wall time.")
cr=c['candidate_resolutions']
cr[0]['evidence'] = ("misc.gpfit.RBF|*|pipeline|multistart (11 runs, 21 starts per pair): higher LML on 100/128 pairs, value change > 1e-3 on 99; the "
 "best fit interpolates on 71 pairs (e.g. iid_gaussian T256 0->2: 0.996094 -> 9.96e-11, LML +2.773, LOO 0.9961). The single start converges "
 "locally (|params runs, 10/12 pass the polish test). Not in KNOWN_ISSUES.md.")
cr[1]['evidence'] = ("misc.gpfit.RBF|iid_gaussian|64|pipeline|multistart (7 pairs), |iid_gaussian|256| (1), |nonlinear_dependence|64| (4): own multi-start "
 "optima with l <= 0.1 x min input spacing match (w'/(1 + w'))^2 mean(y^2) to <= 5.5e-11 relative (interp_formula_max_rel). Why the fixed "
 "amplitude matters: |iid_gaussian|256|pipeline|amplitude and |delayed_noise|256|pipeline|amplitude: under pyspi's C + W + RBF the interpolating "
 "mode beats the flat no-signal mode by 2.7733 in LML on all 12 pairs (0.5 log T = 2.7726, the Occam cost of the forced unit-amplitude constant), "
 "so interpolation is strictly preferred; under C*RBF + W the interpolating end (MSE 1.0e-10) and the white-noise end (MSE 0.996) of the l = 1e-5 "
 "ridge tie to <= 2.3e-4, so the amplitude turns the mode into an LML tie rather than removing it (|nonlinear_dependence|256|pipeline|amplitude fails "
 "this tie on the 6 pairs whose input has spacings below 1e-5).")
cr[6]['candidate'] = 'random_state is a no-op; deterministic given data and BLAS'
cr[6]['evidence'] = ("misc.gpfit.RBF|iid_gaussian|256|pipeline|determinism and |shared_envelope|64|pipeline|determinism: bit-identical over 5 "
 "recomputations within one process (random_state 0 and 12345, reseeded numpy/random); params runs: 0 draws from gp._rng, n_restarts_optimizer 0. "
 "Across processes (|shared_envelope|64|, |shared_envelope|256|, |iid_gaussian|256|pipeline|crossproc): fresh processes with the pipeline import "
 "order, with pyspi imported first, or with OPENBLAS_NUM_THREADS=1 reproduce the stored output bit for bit; 'given BLAS' includes the thread "
 "count of SciPy's OpenBLAS, which pyspi/__init__.py:4 (OMP_NUM_THREADS=1) sets only if scipy.linalg is not loaded before 'import pyspi'. "
 "With SciPy loaded first (64 threads) values move by up to 2.8e-9 relative (shared_envelope T64), no basin change.")
runs=c['checks_run']
for r in runs:
    o=r['outcome']
    if o.startswith('15/15 pass'): o='15/15 pass; max_rel 3.1e-11 (shared_envelope), <= 1.7e-14 elsewhere'
    if o.startswith('14/14 pass'): o='14/14 pass; max_rel 2.1e-7 (shared_envelope T64 raw), 4.3e-9 (T256 raw), <= 1.7e-11 elsewhere'
    if o.startswith('0/11 pass'): o='0/11 pass; 21 starts per pair; higher LML on 100/128 pairs, max gain 419.4; interpolation formula 5.5e-11'
    if o.startswith('8/8 pass; bit-identical'): o=('8/8 pass; bit-identical within the process; 11 bound warnings, 0 escape; SciPy 1.18.1 max_rel 2.7e-11 at '
        'matched BLAS threads (shared_envelope T64, 6/12 entries bit-identical)')
    r['outcome']=o
if not any('crossproc' in x for r in runs for x in r['run_ids']):
    runs.append(dict(run_ids=['misc.gpfit.RBF|shared_envelope|64|pipeline|crossproc','misc.gpfit.RBF|shared_envelope|256|pipeline|crossproc','misc.gpfit.RBF|iid_gaussian|256|pipeline|crossproc'],
        reference='audit/checks/refs/gpfit.py:h_crossproc (same-lineage, five fresh project-venv processes vs the stored output)',
        outcome='3/3 pass; pipeline import order bit-identical across processes; SciPy OpenBLAS at 64 threads moves values by <= 2.8e-9 relative'))
    runs.append(dict(run_ids=['misc.gpfit.RBF|iid_gaussian|256|pipeline|fixedhp','misc.gpfit.RBF|nonlinear_dependence|256|pipeline|fixedhp','misc.gpfit.RBF|shared_envelope|64|pipeline|fixedhp'],
        reference='audit/checks/refs/gpfit.py:h_fixedhp (_kernels_basic_misc.gp_posterior_mean at theta = 0; probes/gpfit_probes.py:fixedhp)',
        outcome='3/3 pass (max_rel 0); fixed minus fitted up to 0.661 (shared_envelope T64), 0.026 (iid_gaussian T256), 0.0126 (nonlinear_dependence T256)'))
    runs.append(dict(run_ids=['misc.gpfit.RBF|iid_gaussian|256|pipeline|amplitude','misc.gpfit.RBF|delayed_noise|256|pipeline|amplitude','misc.gpfit.RBF|nonlinear_dependence|256|pipeline|amplitude'],
        reference='audit/checks/refs/gpfit.py:h_amplitude (own LML for C*RBF + W, amp_lml/amp_fit; probes/gpfit_probes.py:amplitude)',
        outcome=('2/3 pass; tie <= 2.3e-4 on 18/24 pairs; fails on the 6 nonlinear_dependence pairs with input spacing < 1e-5 (up to 11.2); '
                 'pyspi-model interpolation advantage 2.7733 = 0.5 log T')))
yaml.safe_dump(d, open(R+u+'.yaml','w'), sort_keys=False, width=140, allow_unicode=False)
print(c['what_changed']); print([r['outcome'] for r in runs])
