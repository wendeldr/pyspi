import sys, warnings, contextlib, io, time
import numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
import make_data
from pyspi.statistics.misc import GPModel
from pyspi.data import Data
ds, T, out = sys.argv[1], int(sys.argv[2]), sys.argv[3]
x = np.asarray(make_data.load(ds, T)["x"], dtype=np.float64)
with contextlib.redirect_stdout(io.StringIO()):
    d = Data(x.copy(), dim_order="ps")
t=time.time()
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    A = GPModel(kernel="RBF").multivariate(d)
np.save(out, A); print(out, time.time()-t)
