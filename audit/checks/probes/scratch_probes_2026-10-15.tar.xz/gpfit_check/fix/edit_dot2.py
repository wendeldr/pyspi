import yaml
R='/media/dan/Data/git/pyspi/audit/records/'
u='misc.gpfit.DotProduct'
d=yaml.safe_load(open(R+u+'.yaml')); c=d['correctness']
rep={'7/7 pass; max_rel <= 1.6e-13; f_bar elementwise <= 1.25e-12':'7/7 pass; max_rel 0 (bit-identical in this run, reference BLAS on one thread); f_bar, LML and MSE differences 0',
 '8/8 pass; polish gain <= 8.0e-13 on z-scored data, 7.5e-5 on raw anm; multi-start gain <= 1.5e-12':'8/8 pass; polish gain <= 1.8e-12 on z-scored data, 7.5e-5 on raw anm; multi-start (21 starts) gain <= 3.2e-12',
 '3/3 pass; bit-identical; 24 bound warnings, 0 escape; SciPy 1.18.1 max_rel 1.2e-15':'3/3 pass; bit-identical within the process; 24 bound warnings, 0 escape; SciPy 1.18.1 max_rel 1.7e-15'}
for r in c['checks_run']:
    r['outcome']=rep.get(r['outcome'], r['outcome'])
cr=c['candidate_resolutions'][2]
cr['evidence']=("misc.gpfit.DotProduct|iid_gaussian|256|pipeline|determinism: bit-identical within one process over two multivariate calls, "
 "random_state 0 and 12345, and after reseeding numpy/random (cross-process reproducibility was tested on RBF only, misc.gpfit.RBF|*|crossproc); "
 "params runs: n_restarts_optimizer 0, 0 draws from gp._rng; |multistart runs (21 starts): no start beats pyspi (max LML gain 3.2e-12 anm T256, "
 "4.5e-13 iid_gaussian T256).")
yaml.safe_dump(d, open(R+u+'.yaml','w'), sort_keys=False, width=140, allow_unicode=False)
print([r['outcome'] for r in c['checks_run']])
