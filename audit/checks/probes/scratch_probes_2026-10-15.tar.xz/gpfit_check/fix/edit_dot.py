import yaml
R='/media/dan/Data/git/pyspi/audit/records/'
u='misc.gpfit.DotProduct'
d=yaml.safe_load(open(R+u+'.yaml'))
c=d['correctness']
c['check_reference'] = c['check_reference'].rstrip() if 'h_fixedhp' in c['check_reference'] else c['check_reference'].rstrip() + '; audit/checks/refs/gpfit.py:h_fixedhp (_kernels_basic_misc.gp_posterior_mean at theta = 0, i.e. the documented values held fixed, against sklearn with optimizer=None, probes/gpfit_probes.py:fixedhp)'
if 'fixedhp' not in c['check_data']:
    c['check_data'] = c['check_data'].rstrip() + '; fixedhp: bivariate_gaussian T64 and T256 (pipeline)'
if 'fixedhp' not in c['agreement_criterion']:
    c['agreement_criterion'] = c['agreement_criterion'].rstrip() + '; fixedhp: exact rtol 1e-8 (own posterior mean at the documented, fixed hyperparameters vs sklearn optimizer=None)'
c['closeness'] = ("Posterior arithmetic (reference BLAS pinned to one thread): ridgecf 5/5 pass, max_rel <= 7.4e-15 on z-scored data (anm, bivariate_gaussian, "
 "iid_gaussian, nonlinear_dependence T256) and 2.0e-13 on raw cointegrated T256 where c and sigma_0 matter; posterior 5/5, max_rel 0 (bit-identical "
 "in this run); postmean 2/2, f_bar, LML and MSE differences 0 (bivariate_gaussian T256, cointegrated T256 raw). ML-II on z-scored data: scratch "
 "(global BLR optimum) 8/8 pass, max_rel 2.4e-9; params 4/4, polish gain <= 1.8e-12, projected gradient <= 9.7e-6, every fit stopped on PGTOL; "
 "multistart (21 starts) 2/2, max LML gain 3.2e-12. Raw data (kernel path): scratch 4/13 pass, 9 fail with max_rel 1.35e-4 (anm T256), 1.2e-6 "
 "(cointegrated T256), <= 8.6e-7 elsewhere; single 5/5 pass with max_rel <= 2.4e-9, and the single start's gap to the global optimum equals "
 "pyspi's (anm T256: LML 7.5e-5 below, MSE 1.35e-4 relative; cointegrated T256: 6.0e-6, 1.2e-6); params anm T256 kernel polish gain 7.5e-5, "
 "MSE change 1.35e-4 relative; cointegrated T256 kernel 8/12 fits stopped on the factr test (theta moves up to 1.13 under the polish). Closed "
 "form: closedform 14/14, max relative difference to ((T-1)/T)(1 - r^2) 5.4e-5 to 6.1e-5 at T=64, <= 3.8e-6 at T=256, <= 6.9e-8 at T=1024 "
 "(trending detrended 6.8e-8). Documented values held fixed (fixedhp, 2/2 pass, own vs sklearn optimizer=None max_rel 0): the fixed-hyperparameter "
 "value differs from pyspi's fitted value by <= 9.2e-6 absolute (2.8e-5 relative) at T=256 and <= 1.5e-4 (4.7e-4 relative) at T=64 on "
 "bivariate_gaussian, and equals the ridge (alpha = 1) closed form to <= 3.3e-14. Other: affine scaled_offset vs bivariate_gaussian 1.0e-15; "
 "scipy118 max_rel 1.7e-15.")
c['score_0_10'] = 9
c['what_changed'] = ("The estimator matches canonical GP regression with ML-II hyperparameters. With Constant + White + DotProduct, the GP is Bayesian "
 "linear regression, and pyspi's value is the in-sample MSE of the posterior mean at the type-II ML hyperparameters. It is reproduced at sklearn's "
 "theta to <= 2.0e-13 (analytic ridge form), and on the default (z-scored) path it equals an independent global ML-II optimum to <= 2.4e-9 "
 "(blr_ml2, no sklearn). Score 9, not 10, by the README anchor 9 as applied to distance.hhg: the computation matches canonical on independent "
 "references, but the supplement does not describe it. (a) The documented values sigma_0 = 1, constant 1 and noise 1 are only starting points "
 "and are fitted. Holding them fixed changes the value by <= 9.2e-6 at T=256 and <= 1.5e-4 at T=64 (fixedhp runs); the fixed version is the "
 "ridge (alpha = 1) fit. (b) The labels nonlinear and directed, and the word 'nonparametric', do not describe the computation. The value is "
 "((T-1)/T)(1 - r^2) to <= 6.1e-5 relative, symmetric to <= 8.1e-15, and blind to x1 = x0^2 (0.995776 both ways). Other recorded deviations: "
 "(1) On raw (normalise=False) data, sklearn's single L-BFGS-B start stops on the factr test along the flat c + sigma_0^2 direction, up to 7.5e-5 "
 "below the ML-II maximum, which moves the value by <= 1.35e-4 relative. This is an optimiser tolerance on a non-default path; it does not "
 "arise under the default z-scoring, where c and sigma_0 do not affect the prediction. (2) The score is an in-sample error, not a predictive error. "
 "The earlier score of 7 rested on reading anchor 7 as a cap for optimiser units; the README has no such cap.")
# checks_run additions
runs=[r for r in c['checks_run']]
if not any('fixedhp' in x for r in runs for x in r['run_ids']):
    runs.append(dict(run_ids=['misc.gpfit.DotProduct|bivariate_gaussian|256|pipeline|fixedhp','misc.gpfit.DotProduct|bivariate_gaussian|64|pipeline|fixedhp'],
        reference='audit/checks/refs/gpfit.py:h_fixedhp (_kernels_basic_misc.gp_posterior_mean at theta = 0; probes/gpfit_probes.py:fixedhp)',
        outcome='2/2 pass (max_rel 0); fixed minus fitted <= 9.2e-6 (T256), <= 1.5e-4 (T64); fixed = ridge alpha 1 to <= 3.3e-14'))
for r in runs:
    o=r['outcome']
    o=o.replace('max LML gain 1.5e-12','max LML gain 3.2e-12')
    r['outcome']=o
c['checks_run']=runs
yaml.safe_dump(d, open(R+u+'.yaml','w'), sort_keys=False, width=140, allow_unicode=False)
