import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests'); sys.path.insert(0, '/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/it_kozachenko/probes')
from regression import harness
harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
from scipy.stats import zscore
import importlib.util
spec = importlib.util.spec_from_file_location('p3', '/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/it_kozachenko/probes/probe3.py')
# reuse helper funcs without running probe3 main: copy minimal
from scipy.special import digamma, gammaln
from scipy.spatial import cKDTree
def H(X):
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    N, d = X.shape; dist, _ = cKDTree(X).query(X, k=2, p=2)
    return -digamma(1) + digamma(N) + (d/2)*np.log(np.pi) - gammaln(d/2+1) + d*np.mean(np.log(dist[:, 1]))
def emb(x, k):
    T = len(x); return np.column_stack([x[k-1-i:T-i] for i in range(k)])
di = it.DirectedInfo(estimator='kozachenko'); cce = it.CausalEntropy(estimator='kozachenko'); si = it.StochasticInteraction(estimator='kozachenko')
rng = np.random.default_rng(7)
def ar1(phi, T):
    x = np.zeros(T + 500); e = rng.standard_normal(T + 500)
    for t in range(1, T + 500): x[t] = phi*x[t-1] + e[t]
    return x[500:]
print('DI bias on independent AR(1) pairs, n=5')
for phi in (0.0, 0.5, 0.9):
    for T in (1024, 4096):
        x, y = ar1(phi, T), ar1(phi, T)
        d = Data(np.vstack([x, y]), normalise=True)
        v = di.bivariate(d, i=0, j=1)
        z = zscore(np.vstack([x, y]), axis=1, ddof=1)
        c = cce.bivariate(d, i=0, j=1)
        canon = H(emb(z[1], 5)) - c   # H(Y^5) - CCE
        pop_bias = (1 + 1/2 + 1/3 + 1/4 + 1/5 - 1) * (-0.5*np.log(1 - phi**2))
        print(f'  phi={phi} T={T}: di_pyspi={v:.4f}  H(Y^5)-CCE={canon:.4f}  diff={v-canon:.4f}  gaussian-population bias (H5harm-1)*(-0.5log(1-phi^2))={pop_bias:.4f}')
for ds in ['cointegrated', 'iid_gaussian']:
    for T in (64, 256, 1024, 4096):
        X = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{ds}_T{T}.npz')['x']
        d = Data(X, normalise=True)
        p = (2, 3) if ds == 'cointegrated' else (0, 1)
        print(f'  {ds} T={T} pair{p}: di={di.bivariate(d, i=p[0], j=p[1]):.4f} di_rev={di.bivariate(d, i=p[1], j=p[0]):.4f} si={si.bivariate(d, i=p[0], j=p[1]):.4f}')
