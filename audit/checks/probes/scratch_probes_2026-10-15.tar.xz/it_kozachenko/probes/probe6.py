import sys, numpy as np, runpy, io, contextlib
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
from scipy.stats import zscore
from scipy.special import digamma, gammaln
from scipy.spatial import cKDTree
def H(X):
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    N, d = X.shape; dist, _ = cKDTree(X).query(X, k=2)
    return -digamma(1) + digamma(N) + (d/2)*np.log(np.pi) - gammaln(d/2+1) + d*np.mean(np.log(dist[:, 1]))
def emb(x, k):
    T = len(x); return np.column_stack([x[k-1-i:T-i] for i in range(k)]) if k > 0 else np.zeros((T+1, 0))
def cce_ref(s, t, n=5):
    out = 0.
    for i in range(1, n+1):
        XYp = np.concatenate([emb(t, i-1)[:-1], emb(s, i)], axis=1); Yf = t[i-1:, None]
        out += H(np.concatenate([Yf, XYp], 1)) - H(XYp)
    return out
refs = {
 'je': lambda x, y: H(np.column_stack([x, y])),
 'ce': lambda x, y: H(np.column_stack([x, y])) - H(x),
 'cce': cce_ref,
 'xme1': lambda x, y: (lambda P: H(np.column_stack([P, y[1:]])) - H(P))(x[:-1, None]),
 'xme10': lambda x, y: (lambda P: H(np.column_stack([P, y[10:]])) - H(P))(np.column_stack([x[9:-1]] + [x[10-i:-i] for i in range(2, 10)])),
 'di': lambda x, y: sum(H(emb(y, i))/i for i in range(1, 6)) - cce_ref(x, y),
 'si': lambda x, y: (lambda xy: (H(np.column_stack([x[1:], x[:-1]])) - H(x[:-1])) + (H(np.column_stack([y[1:], y[:-1]])) - H(y[:-1])) - (H(np.column_stack([xy[1:], xy[:-1]])) - H(xy[:-1])))(np.column_stack([x, y])),
}
objs = {'je': it.JointEntropy(estimator='kozachenko'), 'ce': it.ConditionalEntropy(estimator='kozachenko'), 'cce': it.CausalEntropy(estimator='kozachenko'),
        'xme1': it.CrossmapEntropy(estimator='kozachenko', history_length=1), 'xme10': it.CrossmapEntropy(estimator='kozachenko', history_length=10),
        'di': it.DirectedInfo(estimator='kozachenko'), 'si': it.StochasticInteraction(estimator='kozachenko')}
for o in objs.values(): o._entropy_calc.setProperty('NOISE_LEVEL_TO_ADD', '0')
for ds in ['var2_bivariate', 'iid_gaussian']:
    for T in (1024, 4096):
        X = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{ds}_T{T}.npz')['x'][:2]
        with contextlib.redirect_stdout(io.StringIO()): d = Data(X, normalise=True)
        Z = zscore(X, axis=1, ddof=1)
        row = []
        for k, o in objs.items():
            v = o.bivariate(d, i=0, j=1); r = refs[k](Z[0], Z[1]); row.append(f'{k}:{v:.3f}/{r:.3f}')
        print(ds, T, ' '.join(row))
# threshold for xme10: observations = T-10
x = np.random.default_rng(5).standard_normal((2, 2020))
for T in (2009, 2010, 2011, 2012):
    with contextlib.redirect_stdout(io.StringIO()): d = Data(x[:, :T], normalise=True)
    Z = zscore(x[:, :T], axis=1, ddof=1)
    print('xme10 T', T, 'n_obs', T-10, 'pyspi', round(objs['xme10'].bivariate(d, i=0, j=1), 4), 'ref', round(refs['xme10'](Z[0], Z[1]), 4))
