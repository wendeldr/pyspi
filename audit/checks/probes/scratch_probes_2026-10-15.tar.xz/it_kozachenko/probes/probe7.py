import sys, io, contextlib, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.calculator import Calculator
objs = {'je': it.JointEntropy(estimator='kozachenko'), 'ce': it.ConditionalEntropy(estimator='kozachenko'), 'cce': it.CausalEntropy(estimator='kozachenko'),
        'xme1': it.CrossmapEntropy(estimator='kozachenko', history_length=1), 'xme10': it.CrossmapEntropy(estimator='kozachenko', history_length=10),
        'di': it.DirectedInfo(estimator='kozachenko'), 'si': it.StochasticInteraction(estimator='kozachenko')}
from pyspi.data import Data
def mats(ds, T, keys):
    X = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{ds}_T{T}.npz')['x']
    out = {}
    for k in keys:
        with contextlib.redirect_stdout(io.StringIO()): d = Data(X, normalise=True)
        A = objs[k].multivariate(d); np.fill_diagonal(A, np.nan); out[k] = A
    return out
np.set_printoptions(precision=3, suppress=True)
for ds, T, keys in [('nonlinear_dependence', 1024, ['ce']), ('anm', 1024, ['ce']), ('logistic_maps', 1024, ['xme1', 'xme10', 'di', 'cce']),
                    ('var2_bivariate', 1024, ['xme1', 'xme10', 'di', 'cce', 'ce']), ('delayed_noise', 1024, ['di', 'xme1']),
                    ('gauss_ar1_pair', 1024, ['si', 'di', 'je']), ('iid_gaussian', 64, ['si', 'di']), ('shared_envelope', 1024, ['je', 'ce'])]:
    for k, A in mats(ds, T, keys).items():
        print(ds, T, k, 'symmetric' if np.allclose(A, A.T, equal_nan=True, rtol=0, atol=0) else '', '\n', A)
