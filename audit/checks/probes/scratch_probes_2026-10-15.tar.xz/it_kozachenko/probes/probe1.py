import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
print('jvm', harness.ensure_jvm())
import jpype as jp
import pyspi.statistics.infotheory as it
from scipy.special import digamma, gammaln
from scipy.spatial import cKDTree

def kl_ref(X):
    X = np.asarray(X, float)
    if X.ndim == 1: X = X[:, None]
    N, d = X.shape
    dist, _ = cKDTree(X).query(X, k=2, p=2)
    eps = dist[:, 1]
    logc = (d/2)*np.log(np.pi) - gammaln(d/2+1)  # unit-ball volume, radius 1
    return -digamma(1) + digamma(N) + logc + d*np.mean(np.log(eps))

je = it.JointEntropy(estimator='kozachenko')
calc = je._entropy_calc
print('class', calc.getClass().getName())
for p in ['NOISE_SEED','NORMALISE','BIAS_CORRECTION','NOISE_LEVEL_TO_ADD','NUM_DIMENSIONS','k']:
    print('getProperty', p, '->', calc.getProperty(p))
for cls, kw in [(it.JointEntropy,{}),(it.ConditionalEntropy,{}),(it.CausalEntropy,{}),(it.CrossmapEntropy,{'history_length':1}),(it.CrossmapEntropy,{'history_length':10}),(it.DirectedInfo,{}),(it.StochasticInteraction,{})]:
    o = cls(estimator='kozachenko', **kw)
    print(o.identifier, o.labels, 'n=', getattr(o,'_n',None), 'dce=', o._dyn_corr_excl)

rng = np.random.default_rng(0)
x = rng.standard_normal(256); y = 0.6*x + 0.8*rng.standard_normal(256)
for d, arr in [(1, x[:,None]), (2, np.column_stack([x,y]))]:
    vals = []
    for r in range(3):
        calc.initialise(d); calc.setObservations(jp.JArray(jp.JDouble, 2)(arr)); vals.append(calc.computeAverageLocalOfObservations())
    print('d',d,'repeat calls', repr(vals), 'spread', max(vals)-min(vals), 'ref', repr(kl_ref(arr)), 'diff', vals[0]-kl_ref(arr))
# with noise disabled
calc.setProperty('NOISE_LEVEL_TO_ADD','0')
for d, arr in [(1, x[:,None]), (2, np.column_stack([x,y]))]:
    calc.initialise(d); calc.setObservations(jp.JArray(jp.JDouble, 2)(arr)); v = calc.computeAverageLocalOfObservations()
    print('noise off d',d, repr(v), 'ref', repr(kl_ref(arr)), 'diff', v-kl_ref(arr))
# ties: discrete-valued data
xd = np.round(x*2)/2
calc.initialise(1); calc.setObservations(jp.JArray(jp.JDouble, 2)(xd[:,None])); print('ties noise off', calc.computeAverageLocalOfObservations())
calc.setProperty('NOISE_LEVEL_TO_ADD','1e-8')
v=[]
for r in range(3):
    calc.initialise(1); calc.setObservations(jp.JArray(jp.JDouble, 2)(xd[:,None])); v.append(calc.computeAverageLocalOfObservations())
print('ties noise 1e-8', v, 'true H(N(0,1)) nats', 0.5*np.log(2*np.pi*np.e))
