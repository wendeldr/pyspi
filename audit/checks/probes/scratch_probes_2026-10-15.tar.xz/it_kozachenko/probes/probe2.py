import sys, zipfile, re
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import jpype as jp
C = jp.JClass('infodynamics.measures.continuous.kozachenko.EntropyCalculatorMultiVariateKozachenko')
k = C.class_
c = k
while c is not None:
    print('class', c.getName(), 'interfaces', [i.getName() for i in c.getInterfaces()])
    c = c.getSuperclass()
print('declared methods', sorted(str(m) for m in k.getDeclaredMethods()))
print('declared fields', [str(f) for f in k.getDeclaredFields()])
z = zipfile.ZipFile('/media/dan/Data/git/pyspi/pyspi/lib/jidt/infodynamics.jar')
names = z.namelist()
print([n for n in names if 'continuous/Entropy' in n or 'MultiVariateCommon' in n or 'KozachenkoLeonenko' in n.replace('/','')][:40])
b = z.read('infodynamics/measures/continuous/kozachenko/EntropyCalculatorMultiVariateKozachenko.class')
print(sorted(set(re.findall(rb'[A-Za-z_/$<>.\[;()0-9]{4,}', b)))[:120])
print(z.read('infodynamics/../' if False else 'META-INF/MANIFEST.MF'))
