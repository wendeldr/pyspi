import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import jpype as jp
import pyspi.statistics.infotheory as it
from pyspi.data import Data
from scipy.special import digamma, gammaln
from scipy.spatial import cKDTree
from scipy.stats import zscore

def H(X):
    X = np.asarray(X, float)
    if X.ndim == 1: X = X[:, None]
    N, d = X.shape
    dist, _ = cKDTree(X).query(X, k=2, p=2)
    return -digamma(1) + digamma(N) + (d/2)*np.log(np.pi) - gammaln(d/2+1) + d*np.mean(np.log(dist[:, 1]))

def emb(x, k):  # rows t=k-1..T-1 : [x_t, x_{t-1}, ..., x_{t-k+1}]  (JIDT order)
    T = len(x); return np.column_stack([x[k-1-i:T-i] for i in range(k)]) if k > 0 else np.zeros((T+1, 0))

def cce_ref(src, targ, n):
    s = 0.0
    for i in range(1, n+1):
        Yp = emb(targ, i-1)[:-1]; Xp = emb(src, i); Yf = targ[i-1:, None]
        XYp = np.concatenate([Yp, Xp], axis=1)
        s += H(np.concatenate([Yf, XYp], axis=1)) - H(XYp)
    return s

def di_ref(src, targ, n):
    return sum(H(emb(targ, i))/i for i in range(1, n+1)) - cce_ref(src, targ, n)

def xme_ref(src, targ, k):
    tf = targ[k:]; cols = [src[k-1:-1]] + [src[k-i:-i] for i in range(2, k)]
    P = np.column_stack(cols); return H(np.column_stack([P, tf])) - H(P), P.shape[1]

def si_ref(x, y, tau=1):
    xy = np.column_stack([x, y])
    ce = lambda A, B: H(np.column_stack([A, B])) - H(B)
    return ce(x[tau:], x[:-tau]) + ce(y[tau:], y[:-tau]) - ce(xy[tau:], xy[:-tau])

def spis(noise):
    out = {}
    for name, cls, kw in [('je', it.JointEntropy, {}), ('ce', it.ConditionalEntropy, {}), ('cce', it.CausalEntropy, {}),
                          ('xme1', it.CrossmapEntropy, {'history_length': 1}), ('xme10', it.CrossmapEntropy, {'history_length': 10}),
                          ('di', it.DirectedInfo, {}), ('si', it.StochasticInteraction, {})]:
        o = cls(estimator='kozachenko', **kw)
        if not noise: o._entropy_calc.setProperty('NOISE_LEVEL_TO_ADD', '0')
        out[name] = o
    return out

# normalise no-op check
c = it.JointEntropy(estimator='kozachenko')._entropy_calc
c.setProperty('NOISE_LEVEL_TO_ADD', '0')
rng = np.random.default_rng(1); x = rng.standard_normal(500)
vals = []
for s in (1.0, 10.0):
    c.initialise(1); c.setObservations(jp.JArray(jp.JDouble, 2)((s*x)[:, None])); vals.append(c.computeAverageLocalOfObservations())
print('NORMALISE prop', c.getProperty('NORMALISE'), 'H(10x)-H(x)=', vals[1]-vals[0], 'log10=', np.log(10))

for ds in ['var2_bivariate_T256', 'iid_gaussian_T256']:
    X = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{ds}.npz')['x'][:2]
    Z = zscore(X, axis=1, ddof=1)
    for noise in (False, True):
        S = spis(noise)
        d = Data(X, normalise=True)
        res = {}
        for (i, j) in [(0, 1), (1, 0)]:
            x, y = Z[i], Z[j]
            refs = {'je': H(np.column_stack([x, y])), 'ce': H(np.column_stack([x, y])) - H(x), 'cce': cce_ref(x, y, 5),
                    'xme1': xme_ref(x, y, 1)[0], 'xme10': xme_ref(x, y, 10)[0], 'di': di_ref(x, y, 5), 'si': si_ref(x, y)}
            for k, o in S.items():
                v = o.bivariate(d, i=i, j=j)
                res[(k, i, j)] = (v, refs[k])
        print(ds, 'noise', noise)
        for k in S:
            a = res[(k, 0, 1)]; b = res[(k, 1, 0)]
            print(f'  {k:6s} A[0,1]={a[0]: .12f} ref={a[1]: .12f} d={a[0]-a[1]: .2e} | A[1,0]={b[0]: .12f} ref={b[1]: .12f} d={b[0]-b[1]: .2e}')
print('xme source lag columns: k=1 ->', xme_ref(np.arange(30.), np.arange(30.), 1)[1], ' k=2 ->', xme_ref(np.arange(30.), np.arange(30.), 2)[1], ' k=10 ->', xme_ref(np.arange(30.), np.arange(30.), 10)[1])
t = np.arange(20.); k = 10; tf = t[k:]; P = np.column_stack([t[k-1:-1]] + [t[k-i:-i] for i in range(2, k)])
print('xme k=10 first row: target t =', tf[0], 'source times', P[0])
# zero-width embedding through JIDT
m = jp.JPackage('infodynamics.utils').MatrixUtils
E0 = m.makeDelayEmbeddingVector(jp.JArray(jp.JDouble, 1)(np.arange(6.)), 0)
print('JIDT emb k=0 shape', np.asarray(E0).shape, ' [:-1] ->', np.asarray(E0[:-1]).shape, ' emb k=3 row0', list(m.makeDelayEmbeddingVector(jp.JArray(jp.JDouble, 1)(np.arange(6.)), 3)[0]))
