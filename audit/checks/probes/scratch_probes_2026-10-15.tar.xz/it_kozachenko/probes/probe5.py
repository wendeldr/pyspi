import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import jpype as jp
from scipy.spatial import cKDTree
from scipy.special import digamma, gammaln
EU = jp.JClass('infodynamics.utils.EuclideanUtils')
K = jp.JClass('infodynamics.measures.continuous.kozachenko.EntropyCalculatorMultiVariateKozachenko')
print('MAX_TIMESTEPS_FOR_FAST_DISTANCE =', EU.MAX_TIMESTEPS_FOR_FAST_DISTANCE)
rng = np.random.default_rng(3)
def Href(X):
    N, d = X.shape; dist, _ = cKDTree(X).query(X, k=2)
    return -digamma(1) + digamma(N) + (d/2)*np.log(np.pi) - gammaln(d/2+1) + d*np.mean(np.log(dist[:, 1]))
for d in (1, 2, 3, 5, 6, 10):
    for N in (1024, 2000, 2001, 4096):
        X = rng.standard_normal((N, d))
        J = jp.JArray(jp.JDouble, 2)(X)
        true = cKDTree(X).query(X, k=2)[0][:, 1]
        naive = np.array(EU.computeMinEuclideanDistancesNaive(J)); fast = np.array(EU.computeMinEuclideanDistancesFast(J)) if N <= 2001 else None
        disp = np.array(EU.computeMinEuclideanDistances(J))
        c = K(); c.setProperty('NOISE_LEVEL_TO_ADD', '0'); c.initialise(d); c.setObservations(J); h = c.computeAverageLocalOfObservations()
        nb = int(np.sum(np.abs(naive - true) > 1e-12)); fb = None if fast is None else int(np.sum(np.abs(fast - true) > 1e-12))
        print(f'd={d:2d} N={N}: naive wrong {nb:4d}/{N} (min ratio {np.min(naive/true):.3f}); fast wrong {fb}; dispatch==true {np.allclose(disp, true, rtol=0, atol=1e-12)}; H_jidt={h:.4f} H_ref={Href(X):.4f} true H={0.5*d*np.log(2*np.pi*np.e):.4f}')
