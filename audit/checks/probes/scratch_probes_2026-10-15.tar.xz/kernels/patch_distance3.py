p = "/media/dan/Data/git/pyspi/audit/checks/refs/_kernels_distance.py"
s = open(p).read()
a = s.index("def simplex_crossmap(")
b = s.index("def ccm_skill_curve(")
new = '''def simplex_predictions(x, y, E, tau=-1, Tp=0, lib_indices=None, ties=True):
    """Simplex cross-map predictions of y from the delay embedding of x (Sugihara & May 1990, Nature 344;
    Sugihara et al. 2012, Science 338, supplement). Returns (rows (m,), y_hat (m,)) for the prediction rows.

    Embedding row t = (x_t, x_{t+tau}, ..., x_{t+(E-1)tau}) (tau < 0: past lags). Rows need a full embedding and a
    valid t+Tp. Every valid row is predicted; the library is lib_indices (default: all valid rows); t itself is
    excluded. Distances: Euclidean, summed coordinate by coordinate as cppEDM Distance() (EDM_Neighbors.cc L453-468).
    Weights u_i = exp(-d_i/d_1) over the knn = E+1 nearest (d_1 = nearest); if d_1 = 0, u_i = [d_i == 0]; floor 1e-6
    (Simplex.cc L44-80). y_hat = sum u_i y(t_i + Tp) / sum u_i.
    ties=True mirrors cppEDM's tie expansion (EDM_Neighbors.cc L276-345, Simplex.cc L90-157): if more than E+1 rows
    lie within the (E+1)-th distance d_K, ALL of them are used, and each row at exactly d_K has its weight multiplied by
    (slots at d_K inside the first E+1) / (number of rows at d_K). The result does not depend on the sort order.
    ties=False keeps exactly E+1 neighbours (stable argsort), the plain Sugihara form."""
    x, y = np.asarray(x, float).ravel(), np.asarray(y, float).ravel()
    n, lag, k = len(x), -tau, E + 1
    rows = np.arange((E - 1) * lag, n)
    rows = rows[(rows + Tp >= 0) & (rows + Tp < n)]
    emb = np.stack([x[rows - j * lag] for j in range(E)], 1)
    lib = rows if lib_indices is None else np.intersect1d(rows, np.asarray(lib_indices))
    Lemb, ylib = emb[np.searchsorted(rows, lib)], y[lib + Tp]
    pred = np.empty(len(rows))
    for a, t in enumerate(rows):
        ss = np.zeros(len(lib))
        for j in range(E):
            ss += (Lemb[:, j] - emb[a, j]) ** 2
        d = np.sqrt(ss)
        d[lib == t] = np.inf
        o = np.argsort(d, kind="stable")
        dK = d[o[k - 1]]
        if ties and np.sum(d <= dK) > k:
            o = o[d[o] <= dK]
        dk = d[o] if len(o) > k and ties else d[o[:k]]
        o = o[:len(dk)]
        w = np.exp(-dk / dk[0]) if dk[0] > 0 else (dk == 0).astype(float)
        w = np.maximum(w, 1e-6)
        if len(o) > k:
            at = dk == dK
            w[at] *= (k - np.sum(dk < dK)) / np.sum(at)
        pred[a] = np.sum(w * ylib[o]) / np.sum(w)
    return rows + Tp, pred


def simplex_crossmap(x, y, E, tau=-1, Tp=0, lib_indices=None, ties=True):
    """Cross-map skill rho(y, y_hat | M_x) = Pearson rho over simplex_predictions (Sugihara et al. 2012).
    Direction (Sugihara): high skill of 'x xmap y' is evidence that y CAUSES x. This equals pyEDM's column
    'x:y' (columns=x, target=y). pyEDM's defaults are E, Tp=0, tau=-1, knn=E+1, exclusionRadius=0
    (pyEDM/CoreEDM.py:363-385); ties=True reproduces its tie expansion (needed for series with repeated values,
    e.g. the period-4 driver of logistic_maps). x, y (n,). Returns a float."""
    t, pred = simplex_predictions(x, y, E, tau, Tp, lib_indices, ties)
    return _pearson0(np.asarray(y, float).ravel()[t], pred)


'''
s = s[:a] + new + s[b:]
open(p, "w").write(s)
print("ok")
