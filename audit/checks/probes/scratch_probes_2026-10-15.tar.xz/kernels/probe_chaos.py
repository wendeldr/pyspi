import sys, numpy as np
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs"); sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks")
import _kernels_distance as K, make_data
def logi(T, rx=3.8, ry=3.7, bxy=0.1, byx=0.0, seed=0):
    x, y = np.empty(T + 300), np.empty(T + 300); x[0], y[0] = 0.4, 0.2
    for t in range(T + 299):
        x[t + 1] = x[t] * (rx - rx * x[t] - bxy * y[t]); y[t + 1] = y[t] * (ry - ry * y[t] - byx * x[t])
    return x[300:], y[300:]
for ry in (3.7, 3.8):
    x, y = logi(1000, ry=ry)
    for E in (1, 2, 3):
        print(ry, E, K.simplex_crossmap(x, y, E, return_tied=True), K.simplex_crossmap(y, x, E, return_tied=True))
lm = make_data.load("logistic_maps", 1024)["x"]
print("lm", K.simplex_crossmap(lm[0], lm[1], 2, return_tied=True), K.simplex_crossmap(lm[1], lm[0], 2, return_tied=True))
