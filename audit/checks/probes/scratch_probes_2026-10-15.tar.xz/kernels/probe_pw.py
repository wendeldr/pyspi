import numpy as np, scipy.signal.windows as sw
for T in (7,8,9,10,12,16):
    w, lam = sw.dpss(T, 3.0, Kmax=5, return_ratios=True)
    W = 3.0/T
    tau = np.arange(T)
    r = np.array([[np.dot(v[:T-k], v[k:]) for k in range(T)] for v in w])
    filt = 4*W*np.sinc(2*W*tau); filt[0] = 2*W
    pw = r @ filt
    print(T, np.round(lam, 5), np.round(pw, 5))
