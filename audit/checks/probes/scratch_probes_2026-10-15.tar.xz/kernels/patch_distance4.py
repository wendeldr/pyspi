p = "/media/dan/Data/git/pyspi/audit/checks/refs/_kernels_distance.py"
s = open(p).read()
old = '''        o = np.argsort(d, kind="stable")
        dK = d[o[k - 1]]
        if ties and np.sum(d <= dK) > k:
            o = o[d[o] <= dK]
        dk = d[o] if len(o) > k and ties else d[o[:k]]
        o = o[:len(dk)]
        w = '''
new = '''        o = np.argsort(d, kind="stable")
        dK = d[o[k - 1]]
        o = o[:np.sum(d <= dK)] if ties else o[:k]             # sorted, so this is every row within d_K
        dk = d[o]
        w = '''
assert s.count(old) == 1
s = s.replace(old, new)
open(p, "w").write(s)
