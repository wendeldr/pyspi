import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import numpy as np, make_data as md, _kernels_spectral as K
import pyspi._spectral_compat  # installs np.in1d shim
import spectral_connectivity as sc
for T in (1024, 4096):
    x = md.load("delayed_noise", T)["x"]
    c = sc.Connectivity.from_multitaper(sc.Multitaper(x.T, sampling_frequency=1))
    d, s, r = c.group_delay([0, 0.5], 0.5/50)
    co, fr = K.multitaper_fft(x); fn = K.nonneg(fr)
    Cn = K.nonneg(K.coherency(K.cross_spectral_matrix(co))); mk = K.band_mask(fn, 0, 0.5, inclusive=False)
    print(T, "lib delay[0,k]", np.round(d[0, 0, 1:], 4), "kernel", [round(float(K.group_delay_fit(np.angle(Cn[:, 0, k]), fn, mk)["delay"]), 4) for k in (1, 2, 3)])
