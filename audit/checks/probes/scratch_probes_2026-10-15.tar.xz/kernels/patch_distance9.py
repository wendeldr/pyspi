p = "/media/dan/Data/git/pyspi/audit/checks/refs/_kernels_distance.py"
s = open(p).read()
def doc(name, new):
    global s
    i = s.index(f"\ndef {name}(")
    a = s.index('"""', i)
    b = s.index('"""', a + 3) + 3
    s = s[:a] + '"""' + new.strip("\n") + '"""' + s[b:]
def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new)
rep('''    import warnings
    warnings.filterwarnings("ignore")
    sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks")
    import make_data
    import dcor
    from dtaidistance import dtw as tdtw
    import ot
    res = []
''', '''    import warnings; warnings.filterwarnings("ignore")
    sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks")
    import make_data, dcor, ot                               # dcor, ot, dtaidistance: labelled 2nd opinions
    from dtaidistance import dtw as tdtw
    res = []
''')
doc("simplex_predictions", '''Simplex cross-map predictions of y from the delay embedding of x (Sugihara & May 1990, Nature 344; Sugihara et al.
    2012, Science 338, supplement). Returns (rows (m,), y_hat (m,), tied (m,) bool).
    Embedding row t = (x_t, x_{t+tau}, ..., x_{t+(E-1)tau}) (tau < 0: past lags); rows need a full embedding and a valid
    t+Tp. Every valid row is predicted from the library lib_indices (default: all valid rows), t itself excluded.
    Euclidean distances, summed coordinate by coordinate as cppEDM Distance() (EDM_Neighbors.cc L453-468). The E+1
    nearest (stable argsort) get u_i = exp(-d_i/d_1) (if d_1 = 0, u_i = [d_i == 0]), floored at 1e-6 (Simplex.cc L44-80);
    y_hat = sum u_i y(t_i + Tp) / sum u_i.
    tied[a]: the (E+1)-th and (E+2)-th distances are equal, so the neighbour SET is ambiguous. pyEDM's CCM does not expand
    ties (the expansion at EDM_Neighbors.cc L282 is gated on method == Simplex; CCM runs as Method::CCM, API.cc L659): on
    tied rows it keeps whichever E+1 rows libstdc++'s unstable std::sort (EDM_Neighbors.cc L226) puts first, which is
    implementation-defined. Compare with pyEDM only where no row is tied (scratchpad probe kernels/probe_ccm_stdsort.py:
    an introsort emulation reproduces pyEDM to 1e-13 on logistic_maps, both directions).''')
doc("_sqdiff_scaled", '''(x_i/l - x_j/l)^2, (n, n), exact differencing of pre-scaled inputs: sklearn RBF's arithmetic, pdist(X / length_scale,
    'sqeuclidean') for k(X) and cdist for k(X, X_train) (sklearn/gaussian_process/kernels.py:1561, 1569), NOT pairwise.py's
    dot-product form. In the ANM regime (l ~ 1e-4, residual ~ 1e-10 y) rounding-level changes in K reach the z-scored residual.''')
open(p, "w").write(s)
print("ok")
