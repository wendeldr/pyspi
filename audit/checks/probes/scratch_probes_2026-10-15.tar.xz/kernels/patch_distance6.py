p = "/media/dan/Data/git/pyspi/audit/checks/refs/_kernels_distance.py"
s = open(p).read()
def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new)
rep('''    # (7) CCM
    lm = make_data.load("logistic_maps", 1024)["x"]
    xy, yx = simplex_crossmap(lm[0], lm[1], 2), simplex_crossmap(lm[1], lm[0], 2)
    check("ccm: x xmap y (y causes x) exceeds y xmap x by > 0.1, T=1024, E=2", xy - yx > 0.1, f"{xy:.3f} vs {yx:.3f}")
    curve = ccm_skill_curve(lm[0], lm[1], 2, [20, 100, 500], n_samples=10)
    check("ccm skill rises with library size", curve[-1] > curve[0], np.array2string(curve, precision=3))
''', '''    # (7) CCM on tie-free data: Sugihara 2012 eq. 1 with a CHAOTIC driver (r_y = 3.7), y -> x only (beta_xy = 0.1)
    cx, cy = np.empty(1300), np.empty(1300); cx[0], cy[0] = 0.4, 0.2
    for t in range(1299):
        cx[t + 1] = cx[t] * (3.8 - 3.8 * cx[t] - 0.1 * cy[t]); cy[t + 1] = cy[t] * (3.7 - 3.7 * cy[t])
    cx, cy = cx[300:], cy[300:]
    (xy, nxy), (yx, nyx) = simplex_crossmap(cx, cy, 2, return_tied=True), simplex_crossmap(cy, cx, 2, return_tied=True)
    check("ccm chaotic maps: x xmap y (y causes x) exceeds y xmap x by > 0.3, T=1000, E=2, no tied rows",
          xy - yx > 0.3 and nxy == nyx == 0, f"{xy:.3f} vs {yx:.3f}, tied rows {nxy}, {nyx}")
    curve = ccm_skill_curve(cx, cy, 2, [20, 100, 500], n_samples=10)
    check("ccm skill rises with library size (chaotic maps)", curve[-1] > curve[0], np.array2string(curve, precision=3))
    lm = make_data.load("logistic_maps", 256)["x"]          # period-4 driver: 4 distinct values of y
    nt = [simplex_crossmap(lm[0], lm[1], 2, return_tied=True)[1], simplex_crossmap(lm[1], lm[0], 2, return_tied=True)[1]]
    check("ccm tie flag: logistic_maps 'y xmap x' tied on every row, 'x xmap y' on none", nt == [0, 255], f"{nt}")
    pr = simplex_predictions([0., 1., 3., 7.], [0., 1., 3., 7.], 1)[1]   # E=1, 2 neighbours, hand-computed
    w = lambda d1, d2, a, b: (a + np.exp(-d2 / d1) * b) / (1 + np.exp(-d2 / d1))
    check("simplex weights exp(-d/d1), hand case", np.allclose(pr, [w(1, 3, 1, 3), w(1, 2, 0, 3), w(2, 3, 1, 0), w(4, 6, 3, 1)], 0, 1e-15), "ok")
''')
rep('''    th = gp_fit_hyperparameters(Xa, Ya)
''', '''    th = gp_fit_hyperparameters(Xa, Ya)
    from scipy.spatial.distance import pdist, squareform     # scipy primitive, as sklearn RBF uses (kernels.py:1561)
    Ksk = th[0] * np.exp(-0.5 * squareform(pdist(Xa.reshape(-1, 1) / th[1], "sqeuclidean")))
    check("_rbf arithmetic = pdist(x/l) at the fitted theta (bitwise)", np.array_equal(_rbf(Xa, *th), Ksk), "max diff 0")
''')
rep('''    print(f"{sum(res)}/{len(res)} checks passed")''', '''    # (9) degenerate inputs
    try:
        dcorr(a[:2], a[2:4]); bad = True
    except ValueError:
        bad = False
    d3 = dcorr(a[:3], a[3:6])
    check("dcorr: U-form n=3 finite ratio (hyppo), n=2 raises", not bad and np.isfinite(d3["hyppo"]), f"n=3 {d3['hyppo']:.4f}")
    check("hsic normalised = 0 for a constant series", hsic_biased(np.ones(30), a[:30])["normalised"] == 0.0, "0")
    yc = (a[:30] - a[:30].min()) / np.ptp(a[:30])
    check("reci constant x -> MSE = var(minmax y) (OLS on [1, 0])", abs(reci_ref(np.ones(30), a[:30]) - yc.var()) < 1e-14, "ok")
    print(f"{sum(res)}/{len(res)} checks passed")''')
open(p, "w").write(s)
print("ok")
