p = "/media/dan/Data/git/pyspi/audit/checks/refs/_kernels_distance.py"
s = open(p).read()
def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new)
rep('''    dcor2 is formed from the unscaled sums (the scale cancels), as hyppo's _dcorr does (only_dcov=False,
    dcorr.py:402-404, 432-445). For biased=False and n = 3 the U-statistics are undefined (n(n-3) = 0): the
    three covariances are NaN while dcor2 is still the ratio hyppo returns. biased=False with n < 3 raises ValueError.
    """''', '''    dcor2 is formed from the unscaled sums (the scale cancels), as hyppo's _dcorr does (only_dcov=False,
    dcorr.py:402, 432-445). biased=False, n = 3: the U-centred matrices are identically 0 (A~_12 = a12 - (a12+a13)
    - (a12+a23) + (a12+a13+a23) = 0), so dcor2 = 0 and the covariances are NaN (n(n-3) = 0); hyppo returns a
    rounding-noise ratio there (probe kernels/probe_edges_fix.py). biased=False with n < 3 raises ValueError.
    """''')
rep('''    d2 = 0.0 if (sxx <= 0 or syy <= 0) else sxy / np.sqrt(sxx * syy)
    return d2, s * sxy''', '''    d2 = 0.0 if (sxx <= 0 or syy <= 0 or (not biased and n == 3)) else sxy / np.sqrt(sxx * syy)
    return d2, s * sxy''')
rep('''    check("dcorr: U-form n=3 finite ratio (hyppo), n=2 raises", not bad and np.isfinite(d3["hyppo"]), f"n=3 {d3['hyppo']:.4f}")''',
    '''    check("dcorr: U-form n=3 gives 0 (A~ = 0 analytically), n=2 raises", not bad and d3["hyppo"] == 0.0, f"n=3 {d3['hyppo']}")''')
open(p, "w").write(s)
print("ok")
