import sys, numpy as np, warnings, pandas as pd; warnings.filterwarnings("ignore")
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs"); sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks")
import _kernels_distance as K, make_data, pyEDM
worst = {}
for name in ("logistic_maps", "logistic_maps_bidir", "nonlinear_dependence", "var2_bivariate"):
    for T in (256, 1024):
        d = make_data.load(name, T)["x"]; N = d.shape[1]
        df = pd.DataFrame({"index": np.arange(N), "x": d[0], "y": d[1]})
        for E in (1, 2, 3, 10):
            valid = np.arange(E - 1, N)
            for L in (20, 50, 200, N - E + 1):
                out = pyEDM.CCM(dataFrame=df, E=E, columns="x", target="y", libSizes=f"{L} {L} 1", sample=1, random=False)
                kxy = K.simplex_crossmap(d[0], d[1], E, lib_indices=valid[:L]); kyx = K.simplex_crossmap(d[1], d[0], E, lib_indices=valid[:L])
                exy = abs(float(out['x:y'].iloc[0]) - kxy); eyx = abs(float(out['y:x'].iloc[0]) - kyx)
                worst[name] = max(worst.get(name, 0), exy, eyx)
                if name == "logistic_maps": print(f"{name} T={T} E={E:2d} L={L:4d} x:y {exy:.1e} y:x {eyx:.1e}  (pyEDM y:x {float(out['y:x'].iloc[0]):.6f}, kernel {kyx:.6f})")
print(worst)
# Simplex (Tp=0 cross-map via pyEDM.Simplex on embedded=False, column=y target=x) full lib, E=2
d = make_data.load("logistic_maps", 512)["x"]; N = d.shape[1]
df = pd.DataFrame({"index": np.arange(N), "x": d[0], "y": d[1]})
# analytic hand cases checked against pyEDM
rng = np.random.default_rng(3)
for trial in range(3):
    xs = rng.integers(0, 4, 60).astype(float) * 0.5; ys = rng.standard_normal(60)
    df = pd.DataFrame({"index": np.arange(60), "x": xs, "y": ys})
    for E in (1, 2, 3):
        out = pyEDM.CCM(dataFrame=df, E=E, columns="x", target="y", libSizes=f"{60-E+1} {60-E+1} 1", sample=1, random=False)
        print("random 4-level x, E", E, abs(float(out['x:y'].iloc[0]) - K.simplex_crossmap(xs, ys, E)), "ties=False", abs(float(out['x:y'].iloc[0]) - K.simplex_crossmap(xs, ys, E, ties=False)))
