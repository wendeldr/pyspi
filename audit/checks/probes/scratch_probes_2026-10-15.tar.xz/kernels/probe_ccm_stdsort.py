"""Hypothesis: in CCM (method == Method::CCM) cppEDM does NOT expand ties (EDM_Neighbors.cc gate
'parameters.method == Method::Simplex'); tied neighbour SELECTION follows libstdc++ std::sort (unstable).
Emulate libstdc++ introsort on (distance, libRow) pairs compared by distance only, then plain E+1 simplex."""
import sys, numpy as np, warnings, pandas as pd; warnings.filterwarnings("ignore")
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs"); sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks")
import _kernels_distance as K, make_data, pyEDM

def std_sort(a):  # a: list of (d, idx); comparator a.d < b.d; libstdc++ introsort
    def lt(x, y): return x[0] < y[0]
    def med_to_first(r, i, j, k):
        if lt(a[i], a[j]):
            if lt(a[j], a[k]): a[r], a[j] = a[j], a[r]
            elif lt(a[i], a[k]): a[r], a[k] = a[k], a[r]
            else: a[r], a[i] = a[i], a[r]
        elif lt(a[i], a[k]): a[r], a[i] = a[i], a[r]
        elif lt(a[j], a[k]): a[r], a[k] = a[k], a[r]
        else: a[r], a[j] = a[j], a[r]
    def upart(f, l, p):
        while True:
            while lt(a[f], a[p]): f += 1
            l -= 1
            while lt(a[p], a[l]): l -= 1
            if not f < l: return f
            a[f], a[l] = a[l], a[f]; f += 1
    def loop(f, l, depth):
        while l - f > 16:
            if depth == 0: raise RuntimeError("heap fallback not emulated")
            depth -= 1
            mid = f + (l - f) // 2
            med_to_first(f, f + 1, mid, l - 1)
            cut = upart(f + 1, l, f)
            loop(cut, l, depth)
            l = cut
    def ulin(i):
        v = a[i]; j = i - 1
        while lt(v, a[j]): a[j + 1] = a[j]; j -= 1
        a[j + 1] = v
    def ins(f, l):
        for i in range(f + 1, l):
            if lt(a[i], a[f]):
                v = a[i]; a[f + 1:i + 1] = a[f:i]; a[f] = v
            else: ulin(i)
    n = len(a)
    if n:
        loop(0, n, 2 * (n.bit_length() - 1))
        if n > 16: ins(0, 16); [ulin(i) for i in range(16, n)]
        else: ins(0, n)
    return a

def xmap_stdsort(x, y, E, L):
    x, y = np.asarray(x, float), np.asarray(y, float); n = len(x); k = E + 1
    rows = np.arange(E - 1, n); emb = np.stack([x[rows - j] for j in range(E)], 1)
    lib = rows[:L]; Lemb = emb[:L]
    pred = np.empty(len(rows))
    for a_, t in enumerate(rows):
        ss = np.zeros(len(lib))
        for j in range(E): ss += (Lemb[:, j] - emb[a_, j]) ** 2
        d = np.sqrt(ss)
        pairs = [(d[i], i) for i in range(len(lib)) if lib[i] != t]
        o = np.array([p[1] for p in std_sort(pairs)[:k]]); dk = d[o]
        w = np.exp(-dk / dk[0]) if dk[0] > 0 else (dk == 0).astype(float)
        w = np.maximum(w, 1e-6); pred[a_] = np.sum(w * y[lib[o]]) / np.sum(w)
    return K._pearson0(y[rows], pred)

for T in (256, 1024):
    d = make_data.load("logistic_maps", T)["x"]; N = d.shape[1]
    df = pd.DataFrame({"index": np.arange(N), "x": d[0], "y": d[1]})
    for E in (1, 2, 3, 10):
        for L in (20, 50, 200, N - E + 1):
            out = pyEDM.CCM(dataFrame=df, E=E, columns="x", target="y", libSizes=f"{L} {L} 1", sample=1, random=False)
            v = float(out['y:x'].iloc[0])
            print(f"T={T} E={E:2d} L={L:4d} pyEDM y:x {v:.12f}  stdsort-emul diff {abs(v - xmap_stdsort(d[1], d[0], E, L)):.1e}  stable-E+1 diff {abs(v - K.simplex_crossmap(d[1], d[0], E, lib_indices=np.arange(E-1, N)[:L], ties=False)):.1e}")
