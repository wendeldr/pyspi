p = "/media/dan/Data/git/pyspi/audit/checks/refs/_kernels_distance.py"
s = open(p).read()
a = s.index("def simplex_predictions(")
b = s.index("def ccm_skill_curve(")
new = '''def simplex_predictions(x, y, E, tau=-1, Tp=0, lib_indices=None):
    """Simplex cross-map predictions of y from the delay embedding of x (Sugihara & May 1990, Nature 344;
    Sugihara et al. 2012, Science 338, supplement). Returns (rows (m,), y_hat (m,), tied (m,) bool).

    Embedding row t = (x_t, x_{t+tau}, ..., x_{t+(E-1)tau}) (tau < 0: past lags). Rows need a full embedding and a
    valid t+Tp. Every valid row is predicted; the library is lib_indices (default: all valid rows); t itself is
    excluded. Distances are Euclidean, summed coordinate by coordinate as cppEDM Distance() (EDM_Neighbors.cc L453-468).
    The E+1 nearest (stable argsort) get u_i = exp(-d_i/d_1) (d_1 = nearest; if d_1 = 0, u_i = [d_i == 0]), floored
    at 1e-6 (Simplex.cc L44-80); y_hat = sum u_i y(t_i + Tp) / sum u_i.
    tied[a] is True when the (E+1)-th and (E+2)-th distances are equal, i.e. the neighbour SET is ambiguous. pyEDM's CCM
    does not expand ties (the expansion in EDM_Neighbors.cc L281 is gated on method == Simplex; CCM runs with
    Method::CCM, API.cc L659), so on tied rows it keeps whichever E+1 rows libstdc++'s unstable std::sort
    (EDM_Neighbors.cc L226) puts first. That order is implementation-defined; compare with pyEDM only where no row is
    tied (probe kernels/probe_ccm_stdsort.py: an introsort emulation reproduces pyEDM to 1e-13 on logistic_maps)."""
    x, y = np.asarray(x, float).ravel(), np.asarray(y, float).ravel()
    n, lag, k = len(x), -tau, E + 1
    rows = np.arange((E - 1) * lag, n)
    rows = rows[(rows + Tp >= 0) & (rows + Tp < n)]
    emb = np.stack([x[rows - j * lag] for j in range(E)], 1)
    lib = rows if lib_indices is None else np.intersect1d(rows, np.asarray(lib_indices))
    Lemb, ylib = emb[np.searchsorted(rows, lib)], y[lib + Tp]
    pred, tied = np.empty(len(rows)), np.zeros(len(rows), bool)
    for a, t in enumerate(rows):
        ss = np.zeros(len(lib))
        for j in range(E):
            ss += (Lemb[:, j] - emb[a, j]) ** 2
        d = np.sqrt(ss)
        d[lib == t] = np.inf
        o = np.argsort(d, kind="stable")
        tied[a] = len(o) > k and d[o[k - 1]] == d[o[k]]
        dk = d[o[:k]]
        w = np.exp(-dk / dk[0]) if dk[0] > 0 else (dk == 0).astype(float)
        w = np.maximum(w, 1e-6)
        pred[a] = np.sum(w * ylib[o[:k]]) / np.sum(w)
    return rows + Tp, pred, tied


def simplex_crossmap(x, y, E, tau=-1, Tp=0, lib_indices=None, return_tied=False):
    """Cross-map skill rho(y, y_hat | M_x) = Pearson rho over simplex_predictions (Sugihara et al. 2012).
    Direction (Sugihara): high skill of 'x xmap y' is evidence that y CAUSES x. This equals pyEDM's column
    'x:y' (columns=x, target=y). pyEDM's defaults are E, Tp=0, tau=-1, knn=E+1, exclusionRadius=0
    (pyEDM/CoreEDM.py:363-385). x, y (n,). Returns rho, or (rho, number of tied prediction rows) with
    return_tied=True; a non-zero count means pyEDM's value depends on std::sort order (see simplex_predictions)."""
    t, pred, tied = simplex_predictions(x, y, E, tau, Tp, lib_indices)
    rho = _pearson0(np.asarray(y, float).ravel()[t], pred)
    return (rho, int(tied.sum())) if return_tied else rho


'''
s = s[:a] + new + s[b:]
open(p, "w").write(s)
print("ok")
