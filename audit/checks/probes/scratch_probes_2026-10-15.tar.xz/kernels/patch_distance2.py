p = "/media/dan/Data/git/pyspi/audit/checks/refs/_kernels_distance.py"
s = open(p).read()
def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new)
rep('''    Returns (dcor2, dcov2_xy, dvar2_x, dvar2_y). dcor2 is 0 when a variance is <= 0.
    Raises ValueError for biased=False with n < 4 (also reached by dcorrx_mehta when max_lag > n - 4).
    """
    n = dx.shape[0]
    if biased:
        A, B, s = _double_centre(dx), _double_centre(dy), 1.0 / n ** 2
    else:
        if n < 4:   # n(n-3) = 0; hyppo's numba path divides by zero here too (dcorr.py:404-405)
            raise ValueError(f"bias-corrected dCor needs n >= 4 samples, got {n}")
        A, B, s = _u_centre(dx), _u_centre(dy), 1.0 / (n * (n - 3))
    cxy, cxx, cyy = s * np.sum(A * B), s * np.sum(A * A), s * np.sum(B * B)
    d2 = 0.0 if (cxx <= 0 or cyy <= 0) else cxy / np.sqrt(cxx * cyy)
    return d2, cxy, cxx, cyy''',
'''    Returns (dcor2, dcov2_xy, dvar2_x, dvar2_y). dcor2 is 0 when a variance is <= 0.
    dcor2 is formed from the unscaled sums (the scale cancels), as hyppo's _dcorr does (only_dcov=False,
    dcorr.py:402-404, 432-445). For biased=False and n = 3 the U-statistics are undefined (n(n-3) = 0): the
    three covariances are NaN while dcor2 is still the ratio hyppo returns. biased=False with n < 3 raises ValueError.
    """
    n = dx.shape[0]
    if biased:
        A, B, s = _double_centre(dx), _double_centre(dy), 1.0 / n ** 2
    else:
        if n < 3:   # U-centring divides by n - 2
            raise ValueError(f"bias-corrected dCor needs n >= 3 samples, got {n}")
        A, B, s = _u_centre(dx), _u_centre(dy), (1.0 / (n * (n - 3)) if n > 3 else np.nan)
    sxy, sxx, syy = np.sum(A * B), np.sum(A * A), np.sum(B * B)
    d2 = 0.0 if (sxx <= 0 or syy <= 0) else sxy / np.sqrt(sxx * syy)
    return d2, s * sxy, s * sxx, s * syy''')
rep('''    d2, cxy, cxx, cyy = dcorr_from_dist(dx, dy, biased)
    if cxx <= 0 or cyy <= 0 or (biased and cxy <= 0):
        return 0.0
    return float(np.sqrt(d2)) if biased else float(d2)''',
'''    d2 = dcorr_from_dist(dx, dy, biased)[0]          # already 0 when a variance is <= 0
    if biased and d2 <= 0:
        return 0.0
    return float(np.sqrt(d2)) if biased else float(d2)''')
open(p, "w").write(s)
print("ok")
