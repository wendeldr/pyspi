import numpy as np, scipy.signal.windows as sw
from spectral_connectivity.transforms import dpss_windows, _find_tapers_from_optimization
for T in (8, 9, 10):
    tap, ev = dpss_windows(T, 3.0, 5, is_low_bias=False)
    w, lam = sw.dpss(T, 3.0, Kmax=5, return_ratios=True)
    G = tap @ tap.T
    print(T, "SC eig", np.round(ev, 5), "scipy", np.round(lam, 5))
    print("   SC gram offdiag max", np.abs(G - np.diag(np.diag(G))).max(), "|<sc_k, scipy_k>|", np.round(np.abs((tap*w).sum(1)), 5))
