import sys, numpy as np, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs")
import _kernels_distance as K
from hyppo.independence import Dcorr, Hsic
from cdt.causality.pairwise import RECI
rng = np.random.default_rng(5)
for n in (3, 4, 5):
    for _ in range(3):
        a, b = rng.standard_normal((2, n))
        for bias in (False, True):
            try: h = Dcorr(bias=bias).statistic(a[:, None], b[:, None])
            except Exception as e: h = repr(e)
            try: k = K.dcorr(a, b, biased=bias, sklearn_arith=True)["hyppo"]
            except Exception as e: k = repr(e)
            print("dcorr n", n, "bias", bias, "hyppo", h, "kernel", k)
c = np.ones(30); y = rng.standard_normal(30)
print("hsic const hyppo", Hsic().statistic(c[:, None], y[:, None]), Hsic().statistic(y[:, None], c[:, None]), "kernel replica", K.hyppo_hsic_replica(c, y), K.hyppo_hsic_replica(y, c), "gretton normalised", K.hsic_biased(c, y)["normalised"])
r = RECI()
print("reci const cdt", r.b_fit_score(c, y), "kernel", K.reci_ref(c, y)); print("reci const y cdt", r.b_fit_score(y, c), "kernel", K.reci_ref(y, c))
print("reci edge probe input (rng 0?)")
