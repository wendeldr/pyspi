import numpy as np, warnings, scipy.signal.windows as sw
warnings.simplefilter("ignore")
from spectral_connectivity.transforms import dpss_windows
bad = []
for T in list(range(7, 1100)) + [2048, 4096]:
    tap, ev = dpss_windows(T, 3.0, 5, is_low_bias=True)
    w, lam = sw.dpss(T, 3.0, Kmax=5, return_ratios=True)
    keep = lam > 0.9
    if tap.shape[0] != keep.sum() or not np.isfinite(tap).all() or np.abs(tap - w[keep]).max() > 1e-10:
        bad.append((T, tap.shape[0], int(keep.sum())))
print("mismatching T:", bad)
