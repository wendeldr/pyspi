p = "/media/dan/Data/git/pyspi/audit/checks/refs/_kernels_distance.py"
s = open(p).read()
def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new)

# --- dcorr guard
rep('''    if biased:
        A, B, s = _double_centre(dx), _double_centre(dy), 1.0 / dx.shape[0] ** 2
    else:
        n = dx.shape[0]
        A, B, s = _u_centre(dx), _u_centre(dy), 1.0 / (n * (n - 3))''',
'''    n = dx.shape[0]
    if biased:
        A, B, s = _double_centre(dx), _double_centre(dy), 1.0 / n ** 2
    else:
        if n < 4:   # n(n-3) = 0; hyppo's numba path divides by zero here too (dcorr.py:404-405)
            raise ValueError(f"bias-corrected dCor needs n >= 4 samples, got {n}")
        A, B, s = _u_centre(dx), _u_centre(dy), 1.0 / (n * (n - 3))''')
rep('''    Returns (dcor2, dcov2_xy, dvar2_x, dvar2_y). dcor2 is 0 when a variance is <= 0.
    """''', '''    Returns (dcor2, dcov2_xy, dvar2_x, dvar2_y). dcor2 is 0 when a variance is <= 0.
    Raises ValueError for biased=False with n < 4 (also reached by dcorrx_mehta when max_lag > n - 4).
    """''')

# --- hsic citation + constant guard
rep('''    """Biased empirical HSIC with Gaussian kernels (Gretton et al. 2005, ALT, biased estimator, 1/n^2):
    HSIC_b = tr(K H L H) / n^2, where H = I - 11^T/n and K_ij = exp(-gamma |x_i - x_j|^2).
''', '''    """Biased empirical HSIC with Gaussian kernels, HSIC_b = tr(K H L H) / n^2 (the 1/n^2 form of Gretton,
    Fukumizu, Teo, Song, Schoelkopf & Smola 2008, NIPS 20, 'A kernel statistical test of independence').
    Gretton et al. 2005 (ALT) eq. 9 scales by (n-1)^-2 instead; the factor cancels in 'normalised'.
    H = I - 11^T/n, K_ij = exp(-gamma |x_i - x_j|^2). 'normalised' is 0 when hsic_xx * hsic_yy <= 0
    (a constant series), matching the 0 that hyppo returns for a zero variance (dcorr.py:439-440).
''')
rep('''    return {"hsic": hxy, "hsic_xx": hxx, "hsic_yy": hyy, "normalised": hxy / np.sqrt(hxx * hyy),''',
'''    nrm = hxy / np.sqrt(hxx * hyy) if hxx * hyy > 0 else 0.0
    return {"hsic": hxy, "hsic_xx": hxx, "hsic_yy": hyy, "normalised": nrm,''')

# --- RBF arithmetic
rep('''def _rbf(x, c, l):
    return c * np.exp(-0.5 * _sk_sqdist(np.asarray(x, float).reshape(-1, 1) / l))
''', '''def _sqdiff_scaled(x, l):
    """(x_i/l - x_j/l)^2, (n, n), by exact differencing of the pre-scaled inputs. This is sklearn RBF's
    arithmetic: pdist(X / length_scale, 'sqeuclidean') for k(X) and cdist(...) for k(X, X_train)
    (sklearn/gaussian_process/kernels.py:1561, 1569), NOT the dot-product form of pairwise.py. In the ANM
    regime (l ~ 1e-4, residual ~ 1e-10 y) rounding-level differences in K reach the z-scored residual."""
    z = np.asarray(x, float).ravel() / l
    return (z[:, None] - z[None, :]) ** 2


def _rbf(x, c, l):
    """c * exp(-0.5 * (x_i/l - x_j/l)^2), (n, n): sklearn ConstantKernel(c) * RBF(l) (kernels.py:1561-1564)."""
    return c * np.exp(-0.5 * _sqdiff_scaled(x, l))
''')
rep('''    These mirror sklearn GaussianProcessRegressor (sklearn/gaussian_process/_gpr.py:215-218, 249, 348-352).
    x, y (n,). Returns the prediction (n,)."""''',
'''    These mirror sklearn GaussianProcessRegressor: K + alpha I, lower Cholesky, alpha_ = cho_solve, mean = K alpha_
    (sklearn/gaussian_process/_gpr.py:350-363, 446-447), with the RBF arithmetic of _sqdiff_scaled.
    x, y (n,). Returns the prediction (n,)."""''')
rep('''    S = _sk_sqdist(x.reshape(-1, 1))

    def nlml(th):
        c, l = np.exp(th)
        K0 = np.exp(-0.5 * S / l ** 2)
        cf = cho_factor(c * K0 + alpha * np.eye(len(x)), lower=True)
        a = cho_solve(cf, y)
        Ki = cho_solve(cf, np.eye(len(x)))
        W = np.outer(a, a) - Ki
        g = [-0.5 * np.sum(W * (c * K0)), -0.5 * np.sum(W * (c * K0 * S / l ** 2))]''',
'''
    def nlml(th):
        c, l = np.exp(th)
        S = _sqdiff_scaled(x, l)                               # (x_i - x_j)^2 / l^2, sklearn arithmetic
        K0 = np.exp(-0.5 * S)
        cf = cho_factor(c * K0 + alpha * np.eye(len(x)), lower=True)
        a = cho_solve(cf, y)
        Ki = cho_solve(cf, np.eye(len(x)))
        W = np.outer(a, a) - Ki
        g = [-0.5 * np.sum(W * (c * K0)), -0.5 * np.sum(W * (c * K0 * S))]''')

# --- RECI constant guard
rep('''    features with the x and x^2 columns zeroed). Infer x -> y when reci(x, y) < reci(y, x)."""
    s = lambda v: (v - v.min()) / (v.max() - v.min())''',
'''    features with the x and x^2 columns zeroed). Infer x -> y when reci(x, y) < reci(y, x).
    A constant variable scales to 0, as sklearn minmax_scale does (zero range -> 1, preprocessing/_data.py:537-539)."""
    s = lambda v: (v - v.min()) / ((v.max() - v.min()) or 1.0)''')
open(p, "w").write(s)
print("ok")
