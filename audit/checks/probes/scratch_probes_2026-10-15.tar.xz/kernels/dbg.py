import sys; sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import numpy as np, make_data as md, scipy.special as sp
from _kernels_spectral import *
d = md.load("var2_bivariate", 4096); A=[d["A1"],d["A2"]]; Sig=d["Sigma"]
co, fr = multitaper_fft(d["x"]); Sh = cross_spectral_matrix(co)
H,Af,S = var_transfer_function(A, fr, Sig); n=len(fr)//2
dd=ddtf(H[:n],S[:n]); ddl=ddtf_library_as_coded(H[:n])
print(dd[:,0,1].max(), ddl[:,0,1].max(), np.abs(np.sqrt(dd)-ddl)[:,1,0].max())
for T in (1024,4096):
  co, fr = multitaper_fft(md.load("var2_bivariate", T)["x"]); Sh = cross_spectral_matrix(co)
  Hw,Sg,info=wilson_factorise(Sh)
  print(T, np.linalg.det(Sg)/np.linalg.det(Sig), np.exp(sp.digamma(5)+sp.digamma(4)-2*np.log(5)), Sg, np.mean(np.log(np.linalg.det(Sh).real)) - np.log(np.linalg.det(Sig)))
rng=np.random.default_rng(1)
K,nf,phi=5,64,0.7
X0 = rng.standard_normal((K, nf)) + 1j * rng.standard_normal((K, nf))
co = np.stack([X0, X0 * rng.uniform(0.2, 3, (K, nf)) * np.exp(-1j * phi)], axis=-1)
for nm,v in {"PLV": phase_locking_value(co)[:, 0, 1], "PLI": phase_lag_index(co)[:, 0, 1],
            "wPLI": weighted_phase_lag_index(co)[:, 0, 1], "PPC": pairwise_phase_consistency(co)[:, 0, 1],
            "dPLI2": debiased_squared_pli(co)[:, 0, 1], "dwPLI2": debiased_squared_wpli(co)[:, 0, 1],
            "phase": coherence_phase(cross_spectral_matrix(co))[:, 0, 1] / phi}.items(): print(nm, np.abs(v-1).max())
