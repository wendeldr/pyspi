"""Reference kernels: distance-similarity and causal-inference SPIs (pyspi calculation audit).

Independent numpy/scipy implementations written from the cited papers. Library conventions are
mirrored only where a docstring says so, with the library file:line (paths relative to
``.venv/lib/python3.12/site-packages/``). This module never imports hyppo, tslearn, cdt or pyEDM.
dcor, dtaidistance and POT are used only as labelled second opinions inside ``selftest``.
Run ``python _kernels_distance.py --selftest``. Equation, definition and algorithm numbers come from memory,
except Kravtsova et al. (from audit/notes/gwtau.md), and were not re-checked against the PDFs.

Shapes: 1-D series are ``(n,)``. Multivariate samples are ``(n, p)``. Datasets are ``(n_series, T)``.
"""
import sys
import numpy as np
from scipy.linalg import cho_factor, cho_solve
from scipy.optimize import minimize
from scipy.special import digamma


def _as2d(x):
    x = np.asarray(x, dtype=float)
    return x[:, None] if x.ndim == 1 else x


def _pdist(x):
    """Exact Euclidean distance matrix, (n, n), computed by direct differencing."""
    x = _as2d(x)
    return np.sqrt(((x[:, None, :] - x[None, :, :]) ** 2).sum(-1))


def _sk_sqdist(x):
    """Squared distances with sklearn's float64 arithmetic: -2 X X^T + |x_i|^2 + |x_j|^2, clipped at 0,
    zero diagonal (sklearn/metrics/pairwise.py:409-421). Used only by the hyppo/cdt replicas."""
    x = _as2d(x)
    xx = np.einsum("ij,ij->i", x, x)[:, None]
    d = -2 * (x @ x.T)
    d += xx
    d += xx.T
    np.maximum(d, 0, out=d)
    np.fill_diagonal(d, 0)
    return d


# ----------------------------------------------------------------- distance correlation
def _double_centre(a):
    return a - a.mean(0, keepdims=True) - a.mean(1, keepdims=True) + a.mean()


def _u_centre(a):
    n = a.shape[0]
    u = a - a.sum(0, keepdims=True) / (n - 2) - a.sum(1, keepdims=True) / (n - 2) + a.sum() / ((n - 1) * (n - 2))
    np.fill_diagonal(u, 0.0)
    return u


def dcorr_from_dist(dx, dy, biased=False):
    """Squared distance correlation from (n, n) distance matrices.

    biased=True:  V-statistic dCor_n^2 (Szekely, Rizzo & Bakirov 2007, Ann. Stat. 35, Sec. 2):
        A = double-centred a_ij, dCov_n^2 = (1/n^2) sum A_ij B_ij, dCor_n^2 = dCov^2(x,y)/sqrt(dVar^2 x dVar^2 y).
    biased=False: bias-corrected dCor^2 from U-centred matrices (Szekely & Rizzo 2014, Ann. Stat. 42,
        Sec. 3, U-centring): A~_ij = a_ij - a_i./(n-2) - a_.j/(n-2) + a_../((n-1)(n-2)), A~_ii = 0,
        (A~.B~) = sum A~B~ / (n(n-3)). It can be negative.
    Returns (dcor2, dcov2_xy, dvar2_x, dvar2_y). dcor2 is 0 when a variance is <= 0.
    """
    if biased:
        A, B, s = _double_centre(dx), _double_centre(dy), 1.0 / dx.shape[0] ** 2
    else:
        n = dx.shape[0]
        A, B, s = _u_centre(dx), _u_centre(dy), 1.0 / (n * (n - 3))
    cxy, cxx, cyy = s * np.sum(A * B), s * np.sum(A * A), s * np.sum(B * B)
    d2 = 0.0 if (cxx <= 0 or cyy <= 0) else cxy / np.sqrt(cxx * cyy)
    return d2, cxy, cxx, cyy


def hyppo_dcorr_from_dist(dx, dy, biased=False):
    """What hyppo's Dcorr.statistic returns for precomputed distances (mirrored, not imported).

    hyppo/independence/dcorr.py:417-447 (_dcorr): stat = 0 if varx<=0, vary<=0 or (biased and cov<=0).
    Otherwise stat = cov/sqrt(varx*vary), and when biased, stat = sqrt(stat). So hyppo returns
    dCor (NOT squared) for bias=True and the bias-corrected dCor^2 (signed) for bias=False. The centring
    is at dcorr.py:262-281. The non-fast path is always used: is_fast is only set inside .test() (dcorr.py:237).
    """
    d2, cxy, cxx, cyy = dcorr_from_dist(dx, dy, biased)
    if cxx <= 0 or cyy <= 0 or (biased and cxy <= 0):
        return 0.0
    return float(np.sqrt(d2)) if biased else float(d2)


def dcorr(x, y, biased=False, sklearn_arith=False):
    """Distance correlation of paired samples x (n,)|(n,p) and y (n,)|(n,q) with Euclidean distances.

    Implements Szekely, Rizzo & Bakirov 2007 (biased V-statistic) and Szekely & Rizzo 2014 (U-centred,
    bias-corrected). Returns a dict with:
      dcor2 - dCor^2 (V- or U-statistic),
      dcor  - sqrt(max(dcor2, 0)),
      hyppo - the value pyspi stores: dCor for biased=True, the signed dCor^2 for biased=False
              (see hyppo_dcorr_from_dist).
    sklearn_arith=True builds distances with sklearn's dot-product formula, as hyppo does
    (hyppo/tools/common.py:497-499 -> pairwise_distances). The difference is at rounding level.
    """
    if sklearn_arith:
        dx, dy = np.sqrt(_sk_sqdist(x)), np.sqrt(_sk_sqdist(y))
    else:
        dx, dy = _pdist(x), _pdist(y)
    d2 = dcorr_from_dist(dx, dy, biased)[0]
    return {"dcor2": float(d2), "dcor": float(np.sqrt(max(d2, 0.0))),
            "hyppo": hyppo_dcorr_from_dist(dx, dy, biased)}


# ------------------------------------------------------------------------------- HSIC
def median_gamma(x, sklearn_arith=False):
    """Gaussian-kernel gamma from the median heuristic, as hyppo computes it (hyppo/tools/common.py:321-333).

    med = median of the off-diagonal Euclidean distances of x (both triangles; the stride trick at
    common.py:326-330 visits every off-diagonal entry once). med = 1 if it is 0. gamma = 1/(2 med^2).
    hyppo computes gamma from x ONLY and reuses it for the y kernel (common.py:342-343).
    """
    d = np.sqrt(_sk_sqdist(x)) if sklearn_arith else _pdist(x)
    med = np.median(d[~np.eye(d.shape[0], dtype=bool)])
    med = med if med else 1.0
    return 1.0 / (2 * med ** 2)


def hsic_biased(x, y, gamma=None):
    """Biased empirical HSIC with Gaussian kernels (Gretton et al. 2005, ALT, biased estimator, 1/n^2):
    HSIC_b = tr(K H L H) / n^2, where H = I - 11^T/n and K_ij = exp(-gamma |x_i - x_j|^2).

    gamma=None uses median_gamma(x) for BOTH kernels, mirroring hyppo (common.py:321-343).
    gamma may also be a pair (gamma_x, gamma_y).
    Returns dict(hsic, hsic_xx, hsic_yy, normalised = hsic / sqrt(hsic_xx * hsic_yy), gamma_x, gamma_y).
    """
    gx, gy = (median_gamma(x),) * 2 if gamma is None else (np.broadcast_to(gamma, 2))
    K, L = np.exp(-gx * _pdist(x) ** 2), np.exp(-gy * _pdist(y) ** 2)
    n = K.shape[0]
    Kc, Lc = _double_centre(K), _double_centre(L)              # H K H, H L H
    h = lambda a, b: float(np.sum(a * b) / n ** 2)             # tr(HKH HLH) = sum (HKH)*(HLH)
    hxy, hxx, hyy = h(Kc, Lc), h(Kc, Kc), h(Lc, Lc)
    return {"hsic": hxy, "hsic_xx": hxx, "hsic_yy": hyy, "normalised": hxy / np.sqrt(hxx * hyy),
            "gamma_x": float(gx), "gamma_y": float(gy)}


def hyppo_hsic_replica(x, y, biased=False):
    """Re-creates hyppo's Hsic.statistic, which is what pyspi's hsic / hsic_biased call.

    hyppo/independence/hsic.py:117-122: K, L = Gaussian kernels with the x-derived median gamma
    (common.py:321-343, sklearn arithmetic). Then D_x = 1 - K/max(K) and D_y = 1 - L/max(L), and these go to
    Dcorr(compute_distance=None, bias). The result is therefore dCor (biased) or the signed U-dCor^2 of the
    kernel-induced distances (hyppo_dcorr_from_dist). It is NOT the Gretton tr(KHLH)/n^2.
    """
    g = median_gamma(x, sklearn_arith=True)
    K, L = np.exp(-g * _sk_sqdist(x)), np.exp(-g * _sk_sqdist(y))
    return hyppo_dcorr_from_dist(1 - K / np.max(K), 1 - L / np.max(L), biased)


# -------------------------------------------------------------------------------- HHG
def hhg(x, y):
    """Heller, Heller & Gorfine 2013 (Biometrika 100, 503-510), sum-of-chi-square statistic:
    T = sum over i != j of S(i,j), with
    S(i,j) = (n-2) (A12 A21 - A11 A22)^2 / (A1. A2. A.1 A.2).
    A is the 2x2 table, over k not in {i,j}, of [d(x_i,x_k) <= d(x_i,x_j)] x [d(y_i,y_k) <= d(y_i,y_j)].
    A term with a zero margin contributes 0, as in hyppo/independence/hhg.py:293-295.
    Swapping x and y transposes every table, which leaves S unchanged, so T(x,y) = T(y,x).
    pyspi labels hhg 'Directed', but the statistic is symmetric. Cost O(n^3); fine for n <= ~300.
    """
    dx, dy = _pdist(x), _pdist(y)
    n, tot = dx.shape[0], 0.0
    for i in range(n):
        a = (dx[i][None, :] <= dx[i][:, None]).astype(float)    # a[j, k] = d(x_i,x_k) <= d(x_i,x_j)
        b = (dy[i][None, :] <= dy[i][:, None]).astype(float)
        a[:, i] = b[:, i] = 0.0                               # drop k = i
        a[np.arange(n), np.arange(n)] = b[np.arange(n), np.arange(n)] = 0.0   # drop k = j
        t11 = (a * b).sum(1); t12 = (a * (1 - b)).sum(1); t21 = ((1 - a) * b).sum(1)
        t22 = (n - 2) - t11 - t12 - t21                       # k = i, j are in none of the four cells
        den = (t11 + t12) * (t21 + t22) * (t11 + t21) * (t12 + t22)
        num = (n - 2) * (t12 * t21 - t11 * t22) ** 2
        s = np.where(den > 0, num / np.where(den > 0, den, 1.0), 0.0)
        s[i] = 0.0
        tot += s.sum()
    return float(tot)


# ------------------------------------------------------------------------------ DcorrX
def dcorrx_mehta(x, y, max_lag, biased=False):
    """Cross-distance correlation (Mehta et al. 2019, arXiv:1907.02088, DcorrX):
    DcorrX = sum_{j=0}^{M} ((n-j)/n) Dcorr(x[j:n], y[0:n-j]).
    Here Dcorr is the U-centred dCor^2 (hyppo's default, bias=False), and distances are taken between the
    SERIES SAMPLES of each slice. So D_x^{(j)} = D_x[j:, j:], a sub-matrix of the full distance matrix.
    Direction: lag j pairs x_{t+j} with y_t (y leads). In pyspi, x = process i and y = process j.
    Returns (stat, per_lag list of weighted terms, opt_lag = argmax of the weighted terms).
    """
    dx, dy = _pdist(x), _pdist(y)
    n, terms = dx.shape[0], []
    for j in range(max_lag + 1):
        v = hyppo_dcorr_from_dist(dx[j:, j:], dy[:n - j, :n - j], biased)
        terms.append((n - j) * v / n)
    return float(np.sum(terms)), terms, int(np.argmax(terms))


def hyppo_dcorrx_replica(x, y, max_lag, biased=False):
    """What hyppo's DcorrX.statistic computes (hyppo/time_series/_utils.py:85-108), mirrored:
    lag 0 is Dcorr on the raw series (line 93). For j >= 1, the SLICES OF THE DISTANCE MATRICES (lines 99-101)
    go to a Dcorr whose compute_distance is still 'euclidean' (line 92). Each row of D_x[j:, j:] is treated
    as a point in R^{n-j}, and Euclidean distances are taken again (distance-of-distance-matrix). Weights are
    (n-j)/n (line 102). stat = sum, opt_lag = argmax (lines 105-106). sklearn arithmetic is used throughout.
    """
    dx, dy = np.sqrt(_sk_sqdist(x)), np.sqrt(_sk_sqdist(y))
    n = dx.shape[0]
    terms = [hyppo_dcorr_from_dist(dx, dy, biased)]
    for j in range(1, max_lag + 1):
        sx, sy = dx[j:n, j:n], dy[0:n - j, 0:n - j]
        v = hyppo_dcorr_from_dist(np.sqrt(_sk_sqdist(sx)), np.sqrt(_sk_sqdist(sy)), biased)
        terms.append((n - j) * v / n)
    return float(np.sum(terms)), terms, int(np.argmax(terms))


# --------------------------------------------------------------------- DTW family masks
def sakoe_chiba_mask(sz1, sz2, radius=1):
    """Sakoe-Chiba band, mirroring tslearn/metrics/_masks.py:15-29 (for equal lengths, |i-j| <= radius)."""
    mask = np.zeros((sz1, sz2), bool)
    if sz1 > sz2:
        width = sz1 - sz2 + radius
        for i in range(sz2):
            mask[max(0, i - radius):min(sz1, i + width) + 1, i] = True
    else:
        width = sz2 - sz1 + radius
        for i in range(sz1):
            mask[i, max(0, i - radius):min(sz2, i + width) + 1] = True
    return mask


def itakura_mask(sz1, sz2, max_slope=2.0):
    """Itakura parallelogram (Itakura 1975), mirroring tslearn/metrics/_masks.py:91-140, including the
    2-decimal rounding of the bounds before ceil/floor."""
    min_slope = 1 / float(max_slope)
    max_slope = max_slope * float(sz1) / float(sz2)
    min_slope = min_slope * float(sz1) / float(sz2)
    k = np.arange(sz2)
    lb = np.ceil(np.maximum(np.round(min_slope * k, 2), np.round((sz1 - 1) - max_slope * (sz2 - 1) + max_slope * k, 2)))
    ub = np.floor(np.minimum(np.round(max_slope * k, 2), np.round((sz1 - 1) - min_slope * (sz2 - 1) + min_slope * k, 2)) + 1)
    mask = np.zeros((sz1, sz2), bool)
    for i in range(sz2):
        mask[int(lb[i]):int(ub[i]), i] = True
    if not (mask.any(1).all() and mask.any(0).all()):
        raise ValueError("itakura_max_slope constraint is infeasible for these sizes")
    return mask


def _mask(n, m, constraint, radius, slope):
    """tslearn/metrics/_masks.py:318-350: None -> full mask; 'sakoe_chiba' -> radius (default 1);
    'itakura' -> max slope (default 2)."""
    if constraint is None:
        return np.ones((n, m), bool)
    if constraint == "sakoe_chiba":
        return sakoe_chiba_mask(n, m, radius)
    if constraint == "itakura":
        return itakura_mask(n, m, slope)
    raise ValueError(constraint)


def _diag(n, m, d):
    """1-based cells (i, j) of anti-diagonal i + j = d in an (n+1, m+1) DP table."""
    i = np.arange(max(1, d - m), min(n, d - 1) + 1)
    return i, d - i


def _sqcost(x, y):
    x, y = _as2d(x), _as2d(y)
    return ((x[:, None, :] - y[None, :, :]) ** 2).sum(-1)


# ------------------------------------------------------------------------------ DTW
def dtw_acc(x, y, constraint=None, sakoe_chiba_radius=1, itakura_max_slope=2.0):
    """Accumulated cost R (n+1, m+1), with R[0,0] = 0, inf boundaries and inf in masked cells.
    R[i,j] = c(i,j) + min(R[i-1,j], R[i,j-1], R[i-1,j-1]), with squared local cost (tslearn/metrics/_dtw.py:325-344).
    Each anti-diagonal is filled in one vectorised step, which applies the same arithmetic as the cell loop."""
    C = _sqcost(x, y)
    n, m = C.shape
    M = _mask(n, m, constraint, sakoe_chiba_radius, itakura_max_slope)
    R = np.full((n + 1, m + 1), np.inf)
    R[0, 0] = 0.0
    for d in range(2, n + m + 1):
        i, j = _diag(n, m, d)
        best = np.minimum(np.minimum(R[i - 1, j], R[i, j - 1]), R[i - 1, j - 1])
        R[i, j] = np.where(M[i - 1, j - 1], C[i - 1, j - 1] + best, np.inf)
    return R


def dtw_dp(x, y, constraint=None, sakoe_chiba_radius=1, itakura_max_slope=2.0, squared_cost=True):
    """Dynamic time warping by O(nm) dynamic programming (Sakoe & Chiba 1978, IEEE TASSP 26, 43-49).

    squared_cost=True (tslearn form, pyspi's dtw*): returns sqrt(min over warping paths of sum (x_i - y_j)^2)
        with steps (1,0), (0,1), (1,1), all of weight 1 (tslearn/metrics/_dtw.py:383-400). The masks follow
        tslearn/metrics/_masks.py. radius r here corresponds to dtaidistance window = r + 1.
    squared_cost=False: Sakoe & Chiba 1978 symmetric form with slope constraint P = 0:
        g(i,j) = min(g(i-1,j) + d, g(i-1,j-1) + 2d, g(i,j-1) + d) with d = |x_i - y_j|, and D = g(n,m)/(n+m).
        Same masks.
    """
    if squared_cost:
        return float(np.sqrt(dtw_acc(x, y, constraint, sakoe_chiba_radius, itakura_max_slope)[-1, -1]))
    C = np.sqrt(_sqcost(x, y))
    n, m = C.shape
    M = _mask(n, m, constraint, sakoe_chiba_radius, itakura_max_slope)
    g = np.full((n + 1, m + 1), np.inf)
    g[0, 0] = 0.0
    for d in range(2, n + m + 1):
        i, j = _diag(n, m, d)
        c = C[i - 1, j - 1]
        v = np.minimum(np.minimum(g[i - 1, j] + c, g[i, j - 1] + c), g[i - 1, j - 1] + 2 * c)
        g[i, j] = np.where(M[i - 1, j - 1], v, np.inf)
    return float(g[n, m] / (n + m))


def dtw_path(x, y):
    """Optimal unconstrained path. Backtracking mirrors tslearn/metrics/utils.py:20-46: from (n-1, m-1),
    take argmin over [diag, up (i-1), left (j-1)], with the first index winning ties.
    Returns (dist, list of (i, j))."""
    A = dtw_acc(x, y)[1:, 1:]
    i, j = A.shape[0] - 1, A.shape[1] - 1
    path = [(i, j)]
    while (i, j) != (0, 0):
        if i == 0:
            j -= 1
        elif j == 0:
            i -= 1
        else:
            k = int(np.argmin([A[i - 1, j - 1], A[i - 1, j], A[i, j - 1]]))
            i, j = (i - 1, j - 1) if k == 0 else ((i - 1, j) if k == 1 else (i, j - 1))
        path.append((i, j))
    return float(np.sqrt(A[-1, -1])), path[::-1]


# ----------------------------------------------------------------------------- LCSS
def lcss_dp(x, y, eps=1.0, constraint=None, sakoe_chiba_radius=1, itakura_max_slope=2.0, strict=False):
    """LCSS similarity (Vlachos, Gunopulos & Kollios 2002, ICDE), with tslearn's conventions: a match is
    ||x_i - y_j|| <= eps (strict=True gives Vlachos' < eps), a masked cell holds 0, and the score is L(n,m)/min(n,m)
    (tslearn/metrics/dtw_variants.py:2301-2310 generic path, 2343-2345). For the Sakoe-Chiba band, holding 0 in
    masked cells gives the same result as Vlachos' delta-window rule.
    NOTE: the numpy path that pyspi runs (dtw_variants.py:2259) gates cells with numpy.isfinite(bool mask). That is
    always True, so in tslearn 0.9.0 pyspi's lcss_constraint-* values equal unconstrained lcss (audit/notes/dtw_family.md).
    To reproduce pyspi, use constraint=None.
    """
    C = np.sqrt(_sqcost(x, y))
    n, m = C.shape
    M = _mask(n, m, constraint, sakoe_chiba_radius, itakura_max_slope)
    L = np.zeros((n + 1, m + 1))
    for d in range(2, n + m + 1):
        i, j = _diag(n, m, d)
        hit = C[i - 1, j - 1] < eps if strict else C[i - 1, j - 1] <= eps
        v = np.where(hit, 1 + L[i - 1, j - 1], np.maximum(L[i, j - 1], L[i - 1, j]))
        L[i, j] = np.where(M[i - 1, j - 1], v, 0.0)
    return float(L[n, m] / min(n, m))


# ------------------------------------------------------------------------ soft-DTW
def _softmin3(a, b, c, gamma):
    """-gamma log(sum exp(-v/gamma)), with the max-shift order of tslearn/metrics/soft_dtw_fast.py:37-48."""
    a, b, c = a / -gamma, b / -gamma, c / -gamma
    mx = np.maximum(np.maximum(a, b), c)
    return -gamma * (np.log(np.exp(a - mx) + np.exp(b - mx) + np.exp(c - mx)) + mx)


def soft_dtw_acc(x, y, gamma=1.0):
    """Soft-DTW table R (n+1, m+1) (Cuturi & Blondel 2017, ICML, Algorithm 1):
    R[i,j] = D[i,j] + softmin_gamma(R[i-1,j], R[i-1,j-1], R[i,j-1]), D = squared Euclidean,
    R[0,0] = 0, other boundaries = +inf (tslearn uses DBL_MAX, soft_dtw_fast.py:115-118; same result).
    Returns (R, D)."""
    D = _sqcost(x, y)
    n, m = D.shape
    R = np.full((n + 1, m + 1), np.inf)
    R[0, 0] = 0.0
    with np.errstate(invalid="ignore"):
        for d in range(2, n + m + 1):
            i, j = _diag(n, m, d)
            R[i, j] = D[i - 1, j - 1] + _softmin3(R[i - 1, j], R[i - 1, j - 1], R[i, j - 1], gamma)
    return R, D


def soft_dtw_dp(x, y, gamma=1.0):
    """Soft-DTW value R[n,m] (Cuturi & Blondel 2017, Alg. 1). As gamma -> 0 it tends to dtw^2;
    tslearn returns dtw^2 exactly when gamma == 0 (softdtw_variants.py:627-628). For gamma > 0, softmin < min,
    so soft_dtw(x, x) < 0 (it is not a divergence). Exact bounds:
    dtw^2 - gamma*log(3)*(n+m-1) <= soft_dtw <= dtw^2.
    pyspi's softdtw* SPIs ignore the global_constraint (distance.py:205-208), so the constraint variants equal softdtw.
    """
    return float(soft_dtw_acc(x, y, gamma)[0][-1, -1])


def soft_dtw_grad_D(R, D, gamma):
    """E = d soft_dtw / d D (n, m), from the backward recursion of Cuturi & Blondel 2017, Algorithm 2."""
    n, m = D.shape
    Dp = np.zeros((n + 2, m + 2)); Dp[1:-1, 1:-1] = D
    Rp = np.full((n + 2, m + 2), -np.inf); Rp[1:-1, 1:-1] = R[1:, 1:]; Rp[-1, -1] = R[n, m]
    E = np.zeros((n + 2, m + 2)); E[-1, -1] = 1.0
    for d in range(n + m, 1, -1):
        i, j = _diag(n, m, d)
        a = np.exp((Rp[i + 1, j] - Rp[i, j] - Dp[i + 1, j]) / gamma)
        b = np.exp((Rp[i, j + 1] - Rp[i, j] - Dp[i, j + 1]) / gamma)
        c = np.exp((Rp[i + 1, j + 1] - Rp[i, j] - Dp[i + 1, j + 1]) / gamma)
        E[i, j] = E[i + 1, j] * a + E[i, j + 1] * b + E[i + 1, j + 1] * c
    return E[1:-1, 1:-1]


def soft_dtw_barycenter_objective(z, X, gamma=1.0, weights=None):
    """Objective and gradient of the soft-DTW barycenter (Cuturi & Blondel 2017, Sec. 4, barycenters):
    f(z) = sum_k w_k sdtw_gamma(z, X_k), grad_i = sum_k w_k sum_j E^k_ij 2 (z_i - X_kj).
    The weights are uniform ones, as in tslearn/barycenters/softdtw.py:19-35 and utils._set_weights.
    Use it as an optimality check: the gradient at pyspi's softdtw barycenter should be small. z (T,), X (K, T)."""
    z = np.asarray(z, float)
    w = np.ones(len(X)) if weights is None else np.asarray(weights, float)
    f, g = 0.0, np.zeros_like(z)
    for wk, xk in zip(w, X):
        R, D = soft_dtw_acc(z, xk, gamma)
        E = soft_dtw_grad_D(R, D, gamma)
        f += wk * R[-1, -1]
        g += wk * 2 * (E.sum(1) * z - E @ np.asarray(xk, float))
    return float(f), g


# ---------------------------------------------------------------------- barycenters
def euclidean_barycenter(X):
    """Euclidean barycenter = pointwise mean over series (tslearn/barycenters/euclidean.py:44). X (K, T) -> (T,)."""
    return np.asarray(X, float).mean(0)


def dba(X, max_iter=30, tol=1e-5):
    """DTW barycenter averaging (Petitjean, Ketterlin & Gancarski 2011, Pattern Recogn. 44, 678-693), in the
    form pyspi calls it (tslearn dtw_barycenter_averaging, n_init=1, tslearn/barycenters/dba.py:700-737):
      init = pointwise mean (dba.py:23-25);
      each iteration: align every series to the current barycenter (dtw_path), cost = mean_k dtw_k^2
        (uniform weights, dba.py:229-305), then set each barycenter point to the mean of its associated
        points (dba.py:400-434);
      stop when |cost_prev - cost| < tol, or when cost rises. The barycenter that was just updated is returned
        either way (dba.py:727-737).
    X (K, T). Returns (barycenter (T,), list of costs, one per iteration, each for the pre-update barycenter).
    """
    X = np.asarray(X, float)
    z = X.mean(0)
    costs, prev = [], np.inf
    for _ in range(max_iter):
        num, cnt, cost = np.zeros_like(z), np.zeros_like(z), 0.0
        for xk in X:
            dist, path = dtw_path(z, xk)
            cost += dist ** 2
            p = np.array(path)
            np.add.at(num, p[:, 0], xk[p[:, 1]])
            np.add.at(cnt, p[:, 0], 1.0)
        cost /= len(X)
        costs.append(cost)
        z = num / cnt
        if abs(prev - cost) < tol or prev < cost:
            break
        prev = cost
    return z, costs


# ---------------------------------------------------------------------------- GWtau
def wasserstein2_1d(a, b):
    """Exact W2 between the empirical uniform distributions of a (N,) and b (M,):
    sqrt of the integral over u in (0,1) of (F_a^{-1}(u) - F_b^{-1}(u))^2. This is computed on the merged
    quantile breakpoints. It matches Kravtsova et al. 2023 eq. 11 (N = M) and eq. 12 (lambda_ij overlaps)."""
    a, b = np.sort(np.asarray(a, float)), np.sort(np.asarray(b, float))
    u = np.union1d(np.arange(len(a) + 1) / len(a), np.arange(len(b) + 1) / len(b))
    mid, du = 0.5 * (u[1:] + u[:-1]), np.diff(u)
    ia = np.minimum((mid * len(a)).astype(int), len(a) - 1)
    ib = np.minimum((mid * len(b)).astype(int), len(b) - 1)
    return float(np.sqrt(np.sum(du * (a[ia] - b[ib]) ** 2)))


def root_arc_lengths(x, include_root=False):
    """Root distances on the trajectory f(t) = (t, x_t), t = 0..n-1:
    d(r, x_k) = sum_{t<k} sqrt(1 + (x_{t+1} - x_t)^2) (Kravtsova, McGee & Dawes 2023, Bull. Math. Biol. 85:77, eq. 8).
    include_root=False drops the root's own 0, as pyspi distance.py:273-277 and the authors' vec_geo_dist.m do (n-1 values)."""
    x = np.asarray(x, float).ravel()
    L = np.cumsum(np.sqrt(1.0 + np.diff(x) ** 2))
    return np.concatenate([[0.0], L]) if include_root else L


def gwtau(x, y, include_root=False):
    """GW-tau with p = 2 (Kravtsova et al. 2023, eqs. 5, 10; Prop. 1a): W2 between the root-distance
    distributions of the two series. The pyspi docs (spi-descriptions/distance-similarity.md:164-180) describe
    it as 'distances from the start of each time series to every point ... compared using the Wasserstein
    distance'. supplement.txt section 1.2 (lines 209-330) has no gwtau entry.
    Difference from pyspi (distance.py:279-315): pyspi sorts both vectors in DESCENDING order and takes
    sqrt(mean((a-b)^2)). With equal lengths, sorting both in the same order gives the same monotone coupling,
    so the value equals this W2. pyspi excludes the root (include_root=False). The paper's uniform mass on all
    n points (include_root=True) changes the result, for equal lengths, by exactly sqrt((n-1)/n).
    """
    return wasserstein2_1d(root_arc_lengths(x, include_root), root_arc_lengths(y, include_root))


# ------------------------------------------------------------------------------ CCM
def _pearson0(a, b):
    """Pearson rho, set to 0 when either variance is 0 (cppEDM Common.cc behaviour, per audit/notes/ccm.md)."""
    a, b = a - a.mean(), b - b.mean()
    den = np.sqrt((a * a).sum() * (b * b).sum())
    return float((a * b).sum() / den) if den > 0 else 0.0


def simplex_crossmap(x, y, E, tau=-1, Tp=0, lib_indices=None):
    """Cross-map skill rho(y, y_hat | M_x): the delay embedding of x predicts y (Sugihara et al. 2012,
    Science 338, 496-500, and its supplement; simplex projection of Sugihara & May 1990).

    The embedding at row t is (x_t, x_{t+tau}, ..., x_{t+(E-1)tau}), with tau < 0 meaning lags into the past.
    Only rows with a complete embedding and a valid t+Tp are used. For every prediction row t (all valid rows),
    the E+1 nearest library rows (Euclidean, t itself excluded, stable sort) get weights
    u_i = exp(-d_i/d_1) (d_1 = nearest distance; when d_1 = 0 the weights are [d_i == 0]), floored at 1e-6.
    The prediction is y_hat(t+Tp) = sum w_i y(t_i + Tp). The skill is the Pearson rho over prediction rows.
    lib_indices=None uses every valid row. Otherwise pass the contiguous (or any) set of time indices.
    Direction (Sugihara): high skill of 'x xmap y' is evidence that y CAUSES x. This equals pyEDM's column
    'x:y' (columns=x, target=y). pyEDM's default arguments are E, Tp=0, tau=-1, knn=E+1 and exclusionRadius=0
    (pyEDM/CoreEDM.py:363-385). pyEDM expands distance ties at the k-th neighbour; this kernel does not.
    """
    x, y = np.asarray(x, float).ravel(), np.asarray(y, float).ravel()
    n, lag = len(x), -tau
    t0 = (E - 1) * lag
    rows = np.arange(t0, n)
    rows = rows[(rows + Tp >= 0) & (rows + Tp < n)]
    emb = np.stack([x[rows - k * lag] for k in range(E)], 1)
    lib = rows if lib_indices is None else np.intersect1d(rows, np.asarray(lib_indices))
    pos = np.searchsorted(rows, lib)
    Lemb, ylib = emb[pos], y[lib + Tp]
    pred = np.empty(len(rows))
    for a, t in enumerate(rows):
        d = np.sqrt(((Lemb - emb[a]) ** 2).sum(1))
        d[lib == t] = np.inf
        o = np.argsort(d, kind="stable")[:E + 1]
        dk = d[o]
        w = np.exp(-dk / dk[0]) if dk[0] > 0 else (dk == 0).astype(float)
        w = np.maximum(w, 1e-6)
        pred[a] = np.sum(w * ylib[o]) / np.sum(w)
    return _pearson0(y[rows + Tp], pred)


def ccm_skill_curve(x, y, E, lib_sizes, n_samples=100, seed=0, tau=-1, random=True):
    """CCM curve: the mean of simplex_crossmap(x, y) over n_samples libraries of each size L
    (Sugihara 2012, Fig. 3). random=True draws L valid rows without replacement (pyEDM's default
    random=True, replacement=False). numpy's RNG cannot reproduce pyEDM's std::default_random_engine(seed)
    draws, so only the statistics of the curves are comparable, not the values bit-for-bit.
    random=False uses the first L valid rows (a contiguous library). Returns an array (len(lib_sizes),)."""
    rng = np.random.default_rng(seed)
    valid = np.arange((E - 1) * (-tau), len(np.ravel(x)))
    out = []
    for L in lib_sizes:
        if not random:
            out.append(simplex_crossmap(x, y, E, tau, 0, valid[:L]))
            continue
        out.append(np.mean([simplex_crossmap(x, y, E, tau, 0, rng.choice(valid, L, replace=False))
                            for _ in range(n_samples)]))
    return np.array(out)


# -------------------------------------------------------------------- causal (cdt)
def _rbf(x, c, l):
    return c * np.exp(-0.5 * _sk_sqdist(np.asarray(x, float).reshape(-1, 1) / l))


def gp_posterior_mean(x, y, constant=1.0, length_scale=1.0, alpha=1e-10):
    """GP regression posterior mean at the training inputs (Rasmussen & Williams 2006, Alg. 2.1), with zero prior
    mean (normalize_y=False), kernel k = constant * exp(-|x-x'|^2 / (2 length_scale^2)) and jitter alpha.
    These mirror sklearn GaussianProcessRegressor (sklearn/gaussian_process/_gpr.py:215-218, 249, 348-352).
    x, y (n,). Returns the prediction (n,)."""
    K = _rbf(x, constant, length_scale)
    cf = cho_factor(K + alpha * np.eye(len(K)), lower=True)
    return K @ cho_solve(cf, np.asarray(y, float).ravel())


def gp_fit_hyperparameters(x, y, alpha=1e-10):
    """Maximise the log marginal likelihood over log(constant), log(length_scale) with L-BFGS-B,
    starting at (1, 1) with bounds [1e-5, 1e5]. This mirrors sklearn's default C()*RBF() and
    n_restarts_optimizer=0 (_gpr.py:216-217, 249; kernels.py:1236, 1511). Analytic gradient (Rasmussen & Williams 2006, Sec. 5.4.1).
    An independent optimiser, so expect agreement with sklearn's fit only to optimiser tolerance."""
    x, y = np.asarray(x, float).ravel(), np.asarray(y, float).ravel()
    S = _sk_sqdist(x.reshape(-1, 1))

    def nlml(th):
        c, l = np.exp(th)
        K0 = np.exp(-0.5 * S / l ** 2)
        cf = cho_factor(c * K0 + alpha * np.eye(len(x)), lower=True)
        a = cho_solve(cf, y)
        Ki = cho_solve(cf, np.eye(len(x)))
        W = np.outer(a, a) - Ki
        g = [-0.5 * np.sum(W * (c * K0)), -0.5 * np.sum(W * (c * K0 * S / l ** 2))]
        f = 0.5 * y @ a + np.log(np.diag(cf[0])).sum() + 0.5 * len(x) * np.log(2 * np.pi)
        return f, np.array(g)
    r = minimize(nlml, np.zeros(2), jac=True, method="L-BFGS-B", bounds=[(np.log(1e-5), np.log(1e5))] * 2)
    return tuple(np.exp(r.x))


def cdt_fast_hsic_gamma(X, Y, maxpnt=200):
    """cdt's FastHsicTestGamma statistic, mirrored from cdt/causality/pairwise/ANM.py:53-103:
    keep floor(arange(0, m, (m-1)/(maxpnt-1))) evenly spaced rows when m > maxpnt (ANM.py:81-86);
    rbf_dot bandwidth deg = sqrt(0.5 * median(upper-triangle squared distances > 0)) (ANM.py:61-63);
    K = exp(-H/(2 deg^2)); statistic = (1/m) sum(HKH * HLH), i.e. 1/m scaling, not 1/m^2 (ANM.py:99).
    A non-finite value is set to 0."""
    X, Y = np.asarray(X, float).ravel(), np.asarray(Y, float).ravel()
    m = len(X)
    if m > maxpnt:
        idx = np.floor(np.arange(0, m, float(m - 1) / (maxpnt - 1))).astype(int)
        X, Y, m = X[idx], Y[idx], len(idx)

    def rbf_dot(v):
        G = (v * v)[:, None]
        H = G + G.T - 2.0 * np.outer(v, v)
        dists = (H - np.tril(H)).ravel()
        deg = np.sqrt(0.5 * np.median(dists[dists > 0]))
        return np.exp(-H / 2.0 / deg ** 2)
    Kc, Lc = _double_centre(rbf_dot(X)), _double_centre(rbf_dot(Y))
    s = (1.0 / m) * np.sum(Kc.T * Lc)
    return float(s) if np.isfinite(s) else 0.0


def anm_replica(x, y, constant=None, length_scale=None, alpha=1e-10):
    """ANM fit score for x -> y (Hoyer et al. 2009, NIPS): fit y = f(x) + n by GP regression, then measure
    the dependence between the residual and x. A lower value means x -> y is more plausible.
    As pyspi runs it (pyspi/statistics/causal.py:18-29, the patched anm_score), there is NO extra scaling of the
    pyspi-z-scored inputs. The residual is y_hat - y, and the score is normalized_hsic(residual, x)
    (ANM.py:106-111: z-score each with np.std ddof=0, then cdt_fast_hsic_gamma).
    Hyperparameters: pass constant/length_scale to use fixed values (to match a known sklearn fit).
    None fits them with gp_fit_hyperparameters. sklearn OPTIMISES the default C()*RBF() kernel
    (_gpr.py:249), so the fixed C(1)*RBF(1) kernel is not what pyspi uses. With alpha=1e-10 the fit usually
    drives length_scale to the 1e-5 bound (interpolation). The residual is then about -1e-10*y, so after z-scoring
    the score measures dependence between y and x (audit/notes/cdt_pairwise.md:65). The kernel reproduces this."""
    x, y = np.asarray(x, float).ravel(), np.asarray(y, float).ravel()
    if constant is None or length_scale is None:
        constant, length_scale = gp_fit_hyperparameters(x, y, alpha)
    r = gp_posterior_mean(x, y, constant, length_scale, alpha) - y
    zs = lambda v: (v - v.mean()) / v.std()
    return cdt_fast_hsic_gamma(zs(r), zs(x))


def _cds_discretize(v, ffactor, maxdev, norm=True):
    """cdt CDS.py:56-80 for numerical data: if v has more unique values than the discretised range
    (2*ffactor*maxdev+1 values once it is long enough), z-score it, re-standardise on |z| < maxdev, round(z*ffactor)
    (half-to-even) and clip to +-ffactor*maxdev. With norm=False it only rounds and clips."""
    nu, nv = len(np.unique(v)), 2 * ffactor * maxdev + 1
    if norm and not nu > nv:                 # CDS.py:61, 70 reduce to: more unique values than nv
        return v
    if norm:
        v = (v - v.mean()) / v.std()
        vf = v[np.abs(v) < maxdev]
        v = (v - vf.mean()) / vf.std()
    return np.clip(np.round(v * ffactor), -ffactor * maxdev, ffactor * maxdev)


def cds_ref(x, y, ffactor=2, maxdev=3, minc=12):
    """Conditional distribution similarity, x -> y (Fonollosa 2016, arXiv:1601.06680, 'CDS' feature), mirroring
    cdt CDS.cds_score (CDS.py:143-195) for continuous y.
    Discretise x. For every x-bin with more than minc points, take y in the bin, centre it on the bin mean, scale
    by the GLOBAL std(y) (ddof 0) and discretise into the 13 bins of -6..6. Normalise the counts to a pmf.
    Score = std over all entries of (pmf matrix - column mean). Low values (similar conditionals) favour x -> y.
    cdt's CDS.predict_proba = cds(y,x) - cds(x,y), so a positive value means x -> y."""
    x, y = np.asarray(x, float).ravel(), np.asarray(y, float).ravel()
    xd = _cds_discretize(x, ffactor, maxdev)
    vals = np.arange(-ffactor * maxdev, ffactor * maxdev + 1)
    if not len(np.unique(y)) > len(vals):
        raise NotImplementedError("discrete-y branch of CDS.py:178-184 not mirrored")
    pyx = []
    for a in np.unique(xd):
        sel = xd == a
        if sel.sum() > minc:
            yx = _cds_discretize((y[sel] - y[sel].mean()) / y.std(), ffactor, maxdev, norm=False)
            p = np.array([(yx == v).sum() for v in vals], float)
            pyx.append(p / p.sum())
    if not pyx:
        return 0.0
    pyx = np.array(pyx)
    return float(np.std(pyx - pyx.mean(0)))


def reci_ref(x, y):
    """RECI fit score for x -> y (Bloebaum et al. 2018, AISTATS): min-max scale both variables to [0, 1],
    fit y by OLS on [1, x^3] and return the MSE. Mirrors cdt RECI.b_fit_score (RECI.py:104-118: degree-3 polynomial
    features with the x and x^2 columns zeroed). Infer x -> y when reci(x, y) < reci(y, x)."""
    s = lambda v: (v - v.min()) / (v.max() - v.min())
    x, y = s(np.asarray(x, float).ravel()), s(np.asarray(y, float).ravel())
    Z = np.column_stack([np.ones_like(x), x ** 3])
    beta = np.linalg.lstsq(Z, y, rcond=None)[0]
    return float(np.mean((Z @ beta - y) ** 2))


def _spacing_entropy(v):
    """Spacing estimator used by cdt (IGCI.py:42-56): sum of log|delta| over non-zero sorted spacings,
    divided by (n-1), plus psi(n) - psi(1)."""
    d = np.diff(np.sort(v))
    d = d[d != 0]
    return float(np.sum(np.log(np.abs(d))) / (len(v) - 1) + digamma(len(v)) - digamma(1))


def igci_ref(x, y):
    """IGCI, entropy estimator with a Gaussian reference measure (Janzing et al. 2012, Artif. Intell. 182-183,
    with Daniusis et al. 2010). Standardise each variable (ddof 0, as cdt's StandardScaler,
    IGCI.py:142), then C_{x->y} = H(y) - H(x), and x -> y is inferred when C_{x->y} < 0.
    Returns the antisymmetric score H(x) - H(y) = -C_{x->y}, which is cdt's predict_proba (IGCI.py:141, 148-151) and pyspi's
    igci value. Positive means x -> y."""
    z = lambda v: (v - v.mean()) / v.std()
    return _spacing_entropy(z(np.asarray(x, float).ravel())) - _spacing_entropy(z(np.asarray(y, float).ravel()))


# -------------------------------------------------------------------------- selftest
def selftest():
    import warnings
    warnings.filterwarnings("ignore")
    sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks")
    import make_data
    import dcor
    from dtaidistance import dtw as tdtw
    import ot
    res = []

    def check(label, ok, detail):
        res.append(bool(ok))
        print(f"{'PASS' if ok else 'FAIL'}  {label}: {detail}")

    rng = np.random.default_rng(7)
    # (1) dcorr
    nd = make_data.load("nonlinear_dependence", 4096)["x"]
    indep = [(0, 2), (0, 3), (1, 2), (1, 3)]
    d01 = dcorr(nd[0], nd[1])
    din = [dcorr(nd[a], nd[b])["dcor2"] for a, b in indep]
    check("dcorr U-dCor x^2 pair > 0.3 (dCor^2 ~0.23)", d01["dcor"] > 0.3, f"dCor {d01['dcor']:.4f}, dCor^2 {d01['dcor2']:.4f}")
    check("dcorr U-dCor^2 independent pairs < 0.05", max(np.abs(din)) < 0.05, f"max |.| = {max(np.abs(din)):.2e}")
    b01 = dcorr(nd[0], nd[1], biased=True)
    check("dcorr biased dCor x^2 pair > 0.3", b01["dcor"] > 0.3, f"{b01['dcor']:.4f}")
    e1 = abs(b01["dcor2"] - dcor.distance_correlation_sqr(nd[0], nd[1]))
    e2 = abs(d01["dcor2"] - dcor.u_distance_correlation_sqr(nd[0], nd[1]))
    check("dcorr vs dcor package (V and U, T=4096) [2nd opinion]", max(e1, e2) < 1e-10, f"{e1:.1e}, {e2:.1e}")
    check("hyppo convention: biased value is sqrt(dcor2)", abs(b01["hyppo"] - np.sqrt(b01["dcor2"])) < 1e-15, "ok")
    # (2) HSIC
    h01 = hsic_biased(nd[0], nd[1])
    hin = [hsic_biased(nd[a], nd[b])["normalised"] for a, b in indep]
    check("hsic normalised x^2 pair > 0.3", h01["normalised"] > 0.3, f"{h01['normalised']:.4f}")
    check("hsic normalised independent pairs < 0.05", max(hin) < 0.05, f"max = {max(hin):.2e}")
    rep = [hyppo_hsic_replica(nd[0], nd[1]), max(abs(hyppo_hsic_replica(nd[a], nd[b])) for a, b in indep)]
    check("hyppo_hsic_replica: x^2 > 0.3, independent < 0.05", rep[0] > 0.3 and rep[1] < 0.05, f"{rep[0]:.4f}, {rep[1]:.2e}")
    a = rng.standard_normal(64)
    check("hsic analytic: normalised hsic(x, x) = 1", abs(hsic_biased(a, a)["normalised"] - 1) < 1e-12, "ok")
    # (3) HHG
    s = make_data.load("nonlinear_dependence", 256)["x"][:, :128]
    t1, t2, t0 = hhg(s[0], s[1]), hhg(s[1], s[0]), hhg(s[0], s[2])
    check("hhg symmetric in (x, y)", abs(t1 - t2) < 1e-9 * t1, f"{t1:.6g} vs {t2:.6g}")
    check("hhg dependent >> independent (T=128)", t1 > 0 and t1 > 3 * t0, f"{t1:.4g} vs {t0:.4g}")
    # DcorrX
    dn = make_data.load("delayed_noise", 256)["x"]
    sm, terms, lag = dcorrx_mehta(dn[1], dn[0], 3)
    sh = hyppo_dcorrx_replica(dn[1], dn[0], 3)[0]
    check("dcorrx_mehta finds the delay-1 lag (x1 lags x0)", lag == 1 and terms[1] > 0.5,
          f"opt_lag={lag}, term={terms[1]:.3f}; hyppo replica stat {sh:.4f} vs Mehta {sm:.4f}")
    # (4) DTW vs dtaidistance
    u, v = dn[0], dn[3]
    e_unc = abs(dtw_dp(u, v) - tdtw.distance(u, v, use_c=False))
    e_sc = abs(dtw_dp(u, v, "sakoe_chiba", 1) - tdtw.distance(u, v, window=2, use_c=False))
    e_sc0 = abs(dtw_dp(u, v, "sakoe_chiba", 0) - np.linalg.norm(u - v))
    check("dtw_dp vs dtaidistance unconstrained, T=256 [2nd opinion]", e_unc < 1e-10, f"{e_unc:.1e}")
    check("dtw_dp sakoe_chiba r=1 vs dtaidistance window=2 [2nd opinion]", e_sc < 1e-10, f"{e_sc:.1e}")
    it = dtw_dp(u, v, "itakura")
    check("dtw: r=0 band = Euclidean; unconstrained <= itakura", e_sc0 < 1e-10 and dtw_dp(u, v) <= it, f"{e_sc0:.1e}")
    check("itakura mask: tslearn docstring example (_masks.py:181-186)",
          np.array_equal(itakura_mask(6, 6, 3).astype(int).sum(0), [1, 3, 4, 4, 3, 1]), "max_slope=3 column counts")
    check("abs-cost 1978 form: x vs shifted copy", abs(dtw_dp([0, 1, 2, 3], [0, 0, 1, 2, 3], squared_cost=False)) < 1e-15, "0")
    # (5) LCSS and soft-DTW
    check("lcss(x, x) = 1; tslearn doc examples 1.0 and 2/3", lcss_dp(u, u) == 1.0 == lcss_dp(u, u, constraint="itakura")
          and lcss_dp([1, 2, 3], [1., 2., 2., 4., 7.]) == 1.0 and abs(lcss_dp([1, 2, 3], [-2., 5., 7.], 3) - 2 / 3) < 1e-15, "ok")
    sx = soft_dtw_dp(u[:64], u[:64])
    check("soft_dtw(x, x) < 0 for gamma=1 (not a divergence)", sx < 0, f"{sx:.4f}")
    g = 1e-3
    s_g, d2 = soft_dtw_dp(u[:64], v[:64], g), dtw_dp(u[:64], v[:64]) ** 2
    check("soft_dtw gamma->0 within analytic bound of dtw^2", d2 - g * np.log(3) * 127 <= s_g <= d2 + 1e-12,
          f"{s_g:.6f} vs {d2:.6f}")
    z0 = rng.standard_normal(24); Xs = rng.standard_normal((2, 24))
    f0, g0 = soft_dtw_barycenter_objective(z0, Xs)
    fd = np.array([(soft_dtw_barycenter_objective(z0 + 1e-6 * e, Xs)[0] - soft_dtw_barycenter_objective(z0 - 1e-6 * e, Xs)[0]) / 2e-6
                   for e in np.eye(24)])
    check("soft-DTW barycenter gradient vs finite differences", np.max(np.abs(fd - g0)) < 1e-5 * max(1, np.abs(g0).max()),
          f"max err {np.max(np.abs(fd - g0)):.1e}")
    # (6) DBA
    z, costs = dba(dn[[0, 3], :128])
    check("dba cost non-increasing", all(np.diff(costs) <= 1e-12), f"{len(costs)} iters, {costs[0]:.3f} -> {costs[-1]:.3f}")
    check("euclidean_barycenter = mean", np.allclose(euclidean_barycenter(dn[:2]), dn[:2].mean(0)), "ok")
    # GWtau
    gx, gy = rng.standard_normal(50), rng.standard_normal(80)
    ra, rb = root_arc_lengths(gx), root_arc_lengths(gy)
    e = abs(wasserstein2_1d(ra, rb) - np.sqrt(ot.wasserstein_1d(ra, rb, p=2)))
    check("W2 unequal sizes vs ot.wasserstein_1d(p=2) [2nd opinion]", e < 1e-10, f"{e:.1e}")
    r1, r2 = gwtau(u, v), gwtau(u, v, include_root=True)
    desc = np.sqrt(np.mean((np.sort(root_arc_lengths(u))[::-1] - np.sort(root_arc_lengths(v))[::-1]) ** 2))
    check("gwtau = pyspi descending-sort RMS; root factor sqrt((n-1)/n)",
          abs(r1 - desc) < 1e-12 and abs(r2 - r1 * np.sqrt(255 / 256)) < 1e-12, f"{r1:.5f}")
    # (7) CCM
    lm = make_data.load("logistic_maps", 1024)["x"]
    xy, yx = simplex_crossmap(lm[0], lm[1], 2), simplex_crossmap(lm[1], lm[0], 2)
    check("ccm: x xmap y (y causes x) exceeds y xmap x by > 0.1, T=1024, E=2", xy - yx > 0.1, f"{xy:.3f} vs {yx:.3f}")
    curve = ccm_skill_curve(lm[0], lm[1], 2, [20, 100, 500], n_samples=10)
    check("ccm skill rises with library size", curve[-1] > curve[0], np.array2string(curve, precision=3))
    # (8) causal direction on the anm dataset (x0 -> x1 cubic, x2 -> x3 tanh)
    an = make_data.load("anm", 1024)["x"]
    zs = lambda q: (q - q.mean()) / q.std(ddof=1)
    for c, ef in [(0, 1), (2, 3)]:
        X, Y = zs(an[c]), zs(an[ef])
        r_f, r_b = reci_ref(X, Y), reci_ref(Y, X)
        ig, cd = igci_ref(X, Y), cds_ref(Y, X) - cds_ref(X, Y)
        print(f"INFO  pair {c}->{ef}: reci fwd {r_f:.4f} bwd {r_b:.4f}; igci {ig:+.4f}; cds(y,x)-cds(x,y) {cd:+.4f}")
        check(f"cds picks x{c} -> x{ef}", cd > 0, f"{cd:+.4f}")
        if c == 0:
            check("reci picks x0 -> x1 (cubic)", r_f < r_b, f"{r_f:.4f} < {r_b:.4f}")
    print("INFO  method limits (not kernel failures): igci (Gaussian ref) is wrong-signed on the noisy cubic pair;"
          " reci is a near-tie on the tanh pair")
    check("igci antisymmetric", abs(igci_ref(an[0], an[1]) + igci_ref(an[1], an[0])) < 1e-12, "exact")
    xu = rng.uniform(-1, 1, 5000)
    check("igci noiseless y = x^3, x uniform: positive (x -> y)", igci_ref(xu, xu ** 3) > 0, f"{igci_ref(xu, xu ** 3):+.4f}")
    hn = _spacing_entropy(rng.standard_normal(200000))      # estimator sd ~ sqrt(pi^2/6/n) ~ 0.003
    check("spacing entropy of N(0,1) ~ 0.5 log(2 pi e), n=2e5", abs(hn - 0.5 * np.log(2 * np.pi * np.e)) < 0.015, f"{hn:.4f}")
    Xa, Ya = zs(an[0][:300]), zs(an[1][:300])
    af, ab = anm_replica(Xa, Ya, 1.0, 0.5, 0.1), anm_replica(Ya, Xa, 1.0, 0.5, 0.1)
    check("anm Hoyer form (fixed GP l=0.5, alpha=0.1, T=300) lower in causal direction", af < ab, f"{af:.4f} < {ab:.4f}")
    th = gp_fit_hyperparameters(Xa, Ya)
    print(f"INFO  fitted GP (sklearn-default bounds, alpha=1e-10): constant={th[0]:.4g}, length_scale={th[1]:.3g}")
    p, q = rng.standard_normal((2, 150)); q = q + p ** 2
    sq = lambda w: np.median(_pdist(w)[np.triu_indices(150, 1)] ** 2)
    e = abs(cdt_fast_hsic_gamma(p, q) - 150 * hsic_biased(p, q, gamma=(1 / sq(p), 1 / sq(q)))["hsic"])
    check("cdt hsic replica = m * Gretton HSIC_b at deg^2 = median/2", e < 1e-12, f"{e:.1e}")
    print(f"{sum(res)}/{len(res)} checks passed")
    return all(res)


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(0 if selftest() else 1)
