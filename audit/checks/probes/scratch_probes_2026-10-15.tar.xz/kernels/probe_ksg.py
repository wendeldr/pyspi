import sys; sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np, _kernels_infotheory as K
from scipy.special import digamma
rng=np.random.default_rng(3)
for W in (0,3):
    x=rng.standard_normal((300,1)); y=0.6*x+rng.standard_normal((300,1)); y=np.round(y,1)  # ties
    xs,ys=K.zscore_jidt(x),K.zscore_jidt(y); N=300; k=4
    J=np.hstack([xs,ys]); t=np.arange(N)
    Dj=np.max(np.abs(J[:,None]-J[None]),axis=2); Dx=np.abs(xs-xs.T); Dy=np.abs(ys-ys.T)
    excl=np.abs(t[:,None]-t[None])<=W
    Dj2=np.where(excl,np.inf,Dj); eps=np.sort(Dj2,axis=1)[:,k-1]
    nx=((Dx<eps[:,None])&~excl).sum(1); ny=((Dy<eps[:,None])&~excl).sum(1)
    brute=digamma(k)-np.mean(digamma(nx+1)+digamma(ny+1))+digamma(N)
    print(W, brute, K.mi_ksg1(x,y,k=4,theiler=W), abs(brute-K.mi_ksg1(x,y,k=4,theiler=W)))
