# Throwaway probe (pyspi .venv): compare _kernels_distance replicas with the libraries they mirror.
import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs"); sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks")
import numpy as np, _kernels_distance as k, make_data
from hyppo.independence import Dcorr, Hsic, HHG
from hyppo.time_series import DcorrX
import tslearn.metrics as tm
from tslearn.metrics import itakura_mask, sakoe_chiba_mask
from tslearn.barycenters import dtw_barycenter_averaging, softdtw_barycenter
from cdt.causality.pairwise import CDS, RECI, IGCI
from cdt.causality.pairwise.ANM import normalized_hsic
from sklearn.gaussian_process import GaussianProcessRegressor
r = np.random.default_rng(0)
x = make_data.load("nonlinear_dependence", 256)["x"]; z = lambda v: (v - v.mean()) / v.std(ddof=1)
a, b = z(x[0]).reshape(-1, 1), z(x[1]).reshape(-1, 1)
for bias in (False, True):
    print("dcorr", bias, Dcorr(bias=bias).statistic(a, b) - k.dcorr(a, b, bias, sklearn_arith=True)["hyppo"], Dcorr(bias=bias).statistic(a, b) - k.dcorr(a, b, bias)["hyppo"])
    print("hsic ", bias, Hsic(bias=bias).statistic(a, b) - k.hyppo_hsic_replica(a, b, bias))
s = x[:, :100]
print("hhg", HHG().statistic(s[0].reshape(-1,1), s[1].reshape(-1,1)) - k.hhg(s[0], s[1]))
for L in (1, 3):
    print("dcorrx", L, DcorrX(max_lag=L).statistic(a, b)[0] - k.hyppo_dcorrx_replica(a, b, L)[0], k.dcorrx_mehta(a, b, L)[0])
for (n1, n2, sl) in [(6,6,3), (50,50,2), (40,60,2), (64,64,1.5), (30,20,3)]:
    try: print("itakura", n1, n2, sl, np.array_equal(itakura_mask(n1, n2, sl), k.itakura_mask(n1, n2, sl)))
    except Exception as e: print("itakura", n1, n2, sl, "err", e)
for (n1, n2, rr) in [(10,10,1),(10,14,2),(14,10,3)]:
    print("sakoe", np.array_equal(sakoe_chiba_mask(n1, n2, rr), k.sakoe_chiba_mask(n1, n2, rr)))
dn = make_data.load("delayed_noise", 256)["x"]; u, v = z(dn[0]), z(dn[3])
for c in (None, "sakoe_chiba", "itakura"):
    print("dtw", c, tm.dtw(u, v, global_constraint=c) - k.dtw_dp(u, v, c), "lcss", tm.lcss(u, v, global_constraint=c) - k.lcss_dp(u, v, constraint=c))
print("softdtw", tm.soft_dtw(u, v) - k.soft_dtw_dp(u, v))
X2 = np.stack([u[:128], v[:128]])
bc = dtw_barycenter_averaging(X2).ravel(); mine = k.dba(X2)[0]
print("dba max diff", np.abs(bc - mine).max())
sb = softdtw_barycenter(X2).ravel(); f, g = k.soft_dtw_barycenter_objective(sb, X2)
print("softdtw bary grad norm at tslearn optimum", np.abs(g).max(), "obj", f)
an = make_data.load("anm", 1024)["x"][:, :400]; p, q = z(an[0]).reshape(-1,1), z(an[1]).reshape(-1,1)
print("cds", CDS().cds_score(p, q) - k.cds_ref(p, q), CDS().cds_score(q, p) - k.cds_ref(q, p))
print("reci", RECI().b_fit_score(p, q) - k.reci_ref(p, q))
print("igci", IGCI().predict_proba((p, q)) - k.igci_ref(p, q))
gp = GaussianProcessRegressor(random_state=42).fit(p, q)
th = np.exp(gp.kernel_.theta); print("sk theta", th, "mine", k.gp_fit_hyperparameters(p, q))
pyspi_anm = normalized_hsic(gp.predict(p).reshape(-1, 1) - q, p)
print("anm fixed-theta", pyspi_anm - k.anm_replica(p, q, th[0], th[1]), "fitted", pyspi_anm - k.anm_replica(p, q))
