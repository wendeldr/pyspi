import sys, warnings; warnings.filterwarnings('ignore')
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
import numpy as np, _kernels_distance as k, make_data
from cdt.causality.pairwise import CDS, RECI, IGCI
from cdt.causality.pairwise.ANM import normalized_hsic
from sklearn.gaussian_process import GaussianProcessRegressor
z = lambda v: (v - v.mean()) / v.std(ddof=1)
an = make_data.load("anm", 1024)["x"][:, :400]; p, q = z(an[0]).reshape(-1,1), z(an[1]).reshape(-1,1)
print("cds", CDS().cds_score(p, q) - k.cds_ref(p, q), CDS().cds_score(q, p) - k.cds_ref(q, p))
print("reci", RECI().b_fit_score(p, q) - k.reci_ref(p, q))
print("igci", IGCI().predict_proba((p, q)) - k.igci_ref(p, q))
gp = GaussianProcessRegressor(random_state=42).fit(p, q)
th = np.exp(gp.kernel_.theta); print("sk theta", th, "mine", k.gp_fit_hyperparameters(p, q))
pyspi_anm = normalized_hsic(gp.predict(p).reshape(-1, 1) - q, p)
print("anm fixed-theta", pyspi_anm - k.anm_replica(p, q, th[0], th[1]), "fitted", pyspi_anm - k.anm_replica(p, q))
