import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import numpy as np, make_data as md
import _kernels_spectral as K
import spectral_connectivity as sc
from mne.time_frequency.tfr import morlet, cwt
def cmp(name, a, b):
    a, b = np.asarray(a), np.asarray(b); off = ~np.eye(a.shape[-1], dtype=bool)
    a, b = a[..., off], b[..., off]; m = np.isfinite(a) & np.isfinite(b)
    bad = np.nonzero(~np.isclose(a, b, rtol=1e-8, atol=1e-10, equal_nan=True))
    print(f"{name:10s} offdiag max|diff| {np.abs(a[m]-b[m]).max():.2e} nan-eq {np.array_equal(np.isnan(a), np.isnan(b))} bad freq idx {np.unique(bad[0])[:8]}")
for nm, T in (("var2_bivariate", 1000), ("delayed_noise", 1021)):
    x = md.load(nm, 4096)["x"][:, :T]
    m = sc.Multitaper(x.T, sampling_frequency=1); c = sc.Connectivity.from_multitaper(m)
    co, fr = K.multitaper_fft(x); cn = K.nonneg(co, 1)
    cmp("PLI", c.phase_lag_index()[0], K.phase_lag_index(cn))
    cmp("dPLI2", c.debiased_squared_phase_lag_index()[0], K.debiased_squared_pli(cn))
    cmp("dwPLI2", c.debiased_squared_weighted_phase_lag_index()[0], K.debiased_squared_wpli(cn))
    print(" lib PLI diag sample", c.phase_lag_index()[0][:3, 0, 0], "lib dwPLI2 DC", c.debiased_squared_weighted_phase_lag_index()[0][0], "kernel", K.debiased_squared_wpli(cn)[0])
    # group delay without the library significance machinery: replicate slope with all bins
    fn = K.nonneg(fr); S = K.cross_spectral_matrix(co)
    Cn = K.nonneg(K.coherency(S)); mk = K.band_mask(fn, 0, 0.5, inclusive=False)
    print(" kernel group delay [0,k]", [round(float(K.group_delay_fit(np.angle(Cn[:, 0, k]), fn, mk)["delay"]), 4) for k in range(1, x.shape[0])])
for f, nc in ((0.2, 0.2/7), (0.33, 7.0), (0.5, 7.0)):
    a, b = morlet(1.0, [f], n_cycles=nc, zero_mean=True)[0], K.morlet_wavelet(f, nc)
    print(f"morlet f={f} nc={nc:.3g} len {a.size}/{b.size} max|diff| {np.abs(a-b).max():.1e}")
x = md.load("delayed_noise", 256)["x"]; fq = np.linspace(0.2, 0.5, 7)
a, b = cwt(x, morlet(1.0, fq, 7.0, zero_mean=True), use_fft=True, mode="same"), K.cwt_morlet(x, fq, 7.0)
print("cwt n_cycles=7", a.shape, b.shape, np.abs(a-b).max())
