import numpy as np, scipy.signal.windows as w
from spectral_connectivity.transforms import dpss_windows, Multitaper
from spectral_connectivity import Connectivity
for T in (64, 256, 1024):
    tl, el = dpss_windows(T, 3, 5, is_low_bias=False)
    ts, es = w.dpss(T, 3, Kmax=5, return_ratios=True)
    print(T, np.abs(tl-ts).max(), np.abs(el-es).max(), el)
