import sys, warnings, numpy as np
warnings.simplefilter("ignore")
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import make_data as md, _kernels_basic_misc as K
from sklearn import covariance as cv, linear_model as lm
from sklearn.gaussian_process import GaussianProcessRegressor, kernels as gk
from statsmodels.tsa.vector_ar.vecm import coint_johansen
from statsmodels.tsa.stattools import coint
from scipy import stats, signal
from scipy.spatial.distance import cdist
import mne_connectivity as mnec
from pyspi.lib.ids.dependence import compute_IDS
z1 = lambda v: (v - v.mean()) / v.std(ddof=1)
X = md.load("bivariate_gaussian", 256)["x"]
print("LW", abs(K.ledoit_wolf(X)[0]-cv.ledoit_wolf(X.T)[0]).max(), "OAS sk", abs(K.oas(X,False)[0]-cv.oas(X.T)[0]).max(), "OAS paper-vs-sk", abs(K.oas(X)[1]-cv.oas(X.T)[1]))
print("prec", abs(K.precision(K.empirical_cov(X))-cv.EmpiricalCovariance().fit(X.T).precision_).max(), "shrunk", abs(K.shrunk_cov(X)[0]-cv.ShrunkCovariance().fit(X.T).covariance_).max())
gl = cv.GraphicalLasso(alpha=0.05, tol=1e-8, max_iter=1000).fit(md.load("sparse_precision",1024)["x"].T)
print("glasso KKT of sklearn", K.glasso_kkt_residual(gl.covariance_ if False else K.empirical_cov(md.load("sparse_precision",1024)["x"]), gl.precision_, 0.05))
dn = md.load("delayed_noise", 256)["x"]; a,b = z1(dn[0]), z1(dn[2])
r = signal.correlate(a,b,'full')/a.std()/b.std()/255; rep = K.pyspi_xcorr_replica(a,b)
print("xcorr replica", abs(rep['r_window']-r[256-64:256+64]).max())
from pyspi.statistics.basic import CrossCorrelation
from pyspi.data import Data
d = Data(dn[[0,2]], dim_order='ps')
for st in ('max','mean'):
  v = CrossCorrelation(statistic=st, sigonly=True).bivariate(d,i=0,j=1); print("pyspi xcorr", st, v, rep[st+'_sig'])
rng=np.random.default_rng(0); u=rng.integers(0,5,50).astype(float); v=rng.integers(0,3,50).astype(float)
print("kendall", K.kendall_tau_b(u,v)-stats.kendalltau(u,v).statistic, "spearman", K.spearman(u,v)-stats.spearmanr(u,v).statistic)
for m in ['euclidean','cityblock','cosine','chebyshev','canberra','braycurtis']:
  print(m, abs(K.pdist_metric(X,m)-cdist(X,X,m)).max())
ci = md.load("cointegrated", 1024)["x"]
for do in (-1,0,1):
  for k in (0,1,10):
    sm = coint_johansen(ci[[0,1]].T, do, k); mine = K.johansen(ci[[0,1]], do, k)
    sm2 = coint_johansen(ci[[2,3]].T, do, k); mine2 = K.johansen(ci[[2,3]], do, k)
    print("joh", do, k, abs(sm.trace_stat-mine['trace_stat']).max(), abs(sm.max_eig_stat-mine['max_eig_stat']).max(), abs(sm2.trace_stat-mine2['trace_stat']).max())
for tr in ('c','ct','n'):
  for al in ('aic','bic',None):
    for pair in ((0,1),(2,3),(1,0)):
      print("eg", tr, al, pair, coint(ci[pair[0]], ci[pair[1]], trend=tr, autolag=al, maxlag=10)[0]- K.engle_granger_tstat(ci[pair[0]], ci[pair[1]], tr, 10, al))
g = md.load("bivariate_gaussian", 1024)["x"]; u, v = z1(g[2]), z1(g[3]); xx = u[:,None]
mse = lambda m: np.mean((m.fit(xx,v).predict(xx)-v)**2)
print("ridge", mse(lm.Ridge())-K.ridge_mse(u,v), "lasso", mse(lm.Lasso())-K.lasso_1d_mse(u,v), "lasso .3", mse(lm.Lasso(alpha=.3, tol=1e-12))-K.lasso_1d_mse(u,v,.3),
      "EN", mse(lm.ElasticNet(alpha=.2, tol=1e-12))-K.elasticnet_1d_mse(u,v,.2), "BR", mse(lm.BayesianRidge())-K.bayesian_ridge_mse(u,v))
for T in (64,256):
  an = md.load("anm", T)["x"]; uu, vv = z1(an[0]), z1(an[1])
  print("BR anm", T, mse.__call__ if False else np.mean((lm.BayesianRidge().fit(uu[:,None],vv).predict(uu[:,None])-vv)**2)-K.bayesian_ridge_mse(uu,vv))
se = md.load("shared_envelope", 1024)["x"]
for orth in (False,'pairwise'):
  for log in (False,True):
    for ab in (False,True):
      mc = np.squeeze(mnec.envelope_correlation(se[None], orthogonalize=orth, log=log, absolute=ab).combine("mean").get_data(output="dense"))
      mine = K.envelope_correlation(se, bool(orth), log, ab, mne_order=True); mine0 = K.envelope_correlation(se, bool(orth), log, ab)
      off = ~np.eye(4,dtype=bool)
      print("env", orth, log, ab, abs(mc-mine)[off].max(), "def-order vs mne", abs(mc-mine0)[off].max(), "mne C02", mc[0,2])
nl = md.load("nonlinear_dependence", 256)["x"]; Z = np.stack([z1(v) for v in nl])
for p in ('max',1,2): print("ids", p, abs(compute_IDS(Z.T, p_norm=p)-K.ids(Z, pnorm=p)).max())
an = md.load("anm", 64)["x"]; gx, gy = z1(an[0]), z1(an[1])
for kern in ('RBF','DotProduct'):
  gp = GaussianProcessRegressor(kernel=gk.ConstantKernel()+gk.WhiteKernel()+getattr(gk,kern)()).fit(gx[:,None], gy)
  th = np.exp(gp.kernel_.theta); kp = K._gp_params(kern, gp.kernel_.theta)
  lml, gr = K.gp_log_marginal_likelihood(gx, gy, kp); sl, sg = gp.log_marginal_likelihood(gp.kernel_.theta, eval_gradient=True)
  m = K.gp_posterior_mean(gx, gy, kp)
  kp2, l2, g2 = K.gp_fit(gx, gy, kern)
  print("gp", kern, th, "lml", lml-sl, "grad", abs(gr-sg).max(), "mean", abs(m-gp.predict(gx[:,None])).max(), "myfit lml", l2, "sk lml", sl)
