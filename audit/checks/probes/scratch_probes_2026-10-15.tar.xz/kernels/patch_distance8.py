import re
p = "/media/dan/Data/git/pyspi/audit/checks/refs/_kernels_distance.py"
s = open(p).read()
def doc(name, new):
    global s
    i = s.index(f"\ndef {name}(")
    a = s.index('"""', i)
    b = s.index('"""', a + 3) + 3
    s = s[:a] + '"""' + new.strip("\n") + '"""' + s[b:]
def rep(old, new):
    global s
    assert s.count(old) == 1, (s.count(old), old[:80])
    s = s.replace(old, new)

rep('''    d = -2 * (x @ x.T)
    d += xx
    d += xx.T
    np.maximum(d, 0, out=d)
    np.fill_diagonal(d, 0)
    return d''', '''    d = -2 * (x @ x.T); d += xx; d += xx.T
    np.maximum(d, 0, out=d); np.fill_diagonal(d, 0)
    return d''')
doc("dcorr_from_dist", '''Squared distance correlation from (n, n) distance matrices. Returns (dcor2, dcov2_xy, dvar2_x, dvar2_y).
    biased=True: V-statistic (Szekely, Rizzo & Bakirov 2007, Ann. Stat. 35, Sec. 2): A = double-centred a_ij,
        dCov_n^2 = (1/n^2) sum A_ij B_ij, dCor_n^2 = dCov^2(x,y) / sqrt(dVar^2 x dVar^2 y).
    biased=False: bias-corrected dCor^2 (Szekely & Rizzo 2014, Ann. Stat. 42, Sec. 3, U-centring): A~_ij = a_ij
        - a_i./(n-2) - a_.j/(n-2) + a_../((n-1)(n-2)), A~_ii = 0, (A~.B~) = sum A~B~ / (n(n-3)); it can be negative.
    dcor2 is 0 when a variance is <= 0 and is formed from the unscaled sums, as hyppo's _dcorr (only_dcov=False,
    dcorr.py:402, 432-445). biased=False, n = 3: A~ is identically 0 (A~_12 = a12 - (a12+a13) - (a12+a23)
    + (a12+a13+a23)), so dcor2 = 0 and the covariances are NaN; hyppo returns a rounding-noise ratio there
    (scratchpad probe kernels/probe_edges_fix.py). biased=False with n < 3 raises ValueError.
    ''')
doc("hyppo_dcorr_from_dist", '''What hyppo's Dcorr.statistic returns for precomputed distances (mirrored, not imported).
    hyppo/independence/dcorr.py:417-447 (_dcorr): 0 if varx<=0, vary<=0 or (biased and cov<=0), else cov/sqrt(varx*vary),
    square-rooted when biased. So hyppo returns dCor (NOT squared) for bias=True and the signed bias-corrected dCor^2
    for bias=False. Centring: dcorr.py:262-281. The non-fast path is always used (is_fast is set only in .test(), :237).''')
doc("dcorr", '''Distance correlation of x (n,)|(n,p) and y (n,)|(n,q), Euclidean distances (Szekely, Rizzo & Bakirov 2007
    biased V-statistic; Szekely & Rizzo 2014 U-centred). Returns dict(dcor2 = dCor^2, dcor = sqrt(max(dcor2, 0)),
    hyppo = the value pyspi stores: dCor if biased else the signed dCor^2, see hyppo_dcorr_from_dist).
    sklearn_arith=True builds distances with sklearn's dot-product formula, as hyppo does (hyppo/tools/common.py:497-499
    -> pairwise_distances); the difference is at rounding level.''')
doc("median_gamma", '''Gaussian-kernel gamma by the median heuristic, as hyppo computes it (hyppo/tools/common.py:321-333):
    med = median of the off-diagonal Euclidean distances of x (both triangles; the stride trick at common.py:326-330
    visits every off-diagonal entry once), med = 1 if it is 0, gamma = 1/(2 med^2). hyppo derives gamma from x ONLY
    and reuses it for the y kernel (common.py:342-343).''')
doc("hsic_biased", '''Biased empirical HSIC with Gaussian kernels, HSIC_b = tr(K H L H) / n^2: the 1/n^2 form of Gretton, Fukumizu,
    Teo, Song, Schoelkopf & Smola 2008 (NIPS 20, 'A kernel statistical test of independence'). Gretton et al. 2005
    (ALT) eq. 9 scales by (n-1)^-2 instead; the factor cancels in 'normalised'. H = I - 11^T/n, K_ij = exp(-gamma |x_i - x_j|^2).
    gamma=None uses median_gamma(x) for BOTH kernels, mirroring hyppo (common.py:321-343); a pair (gamma_x, gamma_y) is allowed.
    Returns dict(hsic, hsic_xx, hsic_yy, normalised = hsic / sqrt(hsic_xx * hsic_yy), gamma_x, gamma_y). normalised is 0
    when hsic_xx * hsic_yy <= 0 (a constant series), as hyppo returns 0 for a zero variance (dcorr.py:438-439).''')
doc("hyppo_hsic_replica", '''Re-creates hyppo's Hsic.statistic, which pyspi's hsic / hsic_biased call (hyppo/independence/hsic.py:117-122):
    Gaussian K, L with the x-derived median gamma (common.py:321-343, sklearn arithmetic), D_x = 1 - K/max(K),
    D_y = 1 - L/max(L), then Dcorr(compute_distance=None, bias). So it is dCor (biased) or the signed U-dCor^2 of the
    kernel-induced distances (hyppo_dcorr_from_dist), NOT the Gretton tr(KHLH)/n^2.''')
doc("hhg", '''Heller, Heller & Gorfine 2013 (Biometrika 100, 503-510) sum-of-chi-square statistic T = sum_{i != j} S(i,j),
    S(i,j) = (n-2) (A12 A21 - A11 A22)^2 / (A1. A2. A.1 A.2), A = 2x2 table over k not in {i,j} of
    [d(x_i,x_k) <= d(x_i,x_j)] x [d(y_i,y_k) <= d(y_i,y_j)]. A zero margin contributes 0 (hyppo/independence/hhg.py:293-295).
    Swapping x and y transposes every table, so T(x,y) = T(y,x): pyspi labels hhg 'Directed' but it is symmetric.
    Cost O(n^3); fine for n <= ~300.''')
doc("dcorrx_mehta", '''Cross-distance correlation (Mehta et al. 2019, arXiv:1907.02088): DcorrX = sum_{j=0}^{M} ((n-j)/n) Dcorr(x[j:n], y[0:n-j]),
    with Dcorr = U-centred dCor^2 (hyppo's default bias=False) on distances between the SERIES SAMPLES of each slice,
    so D_x^{(j)} = D_x[j:, j:]. Lag j pairs x_{t+j} with y_t (y leads); in pyspi x = process i, y = process j.
    Returns (stat, list of weighted per-lag terms, opt_lag = argmax of the terms).''')
doc("dtw_dp", '''Dynamic time warping by O(nm) dynamic programming (Sakoe & Chiba 1978, IEEE TASSP 26, 43-49).
    squared_cost=True (tslearn form, pyspi's dtw*): sqrt(min over paths of sum (x_i - y_j)^2), steps (1,0), (0,1), (1,1)
        of weight 1 (tslearn/metrics/_dtw.py:383-400), masks of tslearn/metrics/_masks.py; radius r = dtaidistance window r+1.
    squared_cost=False: the 1978 symmetric form with P = 0, g(i,j) = min(g(i-1,j) + d, g(i-1,j-1) + 2d, g(i,j-1) + d),
        d = |x_i - y_j|, D = g(n,m)/(n+m), same masks.''')
doc("lcss_dp", '''LCSS similarity (Vlachos, Gunopulos & Kollios 2002, ICDE) with tslearn's conventions: a match is ||x_i - y_j|| <= eps
    (strict=True gives Vlachos' < eps), a masked cell holds 0, score L(n,m)/min(n,m) (tslearn/metrics/dtw_variants.py:2301-2310
    generic path, 2343-2345). For the Sakoe-Chiba band, 0 in masked cells equals Vlachos' delta-window rule.
    NOTE: the numpy path pyspi runs (dtw_variants.py:2259) gates cells with numpy.isfinite(bool mask), always True, so in
    tslearn 0.9.0 pyspi's lcss_constraint-* equal unconstrained lcss (audit/notes/dtw_family.md): use constraint=None.''')
doc("soft_dtw_dp", '''Soft-DTW value R[n,m] (Cuturi & Blondel 2017, Alg. 1); -> dtw^2 as gamma -> 0 (tslearn returns dtw^2 exactly at
    gamma == 0, softdtw_variants.py:627-628). For gamma > 0 softmin < min, so soft_dtw(x, x) < 0 (not a divergence), and
    dtw^2 - gamma*log(3)*(n+m-1) <= soft_dtw <= dtw^2. pyspi's softdtw* SPIs ignore the global_constraint
    (distance.py:205-208), so the constraint variants equal softdtw.''')
doc("dba", '''DTW barycenter averaging (Petitjean, Ketterlin & Gancarski 2011, Pattern Recogn. 44, 678-693) as pyspi calls it
    (tslearn dtw_barycenter_averaging, n_init=1, tslearn/barycenters/dba.py:700-737): init = pointwise mean (dba.py:23-25);
    each iteration aligns every series to the barycenter (dtw_path), cost = mean_k dtw_k^2 (uniform weights,
    dba.py:229-305), then sets each point to the mean of its associated points (dba.py:400-434); stop when
    |cost_prev - cost| < tol or the cost rises, returning the just-updated barycenter either way (dba.py:727-737).
    X (K, T). Returns (barycenter (T,), per-iteration costs of the pre-update barycenter).''')
doc("gwtau", '''GW-tau with p = 2 (Kravtsova et al. 2023, eqs. 5, 10; Prop. 1a): W2 between the root-distance distributions of
    the two series; pyspi docs: 'distances from the start of each time series to every point ... compared using the
    Wasserstein distance' (spi-descriptions/distance-similarity.md:164-180; no supplement.txt entry in section 1.2).
    pyspi (distance.py:279-315) sorts both vectors DESCENDING and takes sqrt(mean((a-b)^2)): for equal lengths the same
    monotone coupling, so equal to this W2. pyspi drops the root (include_root=False); the paper's uniform mass on all n
    points (include_root=True) changes the value, for equal lengths, by exactly sqrt((n-1)/n).''')
doc("ccm_skill_curve", '''CCM curve (Sugihara 2012, Fig. 3): mean simplex_crossmap(x, y) over n_samples libraries per size L. random=True
    draws L valid rows without replacement (pyEDM's default); numpy's RNG cannot reproduce pyEDM's
    std::default_random_engine(seed) draws, so only curve statistics are comparable. random=False uses the first L
    valid rows (contiguous). Returns (len(lib_sizes),).''')
doc("anm_replica", '''ANM fit score for x -> y (Hoyer et al. 2009, NIPS): GP-regress y = f(x) + n, then measure dependence between the
    residual and x (lower = x -> y more plausible). As pyspi runs it (pyspi/statistics/causal.py:18-29, patched anm_score)
    the z-scored inputs are not rescaled; residual = y_hat - y; score = normalized_hsic(residual, x) (ANM.py:106-111:
    z-score each with np.std ddof=0, then cdt_fast_hsic_gamma). constant/length_scale fix the GP (e.g. to a known sklearn
    fit); None fits them with gp_fit_hyperparameters, since sklearn OPTIMISES the default C()*RBF() (_gpr.py:249).
    With alpha=1e-10 the fit usually reaches length_scale ~ 1e-5..1e-4 (interpolation): the residual is ~1e-10 y, the
    z-scored score measures dependence between y and x (audit/notes/cdt_pairwise.md:65), and the RBF arithmetic matters
    (see _sqdiff_scaled).''')
doc("cds_ref", '''Conditional distribution similarity x -> y (Fonollosa 2016, arXiv:1601.06680, 'CDS'), mirroring cdt CDS.cds_score
    (CDS.py:143-195) for continuous y: discretise x; for each x-bin with more than minc points, centre y on the bin mean,
    scale by the GLOBAL std(y) (ddof 0), discretise into the 13 bins -6..6 and normalise to a pmf. Score = std of all
    entries of (pmf matrix - column mean); low (similar conditionals) favours x -> y. cdt's predict_proba =
    cds(y,x) - cds(x,y), so positive means x -> y.''')
open(p, "w").write(s)
print("ok")
