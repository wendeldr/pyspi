import sys, warnings, numpy as np, time
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
import pyspi.statistics.causal as C
from cdt.causality.pairwise.ANM import normalized_hsic
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel as CK
np.set_printoptions(precision=4, suppress=True)
for name,T in [('anm',64),('anm',1024),('iid_gaussian',256),('nonlinear_dependence',256),('bivariate_gaussian',1024)]:
    x = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{name}_T{T}.npz')['x']
    D = Data(x, dim_order='ps'); z = D.to_numpy()
    t=time.time(); A = C.AdditiveNoiseModel().multivariate(D); el=time.time()-t
    P=z.shape[0]
    H = np.full((P,P),np.nan)
    for i in range(P):
        for j in range(P):
            if i!=j: H[i,j]=normalized_hsic(z[j], z[i])
    print(f'== {name} T={T} time {el:.2f}s'); print('A anm\n',A); print('HSIC(y,x) directly\n',H)
    print('max |A-H|/H', np.nanmax(np.abs(A-H)/H))
    i,j=0,1
    gp = GaussianProcessRegressor(random_state=42).fit(z[i], z[j]); r = gp.predict(z[i]).reshape(-1,1)-z[j]
    c2 = gp.kernel_.k1.constant_value
    print('kernel', gp.kernel_, 'corr(r,y)', np.corrcoef(r.ravel(), z[j].ravel())[0,1], 'r/(-1e-10 y/c2) median', np.median(r.ravel()/(-1e-10*z[j].ravel()/c2)))
    # GP with noise kernel for comparison (Hoyer-style)
    gpn = GaussianProcessRegressor(kernel=CK()*RBF()+WhiteKernel(), random_state=42).fit(z[i], z[j]); rn = gpn.predict(z[i]).reshape(-1,1)-z[j]
    print('with WhiteKernel:', gpn.kernel_, 'resid std', rn.std(), 'score', normalized_hsic(rn, z[i]), 'rev', end=' ')
    gpn2 = GaussianProcessRegressor(kernel=CK()*RBF()+WhiteKernel(), random_state=42).fit(z[j], z[i]); rn2 = gpn2.predict(z[j]).reshape(-1,1)-z[i]
    print(normalized_hsic(rn2, z[j]))
