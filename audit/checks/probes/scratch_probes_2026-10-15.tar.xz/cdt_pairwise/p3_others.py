import sys, warnings, numpy as np
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
import pyspi.statistics.causal as C
from scipy.special import digamma
np.set_printoptions(precision=5, suppress=True)
def load(name,T):
    return np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{name}_T{T}.npz')['x']
# --- RECI from scratch
def reci_ref(x,y):
    x=x.ravel(); y=y.ravel()
    x=(x-x.min())/(x.max()-x.min()); y=(y-y.min())/(y.max()-y.min())
    X=np.c_[np.ones_like(x), x**3]; b,*_=np.linalg.lstsq(X,y,rcond=None)
    return np.mean((X@b-y)**2)
# --- IGCI from scratch
def H(v):
    v=v.ravel(); v=(v-v.mean())/v.std(); s=np.sort(v); d=np.diff(s); d=d[d!=0]
    return np.sum(np.log(np.abs(d)))/(len(v)-1)+digamma(len(v))-digamma(1)
# --- CDS from scratch
def disc(x, ff=2, md=3):
    x=(x-x.mean())/x.std(); xf=x[np.abs(x)<md]; x=(x-xf.mean())/xf.std()
    return np.clip(np.round(x*ff), -ff*md, ff*md)
def cds_ref(x,y,ff=2,md=3,minc=12):
    x=x.ravel(); y=y.ravel(); xd=disc(x,ff,md)
    rows=[]
    for a in np.unique(xd):
        m = xd==a
        if m.sum()>minc:
            yx=(y[m]-y[m].mean())/y.std(); yx=np.clip(np.round(yx*ff),-ff*md,ff*md)
            p=np.array([np.sum(yx==k) for k in range(-ff*md, ff*md+1)],float); rows.append(p/p.sum())
    if not rows: return 0.0
    P=np.array(rows); P=P-P.mean(0); return np.std(P)
for name,T in [('anm',64),('anm',256),('anm',1024),('nonlinear_dependence',256),('iid_gaussian',64),('delayed_noise',256)]:
    D=Data(load(name,T),dim_order='ps'); z=D.to_numpy(); P=z.shape[0]
    print(f'===== {name} T={T}')
    for cls,ref in [(C.RegressionErrorCausalInference,reci_ref),(C.InformationGeometricConditionalIndependence,lambda a,b:H(a)-H(b)),(C.ConditionalDistributionSimilarity,cds_ref)]:
        A=cls().multivariate(D)
        R=np.full((P,P),np.nan)
        for i in range(P):
            for j in range(P):
                if i!=j: R[i,j]=ref(z[i],z[j])
        print(cls.identifier, 'max abs diff vs from-scratch', np.nanmax(np.abs(A-R)), 'antisym max|A+A.T|', np.nanmax(np.abs(A+A.T)), 'min', np.nanmin(A), 'n zeros', np.sum(A==0))
        print(A)
