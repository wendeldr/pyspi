import sys, warnings, numpy as np
warnings.simplefilter('ignore')
sys.path.insert(0,'/media/dan/Data/git/pyspi')
import pyspi.statistics.causal as C
rng=np.random.default_rng(0)
for T in [256,1024,4096]:
    x=rng.uniform(0,1,T); y=x**3
    v=C.InformationGeometricConditionalIndependence().bivariate(x,y)
    vr=C.InformationGeometricConditionalIndependence().bivariate(y,x)
    print(T, 'A[x,y]=',v,'A[y,x]=',vr)
print('analytic -C^G =', -( np.log(3)-2 + np.log(1/np.sqrt(12)) - np.log(np.sqrt(1/7-1/16)) ))
# labels / sign
print(C.InformationGeometricConditionalIndependence().issigned() if hasattr(C.InformationGeometricConditionalIndependence(),'issigned') else 'no issigned', C.InformationGeometricConditionalIndependence.labels, C.AdditiveNoiseModel.labels)
