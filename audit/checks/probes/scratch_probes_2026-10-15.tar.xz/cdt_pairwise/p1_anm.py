import sys, warnings, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
import pyspi.statistics.causal as C
from cdt.causality.pairwise import ANM
from cdt.causality.pairwise import ANM as ANM2
import cdt.causality.pairwise.ANM as anmmod
from sklearn.gaussian_process import GaussianProcessRegressor
print("ANM.anm_score is patched:", ANM.anm_score is C.AdditiveNoiseModel.corrected_anm_score, ANM.anm_score.__qualname__)
d = np.load('/media/dan/Data/git/pyspi/audit/checks/data/anm_T256.npz')
x = d['x']; print('cause',d['cause'],'effect',d['effect'])
D = Data(x, dim_order='ps', normalise=True)
z = D.to_numpy(); print('z shape', z.shape, 'z[0] shape', z[0].shape)
spi = C.AdditiveNoiseModel()
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter('always')
    A = spi.multivariate(D)
    print('warnings:', set(str(ww.category.__name__)+': '+str(ww.message)[:120] for ww in w))
np.set_printoptions(precision=5, suppress=True)
print('A=\n', A)
# inspect GP fit for pair 0->1
for (i,j) in [(0,1),(1,0),(2,3),(3,2)]:
    xx, yy = z[i], z[j]
    gp = GaussianProcessRegressor(random_state=42).fit(xx, yy)
    yp = gp.predict(xx)
    r = yp.reshape(-1,1) - yy
    print(i,j,'kernel_', gp.kernel_, 'pred shape', yp.shape, 'resid std', r.std(), 'y std', yy.std(), 'R2', 1-r.var()/yy.var())
    # random_state effect
    gp2 = GaussianProcessRegressor(random_state=7).fit(xx, yy)
    print('   rs effect max diff', np.abs(gp2.predict(xx)-yp).max())
# direct manual HSIC
def hsic_manual(a,b,maxpnt=200):
    a=(a-a.mean())/a.std(); b=(b-b.mean())/b.std()
    m=len(a)
    if m>maxpnt:
        idx=np.floor(np.arange(0,m,(m-1)/(maxpnt-1))).astype(int); a=a[idx]; b=b[idx]; m=len(a)
    def K(v):
        v=v.reshape(-1,1); D2=(v-v.T)**2
        iu=np.triu_indices(m,1); dd=D2[iu]; s=np.sqrt(0.5*np.median(dd[dd>0]))
        return np.exp(-D2/(2*s*s))
    H=np.eye(m)-1/m
    return (1/m)*np.sum((H@K(a)@H)*(H@K(b)@H)), m
gp = GaussianProcessRegressor(random_state=42).fit(z[0], z[1]); r = gp.predict(z[0]).reshape(-1,1)-z[1]
print('manual hsic', hsic_manual(r.ravel(), z[0].ravel()), 'pyspi', A[0,1])
# unpatched cdt behaviour
orig = anmmod.normalized_hsic
