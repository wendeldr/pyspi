import sys, re, yaml
for p in sys.argv[1:]:
    txt = open(p).read()
    before = yaml.safe_load(txt)
    lines = txt.split('\n')
    i = next(k for k, l in enumerate(lines) if l.endswith('datasets: &id001'))
    lines[i] = lines[i][:-len(' &id001')]
    items = []
    j = i + 1
    while lines[j].startswith('    - '):
        items.append(lines[j]); j += 1
    a = next(k for k, l in enumerate(lines) if l.endswith('datasets: *id001'))
    lines[a] = lines[a][:-len(' *id001')]
    lines[a+1:a+1] = items
    new = '\n'.join(lines)
    assert 'id001' not in new
    assert yaml.safe_load(new) == before
    open(p, 'w').write(new)
    print(p, 'ok', len(items))
