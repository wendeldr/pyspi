import yaml, pathlib, sys
R = pathlib.Path('/media/dan/Data/git/pyspi/audit/records')
N = pathlib.Path('/media/dan/Data/git/pyspi/audit/notes/cdt_pairwise.md')
PROBE = 'cleanup/cdt_pairwise/ident_bins.py'

def apply(path, reps, check_yaml=True):
    t = path.read_text()
    for old, new in reps:
        c = t.count(old)
        assert c == 1, (path.name, c, old[:80])
        t = t.replace(old, new)
    if check_yaml:
        yaml.safe_load(t)
    path.write_text(t)

shared = [
    ("'pyspi/calculator.py:236-250 Calculator._load_yaml: configs is empty for the four causal classes, so iterating None raises TypeError\n    and the class is instantiated with no arguments (247-250);",
     "'pyspi/calculator.py:251-267 Calculator._load_yaml: configs is empty for the four causal classes, so iterating None raises TypeError\n    and the class is instantiated with no arguments (261-267);"),
    ("'pyspi/calculator.py:292-302 Calculator.compute: S = spi.multivariate(dataset); fill_diagonal(S, nan); any exception -> whole matrix\n    NaN with a warning'",
     "'pyspi/calculator.py:327-339 Calculator.compute: S = spi.multivariate(dataset) (329); fill_diagonal(S, nan) (332); any exception\n    -> whole matrix NaN (336-339) with a warning (354-355)'"),
    ("wrapped into a new Data object with i, j = 0, 1 (base.py:33-36);",
     "wrapped into a new Data object (base.py:33-36) and i, j = 0, 1 is set (base.py:41-43);"),
]
for u in ('cds', 'anm', 'igci', 'reci'):
    reps = list(shared)
    if u == 'anm':
        reps.append(("calculator.py:246-253 reports the class labels.", "calculator.py:258-260 and 265-267 report the class labels."))
    if u == 'cds':
        reps += [
            ("Returns exactly 0 if no bin\n    has > 12 samples (CDS.py:190-191), and also exactly 0 whenever all qualifying bins have identical pmfs, in particular when exactly\n    one bin has > 12 samples (P is then 1 x 13, CDS.py:194 centring gives all zeros, np.std = 0.0 at CDS.py:195).",
             "Returns exactly 0 if no bin\n    has > 12 samples (CDS.py:190-191), and exactly 0.0 when exactly one bin has > 12 samples (P is then 1 x 13, CDS.py:194 centring\n    gives all zeros, np.std = 0.0 at CDS.py:195). When several qualifying bins have identical pmfs the result is 0 only up to rounding\n    of the column mean: exactly 0.0 for 2 identical bins, but up to ~2e-17 for 3 or 7 identical bins with non-dyadic pmf entries (probe\n    " + PROBE + ")."),
            ("np.std returns 0.0\n    with exactly one qualifying bin, or several with identical pmfs, the centred matrix is all zeros and\n    np.std returns 0.0", None),  # placeholder, handled below
        ]
        reps.pop()  # trace entry handled separately (single line)
        reps += [
            ("with exactly one qualifying bin, or several with identical pmfs, the centred matrix is all zeros and\n    np.std returns 0.0",
             "with exactly one qualifying bin the centred matrix is all zeros and np.std returns 0.0;\n    with several identical pmfs it is 0 only up to rounding of the column mean (exactly 0.0 for 2 bins, <= ~2e-17 for 3 or 7 bins)"),
            ("bin holds all but <= 144 samples) and also when all qualifying bins have identical conditional pmfs.",
             "bin holds all but <= 144 samples); 0 up to rounding (exactly 0.0 for two bins, <= ~2e-17 for 3 or 7) when all qualifying bins have\n    identical conditional pmfs."),
            ("np.std returns 0.0 (CDS.py:193-195); the same happens when several qualifying bins have identical pmfs.",
             "np.std returns 0.0 (CDS.py:193-195); when several qualifying bins have identical pmfs the result is 0 up to rounding of the\n    column mean (exactly 0.0 for two bins; up to ~2e-17 for 3 or 7 bins with non-dyadic pmf entries, probe " + PROBE + ")."),
            ("the exact 0 returned when at most one bin qualifies (or all qualifying pmfs coincide)",
             "the exact 0 returned when at most one bin qualifies (or the 0 up to rounding when all qualifying pmfs coincide)"),
            ("when exactly one bin qualifies or all qualifying pmfs are identical (CDS.py:193-195)",
             "when exactly one bin qualifies, or up to rounding when all qualifying pmfs are identical (CDS.py:193-195)"),
            ("    criterion: exact\n    expected_outcome: 'A[i, j] == 0 exactly iff the predicate holds;",
             "    criterion: tolerance\n    expected_outcome: 'A[i, j] == 0.0 exactly whenever the count part holds (at most one qualifying bin); |A[i, j]| < 1e-15 iff\n      the full predicate holds (2 identical bins give exactly 0.0, but >= 3 identical bins with non-dyadic pmf entries can leave ~1e-17\n      from rounding of the column mean, probe " + PROBE + ");"),
        ]
    apply(R / f'causal.{u}.yaml', reps)

apply(N, [
    ("`calculator.py:247-250` instantiates", "`calculator.py:261-267` instantiates"),
    ("- `calculator.py:292-302`: if the call raises", "- `calculator.py:327-339`: if the call raises"),
    ("(`CDS.py:193-195`). The same happens when all qualifying bins have identical pmfs.",
     "(`CDS.py:193-195`). When all qualifying bins have identical pmfs the result is 0 only up to rounding\n  of the column mean: exactly 0.0 for 2 bins, up to ~2e-17 for 3 or 7 bins with non-dyadic pmf entries\n  (probe `" + PROBE + "`)."),
    ("and also\n  when all qualifying bins have identical pmfs.", "and is 0 up\n  to rounding when all qualifying bins have identical pmfs."),
    ("- Exact predicate check for the zero outputs.", "- Predicate check for the zero outputs (exact 0.0 for the count part, |A| < 1e-15 for the identical-pmf part)."),
], check_yaml=False)
print('ok')
