import numpy as np
rng = np.random.default_rng(0)
# reproduce CDS.py:186,193-195 tail: pmf rows, centring, np.std
res = {}
for nb in (1, 2, 3, 4, 7):
    worst = 0.0; nz = 0; tot = 0
    for n in range(13, 41):
        for _ in range(50):
            c = np.bincount(rng.integers(0, 13, n), minlength=13).astype(float)
            p = c / c.sum()
            P = np.tile(p, (nb, 1))
            s = np.std(P - P.mean(axis=0))
            tot += 1; nz += (s != 0.0); worst = max(worst, s)
    print(f"nbins={nb}: nonzero {nz}/{tot}, max std {worst:.3g}")
