import pathlib
R = pathlib.Path('/media/dan/Data/git/pyspi/audit/records')
def rep(path, old, new, count=1):
    s = path.read_text()
    n = s.count(old)
    assert n == count, (path.name, n, old[:80])
    path.write_text(s.replace(old, new))

OLD_DIR_REF = "reference: numpy comparison of A and A.T from Calculator-style Barycenter(mode='{m}').multivariate(Data(x)) plus a cold-cache call bivariate(Data(x), i=0, j=1) vs bivariate(Data(x), i=1, j=0) on fresh Data objects (direction convention)\n    reference_kind: analytic\n"
NEW_DIR_REF = "reference: 'SELF-CONSISTENCY (pyspi vs pyspi): numpy comparison of A and A.T from Calculator-style Barycenter(mode=''{m}'').multivariate(Data(x)) plus a cold-cache call bivariate(Data(x), i=0, j=1) vs bivariate(Data(x), i=1, j=0) on fresh Data objects (direction convention). Can establish symmetry/order-invariance only, not what A[i,j] means'\n    reference_kind: same-lineage\n"
for m in ['euclidean', 'dtw', 'sgddtw', 'softdtw']:
    rep(R/f'distance.bary.{m}.yaml', OLD_DIR_REF.format(m=m), NEW_DIR_REF.format(m=m))

# euclidean check [3]: drop pyspi-vs-pyspi half, append it as its own same-lineage check
p = R/'distance.bary.euclidean.yaml'
rep(p, "expected_outcome: detrend=True results match to rtol 1e-12; scaled_offset gives the same values as bivariate_gaussian (same draw) because z-scoring removes scale and offset\n",
       "expected_outcome: detrend=True results match the from-scratch detrend+z-score reference to rtol 1e-12 on both datasets\n")
s = p.read_text()
tail = "possibly unequal for sgddtw\n"
assert s.endswith(tail) or tail in s
add = ("  - datasets:\n    - bivariate_gaussian\n    - scaled_offset\n    path: pipeline\n"
       "    reference: 'SELF-CONSISTENCY (pyspi vs pyspi): invariance of the z-scored Euclidean barycenter to per-variable positive scaling and offset; compares pyspi output on scaled_offset with pyspi output on bivariate_gaussian (same draw). Can establish invariance only, not what A[i,j] means'\n"
       "    reference_kind: same-lineage\n    criterion: tolerance\n"
       "    expected_outcome: scaled_offset output equals bivariate_gaussian output within 1e-10 for all four identifiers because z-scoring removes scale and offset\n")
i = s.index(tail) + len(tail)
p.write_text(s[:i] + add + s[i:])

# dtw: units_and_range and candidate [1]
p = R/'distance.bary.dtw.yaml'
rep(p, "mean: near 0 but not structurally zero (probe2: 0.0334 at T=64, -0.0052 at T=256 bivariate_gaussian; 0.0199 delayed_noise T=256), either sign. max: typically positive, of order max of the inputs.",
       "mean: near 0 but not structurally zero, either sign; max over pairs of |bary_dtw_mean| (cleanup probe p_dtwmean.py, Barycenter(mode=''dtw'', statistic=''mean'').multivariate on audit/checks/data) is 0.016-0.090 at T=64 (logistic_maps 0.0901, delayed_noise 0.0757, iid_gaussian 0.0707, narrowband_f0-0.25 0.0519, bivariate_gaussian 0.0508), 0.006-0.063 at T=256 and 0.004-0.012 at T=1024 except logistic_maps (0.0712). max: typically positive, of order max of the inputs (bary_dtw_max 1.16-3.20 on the same datasets).")
rep(p, "'Candidate: bary_dtw_mean is near-degenerate (close to zero), inheriting the zero mean of the Euclidean init; it only departs from 0 through warping-induced duplicated samples. Evidence: probe2 |mean| <= 0.034 across bivariate_gaussian/delayed_noise/narrowband at T=64..1024.'",
       "'Candidate: bary_dtw_mean is near-degenerate (small relative to bary_dtw_max of 1.2-3.2), inheriting the zero mean of the Euclidean init; it only departs from 0 through warping-induced duplicated samples. Evidence: cleanup probe p_dtwmean.py (Barycenter(mode=''dtw'', statistic=''mean'').multivariate on audit/checks/data), max over pairs of |bary_dtw_mean| up to ~0.09 at T=64 (logistic_maps 0.0901, delayed_noise 0.0757, iid_gaussian 0.0707, narrowband_f0-0.25 0.0519, bivariate_gaussian 0.0508), shrinking to 0.004-0.012 at T=1024 except logistic_maps (0.0712). The earlier probe2 values (0.0334, -0.0052, 0.0199) were single pairs, not a bound.'")

# sgddtw candidate [1]: lead with the cache/ordering effect, cite RNG dependence as documented
p = R/'distance.bary.sgddtw.yaml'
rep(p, "'Candidate: value depends on the global RNG state consumed by SPIs computed earlier in the same Calculator run, and on which sgddtw identifier runs first (the others reuse the cached barycenter). Evidence: dba.py:838 + validation.py:1477-1478; probe3 cache keys [''sgddtw''] with 12 cached pairs after the mean SPI and no RNG consumption by the max SPI. (Global-RNG use itself is in tests/README.md:115/127.)'",
       "'Candidate: cache/ordering effect: whichever sgddtw identifier runs first in a Calculator run fixes the barycenter for the other three (they reuse the cached barycenter per pair, so they consume no RNG draws), and the Directed loop computes pair {a<b} from z[[b, a]]. Evidence: distance.py:247-263 cache under (i,j) and (j,i); base.py:85-94 loop order; probe3 cache keys [''sgddtw''] with 12 cached pairs after the mean SPI and no RNG consumption by the max SPI. The dependence on the global numpy RNG (dba.py:838, validation.py:1477-1478), and hence on RNG draws consumed by SPIs computed earlier, is already documented (tests/README.md:115/127) and is not part of this candidate.'")
print("ok")
