# Reviewer probe: max over pairs of |bary_sgddtw_mean| (one unseeded-but-fixed-seed run per dataset), same datasets as p_dtwmean.py
import io, contextlib, warnings, numpy as np
warnings.filterwarnings("ignore")
from pyspi.data import Data
from pyspi.statistics.distance import Barycenter
D='/media/dan/Data/git/pyspi/audit/checks/data/'
for name in ['bivariate_gaussian','delayed_noise','narrowband_f0-0.25','logistic_maps','var2_bivariate','iid_gaussian']:
    for T in (64,256,1024):
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                d = Data(np.load(D+f'{name}_T{T}.npz')['x'], dim_order='ps')
        except FileNotFoundError:
            continue
        np.random.seed(0)
        with contextlib.redirect_stdout(io.StringIO()):
            Am = Barycenter(mode='sgddtw', statistic='mean').multivariate(d)
            Ax = Barycenter(mode='sgddtw', statistic='max').multivariate(d)
        off = Am[~np.eye(len(Am),dtype=bool)]
        print(f"{name:22s} T={T:5d} max|mean|={np.nanmax(np.abs(off)):.4f} median|mean|={np.nanmedian(np.abs(off)):.4f} sgd_max {np.nanmin(Ax):.3f}-{np.nanmax(Ax):.3f}")
