import numpy as np, warnings, tempfile, os
from pyspi.calculator import Calculator
cfg = tempfile.NamedTemporaryFile('w', suffix='.yaml', delete=False)
cfg.write('.statistics.misc:\n  InterDependenceScore:\n    labels: [x]\n    dependencies:\n    configs:\n      - terms: 6\n        pnorm: 3\n        bandwidth: 0.5\n')
cfg.close()
for P in (4, 6):
    X = np.random.default_rng(0).standard_normal((P, 200))
    c = Calculator(dataset=X, configfile=cfg.name)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        c.compute()
    r = c.metric_reports['ids']
    print(P, np.isnan(c.table['ids'].to_numpy()).all(), r.status, r.error, [str(x.message)[:60] for x in w if 'Caught' in str(x.message)])
