import pathlib
def rep(path, pairs):
    p = pathlib.Path(path); s = p.read_text()
    for a, b in pairs:
        assert s.count(a) == 1, (path, a[:60], s.count(a))
        s = s.replace(a, b)
    p.write_text(s)
rep('audit/records/misc.ids.yaml', [
 ("pyspi/calculator.py:224-247 Calculator._load_yaml: importlib.import_module(\".statistics.misc\") (226)",
  "pyspi/calculator.py:237-260 Calculator._load_yaml: importlib.import_module(\".statistics.misc\") (239)"),
 ("then InterDependenceScore(**params) (243), stored under identifier \"ids\" (244)",
  "then InterDependenceScore(**params) (256), stored under identifier \"ids\" (257)"),
 ("'pyspi/calculator.py:292-303 Calculator.compute: S = spi.multivariate(dataset) (294); fill_diagonal(S, nan) (297); exception -> whole block\n    NaN (301-303)'",
  "'pyspi/calculator.py:295-355 Calculator.compute (def 295; per-SPI try/except 327-339): S = spi.multivariate(dataset) (329); fill_diagonal(S,\n    nan) (332); self._table[spi] = S (335); exception -> whole block NaN (336-337), error and warning text recorded (338-339), MetricReport\n    status \"failed\" (342-346), warnings.warn emitted after the on_metric_complete callback (355)'"),
 ("tests/README.md:115-116\n    and :126-127 describe",
  "tests/README.md:113,\n    :134-135 and :145-146 describe"),
 ("and calculator.py:226\n    imports .statistics.misc", "and calculator.py:239\n    imports .statistics.misc"),
 ("for P != 6, fill_diagonal (calculator.py:297) raises ValueError;", "for P != 6, fill_diagonal (calculator.py:332) raises ValueError;"),
 ("self._table[spi] = S (calculator.py:300) raises AssertionError", "self._table[spi] = S (calculator.py:335) raises AssertionError"),
 ("In both cases the except at calculator.py:301-303 sets the whole block to NaN with\n    a warning",
  "In both cases the except at calculator.py:336-337 sets the whole block to NaN, the\n    MetricReport is marked failed (342-346) and a warning is emitted (355)"),
])
rep('audit/notes/ids.md', [
 ("`calculator.py:226` imports", "`calculator.py:239` imports"),
 ("`calculator.py:243` then instantiates", "`calculator.py:256` then instantiates"),
 ("`fill_diagonal` (calculator.py:297)", "`fill_diagonal` (calculator.py:332)"),
 ("table assignment at calculator.py:300 raises", "table assignment at calculator.py:335 raises"),
 ("the except at calculator.py:301-303 sets the whole `ids` block to NaN and only issues a warning.",
  "the except at calculator.py:336-337 sets the whole `ids` block to NaN; the failure is recorded as a `MetricReport` with status `failed` (calculator.py:342-346) and a warning is emitted at calculator.py:355, after the optional callback. No 4-D result is stored."),
])
