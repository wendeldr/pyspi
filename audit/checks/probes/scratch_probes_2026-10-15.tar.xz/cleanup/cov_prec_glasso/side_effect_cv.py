import numpy as np, warnings
warnings.simplefilter("ignore")
from pyspi.data import Data
from pyspi.statistics.basic import Covariance, Precision
rng = np.random.default_rng(0)
X = rng.standard_normal((5, 512))
for est in ["GraphicalLassoCV", "GraphicalLasso"]:
    for cls, attr in [(Precision, "precision_"), (Covariance, "covariance_")]:
        d = Data(X.copy(), dim_order='ps', normalise=True)
        M = cls(estimator=est).multivariate(d)
        cached = getattr(d.covariance[est], attr)
        print(est, cls.__name__, "keys", list(d.covariance.keys()), "diag", np.diag(cached), "is", M is cached)
