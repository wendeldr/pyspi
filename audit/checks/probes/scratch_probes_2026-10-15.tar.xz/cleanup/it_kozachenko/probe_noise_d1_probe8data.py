# d=1 noise effect (JIDT noise on minus cKDTree) on probe8's own x,y draws, T=1024
import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import jpype as jp
from scipy.stats import zscore
from scipy.special import digamma, gammaln
from scipy.spatial import cKDTree
def H(X):
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    N, d = X.shape; dist, _ = cKDTree(X).query(X, k=2, p=2)
    return -digamma(1) + digamma(N) + (d/2)*np.log(np.pi) - gammaln(d/2+1) + d*np.mean(np.log(dist[:, 1]))
def Hj(X):
    c = jp.JClass('infodynamics.measures.continuous.kozachenko.EntropyCalculatorMultiVariateKozachenko')()
    c.setProperty('BIAS_CORRECTION', 'false'); c.setProperty('NOISE_SEED', '42')
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    c.initialise(X.shape[1]); c.setObservations(jp.JArray(jp.JDouble, 2)(X.tolist()))
    return float(c.computeAverageLocalOfObservations())
def ar1(rng, phi, T):
    x = np.zeros(T + 500); e = rng.standard_normal(T + 500)
    for t in range(1, T + 500): x[t] = phi*x[t-1] + e[t]
    return x[500:]
T = 1024
for phi in (0.0, 0.5, 0.9):
    m = 0.0
    for seed in range(10):
        rng = np.random.default_rng(seed)
        x, y = ar1(rng, phi, T), ar1(rng, phi, T)
        zx, zy = zscore(np.vstack([x, y]), axis=1, ddof=1)
        for z in (zx[:-1], zy, zy[:-1], zx):
            m = max(m, abs(Hj(z) - H(z)))
    print(f'phi={phi} max |d=1 noise effect| over 10 seeds, x/y series = {m:.2e}')
