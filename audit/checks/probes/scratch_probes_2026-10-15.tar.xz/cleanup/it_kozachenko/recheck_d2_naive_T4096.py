# d=2 naive-routine wrong NN distances at N=4096 on the real check datasets (noise off)
import sys, io, contextlib, itertools, numpy as np, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
import jpype as jp
from scipy.stats import zscore
from scipy.spatial import cKDTree
EU = jp.JClass('infodynamics.utils.EuclideanUtils')
D = '/media/dan/Data/git/pyspi/audit/checks/data/%s_T4096.npz'
for ds in ["iid_gaussian", "bivariate_gaussian", "var2_bivariate", "anm", "delayed_noise", "logistic_maps_bidir"]:
    z = zscore(np.load(D % ds)['x'], axis=1, ddof=1)
    out = []
    for i, j in itertools.permutations(range(z.shape[0]), 2):
        X = np.column_stack([z[i], z[j]])
        true = cKDTree(X).query(X, k=2)[0][:, 1]
        naive = np.array(EU.computeMinEuclideanDistancesNaive(jp.JArray(jp.JDouble, 2)(X)))
        wrong = int((np.abs(naive - true) > 1e-12).sum())
        out.append((wrong, int((true > 1).sum()), (i, j)))
    out.sort(reverse=True)
    print(f'{ds:19s} N=4096 d=2: max wrong NN distances over pairs = {out[0][0]} (pair {out[0][2]}, #rho>1 = {out[0][1]}); pairs with any wrong: {sum(1 for o in out if o[0] > 0)}/{len(out)}')
