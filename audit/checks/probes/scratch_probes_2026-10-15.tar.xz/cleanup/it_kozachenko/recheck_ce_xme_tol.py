# Re-check: is the 1e-5 nat tolerance in ce.kozachenko / xme.kozachenko_k1 proposed_checks achievable
# given the d=1 noise effect? Pipeline (Data normalise=True) vs from-scratch cKDTree KL, all pairs.
import sys, io, contextlib, itertools, numpy as np, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
warnings.filterwarnings('ignore')
import pyspi.statistics.infotheory as it
from pyspi.data import Data
from scipy.stats import zscore
from scipy.special import digamma, gammaln
from scipy.spatial import cKDTree
def H(X):
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    N, d = X.shape; dist, _ = cKDTree(X).query(X, k=2, p=2)
    return -digamma(1) + digamma(N) + (d/2)*np.log(np.pi) - gammaln(d/2+1) + d*np.mean(np.log(dist[:, 1]))
ce = it.ConditionalEntropy(estimator='kozachenko')
xme = it.CrossmapEntropy(estimator='kozachenko', history_length=1)
D = '/media/dan/Data/git/pyspi/audit/checks/data/%s_T%d.npz'
for name, dsets in [('ce', ["iid_gaussian", "bivariate_gaussian", "var2_bivariate", "anm"]),
                    ('xme_k1', ["iid_gaussian", "bivariate_gaussian", "var2_bivariate", "anm", "delayed_noise", "logistic_maps_bidir"])]:
    for ds in dsets:
        for T in (64, 256, 1024, 4096):
            x = np.load(D % (ds, T))['x']
            with contextlib.redirect_stdout(io.StringIO()):
                d = Data(x, dim_order='ps', normalise=True)
            z = zscore(x, axis=1, ddof=1)
            worst = 0.0; wpair = None
            for i, j in itertools.permutations(range(x.shape[0]), 2):
                if name == 'ce':
                    v = ce.bivariate(d, i=i, j=j); r = H(np.column_stack([z[i], z[j]])) - H(z[i])
                else:
                    v = xme.bivariate(d, i=i, j=j); r = H(np.column_stack([z[i][:-1], z[j][1:]])) - H(z[i][:-1])
                if abs(v - r) > worst: worst, wpair = abs(v - r), (i, j)
            flag = '  EXCEEDS 1e-5' if worst > 1e-5 else ''
            print(f'{name:7s} {ds:19s} T={T:4d} n={x.shape[0]} max|A-ref|={worst:.2e} pair={wpair}{flag}', flush=True)
