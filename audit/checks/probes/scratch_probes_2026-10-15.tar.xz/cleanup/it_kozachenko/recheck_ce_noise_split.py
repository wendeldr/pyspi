# For cases where ce/xme_k1 pipeline vs cKDTree exceeds 1e-5: is it the 1e-8 noise, and which term (d=1 or d=2)?
import sys, io, contextlib, numpy as np, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
warnings.filterwarnings('ignore')
import jpype as jp
from scipy.stats import zscore
from scipy.special import digamma, gammaln
from scipy.spatial import cKDTree
def H(X):
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    N, d = X.shape; dist, _ = cKDTree(X).query(X, k=2, p=2)
    return -digamma(1) + digamma(N) + (d/2)*np.log(np.pi) - gammaln(d/2+1) + d*np.mean(np.log(dist[:, 1]))
def Hj(X, noise=True):
    c = jp.JClass('infodynamics.measures.continuous.kozachenko.EntropyCalculatorMultiVariateKozachenko')()
    c.setProperty('BIAS_CORRECTION', 'false'); c.setProperty('NOISE_SEED', '42')
    if not noise: c.setProperty('NOISE_LEVEL_TO_ADD', '0')
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    c.initialise(X.shape[1]); c.setObservations(jp.JArray(jp.JDouble, 2)(X.tolist()))
    return float(c.computeAverageLocalOfObservations())
D = '/media/dan/Data/git/pyspi/audit/checks/data/%s_T%d.npz'
cases = [('iid_gaussian', 1024, 1, 2), ('iid_gaussian', 4096, 1, 2), ('bivariate_gaussian', 256, 1, 0),
         ('var2_bivariate', 1024, 1, 0), ('anm', 4096, 1, 0), ('logistic_maps_bidir', 256, 1, 0)]
for ds, T, i, j in cases:
    z = zscore(np.load(D % (ds, T))['x'], axis=1, ddof=1)
    J = np.column_stack([z[i], z[j]]); M = z[i]
    dist = cKDTree(M[:, None]).query(M[:, None], k=2)[0][:, 1]
    print(f'{ds:19s} T={T:4d} ({i},{j}) ce noise-on diff={abs((Hj(J)-Hj(M))-(H(J)-H(M))):.2e} '
          f'noise-off diff={abs((Hj(J,False)-Hj(M,False))-(H(J)-H(M))):.2e} | '
          f'd=2 noise effect={abs(Hj(J)-H(J)):.2e} d=1 noise effect={abs(Hj(M)-H(M)):.2e} | '
          f'd=1 min NN dist={dist.min():.1e}, #dist<1e-6: {int((dist<1e-6).sum())}')
