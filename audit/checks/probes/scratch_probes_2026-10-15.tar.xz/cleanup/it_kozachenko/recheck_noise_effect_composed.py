# Noise effect on each composed kozachenko SPI through the pipeline path: value with JIDT's 1e-8 noise (as shipped)
# minus value with NOISE_LEVEL_TO_ADD=0, max over pairs. With noise off JIDT equals a cKDTree KL reference to ~1e-14
# for N <= 2000 (probe1/probe3), so this is the floor any tolerance against a from-scratch reference must clear.
import sys, io, contextlib, itertools, numpy as np, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
warnings.filterwarnings('ignore')
import pyspi.statistics.infotheory as it
from pyspi.data import Data
D = '/media/dan/Data/git/pyspi/audit/checks/data/%s_T%d.npz'
mk = {'ce': lambda: it.ConditionalEntropy(estimator='kozachenko'),
      'xme_k1': lambda: it.CrossmapEntropy(estimator='kozachenko', history_length=1),
      'cce': lambda: it.CausalEntropy(estimator='kozachenko'),
      'di': lambda: it.DirectedInfo(estimator='kozachenko'),
      'si': lambda: it.StochasticInteraction(estimator='kozachenko')}
dsets = {'ce': ["iid_gaussian", "bivariate_gaussian", "var2_bivariate", "anm"],
         'xme_k1': ["iid_gaussian", "bivariate_gaussian", "var2_bivariate", "anm", "delayed_noise", "logistic_maps_bidir"],
         'cce': ["iid_gaussian", "var2_bivariate", "gauss_ar1_pair"],
         'di': ["iid_gaussian", "var2_bivariate", "gauss_ar1_pair", "delayed_noise"],
         'si': ["iid_gaussian", "var2_bivariate", "gauss_ar1_pair", "logistic_maps_bidir"]}
for name in ['ce', 'xme_k1', 'cce', 'di', 'si']:
    for ds in dsets[name]:
        for T in (64, 256, 1024):
            x = np.load(D % (ds, T))['x']
            vals = {}
            for noise in (True, False):
                spi = mk[name]()
                if not noise: spi._entropy_calc.setProperty('NOISE_LEVEL_TO_ADD', '0')
                with contextlib.redirect_stdout(io.StringIO()):
                    d = Data(x, dim_order='ps', normalise=True)
                vals[noise] = {(i, j): spi.bivariate(d, i=i, j=j) for i, j in itertools.permutations(range(x.shape[0]), 2)}
            diffs = {p: abs(vals[True][p] - vals[False][p]) for p in vals[True]}
            p = max(diffs, key=diffs.get)
            print(f'{name:7s} {ds:19s} T={T:4d} max|noise on - off|={diffs[p]:.2e} pair={p}{"  >1e-5" if diffs[p] > 1e-5 else ""}', flush=True)
