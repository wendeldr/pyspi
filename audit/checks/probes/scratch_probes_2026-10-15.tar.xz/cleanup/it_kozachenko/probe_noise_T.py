# Noise effect per embedding dim: JIDT Kozachenko (noise on, as pyspi uses) minus cKDTree KL (no noise)
import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
from scipy.stats import zscore
from scipy.special import digamma, gammaln
from scipy.spatial import cKDTree
def H(X):
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    N, d = X.shape; dist, _ = cKDTree(X).query(X, k=2, p=2)
    return -digamma(1) + digamma(N) + (d/2)*np.log(np.pi) - gammaln(d/2+1) + d*np.mean(np.log(dist[:, 1]))
def emb(x, k):
    T = len(x); return np.column_stack([x[k-1-i:T-i] for i in range(k)])
je = it.JointEntropy(estimator='kozachenko')
calc = je._getcalc('entropy') if hasattr(je, '_getcalc') else None
import jpype as jp
def Hj(X, noise=True):
    c = jp.JClass('infodynamics.measures.continuous.kozachenko.EntropyCalculatorMultiVariateKozachenko')()
    c.setProperty('BIAS_CORRECTION', 'false'); c.setProperty('NOISE_SEED', '42')
    if not noise: c.setProperty('NOISE_LEVEL_TO_ADD', '0')
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    c.initialise(X.shape[1]); c.setObservations(jp.JArray(jp.JDouble, 2)(X.tolist()))
    return float(c.computeAverageLocalOfObservations())
def ar1(rng, phi, T):
    x = np.zeros(T + 500); e = rng.standard_normal(T + 500)
    for t in range(1, T + 500): x[t] = phi*x[t-1] + e[t]
    return x[500:]
for T in (256, 1024):
    for phi in (0.0, 0.9):
        worst = {k: [0.0, 0.0] for k in range(1, 6)}
        for seed in range(10):
            rng = np.random.default_rng(seed)
            z = zscore(ar1(rng, phi, T), ddof=1)
            for k in range(1, 6):
                E = emb(z, k); r = H(E)
                worst[k][0] = max(worst[k][0], abs(Hj(E, True) - r))
                worst[k][1] = max(worst[k][1], abs(Hj(E, False) - r))
        print(f'T={T} phi={phi}', {k: (f'{a:.1e}', f'{b:.1e}') for k, (a, b) in worst.items()})
