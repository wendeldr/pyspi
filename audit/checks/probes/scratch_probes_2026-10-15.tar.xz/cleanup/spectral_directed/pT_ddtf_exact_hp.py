# exact-spectrum ddtf scaling with grid size n (no estimation noise)
import numpy as np, sys, logging
logging.disable(logging.WARNING)
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi._spectral_compat import spectral_connectivity as sc
import spectral_connectivity.connectivity as C
def ct(a): return np.conj(np.swapaxes(a,-1,-2))
A1=np.array([[0.5,0.0],[0.5,0.4]]); A2=np.array([[-0.3,0.0],[-0.2,-0.2]]); Sig=np.diag([1.0,0.8])
prev=None
for n in [64,256,1024,4096]:
    f=np.fft.fftfreq(n); zz=np.exp(-2j*np.pi*f)
    Abar=np.eye(2)[None]-A1[None]*zz[:,None,None]-A2[None]*(zz**2)[:,None,None]
    H=np.linalg.inv(Abar); S=H@Sig@ct(H)
    class Exact(C.Connectivity):
        def _expectation_cross_spectral_matrix(self, fcn=None, dtype=None): return S[None]
    con=Exact(fourier_coefficients=np.zeros((1,1,1,n,2),complex), frequencies=f)
    dd=con.direct_directed_transfer_function()[0][1:,1,0].mean()
    s='' if prev is None else f' slope {np.log(dd/prev)/np.log(n/pn):.4f}'
    print(f'n={n}: exact ddtf[1,0] band mean {dd:.6f} x sqrt(n/2) {dd*np.sqrt(n/2):.8f}'+s); prev,pn=dd,n
# spread summary (appended for the recheck)
import numpy as np
vals=[]
for n in [64,256,1024,4096]:
    f=np.fft.fftfreq(n); zz=np.exp(-2j*np.pi*f)
    Abar=np.eye(2)[None]-A1[None]*zz[:,None,None]-A2[None]*(zz**2)[:,None,None]
    H=np.linalg.inv(Abar); S=H@Sig@ct(H)
    class Exact(C.Connectivity):
        def _expectation_cross_spectral_matrix(self, fcn=None, dtype=None): return S[None]
    con=Exact(fourier_coefficients=np.zeros((1,1,1,n,2),complex), frequencies=f)
    vals.append(con.direct_directed_transfer_function()[0][1:,1,0].mean()*np.sqrt(n/2))
v=np.array(vals)
print('spread all rel max %.4f%%  rel min %.4f%%  rel mean %.4f%%' % (100*(v.max()-v.min())/v.max(), 100*(v.max()-v.min())/v.min(), 100*(v.max()-v.min())/v.mean()))
w=v[1:]
print('spread 256..4096 rel max %.4f%%  rel min %.4f%%' % (100*(w.max()-w.min())/w.max(), 100*(w.max()-w.min())/w.min()))
