# per-entry pipeline ddtf log-log slopes (single realisation per T) + exact-spectrum spread
import numpy as np, warnings, contextlib, io, sys, logging
warnings.filterwarnings('ignore'); logging.disable(logging.WARNING)
sys.path.insert(0, '/media/dan/Data/git/pyspi')
from pyspi.statistics import spectral as S
from pyspi.data import Data
D='/media/dan/Data/git/pyspi/audit/checks/data'
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x, dim_order='ps')
Ts=[64,256,1024,4096]
for name in ['var2_bivariate','iid_gaussian']:
    res={}
    for T in Ts:
        x=np.load(f'{D}/{name}_T{T}.npz')['x']
        if name=='iid_gaussian': x=x[:3]
        res[T]=S.DirectDirectedTransferFunction(statistic='mean').multivariate(mk(x))
    P=res[64].shape[0]; off=~np.eye(P,dtype=bool)
    for k in range(3):
        a,b=Ts[k],Ts[k+1]; sl=np.log(res[b]/res[a])/np.log(b/a)
        print(name, f'{a}->{b}', 'mean slope %.3f'%(np.log(res[b][off].mean()/res[a][off].mean())/np.log(b/a)),
              'entries', {f'[{i},{j}]':round(float(sl[i,j]),3) for i in range(P) for j in range(P) if i!=j})
