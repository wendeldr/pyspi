import warnings, json
import numpy as np
warnings.simplefilter("ignore")
from mne.time_frequency import morlet
from mne.time_frequency.tfr import cwt
from scipy.stats import zscore
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
f = np.linspace(0.2, 0.5, 125); Ws = morlet(1.0, f, n_cycles=f/7.0, zero_mean=True)
m = json.load(open(D + "MANIFEST.json")); names = sorted({ff["name"] for ff in m["files"]})
mx = 0.0; n9 = 0; n10 = 0; pts = 0; minre = np.inf; where = None
for T in (64, 256, 1024):
    for nm in names:
        try: x = np.load(f"{D}{nm}_T{T}.npz")["x"]
        except FileNotFoundError: continue
        z = zscore(x, axis=1, ddof=1); C = cwt(z, Ws, use_fft=True, mode="same"); P = z.shape[0]
        for i in range(P):
            for j in range(i):
                csd = C[i]*np.conj(C[j]); re = np.abs(csd.real); im = np.abs(csd.imag)
                ok = re > 0; r = im[ok]/re[ok]; pts += csd.size
                if r.max() > mx: mx = r.max(); where = (nm, T, i, j)
                n9 += int((r > 1e-9).sum()); n10 += int((r > 1e-10).sum()); minre = min(minre, re[ok].min())
print(f"points {pts}; max |Im csd|/|Re csd| = {mx:.3e} at {where}; count ratio>1e-10: {n10}; >1e-9: {n9}; min |Re csd| = {minre:.3e}")
