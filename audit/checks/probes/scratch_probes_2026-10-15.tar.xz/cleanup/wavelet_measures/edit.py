import glob, re
def sub(path, old, new, count=None):
    s = open(path).read()
    n = s.count(old)
    assert n >= 1, (path, old[:60])
    if count is not None: assert n == count, (path, old[:60], n)
    s = s.replace(old, new); open(path, 'w').write(s)

R = 'audit/records/'
# --- ppc +inf condition ---
p = R + 'wavelet.ppc.yaml'
sub(p, "per point |unit phasor|^2 - 1 is 0 or slightly negative (never positive where |csd| equals |Re csd| bitwise, which held at every probed point), giving NaN or -inf",
       "per point |unit phasor|^2 - 1 is 0 or slightly negative at every probed point (it turns positive only once |Im csd| exceeds about 1.05e-8 |Re csd|, i.e. Im(acc)^2 >= 2^-53, even where |csd| equals |Re csd| bitwise; the largest ratio in the audit data is 2.41e-12), giving NaN or -inf", 1)
sub(p, "+inf cannot arise at a point where |csd| equals |Re csd| bitwise (every probed point), and would need |Im csd| above about 1e-8 |Re csd|, i.e. a lag-0 product close to zero relative to the FFT round-off (not observed)",
       "+inf needs a point with |Im csd| above about 1.05e-8 |Re csd| (Im(acc)^2 >= 2^-53 makes |acc|^2 - 1 positive whether or not |csd| equals |Re csd| bitwise; synthetic Re = 1, Im = 1.2e-8 gives +inf), i.e. a lag-0 product close to zero relative to the FFT round-off (not observed: the largest |Im csd|/|Re csd| over the 14,280,000 audit points is 2.41e-12)", 1)
s = open(p).read()
i = s.index("  - 'CANDIDATE: the -inf comes from round-off:"); j = s.index("\n", i)
new = ("  - 'CANDIDATE: the -inf comes from round-off: per point |csd/|csd||^2 - 1 is slightly negative or 0, giving -inf or NaN (probe iid T=256: 4756 -inf, 27244 NaN, 0 +inf). numpy computes Re acc = Re csd * fl(1/|csd|); where |csd| equals |Re csd| bitwise this is c*fl(1/c) <= 1 in round-to-nearest (reviewer probe fable_wl/wav4.py: c*(1/c) > 1 at 0 of 32000), but that bounds only Re(acc)^2. The residue fl(fl(Re(acc)^2) + fl(Im(acc)^2)) - 1 turns positive once Im(acc)^2 reaches about 2^-53, i.e. |Im csd| above about 1.05e-8 |Re csd| (about 1.5e-8 when Re acc = 1 - 2^-53), and |csd| still equals |Re csd| bitwise there, so bitwise equality does not exclude +inf (probe cleanup/wavelet_measures/pinf.py: for Re csd = 1.0, 0.37 and 2.9e-7 every ratio from 1.06e-8 to 1.6e-8 gives bitwise equality and a positive residue; the pipeline expression at Re = 1, Im = 1.2e-8 returns +inf with |csd| == |Re csd| True; on the synthetic setup of wl_fix2/p1.py at ratio 1e-8, 193029 of 1000000 points are bitwise equal with a positive residue, at ratio 1e-9 none are positive). The audit data never approach the threshold: over 14,280,000 points of all lower pairs of the 19 datasets at T = 64, 256, 1024, |csd| != |Re csd| at 0 points and the residue is positive at 0 points (wl_fix/fx1.py), and the largest |Im csd|/|Re csd| is 2.41e-12 (bivariate_gaussian T=1024 pair (2,1); 0 points above 1e-10; min |Re csd| 7.46e-7; probe cleanup/wavelet_measures/ratio.py). +inf is therefore excluded only for the inputs probed; it needs a lag-0 product close to zero relative to the FFT round-off.'")
s = s[:i] + new + s[j:]; open(p, 'w').write(s)

# --- README citations in records ---
for p in sorted(glob.glob(R + 'wavelet.*.yaml')):
    s = open(p).read(); o = s
    s = s.replace("tests/README.md:136 ", "tests/README.md:155 ")
    s = s.replace("tests/README.md flagged: wavelet degenerate (tests/README.md:198", "tests/README.md ''Degenerate outputs in the extra wavelet set'' (tests/README.md:217")
    s = s.replace("tests/README.md ''flagged: wavelet degenerate'' (line 198)", "tests/README.md ''Degenerate outputs in the extra wavelet set'' (line 217)")
    s = s.replace(" and :138: ''cohmag", " and :157: ''cohmag")
    s = s.replace("; :138 ''", "; :157 ''")
    s = s.replace("same :138 statement", "same :157 statement")
    s = s.replace("contradicts tests/README.md:198 ''non-trivial values''", "contradicts tests/README.md:157 ''non-trivial values''")
    s = s.replace("(''the array is 1 x processes x samples'')", "(''a single epoch (1 x processes x samples)'')")
    if s != o: open(p, 'w').write(s); print('edited', p)

# --- notes ---
n = 'audit/notes/wavelet_measures.md'
s = open(n).read()
old136 = s[s.index("**Candidate.** The −inf comes from round-off, and +inf is excluded"):]
old136 = old136[:old136.index("\n")]
s = s.replace(old136, "**Candidate.** The −inf comes from round-off. numpy divides the complex csd by the real |csd|, so Re acc = Re csd · fl(1/|csd|); where |csd| equals |Re csd| bitwise this is c·fl(1/c), which in round-to-nearest is 1 or 1 − 2⁻⁵³, never above 1. That bounds only Re(acc)². The residue |acc|² − 1 = fl(fl(Re(acc)²) + fl(Im(acc)²)) − 1 turns positive once Im(acc)² reaches about 2⁻⁵³, that is once |Im csd| exceeds about 1.05e-8·|Re csd| (about 1.5e-8 when Re acc = 1 − 2⁻⁵³), and |csd| still equals |Re csd| bitwise there, so bitwise equality does not exclude +inf. A synthetic probe (`cleanup/wavelet_measures/pinf.py`) gives bitwise equality and a positive residue at every ratio from 1.06e-8 to 1.6e-8 for Re csd = 1.0, 0.37 and 2.9e-7, and the pipeline expression at Re = 1, Im = 1.2e-8 returns +inf. On the synthetic setup of `wl_fix2/p1.py`, |Im| = 1e-9·|Re| never gave a positive residue, while |Im| about 1e-8·|Re| gave one at 216,800 of 10⁶ points, most of them (193,029 in the rerun) at points where |csd| equals |Re csd| bitwise. The audit data stay far below the threshold: over all lower pairs of the 19 datasets at T = 64, 256 and 1024 (14,280,000 points), the residue was never positive (1,984,491 negative, 12,295,509 zero), and the largest |Im csd|/|Re csd| is 2.41e-12 (bivariate_gaussian, T = 1024, pair (2, 1); no point above 1e-10; `cleanup/wavelet_measures/ratio.py`). So +inf is excluded only for the inputs probed; it needs a lag-0 product close to zero relative to the FFT round-off.", 1)
s = s.replace("For ppc, +inf is excluded wherever |csd| equals |Re csd| bitwise, which held at every probed point (see the ppc section); the remaining case is a lag-0 product close to zero relative to the round-off.",
              "For ppc, +inf needs a point with |Im csd| above about 1.05e-8·|Re csd| (Im(acc)² ≥ 2⁻⁵³), which bitwise equality of |csd| and |Re csd| does not rule out; the largest ratio in the audit data is 2.41e-12 (see the ppc section), so the case is a lag-0 product close to zero relative to the round-off, which no dataset produced.")
s = s.replace("`tests/README.md:136`", "`tests/README.md:155`").replace("`tests/README.md:198`", "`tests/README.md:217`").replace("`tests/README.md:138`", "`tests/README.md:157`")
s = s.replace("README:198", "README:217").replace("README:138", "README:157").replace("The README (:198)", "The README (:217)")
open(n, 'w').write(s)
