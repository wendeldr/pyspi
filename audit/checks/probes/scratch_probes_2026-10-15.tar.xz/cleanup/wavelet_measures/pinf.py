import numpy as np
rng = np.random.default_rng(0)
# 1. fl(c*fl(1/c)) <= 1 ?
c = np.abs(rng.standard_normal(10**7)) * 10.0**rng.uniform(-6, 6, 10**7)
print("c*fl(1/c) > 1 count:", int((c*(1.0/c) > 1).sum()), "of 1e7; values seen:", np.unique(c*(1.0/c))[:4])
# 2. p1.py setup at ratio 1e-8: how many positive residues ALSO have |csd| == |Re csd| bitwise?
N = 10**6
for ratio in [1e-9, 5e-9, 8e-9, 1e-8, 1.2e-8, 1.5e-8, 2e-8, 1e-7]:
    re = rng.standard_normal(N); im = re*ratio*rng.standard_normal(N)
    csd = re + 1j*im; d = np.abs(csd); a = csd/d
    r = (a*np.conj(a)).real - 1
    eq = d == np.abs(re)
    print(f"ratio={ratio:.0e}: |csd|==|Re| bitwise {int(eq.sum())}, residue>0 {int((r>0).sum())}, BOTH (bitwise-equal AND residue>0 -> +inf) {int((eq & (r>0)).sum())}")
# 3. deterministic sweep: re = 1.0 and re = random, rho on a fine grid
for re0 in [1.0, 0.37, 2.9e-7]:
    rhos = np.linspace(0.9e-8, 1.6e-8, 71)
    out = []
    for rho in rhos:
        csd = np.array([re0 + 1j*re0*rho]); d = np.abs(csd); a = csd/d; r = (a*np.conj(a)).real - 1
        out.append((rho, bool(d[0] == abs(re0)), float(r[0])))
    both = [rho for rho, eq, r in out if eq and r > 0]
    print(f"re={re0}: rho window with |csd|==|Re| AND residue>0: {min(both):.3e}..{max(both):.3e} ({len(both)} of {len(rhos)} grid points)" if both else f"re={re0}: no window")
# 4. the actual pipeline division (epochs_bivariate.py:328-345) on one such point
csd = np.array([[1.0 + 1.2e-8j]]); denom = np.abs(csd); acc = csd/denom
con = (acc*np.conj(acc) - 1) / (1*(1-1.0)); print("pipeline value at Re=1, Im=1.2e-8:", np.real(con), "|csd|==|Re|:", bool(denom[0,0]==1.0))
# 5. threshold for Im(acc)^2 >= 2^-53 vs bitwise window
print("sqrt(2^-53) =", np.sqrt(2.0**-53), " sqrt(2^-52)=", np.sqrt(2.0**-52))
