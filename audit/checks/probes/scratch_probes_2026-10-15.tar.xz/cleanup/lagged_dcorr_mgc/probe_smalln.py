import numpy as np, traceback
from hyppo.time_series import DcorrX
for ml, Ts in [(1, range(2, 6)), (10, range(10, 15))]:
    for seed in range(4):
        rng = np.random.default_rng(seed)
        out = []
        for T in Ts:
            x = rng.standard_normal((T, 1)); y = rng.standard_normal((T, 1))
            try:
                s = DcorrX(max_lag=ml).statistic(x, y)[0]
                out.append(f"T={T}:ok({s:.3f})")
            except Exception as e:
                tb = traceback.extract_tb(e.__traceback__)[-1]
                out.append(f"T={T}:{type(e).__name__}@{tb.filename.split('/')[-1]}:{tb.lineno}")
        print(ml, seed, out)
