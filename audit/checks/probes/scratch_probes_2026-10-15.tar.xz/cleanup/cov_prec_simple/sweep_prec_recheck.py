import numpy as np, warnings, json, sys
warnings.filterwarnings("ignore")
sys.path.insert(0, "/media/dan/Data/git/pyspi")
from pyspi.data import Data
from pyspi.statistics import basic
D = "/media/dan/Data/git/pyspi/audit/checks/data/"
m = json.load(open(D+"MANIFEST.json"))
ests = ["EmpiricalCovariance","LedoitWolf","OAS","ShrunkCovariance"]
stats = {e: dict(n=0, asym_n=0, asym_max=0.0, asym_file='', vmax=0.0, vfile='') for e in ests}
coint = {}
print("files:", len(m["files"]))
for f in m["files"]:
    x = np.load(D+f["file"])["x"]; dat = Data(x)
    for e in ests:
        A = basic.Precision(estimator=e).multivariate(dat)
        a = np.nanmax(np.abs(A - A.T)); v = np.nanmax(np.abs(A))
        s = stats[e]; s['n'] += 1; s['asym_n'] += int(a > 0)
        if a > s['asym_max']: s['asym_max'] = a; s['asym_file'] = f["file"]
        if v > s['vmax']: s['vmax'] = v; s['vfile'] = f["file"]
        if f["file"].startswith("cointegrated_T1024"): coint[e] = v
for e in ests: print(e, stats[e])
print("cointegrated_T1024 max|prec|:", {k: round(v,3) for k,v in coint.items()})
# bivariate_gaussian T=1024 pair (2,3)
x = np.load(D+"bivariate_gaussian_T1024.npz")["x"]; dat = Data(x)
for e in ests:
    A = basic.Precision(estimator=e).multivariate(dat)
    Th = dat.covariance[e].precision_.copy()  # diag mutated to NaN -> recompute from covariance_
    C = dat.covariance[e].covariance_.copy(); np.fill_diagonal(C, np.diag(np.cov(dat.to_numpy(squeeze=True), bias=True)))
    # rebuild full precision from the covariance_ with diag restored
    from scipy.linalg import pinvh
    Thf = pinvh(C)
    pc = -Thf[2,3]/np.sqrt(Thf[2,2]*Thf[3,3])
    print(f"bivariate_gaussian T1024 {e}: prec[2,3]={A[2,3]:.4f} partial_corr={pc:.4f}")
# shared_envelope T=256 pair (0,2)
x = np.load(D+"shared_envelope_T256.npz")["x"]; dat = Data(x)
print("shared_envelope T256 x2==x0:", np.array_equal(x[2], x[0]))
for e in ests:
    A = basic.Precision(estimator=e).multivariate(dat); print(f"  {e} prec[0,2]={A[0,2]:.3f}")
# sparse_precision T=4096 scaling note
z = np.load(D+"sparse_precision_T4096.npz"); x = z["x"]
K = basic.Precision().multivariate(Data(x, normalise=False))
P = basic.Precision().multivariate(Data(x))
d = np.sqrt(np.diag(np.cov(x, bias=True)))
K0 = np.where(np.isnan(K), 0, K)
DTD = (np.diag(d) @ K0 @ np.diag(d))[0,1]
T = x.shape[1]
print(f"sparse_precision T4096: kernel prec[0,1]={K[0,1]:.4f} truth={z['precision_true'][0,1]} pipeline prec[0,1]={P[0,1]:.4f} D*Th*D[0,1]={DTD:.4f} T/(T-1)*DTD={T/(T-1)*DTD:.4f}")
# ddof=1 D variant
d1 = np.sqrt(np.diag(np.cov(x, bias=False)))
print(f"  with ddof=1 D: {(np.diag(d1) @ K0 @ np.diag(d1))[0,1]:.4f}")
