import numpy as np, io, contextlib, warnings
warnings.simplefilter('ignore')
from pyspi.data import Data
from pyspi.statistics.basic import CrossCorrelation
B='/media/dan/Data/git/pyspi/audit/checks/data/'
def mk(X, **kw):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(X, **kw)
for name in ('cointegrated','trending','var2_bivariate','gauss_ar1_pair','bivariate_gaussian'):
    for T in (256,1024):
        try: X=np.load(B+f'{name}_T{T}.npz')['x']
        except Exception as e: print(name,T,'missing'); continue
        d=mk(X.copy()); A=CrossCorrelation(statistic='mean',sigonly=False).multivariate(d)
        # identity check for pair (0,1) orientation hi=1, lo=0
        z=d.to_numpy()[:,:,0]; x=z[1]; y=z[0]
        full=np.correlate(x,y,'full')/x.std()/y.std()/(T-1)
        L=T//4; win=full[T-L:T+L]; tail=full.sum()-win.sum()
        print(f"{name} T={T} max|A|={np.nanmax(np.abs(A)):.4f} A01={A[0,1]:.6f} -tail/2L={-tail/(2*L):.6f} lag0/2L={full[T-1]/(2*L):.6f} lag0={full[T-1]:.4f}")
rng=np.random.default_rng(7); T=1024; w=np.cumsum(rng.standard_normal(T)); X=np.vstack([w+rng.standard_normal(T)*0.1, w+rng.standard_normal(T)*0.1])
A=CrossCorrelation(statistic='mean',sigonly=False).multivariate(mk(X.copy())); print("rw pair", A[0,1])
# ulp check shared_envelope
for T in (256,1024):
    X=np.load(B+f'shared_envelope_T{T}.npz')['x']; d=mk(X.copy())
    CrossCorrelation(statistic='mean',sigonly=False).multivariate(d)
    r=d.xcorr[(0,2)] if (0,2) in d.xcorr else d.xcorr[(2,0)]
    v=r[T//4-1]; print('shared_env',T,repr(v),repr(T/(T-1)),v==T/(T-1),abs(v-T/(T-1)))
