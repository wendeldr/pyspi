import numpy as np, pandas as pd, pyEDM, warnings
warnings.simplefilter('ignore')
from scipy.stats import zscore
base='/media/dan/Data/git/pyspi/audit/checks/data/'
x=zscore(np.load(base+'logistic_maps_T256.npz')['x'][:2],axis=1,ddof=1); N=x.shape[1]
df=pd.DataFrame(np.c_[np.arange(N),x.T],columns=['index','proc0','proc1'])

def xmap(src,tgt,E,mode):
    rows=np.arange(E-1,N); emb=np.stack([src[rows-k] for k in range(E)],1); knn=E+1
    pred=np.empty(len(rows)); nexp=0
    for a in range(len(rows)):
        d=np.sqrt(((emb-emb[a])**2).sum(1)); d[a]=np.inf
        o=np.argsort(d,kind='stable'); dk=d[o]; dK=dk[knn-1]
        if mode=='plain':
            sel=o[:knn]; ds=dk[:knn]
        else:
            nb=int((dk<dK).sum()); nt=int((dk==dK).sum()); sel=o[:nb+nt]; ds=dk[:nb+nt]
        dmin=ds.min()
        w=np.where(ds==0,1.0,0.0) if dmin==0 else np.exp(-ds/dmin)
        w=np.maximum(w,1e-6)
        if mode!='plain' and nb+nt>knn:
            w[nb:]*=(knn-nb)/nt; nexp+=1
        pred[a]=(w*tgt[rows[sel]]).sum()/w.sum()
    return np.corrcoef(tgt[rows],pred)[0,1], nexp

for E in (1,10):
    out=pyEDM.CCM(dataFrame=df,E=E,columns='proc0',target='proc1',libSizes=f"{N-E+1}",random=False)
    ccm01=out.iloc[0,1]; ccm10=out.iloc[0,2]
    for (s,t,lab,ccmv) in ((0,1,'p0:p1',ccm01),(1,0,'p1:p0',ccm10)):
        rp,_=xmap(x[s],x[t],E,'plain'); rt,ne=xmap(x[s],x[t],E,'tie')
        sp=pyEDM.Simplex(dataFrame=df,lib=f"1 {N}",pred=f"1 {N}",E=E,Tp=0,columns=f'proc{s}',target=f'proc{t}',showPlot=False)
        sp=sp.dropna(); rs=np.corrcoef(sp['Observations'],sp['Predictions'])[0,1]
        print(f'E={E} {lab}: pyEDM.CCM {ccmv:.15f} | pyEDM.Simplex(lib=pred=all,Tp=0) {rs:.15f} | plain-stable {rp:.15f} | tie-expanded {rt:.15f} (rows expanded {ne}) | CCM-tie {ccmv-rt:.1e} CCM-plain {ccmv-rp:.1e} Simplex-tie {rs-rt:.1e} Simplex-plain {rs-rp:.1e}')
