import yaml, sys
R='/media/dan/Data/git/pyspi/audit/records/'
PROBE='fable_recheck_cdt_ccm_gwtau/ccm_tie_probe.py'
NUM={1:dict(ccm='0.258036085716451',plain='0.016209343992146',tie='0.449407364219300',dp='0.24',dt='-0.19',sim='1.7e-16'),
     10:dict(ccm='0.412996812927705',plain='0.408547833137669',tie='0.438997955936925',dp='4.4e-3',dt='-2.6e-2',sim='0.0')}

OLD_TIES=('Neighbour ties: when the (E+1)-th neighbour distance is tied, cppEDM keeps every library row tied at that distance and rescales the weights from the first tied neighbour onward by tieFactor (EDM_Neighbors.cc L276-345, Simplex.cc L90-157), and exactly-zero distances get weight 1 with all others at the 1e-6 floor (Simplex.cc L57-70), so the neighbour set can exceed E+1. On logistic_maps the embedded process 1 (period-4 driver, 4 distinct values) has tied neighbours at every prediction row (probe fable_dt3/fm2.py, T=256, full library: 256 of 256 rows at E=1, 247 of 247 at E=10), so the whole ccmf[1,0] curve on that dataset comes from the tie-expansion path, not from an ordinary E+1-neighbour simplex.')
NEW_TIES=('Neighbour ties: cppEDM tie detection runs only when parameters.method == Method::Simplex (EDM_Neighbors.cc L282); CCM builds its Parameters with Method::CCM (API.cc L659) and reuses them unchanged in colToTarget/targetToCol (CCM.cc L21-26) and in the per-sample local SimplexClass (CCM.cc L342), so ties/anyTies stay false, the tie expansion in Simplex.cc L93-157 never runs, and exactly knn = E+1 neighbours are used: the first E+1 entries of std::sort by distance only (DistanceCompare, Common.cc L10-13; EDM_Neighbors.cc L226), whose order among equal distances is unspecified (std::sort is not stable). Exactly-zero distances still get weight 1 with all others at the 1e-6 floor (Simplex.cc L57-70). On logistic_maps the embedded process 1 (period-4 driver, 4 distinct values) has a tie at the (E+1)-th neighbour distance at every prediction row (probe fable_dt3/fm2.py, T=256, full library: 256 of 256 rows at E=1, 247 of 247 at E=10), so the whole ccmf[1,0] curve on that dataset depends on which equal-distance rows std::sort places first. Probe '+PROBE+' (T=256, full library, random=False), proc1:proc0: pyEDM.CCM 0.258036085716451 (E=1) and 0.412996812927705 (E=10) vs a tie-expanded reference 0.449407364219300 / 0.438997955936925 (which pyEDM.Simplex(lib=pred=all, Tp=0) reproduces to <= 1.7e-16) and a plain stable-argsort E+1 reference 0.016209343992146 / 0.408547833137669; the tie-free column proc0:proc1 matches both references to <= 3.3e-16.')

OLD_FN='sort, take knn; tie bookkeeping'
NEW_FN=('sort (std::sort L226 with DistanceCompare, Common.cc L10-13: distance only, order among equal distances unspecified), take the first knn; tie bookkeeping (L276-345) is gated on parameters.method == Method::Simplex (L282) and is skipped for CCM (Method::CCM, API.cc L659)')
OLD_SX=('tie expansion (L90-157: neighbour set extended to all rows tied with the knn-th distance, flagged in EDM_Neighbors.cc L276-345, weights from the first tie onward scaled by tieFactor)')
NEW_SX=('tie expansion (L93-157, entered only if anyTies) is never reached in CCM: tie detection (EDM_Neighbors.cc L282) runs only for Method::Simplex, and CCM\'s colToTarget/targetToCol (CCM.cc L21-26) and per-sample SimplexClass (CCM.cc L342) keep Method::CCM, so exactly knn = E+1 neighbours are used')
OLD_DC=('(cppEDM additionally expands tied neighbour sets, Simplex.cc L90-157, a tie rule Sugihara 2012 does not specify; it changes values only when neighbour distances tie, e.g. the period-4 process of logistic_maps)')
NEW_DC=('(Sugihara 2012 does not specify a tie rule; when the (E+1)-th neighbour distance is tied, cppEDM CCM keeps the first E+1 entries of std::sort by distance with no tie expansion (the expansion in Simplex.cc L93-157 is gated to Method::Simplex, EDM_Neighbors.cc L282), so the neighbours chosen among equal distances depend on the implementation-defined sort order; this affects values only when neighbour distances tie, e.g. the period-4 process of logistic_maps)')
OLD_R0=('To cover tied neighbours the reference must also implement cppEDM tie handling (zero-distance weights, Simplex.cc L57-70; tie detection EDM_Neighbors.cc L276-345; tie expansion and tieFactor, Simplex.cc L90-157); a plain E+1 argsort reference is valid only for tie-free columns')
NEW_R0=('The reference must implement the zero-distance weight rule (Simplex.cc L57-70) and must not implement tie expansion (gated to Method::Simplex, EDM_Neighbors.cc L282, so CCM never expands ties). Where the (E+1)-th neighbour distance is tied, CCM keeps the first E+1 entries of an unstable std::sort, so no order-independent reference can reproduce those columns; the exact comparison is restricted to tie-free columns')
def old_e0(E,n): return ('is expected to match only if the reference implements the cppEDM tie handling; a plain E+1 reference differs (probe at E=%d: pyEDM %s vs plain reference %s, diff %s). Report the tied column separately from the tie-free columns.'%(E,n['ccm'],n['plain'],n['dp']))
def new_e0(E,n): return ('is not expected to match any order-independent reference (probe '+PROBE+' at E=%d: pyEDM.CCM %s vs plain stable-argsort E+1 reference %s, diff %s, and vs tie-expanded reference %s, diff %s, although pyEDM.Simplex reproduces the tie-expanded value to %s). Report the tied column separately as irreproducible (it depends on std::sort order among equal distances); the pass criterion applies to the tie-free columns only.'%(E,n['ccm'],n['plain'],n['dp'],n['tie'],n['dt'],n['sim']))
OLD_C3=('is produced entirely by cppEDM tie expansion (ties at every prediction row), so no plain E+1-neighbour reference reproduces that column (probe fable_dt3/fm2.py)')
NEW_C3=('has a tie at the (E+1)-th neighbour distance at every prediction row and depends on std::sort order among equal distances (CCM does not expand ties, EDM_Neighbors.cc L282), so no order-independent reference reproduces that column (probes fable_dt3/fm2.py, '+PROBE+')')
OLD_RP='so both directions share library subsets.'
NEW_RP=('so both directions share library subsets. A second implementation-defined element: when the (E+1)-th neighbour distance is tied, CCM keeps the first E+1 rows of std::sort (not stable; DistanceCompare compares distance only, Common.cc L10-13, EDM_Neighbors.cc L226) with no tie expansion (gated to Method::Simplex, EDM_Neighbors.cc L282), so tied columns (e.g. logistic_maps proc1:proc0) may also differ between standard-library implementations.')

def rep(s,old,new,what):
    assert s.count(old)==1,(what,s.count(old)); return s.replace(old,new)

for u,E,knn_old,knn_new in (('E-None',10,'knn = E+1 = 11 (more with ties, see below)','knn = E+1 = 11 (exactly E+1: CCM does not expand ties, see below)'),
                            ('E-1',1,'knn = 2 (more with ties, see below)','knn = 2 (exactly E+1: CCM does not expand ties, see below)'),
                            ('E-10',10,'knn = 11 (more with ties, see below)','knn = 11 (exactly E+1: CCM does not expand ties, see below)')):
    p=R+f'causal.ccm.{u}.yaml'; d=yaml.safe_load(open(p)); c=d['correctness']
    s=c['implemented_as']; s=rep(s,knn_old,knn_new,u+' knn'); s=rep(s,OLD_TIES,NEW_TIES,u+' ties'); c['implemented_as']=s
    tr=c['implementation_trace']; nfn=nsx=0
    for i,t in enumerate(tr):
        if 'EDM_Neighbors.cc#L74-L365' in t: tr[i]=rep(t,OLD_FN,NEW_FN,u+' fn'); nfn+=1
        if 'Simplex.cc#L34-L167' in t: tr[i]=rep(tr[i],OLD_SX,NEW_SX,u+' sx'); nsx+=1
    assert nfn==1 and nsx==1
    c['deviation_from_canonical']=rep(c['deviation_from_canonical'],OLD_DC,NEW_DC,u+' dc')
    pc=c['proposed_checks']
    pc[0]['reference']=rep(pc[0]['reference'],OLD_R0,NEW_R0,u+' r0')
    pc[0]['expected_outcome']=rep(pc[0]['expected_outcome'],old_e0(E,NUM[E]),new_e0(E,NUM[E]),u+' e0')
    pc[3]['expected_outcome']=rep(pc[3]['expected_outcome'],OLD_C3,NEW_C3,u+' c3')
    nc=c['new_finding_candidates']; k=[i for i,t in enumerate(nc) if t.startswith('CANDIDATE reproducibility')]; assert len(k)==1
    nc[k[0]]=rep(nc[k[0]],OLD_RP,NEW_RP,u+' rp')
    open(p,'w').write(yaml.safe_dump(d,sort_keys=False,width=120,allow_unicode=True))
    print('ok',u)
