import sys, io, contextlib, numpy as np, warnings
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
warnings.filterwarnings('ignore')
import pyspi.statistics.infotheory as it
from pyspi.data import Data
for ds in ['bivariate_gaussian_T256', 'var2_bivariate_T256']:
    x = np.load('/media/dan/Data/git/pyspi/audit/checks/data/%s.npz' % ds)['x']
    with contextlib.redirect_stdout(io.StringIO()):
        d = Data(x, dim_order='ps', normalise=True)
        je = it.JointEntropy(estimator='kernel', kernel_width=0.25).bivariate(d, i=0, j=1)
        ce = it.ConditionalEntropy(estimator='kernel', kernel_width=0.25).bivariate(d, i=0, j=1)
    print('%s direct W-0.25 A01 je=%.10f ce=%.10f' % (ds, je, ce))
