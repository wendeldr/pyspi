import numpy as np
from spectral_connectivity import Multitaper
rng=np.random.default_rng(0)
for T in (64,256,1024):
    x=rng.standard_normal((T,3)); x[:,2]=x[:,0]  # bit-identical pair (0,2)
    m=Multitaper(x[:,None,:] if False else x, sampling_frequency=1)
    X=m.fft()  # (time, trials, tapers, freq, signals)
    X=X.reshape(-1, X.shape[-2], X.shape[-1])
    S=X[...,:,None]*np.conj(X[...,None,:])
    off=~np.eye(3,dtype=bool)
    dc=np.abs(S[:,0].imag)[:,off].max()
    diag=np.abs(np.einsum('kfii->kfi',S[:,1:]).imag).max()
    pair=np.abs(S[:,1:,0,2].imag).max()
    print(T,'DC offdiag max|ImS|',dc,'diag nonDC',diag,'identical pair nonDC',pair, 'fft DC imag max',np.abs(X[:,0].imag).max())
