# Probe: E=None embedding selection: pyspi uses embed_df.max()["E"] (column-wise max of E) vs argmax rho
import sys, numpy as np, pandas as pd, pyEDM
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import make_data
from scipy.stats import zscore
for name in ('logistic_maps','iid_gaussian','var2_bivariate'):
    x=make_data.load(name,256)['x'][:2]
    z=zscore(x,axis=1,ddof=1); N=z.shape[1]
    df=pd.DataFrame(np.c_[np.arange(N),z.T],columns=['index','proc0','proc1'])
    for c in ('proc0','proc1'):
        pred=f"10 {N-10}"
        ed=pyEDM.EmbedDimension(dataFrame=df,lib=pred,pred=pred,columns=c,showPlot=False)
        print(name,c,'pyspi E =',ed.max()['E'],' argmax-rho E =',int(ed.loc[ed['rho'].idxmax(),'E']),' rho by E:',np.round(ed['rho'].values,3))
