# Analytic library-size schedule: pyspi causal.py:128-131 + cppEDM Parameter.cc:228-279, truncated by causal.py:143
import numpy as np
for N in (64,256,1024,4096):
    for E in (1,10):
        up=int(np.floor((N-E-1)/10)*10); lo=int(np.ceil(2*E/10)*10); inc=int((up-lo)/21)
        n=(up-lo)//inc+1; libs=[lo+k*inc for k in range(n)]
        print(f"T={N} E={E}: libSizes='{lo} {up} {inc}' -> cppEDM {n} sizes {libs[0]}..{libs[-1]}; pyspi keeps 22: {libs[0]}..{libs[21]} (upper {up}); N_row={N-E+1}")
