# Probe: pyspi CCM direction convention on logistic_maps (process 1 = y CAUSES process 0 = x)
import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import make_data
from pyspi.statistics.causal import ConvergentCrossMapping as C
from pyspi.data import Data
T=int(sys.argv[1]) if len(sys.argv)>1 else 256
for name in ('logistic_maps','logistic_maps_bidir'):
    x=make_data.load(name,T)['x']
    d=Data(x,normalise=True)
    for E in (1,2):
        for st in ('mean','max','diff'):
            A=C(statistic=st,embedding_dimension=E).multivariate(d)
            print(name,T,'E',E,st,np.array2string(A,precision=4).replace('\n',' '))
    ccmf=d.ccm[2]
    print('ccmf[0,1,:5] (embed proc0 predict proc1):',np.round(ccmf[0,1,:5],4))
    print('ccmf[1,0,:5] (embed proc1 predict proc0):',np.round(ccmf[1,0,:5],4))
    print('diag ccmf[0,0] all zero:',np.all(ccmf[0,0]==0), 'ccmf shape',ccmf.shape)
