# Probe: E-None equals E-10 (known bug 2) on a check dataset
import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); import make_data
from pyspi.statistics.causal import ConvergentCrossMapping as C
from pyspi.data import Data
x=make_data.load('var2_bivariate',256)['x']
for st in ('mean','diff'):
    a=C(statistic=st,embedding_dimension=None).multivariate(Data(x)); b=C(statistic=st,embedding_dimension=10).multivariate(Data(x))
    print(st,'E-None==E-10:',np.array_equal(a,b),np.round(a,4).tolist())
