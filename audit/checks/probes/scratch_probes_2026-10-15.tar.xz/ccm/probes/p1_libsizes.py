# Probe: library-size schedule pyspi requests and what cppEDM returns; truncation to 22 rows.
import numpy as np, pandas as pd, pyEDM
def sched(N,E,nlibs=21):
    upperE = int(np.floor((N - E - 1) / 10) * 10)
    lowerE = int(np.ceil(2 * E / 10) * 10)
    inc = int((upperE - lowerE) / nlibs)
    return lowerE, upperE, inc
rng=np.random.default_rng(0)
for N in (64,100,256,1024,4096):
    for E in (1,2,10):
        lo,up,inc=sched(N,E)
        if inc<1:
            print(N,E,'inc<1', lo,up,inc); continue
        nlib=(up-lo)//inc+1
        z=rng.standard_normal((2,N))
        df=pd.DataFrame(np.c_[np.arange(N),z.T],columns=['index','proc0','proc1'])
        try:
            out=pyEDM.CCM(dataFrame=df,E=E,columns='proc0',target='proc1',libSizes=f"{lo} {up} {inc}",sample=100,seed=42)
            ls=out['LibSize'].values
            print(f"N={N} E={E} lib='{lo} {up} {inc}' cppEDM_rows={len(ls)} expected={nlib} used_first22_max={ls[:22].max():.0f} upper={up} cols={list(out.columns)}")
        except Exception as e:
            print(N,E,'ERR',e)
