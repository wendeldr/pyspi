# Probe: confirm the trace by reproducing cppEDM CCM (random=False, full library) from scratch with numpy,
# and confirm column semantics 'A:B' = embed A, predict B.
import numpy as np, pandas as pd, pyEDM
def xmap(src, tgt, E, lib_rows=None):
    N=len(src); rows=np.arange(E-1,N)            # AdjustLibPred drops first tau*(E-1) partial rows
    emb=np.stack([src[rows-k] for k in range(E)],1)  # tau=-1: x(t), x(t-1), ...
    lib = rows if lib_rows is None else lib_rows
    L=np.stack([src[lib-k] for k in range(E)],1)
    pred=np.empty(len(rows))
    for a,(t,v) in enumerate(zip(rows,emb)):
        d=np.sqrt(((L-v)**2).sum(1)); d[lib==t]=np.inf  # self excluded
        o=np.argsort(d,kind='stable')[:E+1]; dk=d[o]
        w=np.exp(-dk/dk.min()) if dk.min()>0 else (dk==0).astype(float)
        w=np.maximum(w,1e-6); pred[a]=(w*tgt[lib[o]]).sum()/w.sum()
    return np.corrcoef(tgt[rows],pred)[0,1]
rng=np.random.default_rng(3); N=300
x0=rng.uniform(-1,1,N); x1=x0**2+0.05*rng.standard_normal(N)
df=pd.DataFrame(np.c_[np.arange(N),x0,x1],columns=['index','proc0','proc1'])
for E in (1,3):
    out=pyEDM.CCM(dataFrame=df,E=E,columns='proc0',target='proc1',libSizes=f"{N-E+1}",random=False)
    print('E',E,'pyEDM',out.iloc[0].to_dict())
    print('   scratch proc0:proc1 (embed x0 predict x1)=',xmap(x0,x1,E),' proc1:proc0=',xmap(x1,x0,E))
