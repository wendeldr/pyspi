# Probe: short series behaviour and output columns
import numpy as np, pandas as pd, pyEDM, warnings
from pyspi.statistics.causal import ConvergentCrossMapping as C
from pyspi.data import Data
rng=np.random.default_rng(1)
for T in (50,55,64):
    x=rng.standard_normal((2,T))
    for E in (1,10):
        try:
            A=C(embedding_dimension=E).multivariate(Data(x))
            print('T',T,'E',E,'ok',np.round(A,3).tolist())
        except Exception as e:
            print('T',T,'E',E,'EXC',type(e).__name__,str(e)[:120])
N=64; z=rng.standard_normal((2,N))
df=pd.DataFrame(np.c_[np.arange(N),z.T],columns=['index','proc0','proc1'])
out=pyEDM.CCM(dataFrame=df,E=10,columns='proc0',target='proc1',libSizes="20 50 1",sample=100,seed=42)
print('columns',list(out.columns)); print('LibSize rows',len(out),'first22 last',out.LibSize.values[21],'last',out.LibSize.values[-1])
# self-consistency: same seed, separate calls identical
out2=pyEDM.CCM(dataFrame=df,E=10,columns='proc0',target='proc1',libSizes="20 50 1",sample=100,seed=42)
print('repeat identical',np.array_equal(out.values,out2.values))
# what does includeData parameters say about version and knn
cm=pyEDM.CCM(dataFrame=df,E=2,columns='proc0',target='proc1',libSizes="10 50 10",sample=5,seed=42,includeData=True,parameterList=True)
p=cm['parameters']; print({k:p[k] for k in ('version','knn','tau','Tp','exclusionRadius','randomLib','replacement','seed','subSamples','libSizes') if k in p})
