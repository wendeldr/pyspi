import yaml
from pathlib import Path
OUT = Path('/media/dan/Data/git/pyspi/audit/records')
CPP = 'https://github.com/SugiharaLab/cppEDM/blob/v1.15.2/src/'

DOC = ('supplement §1.3.5, p.8-9 (pack lines 381-413): "there is a causal influence from time series x → y if the '
       'Takens time-delay embedding of y can be used to predict the observations of x"; E-None: "we infer the embedding '
       'dimension to be the maximum of the two univariate delay embeddings that best predicted each time series"; '
       '"we use 21 uniformly sampled library sizes between this minimum and maximum"; "summary statistics of the mean '
       '(modifier mean) and the maximum (max) across the curves"; keywords list "unsigned". The supplement lists six ccm SPIs '
       '(no diff). GitBook spi-descriptions/causal-inference.md (Convergent Cross-Mapping) repeats this text and adds '
       '"mean (mean), maximum (max) and difference (diff) across the curves" without defining diff; it lists all nine identifiers.')

CANON_REF = ('Sugihara G, May R, Ye H, Hsieh C-h, Deyle E, Fogarty M, Munch S (2012) Detecting causality in complex ecosystems. '
             'Science 338(6106):496-500, main text and Supplementary Materials (cross-map estimate, simplex weights, convergence '
             'criterion); simplex projection: Sugihara G & May RM (1990) Nature 344:734-741; E selection by simplex forecast skill: '
             'Sugihara & May 1990 and Chang, Ushio & Hsieh (2017) Ecol Res 32:785-796.')

CANON_DEF = ('Shadow manifold M_X = {x(t) = (X(t), X(t-tau), ..., X(t-(E-1)tau))}. For each t take the E+1 nearest library '
             'neighbours x(t_1..t_{E+1}) of x(t) (t itself excluded), u_i = exp(-d(x(t),x(t_i))/d(x(t),x(t_1))), w_i = u_i/sum u; '
             'cross-map estimate Yhat(t)|M_X = sum_i w_i Y(t_i); skill rho(L) = Pearson corr(Y, Yhat|M_X) for random libraries of '
             'length L. Y causes X ("X <- Y") is inferred when rho(Y|M_X) increases with L and converges; the two directions are '
             'compared. Convergence, not a summary of the curve, is the causal criterion.')

COMMON_TRACE = [
    'pyspi/statistics/causal.py:68-78 ConvergentCrossMapping(Directed, Signed); identifier ccm_E-{E}_{statistic}; __init__(statistic="mean", embedding_dimension=None)',
    'pyspi/statistics/causal.py:80-82 cache key = self._E (shared by mean/max/diff of one E on the same Data object)',
    'pyspi/statistics/causal.py:84-96 on cache miss: z = data.to_numpy(squeeze=True) (data.py:108-118), DataFrame with float "index" time column + proc0..proc{M-1}',
    'pyspi/data.py:193-195 default pipeline z-scores each process (zscore ddof=1); detrend default False (data.py:63, 184-191)',
    'pyspi/statistics/causal.py:116-117 nlibs = 21; ccmf = zeros((M, M, 22)) (diagonal stays 0)',
    'pyspi/statistics/causal.py:118-125 loop over unordered pairs i<j; E = int(max(embedding[[i, j]])) (same E both directions); except NameError branch is dead',
    'pyspi/statistics/causal.py:127-131 upperE = floor((N-E-1)/10)*10; lowerE = ceil(2E/10)*10; inc = int((upperE-lowerE)/21); libSizes string "lowerE upperE inc"',
    'pyspi/statistics/causal.py:134-142 pyEDM.CCM(dataFrame=df, E=E, columns=proc_i, target=proc_j, libSizes=lib_sizes, sample=100, seed=42); all other args default',
    'pyspi/statistics/causal.py:143-144 ccmf[i, j] = column 1 ("proc_i:proc_j") first 22 rows; ccmf[j, i] = column 2 ("proc_j:proc_i") first 22 rows',
    'pyspi/statistics/causal.py:146-150 cache ccmf in data.ccm[E]',
    'pyspi/statistics/causal.py:152-163 mean = nanmean(ccmf, axis=2); max = nanmax(ccmf, axis=2); diff = nanmean(ccmf - ccmf^T, axis=2)',
    'pyspi/calculator.py:293-303 Calculator.compute: np.fill_diagonal(S, nan); any exception -> whole matrix NaN with a warning',
    'pyspi/base.py:84-94 generic Directed.multivariate convention A[i,j] = bivariate(i, j) (e.g. TE i->j, statistics/infotheory.py:377-383); ccm overrides multivariate',
    '.venv/lib/python3.12/site-packages/pyEDM/CoreEDM.py:363-385 CCM signature defaults: Tp=0, knn=0, tau=-1, exclusionRadius=0, random=True, replacement=False, embedded=False',
    '.venv/lib/python3.12/site-packages/pyEDM/CoreEDM.py:389-426 GetDF (AuxFunc.py:137-166 -> PandasDataFrametoDF AuxFunc.py:176-228, first column = time) then pyBindEDM.CCM(...)',
    '.venv/lib/python3.12/site-packages/pyEDM/CoreEDM.py:428-454 returns LibMeans DataFrame: columns LibSize, "col:target", "target:col"',
    'pyBindEDM.cpython-312-x86_64-linux-gnu.so = cppEDM 1.15.2 (parameterList reports version "1.15.2 2023-11-27"); source ' + CPP,
    CPP + 'API.cc#L635-L708 CCM(DataFrame): lib = pred = "1 N" (all rows), Parameters(Method::CCM, ...), CCMClass.Project()',
    CPP + 'Parameter.cc#L198-L291 libSizes "start stop increment": sequence if increment < stop; increment < 1 throws "CCM librarySizes increment ... is invalid"; N_lib = (stop-start)/increment + 1',
    CPP + 'Parameter.cc#L297-L316 Simplex/CCM: knn < 1 -> knn = E+1',
    CPP + 'Parameter.cc#L643-L721 AdjustLibPred: drop the first |tau|(E-1) rows (partial embedding vectors) from lib and pred',
    CPP + 'CCM.cc#L34-L51 Project: SetupParameters, PrepareEmbedding + Distances for both mappings, CCM(), FormatOutput',
    CPP + 'CCM.cc#L426-L434 SetupParameters: targetToCol swaps columns and target (reverse mapping)',
    CPP + 'CCM.cc#L139-L203 CrossMap: N_row = rows - (E-1); RNG std::default_random_engine(seed) created per direction with the same seed (42)',
    CPP + 'CCM.cc#L213-L286 per libSize: 100 samples; lib rows drawn uniformly without replacement (std::uniform_int_distribution + unordered_set rejection)',
    CPP + 'CCM.cc#L342-L380 per sample: subset allDistances to lib_i, FindNeighbors, Simplex, ComputeError(Observations, Predictions) over ALL prediction rows',
    CPP + 'CCM.cc#L403-L409 LibStats row = (libSize, mean rho over samples, mean RMSE, mean MAE)',
    CPP + 'CCM.cc#L475-L491 FormatOutput names "LibSize col:target target:col"; col:target = colToTarget = embed columns, predict target',
    CPP + 'EDM_Neighbors.cc#L388-L448 Distances: Euclidean between delay vectors (pred row == lib row left at DistanceMax)',
    CPP + 'EDM_Neighbors.cc#L74-L365 FindNeighbors: skip libRow == predictionRow (L153-155), exclusionRadius only if nonzero (L173-178, here 0), sort, take knn; tie bookkeeping',
    CPP + 'Simplex.cc#L34-L167 weights exp(-d/d_min) (all-zero-distance special case), floor 1e-6, tie expansion; prediction = sum(w*target[nn+Tp])/sum(w), Tp = 0',
    CPP + 'Common.cc#L100-L219 ComputeError: NaN-trimmed slice, Pearson rho; denom 0 or NaN -> rho = 0',
]

EMBED_TRACE = [
    'pyspi/statistics/causal.py:98-111 E=None: for each process pyEDM.EmbedDimension(dataFrame=df, lib=pred="10 N-10", columns=proc_i, showPlot=False); embedding[i] = embed_df.max()["E"] (column-wise maximum of the E column = 10), not the E at max rho',
    '.venv/lib/python3.12/site-packages/pyEDM/CoreEDM.py:459-526 EmbedDimension defaults maxE=10, Tp=1, tau=-1, exclusionRadius=0, numThreads=4; returns DataFrame columns E, rho',
    CPP + 'Eval.cc#L132-L207 EmbedDimension: Simplex for E = 1..maxE in worker threads (EmbedThread L212-), E_rho table',
]

def checks_common(E_label):
    return [
        dict(datasets=['logistic_maps', 'nonlinear_dependence', 'var2_bivariate'], path='kernel',
             reference='from-scratch numpy simplex cross-map (Sugihara 2012 SOM: E+1 nearest neighbours by Euclidean distance on tau=1 delay vectors, self excluded, weights exp(-d/d_min) floored at 1e-6, Tp=0, Pearson rho over prediction rows E-1..N-1) with the full deterministic library; compared with pyEDM.CCM(random=False, libSizes=str(N-E+1)) at E=' + E_label + '; T in {256, 1024}',
             reference_kind='independent-impl', criterion='exact',
             expected_outcome='max |rho_scratch - rho_pyEDM| < 1e-12 for both columns (a trace probe already matched to ~1e-16 for E=1 and E=3 on a toy x1=x0^2 pair); establishes that "col:target" = predict target from the embedding of col'),
        dict(datasets=['logistic_maps', 'iid_gaussian'], path='kernel',
             reference='same from-scratch cross-map with random libraries drawn with numpy (100 libraries per L, without replacement, from rows E-1..N-1) on the pyspi library-size schedule; optional exact variant: re-implement libstdc++ std::minstd_rand0 + std::uniform_int_distribution with seed 42 to reproduce cppEDM library draws',
             reference_kind='independent-impl', criterion='statistical',
             expected_outcome='for every L, |mean_rho_scratch(L) - LibMeans_pyEDM(L)| <= 4*sqrt(2)*SE(L) with SE from the per-library spread; the optional RNG replica should match to 1e-12'),
        dict(datasets=['iid_gaussian', 'var2_bivariate'], path='pipeline',
             reference='numpy on pyspi\'s own cached curve data.ccm[E] plus analytic library schedule (lowerE = ceil(2E/10)*10, upperE = floor((T-E-1)/10)*10, inc = floor((upperE-lowerE)/21), cppEDM sequence start..stop step inc, first 22 kept)',
             reference_kind='analytic', criterion='exact',
             expected_outcome='mean == nanmean(ccmf, 2), max == nanmax(ccmf, 2), diff == mean - mean^T (|diff| < 1e-15) and diff antisymmetric; ccmf shape (M, M, 22); at T=64 the curve covers only the first 22 of the cppEDM sizes (E=1: 10..52 of 10..60; E=10: 20..41 of 20..50)'),
        dict(datasets=['logistic_maps', 'logistic_maps_bidir', 'var2_bivariate'], path='pipeline',
             reference='Sugihara 2012 criterion on a system with known coupling (logistic_maps: process 1 (y) drives process 0 (x)); pyspi direction convention established from TransferEntropy/Granger (A[i,j] = i->j, infotheory.py:377-383) on var2_bivariate (0 -> 1)',
             reference_kind='analytic', criterion='direction',
             expected_outcome='A_mean[0,1] > A_mean[1,0] and diff[0,1] > 0 on logistic_maps at T in {1024, 4096} (probe at T=256, E=1: 0.5484 vs 0.2913; E=2: 0.7415 vs 0.3226), i.e. a large A[i,j] means j -> i, the transpose of pyspi\'s TE/GC orientation. Caveat: in logistic_maps the uncoupled driver y (r=3.5) is periodic; repeat on a check-generated chaotic-driver Sugihara system before relying on it'),
        dict(datasets=['iid_gaussian'], path='pipeline',
             reference='analytic null: independent processes have no cross-map skill (rho -> 0)',
             reference_kind='analytic', criterion='statistical',
             expected_outcome='at T in {1024, 4096} all off-diagonal |A_mean| and |A_max| small (expected < 0.1, the bias of small-library rho is the open part), diff off-diagonal centred on 0'),
        dict(datasets=['bivariate_gaussian', 'scaled_offset'], path='kernel',
             reference='analytic invariance: kNN sets and exp(-d/d_min) weights are invariant to positive rescaling of the embedded series; Pearson rho is invariant to affine maps of the target; so pyEDM.CCM on raw scaled_offset equals pyEDM.CCM on the same-draw bivariate_gaussian',
             reference_kind='analytic', criterion='tolerance',
             expected_outcome='LibMeans equal within 1e-10 (positive scales only; a negative scale of the target flips sign of rho)'),
    ]

def rec(uid, E_label, extra_trace, implemented, dev_doc, dev_can, already, cands, extra_checks, units_extra=''):
    return {
        'unit_id': uid,
        'status': 'traced',
        'correctness': {
            'metric_name_standard': 'Convergent cross mapping (CCM) cross-map skill rho(L) = corr(X_j, Xhat_j | M_{X_i}) summarised over library sizes L (mean, max) and the directional skill difference (diff)',
            'canonical_ref': CANON_REF,
            'canonical_definition': CANON_DEF,
            'documented_definition': DOC,
            'delegate_lib': 'pyEDM==1.15.2.0 (cppEDM 1.15.2, 2023-11-27, compiled in pyBindEDM): pyEDM.CCM(dataFrame, E=' + E_label + ', columns=proc_i, target=proc_j, libSizes="lowerE upperE inc", sample=100, seed=42) with defaults Tp=0, knn=0 -> E+1, tau=-1, exclusionRadius=0, random=True, replacement=False' + (' ; plus pyEDM.EmbedDimension(lib=pred="10 N-10", maxE=10, Tp=1) per process' if E_label == 'None->10' else ''),
            'implemented_as': implemented,
            'implementation_trace': COMMON_TRACE[:4] + (extra_trace if uid.endswith('None') else ['pyspi/statistics/causal.py:112-113 fixed E: embedding = np.array([E] * M), so E = ' + E_label + ' for every pair and both directions']) + COMMON_TRACE[4:],
            'deviation_from_documented': dev_doc,
            'deviation_from_canonical': dev_can,
            'units_and_range': 'Dimensionless Pearson correlations. mean and max in [-1, 1] (negative values occur; cppEDM returns rho = 0, not NaN, when either vector has zero variance, Common.cc L205-207); diff in [-2, 2] and antisymmetric (diff = mean - mean^T). Diagonal: 0 from a direct .multivariate call (ccmf initialised to zeros), NaN after Calculator.compute. Whole matrix NaN when cppEDM throws (short series). Not symmetric for mean/max.' + units_extra,
            'direction_convention': 'A[i,j] = summary over L of rho(x_j | M_{x_i}): skill of predicting process j from the delay embedding of process i (pyEDM column "proc_i:proc_j", causal.py:143). By Sugihara\'s criterion a large A[i,j] is evidence that j causes i (j -> i), the transpose of pyspi\'s generic Directed orientation A[i,j] = i -> j (base.py:91-93; TE infotheory.py:377-383). diff[i,j] = mean_L[rho(x_j|M_i) - rho(x_i|M_j)] > 0 means j -> i dominates. Probe (logistic_maps T=256, process 1 drives process 0, E=2): A_mean[0,1] = 0.7415 > A_mean[1,0] = 0.3226, diff[0,1] = +0.4188. To be confirmed in the check stage.',
            'symmetry_expected': 'asym',
            'already_documented': already,
            'new_finding_candidates': cands,
            'proposed_checks': checks_common(E_label if E_label != 'None->10' else '10') + extra_checks,
        },
    }

COMMON_CANDS = [
    'CANDIDATE orientation: pyspi stores ccmf[i,j] = pyEDM column "proc_i:proc_j" = rho(x_j | M_{x_i}) (causal.py:134-144; cppEDM CCM.cc L475-491 names col:target for the colToTarget mapping, which embeds columns and predicts target). Under the documented reading "x -> y if the embedding of y predicts x", A[i,j] large means j -> i, the opposite of pyspi\'s Directed convention A[i,j] = i -> j (base.py:91-93, TE infotheory.py:377-383). Evidence: probe on logistic_maps T=256 (process 1 drives process 0), E=1 mean [[0, 0.5484], [0.2913, 0]], E=2 mean [[0, 0.7415], [0.3226, 0]]; from-scratch probe: "proc0:proc1" reproduced exactly by embedding x0 and predicting x1 (0.972222487974537 vs 0.9722224879745365).',
    'CANDIDATE library schedule: the curve has 22 points, not the documented 21 (nlibs + 1, causal.py:116-117, 143), and at short T it is truncated: cppEDM expands "lo up inc" to (up-lo)//inc + 1 sizes (Parameter.cc L271-279), pyspi keeps the first 22. Probe: libSizes "20 50 1" (T=64, E=10) -> "LibSize rows 31 first22 last 41.0 last 50.0"; analytic: T=64 E=1 keeps 10..52 of 10..60, T=256 E=10 keeps 20..230 of 20..240. The maximum library used is below the documented upper bound.',
    'CANDIDATE short-series failure: inc = int((upperE-lowerE)/21) is 0 when upperE-lowerE < 21 and cppEDM throws. Probe: T=50 and T=55 with E=10 -> "RuntimeError Parameters::Validate(): CCM librarySizes increment 0 is invalid."; analytic threshold T <= 60 for E=10 (and E=None) and T <= 41 for E=1. Calculator.compute turns this into an all-NaN matrix with a warning (calculator.py:301-303).',
    'CANDIDATE no temporal exclusion: exclusionRadius=0 (CoreEDM.py:372 default, not overridden) so only the prediction row itself is excluded (EDM_Neighbors.cc L153-155); temporally adjacent library vectors can be nearest neighbours, which may inflate rho for autocorrelated or oversampled signals (e.g. EEG). tau is fixed at 1 sample. Hypothesis to quantify with a from-scratch cross-map with a Theiler window.',
    'CANDIDATE reproducibility: random libraries come from std::default_random_engine and std::uniform_int_distribution (CCM.cc L203, L220), both implementation-defined in C++, so values with seed=42 may differ between builds/platforms (libstdc++ vs libc++); the same seed is used for both directions and every pair, so both directions share library subsets.',
    'CANDIDATE diagonal: ccmf is created with np.zeros and only i != j are filled (causal.py:117-144), so a direct ConvergentCrossMapping.multivariate call returns 0 on the diagonal (probe: "diag ccmf[0,0] all zero: True"); only Calculator.compute sets NaN (calculator.py:296-297).',
    'CANDIDATE labels: supplement keywords and config.yaml:371-376 say "unsigned", the class is Signed (causal.py:68, 72); the code label is the consistent one because rho and diff are negative in practice (probe diff [[0, 0.2571], [-0.2571, 0]]). Documentation-only inconsistency.',
]

# ---------- E-None
impl_none = ('Default pipeline z-scores each process. E=None: for each process, pyEDM.EmbedDimension (simplex, Tp=1, lib = pred = rows 10..N-10, E = 1..10) is run and embedding[i] = embed_df.max()["E"], the column maximum of E, which is always 10 (known bug 2), so E = 10 for every pair. Then for each unordered pair (i<j) one pyEDM.CCM call with E = max(E_i, E_j) = 10, tau = 1 sample, Tp = 0, knn = E+1 = 11, no exclusion radius (self excluded), 100 random libraries per size drawn without replacement (seed 42), library sizes lowerE = 20 to upperE = floor((T-11)/10)*10 in steps floor((upperE-20)/21), first 22 sizes kept. Each library size gives the mean over 100 libraries of Pearson rho between observed and cross-mapped values over all prediction rows (rows 9..T-1). ccmf[i,j,:] = rho(x_j | M_{x_i})(L); ccmf[j,i,:] = rho(x_i | M_{x_j})(L). Statistics: mean = nanmean over the 22 L, max = nanmax over L, diff = nanmean over L of ccmf - ccmf^T. The result is bitwise identical to causal.ccm.E-10 (probe on var2_bivariate T=256: "mean E-None==E-10: True", "diff E-None==E-10: True").')

dev_doc_none = ('(1) Documented E = "maximum of the two univariate delay embeddings that best predicted each time series"; code takes embed_df.max()["E"] = 10 for every process (known bug 2): probe on T=256 data gives pyspi E = 10 while the argmax-rho E is 1 (logistic x), 9 (iid process 0), 3 (iid process 1), 7 (var2 process 1). (2) 22 library sizes, not 21; truncated at short T (see candidates). (3) diff is not defined in the supplement (which lists six SPIs) and only named on the GitBook; code defines it as mean over L of rho(x_j|M_i) - rho(x_i|M_j) = mean - mean^T. (4) Keywords say unsigned, class is Signed. (5) Orientation candidate: A[i,j] is evidence for j -> i.')
dev_can_none = ('(1) E is fixed at 10 instead of chosen per variable by simplex forecast skill; even as documented, pyspi would use max(E_i, E_j) for both directions, whereas canonically each cross map uses the E of the variable being embedded. (2) Convergence, the CCM causal criterion, is replaced by the mean or max of rho over L (documented; the mean includes the small-L part of the curve). (3) diff is a pyspi-specific antisymmetric skill difference, not part of Sugihara 2012. (4) tau fixed at 1 sample, no exclusion radius beyond self (Sugihara 2012 has no Theiler window either; later EDM practice recommends one). (5) Otherwise the per-library cross-map (E+1 neighbours, exp(-d/d_min) weights, Pearson rho, random libraries) matches Sugihara 2012 / rEDM practice.')
already_none = ('tests/README.md bug 2 (ConvergentCrossMapping(embedding_dimension=None) picks max E (10), not best-rho E; ccm_E-None == ccm_E-10; tests/unit/test_known_bugs.py:86-107); EEG_OPTIMIZATION_NOTES.md §review "automatic CCM embedding selection"; EEG_OPTIMIZATION_NOTES.md §review and DEPENDENCY_MIGRATION.md / DEPENDENCY_COMPATIBILITY_REVIEW.md:87 "pyEDM 2.x CCM drift"')
cands_none = COMMON_CANDS + [
    'CANDIDATE wasted work and duplicate SPI: because of bug 2 the EmbedDimension runs (10 simplex fits per process, causal.py:102-111) are computed and discarded and the three ccm_E-None_* outputs duplicate ccm_E-10_* (probe: bitwise equal on var2_bivariate T=256). Not a new definition issue; recorded so that a fix (argmax rho) is tested against the documented intent rather than against the snapshot goldens.',
    'CANDIDATE intended-design question: even the documented rule applies max(E_i, E_j) to both cross-map directions (causal.py:123), and EmbedDimension uses lib == pred (rows 10..N-10) with leave-one-out only; canonical practice chooses E per embedded variable, so the fixed behaviour would still differ from Sugihara 2012.',
]
extra_none = [
    dict(datasets=['logistic_maps', 'var2_bivariate', 'iid_gaussian'], path='kernel',
         reference='from-scratch numpy simplex forecast (Tp=1, E = 1..10, tau=1, E+1 neighbours, exp weights, lib = pred = rows 10..N-10 with self excluded) choosing argmax-rho E per process; compared with pyspi\'s chosen embedding',
         reference_kind='independent-impl', criterion='exact',
         expected_outcome='from-scratch rho(E) table equals pyEDM.EmbedDimension within 1e-12; pyspi\'s chosen E is 10 for every process while the argmax-rho E differs (probe T=256: logistic x -> 1, iid -> 9 and 3, var2 process 1 -> 7), reproducing known bug 2; ccm_E-None_* == ccm_E-10_* bitwise'),
]

# ---------- E-1
impl_1 = ('Default pipeline z-scores each process. E=1 for both directions: the "embedding" is the scalar x_i(t) (no delay coordinates), knn = 2, Tp = 0, no exclusion radius (self excluded). For each unordered pair one pyEDM.CCM call; library sizes lowerE = 10 to upperE = floor((T-2)/10)*10 in steps floor((upperE-10)/21), first 22 sizes kept; 100 random libraries per size without replacement (seed 42); per size the mean over libraries of Pearson rho between x_j(t) and its 2-nearest-neighbour exponentially weighted estimate from x_i over all T rows. ccmf[i,j,:] = rho(x_j | x_i)(L); mean / max / diff over the 22 sizes as for every ccm unit. With E=1 this is a nonparametric contemporaneous regression skill of x_j on x_i, not a state-space (Takens) reconstruction.')
dev_doc_1 = ('(1) 22 library sizes, not 21; truncated at T=64 (10..52 of 10..60). (2) diff undefined in the supplement (GitBook names it only); code: mean - mean^T. (3) Keywords unsigned vs Signed class. (4) Orientation candidate: A[i,j] is evidence for j -> i. (5) The documented description of CCM as using "the Takens time-delay embedding" does not hold for E=1, where no delay coordinate is used.')
dev_can_1 = ('(1) E=1 is not a delay embedding: Takens\' theorem needs E > 2d, so the cross map is a 2-nearest-neighbour regression of x_j(t) on x_i(t); it responds to static (instantaneous) functional dependence without any dynamics (from-scratch probe on iid x1 = x0^2 + noise: rho(x1|x0) = 0.972, rho(x0|x1) = -0.032). (2) Convergence criterion replaced by mean/max of rho over L (documented). (3) diff is pyspi-specific. (4) Per-library cross-map algorithm otherwise matches Sugihara 2012 (E+1 neighbours, exp(-d/d_min) weights, Pearson rho).')
already_fixed = ('no (family-level references: EEG_OPTIMIZATION_NOTES.md §review and DEPENDENCY_MIGRATION.md / DEPENDENCY_COMPATIBILITY_REVIEW.md:87 record that pyEDM 2.x changes CCM values; tests/README.md bug 2 concerns only E=None)')
cands_1 = COMMON_CANDS + [
    'CANDIDATE static dependence read as causality: with E=1 the measure is a contemporaneous kNN regression skill, so a static asymmetric function produces a large asymmetric "causal" score. Evidence: from-scratch probe reproducing pyEDM exactly on iid x0 ~ U(-1,1), x1 = x0^2 + 0.05 noise, N=300: "proc0:proc1" = 0.9722, "proc1:proc0" = -0.0315, although the data have no temporal structure.',
]
extra_1 = [
    dict(datasets=['nonlinear_dependence'], path='pipeline',
         reference='analytic: process 1 = process 0^2 + noise with iid samples (no dynamics); x1 is a function of x0 but x0 is not a function of x1',
         reference_kind='analytic', criterion='qualitative',
         expected_outcome='ccm_E-1_mean A[0,1] close to 1 and A[1,0] near 0 at T in {1024, 4096} (diff[0,1] strongly positive), showing E=1 scores static functional dependence; by the code orientation this would be read as process 1 -> process 0'),
]

# ---------- E-10
impl_10 = ('Default pipeline z-scores each process. E=10 for both directions with tau = 1 sample (delay vector x_i(t), ..., x_i(t-9)), knn = 11, Tp = 0, no exclusion radius (self excluded). For each unordered pair one pyEDM.CCM call; library sizes lowerE = 20 to upperE = floor((T-11)/10)*10 in steps floor((upperE-20)/21), first 22 kept; 100 random libraries per size without replacement (seed 42); per size the mean over libraries of Pearson rho between x_j(t) and its cross-mapped estimate over prediction rows 9..T-1. ccmf[i,j,:] = rho(x_j | M_{x_i})(L); mean / max / diff over the 22 sizes. Identical numbers are produced by causal.ccm.E-None (known bug 2).')
dev_doc_10 = ('(1) 22 library sizes, not 21; truncated at T=64 (20..41 of 20..50) and T=256 (20..230 of 20..240). (2) diff undefined in the supplement; code: mean - mean^T. (3) Keywords unsigned vs Signed class. (4) Orientation candidate: A[i,j] is evidence for j -> i. (5) Fails (all-NaN in Calculator) for T <= 60.')
dev_can_10 = ('(1) Fixed E=10 and tau=1 for every dataset instead of a data-driven E/tau (Sugihara 2012 chose E by simplex projection). (2) Convergence criterion replaced by mean/max of rho over L (documented). (3) diff is pyspi-specific. (4) No exclusion radius beyond self. (5) Per-library cross-map algorithm otherwise matches Sugihara 2012. Behaviour note (not a code defect): on stochastic linear data CCM direction readings are unreliable; probe on var2_bivariate T=256 (0 -> 1) gives A_mean[0,1] = 0.3208 > A_mean[1,0] = 0.0774, which under the Sugihara reading points to 1 -> 0.')
cands_10 = COMMON_CANDS + [
    'CANDIDATE (behaviour, not code): for stochastic linear coupling the E=10 CCM orientation reading fails: var2_bivariate T=256 (process 0 drives process 1) gives mean [[0, 0.3208], [0.0774, 0]] and diff [[0, 0.2434], [-0.2434, 0]], i.e. the cause\'s embedding predicts the effect better than the reverse; under the code orientation (A[i,j] large -> j -> i) this reads 1 -> 0. Consistent with the CCM literature on strongly forced / stochastic systems; to be characterised in the check stage rather than reported as a defect.',
]
extra_10 = [
    dict(datasets=['gauss_ar1_pair', 'narrowband_f0-0.1'], path='kernel',
         reference='from-scratch cross-map (as in the first check) run with exclusion radius 0 and with a Theiler window of (E-1)*tau + 1 = 10 samples',
         reference_kind='independent-impl', criterion='qualitative',
         expected_outcome='the exclusion-radius-0 version equals pyEDM; the gap between the two quantifies how much of the E=10 skill comes from temporally adjacent neighbours (expected to be large for the narrowband signal)'),
]

recs = [
    rec('causal.ccm.E-None', 'None->10', EMBED_TRACE, impl_none, dev_doc_none, dev_can_none, already_none, cands_none, extra_none),
    rec('causal.ccm.E-1', '1', [], impl_1, dev_doc_1, dev_can_1, already_fixed, cands_1, extra_1),
    rec('causal.ccm.E-10', '10', [], impl_10, dev_doc_10, dev_can_10, already_fixed, cands_10, extra_10),
]
for r in recs:
    p = OUT / f"{r['unit_id']}.yaml"
    p.write_text(yaml.safe_dump(r, sort_keys=False, allow_unicode=True, width=120))
    print('wrote', p)
