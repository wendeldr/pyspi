import numpy as np, warnings, glob, os
from scipy.stats import zscore
import sklearn.covariance as skc
warnings.simplefilter('ignore')
for f in sorted(glob.glob('/media/dan/Data/git/pyspi/audit/checks/data/*.npz')):
    X = np.load(f)['x']; z = zscore(X, axis=1, ddof=1).T
    S = np.cov(z.T, bias=1); off = ~np.eye(len(S), dtype=bool)
    try:
        m = skc.GraphicalLasso().fit(z)
    except Exception as e:
        print(os.path.basename(f), 'default EXC', type(e).__name__); continue
    try:
        t = skc.GraphicalLasso(tol=1e-10, enet_tol=1e-12, max_iter=5000).fit(z)
        tc = t.covariance_; tp = t.precision_; tit = t.n_iter_; tg=t.costs_[-1][1]
    except Exception as e:
        print(os.path.basename(f), 'tight EXC', type(e).__name__); continue
    stall = np.allclose(m.covariance_[off], 0.95*S[off], rtol=1e-10, atol=0)
    dc = np.abs(m.covariance_-tc)[off].max(); dp = np.abs(m.precision_-tp)[off].max()
    rp = dp/np.abs(tp[off]).max()
    if m.n_iter_>=100 or dc>1e-6 or stall:
        print(f'{os.path.basename(f)[:-4]:28s} it={m.n_iter_:3d} gap={m.costs_[-1][1]:+.1e} stall_at_0.95S={stall} max|dcov|={dc:.2e} max|dprec|={dp:.2e} rel={rp:.2e} tight_it={tit} tight_gap={tg:.1e}')
