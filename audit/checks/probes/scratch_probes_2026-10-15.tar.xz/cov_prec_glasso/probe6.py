import sys, numpy as np, warnings, traceback
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
from pyspi.statistics.basic import Covariance, Precision
for name, est in [('trending_T4096','GraphicalLasso'),('shared_envelope_T256','GraphicalLassoCV')]:
    X = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{name}.npz')['x']
    d = Data(X, dim_order='ps')
    try:
        Precision(estimator=est).multivariate(d)
    except Exception as e:
        tb = traceback.extract_tb(e.__traceback__)
        print(name, est, type(e).__name__, str(e)[:120]); print('   frames:', [(f.filename.split('site-packages/')[-1].split('pyspi/')[-1], f.lineno) for f in tb][-4:])
    print('   cached after failure?', hasattr(d,'covariance') and est in d.covariance)
    d2 = Data(X, dim_order='ps', detrend=True)
    try:
        P = Precision(estimator=est).multivariate(d2); print('   detrend=True OK, max|P|', np.nanmax(np.abs(P)))
    except Exception as e:
        print('   detrend=True', type(e).__name__)
