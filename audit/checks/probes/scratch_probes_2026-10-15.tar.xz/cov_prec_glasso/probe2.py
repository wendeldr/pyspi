import sys, numpy as np, warnings, glob, os
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from scipy.stats import zscore
import sklearn.covariance as skc
from sklearn.model_selection import check_cv
print('default cv:', check_cv(None))
np.set_printoptions(precision=4, suppress=True, linewidth=140)
for f in sorted(glob.glob('/media/dan/Data/git/pyspi/audit/checks/data/*.npz')):
    X = np.load(f)['x']
    z = zscore(X, axis=1, nan_policy='omit', ddof=1).T
    row = [os.path.basename(f)[:-4]]
    for est in ['GraphicalLasso','GraphicalLassoCV']:
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            try:
                m = getattr(skc, est)().fit(z)
            except Exception as e:
                row.append(f'{est}: EXC {type(e).__name__}'); continue
        Th, W = m.precision_, m.covariance_
        off = ~np.eye(len(W), dtype=bool)
        cw = [str(x.category.__name__) for x in w]
        a = m.alpha_ if hasattr(m,'alpha_') else m.alpha
        row.append(f'{est}: a={a:.4g} it={m.n_iter_} gap={m.costs_[-1][1]:.1e} max|Th_off|={np.abs(Th[off]).max():.3g} zeros={int(((Th==0)&off).sum())} invErr={np.abs(np.linalg.inv(W)-Th).max():.1e} warn={set(cw)}')
    print(' | '.join(row))
