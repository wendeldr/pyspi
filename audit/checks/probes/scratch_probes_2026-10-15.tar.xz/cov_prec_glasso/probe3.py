# P=2 closed form: W12 = soft(S12, alpha), W_ii = S_ii, Theta = inv(W)
import numpy as np, warnings
from scipy.stats import zscore
import sklearn.covariance as skc
for name in ['var2_bivariate','gauss_ar1_pair','logistic_maps','contaminated','logistic_maps_bidir']:
    for T in [64,256,1024,4096]:
        X = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{name}_T{T}.npz')['x']
        z = zscore(X, axis=1, ddof=1).T
        S = np.cov(z.T, bias=1)
        a = 0.01
        W = S.copy(); W[0,1]=W[1,0]=np.sign(S[0,1])*max(abs(S[0,1])-a,0)
        Th = np.linalg.inv(W)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            m = skc.GraphicalLasso().fit(z)
        print(f'{name} T={T} S12={S[0,1]:.6f} cov ref={W[0,1]:.8f} sk={m.covariance_[0,1]:.8f} d={abs(W[0,1]-m.covariance_[0,1]):.2e} | prec ref={Th[0,1]:.8f} sk={m.precision_[0,1]:.8f} d={abs(Th[0,1]-m.precision_[0,1]):.2e} it={m.n_iter_} warn={len(w)}')
