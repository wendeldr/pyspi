import numpy as np
from scipy.stats import zscore
from sklearn.linear_model import _cd_fast as cd_fast
from sklearn.utils import check_random_state
X = np.load('/media/dan/Data/git/pyspi/audit/checks/data/var2_bivariate_T4096.npz')['x']
z = zscore(X, axis=1, ddof=1).T; S = np.cov(z.T, bias=1)
Q = np.array([[S[1,1]]]); q = np.array([S[0,1]])
w0 = 0.95*S[0,1]/S[1,1]
for tol in [1e-4, 1e-6]:
    c = cd_fast.enet_coordinate_descent_gram(w=np.array([w0]), alpha=0.01, beta=0, Q=Q, q=q, y=q, max_iter=100, tol=tol, rng=check_random_state(None), random=False, positive=False, do_screening=True)
    print('enet_tol',tol,'w0',w0,'-> w',c[0][0],'inner gap',c[1],'n_iter',c[3],'exact',(abs(S[0,1])-0.01)/S[1,1])
