import numpy as np, warnings
from scipy.stats import zscore
import sklearn.covariance as skc
X = np.load('/media/dan/Data/git/pyspi/audit/checks/data/var2_bivariate_T4096.npz')['x']
z = zscore(X, axis=1, ddof=1).T
S = np.cov(z.T, bias=1)
ref = np.sign(S[0,1])*(abs(S[0,1])-0.01)
warnings.simplefilter('ignore')
m = skc.GraphicalLasso().fit(z)
print('costs first/last', m.costs_[:3], m.costs_[-2:])
print('cov12 values distinct over runs? ref', ref, 'sk', m.covariance_[0,1])
for kw in [dict(enet_tol=1e-8), dict(max_iter=1000), dict(tol=1e-6, enet_tol=1e-10, max_iter=1000), dict(mode='lars')]:
    mm = skc.GraphicalLasso(**kw).fit(z)
    print(kw, 'it', mm.n_iter_, 'cov12 err', abs(mm.covariance_[0,1]-ref), 'gap', mm.costs_[-1][1])
# trace the CD: emulate one column update
from sklearn.linear_model import _cd_fast as cd_fast
from sklearn.utils import check_random_state
Q = np.array([[S[1,1]]]); q = np.array([S[0,1]])
for w0 in [0.0, 0.2]:
    c = cd_fast.enet_coordinate_descent_gram(w=np.array([w0]), alpha=0.01, beta=0, Q=Q, q=q, y=q, max_iter=100, tol=1e-4, rng=check_random_state(None), random=False, positive=False, do_screening=True)
    print('w0',w0,'cd result', c[0], 'gap', c[1], 'n_iter', c[3], 'exact', np.sign(S[0,1])*(abs(S[0,1])-0.01)/S[1,1])
