import sys, numpy as np, warnings
sys.path.insert(0,'/media/dan/Data/git/pyspi')
from pyspi.data import Data
from pyspi.statistics.basic import Covariance, Precision
np.set_printoptions(precision=5, suppress=True, linewidth=140)
for name in ['sparse_precision_T1024','sparse_precision_T64','bivariate_gaussian_T256']:
    X = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{name}.npz')['x']
    print('=====', name)
    for est in ['GraphicalLasso','GraphicalLassoCV']:
        d = Data(X.copy(), dim_order='ps', normalise=True)
        z = d.to_numpy(squeeze=True).T
        T = z.shape[0]
        S = np.cov(z.T, bias=1)
        P = Precision(estimator=est).multivariate(d)
        m = d.covariance[est]
        print(est, 'cached obj diag after prec call:', np.diag(m.precision_))
        C = Covariance(estimator=est).multivariate(d)
        print(' prec==cache obj?', P is m.precision_, ' cov is cache obj?', C is m.covariance_)
        Csq = Covariance(estimator=est, squared=True).multivariate(d)
        print(' identifiers', Covariance(estimator=est, squared=True).identifier, Precision(estimator=est).identifier)
        print(' n_iter', m.n_iter_, 'last cost,gap', m.costs_[-1], 'alpha', getattr(m,'alpha_',m.__dict__.get('alpha')))
        print(' exact symmetry prec', np.array_equal(np.nan_to_num(P), np.nan_to_num(P).T), 'cov', np.array_equal(np.nan_to_num(C), np.nan_to_num(C).T))
        # recompute fresh to get diagonals
        import sklearn.covariance as skc
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            f = getattr(skc, est)().fit(z)
        W, Th = f.covariance_, f.precision_
        print(' fresh == pyspi offdiag prec', np.allclose(np.nan_to_num(P), Th - np.diag(np.diag(Th)), atol=0, rtol=0), ' cov', np.array_equal(np.nan_to_num(C), W-np.diag(np.diag(W))))
        print(' diag W', np.diag(W), ' (T-1)/T=', (T-1)/T, ' diag S', np.diag(S))
        print(' ||W Th - I||max', np.abs(W@Th-np.eye(len(W))).max(), ' ||inv(W)-Th||max', np.abs(np.linalg.inv(W)-Th).max())
        a = f.alpha_ if est.endswith('CV') else f.alpha
        off = ~np.eye(len(W),dtype=bool)
        nz = (Th!=0)&off
        r_nz = np.abs(W[nz]-S[nz]-a*np.sign(Th[nz])).max() if nz.any() else 0
        r_z = (np.abs(W[(Th==0)&off]-S[(Th==0)&off]).max()-a) if ((Th==0)&off).any() else None
        print(' alpha',a,' KKT nz resid', r_nz, ' zero-entries max|W-S|-alpha', r_z, ' #exact zeros offdiag', int(((Th==0)&off).sum()))
        pc = -Th/np.sqrt(np.outer(np.diag(Th),np.diag(Th)))
        print(' prec Th:\n', Th)
        print(' partial corr (-Th_ij/sqrt):\n', pc)
        print(' max|offdiag prec|', np.abs(Th[off]).max(), ' diag prec', np.diag(Th))
        print(' max|offdiag cov|', np.abs(W[off]).max(), ' emp corr offdiag max', np.abs(np.corrcoef(z.T)[off]).max())
        if est.endswith('CV'):
            print(' cv alphas', f.cv_results_['alphas']); print(' mean score', f.cv_results_['mean_test_score'])
            from sklearn.covariance._graph_lasso import alpha_max
            print(' alpha_max', alpha_max(S))
