import yaml
SP = '/media/dan/Data/git/pyspi/.venv/lib/python3.12/site-packages/'
GL = SP + 'sklearn/covariance/_graph_lasso.py'
EC = SP + 'sklearn/covariance/_empirical_covariance.py'
CD = SP + 'sklearn/linear_model/_cd_fast.pyx'

DOC_COV = ("supplement §1.1.1, p.3-4: 'Due to the z-scoring of the time series, the correlation and covariance matrices are equivalent and thus the covariance statistic is within [-1, 1]. We use v0.24.1 of scikit-learn ... "
           "the Lasso technique, which uses an l1-regularization to sparsify the covariance matrix GraphicalLasso (as well as a method with the regularization method chosen through cross validation with five splits, GraphicalLassoCV)'; "
           "keywords 'undirected, linear, signed, multivariate, contemporaneous'. GitBook basic-statistics.md (Covariance) repeats the text but gives keywords 'undirected, nonlinear, unsigned, bivariate, contemporaneous'. "
           "The -sq (squared) identifiers are not described in the supplement.")
DOC_PREC = ("supplement §1.1.2, p.4: 'The precision matrix is the matrix inverse of the covariance matrix ... For normalized time-series data, the precision matrix is equivalent to the partial correlation between each pairwise time series, "
            "conditioned on all other time series, and is within [-1, 1]. The precision matrix is computed via the same module as the covariance matrix (in scikit-learn [2]), and has the same estimators.' Estimator described in §1.1.1, p.3-4 "
            "('Lasso technique, which uses an l1-regularization to sparsify the covariance matrix'; CV variant 'with five splits'); keywords 'undirected, linear, signed, multivariate, contemporaneous'. GitBook basic-statistics.md (Precision) same text. "
            "The -sq identifiers are not described in the supplement.")

CANON_REF = ("Friedman J, Hastie T, Tibshirani R 2008, 'Sparse inverse covariance estimation with the graphical lasso', Biostatistics 9(3):432-441, eq. (1)/(2.1) (diagonal penalised); "
             "off-diagonal-only penalty: Yuan M, Lin Y 2007, 'Model selection and estimation in the Gaussian graphical model', Biometrika 94(1):19-35, eq. (4); Banerjee O, El Ghaoui L, d'Aspremont A 2008, JMLR 9:485-516")
CANON_DEF = ("Theta_hat = argmin_{Theta > 0} -log det Theta + tr(S Theta) + alpha * sum_{i != j} |Theta_ij| (Friedman 2008 sums over all i,j incl. the diagonal; Yuan & Lin 2007 penalise off-diagonals only); "
             "Sigma_hat = W = Theta_hat^{-1}; KKT: W_ii = S_ii (+alpha if diagonal penalised), W_ij = S_ij + alpha*sign(Theta_ij) if Theta_ij != 0, |W_ij - S_ij| <= alpha otherwise; "
             "partial correlation rho_ij|rest = -Theta_ij / sqrt(Theta_ii Theta_jj)")
CV_REF = (" CV variant: alpha chosen by K-fold cross-validated Gaussian log-likelihood (e.g. Friedman et al. 2008 §4; sklearn GraphicalLassoCV, iteratively refined log grid); there is no single canonical CV rule.")

TRACE_PRE = [
  "pyspi/config.yaml:3-36 Covariance configs (estimator GraphicalLasso / GraphicalLassoCV, squared False/True) and :38-70 Precision configs; pyspi/calculator.py:239-244 Calculator._load_yaml instantiates getattr(module, fcn)(**params)",
  "pyspi/data.py:184-195 preprocessing before any SPI: optional scipy.signal.detrend(axis=1) (default detrend=False, data.py:63), then scipy.stats.zscore(axis=1, ddof=1, nan_policy='omit') (default normalise=True, data.py:64)",
  "pyspi/calculator.py:294 Calculator.compute calls self._spis[spi].multivariate(self.dataset); :297 np.fill_diagonal(S, np.nan); :302-303 any exception -> warning and the whole SPI entry set to NaN",
  "pyspi/base.py:51-67 parse_multivariate passes a Data object straight through (no copy when inplace=True)",
]
def trace_cls(cls, kind, est):
    lines = {"Covariance": "pyspi/statistics/basic.py:57-63 class Covariance(Estimators), identifier 'cov', kind='covariance'",
             "Precision": "pyspi/statistics/basic.py:66-72 class Precision(Estimators), identifier 'prec', kind='precision'"}
    return [
      lines[cls],
      "pyspi/statistics/basic.py:9-29 class Estimators(Undirected, Signed): identifier += '_' + estimator, '-sq' prefix and issigned->False when squared=True; labels = ['basic','unordered','linear','undirected'] + ['signed'|'unsigned'] (new list, no class-level mutation)",
      f"pyspi/statistics/basic.py:31-44 _from_cache: cache key is the estimator name only (data.covariance['{est}']), shared by cov, cov-sq, prec, prec-sq; z = data.to_numpy(squeeze=True).T -> (T, P); all warnings suppressed (:37-38 warnings.simplefilter('ignore')); mycov = sklearn.covariance.{est}().fit(z) with library defaults; an exception is not cached",
      f"pyspi/statistics/basic.py:46-54 multivariate: matrix = getattr(mycov, '{kind}_') (the cached estimator's own array, no copy); np.fill_diagonal(matrix, np.nan) mutates the cached estimator in place; returns matrix or np.square(matrix); overrides Undirected.multivariate (base.py:132-138), so no triangle mirroring (REVIEW M1)",
    ]
TRACE_GL = [
  GL + ":522-545 GraphicalLasso.__init__ defaults alpha=0.01, mode='cd', covariance=None, tol=1e-4, enet_tol=1e-4, max_iter=100, eps=float64 eps, assume_centered=False",
  GL + ":547-587 GraphicalLasso.fit: validate_data(ensure_min_features=2); emp_cov = empirical_covariance(X, assume_centered=False); location_ = X.mean(0); _graphical_lasso(emp_cov, alpha, cov_init=None, ...)",
  EC + ":104-107 empirical_covariance: np.cov(X.T, bias=1) (divides by T, while pyspi z-scored with ddof=1, so S_ii = (T-1)/T)",
]
TRACE_SOLVER = [
  GL + ":69-88 _graphical_lasso; alpha == 0 early return with linalg.inv (not reached for these units: GraphicalLasso alpha=0.01, CV never selects 0)",
  GL + ":90-103 initialisation: covariance_ = 0.95 * emp_cov off-diagonal, diagonal = emp_cov diagonal (never changed afterwards: diagonal unpenalised); precision_ = pinvh(covariance_)",
  GL + ":119-177 block coordinate descent over columns: inner lasso via cd_fast.enet_coordinate_descent_gram warm-started from -precision_[:,idx]/precision_[idx,idx] (:134-156, inner max_iter=max(20,max_iter), tol=enet_tol); precision_ column/row and covariance_ column/row are written symmetrically (:169-177)",
  CD + ":1092 enet_coordinate_descent_gram; :1173 tol *= ||y||^2; :1176-1182 returns before any coordinate update (n_iter 0) when the warm-start duality gap is already 0 <= gap <= tol",
  GL + ":178-201 after each sweep: FloatingPointError if precision_ not finite or cost not finite; d_gap = _dual_gap (:56-65, off-diagonal |Theta| penalty, :43-53 objective likewise); stop when |d_gap| < tol; otherwise ConvergenceWarning after max_iter (silenced by pyspi)",
  GL + ":206 returns (covariance_, precision_, costs, n_iter): both matrices are the solver's running iterates; neither is recomputed as the inverse of the other at exit",
]
TRACE_CV = [
  GL + ":916-943 GraphicalLassoCV.__init__ defaults alphas=4, n_refinements=4, cv=None, tol=1e-4, enet_tol=1e-4, max_iter=100, mode='cd', n_jobs=None",
  GL + ":976-983 fit: location_ = X.mean(0); emp_cov = empirical_covariance(X); cv = check_cv(None) -> KFold(n_splits=5, shuffle=False), i.e. 5 contiguous time blocks (probe printed KFold(n_splits=5, random_state=None, shuffle=False))",
  GL + ":1002-1006 initial grid: alpha_1 = alpha_max(emp_cov) (:209-225, max |off-diagonal S|), alpha_0 = 0.01*alpha_1, 4 log-spaced values, descending",
  GL + ":1014-1038 for each of n_refinements=4 rounds: graphical_lasso_path on each training fold with X_test = test fold and max_iter=int(0.1*max_iter)=10, ConvergenceWarning suppressed",
  GL + ":592-717 graphical_lasso_path: emp_cov of the training fold, warm start across alphas (cov_init=covariance_), test score = log_likelihood(empirical_covariance(X_test), precision_) (test fold centred on its own mean); FloatingPointError or non-finite -> score -inf",
  EC + ":31-55 log_likelihood = (-sum(S_test * Theta) + logdet(Theta) - p log 2pi)/2",
  GL + ":1047-1060 best_index = argmax of mean fold score with ties going to the smaller alpha (>=); scores >= 0.1/eps treated as NaN",
  GL + ":1062-1083 grid refinement around best_index (extends downward by 0.01x when the smallest alpha wins); 4 rounds x 4 alphas = 16 alphas evaluated, the grid built after the last round is unused",
  GL + ":1091-1105 alpha=0 appended with EmpiricalCovariance cross_val_score after selection, so alpha=0 is reported in cv_results_ but can never be selected",
  GL + ":1116-1129 alpha_ = alphas[best_index]; final _graphical_lasso(emp_cov, alpha_, max_iter=100) on all data (a FloatingPointError here propagates to pyspi)",
]

def common_checks(kind, cv):
    ck = []
    a_txt = "alpha_ read from data.covariance['GraphicalLassoCV'].alpha_ after the pyspi call" if cv else "alpha = 0.01"
    if kind == 'covariance':
        ck.append(dict(datasets=["var2_bivariate","gauss_ar1_pair","logistic_maps","logistic_maps_bidir","contaminated"], path="kernel",
            reference=f"analytic P=2 closed form of the off-diagonal-penalised graphical lasso: W_ii = S_ii, W_12 = sign(S_12)*max(|S_12| - alpha, 0) with S = np.cov(zscore(x, ddof=1), bias=1) and {a_txt}",
            reference_kind="analytic", criterion="tolerance",
            expected_outcome="cov[0,1] equals the closed form to <= 1e-10 on converged fits (probe: <= 1e-13 on 18 of 20 dataset/T pairs for alpha=0.01); var2_bivariate T=4096 expected to deviate by ~8.7e-4 (solver stalls at the 0.95*S_12 starting value) and T=1024 by ~1.3e-5 (early stop); -sq variant equals the square of the cov value exactly"))
    else:
        ck.append(dict(datasets=["var2_bivariate","gauss_ar1_pair","logistic_maps","logistic_maps_bidir","contaminated"], path="kernel",
            reference=f"analytic P=2 closed form: W as for cov (soft-threshold of S_12 by alpha, diagonal S_ii), Theta = np.linalg.inv(W), i.e. Theta_12 = -W_12/(S_11 S_22 - W_12^2); {a_txt}",
            reference_kind="analytic", criterion="tolerance",
            expected_outcome="prec[0,1] equals the closed form to <= 1e-10 on converged fits (probe: <= 4e-13 on 18 of 20 pairs for alpha=0.01); var2_bivariate T=4096 expected ~9.9e-4 off (stall), T=1024 ~1.4e-5; sign of prec[0,1] opposite to sign of S_12; -sq variant equals the square exactly"))
    ck.append(dict(datasets=["sparse_precision","bivariate_gaussian","iid_gaussian","delayed_noise","nonlinear_dependence","var2_chain","scaled_offset"], path="kernel",
        reference=f"from-scratch numpy ADMM graphical lasso (Boyd et al. 2011, Found. Trends Mach. Learn. 3(1), §6.5) with off-diagonal-only l1 penalty, run to primal/dual residual < 1e-10 on the same S (biased covariance of the ddof=1 z-scored data), {a_txt}; does not import sklearn",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome=f"max |pyspi - reference| over off-diagonal {kind} entries <= 1e-3 * max|reference| (probe against a tight-tolerance sklearn refit suggests ~1e-5 to 1e-4 absolute at sklearn's default tol=1e-4); identical zero pattern except entries within ~1e-4 of zero"))
    ck.append(dict(datasets=["narrowband_f0-0.1","narrowband_f0-0.25","narrowband_f0-0.4","shared_envelope","cointegrated","trending","var2_bivariate"], path="kernel",
        reference=f"optimality certificate computed from scratch: graphical-lasso objective -logdet(Theta) + tr(S Theta) + alpha*sum_{{i!=j}}|Theta_ij| and KKT residuals (W - S - alpha*sign(Theta) on the support; |W - S| <= alpha off the support) evaluated for pyspi's output (diagonal restored as S_ii for W, refit value for Theta) and for the ADMM reference; {a_txt}",
        reference_kind="independent-impl", criterion="optimality",
        expected_outcome="on ill-conditioned inputs (rank-deficient or near-collinear) pyspi's fit is expected to be measurably sub-optimal: probe saw ConvergenceWarning (silenced by pyspi) with |dual gap| up to 0.27 and precision entries differing from a tight refit by up to 0.27 absolute (shared_envelope) / 0.1 (narrowband_f0-0.25 T=256); record objective excess and max KKT violation per dataset/T"))
    ck.append(dict(datasets=["sparse_precision","iid_gaussian","bivariate_gaussian"], path="pipeline",
        reference="numpy symmetry and permutation-equivariance test: A == A.T exactly; for a random process permutation p, A(x[p])[i,j] == A(x)[p[i],p[j]] (tolerance 1e-8, the coordinate-descent sweep order changes with the permutation)",
        reference_kind="analytic", criterion="direction",
        expected_outcome="A[i,j] == A[j,i] bit-exactly (probe: np.array_equal(A, A.T) True for both cov and prec, unlike other precision estimators in REVIEW M2) and A[i,j] refers to processes i and j in input row order; diagonal NaN"))
    ck.append(dict(datasets=["trending","shared_envelope","narrowband_f0-0.1"], path="pipeline-detrend",
        reference="qualitative failure-mode check: run Calculator-style compute with detrend False and True, record whether the SPI is a NaN matrix (FloatingPointError caught at calculator.py:302-303)",
        reference_kind="analytic", criterion="qualitative",
        expected_outcome=("GraphicalLasso: trending T=4096 raises FloatingPointError without detrending (whole matrix NaN), succeeds with detrend=True" if not cv else
                          "GraphicalLassoCV: shared_envelope T=256 and T=1024 and narrowband_f0-0.1 T=64 raise FloatingPointError in the final refit (whole matrix NaN); shared_envelope T=256 still fails with detrend=True")))
    if kind == 'covariance':
        ck.append(dict(datasets=["bivariate_gaussian","contaminated","delayed_noise"], path="pipeline",
            reference="analytic bound: |W_ij| <= sqrt(W_ii W_jj) = (T-1)/T for a positive-definite W with W_ii = S_ii = (T-1)/T; compare also to the Pearson correlation np.corrcoef",
            reference_kind="analytic", criterion="qualitative",
            expected_outcome="all off-diagonal values in [-(T-1)/T, (T-1)/T] (documented [-1,1] holds); values are shrunk towards 0 relative to (T-1)/T * Pearson r by <= alpha (KKT), not equal to the correlation matrix"))
    else:
        ck.append(dict(datasets=["bivariate_gaussian","sparse_precision","delayed_noise"], path="pipeline",
            reference="from-scratch partial correlation -Theta_ij/sqrt(Theta_ii Theta_jj) of the same Theta, and the documented claim 'equivalent to the partial correlation ... within [-1, 1]'",
            reference_kind="analytic", criterion="qualitative",
            expected_outcome="documented definition not met: prec values are raw precision entries with the opposite sign to the partial correlation and magnitude outside [-1,1] (probe bivariate_gaussian T=256: prec[2,3] = -2.385 while the partial correlation is +0.811)"))
        ck.append(dict(datasets=["sparse_precision"], path="kernel",
            reference="ground-truth tridiagonal precision (precision_true in the dataset, off-diagonal -0.4) scaled to the z-scored data; support recovery and sign agreement",
            reference_kind="analytic", criterion="statistical",
            expected_outcome="nearest-neighbour entries negative and largest in magnitude at all T; non-neighbour entries small, many exactly zero at T>=1024 (probe T=1024: 2 exact zeros out of 20 off-diagonals at alpha=0.01)"))
    return ck

def cv_checks(kind):
    return [dict(datasets=["sparse_precision","bivariate_gaussian","iid_gaussian","delayed_noise","var2_chain"], path="kernel",
        reference="from-scratch re-implementation (numpy only) of the selection protocol: contiguous 5-fold split, ADMM fits on training folds, Gaussian test log-likelihood with the test fold centred on its own mean, grid alpha_max*logspace(-2,0,4) refined 4 times as in _graph_lasso.py:1062-1083; select argmax mean score",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="selected alpha within one refined-grid step of sklearn's alpha_ on well-conditioned data; differences are expected where sklearn's 10-iteration warm-started training-fold fits stop early; record both alphas and the mean CV score at each"),
      dict(datasets=["iid_gaussian","nonlinear_dependence","var2_chain"], path="pipeline",
        reference="qualitative degenerate-output check: count off-diagonal entries that are exactly 0 or below 1e-15 in magnitude",
        reference_kind="analytic", criterion="qualitative",
        expected_outcome="when CV picks alpha >= alpha_max the whole off-diagonal is 0 (probe iid_gaussian T=64: alpha_=0.2069, 20/20 exact zeros; T=4096: 18 exact zeros plus 2 entries of 3.5e-18 roundoff); such matrices are constant and carry no pairwise information")]

base = {
 'basic.cov.GraphicalLasso': dict(cls='Covariance', kind='covariance', est='GraphicalLasso', cv=False),
 'basic.cov.GraphicalLassoCV': dict(cls='Covariance', kind='covariance', est='GraphicalLassoCV', cv=True),
 'basic.prec.GraphicalLasso': dict(cls='Precision', kind='precision', est='GraphicalLasso', cv=False),
 'basic.prec.GraphicalLassoCV': dict(cls='Precision', kind='precision', est='GraphicalLassoCV', cv=True),
}

NOCONV = ("CANDIDATE (silent non-convergence): pyspi suppresses every warning around the fit (basic.py:37-38), so sklearn's ConvergenceWarning (_graph_lasso.py:196-201) never reaches the user. Probe over the 76 audit dataset files (default pipeline preprocessing): "
          "{n} emitted ConvergenceWarning: {ex}. Against a tight refit (tol=1e-10, enet_tol=1e-12) the default-tolerance precision differs by up to 0.27 absolute (shared_envelope T=256, rel 5.4e-3) and covariance by up to 1.3e-4 (8.7e-4 in the var2_bivariate T=4096 stall).")
STALL = ("CANDIDATE (solver stall, sklearn 1.9.1): on var2_bivariate T=4096 (P=2, well conditioned) GraphicalLasso returns its starting point: covariance_[0,1] == 0.95*S_12 (np.allclose rtol 1e-10 True), "
         "0.20643823 versus the closed-form optimum soft(S_12, 0.01) = 0.20730340 (error 8.65e-4; precision error 9.85e-4), n_iter_=100, dual gap stuck at -3.73e-4. Mechanism (probe): the inner "
         "enet_coordinate_descent_gram exits with n_iter 0 because the warm-start gap 3.4e-7 <= enet_tol*||row||^2 (_cd_fast.pyx:1173-1182), so the outer loop never moves; enet_tol=1e-8 or mode='lars' gives the exact optimum. "
         "Whether sklearn 0.24.1 (the documented version) has the same early exit is not established.")
NOTINV = ("CANDIDATE (cov/prec mutual consistency): covariance_ and precision_ are the solver's running iterates (_graph_lasso.py:169-177, 206), not exact inverses of each other. Probe max|inv(covariance_) - precision_|: "
          "2.6e-5 to 1e-4 on sparse_precision/bivariate_gaussian, 0.41 on shared_envelope T=1024, 0.51 for GraphicalLassoCV on narrowband_f0-0.25 T=4096. So cov_GraphicalLasso and prec_GraphicalLasso are not exactly inverse pairs. "
          "This refutes the briefing wording 'covariance from its inverse': both come from the solver.")
MUTATE = ("CANDIDATE (side effect, value-neutral for these SPIs): multivariate() returns the cached estimator's own array and np.fill_diagonal(matrix, np.nan) (basic.py:49-50) overwrites the diagonal of "
          "data.covariance[estimator].covariance_ / .precision_ in place. Probe: after Precision(...).multivariate(d), np.diag(d.covariance['GraphicalLasso'].precision_) is all NaN and the returned array 'is' the cached array. "
          "Anything that later reads the cached estimator (e.g. its diagonal, score(), mahalanobis()) sees NaNs.")
FPE = ("CANDIDATE (failure -> NaN, repeated refits): a FloatingPointError from the solver propagates out of _from_cache (not cached), Calculator.compute turns it into an all-NaN entry (calculator.py:302-303), "
       "and each of the four identifiers sharing the estimator refits and fails again. Probe: {cases}.")
SCALE = ("CANDIDATE (scale): pyspi z-scores with ddof=1 (data.py:195) but sklearn's empirical_covariance divides by T (np.cov bias=1, _empirical_covariance.py:107), so S_ii = (T-1)/T (probe: diag 0.984375 at T=64, 0.99902 at T=1024). "
         "The documented 'correlation and covariance matrices are equivalent' holds only up to the factor (T-1)/T, and alpha acts on this scale.")

recs = {}
for uid, b in base.items():
    cls, kind, est, cv = b['cls'], b['kind'], b['est'], b['cv']
    idents = [f"{'cov' if kind=='covariance' else 'prec'}_{est}", f"{'cov' if kind=='covariance' else 'prec'}-sq_{est}"]
    trace = TRACE_PRE + trace_cls(cls, kind, est)
    if cv:
        trace += TRACE_CV + [EC + ":104-107 empirical_covariance np.cov(X.T, bias=1)"] + TRACE_SOLVER
    else:
        trace += TRACE_GL + TRACE_SOLVER
    if kind == 'covariance':
        name = ("graphical-lasso (l1-penalised Gaussian MLE) covariance estimate W = Theta_hat^{-1}, off-diagonal entries" + ("; alpha chosen by 5-fold CV" if cv else "; alpha = 0.01") +
                "; cov-sq is its square")
    else:
        name = ("graphical-lasso sparse precision (inverse covariance) estimate Theta_hat, raw off-diagonal entries (not partial correlations)" + ("; alpha chosen by 5-fold CV" if cv else "; alpha = 0.01") +
                "; prec-sq is its square")
    impl = ("Each channel z-scored (ddof=1, optional detrend); X = (T, P) array; sklearn." + est + "() with library defaults: S = biased empirical covariance (divide by T, so S_ii=(T-1)/T); "
            + ("alpha selected by 5-fold contiguous KFold CV on Gaussian test log-likelihood over 16 alphas from 4 refinement rounds of a 4-point log grid starting at [0.01, 1]*max|S_offdiag|, training-fold fits capped at 10 iterations and warm-started; then a full-data fit at alpha_ (max_iter 100). "
               if cv else "alpha = 0.01 fixed (absolute, on the (T-1)/T-scaled correlation matrix). ")
            + "Solver: sklearn block coordinate descent (Friedman 2008 glasso algorithm) with off-diagonal-only l1 penalty, start 0.95*S off-diagonal, stop when |dual gap| < 1e-4 or after 100 sweeps (warning silenced). "
            + ("Returns covariance_ (the solver's W iterate, diagonal = S_ii) " if kind=='covariance' else "Returns precision_ (the solver's Theta iterate, not inv(covariance_)) ")
            + "with diagonal set to NaN; -sq returns the elementwise square. Fit shared through data.covariance['" + est + "'] by cov, cov-sq, prec, prec-sq; exactly symmetric because rows/columns are written together.")
    if kind == 'covariance':
        dev_doc = ("(1) The supplement says the l1 penalty 'sparsif[ies] the covariance matrix'; it sparsifies the precision matrix (penalty on Theta, _graph_lasso.py:52, :64); W = covariance_ is generally dense (probe sparse_precision T=1024: no exact zeros in W while Theta has 2). "
                   "(2) 'correlation and covariance matrices are equivalent': here W is a shrunk estimate with |W_ij - S_ij| <= alpha and S_ij = (T-1)/T * r_ij, so values differ from Pearson r by up to alpha + r/T. Range [-1,1] holds. "
                   "(3) Documented scikit-learn v0.24.1; executed 1.9.1 (inner CD max_iter changed from max_iter to max(20, max_iter), do_screening and a pre-loop early exit added; numeric effect not measured). "
                   "(4) GitBook keywords 'nonlinear, unsigned, bivariate' contradict the supplement/class labels 'linear, signed, multivariate'. (5) -sq variants undocumented.")
        if cv: dev_doc += " (6) 'five splits' confirmed: KFold(5), unshuffled contiguous blocks."
    else:
        dev_doc = ("(1) Documented as 'equivalent to the partial correlation ... within [-1, 1]': the code returns raw precision entries Theta_ij, whose sign is opposite to the partial correlation -Theta_ij/sqrt(Theta_ii Theta_jj) and whose magnitude is unbounded "
                   "(probe: bivariate_gaussian T=256 prec[2,3] = -2.385 vs partial correlation +0.811; up to |Theta_ij| ~ 49 on shared_envelope and ~95 for the CV variant on narrowband). "
                   "(2) 'the matrix inverse of the covariance matrix': it is the l1-penalised estimate, and it is not the exact inverse of the reported cov_" + est + " (solver iterates, see candidates). "
                   "(3) The supplement says the l1 penalty sparsifies the covariance; it sparsifies this precision matrix. (4) Documented scikit-learn v0.24.1, executed 1.9.1. (5) -sq variants undocumented.")
        if cv: dev_doc += " (6) 'five splits' confirmed: KFold(5), unshuffled contiguous blocks."
    dev_can = ("Variant of Friedman et al. 2008: the diagonal is not penalised (sklearn docstring _graph_lasso.py:328-329; W_ii = S_ii exactly, probe), which matches Yuan & Lin 2007 / R glasso(penalize.diagonal=FALSE). "
               "S uses divisor T on ddof=1 z-scored data. Optimisation is approximate: default tol=1e-4 on the absolute dual gap, 100 sweeps, and the result is returned even without convergence; on ill-conditioned inputs the output can be measurably sub-optimal (candidate). "
               + ("CV rule is sklearn-specific (contiguous KFold, 10-iteration warm-started fold fits, ties to smaller alpha, alpha=0 never selectable). " if cv else "alpha=0.01 is an arbitrary fixed absolute penalty, not data-adaptive. ")
               + ("The reported value is W itself; canonical W = Theta_hat^{-1} holds only to solver tolerance." if kind=='covariance' else "Reported value is Theta_ij, a precision entry, not a partial correlation."))
    if kind == 'covariance':
        rng = "dimensionless (data are z-scored); signed, off-diagonals within [-(T-1)/T, (T-1)/T] by positive definiteness; -sq in [0, ((T-1)/T)^2]; exactly symmetric; diagonal NaN; exact 0 when |S_ij| is small only through the Theta support (W itself rarely exactly 0); whole matrix NaN when the solver raises FloatingPointError"
    else:
        rng = "dimensionless inverse-variance units on z-scored data; signed, unbounded (probe up to |Theta_ij| ~ 49 for GraphicalLasso, ~95 for CV, on rank-deficient inputs); sign opposite to the partial correlation; exact zeros from the l1 penalty; -sq >= 0 unbounded; exactly symmetric; diagonal NaN; whole matrix NaN when the solver raises FloatingPointError"
    already = ("REVIEW M1 (Estimators.multivariate overrides Undirected.multivariate, no mirroring; values are nevertheless exactly symmetric here). "
               + ("REVIEW M2 lists precision last-bit reciprocal asymmetry via pinvh; for the graphical-lasso precision the probe found exact symmetry (rows and columns written together), consistent with REVIEW's count of twelve (not sixteen) precision variants with residuals. " if kind=='precision' else "")
               + ("docs/storage_comparison/REVIEW.md R7 (float32 cast flushes cov_GraphicalLassoCV / cov-sq_GraphicalLassoCV values to zero: storage issue, related to the tiny roundoff entries noted below). " if (cv and kind=='covariance') else "")
               + "Otherwise no.")
    cands = [NOCONV.format(n=("14 GraphicalLasso fits (plus 1 FloatingPointError)" if not cv else "22 GraphicalLassoCV final refits (plus 3 FloatingPointError)"),
                           ex=("cointegrated T=256/1024/4096, narrowband_f0-0.1 T=64/4096, narrowband_f0-0.25 T=256 (gap -0.13), narrowband_f0-0.4 T=1024, shared_envelope all four T (gap up to 0.27), trending T=256/1024, var2_bivariate T=4096" if not cv else
                               "all narrowband files except narrowband_f0-0.1 T=64 (which raised; gap up to 0.33), shared_envelope T=64/4096, cointegrated T=256/1024, trending T=256/1024/4096, logistic_maps and logistic_maps_bidir T=1024, var2_bivariate T=64/256")),
             NOTINV, MUTATE,
             FPE.format(cases=("GraphicalLasso on trending T=4096 raises 'Non SPD result' at _graph_lasso.py:193 via :577; with detrend=True it succeeds (max|prec| 2.04)" if not cv else
                               "GraphicalLassoCV raises in the final refit (_graph_lasso.py:1120 -> :193) on shared_envelope T=256 and T=1024 and narrowband_f0-0.1 T=64; detrend=True does not fix shared_envelope T=256")),
             SCALE]
    if not cv: cands.insert(1, STALL)
    if cv:
        cands.append("CANDIDATE (CV behaviour): selected alpha_ spans 8 orders of magnitude across the audit data (probe: 1.3e-8 on delayed_noise T=256, 7.3e-8 on gauss_ar1_pair T=256, 0.207 = alpha_max on iid_gaussian T=64), "
                     "because the grid extends downward by 0.01x per round when the smallest alpha wins (_graph_lasso.py:1074-1076); CV mean scores are very flat near the optimum (sparse_precision T=1024: -6.52445 to -6.52465 over alpha 0.0070-0.0126). "
                     "At alpha_ >= alpha_max all off-diagonals are 0 (iid_gaussian T=64: 20/20 zeros), giving a constant SPI matrix; entries that should be 0 can be ~3.5e-18 roundoff (iid_gaussian T=4096), squared to ~1e-35 in -sq.")
        cands.append("CANDIDATE (CV protocol details): KFold is unshuffled (contiguous blocks; autocorrelated neighbours sit only at block edges), training-fold fits use max_iter=int(0.1*100)=10 with ConvergenceWarning suppressed (_graph_lasso.py:1015-1033), "
                     "the test log-likelihood centres the test fold on its own mean (graphical_lasso_path :677 empirical_covariance(X_test)), and alpha=0 is scored but not selectable (:1095-1116). These are sklearn design choices, documented only as 'five splits'.")
        cands.append("CANDIDATE (alpha relative to GraphicalLasso): on well-behaved Gaussian data CV alpha_ is close to the fixed 0.01 (sparse_precision T=64: 0.00974, T=1024: 0.00848; bivariate_gaussian T=256: 0.0129), so the CV and fixed variants are nearly redundant there; they diverge strongly on rank-deficient data (narrowband: alpha_ ~1e-5..5e-4, |prec| up to 95 vs 14.5).")
    checks = common_checks(kind, cv) + (cv_checks(kind) if cv else [])
    rec = dict(unit_id=uid, status='traced', correctness=dict(
        metric_name_standard=name,
        canonical_ref=CANON_REF + (CV_REF if cv else ""),
        canonical_definition=CANON_DEF,
        documented_definition=(DOC_COV if kind=='covariance' else DOC_PREC) + f" Identifiers: {', '.join(idents)}.",
        delegate_lib=f"scikit-learn==1.9.1 sklearn.covariance.{est}().fit (solver sklearn.covariance._graph_lasso._graphical_lasso, inner sklearn.linear_model._cd_fast.enet_coordinate_descent_gram); numpy==2.5.4, scipy==1.17.1 (zscore, pinvh)",
        implemented_as=impl,
        implementation_trace=trace,
        deviation_from_documented=dev_doc,
        deviation_from_canonical=dev_can,
        units_and_range=rng,
        direction_convention="undirected: A[i,j] = A[j,i] (bit-exact in probes), i and j index processes in input row order; no lag; diagonal NaN",
        symmetry_expected='sym',
        already_documented=already,
        new_finding_candidates=cands,
        proposed_checks=checks))
    with open(f'/media/dan/Data/git/pyspi/audit/records/{uid}.yaml','w') as f:
        yaml.safe_dump(rec, f, sort_keys=False, allow_unicode=True, width=200)
print('ok')
