# from-scratch Johansen reduced-rank regression (numpy + scipy.linalg only) vs statsmodels coint_johansen
from common import *
import scipy.linalg as sla
from statsmodels.tsa.vector_ar.vecm import coint_johansen
def joh(Y, k, case):
    """Y: (T, n) levels. VECM dY_t = Pi y_{t-1} + sum_{i=1..k} G_i dY_{t-i} + D_t + e_t.
    case: 'const_unres' (Johansen H1 / urca ecdet none, constant unrestricted),
          'trend_restr' (constant unrestricted + trend restricted to coint space; urca ecdet='trend'),
          'trend_unres' (constant + trend unrestricted), 'none'."""
    T, n = Y.shape
    dY = np.diff(Y, axis=0)                     # dY[s] = Y[s+1]-Y[s]
    rows = range(k, T-1)                        # s index; dY_t = dY[s], t = s+1
    R0 = np.array([dY[s] for s in rows])
    Y1 = np.array([Y[s] for s in rows])         # y_{t-1}
    Z = np.array([np.concatenate([dY[s-i] for i in range(1, k+1)]) if k>0 else np.zeros(0) for s in rows])
    tt = np.arange(len(R0), dtype=float)[:, None] + k + 1
    ones = np.ones((len(R0), 1))
    if case == 'none': X = Z
    elif case == 'const_unres': X = np.hstack([ones, Z])
    elif case == 'trend_restr': X = np.hstack([ones, Z]); Y1 = np.hstack([Y1, tt])
    elif case == 'trend_unres': X = np.hstack([ones, tt, Z])
    def res(A):
        if X.size == 0: return A
        b, *_ = np.linalg.lstsq(X, A, rcond=None); return A - X @ b
    r0, r1 = res(R0), res(Y1)
    m = len(r0)
    S00 = r0.T @ r0 / m; S11 = r1.T @ r1 / m; S01 = r0.T @ r1 / m
    lam = sla.eigh(S01.T @ np.linalg.solve(S00, S01), S11, eigvals_only=True)[::-1][:n]
    trace = -m * np.sum(np.log(1 - lam)); maxeig = -m * np.log(1 - lam[0])
    return maxeig, trace, lam, m
for name, T in [('cointegrated', 256), ('cointegrated', 1024), ('trending', 1024), ('iid_gaussian', 256), ('var2_bivariate', 1024)]:
    x, _ = load(name, T)
    for (a, b) in [(0, 1), (0, 2)][: (2 if x.shape[0] > 2 else 1)]:
        Y = x[[b, a]].T
        for k in (1, 10):
            for det in (0, 1):
                with warnings.catch_warnings():
                    warnings.simplefilter('ignore')
                    r = coint_johansen(Y, det, k)
                sm = (r.max_eig_stat[0], r.trace_stat[0])
                out = []
                for case in (['const_unres'] if det == 0 else ['trend_restr', 'trend_unres']):
                    me, tr, lam, m = joh(Y, k, case)
                    out.append(f'{case}: maxeig {me:.6f} trace {tr:.6f} (rel diff {abs(me-sm[0])/sm[0]:.2e}, {abs(tr-sm[1])/sm[1]:.2e})')
                print(f'{name} T={T} pair({b},{a}) k={k} det={det}: statsmodels maxeig {sm[0]:.6f} trace {sm[1]:.6f} m={r.rkt.shape[0]} | ' + ' | '.join(out))
