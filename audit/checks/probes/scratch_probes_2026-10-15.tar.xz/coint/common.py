import sys, warnings, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi')
DATA = '/media/dan/Data/git/pyspi/audit/checks/data'
def load(name, T):
    d = np.load(f'{DATA}/{name}_T{T}.npz')
    return d['x'], d
CONFIGS = [
 dict(method='johansen', statistic='max_eig_stat', det_order=0, k_ar_diff=10),
 dict(method='johansen', statistic='trace_stat', det_order=0, k_ar_diff=10),
 dict(method='johansen', statistic='max_eig_stat', det_order=0, k_ar_diff=1),
 dict(method='johansen', statistic='trace_stat', det_order=0, k_ar_diff=1),
 dict(method='johansen', statistic='max_eig_stat', det_order=1, k_ar_diff=10),
 dict(method='johansen', statistic='trace_stat', det_order=1, k_ar_diff=10),
 dict(method='johansen', statistic='max_eig_stat', det_order=1, k_ar_diff=1),
 dict(method='johansen', statistic='trace_stat', det_order=1, k_ar_diff=1),
 dict(method='aeg', statistic='tstat', autolag='aic', maxlag=10, trend='c'),
 dict(method='aeg', statistic='tstat', autolag='aic', maxlag=10, trend='ct'),
 dict(method='aeg', statistic='tstat', autolag='bic', maxlag=10, trend='ct'),
]
