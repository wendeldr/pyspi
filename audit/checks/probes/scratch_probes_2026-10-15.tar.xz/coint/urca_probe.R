suppressMessages(library(urca))
for (f in c("cointegrated_256_pair10.csv","iid_gaussian_256_pair10.csv")) {
 x <- as.matrix(read.csv(f, header=FALSE))
 for (K in c(2, 11)) for (ec in c("none","const","trend")) {
   e <- ca.jo(x, type="eigen", ecdet=ec, K=K, spec="transitory")
   t <- ca.jo(x, type="trace", ecdet=ec, K=K, spec="transitory")
   cat(f, "K=",K," ecdet=",ec," maxeig(r=0)=", sprintf("%.6f", rev(e@teststat)[1]), " trace(r=0)=", sprintf("%.6f", rev(t@teststat)[1]), "\n")
 }
}
