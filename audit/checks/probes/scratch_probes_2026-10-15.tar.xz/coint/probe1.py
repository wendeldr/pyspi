from common import *
import io, contextlib
from pyspi.statistics.misc import Cointegration
from pyspi.data import Data
from statsmodels.tsa import stattools
from statsmodels.tsa.vector_ar.vecm import coint_johansen
x, d = load('cointegrated', 256)
print('keys', list(d.keys()), x.shape)
with contextlib.redirect_stdout(io.StringIO()):
    D = Data(x.copy(), dim_order='ps', normalise=True, detrend=False)
z = D.to_numpy(squeeze=True)
for cfg in CONFIGS:
    s = Cointegration(**cfg)
    A = s.multivariate(D)
    print(s.identifier, s.key, 'labels', s.labels)
    print(np.array2string(A, precision=4))
# orientation for aeg
for trend, al in [('c','aic'),('ct','aic'),('ct','bic')]:
    for (a,b) in [(0,1),(0,2),(2,3)]:
        hi_lo = stattools.coint(z[b], z[a], trend=trend, autolag=al, maxlag=10)[0]
        lo_hi = stattools.coint(z[a], z[b], trend=trend, autolag=al, maxlag=10)[0]
        print('aeg', trend, al, (a,b), 'coint(z_hi,z_lo)=%.10f coint(z_lo,z_hi)=%.10f' % (hi_lo, lo_hi))
# Johansen permutation & trace identity
for det in (0,1):
    for k in (1,10):
        r1 = coint_johansen(z[[0,1]].T, det, k); r2 = coint_johansen(z[[1,0]].T, det, k)
        print('joh', det, k, 'trace', r1.trace_stat, r2.trace_stat, 'maxeig', r1.max_eig_stat, r2.max_eig_stat,
              'eig', r1.eig, 'trace0-(me0+me1)=', r1.trace_stat[0]-r1.max_eig_stat.sum(), 'eig dtype', r1.eig.dtype, 'nobs_eff', r1.rkt.shape[0])
