from common import *
import io, contextlib
from pyspi.statistics.misc import Cointegration
from pyspi.data import Data
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x.copy(), dim_order='ps', normalise=True, detrend=False)
x,_ = load('trending', 4096)
pair = x[[0,3]]
s = Cointegration(**CONFIGS[8])
with warnings.catch_warnings():
    warnings.simplefilter('ignore')
    print('direct bivariate(i=0,j=1) on fresh Data:', s.bivariate(mk(pair)))
    print('multivariate A[0,1] on fresh Data:     ', s.multivariate(mk(pair))[0,1])
    D = mk(pair); b10 = s.bivariate(D, i=1, j=0); print('bivariate(i=1,j=0) first:', b10, 'then bivariate(i=0,j=1) from cache:', s.bivariate(D, i=0, j=1))
    print('cache keys', list(D.coint.keys()), list(D.coint[s.key].keys()))
