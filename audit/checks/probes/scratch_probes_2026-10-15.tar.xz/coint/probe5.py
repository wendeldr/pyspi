# from-scratch Engle-Granger ADF t-stat (numpy only) vs pyspi; also null (iid) values and orientation spread
from common import *
import io, contextlib
from pyspi.statistics.misc import Cointegration
from pyspi.data import Data
def ols(y, X):
    b, *_ = np.linalg.lstsq(X, y, rcond=None); e = y - X @ b; return b, e
def adf_t(u, maxlag, ic, refit=True):
    du = np.diff(u); n_full = len(du)
    def design(p, start):
        rows = range(start, n_full)
        X = np.array([[u[s]] + [du[s-i] for i in range(1, p+1)] for s in rows]); return du[start:], X
    best = None
    for p in range(0, maxlag+1):
        y, X = design(p, maxlag)                     # common sample for IC
        b, e = ols(y, X); n = len(y); k = X.shape[1]
        llf = -n/2*np.log(2*np.pi) - n/2*np.log(e@e/n) - n/2
        crit = -2*llf + (2*k if ic == 'aic' else np.log(n)*k)
        if best is None or crit < best[0]: best = (crit, p)
    p = best[1]
    y, X = design(p, p if refit else maxlag)
    b, e = ols(y, X); n, k = X.shape
    s2 = e@e/(n-k); se = np.sqrt(s2*np.linalg.inv(X.T@X)[0,0]); return b[0]/se, p
def eg(y0, y1, trend, maxlag, ic, refit=True):
    T = len(y0); cols = [y1, np.ones(T)] + ([np.arange(1, T+1, dtype=float)] if trend == 'ct' else [])
    _, e = ols(y0, np.column_stack(cols)); return adf_t(e, maxlag, ic, refit)
def mk(x):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x.copy(), dim_order='ps', normalise=True, detrend=False)
aeg = CONFIGS[8:]
worst = {}
for name in ['cointegrated', 'iid_gaussian', 'trending', 'var2_bivariate', 'delayed_noise']:
    for T in (64, 256, 1024, 4096):
        x, _ = load(name, T); D = mk(x); z = D.to_numpy(squeeze=True); P = len(z)
        for cfg in aeg:
            with warnings.catch_warnings():
                warnings.simplefilter('ignore'); A = Cointegration(**cfg).multivariate(D)
            for a in range(P):
                for b in range(a+1, P):
                    ref, p = eg(z[b], z[a], cfg['trend'], 10, cfg['autolag'])
                    ref_nr, _ = eg(z[b], z[a], cfg['trend'], 10, cfg['autolag'], refit=False)
                    rev, _ = eg(z[a], z[b], cfg['trend'], 10, cfg['autolag'])
                    key = Cointegration(**cfg).identifier
                    d = abs(A[a, b] - ref)
                    w = worst.setdefault(key, [0, 0, 0])
                    w[0] = max(w[0], d); w[1] = max(w[1], abs(A[a,b]-ref_nr)); w[2] = max(w[2], abs(ref-rev))
        if name == 'iid_gaussian':
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                A = Cointegration(**aeg[0]).multivariate(D)
            off = ~np.eye(P, dtype=bool)
            print('iid_gaussian T=%d aeg c/aic off-diag range [%.2f, %.2f]' % (T, A[off].min(), A[off].max()))
for k, w in worst.items():
    print(k, 'max|pyspi - scratch(refit)|=%.2e  max|pyspi - scratch(no refit)|=%.2e  max|forward-reverse orientation|=%.3f' % tuple(w))
