from probe5 import *
rows = []
for name in ['cointegrated', 'iid_gaussian', 'trending', 'var2_bivariate', 'delayed_noise']:
    for T in (256, 1024, 4096):
        x, _ = load(name, T); z = mk(x).to_numpy(squeeze=True); P = len(z)
        for cfg in aeg:
            for a in range(P):
                for b in range(a+1, P):
                    f, pf = eg(z[b], z[a], cfg['trend'], 10, cfg['autolag']); r, pr = eg(z[a], z[b], cfg['trend'], 10, cfg['autolag'])
                    rows.append((abs(f-r), name, T, cfg['trend'], cfg['autolag'], (a,b), round(f,3), round(r,3), pf, pr))
rows.sort(reverse=True)
for r in rows[:8]: print(r)
