from common import *
from statsmodels.tsa.vector_ar.vecm import coint_johansen
mx = {}
for name in ['cointegrated','iid_gaussian','trending','var2_bivariate','delayed_noise','gauss_ar1_pair']:
    for T in (64,256,1024,4096):
        x,_ = load(name,T); P=len(x)
        for a in range(P):
            for b in range(a+1,P):
                for det in (0,1):
                    for k in (1,10):
                        with warnings.catch_warnings():
                            warnings.simplefilter('ignore')
                            r1=coint_johansen(x[[a,b]].T,det,k); r2=coint_johansen(x[[b,a]].T,det,k)
                        for st in ('trace_stat','max_eig_stat'):
                            v1=getattr(r1,st)[0]; v2=getattr(r2,st)[0]
                            mx[(det,k,st)] = max(mx.get((det,k,st),0), abs(v1-v2)/abs(v1))
for k,v in mx.items(): print(k, 'max rel |swap diff| = %.2e' % v)
