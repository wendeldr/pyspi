import yaml, sys
OUT = '/media/dan/Data/git/pyspi/audit/records'
SP = '/media/dan/Data/git/pyspi/.venv/lib/python3.12/site-packages/statsmodels'
SCR = 'scratchpad coint/'

DOC_COMMON = ('supplement §1.6.3, p.19 (heading supplement.txt line 885, text 886-898): "If two time series are individually integrated but some linear '
  'combination of them has a lower order of integration, then the series are said to be cointegrated [79]. We implement statistics for quantifying the '
  'cointegration of bivariate time series from two tests included in v0.12.0 of statsmodels [75]: the Augmented Engle-Granger (AEG, modifier aeg) [80] '
  'two-step test and the Johansen test (johansen) [81]." Keywords: "undirected, linear, unsigned, bivariate, time-dependent". [80] = Engle & Granger 1987 '
  'Econometrica 55, 251; [81] = Pesaran & Shin 1999 (ARDL bounds approach), not Johansen. GitBook spi-descriptions/miscellaneous.md:13-41 has the same text '
  '(Key References link to JSTOR 1913236 = Engle & Granger 1987 and to the Pesaran-Shin ARDL chapter).')

PYSPI_HEAD = [
  'pyspi/calculator.py:239-246 Calculator._load_yaml instantiates Cointegration(**params) per config; the YAML labels block (config.yaml:1294-1299, "linear") is not read, so instance labels come from the class',
  'pyspi/calculator.py:291-302 compute: S = spi.multivariate(dataset); fill_diagonal NaN; any exception -> warning and the whole matrix for that SPI set to NaN (:300-302)',
  'pyspi/data.py:184-195 preprocessing: optional scipy.signal.detrend(axis=1), then zscore(axis=1, ddof=1) by default',
  'pyspi/base.py:132-138 Undirected.multivariate -> Directed.multivariate (base.py:85-94: outer loop j, inner loop i != j, A[i,j] = bivariate(i=i, j=j)); then A[tril] = A.T[tril]. For a pair a<b the FIRST call is bivariate(i=b, j=a)',
  'pyspi/statistics/misc.py:22-26 class Cointegration(Undirected, Unsigned); labels = ["misc","unsigned","temporal","undirected","nonlinear"]',
]
PYSPI_CACHE = [
  'pyspi/statistics/misc.py:62-67 _from_cache: try data.coint[self.key][(i, j)]; on miss z = data.to_numpy(squeeze=True) (shape P x T)',
  'pyspi/statistics/misc.py:89-95 store ci under (i, j) AND (j, i): the first-computed orientation is reused for the reverse pair',
  'pyspi/statistics/misc.py:99-103 bivariate returns ci[self._statistic] (comment at :99 says "Return the negative t-statistic", no negation is applied)',
]

def joh_record(det, k):
    uid = f'misc.coint.johansen_order-{det}_ardiff-{k}'
    ids = f'coint_johansen_max_eig_stat_order-{det}_ardiff-{k}, coint_johansen_trace_stat_order-{det}_ardiff-{k}'
    cfg_lines = {(0,10): '1302-1310', (0,1): '1312-1320', (1,10): '1322-1330', (1,1): '1332-1340'}[(det,k)]
    m256 = 256 - k - 1
    if det == 0:
        dev_can = ('Value: none against Johansen\'s LR statistics with an UNRESTRICTED constant (Johansen-Juselius 1990 model H1(r); urca ca.jo ecdet="none"). '
          f'Probes: statsmodels equals a from-scratch numpy reduced-rank regression with Delta y_t and y_(t-1) partialled on [1, {k} lagged differences] to <= 4.2e-13 relative '
          '(cointegrated, trending, iid_gaussian, var2_bivariate, T=256/1024), and equals R urca 1.3 ca.jo(ecdet="none", K=%d, spec="transitory") to the printed 6 decimals '
          '(cointegrated T=256 pair (1,0): %s). It is NOT the restricted-constant case (urca ecdet="const": %s). statsmodels writes the level regressor as y_(t-k) '
          '(vecm.py:681-682, Johansen 1988 form); because the lagged differences 1..k are partialled out, this spans the same space as y_(t-1) and gives identical eigenvalues '
          '(confirmed by the from-scratch match). Effective sample m = T-k-1 (vecm.py:714), no small-sample correction (canonical). pyspi keeps only r=0 (no rank decision, '
          'critical values and p-values discarded).') % (k+1,
          'maxeig 105.293744, trace 111.013941' if k == 1 else 'maxeig 27.483770, trace 35.158291',
          'maxeig 105.293780, trace 112.303727' if k == 1 else 'maxeig 27.487023, trace 36.310711')
        det_text = 'det_order=0: levels demeaned (vecm.py:670, OLS on a constant), differences/lagged differences/lagged levels demeaned on the effective sample (f=0, vecm.py:665-667, :674, :678, :683) = unrestricted constant in the VECM'
    else:
        dev_can = ('det_order=1 matches NO standard Johansen deterministic case (candidate). statsmodels removes a full-sample linear trend from the LEVELS by OLS before '
          'differencing (vecm.py:650-653, :670) and then only demeans differences and lagged levels on the effective sample (f=0, :665-667, :674, :678, :683); the trend is never '
          'partialled jointly with the lagged differences. Probes (T=256 cointegrated): pair (1,0) k=%d: statsmodels maxeig %s trace %s vs restricted-trend case '
          '(Johansen H*(r), urca ca.jo ecdet="trend", K=%d, identical to a from-scratch RRR) maxeig %s trace %s; pair (2,0): %s. '
          'Unrestricted-trend (case 5) also differs (rel up to 2.5%%). Differences shrink with T (T=1024: 2e-6 to 1.7e-2 relative). Johansen-1988 level form y_(t-k) '
          'is equivalent to y_(t-1) (see order-0 units). pyspi keeps only r=0.') % (
          k,
          '105.347364' if k == 1 else '27.185651', '109.648779' if k == 1 else '32.915367', k+1,
          '105.347370' if k == 1 else '27.511696', '111.330040' if k == 1 else '35.644458',
          'statsmodels maxeig 13.4316 trace 16.8835 vs restricted-trend 13.5735 / 18.4528 (trace 9.3% lower)' if k == 1 else
          'statsmodels maxeig 24.9979 trace 28.8501 vs restricted-trend 25.0466 / 31.5702 (trace 9.4% lower)')
        det_text = 'det_order=1: full-sample linear trend removed from levels by OLS on np.vander(linspace(-1,1,T), 2) (vecm.py:650-653, :670); differences, lagged differences and lagged levels then only demeaned (f=0)'
    trace = PYSPI_HEAD + [
      f'pyspi/config.yaml:{cfg_lines} two configs (statistic max_eig_stat and trace_stat) with det_order={det}, k_ar_diff={k}',
      'pyspi/statistics/misc.py:28-45 __init__: branch method == "johansen" stores _det_order, _k_ar_diff; identifier coint_johansen_<statistic>_order-<det>_ardiff-<k>',
      'pyspi/statistics/misc.py:54-58 key = ("johansen", det_order, k_ar_diff): the statistic is not in the key, so max_eig_stat and trace_stat share one cached fit',
    ] + PYSPI_CACHE[:1] + [
      'pyspi/statistics/misc.py:79-87 coint_johansen(z[[i, j]].T, det_order, k_ar_diff); ci = {max_eig_stat: stats.max_eig_stat[0], trace_stat: stats.trace_stat[0]} (r = 0 row only)',
    ] + PYSPI_CACHE[1:] + [
      f'{SP}/tsa/vector_ar/vecm.py:594 coint_johansen(endog, det_order, k_ar_diff) (statsmodels 0.15.0; imports inv from numpy.linalg :5, lagmat :16)',
      f'{SP}/tsa/vector_ar/vecm.py:650-658 inner detrend(y, order) = OLS residuals on np.vander(np.linspace(-1,1,len(y)), order+1); resid(y, x) = y - x pinv(x) y',
      f'{SP}/tsa/vector_ar/vecm.py:665-670 f = 0 for det_order > -1; endog = detrend(endog, det_order)',
      f'{SP}/tsa/vector_ar/vecm.py:671-679 dx = diff(endog); z = lagmat(dx, k)[k:] demeaned; dx = dx[k:] demeaned; r0t = resid(dx, z)',
      f'{SP}/tsa/vector_ar/vecm.py:681-684 lx = endog[1 : T-k] (level at t-k), demeaned; rkt = resid(lx, z)',
      f'{SP}/tsa/vector_ar/vecm.py:686-692 skk = rkt\'rkt/m, sk0 = rkt\'r0t/m, s00 = r0t\'r0t/m; eig(inv(skk) sk0 inv(s00) sk0\') (numpy 2.5.4 returns complex128 eigenvalues, imaginary part 0 in every probe)',
      f'{SP}/tsa/vector_ar/vecm.py:694-706 cholesky normalisation of eigenvectors and descending sort (no effect on the statistics)',
      f'{SP}/tsa/vector_ar/vecm.py:714-718 m = rkt.shape[0] = T-k-1; lr1[i] = -m sum_(j>=i) log(1-a_j) (trace), lr2[i] = -m log(1-a_i) (max-eig); complex-to-float assignment emits ComplexWarning at :717-718',
      f'{SP}/tsa/vector_ar/vecm.py:772-790 JohansenTestResult.trace_stat -> lr1, max_eig_stat -> lr2',
    ]
    impl = (f'Default pipeline z-scores (optionally detrends) each channel. For each unordered pair the first call bivariate(i=hi, j=lo) runs statsmodels coint_johansen on the '
      f'(T x 2) matrix [z_hi, z_lo] with {det_text}. VECM Delta y_t = Pi y_(t-1) + sum_(i=1..{k}) G_i Delta y_(t-i) + D_t + e_t (VAR order {k+1}); eigenvalues a_1 >= a_2 '
      f'of S_kk^-1 S_k0 S_00^-1 S_0k from residual moment matrices over m = T-{k}-1 samples. Returned: max_eig_stat = -m log(1-a_1) and trace_stat = -m [log(1-a_1)+log(1-a_2)] '
      '(tests of r=0). One fit serves both identifiers. Column order does not matter (probe: max relative swap difference <= 1.3e-11). Critical values, rank decision and eigenvectors are discarded.')
    dev_doc = ('(1) The supplement says "the maximum eigenvalue ... and the trace ... of the vector error correction model"; the code returns the LR test STATISTICS for rank 0 '
      '(-m log(1-a_1) and -m sum log(1-a_i)), not an eigenvalue or a matrix trace. (2) "constant (order-0)" / "constant and linear trend (order-1)" do not name the '
      'Johansen case; order-0 is the unrestricted constant, order-1 is the statsmodels pre-detrending scheme. (3) "autoregressive lags of 1 (ardiff-1) and 10" = number of '
      'lagged DIFFERENCES (VAR order k+1). (4) Citation [81] is Pesaran & Shin 1999 (ARDL), not Johansen 1988/1991. (5) Metadata: class label "nonlinear" (misc.py:26) vs '
      'documented keyword and config label "linear". (6) Supplement cites statsmodels v0.12.0; installed 0.15.0 (value changes between versions not assessed).')
    rec = {
      'unit_id': uid, 'status': 'traced',
      'correctness': {
        'metric_name_standard': f'Johansen cointegration rank test statistics for r=0 in a bivariate VECM: lambda-max (max_eig_stat) and trace (trace_stat); {"unrestricted constant" if det == 0 else "statsmodels det_order=1 (pre-detrended levels)"}, {k} lagged difference{"s" if k > 1 else ""}',
        'canonical_ref': 'Johansen S. 1988, J. Economic Dynamics and Control 12(2-3):231-254, "Statistical analysis of cointegration vectors" (LR trace test, eq. for -2lnQ); Johansen S. 1991, Econometrica 59(6):1551-1580 (deterministic terms, lambda-max); Johansen S. & Juselius K. 1990, Oxford Bull. Econ. Stat. 52(2):169-210 (models H1, H1*, constant restricted/unrestricted); Lutkepohl 2005, New Introduction to Multiple Time Series Analysis, §7.2 / §8.2 (statsmodels docstring reference)',
        'canonical_definition': 'R0t, R1t = residuals of Delta y_t and y_(t-1) on lagged differences Delta y_(t-1..t-k) and deterministic terms D_t; S_ij = m^-1 sum R_it R_jt\'; lambda_1 >= lambda_2 solve |lambda S11 - S10 S00^-1 S01| = 0; trace(r) = -m sum_(i=r+1..n) ln(1-lambda_i), lambda-max(r) = -m ln(1-lambda_(r+1)); here n=2, r=0. ' + ('Deterministic case: unrestricted constant (H1(r)).' if det == 0 else 'Documented "constant and linear trend" most naturally maps to the restricted-trend case H*(r) (trend in the cointegration space, unrestricted constant; urca ecdet="trend").'),
        'documented_definition': DOC_COMMON + ' Johansen bullet (supplement.txt:896-898): "For the Johansen test, we output both the maximum eigenvalue (modifier max_eig_stat) and the trace (trace_stat) of the vector error correction model. Similar to the AEG test, we also assume a constant (order-0) or constant and linear trend (order-1) and fixed autoregressive lags of 1 (ardiff-1) and 10 (ardiff-10)." Listed as SPIs 221-228.',
        'delegate_lib': 'statsmodels==0.15.0 statsmodels.tsa.vector_ar.vecm.coint_johansen (numpy==2.5.4 linalg inv/eig/cholesky/pinv)',
        'implemented_as': impl,
        'implementation_trace': trace,
        'deviation_from_documented': dev_doc,
        'deviation_from_canonical': dev_can,
        'units_and_range': f'dimensionless LR statistics (chi-square-type, non-standard asymptotics); both >= 0, trace_stat >= max_eig_stat, trace - max_eig = -m ln(1-lambda_2) (probe identity error <= 1.5e-14); grow O(T) when the pair is jointly stationary (iid_gaussian T=256 pair (1,0), k={k}, det={det}: trace {"203.18" if (det,k)==(0,1) else "50.40" if (det,k)==(0,10) else "205.73" if (det,k)==(1,1) else "54.03"}); no upper bound; raises LinAlgError (singular inverse or non-PD cholesky, vecm.py:690-694) for exactly collinear pairs, which makes the whole pipeline matrix NaN; symmetric by construction; NaN diagonal',
        'direction_convention': 'undirected: A[i,j] = A[j,i] = statistic of coint_johansen([z_max(i,j), z_min(i,j)]); the column order does not change the value (permutation invariance of the reduced-rank eigenvalues; probe swap difference <= 1.3e-11 relative), so no direction is encoded',
        'symmetry_expected': 'sym',
        'already_documented': 'no (tests/README.md:111 only lists coint_johansen_max_eig_stat_order-1_ardiff-1 among the preprocessing-variant snapshot SPIs; tests/README.md:492-499 lists run status/timing; nothing in KNOWN_ISSUES.md concerns coint)',
        'new_finding_candidates': [],
        'proposed_checks': [],
      }
    }
    c = rec['correctness']
    if det == 1:
        c['new_finding_candidates'].append(
          'CANDIDATE (definition, order-1 only): statsmodels det_order=1 detrends levels over the full sample before differencing (vecm.py:670) instead of putting a trend in the VECM; '
          'the statistic matches neither the restricted-trend (urca ecdet="trend") nor the unrestricted-trend Johansen case. Evidence ' + dev_can.split('Probes ')[1].split(' Unrestricted')[0]
          + ' (from-scratch RRR = urca to 6 decimals). Effect is largest on the trace statistic and at small T; pipeline detrend (data.py:186) leaves order-1 values unchanged (probe max abs diff <= 4.9e-11).')
    c['new_finding_candidates'] += [
      'CANDIDATE (conceptual): the documented premise ("individually integrated") is not checked; on stationary inputs the r=0 statistics are large and grow ~linearly with T, independent of coupling. '
      f'Probe (k={k}, det={det}): independent white noise iid_gaussian T=256 pair (1,0) trace {"203.18" if (det,k)==(0,1) else "50.40" if (det,k)==(0,10) else "205.73" if (det,k)==(1,1) else "54.03"} vs the truly cointegrated random-walk pair (cointegrated T=256 (1,0)) trace '
      f'{"111.01" if (det,k)==(0,1) else "35.16" if (det,k)==(0,10) else "109.65" if (det,k)==(1,1) else "32.92"}. For z-scored stationary data (EEG) the SPI therefore ranks pairs by persistence/stationarity of the channels rather than by cointegration (hypothesis to quantify in the check stage).',
      'CANDIDATE (robustness): exactly collinear pairs raise numpy LinAlgError inside coint_johansen (probe: shared_envelope x2 == x0 at T=256/1024 -> "Singular matrix"; z vs 3z+1 with det_order=1, k=10 -> "Matrix is not positive definite"); '
      'Calculator.compute (calculator.py:300-302) then stores an all-NaN matrix for the SPI, so one duplicated channel blanks every pair.',
      'CANDIDATE (numerics, value-neutral): with numpy 2.5.4 np.linalg.eig returns complex128 even for real spectra (probe: eig of [[2,1],[1,3]] -> complex128), so every call emits ComplexWarning at vecm.py:717-718 and silently drops the imaginary part; max |imag| over all probed pairs/datasets was 0.0.',
      'CANDIDATE (metadata): class label "nonlinear" (misc.py:26) while the supplement keyword and config.yaml:1294-1299 say "linear"; the Calculator never reads YAML labels (calculator.py:239-246). Probe: Cointegration().labels -> ["misc","unsigned","temporal","undirected","nonlinear"].',
      'CANDIDATE (documentation): the supplement says "maximum eigenvalue" and "trace" of the VECM; the outputs are the rank-0 LR statistics (misc.py:84-87 take max_eig_stat[0], trace_stat[0]); citation [81] (Pesaran & Shin 1999, ARDL) does not describe the Johansen test.',
      'CANDIDATE (robustness, latent): __init__ branches on method == "johansen" (misc.py:40) but _from_cache on method == "aeg" (misc.py:69); any other spelling builds an AEG-style identifier and then calls coint_johansen without _det_order. Probe: Cointegration(method="Johansen").bivariate(...) -> AttributeError: no attribute "_det_order". Not reachable from the shipped configs.',
    ]
    hi_lo = 'columns [z_hi, z_lo]'
    crit95 = ('MacKinnon-Haug-Michelis 1999 case "unrestricted constant", n-r=2: trace 15.495, lambda-max 14.265 (literature constants, re-check in the check stage)' if det == 0 else
              'MacKinnon-Haug-Michelis 1999 case "restricted trend", n-r=2: trace 25.872, lambda-max 19.387 (literature constants; the statsmodels det_order=1 statistic is not exactly this case)')
    c['proposed_checks'] = [
      {'datasets': ['cointegrated', 'iid_gaussian', 'trending', 'var2_bivariate', 'gauss_ar1_pair'], 'path': 'kernel',
       'reference': ('from-scratch numpy reduced-rank regression: R0, R1 = residuals of Delta y_t and y_(t-1) on [1, Delta y_(t-1..t-%d)] (np.linalg.lstsq), S_ij, generalized symmetric eigenproblem via scipy.linalg.eigh(S10 S00^-1 S01, S11); trace/max-eig with m = T-%d-1 (probe4.py joh(case="const_unres"))' % (k, k)) if det == 0 else
                    ('from-scratch numpy restricted-trend RRR (R1 augmented with t, constant unrestricted; probe4.py joh(case="trend_restr")) AND a from-scratch literal re-implementation of the statsmodels pre-detrending algorithm (vecm.py:650-718) for exact agreement'),
       'reference_kind': 'independent-impl', 'criterion': 'tolerance' if det == 0 else 'tolerance',
       'expected_outcome': ('relative difference <= 1e-9 on every pair and T for both statistics (probe: <= 4.2e-13)' if det == 0 else
                            'literal re-implementation (same-algorithm, numpy only) within 1e-9 relative; restricted-trend canonical case differs: trace up to ~9% lower at T=256 (cointegrated pairs (1,0),(2,0)), maxeig up to ~1.7%, shrinking with T')},
      {'datasets': ['cointegrated', 'iid_gaussian', 'trending'], 'path': 'kernel',
       'reference': 'R urca::ca.jo(x, type="eigen"/"trace", ecdet=%s, K=%d, spec="transitory"), last element of @teststat (r=0), x = [z_hi, z_lo]' % ('"none"' if det == 0 else '"trend"', k + 1),
       'reference_kind': 'external-pkg', 'criterion': 'tolerance',
       'expected_outcome': ('agreement <= 1e-8 relative (probe at T=256 cointegrated (1,0): identical to 6 printed decimals)' if det == 0 else
                            'DISAGREEMENT expected (canonical case 4 vs statsmodels det_order=1): cointegrated T=256 (1,0) trace %s vs urca %s; report the relative gap per T' % (('109.6488', '111.3300') if k == 1 else ('32.9154', '35.6445')))},
      {'datasets': ['cointegrated'], 'path': 'pipeline',
       'reference': 'analytic truth matrix is_cointegrated from the dataset (pair (0,1) cointegrated with vector [2,-1]; (0,2),(0,3),(1,2),(1,3),(2,3) not) plus ' + crit95,
       'reference_kind': 'analytic', 'criterion': 'statistical',
       'expected_outcome': 'at T >= 256 the (0,1) statistic exceeds the 95% critical value and every non-cointegrated pair; for non-cointegrated random-walk pairs the exceedance rate over a Monte Carlo of independent random walks (simulated in-check, from-scratch reference) is near 5% for order-0 (size check); report T=64 separately (k=10 leaves m=53)'},
      {'datasets': ['iid_gaussian', 'delayed_noise', 'var2_bivariate', 'cointegrated'], 'path': 'pipeline',
       'reference': 'qualitative stationarity confound: compare statistics on jointly stationary independent pairs with the cointegrated pair at the same T',
       'reference_kind': 'analytic', 'criterion': 'qualitative',
       'expected_outcome': 'independent white-noise pairs give statistics of the same order as or larger than the cointegrated pair and grow ~linearly in T (probe T=256: iid trace %s vs cointegrated %s); documents that the SPI does not measure coupling on I(0) data' % (
           ('203.18', '111.01') if (det, k) == (0, 1) else ('50.40', '35.16') if (det, k) == (0, 10) else ('205.73', '109.65') if (det, k) == (1, 1) else ('54.03', '32.92'))},
      {'datasets': ['cointegrated', 'delayed_noise', 'trending'], 'path': 'pipeline',
       'reference': 'direction convention: from-scratch statistic on [z_i, z_j] and on [z_j, z_i] for every pair; compare with A[i,j] and A[j,i]',
       'reference_kind': 'independent-impl', 'criterion': 'direction',
       'expected_outcome': 'A == A.T exactly (mirror + two-key cache), NaN diagonal; A[i,j] equals the from-scratch value for either column order within 1e-9 relative (order invariance), so the unit carries no direction'},
      {'datasets': ['bivariate_gaussian', 'scaled_offset', 'cointegrated'], 'path': 'pipeline',
       'reference': 'invariance of Johansen eigenvalues under per-channel positive affine maps (z-scoring on/off; scaled_offset = scale*D2 + offset)',
       'reference_kind': 'analytic', 'criterion': 'tolerance',
       'expected_outcome': 'scaled_offset == bivariate_gaussian and normalise=True == normalise=False within 1e-8 relative (probe raw vs z-scored max abs diff <= 4e-10)'},
      {'datasets': ['trending', 'cointegrated'], 'path': 'pipeline-detrend',
       'reference': 'from-scratch reference applied to scipy-free least-squares linearly detrended, z-scored series',
       'reference_kind': 'independent-impl', 'criterion': 'tolerance',
       'expected_outcome': ('values change with pipeline detrending (probe trending T=1024: up to %s absolute for trace) and match the from-scratch reference on detrended input within 1e-9 relative' % ('422' if k == 1 else '110') if det == 0 else
                            'pipeline detrend leaves order-1 values unchanged up to rounding (probe max abs diff 4.9e-11 on cointegrated, 1.1e-12 on trending): the full-sample level detrend in vecm.py:670 absorbs it')},
      {'datasets': ['shared_envelope'], 'path': 'pipeline',
       'reference': 'degenerate input (x2 bit-identical to x0)',
       'reference_kind': 'analytic', 'criterion': 'qualitative',
       'expected_outcome': 'kernel raises numpy LinAlgError for pair (0,2); Calculator stores an all-NaN matrix for the SPI (every pair lost)'},
      {'datasets': ['cointegrated', 'iid_gaussian'], 'path': 'kernel',
       'reference': 'analytic identities: trace_stat - max_eig_stat = -m ln(1 - lambda_2) >= 0; both >= 0; the two identifiers read one cached fit',
       'reference_kind': 'analytic', 'criterion': 'exact',
       'expected_outcome': 'identity holds within 1e-12 absolute (probe <= 1.5e-14); max_eig and trace identifiers produced by one coint_johansen call per pair'},
    ]
    return uid, rec

def aeg_record():
    uid = 'misc.coint.aeg'
    trace = PYSPI_HEAD + [
      'pyspi/config.yaml:1342-1358 three configs: (trend c, autolag aic), (ct, aic), (ct, bic), maxlag 10, statistic tstat; pyspi/sonnet_config.yaml:166-181 keeps only (ct, aic, 10) (GitBook miscellaneous.md:39 marks it as the "cointegration" representative)',
      'pyspi/statistics/misc.py:28-37, :46-52 __init__ else-branch (method != "johansen"): stores _autolag, _maxlag, _trend; identifier coint_aeg_tstat_trend-<trend>_autolag-<autolag>_maxlag-<maxlag>',
      'pyspi/statistics/misc.py:54-60 key = ("aeg", autolag, maxlag, trend)',
    ] + PYSPI_CACHE[:1] + [
      'pyspi/statistics/misc.py:69-78 stattools.coint(z[i], z[j], autolag, maxlag, trend) -> ci = {"tstat": stats[0]}; z[i] is the DEPENDENT variable y0',
    ] + PYSPI_CACHE[1:] + [
      f'{SP}/tsa/stattools/_stattools.py:2571-2579 coint(y0, y1, trend="c", method="aeg", maxlag=None, autolag="aic") (statsmodels 0.15.0)',
      f'{SP}/tsa/stattools/_stattools.py:2683-2688 xx = add_trend(y1, trend) (c: constant; ct: constant + linear trend); res_co = OLS(y0, xx).fit() (first-stage cointegrating regression)',
      f'{SP}/tsa/stattools/_stattools.py:2690-2706 if R^2 < 1 - 100*sqrt(eps) (SQRTEPS :84): adfuller(resid, maxlag, autolag, regression="n"); else CollinearityWarning and tstat = -inf',
      f'{SP}/tsa/stattools/_stattools.py:2708-2717 MacKinnon critical values and p-value (computed, discarded by pyspi)',
      f'{SP}/tsa/stattools/_stattools.py:352-363 adfuller input checks (constant series -> ValueError); :380-385 maxlag must be <= nobs//2 - 1 for regression "n" (T >= 22 for maxlag 10)',
      f'{SP}/tsa/stattools/_stattools.py:386-391 xdall = lagmat(diff(u), maxlag, trim="both", original="in"), column 0 replaced by the lagged level u_(t-1); common sample of T-1-maxlag rows',
      f'{SP}/tsa/stattools/_stattools.py:395-407 autolag: _autolag(OLS, xdshort, xdall, startlag=1, maxlag, ic) on the common sample',
      f'{SP}/tsa/stattools/_stattools.py:147-154 _autolag fits lags 0..maxlag and picks min aic / bic',
      f'{SP}/regression/linear_model.py:2143-2174 info_criteria: aic = -2 llf + 2 k, bic = -2 llf + ln(n) k, k = df_model + k_constant (number of regressors; no constant here)',
      f'{SP}/tsa/stattools/_stattools.py:420-427 re-run with the chosen lag p on the LARGEST sample for that lag (T-1-p rows)',
      f'{SP}/tsa/stattools/_stattools.py:433-436 resols = OLS(Delta u_t, [u_(t-1), Delta u_(t-1..t-p)]) (no deterministic term); adfstat = tvalues[0]',
    ]
    rec = {
      'unit_id': uid, 'status': 'traced',
      'correctness': {
        'metric_name_standard': 'Engle-Granger two-step (augmented Engle-Granger, AEG) residual-based cointegration test statistic: ADF t-ratio on the residuals of the cointegrating regression (with constant, or constant + linear trend), lag order chosen by AIC or BIC up to 10',
        'canonical_ref': 'Engle R.F. & Granger C.W.J. 1987, Econometrica 55(2):251-276 (two-step test, ADF on residuals, Table II); Said S.E. & Dickey D.A. 1984, Biometrika 71(3):599-607 (augmented DF); MacKinnon J.G. 1991/2010 (response-surface critical values, N=2); Phillips P.C.B. & Ouliaris S. 1990, Econometrica 58(1):165-193 (normalisation dependence of residual-based tests)',
        'canonical_definition': 'Step 1: OLS y0_t = alpha (+ delta t) + beta y1_t + u_t. Step 2: OLS Delta u_t = rho u_(t-1) + sum_(i=1..p) gamma_i Delta u_(t-i) + e_t (no deterministic term); statistic = t-ratio rho_hat / se(rho_hat); reject no-cointegration for values below the Engle-Granger/MacKinnon critical value (more negative = stronger evidence). The statistic depends on which variable is the regressand.',
        'documented_definition': DOC_COMMON + ' AEG bullet (supplement.txt:892-894): "For the AEG test, we use a lag that is inferred via either AIC (modifier aic) or BIC (bic), with a maximum lag of 10 and obtain a t-statistic (tstat) of the unit-root test on the residuals. The time series is first detrended by assuming either a constant (c) or a constant and linear trend (ct)." Listed as SPIs 229-231; keyword "undirected".',
        'delegate_lib': 'statsmodels==0.15.0 statsmodels.tsa.stattools.coint (method "aeg") -> adfuller(regression="n") -> OLS',
        'implemented_as': ('Default pipeline z-scores (optionally detrends) each channel. For each unordered pair a<b the first call is bivariate(i=b, j=a), so coint(y0 = z_b, y1 = z_a): OLS of the HIGHER-index channel '
          'on the lower-index channel plus constant (c) or constant + trend (ct); ADF without deterministic terms on the residuals with lag p in 0..10 chosen by min AIC/BIC on the common '
          'sample T-11, then re-fit on T-1-p rows; returns the t-ratio on u_(t-1). R^2 >= 1-100*sqrt(eps) returns -inf. Cache stores the value for both (b,a) and (a,b), and the '
          'Undirected mirror copies it, so A[a,b] = A[b,a] = EG(dependent = z_max(a,b), regressor = z_min(a,b)). The p-value and critical values are discarded; the value is returned '
          'with its sign (no negation despite the comment at misc.py:99).'),
        'implementation_trace': trace,
        'deviation_from_documented': ('(1) Asymmetry hidden: the documentation calls the SPI undirected and does not say which series is the regressand; the code uses the higher channel index as y0 under '
          'multivariate (cache + loop order) but z[i] (the first argument) under a direct bivariate call. (2) Sign: labelled "unsigned" (class Unsigned -> issigned() False, base.py:146-150) '
          'and the code comment says "Return the negative t-statistic" (misc.py:99), but the raw t-statistic is returned: typically negative, more negative = more cointegrated, '
          'opposite orientation to the Johansen identifiers. (3) "The time series is first detrended" is implemented as including the deterministic terms in the cointegrating '
          'regression (equivalent by Frisch-Waugh for the residuals). (4) Metadata: class label "nonlinear" vs documented "linear". (5) statsmodels v0.12.0 documented, 0.15.0 installed.'),
        'deviation_from_canonical': ('Value: none against the Engle-Granger two-step ADF t-ratio with constant/trend in step 1, no deterministic term in step 2, IC lag search on a common sample '
          'and refit on the largest sample. Probe: from-scratch numpy implementation reproduces pyspi to <= 4.2e-13 over cointegrated, iid_gaussian, trending, var2_bivariate, delayed_noise '
          'at T=64..4096 for all three configs; a variant that does not refit on the larger sample differs by up to 2.27, so the refit convention matters for references (e.g. R urca ur.df). '
          'Canonical EG requires a normalisation choice; pyspi fixes it by channel index rather than by a substantive rule.'),
        'units_and_range': 'dimensionless t-ratio, real-valued, unbounded below, can be positive; -inf (with CollinearityWarning) for (almost) collinear pairs (shared_envelope x2==x0); on stationary independent inputs it scales like -sqrt(T) (iid_gaussian c/aic off-diagonal range [-17.6,-10.0] at T=256, [-66.0,-45.8] at T=4096); pipeline matrix symmetric by caching/mirroring, kernel asymmetric; NaN diagonal',
        'direction_convention': 'undirected output, asymmetric kernel: A[i,j] = A[j,i] = coint(y0 = z_max(i,j), y1 = z_min(i,j)) (higher index regressed on lower index). Probe trending T=4096 pair (0,3): A[0,3] = -0.3646 = scratch EG(dep z3, reg z0), reverse orientation -61.2392; a direct bivariate(data_2ch) call (i=0, j=1) returns the reverse orientation (-61.2392) for the same pair',
        'symmetry_expected': 'sym',
        'already_documented': 'no (tests/README.md:500-502 lists run status/timing only; nothing in KNOWN_ISSUES.md concerns coint)',
        'new_finding_candidates': [
          'CANDIDATE (definition, index-order dependence): the reported value depends on channel ORDER. Undirected loop order (base.py:91-93, j outer) makes the first call bivariate(i=hi, j=lo), and misc.py:95 caches it for the reverse pair, so the higher index is always the dependent variable (pack hypothesis confirmed). Probes: cointegrated T=256 c/aic pair (0,2) -1.1141 (pyspi) vs -2.2943 reverse; pair (2,3) -2.4740 vs -1.7498; trending T=4096 c/aic pairs (0,1),(0,2),(0,3) about -0.37/-0.40 vs -61.24 reverse; iid_gaussian T=4096 (0,4) -66.05 vs -27.69 (AIC picks lag 0 vs 5). Permuting channels can change values by up to 60.9 (probe max).',
          'CANDIDATE (API inconsistency): the same pair gives different values through the two entry points. Probe trending T=4096 channels (0,3) as a 2-channel Data: Cointegration(aeg c aic).bivariate(D) (i=0, j=1, y0=z0) = -61.2392, while .multivariate(D)[0,1] = -0.3646; within one Data object the first call fixes the cached value for both orders.',
          'CANDIDATE (sign/metadata): Unsigned class and comment "Return the negative t-statistic" (misc.py:99) vs returned raw t-statistic (misc.py:103); all probed values are negative or near zero, and stronger cointegration = more negative, opposite to the Johansen identifiers of the same family.',
          'CANDIDATE (conceptual): on stationary inputs the statistic measures stationarity of the regression residual, not coupling: independent white noise (iid_gaussian T=256) gives [-17.6, -10.0], comparable to the truly cointegrated pair (cointegrated T=256 (0,1): -16.25).',
          'CANDIDATE (robustness): exactly collinear pairs return -inf (statsmodels _stattools.py:2700-2706; probe shared_envelope A[0,2] = -inf at T=256/1024, z vs 3z+1 -> -inf); -inf then enters downstream normalisation/averaging unless filtered.',
          'CANDIDATE (metadata): class label "nonlinear" (misc.py:26) while the supplement keyword and config.yaml:1294-1299 say "linear".',
          'CANDIDATE (robustness, latent): __init__ branches on == "johansen" (misc.py:40), _from_cache on == "aeg" (misc.py:69): a misspelt method (e.g. "AEG") builds an AEG identifier and then fails in the Johansen path. Probe: Cointegration(method="AEG").bivariate(...) -> AttributeError: no attribute "_det_order".',
        ],
        'proposed_checks': [
          {'datasets': ['cointegrated', 'iid_gaussian', 'trending', 'var2_bivariate', 'delayed_noise'], 'path': 'kernel',
           'reference': 'from-scratch numpy Engle-Granger: lstsq of y0 on [y1, 1(, t)], ADF design on residuals without deterministic term, lags 0..10 on the common sample, Gaussian llf aic/bic with k = #regressors, refit on the largest sample, t = b0/se (probe5.py eg/adf_t; no statsmodels import)',
           'reference_kind': 'independent-impl', 'criterion': 'tolerance',
           'expected_outcome': 'abs difference <= 1e-10 for all pairs, T in {64,256,1024,4096} and all three configs (probe max 4.2e-13), with y0 = higher-index channel'},
          {'datasets': ['cointegrated', 'iid_gaussian'], 'path': 'kernel',
           'reference': 'R urca::ur.df(residuals(lm(y0 ~ y1 [+ t])), type="none", lags=10, selectlags="AIC"/"BIC"), t-statistic tau1',
           'reference_kind': 'external-pkg', 'criterion': 'tolerance',
           'expected_outcome': 'same selected lag in most pairs; values agree to ~1e-8 only where urca\'s sample convention equals the statsmodels refit (urca keeps the maxlag-trimmed sample: hypothesis, record the gap otherwise)'},
          {'datasets': ['trending', 'cointegrated', 'iid_gaussian'], 'path': 'pipeline',
           'reference': 'direction convention: from-scratch EG in both orientations (y0 = z_i and y0 = z_j) for every pair; channel-permuted dataset (reverse row order) through the pipeline',
           'reference_kind': 'independent-impl', 'criterion': 'direction',
           'expected_outcome': 'A == A.T exactly; A[i,j] equals EG(dep = z_max(i,j)) within 1e-10 and differs from EG(dep = z_min(i,j)) (trending T=4096 (0,3): -0.3646 vs -61.2392); after reversing channel order the matrix changes (expected failure of order invariance)'},
          {'datasets': ['cointegrated'], 'path': 'pipeline',
           'reference': 'analytic truth matrix is_cointegrated (pair (0,1) cointegrated, others independent random walks) with MacKinnon 2010 N=2 asymptotic 5% critical values (c: about -3.34, ct: about -3.78; literature constants to be re-checked) and an in-check Monte Carlo of independent random walks using the from-scratch reference',
           'reference_kind': 'analytic', 'criterion': 'statistical',
           'expected_outcome': 'pair (0,1) below the 5% critical value at T >= 64 (probe T=64: -8.24 c/aic); non-cointegrated pairs reject at about the nominal 5% rate in the Monte Carlo; values for (0,1) the most negative entry of the matrix'},
          {'datasets': ['iid_gaussian', 'delayed_noise', 'var2_bivariate'], 'path': 'pipeline',
           'reference': 'qualitative stationarity confound: values on independent stationary pairs vs the cointegrated pair',
           'reference_kind': 'analytic', 'criterion': 'qualitative',
           'expected_outcome': 'independent white-noise pairs give strongly negative values scaling ~ -sqrt(T) (T=256: [-17.6,-10.0]; T=4096: [-66.0,-45.8]), i.e. "cointegrated" by the test regardless of coupling'},
          {'datasets': ['bivariate_gaussian', 'scaled_offset', 'cointegrated'], 'path': 'pipeline',
           'reference': 'invariance of the EG t-ratio under per-channel positive affine maps (scaled_offset vs bivariate_gaussian; normalise True vs False)',
           'reference_kind': 'analytic', 'criterion': 'tolerance',
           'expected_outcome': 'equal within 1e-10 (probe raw vs z-scored max abs diff 2e-13)'},
          {'datasets': ['trending'], 'path': 'pipeline-detrend',
           'reference': 'from-scratch EG on lstsq-detrended, z-scored series',
           'reference_kind': 'independent-impl', 'criterion': 'tolerance',
           'expected_outcome': 'match within 1e-10; ct configs unchanged by pipeline detrend (probe 1.8e-14), c config changes (probe up to 32.5 on trending T=1024)'},
          {'datasets': ['shared_envelope'], 'path': 'pipeline',
           'reference': 'degenerate input (x2 bit-identical to x0)',
           'reference_kind': 'analytic', 'criterion': 'qualitative',
           'expected_outcome': 'A[0,2] = A[2,0] = -inf with CollinearityWarning; other entries finite'},
        ],
      }
    }
    return uid, rec

recs = [joh_record(0, 10), joh_record(0, 1), joh_record(1, 10), joh_record(1, 1), aeg_record()]
for uid, rec in recs:
    with open(f'{OUT}/{uid}.yaml', 'w') as fh:
        yaml.safe_dump(rec, fh, sort_keys=False, width=200, allow_unicode=True)
    print('wrote', uid)
