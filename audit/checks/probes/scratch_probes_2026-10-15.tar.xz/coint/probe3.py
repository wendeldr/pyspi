from common import *
import io, contextlib, traceback
from pyspi.statistics.misc import Cointegration
from pyspi.data import Data
from statsmodels.tsa import stattools
from statsmodels.tsa.vector_ar.vecm import coint_johansen
def mk(x, norm=True, det=False):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x.copy(), dim_order='ps', normalise=norm, detrend=det)
x,_ = load('cointegrated', 256)
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter('always')
    coint_johansen(x[[0,1]].T, 0, 1)
    for ww in w: print('johansen warning:', ww.category.__name__, '|', str(ww.message)[:90], '|', ww.filename.split('site-packages/')[-1], ww.lineno)
# identical series: shared_envelope x2 == x0
for T in (256, 1024):
    x,_ = load('shared_envelope', T)
    print('shared_envelope x2==x0 bitwise:', np.array_equal(x[0], x[2]))
    D = mk(x)
    for cfg in CONFIGS:
        s = Cointegration(**cfg)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            try:
                A = s.multivariate(mk(x))
                print(T, s.identifier, 'A[0,2]=', A[0,2], 'A[0,1]=%.4f' % A[0,1], 'warn:', sorted({ww.category.__name__ for ww in w}))
            except Exception as e:
                print(T, s.identifier, 'RAISES', type(e).__name__, e)
# exactly collinear but scaled
z = np.random.default_rng(0).standard_normal(256).cumsum()
for cfg in CONFIGS[:2]+CONFIGS[8:9]:
    try:
        print('y=3x+1', Cointegration(**cfg).bivariate(mk(np.vstack([z, 3*z+1]))))
    except Exception as e:
        print('y=3x+1', cfg, 'RAISES', type(e).__name__, e)
# hypothesis 3: method spelled differently
for m in ['Johansen', 'AEG', 'foo']:
    try:
        s = Cointegration(method=m)
        print('method', m, 'identifier', s.identifier, 'key', s.key)
        v = s.bivariate(mk(load('cointegrated',256)[0][:2]))
        print('  value', v)
    except Exception as e:
        print('  method', m, 'RAISES', type(e).__name__, e)
# defaults of class
s = Cointegration(); print('default identifier', s.identifier)
# small T
for T in (64,):
    x,_ = load('cointegrated', T)
    for cfg in CONFIGS:
        try:
            A = Cointegration(**cfg).multivariate(mk(x)); print(T, Cointegration(**cfg).identifier, np.round(A[0,1],4), np.round(A[2,3],4))
        except Exception as e:
            print(T, cfg, 'RAISES', type(e).__name__, e)
