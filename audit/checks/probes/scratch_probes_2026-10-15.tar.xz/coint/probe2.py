from common import *
import io, contextlib, traceback
from pyspi.statistics.misc import Cointegration
from pyspi.data import Data
from statsmodels.tsa import stattools
from statsmodels.tsa.vector_ar.vecm import coint_johansen
print('np eig dtype on symmetric real', np.linalg.eig(np.array([[2.,1],[1,3]]))[0].dtype)
print('np eig dtype on nonsym real-eig', np.linalg.eig(np.array([[2.,1],[0.5,3]]))[0].dtype)
def mk(x, norm=True, det=False):
    with contextlib.redirect_stdout(io.StringIO()):
        return Data(x.copy(), dim_order='ps', normalise=norm, detrend=det)
# warnings captured
x,_ = load('cointegrated', 256)
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter('always')
    coint_johansen(x[[0,1]].T, 0, 1)
    print('johansen warnings:', [(str(ww.category.__name__), str(ww.message)[:80]) for ww in w])
# max imag part across datasets
mx = 0
for name in ['cointegrated','iid_gaussian','trending','var2_bivariate','delayed_noise','narrowband_f0-0.1','bivariate_gaussian','gauss_ar1_pair','logistic_maps']:
    for T in (64,256,1024,4096):
        x,_ = load(name, T)
        P = x.shape[0]
        for a in range(P):
            for b in range(a+1,P):
                for det in (0,1):
                    for k in (1,10):
                        with warnings.catch_warnings():
                            warnings.simplefilter('ignore')
                            try:
                                r = coint_johansen(x[[b,a]].T, det, k)
                                mx = max(mx, np.abs(np.imag(r.eig)).max())
                            except Exception as e:
                                print('ERR', name, T, a, b, det, k, type(e).__name__, e)
print('max |imag eig| over datasets', mx)
# normalisation invariance (raw vs z-scored), and detrend effect
for name in ['cointegrated','scaled_offset','trending']:
    x,_ = load(name, 1024)
    for cfg in CONFIGS:
        A1 = Cointegration(**cfg).multivariate(mk(x, True, False))
        A0 = Cointegration(**cfg).multivariate(mk(x, False, False))
        A2 = Cointegration(**cfg).multivariate(mk(x, True, True))
        off = ~np.eye(x.shape[0], dtype=bool)
        print(name, Cointegration(**cfg).identifier, 'max|norm-raw|=%.3g' % np.abs(A1-A0)[off].max(), 'max|detrend-nodetrend|=%.3g' % np.abs(A2-A1)[off].max())
