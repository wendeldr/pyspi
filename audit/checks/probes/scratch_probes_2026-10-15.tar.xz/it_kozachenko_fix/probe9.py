import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
X = np.load('/media/dan/Data/git/pyspi/audit/checks/data/shared_envelope_T1024.npz')['x']
d = Data(X, normalise=True)
je = it.JointEntropy(estimator='kozachenko')
for (i, j) in [(0, 1), (0, 2), (1, 2)]:
    print(i, j, repr(je.bivariate(d, i=i, j=j)))
