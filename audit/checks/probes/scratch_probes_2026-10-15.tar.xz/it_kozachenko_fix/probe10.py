# Naive NN routine: wrong distances occur only where the true NN distance rho > 1; wrong values lie in (1, rho)
import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import jpype as jp
from scipy.spatial import cKDTree
EU = jp.JClass('infodynamics.utils.EuclideanUtils')
viol = 0
for seed in (3, 11):
    rng = np.random.default_rng(seed)
    for d in (1, 2, 3, 5, 6, 10):
        for N in (2001, 4096):
            for c in (1.0, 0.05, 10.0):
                X = c*rng.standard_normal((N, d))
                true = cKDTree(X).query(X, k=2)[0][:, 1]
                naive = np.array(EU.computeMinEuclideanDistancesNaive(jp.JArray(jp.JDouble, 2)(X)))
                wrong = np.abs(naive - true) > 1e-12
                n_gt1 = int(np.sum(true > 1))
                bad = int(np.sum(wrong & (true <= 1))) + int(np.sum(wrong & (naive <= 1))) + int(np.sum(naive > true + 1e-12))
                viol += bad
                lo = f'{naive[wrong].min():.3f}' if wrong.any() else '-'
                print(f'seed={seed} d={d:2d} N={N} scale={c:5}: rho>1 {n_gt1:4d}  wrong {int(wrong.sum()):4d}  min wrong value {lo}  violations {bad}')
print('total violations of (wrong => rho>1 and 1<value<rho):', viol)
