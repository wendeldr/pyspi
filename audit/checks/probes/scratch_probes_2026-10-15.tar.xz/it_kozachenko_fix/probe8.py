# DI bias B: seed dependence of the KL gap vs Gaussian plug-in B, independent AR(1) pairs, T=1024
import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
from scipy.stats import zscore
from scipy.special import digamma, gammaln
from scipy.spatial import cKDTree
def H(X):
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    N, d = X.shape; dist, _ = cKDTree(X).query(X, k=2, p=2)
    return -digamma(1) + digamma(N) + (d/2)*np.log(np.pi) - gammaln(d/2+1) + d*np.mean(np.log(dist[:, 1]))
def HG(X):
    X = np.asarray(X, float); X = X[:, None] if X.ndim == 1 else X
    C = np.atleast_2d(np.cov(X, rowvar=False)); d = X.shape[1]
    return 0.5*(d*np.log(2*np.pi*np.e) + np.linalg.slogdet(C)[1])
def emb(x, k):
    T = len(x); return np.column_stack([x[k-1-i:T-i] for i in range(k)])
di = it.DirectedInfo(estimator='kozachenko'); cce = it.CausalEntropy(estimator='kozachenko')
def ar1(rng, phi, T):
    x = np.zeros(T + 500); e = rng.standard_normal(T + 500)
    for t in range(1, T + 500): x[t] = phi*x[t-1] + e[t]
    return x[500:]
T = 1024
for phi in (0.0, 0.5, 0.9):
    popB = (1 + 1/2 + 1/3 + 1/4 + 1/5 - 1) * (-0.5*np.log(1 - phi**2))
    gaps, idents, gBs = [], [], []
    for seed in range(10):
        rng = np.random.default_rng(seed)
        x, y = ar1(rng, phi, T), ar1(rng, phi, T)
        d = Data(np.vstack([x, y]), normalise=True)
        v = di.bivariate(d, i=0, j=1); c = cce.bivariate(d, i=0, j=1)
        z = zscore(np.vstack([x, y]), axis=1, ddof=1)[1]
        gap = v - (H(emb(z, 5)) - c)
        ident = sum(H(emb(z, k))/k for k in range(1, 6)) - H(emb(z, 5))
        gB = sum(HG(emb(z, k))/k for k in range(1, 6)) - HG(emb(z, 5))
        gaps.append(gap); idents.append(ident); gBs.append(gB)
    gaps, idents, gBs = map(np.array, (gaps, idents, gBs))
    print(f'phi={phi} popB={popB:.4f}')
    print('  KL gap      :', np.round(gaps, 3), f'mean={gaps.mean():.3f} sd={gaps.std(ddof=1):.3f} min={gaps.min():.3f} max={gaps.max():.3f}')
    print('  |gap-ident| max:', f'{np.abs(gaps-idents).max():.2e}')
    print('  Gaussian B  :', np.round(gBs, 3), f'mean={gBs.mean():.3f} sd={gBs.std(ddof=1):.3f}')
