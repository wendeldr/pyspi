"""Append the check-stage block to the it_kraskov records (status traced -> checked)."""
import yaml
from pathlib import Path

REC = Path("/media/dan/Data/git/pyspi/audit/records")
REF = "audit/checks/refs/it_kraskov.py"
PRB = "audit/checks/probes/it_kraskov_probes.py"
MI, MID = "infotheory.mi.kraskov", "infotheory.mi.kraskov_DCE"
TL, TLD = "infotheory.tlmi.kraskov", "infotheory.tlmi.kraskov_DCE"
TE1 = "infotheory.te.kraskov_k-1_kt-1_l-1_lt-1"
TED1 = "infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1"
TED2 = "infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1"
TEA = "infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4"
TEAD = "infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4"
KSG, THW = "infotheory.est.ksg1", "infotheory.theiler_window"

EST = (f"{REF}:mi_jidt/cmi_jidt/te_jidt/te_auto_jidt (N-1 column z-score, pure-Python java.util.Random(42) jitter port "
       f"in JIDT row/column order, then audit/checks/refs/_kernels_infotheory.py:mi_ksg1/cmi_ksg1 with normalise=False: "
       f"cKDTree max norm, k=4, strict counts, Theiler |s-t|<=W, guard N<=k+2W -> NaN); DCE window {REF}:window_raw "
       f"(explicit lag-loop ACF); no JIDT/jpype; numpy 2.5.4, scipy 1.18.1")
STAT = f"{REF}:chk_truth (analytic population value + Monte Carlo mean/SD of the same estimator without jitter under the generating model)"
NULL = f"{REF}:chk_null (mean over pairs vs Monte Carlo distribution on iid N(0,1) data)"
DIRN = f"{REF}:chk_direction (ground-truth coupling)"

COMMON_THREADS = ("threads: max|A(default NUM_THREADS=64) - A(NUM_THREADS=1)| = 7.1e-15 mi, 1.07e-14 mi_DCE, 1.6e-14 tlmi, "
                  "2.4e-15 te_k1, 1.8e-15 te_auto (bivariate_gaussian, *|threads); repeat runs bit-identical")
COMMON_TIES = ("seeds (logistic_maps T=256, NOISE_SEED 42/43/44, each seed reproduced by the from-scratch jitter port to <= 2.7e-15): "
               "pair 1->0 mi 0.2301/0.2270/0.2305, tlmi 0.2789/0.2770/0.2814, te_k1 0.1151/0.1133/0.1073, te_DCE_k1 0.0783/0.0802/0.0749, "
               "te_auto 0.1014/0.0891/0.0442; bivariate_gaussian T=1024 spread 0.0 (*|seeds)")
COPY_TE = ("var2_bivariate T=256 A[0,1] (Calculator / CalculatorFrame / deepcopy / pickle): te_auto 0.0606 / 0.1336 / 0.1336 / 0.1336 "
           "(= te_k1 0.1336), te_DCE_k2 0.1592 / 0.1344 / 0.1344 / 0.1344, te_k1 0.1336 on all four paths; getProperty read-back "
           "(te_auto): original (k 4, NOISE_SEED 42, AUTO_EMBED_METHOD MAX_CORR_AIS), deepcopy (4, NONE, NONE), pickle (4, 42, NONE); "
           "te_k1: deepcopy NOISE_SEED NONE, pickle keeps 42 (*|var2_bivariate|256|pipeline|copy, *|copyprops)")
COPY_MI = ("tied data: mi_kraskov logistic_maps T=256 A[0,1] Calculator 0.2301, CalculatorFrame 0.2248 (unseeded jitter after "
           "deepcopy), pickle 0.2301 (infotheory.mi.kraskov|logistic_maps|256|pipeline|copy, frame_vs_calculator 0.0053)")

R = {}

# ------------------------------------------------------------------------------------------- est.ksg1
R[KSG] = dict(
    check_method="independent-impl",
    check_reference=f"{EST}; {REF}:chk_direct (JIDT MI/CMI calculators driven directly by {PRB}:direct_jidt), "
                    f"{REF}:chk_semantics (analytic DYN_CORR_EXCL expectations, {PRB}:dce_semantics), {REF}:chk_props (literature: JIDT source a9b6b3e)",
    check_data="var2_chain T1024 and delayed_noise rows 0-2 T256 (direct, W in 0,1,2,5,20,85); 40-point deterministic pair and 32-point ramps (semantics); "
               "plus every *|ksg run of the nine SPI units (11 datasets, T 64-1024, tied logistic_maps included)",
    agreement_criterion="tolerance rtol 1e-10, atol 1e-12 (MI and CMI values, every W); semantics matrix exact; props qualitative",
    closeness="direct MI(x0;x1) and CMI(x0;x1|x2) for W = 0, 1, 2, 5, 20, 85: max_abs 3.6e-15 (var2_chain) and 5.3e-15 (delayed_noise); "
              "semantics: univariate and KdTree counts 31-2W for W=0..6, nearest admissible |s-t| = W+1, raise at N=4+2W and compute at N=5+2W, "
              "MI column max_abs 1.3e-15 (the alternative |s-t|<W rule gives different MI, e.g. W=1 -0.0559 vs -0.0075); props: availableProcessors 64 = "
              "NUM_THREADS of the MI and CMI calculators, BIAS_CORRECTION getProperty None for MI and TE, fresh NOISE_SEED unset, 42 after pyspi _setup. "
              "Across the 64 *|ksg runs of the nine SPIs the from-scratch estimator agrees to <= 7.1e-15, including logistic_maps (tied, 4 distinct values) where the seeded jitter decides neighbour order.",
    verdict="matches",
    score_0_10=9,
    what_changed="KSG algorithm 1 MI and Frenzel-Pompe CMI exactly as published; conventions on top: N-1 column z-scoring, N(0,1e-8^2) jitter from java.util.Random(NOISE_SEED=42) "
                 "that decides the value on tied data, max norm, nats, psi(N) left unadjusted under a Theiler window (JIDT TODO, MutualInfoCalculatorMultiVariateKraskov1.java a9b6b3e:102-104), "
                 "partial sums over 64 threads (last-bit dependence on core count). Score 9 not 10 for the tie/jitter and psi(N) conventions.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: from-scratch estimator <= 0.2 s per matrix at T=1024; JIDT probes < 1 s",
    symmetry_observed="n/a (estimator); MI symmetric in its arguments: ordered matrices max|O - O.T| = 0.0 (mi.kraskov|*|ordered)",
    direction_observed="n/a (estimator); exclusion semantics: neighbour s of t excluded iff |s - t| <= DYN_CORR_EXCL (W=0 excludes only t)",
    candidate_resolutions=[
        dict(candidate="bundled jar is not the v1.6.1 release (NOISE_SEED honoured)", outcome="confirmed",
             evidence="the seeded stream is honoured: from-scratch java.util.Random port reproduces pyspi for NOISE_SEED 42/43/44 on tied data "
                      "(*|logistic_maps|256|pipeline|seeds, <= 2.7e-15; spreads up to 0.057 nats), which the v1.6.1 tag (unseeded new Random()) could not; "
                      "the exact master commit (a9b6b3e by date) is not confirmed byte-for-byte"),
        dict(candidate="value depends on core count at ~1e-14 (NUM_THREADS = availableProcessors)", outcome="confirmed",
             evidence=f"infotheory.est.ksg1|iid_gaussian|64|kernel|props (NUM_THREADS 64 = availableProcessors); {COMMON_THREADS}"),
        dict(candidate="on tied/discrete inputs the estimate is set by the jitter and its seed", outcome="confirmed", evidence=COMMON_TIES),
        dict(candidate="BIAS_CORRECTION=false is a no-op for the Kraskov calculators", outcome="confirmed",
             evidence="infotheory.est.ksg1|iid_gaussian|64|kernel|props: getProperty('BIAS_CORRECTION') is None for the MI and TE calculators"),
        dict(candidate="estimates negative on independent data despite 'unsigned' (estimator property)", outcome="confirmed",
             evidence="*|iid_gaussian|256|pipeline|null: minima mi -0.055, mi_DCE -0.036, tlmi -0.067, te_k1 -0.061, te_DCE_k1 -0.070, te_DCE_k2 -0.058, "
                      "te_auto -0.057; means consistent with the Monte Carlo null (|z| <= 1.6). Estimator property, not a defect"),
    ],
    checks_run=[
        dict(run_ids=["infotheory.est.ksg1|var2_chain|1024|kernel|direct", "infotheory.est.ksg1|delayed_noise-p012|256|kernel|direct"],
             reference=f"{REF}:chk_direct", outcome="pass 2/2; max_abs 5.3e-15"),
        dict(run_ids=["infotheory.est.ksg1|iid_gaussian|64|kernel|semantics"], reference=f"{REF}:chk_semantics", outcome="pass; max_abs 1.3e-15"),
        dict(run_ids=["infotheory.est.ksg1|iid_gaussian|64|kernel|props"], reference=f"{REF}:chk_props", outcome="pass (qualitative)"),
    ],
)

# ------------------------------------------------------------------------------------------- theiler window
R[THW] = dict(
    check_method="independent-impl",
    check_reference=f"{REF}:chk_lagloop (explicit lag-loop biased ACF, 2 sum_k r_i r_j over k=0..T-1, no np.correlate); {REF}:chk_bartlett "
                    "(audit/checks/refs/_kernels_infotheory.py:theiler_window_bartlett + 1); {REF}:chk_pop (population Bartlett tau from VAR autocovariances, "
                    f"Monte Carlo of the rule); {REF}:chk_growth (sinusoid closed form ~T/3); {REF}:chk_detrend; values read through {PRB}:theiler_raw (data.theiler)",
    check_data="iid_gaussian, bivariate_gaussian, var2_bivariate, gauss_ar1_pair, delayed_noise, narrowband_f0-0.1, logistic_maps, cointegrated, trending, shared_envelope at T1024 "
               "(pipeline; trending and cointegrated also pipeline-detrend); narrowband_f0-0.1 at T64/256/1024/4096",
    agreement_criterion="raw window rtol 1e-10 / atol 1e-12 and integer windows identical; Bartlett+1 rtol 1e-10; population statistical (|pyspi - MC mean| <= 2 MC SD); growth and detrend qualitative",
    closeness="lagloop: 12/12 pass with max_abs 0.0 and int_mismatch 0 (integer windows: iid 1-2, bivariate 2, var2 2, gauss_ar1 5, delayed_noise 2, narrowband 339, "
              "logistic_maps 208, cointegrated 158-205 (37-111 detrended), trending 1-350 (2 detrended), shared_envelope 18-273). Bartlett: raw - (1 + 2 sum_(k>=1) r_i r_j) = 1.0000 "
              "on all 11 pairs (var2_bivariate raw 2.6398 vs Bartlett 1.6398, int 2; iid_gaussian Bartlett 0.940-1.040, raw 1.940-2.040, int 1-2), max_abs 1.3e-15. "
              "Population: tau+1 = 2.00 (iid), 2.34 (var2), 3.63 (gauss_ar1) vs pyspi raw 2.024 / 2.640 / 5.145 and MC mean of the rule 2.001 / 2.739 / 5.061 (z 0.60 / 0.83 / 0.12): "
              "beyond the +1, the all-lag sum of sample ACF products adds a positive finite-sample bias on correlated pairs (+0.39 var2, +1.44 gauss_ar1). Growth: narrowband_f0-0.1 raw "
              "22.1 / 85.4 / 339.2 / 1352.9 at T=64/256/1024/4096, within 1.2% of 2a^2 sum_k (1-k/T)^2 cos^2(wk) (0.346 T -> 0.330 T). Detrend: trending pairs 340-350 -> 2.0-2.7; cointegrated 158-206 -> 38-111.",
    verdict="variant",
    score_0_10=6,
    what_changed="Documented as 'the product of the autocorrelation functions of both time series (a heuristic for the autocorrelation time based on Bartlett's formula)'; implemented as "
                 "W = int(2 sum_{k=0}^{T-1} r_i(k) r_j(k)) over all lags of the biased sample ACFs. That is exactly Bartlett's factor 1 + 2 sum_{k>=1} r_i r_j plus 1 (lag 0 counted twice), "
                 "with no lag truncation, so it carries a positive finite-sample bias on correlated pairs and grows linearly with T (about T/3) for oscillatory, trending or random-walk input, "
                 "where it is not an autocorrelation time. Computed once per Data object for all pairs and cached.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: <= 0.3 s per probe at T=4096",
    symmetry_observed="sym: W[i,j] = W[j,i] exactly (max|W - W.T| = 0.0 on every lagloop run)",
    direction_observed="n/a (symmetric pair quantity)",
    candidate_resolutions=[
        dict(candidate="raw window = Bartlett + 1 before int()", outcome="confirmed",
             evidence="infotheory.theiler_window|var2_bivariate|1024|pipeline|bartlett, infotheory.theiler_window|iid_gaussian|1024|pipeline|bartlett: raw - Bartlett = 1.0000 on 11 pairs (max_abs 1.3e-15)"),
        dict(candidate="window computed for all pairs on the first call and cached as data.theiler, not recomputed per pair", outcome="confirmed",
             evidence="infotheory.theiler_window|*|lagloop: one _set_theiler_window(data, 0, 1) call fills the whole P x P matrix (probe theiler_raw); pyspi/statistics/infotheory.py:197-212"),
        dict(candidate="all-lag sum makes W grow with T on oscillatory/trending/random-walk input", outcome="confirmed",
             evidence="infotheory.theiler_window|narrowband_f0-0.1|{64,256,1024,4096}|pipeline|growth: 22.1/85.4/339.2/1352.9 (0.33 T); lagloop T=1024: logistic_maps 208, trending 350, cointegrated 205, shared_envelope 273"),
        dict(candidate="large W makes the DCE auto-embedding TE NaN at small T", outcome="confirmed",
             evidence="infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4|{narrowband_f0-0.1,logistic_maps,shared_envelope}|64|kernel|ksg: 6/6, 2/2, 6/12 NaN, the NaN mask reproduced exactly by the guard N <= 4 + 2W of the k=10, tau=4 AIS candidate"),
        dict(candidate="efficiency: ACF recomputed inside the pair loop (P(P-1) evaluations instead of P)", outcome="confirmed",
             evidence="code reading pyspi/statistics/infotheory.py:202-209 (utils.acf(src), utils.acf(targ) inside the _i/_j loop); output unaffected (lagloop max_abs 0.0)"),
    ],
    checks_run=[
        dict(run_ids=["infotheory.theiler_window|*|1024|pipeline|lagloop", "infotheory.theiler_window|trending|1024|pipeline-detrend|lagloop",
                      "infotheory.theiler_window|cointegrated|1024|pipeline-detrend|lagloop"], reference=f"{REF}:chk_lagloop", outcome="pass 12/12; max_abs 0.0, integer mismatches 0"),
        dict(run_ids=["infotheory.theiler_window|var2_bivariate|1024|pipeline|bartlett", "infotheory.theiler_window|iid_gaussian|1024|pipeline|bartlett"],
             reference=f"{REF}:chk_bartlett", outcome="pass 2/2; raw - Bartlett = 1.0000"),
        dict(run_ids=["infotheory.theiler_window|iid_gaussian-p01|1024|pipeline|pop", "infotheory.theiler_window|gauss_ar1_pair|1024|pipeline|pop",
                      "infotheory.theiler_window|var2_bivariate|1024|pipeline|pop"], reference=f"{REF}:chk_pop", outcome="pass 3/3; z <= 0.83; population tau+1 2.00/3.63/2.34 vs pyspi 2.02/5.14/2.64"),
        dict(run_ids=["infotheory.theiler_window|narrowband_f0-0.1|{64,256,1024,4096}|pipeline|growth"], reference=f"{REF}:chk_growth", outcome="pass 4/4; within 1.2% of the T/3 closed form"),
        dict(run_ids=["infotheory.theiler_window|trending|1024|pipeline-detrend|detrend", "infotheory.theiler_window|cointegrated|1024|pipeline-detrend|detrend"],
             reference=f"{REF}:chk_detrend", outcome="pass 2/2; trending 350 -> 2.7, cointegrated stays 38-111"),
    ],
)

# ------------------------------------------------------------------------------------------- MI
R[MI] = dict(
    check_method="independent-impl",
    check_reference=f"{EST} ({REF}:chk_ksg, chk_ordered, chk_invariance, chk_seeds, chk_copy); audit/checks/refs/_kernels_infotheory.py:mi_ksg1 without jitter ({REF}:chk_nojitter); "
                    f"external sklearn==1.9.1 feature_selection.mutual_info_regression(n_neighbors=4) ({REF}:chk_sklearn); {STAT}; {NULL}; {REF}:chk_threads (same-lineage)",
    check_data="bivariate_gaussian T256/1024/4096, nonlinear_dependence T1024, delayed_noise T1024, iid_gaussian T64/T256, logistic_maps T256 (tied), narrowband_f0-0.1 T1024, gauss_ar1_pair T1024, scaled_offset T1024; kernel and pipeline paths",
    agreement_criterion="tolerance rtol 1e-10 / atol 1e-12 (from-scratch, kernel, sklearn); statistical |pyspi - MC mean| <= 2 MC SD; null qualitative",
    closeness="from-scratch KSG1: 7/7 ksg runs max_abs <= 4.4e-15 (logistic_maps tied 8.9e-16); kernel mi_ksg1 with no jitter at all 3.6e-15 (bivariate_gaussian, nonlinear_dependence); "
              "sklearn KSG1 0.0 to 1.3e-15 on the four positive-MI pairs; ordered (unmirrored) matrices 3.6e-15 with max|O - O.T| = 0.0; scaled_offset invariance 3.6e-15. "
              "Convergence to -0.5 ln(1-rho^2): pair (0,1) truth 0.0472: pyspi 0.0284 / 0.0333 / 0.0595 at T=256/1024/4096 (MC mean 0.0485/0.0490/0.0463, SD 0.040/0.022/0.010); "
              "pair (2,3) truth 0.5108: 0.5379 / 0.4990 / 0.5084 (MC SD 0.063/0.031/0.016); all |z| <= 1.31. gauss_ar1_pair (autocorrelated) 0.1395 vs population 0.1578 (MC 0.1572, z 0.54). "
              "Null iid T=256: mean -0.0186 (MC -0.0007 +- 0.0112, z -1.60), min -0.055, 80% negative.",
    verdict="matches",
    score_0_10=10,
    what_changed="None in value: KSG1 (k=4, max norm) in nats, fp-exact against an independent implementation and bit-level equal to sklearn's KSG1 on continuous data. Conventions: 1e-8 seeded jitter "
                 "(inert on tie-free data, decides tied data), negative finite-sample values despite the 'unsigned' label. Each unordered pair is estimated twice (efficiency only).",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: pyspi <= 2.6 s at T=1024 (machine under load), <= 1 s at T=4096 for one pair",
    symmetry_observed="sym: max|A - A.T| = 0.0 on every run; the unmirrored ordered matrix is also exactly symmetric (max|O - O.T| = 0.0, *|ordered)",
    direction_observed="undirected: A[i,j] = A[j,i] = I(x_i; x_j) at lag 0 (delayed_noise lag-0 MI near 0 as expected for white x0)",
    candidate_resolutions=[
        dict(candidate="bundled jar is not the v1.6.1 release", outcome="confirmed", evidence="see infotheory.est.ksg1: seeded jitter reproduced for seeds 42/43/44 (infotheory.mi.kraskov|logistic_maps|256|pipeline|seeds)"),
        dict(candidate="core-count dependence at 1e-14", outcome="confirmed", evidence="infotheory.mi.kraskov|bivariate_gaussian|1024|pipeline|threads: 7.1e-15, repeat 0.0"),
        dict(candidate="tied inputs: value set by jitter seed", outcome="confirmed", evidence="infotheory.mi.kraskov|logistic_maps|256|pipeline|seeds: 0.2301/0.2270/0.2305 for seeds 42/43/44 (spread 0.0035), each reproduced to 8.9e-16; bivariate_gaussian spread 0.0"),
        dict(candidate="negative values despite 'unsigned' (estimator property)", outcome="confirmed", evidence="infotheory.mi.kraskov|iid_gaussian|256|pipeline|null: min -0.055, 80% of pairs negative, mean within the MC null (z -1.60)"),
        dict(candidate="BIAS_CORRECTION no-op", outcome="confirmed", evidence="infotheory.est.ksg1|iid_gaussian|64|kernel|props"),
        dict(candidate="deepcopy (CalculatorFrame) loses NOISE_SEED and prop_k", outcome="confirmed", evidence=COPY_MI + "; deepcopy reads NOISE_SEED NONE (infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copyprops, same JIDTBase.__deepcopy__)"),
        dict(candidate="efficiency: every unordered pair estimated twice", outcome="confirmed", evidence="*|ordered runs: bivariate(i,j) == bivariate(j,i) exactly (max|O - O.T| = 0.0), so the discarded lower triangle duplicates the upper"),
    ],
    checks_run=[
        dict(run_ids=["infotheory.mi.kraskov|*|kernel|ksg", "infotheory.mi.kraskov|bivariate_gaussian|256|pipeline|ksg"], reference=f"{REF}:chk_ksg", outcome="pass 7/7; max_abs <= 4.4e-15"),
        dict(run_ids=["infotheory.mi.kraskov|bivariate_gaussian|1024|kernel|nojitter", "infotheory.mi.kraskov|nonlinear_dependence|1024|kernel|nojitter"], reference=f"{REF}:chk_nojitter", outcome="pass 2/2; 3.6e-15"),
        dict(run_ids=["infotheory.mi.kraskov|*-p*|1024|kernel|sklearn"], reference=f"{REF}:chk_sklearn (external-pkg)", outcome="pass 4/4; <= 1.3e-15"),
        dict(run_ids=["infotheory.mi.kraskov|bivariate_gaussian-p01|{256,1024,4096}|pipeline|truth", "infotheory.mi.kraskov|bivariate_gaussian-p23|{256,1024,4096}|pipeline|truth",
                      "infotheory.mi.kraskov|gauss_ar1_pair|1024|pipeline|truth"], reference=f"{REF}:chk_truth", outcome="pass 7/7; max z 1.31"),
        dict(run_ids=["infotheory.mi.kraskov|iid_gaussian|256|pipeline|null"], reference=f"{REF}:chk_null", outcome="pass; z -1.60"),
        dict(run_ids=["infotheory.mi.kraskov|scaled_offset|1024|pipeline|invariance", "infotheory.mi.kraskov|*|pipeline|ordered"], reference=f"{REF}:chk_invariance, chk_ordered", outcome="pass 4/4; <= 4.4e-15, ordered asymmetry 0.0"),
        dict(run_ids=["infotheory.mi.kraskov|bivariate_gaussian|1024|pipeline|threads", "infotheory.mi.kraskov|logistic_maps|256|pipeline|seeds", "infotheory.mi.kraskov|bivariate_gaussian|1024|pipeline|seeds"],
             reference=f"{REF}:chk_threads (same-lineage), chk_seeds", outcome="pass 3/3; threads 7.1e-15, seeds reproduced <= 3.6e-15"),
        dict(run_ids=["infotheory.mi.kraskov|logistic_maps|256|pipeline|copy"], reference=f"{REF}:chk_copy", outcome="fail (finding): CalculatorFrame 0.2248 vs 0.2301; Calculator and pickle 8.9e-16"),
    ],
)

# ------------------------------------------------------------------------------------------- MI DCE
R[MID] = dict(
    check_method="independent-impl",
    check_reference=f"{EST} ({REF}:chk_ksg, chk_ordered, chk_invariance); {STAT}; {NULL}; {REF}:chk_threads (same-lineage); window rule: see infotheory.theiler_window",
    check_data="bivariate_gaussian T256/1024, nonlinear_dependence, delayed_noise, narrowband_f0-0.1, gauss_ar1_pair T1024, iid_gaussian T64/256, logistic_maps T256, narrowband_f0-0.25 T64, trending T1024 (pipeline-detrend), scaled_offset T1024",
    agreement_criterion="tolerance rtol 1e-10 / atol 1e-12; statistical |pyspi - MC mean| <= 2 MC SD; null qualitative",
    closeness="from-scratch KSG1 with the pair window: 10/10 ksg runs max_abs <= 7.1e-15 for W from 1 to 339 (narrowband_f0-0.1 W=339, logistic_maps W=39, narrowband_f0-0.25 T=64 W=22, trending detrended W=2); ordered 3.6e-15 (asymmetry 0.0); "
              "invariance 3.6e-15. Statistical: bivariate_gaussian (0,1) 0.0381 vs MC 0.0550 (z 0.79), (2,3) 0.5050 vs 0.5210 (z 0.52); gauss_ar1_pair (W=5) 0.1475 vs population 0.1578, MC mean of the DCE estimator 0.1697 "
              "(non-DCE MC mean 0.1572): the window adds +0.012 expected bias here instead of removing one. Null iid T=256: mean 0.0008 (MC 0.0125 +- 0.0125, z -0.93), min -0.036. "
              "Effect of the window: narrowband_f0-0.1 T=1024 A[0,1] 1.442 (no DCE) -> 2.254 (W=339); logistic_maps T=256 0.230 -> 0.606 (W=39).",
    verdict="variant",
    score_0_10=7,
    what_changed="KSG1 with a Theiler window is computed exactly as JIDT defines it (|s-t| <= W excluded, psi(N) unadjusted), but the window comes from the pyspi rule int(Bartlett + 1) over all lags "
                 "(infotheory.theiler_window), which grows to about T/3 on oscillatory or trending input and then raises the estimate strongly (narrowband 1.44 -> 2.25 nats). Matches the supplement's DCE description "
                 "in kind; differs from canonical practice (W of the order of the autocorrelation time) in a value-changing way.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: pyspi <= 2.6 s at T=1024",
    symmetry_observed="sym: max|A - A.T| = 0.0 on every run; ordered matrix also exactly symmetric (W_ij = W_ji)",
    direction_observed="undirected: A[i,j] = A[j,i] = I(x_i; x_j) with Theiler window W_ij",
    candidate_resolutions=[
        dict(candidate="window = int(Bartlett + 1), cached once per Data", outcome="confirmed", evidence="infotheory.theiler_window|*|bartlett and |lagloop (raw - Bartlett = 1.0000; whole matrix filled by one call)"),
        dict(candidate="W scales with T on oscillatory/trending/slow input", outcome="confirmed", evidence="infotheory.theiler_window|narrowband_f0-0.1|*|growth (0.33 T); infotheory.mi.kraskov_DCE|narrowband_f0-0.1|1024|kernel|ksg W=339"),
        dict(candidate="DCE raises the estimate markedly on these inputs", outcome="confirmed",
             evidence="infotheory.mi.kraskov|narrowband_f0-0.1|1024|kernel|ksg 1.442 vs infotheory.mi.kraskov_DCE|narrowband_f0-0.1|1024|kernel|ksg 2.254; logistic_maps T=256 0.230 vs 0.606; both reproduced to <= 2.7e-15"),
        dict(candidate="core-count dependence at 1e-14", outcome="confirmed", evidence="infotheory.mi.kraskov_DCE|bivariate_gaussian|1024|pipeline|threads: 1.07e-14, repeat 0.0"),
        dict(candidate="tied inputs: value set by jitter seed", outcome="confirmed", evidence="same calculator and jitter path as mi.kraskov (infotheory.mi.kraskov|logistic_maps|256|pipeline|seeds spread 0.0035); the DCE value on tied logistic_maps (0.606) is reproduced only with the seeded jitter port (infotheory.mi.kraskov_DCE|logistic_maps|256|kernel|ksg 2.7e-15)"),
        dict(candidate="negative values despite 'unsigned'", outcome="confirmed", evidence="infotheory.mi.kraskov_DCE|iid_gaussian|256|pipeline|null: min -0.036, 50% negative"),
        dict(candidate="deepcopy (CalculatorFrame) loses NOISE_SEED and prop_k", outcome="confirmed", evidence="same JIDTBase.__deepcopy__ as mi.kraskov: " + COPY_MI),
        dict(candidate="efficiency: every unordered pair estimated twice", outcome="confirmed", evidence="infotheory.mi.kraskov_DCE|bivariate_gaussian|1024|pipeline|ordered: max|O - O.T| = 0.0"),
    ],
    checks_run=[
        dict(run_ids=["infotheory.mi.kraskov_DCE|*|kernel|ksg", "infotheory.mi.kraskov_DCE|bivariate_gaussian|256|pipeline|ksg", "infotheory.mi.kraskov_DCE|trending|1024|pipeline-detrend|ksg"],
             reference=f"{REF}:chk_ksg", outcome="pass 10/10; max_abs <= 7.1e-15"),
        dict(run_ids=["infotheory.mi.kraskov_DCE|bivariate_gaussian-p01|1024|pipeline|truth", "infotheory.mi.kraskov_DCE|bivariate_gaussian-p23|1024|pipeline|truth", "infotheory.mi.kraskov_DCE|gauss_ar1_pair|1024|pipeline|truth"],
             reference=f"{REF}:chk_truth", outcome="pass 3/3; max z 0.79"),
        dict(run_ids=["infotheory.mi.kraskov_DCE|iid_gaussian|256|pipeline|null"], reference=f"{REF}:chk_null", outcome="pass; z -0.93"),
        dict(run_ids=["infotheory.mi.kraskov_DCE|scaled_offset|1024|pipeline|invariance", "infotheory.mi.kraskov_DCE|bivariate_gaussian|1024|pipeline|ordered", "infotheory.mi.kraskov_DCE|bivariate_gaussian|1024|pipeline|threads"],
             reference=f"{REF}:chk_invariance, chk_ordered, chk_threads", outcome="pass 3/3; 3.6e-15; threads 1.07e-14"),
    ],
)

# ------------------------------------------------------------------------------------------- TLMI
TL_DIR = ("A[i,j] = I(x_i(t); x_j(t+1)), row = earlier (source) channel: delayed_noise A[0,1] 2.323 vs A[1,0] -0.004 (lag-3/5 pairs |A| <= 0.047); var2_bivariate 0.164 vs -0.032; "
          "gauss_ar1_pair 0.139 vs 0.196 (population 0.127 vs 0.174)")
R[TL] = dict(
    check_method="independent-impl",
    check_reference=f"{EST} on (x_i[:-1], x_j[1:]) ({REF}:chk_ksg, chk_seeds); {STAT} (Gaussian lagged MI from Gamma(1)); {NULL}; {DIRN}; {REF}:chk_threads (same-lineage)",
    check_data="delayed_noise, var2_bivariate, gauss_ar1_pair, bivariate_gaussian T1024; iid_gaussian T256; logistic_maps T256 (tied); delayed_noise rows 0-1 T1024 (truth)",
    agreement_criterion="tolerance rtol 1e-10 / atol 1e-12; statistical |pyspi - MC mean| <= 2 MC SD; direction and null qualitative",
    closeness="from-scratch lag-1 KSG1: 6/6 ksg runs max_abs <= 5.3e-15. Statistical: gauss_ar1_pair 0.1386 / 0.1958 vs population 0.1266 / 0.1738 (MC 0.1309 / 0.1771, z 0.50); "
              "delayed_noise (0,1) 2.3233 vs 0.5 ln 101 = 2.3076 (MC 2.3280, z 0.32). Null iid T=256: mean -0.0012 (MC 0.0009 +- 0.0083, z -0.24), min -0.067. Direction 3/3 pass.",
    verdict="matches",
    score_0_10=9,
    what_changed="Value: canonical lag-1 lagged MI I(X_t; Y_{t+1}) by KSG1, fp-exact. Documentation: the supplement keywords/text call tlmi 'undirected' while the code labels it directed and the output is asymmetric "
                 "(row = earlier channel); GitBook says directed. Score 9 for that documentation conflict; asymmetry itself already documented (REVIEW M8).",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: pyspi <= 2.6 s at T=1024",
    symmetry_observed="asym: max|A - A.T| = 2.327 (delayed_noise T1024), 0.196 (var2_bivariate), 0.057 (gauss_ar1_pair)",
    direction_observed=TL_DIR,
    candidate_resolutions=[
        dict(candidate="lag convention src = x_i[:-1], targ = x_j[1:] (I(X_t; Y_{t+1}), X = row)", outcome="confirmed", evidence="infotheory.tlmi.kraskov|*|kernel|ksg (6/6, <= 5.3e-15) and *|direction (delayed_noise A[0,1] 2.323)"),
        dict(candidate="documentation: supplement 'undirected' vs code/GitBook 'directed'", outcome="confirmed", evidence="infotheory.tlmi.kraskov|delayed_noise|1024|pipeline|direction: max|A - A.T| = 2.327; supplement §1.4.4 keyword list"),
        dict(candidate="core-count dependence at 1e-14", outcome="confirmed", evidence="infotheory.tlmi.kraskov|bivariate_gaussian|1024|pipeline|threads: 1.6e-14, repeat 0.0"),
        dict(candidate="tied inputs: value set by jitter seed", outcome="confirmed", evidence="infotheory.tlmi.kraskov|logistic_maps|256|pipeline|seeds: 1->0 0.2789/0.2770/0.2814 (spread 0.0051), reproduced to 2.7e-15"),
        dict(candidate="negative values despite 'unsigned'", outcome="confirmed", evidence="infotheory.tlmi.kraskov|iid_gaussian|256|pipeline|null: min -0.067, 45% negative"),
        dict(candidate="deepcopy (CalculatorFrame) loses NOISE_SEED and prop_k", outcome="confirmed", evidence="same JIDTBase.__deepcopy__: deepcopy reads NOISE_SEED NONE (infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copyprops); " + COPY_MI),
    ],
    checks_run=[
        dict(run_ids=["infotheory.tlmi.kraskov|*|kernel|ksg"], reference=f"{REF}:chk_ksg", outcome="pass 6/6; max_abs <= 5.3e-15"),
        dict(run_ids=["infotheory.tlmi.kraskov|gauss_ar1_pair|1024|pipeline|truth", "infotheory.tlmi.kraskov|delayed_noise-p01|1024|pipeline|truth"], reference=f"{REF}:chk_truth", outcome="pass 2/2; max z 0.50"),
        dict(run_ids=["infotheory.tlmi.kraskov|iid_gaussian|256|pipeline|null"], reference=f"{REF}:chk_null", outcome="pass; z -0.24"),
        dict(run_ids=["infotheory.tlmi.kraskov|{delayed_noise,var2_bivariate,gauss_ar1_pair}|1024|pipeline|direction"], reference=f"{REF}:chk_direction", outcome="pass 3/3"),
        dict(run_ids=["infotheory.tlmi.kraskov|bivariate_gaussian|1024|pipeline|threads", "infotheory.tlmi.kraskov|logistic_maps|256|pipeline|seeds"], reference=f"{REF}:chk_threads (same-lineage), chk_seeds", outcome="pass 2/2"),
    ],
)

R[TLD] = dict(
    check_method="independent-impl",
    check_reference=f"{EST} on (x_i[:-1], x_j[1:]) with W_ij from the unshifted series ({REF}:chk_ksg); {STAT}; {NULL}; {DIRN}",
    check_data="delayed_noise, var2_bivariate, gauss_ar1_pair, bivariate_gaussian, narrowband_f0-0.1 T1024; iid_gaussian T256; logistic_maps T256; delayed_noise rows 0-1 T1024 (truth)",
    agreement_criterion="tolerance rtol 1e-10 / atol 1e-12; statistical |pyspi - MC mean| <= 2 MC SD; direction and null qualitative",
    closeness="from-scratch: 7/7 ksg runs max_abs <= 6.2e-15 (W 1-339). Statistical: gauss_ar1_pair (W=5) 0.1433 / 0.2090 vs population 0.1266 / 0.1738 (MC 0.1388 / 0.1845, z 0.65); delayed_noise (0,1) 2.3274 (MC 2.3376, z 0.28). "
              "Null iid T=256: mean 0.0125 (MC 0.0122 +- 0.0081, z 0.04), min -0.052. Direction 3/3. Window effect: narrowband_f0-0.1 T=1024 (W=339) A 2.24 / 2.40 with min over pairs 1.84.",
    verdict="variant",
    score_0_10=7,
    what_changed="Lag-1 KSG1 MI with JIDT's Theiler exclusion, fp-exact; the window is pyspi's int(Bartlett + 1) all-lag rule (about T/3 on oscillatory input, see infotheory.theiler_window); "
                 "supplement 'undirected' vs directed output as for tlmi.kraskov. On gauss_ar1_pair the DCE estimator's expectation (MC 0.1388 / 0.1845) sits further above the population (0.1266 / 0.1738) than the non-DCE one (0.1309 / 0.1771).",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: pyspi <= 2.6 s at T=1024",
    symmetry_observed="asym: max|A - A.T| = 2.328 (delayed_noise), 0.194 (var2_bivariate), 0.066 (gauss_ar1_pair)",
    direction_observed="A[i,j] = I(x_i(t); x_j(t+1)) with W_ij: delayed_noise A[0,1] 2.327 vs A[1,0] -0.0003; var2_bivariate 0.166 vs -0.028; gauss_ar1_pair 0.143 vs 0.209 (population 0.127 vs 0.174)",
    candidate_resolutions=[
        dict(candidate="window over-estimates Bartlett by 1 and grows with T on oscillatory input", outcome="confirmed", evidence="infotheory.theiler_window|*|bartlett and |growth; infotheory.tlmi.kraskov_DCE|narrowband_f0-0.1|1024|kernel|ksg W=339"),
        dict(candidate="documentation: supplement 'undirected' vs code 'directed'", outcome="confirmed", evidence="infotheory.tlmi.kraskov_DCE|delayed_noise|1024|pipeline|direction: max|A - A.T| = 2.328"),
        dict(candidate="core-count dependence at 1e-14", outcome="confirmed", evidence="same MutualInfoCalculatorMultiVariateKraskov1 path as infotheory.tlmi.kraskov|bivariate_gaussian|1024|pipeline|threads (1.6e-14) and infotheory.mi.kraskov_DCE|bivariate_gaussian|1024|pipeline|threads (1.07e-14)"),
        dict(candidate="tied inputs: value set by jitter seed", outcome="confirmed", evidence="same jitter path as infotheory.tlmi.kraskov|logistic_maps|256|pipeline|seeds (spread 0.0051); tied logistic_maps DCE value reproduced only with the seeded port (infotheory.tlmi.kraskov_DCE|logistic_maps|256|kernel|ksg 4.4e-15)"),
        dict(candidate="negative values despite 'unsigned'", outcome="confirmed", evidence="infotheory.tlmi.kraskov_DCE|iid_gaussian|256|pipeline|null: min -0.052"),
        dict(candidate="deepcopy (CalculatorFrame) loses NOISE_SEED and prop_k", outcome="confirmed", evidence="same JIDTBase.__deepcopy__ (infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copyprops: NOISE_SEED NONE after deepcopy); " + COPY_MI),
    ],
    checks_run=[
        dict(run_ids=["infotheory.tlmi.kraskov_DCE|*|kernel|ksg"], reference=f"{REF}:chk_ksg", outcome="pass 7/7; max_abs <= 6.2e-15"),
        dict(run_ids=["infotheory.tlmi.kraskov_DCE|gauss_ar1_pair|1024|pipeline|truth", "infotheory.tlmi.kraskov_DCE|delayed_noise-p01|1024|pipeline|truth"], reference=f"{REF}:chk_truth", outcome="pass 2/2; max z 0.65"),
        dict(run_ids=["infotheory.tlmi.kraskov_DCE|iid_gaussian|256|pipeline|null"], reference=f"{REF}:chk_null", outcome="pass; z 0.04"),
        dict(run_ids=["infotheory.tlmi.kraskov_DCE|{delayed_noise,var2_bivariate,gauss_ar1_pair}|1024|pipeline|direction"], reference=f"{REF}:chk_direction", outcome="pass 3/3"),
    ],
)

# ------------------------------------------------------------------------------------------- TE fixed
TE_DIR1 = ("A[i,j] = TE(x_i -> x_j), row = source: delayed_noise A[0,1] 2.010 vs A[1,0] 0.023 (lag-3/5 pairs |A| <= 0.016 with l=1, u=1); var2_bivariate 0.164 vs 0.014; "
           "gauss_ar1_pair 0.044 vs 0.060 (population 0.027 vs 0.052, stronger 1->0); logistic_maps_chaotic (x -> y) 0.565 vs -0.074")
R[TE1] = dict(
    check_method="independent-impl",
    check_reference=f"{EST} on the JIDT TE layout (audit/checks/refs/_kernels_infotheory.py:te_embedding, k=kt=l=lt=1, u=1) ({REF}:chk_ksg, chk_seeds, chk_copy); {STAT} (Gaussian TE from the VAR autocovariances); {NULL}; {DIRN}; {REF}:chk_threads (same-lineage)",
    check_data="var2_bivariate, gauss_ar1_pair, delayed_noise, bivariate_gaussian, narrowband_f0-0.1 T1024; logistic_maps T256; gauss_ar1_pair T256/1024/4096 and var2_bivariate, delayed_noise rows 0-1 T1024 (truth); iid_gaussian T256; logistic_maps_chaotic T1024",
    agreement_criterion="tolerance rtol 1e-10 / atol 1e-12; statistical |pyspi - MC mean| <= 2 MC SD; direction and null qualitative",
    closeness="from-scratch KSG1 CMI: 6/6 ksg runs max_abs <= 3.1e-15. Convergence on gauss_ar1_pair to 0.0271 (0->1) / 0.0524 (1->0): pyspi -0.0021 / 0.0630 (T=256), 0.0444 / 0.0601 (T=1024), 0.0253 / 0.0511 (T=4096), z 0.91 / 0.97 / 0.21; "
              "var2_bivariate 0.1642 / 0.0143 vs 0.1326 / 0.0105 (MC 0.1340 / 0.0111, z 1.26); delayed_noise (0,1) 2.0097 vs 0.5 ln 101 = 2.3076 (MC 2.0505: KSG bias at large MI, z 1.75). "
              "Null iid T=256: mean -0.0070 (MC 0.0002 +- 0.0072, z -0.99), min -0.061. Direction 4/4. Copy paths on tie-free var2_bivariate: all four 8.9e-16.",
    verdict="matches",
    score_0_10=10,
    what_changed="None in value: Schreiber TE with k=l=1, delays 1, u=1, by KSG1 CMI, fp-exact; finite-history TE as the identifier states. Conventions: seeded 1e-8 jitter (decides tied data), negative finite-sample values.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: pyspi <= 2.6 s at T=1024, <= 0.7 s at T=4096 for one pair",
    symmetry_observed="asym: max|A - A.T| = 1.987 (delayed_noise T1024), 0.150 (var2_bivariate), 0.016 (gauss_ar1_pair)",
    direction_observed=TE_DIR1,
    candidate_resolutions=[
        dict(candidate="copies keep the k=l=1 embedding only by coincidence of JIDT defaults; deepcopy loses NOISE_SEED", outcome="confirmed",
             evidence="infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copy: all four paths 0.1336 (tie-free); |copyprops: deepcopy NOISE_SEED NONE, pickle 42; tied-data effect as in " + COPY_MI),
        dict(candidate="core-count dependence at 1e-14", outcome="confirmed", evidence="infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|bivariate_gaussian|1024|pipeline|threads: 2.4e-15, repeat 0.0"),
        dict(candidate="tied inputs: value set by jitter seed", outcome="confirmed", evidence="infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|logistic_maps|256|pipeline|seeds: 1->0 0.1151/0.1133/0.1073 (spread 0.0078), reproduced to 4.4e-16"),
        dict(candidate="negative values despite 'unsigned'", outcome="confirmed", evidence="infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|iid_gaussian|256|pipeline|null: min -0.061, 60% negative"),
        dict(candidate="BIAS_CORRECTION no-op", outcome="confirmed", evidence="infotheory.est.ksg1|iid_gaussian|64|kernel|props (TE calculator getProperty None)"),
    ],
    checks_run=[
        dict(run_ids=["infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|*|kernel|ksg"], reference=f"{REF}:chk_ksg", outcome="pass 6/6; max_abs <= 3.1e-15"),
        dict(run_ids=["infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|gauss_ar1_pair|{256,1024,4096}|pipeline|truth", "infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|var2_bivariate|1024|pipeline|truth",
                      "infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|delayed_noise-p01|1024|pipeline|truth"], reference=f"{REF}:chk_truth", outcome="pass 5/5; max z 1.75"),
        dict(run_ids=["infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|iid_gaussian|256|pipeline|null"], reference=f"{REF}:chk_null", outcome="pass; z -0.99"),
        dict(run_ids=["infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|*|1024|pipeline|direction"], reference=f"{REF}:chk_direction", outcome="pass 4/4"),
        dict(run_ids=["infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|bivariate_gaussian|1024|pipeline|threads", "infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|logistic_maps|256|pipeline|seeds",
                      "infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copy"], reference=f"{REF}:chk_threads (same-lineage), chk_seeds, chk_copy", outcome="pass 3/3"),
        dict(run_ids=["infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copyprops"], reference=f"{REF}:chk_copyprops (same-lineage)", outcome="fail (finding): deepcopy NOISE_SEED NONE; pickle keeps it"),
    ],
)

R[TED1] = dict(
    check_method="independent-impl",
    check_reference=f"{EST} on the JIDT TE layout with W_ij ({REF}:chk_ksg, chk_seeds); {STAT}; {NULL}; {DIRN}",
    check_data="var2_bivariate, gauss_ar1_pair, delayed_noise, bivariate_gaussian, narrowband_f0-0.1 T1024; logistic_maps T256; narrowband_f0-0.25 T64; cointegrated T1024 (pipeline, W 158-205); truth gauss_ar1_pair, var2_bivariate, delayed_noise rows 0-1 T1024; iid_gaussian T256; logistic_maps_chaotic T1024",
    agreement_criterion="tolerance rtol 1e-10 / atol 1e-12; statistical |pyspi - MC mean| <= 2 MC SD; direction and null qualitative",
    closeness="from-scratch: 8/8 ksg runs max_abs <= 2.9e-15 (W 2-339). Statistical: gauss_ar1_pair 0.0420 / 0.0630 vs 0.0271 / 0.0524 (MC 0.0288 / 0.0519, z 0.64); var2_bivariate 0.1635 / 0.0157 (MC 0.1372 / 0.0104, z 1.10); "
              "delayed_noise 2.0091 (MC 2.0531, z 1.83). Null iid T=256: mean -0.0076 (z -1.13), min -0.070. Direction 4/4. Window effect at T=1024 narrowband_f0-0.1 (W=339): A[1,0] 0.717 -> 0.675, A[0,1] 0.167 -> 0.175.",
    verdict="variant",
    score_0_10=7,
    what_changed="KSG1 TE (k=l=1) with JIDT's Theiler exclusion, fp-exact; the window is pyspi's int(Bartlett + 1) all-lag rule (about T/3 on oscillatory input; see infotheory.theiler_window). Matches the supplement's DCE variant, differs from canonical window choice in a value-changing way.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: pyspi <= 2.6 s at T=1024",
    symmetry_observed="asym: max|A - A.T| = 1.985 (delayed_noise), 0.148 (var2_bivariate), 0.021 (gauss_ar1_pair)",
    direction_observed="A[i,j] = TE(x_i -> x_j) with W_ij: delayed_noise 2.009 vs 0.024; var2_bivariate 0.163 vs 0.016; gauss_ar1_pair 0.042 vs 0.063 (population 0.027 vs 0.052); logistic_maps_chaotic 0.565 vs -0.074",
    candidate_resolutions=[
        dict(candidate="copies keep k=l=1 by coincidence; deepcopy loses NOISE_SEED", outcome="confirmed", evidence="same TransferEntropy/JIDTBase copy paths as infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copy (all paths equal on tie-free data) and |copyprops (deepcopy NOISE_SEED NONE)"),
        dict(candidate="oscillatory input: window about T/3 changes the estimate", outcome="confirmed", evidence="infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|narrowband_f0-0.1|1024|kernel|ksg vs infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|narrowband_f0-0.1|1024|kernel|ksg: A[1,0] 0.717 -> 0.675 (W=339); both reproduced exactly"),
        dict(candidate="core-count dependence at 1e-14", outcome="confirmed", evidence="same ConditionalMutualInfoCalculatorMultiVariateKraskov1 path as infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|bivariate_gaussian|1024|pipeline|threads (2.4e-15)"),
        dict(candidate="tied inputs: value set by jitter seed", outcome="confirmed", evidence="infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|logistic_maps|256|pipeline|seeds: 1->0 0.0783/0.0802/0.0749, reproduced to 8.9e-16"),
        dict(candidate="negative values despite 'unsigned'", outcome="confirmed", evidence="infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|iid_gaussian|256|pipeline|null: min -0.070, 65% negative"),
        dict(candidate="BIAS_CORRECTION no-op", outcome="confirmed", evidence="infotheory.est.ksg1|iid_gaussian|64|kernel|props"),
    ],
    checks_run=[
        dict(run_ids=["infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|*|ksg"], reference=f"{REF}:chk_ksg", outcome="pass 8/8; max_abs <= 2.9e-15"),
        dict(run_ids=["infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|{gauss_ar1_pair,var2_bivariate,delayed_noise-p01}|1024|pipeline|truth"], reference=f"{REF}:chk_truth", outcome="pass 3/3; max z 1.83"),
        dict(run_ids=["infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|iid_gaussian|256|pipeline|null"], reference=f"{REF}:chk_null", outcome="pass; z -1.13"),
        dict(run_ids=["infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|*|1024|pipeline|direction"], reference=f"{REF}:chk_direction", outcome="pass 4/4"),
        dict(run_ids=["infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|logistic_maps|256|pipeline|seeds"], reference=f"{REF}:chk_seeds", outcome="pass; 8.9e-16"),
    ],
)

R[TED2] = dict(
    check_method="independent-impl",
    check_reference=f"{EST} on the JIDT TE layout (k=2, kt=l=lt=1) with W_ij ({REF}:chk_ksg, chk_copy); {STAT} (Gaussian TE k=2, l=1); {NULL}; {DIRN}",
    check_data="var2_bivariate (kernel and pipeline), gauss_ar1_pair, delayed_noise, bivariate_gaussian, narrowband_f0-0.1 T1024; logistic_maps T256; truth gauss_ar1_pair T1024 and var2_bivariate T256/1024/4096; iid_gaussian T256; logistic_maps_chaotic T1024; var2_bivariate T256 (copy)",
    agreement_criterion="tolerance rtol 1e-10 / atol 1e-12; statistical |pyspi - MC mean| <= 2 MC SD; direction and null qualitative",
    closeness="from-scratch: 7/7 ksg runs max_abs <= 1.1e-15. Statistical: gauss_ar1_pair 0.0259 / 0.0505 vs population 0.0242 / 0.0502 (z 0.11); var2_bivariate 0->1 population 0.1241: pyspi 0.1592 (T=256, z 1.39), "
              "0.1600 (T=1024, MC 0.1203 +- 0.0196, z 2.02: FAIL of the 2-SD criterion on this single draw), 0.1351 (T=4096, z 0.94); the T=1024 draw is exact against the from-scratch estimator (2.2e-16) and also sits high for te_k1 (z 1.26), "
              "so it is a sampling excursion of the dataset draw, not an estimator discrepancy. Null iid T=256: mean 0.0018 (z 0.28), min -0.058. Direction 4/4. "
              "Copy paths var2_bivariate T=256 A[0,1]: Calculator 0.1592, CalculatorFrame / deepcopy / pickle 0.1344 (the k=1 DCE value).",
    verdict="variant",
    score_0_10=7,
    what_changed="KSG1 TE with k=2 target history and JIDT's Theiler exclusion, fp-exact; window from pyspi's int(Bartlett + 1) all-lag rule. config.yaml comment calls the entry 'auto-embedding on target-only' but the code uses a fixed k=2 (documentation slip). "
                 "Any copy of the SPI (CalculatorFrame, deepcopy, pickle) silently computes k=1 instead.",
    new_finding=True,
    definition_under_review=False,
    check_cost="cheap: pyspi <= 1.4 s at T=4096 for one pair",
    symmetry_observed="asym: max|A - A.T| = 1.562 (delayed_noise), 0.153 (var2_bivariate), 0.025 (gauss_ar1_pair)",
    direction_observed="A[i,j] = TE(x_i -> x_j): delayed_noise 1.539 vs -0.023; var2_bivariate 0.160 vs 0.007; gauss_ar1_pair 0.026 vs 0.050 (population 0.024 vs 0.050); logistic_maps_chaotic 0.411 vs -0.088",
    candidate_resolutions=[
        dict(candidate="copying (pickle, deepcopy/CalculatorFrame) silently changes the configuration", outcome="confirmed", evidence="infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copy: Calculator 0.1592 vs CalculatorFrame/deepcopy/pickle 0.1344; " + COPY_TE),
        dict(candidate="oscillatory input: window about T/3 changes the estimate", outcome="confirmed", evidence="infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|narrowband_f0-0.1|1024|kernel|ksg (W=339) reproduced exactly; window growth infotheory.theiler_window|narrowband_f0-0.1|*|growth"),
        dict(candidate="core-count dependence at 1e-14", outcome="confirmed", evidence="same CMI calculator path as infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|bivariate_gaussian|1024|pipeline|threads (2.4e-15)"),
        dict(candidate="tied inputs: value set by jitter seed", outcome="confirmed", evidence="same jitter path as infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|logistic_maps|256|pipeline|seeds (spread 0.0053); tied logistic_maps value reproduced only with the seeded port (infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|logistic_maps|256|kernel|ksg 4.4e-16)"),
        dict(candidate="negative values despite 'unsigned'", outcome="confirmed", evidence="infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|iid_gaussian|256|pipeline|null: min -0.058"),
        dict(candidate="BIAS_CORRECTION no-op", outcome="confirmed", evidence="infotheory.est.ksg1|iid_gaussian|64|kernel|props"),
    ],
    checks_run=[
        dict(run_ids=["infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|*|ksg"], reference=f"{REF}:chk_ksg", outcome="pass 7/7; max_abs <= 1.1e-15"),
        dict(run_ids=["infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|gauss_ar1_pair|1024|pipeline|truth", "infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|var2_bivariate|{256,4096}|pipeline|truth"], reference=f"{REF}:chk_truth", outcome="pass 3/3; max z 1.39"),
        dict(run_ids=["infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|var2_bivariate|1024|pipeline|truth"], reference=f"{REF}:chk_truth", outcome="fail (statistical, z 2.02 on one draw; exact against the from-scratch estimator; T=256 and T=4096 pass)"),
        dict(run_ids=["infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|iid_gaussian|256|pipeline|null"], reference=f"{REF}:chk_null", outcome="pass; z 0.28"),
        dict(run_ids=["infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|*|1024|pipeline|direction"], reference=f"{REF}:chk_direction", outcome="pass 4/4"),
        dict(run_ids=["infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copy"], reference=f"{REF}:chk_copy", outcome="fail (finding): copies 0.1344 vs configured 0.1592"),
    ],
)

# ------------------------------------------------------------------------------------------- TE auto
EMB_A = ("embeddings (k,kt,l,lt) read back per ordered pair and reproduced by the from-scratch MAX_CORR_AIS search (embedding_identical 1 on 5/5 runs): var2_bivariate 0->1 (3,3,1,1) at T=64, (10,1,1,1) at T=256; "
         "gauss_ar1_pair T=256 0->1 (5,1,2,3), 1->0 (2,3,5,1); narrowband_f0-0.1 T=256 0->1 (2,1,4,1); logistic_maps T=256 1->0 (1,1,7,2)")
R[TEA] = dict(
    check_method="independent-impl",
    check_reference=f"{EST}; {REF}:select_embedding (from-scratch MAX_CORR_AIS: k 1..10, tau 1..4, tau loop broken at k=1, strict maximum of KSG1 AIS, no bias correction) "
                    f"({REF}:chk_ksg, chk_embed with {PRB}:auto_embedding, chk_fixed with {PRB}:auto_fixed_repro, chk_seeds, chk_copy, chk_copyprops); {NULL}; {DIRN}; "
                    "selection criterion vs canonical: literature-only (Ragwitz & Kantz 2002, Phys. Rev. E 65, 056201, prediction-error criterion; Garland, James & Bradley 2016 for max-AIS)",
    check_data="var2_bivariate T64/T256, gauss_ar1_pair T256, logistic_maps T256, narrowband_f0-0.1 rows 0-1 T256, delayed_noise rows 0-2 T256, bivariate_gaussian rows 2-3 T256, iid_gaussian rows 0-2 T256, logistic_maps_chaotic T256 (budget: T <= 256, P <= 3)",
    agreement_criterion="tolerance rtol 1e-10 / atol 1e-12 on the TE values and the read-back (k, kt, l, lt); null and direction qualitative",
    closeness=f"from-scratch auto-embedding TE: 5/5 ksg runs max_abs <= 1.1e-15; {EMB_A}. Fixed-embedding pyspi TE with the chosen (k,kt,l,lt) equals the auto value exactly (fixed_minus_auto 0.0 on 4/4 runs). "
              "Null iid T=256 P=3: mean -0.0067 (MC 0.0001 +- 0.0098, z -0.69), min -0.057. Direction 4/4 (delayed_noise 1.616 vs -0.016; var2 0.061 vs -0.026; gauss_ar1 -0.003 vs 0.045; logistic_maps_chaotic 0.302 vs -0.032). "
              "threads 1.8e-15. Seeds (tied logistic_maps 1->0): 0.1014 / 0.0891 / 0.0442 with different source embeddings, each reproduced to 4.4e-16. Copy paths: Calculator 0.0606 vs CalculatorFrame/deepcopy/pickle 0.1336 (= te_k1).",
    verdict="variant",
    score_0_10=7,
    what_changed="Schreiber TE by KSG1 CMI with target and source embeddings chosen separately per ordered pair by maximum (uncorrected) KSG1 AIS, k <= 10, tau <= 4; fp-exact including the selection. "
                 "Documented as tau-max-2 (supplement, GitBook) while the identifier and code use 4. Max-AIS selection follows the supplement but differs from a canonical TE embedding criterion "
                 "(Ragwitz-Kantz prediction error or TE-optimal source embedding) and, comparing AIS across candidates with different N and no bias correction, drifts to large k (var2_bivariate target k=10 at T=256). "
                 "Every copy (CalculatorFrame, deepcopy, pickle) silently computes fixed k=1 TE.",
    new_finding=True,
    definition_under_review=False,
    check_cost="moderate: pyspi 1.5-23 s per run at T=256 with P <= 3 (64 cores under load); reference search <= 1 s",
    symmetry_observed="asym: max|A - A.T| = 1.633 (delayed_noise rows 0-2), 0.087 (var2_bivariate), 0.048 (gauss_ar1_pair), 0.115 (logistic_maps)",
    direction_observed="A[i,j] = TE(x_i -> x_j), row = source: delayed_noise A[0,1] 1.616 vs A[1,0] -0.016; var2_bivariate 0.061 vs -0.026; gauss_ar1_pair -0.003 vs 0.045 (stronger 1->0 coupling); logistic_maps_chaotic (x -> y) 0.302 vs -0.032",
    candidate_resolutions=[
        dict(candidate="copying silently changes the configuration (pickle drops AUTO_EMBED_METHOD; deepcopy also drops NOISE_SEED and prop_k)", outcome="confirmed", evidence=COPY_TE),
        dict(candidate="embedding selected per ordered pair, varies with pair and T", outcome="confirmed", evidence=EMB_A + " (*|embed)"),
        dict(candidate="documentation: tau-max-2 documented, 4 implemented", outcome="confirmed", evidence="config.yaml:556 / identifier tau-max-4; searches pick tau up to 3 here (gauss_ar1_pair l_tau 3, k_tau 3) and 4 in the DCE unit (narrowband (10,4,10,4)), so tau > 2 is actually used (*|embed)"),
        dict(candidate="efficiency: per-channel embedding recomputed for every pair although partner-independent without DCE", outcome="confirmed",
             evidence="*|embed: without DCE a channel gets the same embedding as target and as source (var2_bivariate T=256: channel 1 (10,1) as target of 0->1 and as source of 1->0, channel 0 (1,1) in both roles; gauss_ar1_pair channel 0 (2,3), channel 1 (5,1)), matching the from-scratch per-series cache; JIDT still reruns the 37-candidate search for every ordered pair"),
        dict(candidate="core-count dependence at 1e-14", outcome="confirmed", evidence="infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|bivariate_gaussian-p23|256|pipeline|threads: 1.8e-15, repeat 0.0"),
        dict(candidate="tied inputs: value set by jitter seed", outcome="confirmed", evidence="infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|logistic_maps|256|pipeline|seeds: 0.1014/0.0891/0.0442 (spread 0.057), reproduced to 4.4e-16"),
        dict(candidate="negative values despite 'unsigned'", outcome="confirmed", evidence="infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|iid_gaussian-p012|256|pipeline|null: min -0.057, 50% negative"),
        dict(candidate="BIAS_CORRECTION no-op", outcome="confirmed", evidence="infotheory.est.ksg1|iid_gaussian|64|kernel|props"),
    ],
    checks_run=[
        dict(run_ids=["infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|*|ksg"], reference=f"{REF}:chk_ksg", outcome="pass 5/5; max_abs <= 1.1e-15"),
        dict(run_ids=["infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|*|embed"], reference=f"{REF}:chk_embed", outcome="pass 5/5; embeddings identical"),
        dict(run_ids=["infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|*|fixed"], reference=f"{REF}:chk_fixed", outcome="pass 4/4; fixed - auto = 0.0"),
        dict(run_ids=["infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|iid_gaussian-p012|256|pipeline|null"], reference=f"{REF}:chk_null", outcome="pass; z -0.69"),
        dict(run_ids=["infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|*|256|pipeline|direction"], reference=f"{REF}:chk_direction", outcome="pass 4/4"),
        dict(run_ids=["infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|bivariate_gaussian-p23|256|pipeline|threads", "infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|logistic_maps|256|pipeline|seeds"],
             reference=f"{REF}:chk_threads (same-lineage), chk_seeds", outcome="pass 2/2"),
        dict(run_ids=["infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|var2_bivariate|256|pipeline|copy", "infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|var2_bivariate|256|pipeline|copyprops"],
             reference=f"{REF}:chk_copy, chk_copyprops (same-lineage)", outcome="fail 2/2 (finding): copies give 0.1336 (k=1) vs 0.0606; AUTO_EMBED_METHOD lost by pickle and deepcopy, NOISE_SEED by deepcopy"),
    ],
)

EMB_D = ("with the pair window: gauss_ar1_pair T=256 (W=4) 0->1 (2,2,1,1), 1->0 (1,1,2,2) vs (5,1,2,3) / (2,3,5,1) without DCE; narrowband_f0-0.1 rows 0-1 T=256 (W=85) (10,4,10,4) both ways vs (2,1,4,1) / (4,1,2,1); "
         "logistic_maps T=256 (W=39) 1->0 (1,1,9,4) vs (1,1,7,2); var2_bivariate (W=3) unchanged (10,1,1,1)")
R[TEAD] = dict(
    check_method="independent-impl",
    check_reference=f"{EST}; {REF}:select_embedding with the pair window W_ij passed to every AIS candidate and the guard N <= 4 + 2W ({REF}:chk_ksg, chk_embed, chk_fixed); {NULL}; {DIRN}; "
                    "selection criterion vs canonical: literature-only (Ragwitz & Kantz 2002; Garland, James & Bradley 2016)",
    check_data="var2_bivariate T64/T256, gauss_ar1_pair T256, logistic_maps T64/T256, narrowband_f0-0.1 T64 (P=3) and rows 0-1 T256, shared_envelope T64, delayed_noise rows 0-2 T256, bivariate_gaussian rows 2-3 T256, iid_gaussian rows 0-2 T256, logistic_maps_chaotic T256",
    agreement_criterion="tolerance rtol 1e-10 / atol 1e-12 on values, NaN pattern and read-back embeddings; null and direction qualitative",
    closeness=f"from-scratch: 8/8 ksg runs pass, finite entries max_abs <= 2.2e-15 and NaN masks identical: T=64 narrowband_f0-0.1 6/6 NaN (W=22), logistic_maps 2/2 (W=14), shared_envelope 6/12 (W 9-22; NaN exactly where T-37 <= 4+2W); "
              f"embeddings identical on 5/5 *|embed runs, {EMB_D}; fixed-embedding pyspi TE with the chosen embedding equals the auto value (0.0 on 4/4). Null iid T=256 P=3: mean 0.0030 (z 0.45), min -0.031. Direction 4/4.",
    verdict="variant",
    score_0_10=6,
    what_changed="As the non-DCE auto-embedding unit, plus: pyspi's all-lag window (int(Bartlett + 1), about T/3 on oscillatory input) is forwarded to the AIS calculator, so the embedding of a channel depends on its partner "
                 "(narrowband jumps to (10,4,10,4)), and any AIS candidate with N <= 4 + 2W aborts the search, giving NaN for short or oscillatory series (all pairs of narrowband and logistic_maps at T=64). "
                 "Deviates from both the supplement (window documented as an estimator bias fix, not as an input to embedding selection; tau-max-2) and canonical practice in an interpretable way.",
    new_finding=True,
    definition_under_review=False,
    check_cost="moderate: pyspi 1.5-33 s per run at T <= 256 with P <= 4 (64 cores under load)",
    symmetry_observed="asym: max|A - A.T| = 1.634 (delayed_noise rows 0-2), 0.083 (var2_bivariate), 0.034 (gauss_ar1_pair); NaN pattern symmetric (W_ij = W_ji)",
    direction_observed="A[i,j] = TE(x_i -> x_j): delayed_noise 1.616 vs -0.018; var2_bivariate 0.057 vs -0.026; gauss_ar1_pair 0.028 vs 0.062 (stronger 1->0); logistic_maps_chaotic 0.300 vs -0.036",
    candidate_resolutions=[
        dict(candidate="copying silently changes the configuration", outcome="confirmed", evidence="same TransferEntropy copy paths as the non-DCE unit: " + COPY_TE),
        dict(candidate="NaN for short/oscillatory series (AIS candidate k=10, tau=4 with N = T-37 <= 4+2W aborts the search)", outcome="confirmed",
             evidence="infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4|{narrowband_f0-0.1,logistic_maps,shared_envelope}|64|kernel|ksg: 6/6, 2/2, 6/12 NaN, mask reproduced by the guard"),
        dict(candidate="Theiler window forwarded to the AIS embedding search (embedding depends on partner)", outcome="confirmed", evidence=EMB_D + " (*|embed, both units)"),
        dict(candidate="documentation: tau-max-2 documented, 4 implemented", outcome="confirmed", evidence="identifier tau-max-4; selected k_tau = l_tau = 4 on narrowband_f0-0.1 (infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4|narrowband_f0-0.1-p01|256|pipeline|embed) and logistic_maps (9,4)"),
        dict(candidate="core-count dependence at 1e-14", outcome="confirmed", evidence="same CMI/AIS calculators as infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|bivariate_gaussian-p23|256|pipeline|threads (1.8e-15)"),
        dict(candidate="tied inputs: value set by jitter seed", outcome="confirmed", evidence="same jitter path as infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4|logistic_maps|256|pipeline|seeds (spread 0.057); tied logistic_maps DCE value and embedding (1,1,9,4) reproduced only with the seeded port (2.2e-16)"),
        dict(candidate="negative values despite 'unsigned'", outcome="confirmed", evidence="infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4|iid_gaussian-p012|256|pipeline|null: min -0.031; shared_envelope T=64 finite entries down to -0.035"),
        dict(candidate="BIAS_CORRECTION no-op", outcome="confirmed", evidence="infotheory.est.ksg1|iid_gaussian|64|kernel|props"),
    ],
    checks_run=[
        dict(run_ids=["infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4|*|ksg"], reference=f"{REF}:chk_ksg", outcome="pass 8/8; max_abs <= 2.2e-15, NaN masks equal"),
        dict(run_ids=["infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4|*|embed"], reference=f"{REF}:chk_embed", outcome="pass 5/5; embeddings identical"),
        dict(run_ids=["infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4|*|fixed"], reference=f"{REF}:chk_fixed", outcome="pass 4/4; fixed - auto = 0.0"),
        dict(run_ids=["infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4|iid_gaussian-p012|256|pipeline|null"], reference=f"{REF}:chk_null", outcome="pass; z 0.45"),
        dict(run_ids=["infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4|*|256|pipeline|direction"], reference=f"{REF}:chk_direction", outcome="pass 4/4"),
    ],
)


def main():
    for unit, block in R.items():
        p = REC / f"{unit}.yaml"
        txt = p.read_text()
        assert txt.startswith(f"unit_id: {unit}\nstatus: "), unit
        txt = txt.replace("\nstatus: traced\n", "\nstatus: checked\n", 1)
        if "\n  check_method:" in txt:
            txt = txt[:txt.index("\n  check_method:") + 1]
        if unit == KSG:
            old = ("    reference: self-consistency under NUM_THREADS = 1 and NOISE_SEED in {42, 43, 44} (no external reference)\n"
                   "    reference_kind: analytic\n")
            new = ("    reference: self-consistency under NUM_THREADS = 1 and NOISE_SEED in {42, 43, 44} (no external reference)\n"
                   "    reference_kind: same-lineage\n")
            if old in txt:
                txt = txt.replace(old, new)
        dumped = yaml.safe_dump(block, sort_keys=False, allow_unicode=True, width=200, default_flow_style=False)
        dumped = "".join("  " + ln + "\n" for ln in dumped.rstrip("\n").split("\n"))
        if not txt.endswith("\n"):
            txt += "\n"
        p.write_text(txt + dumped)
        d = yaml.safe_load(p.read_text())
        assert d["correctness"]["verdict"] == block["verdict"]
        assert len(d["correctness"]["candidate_resolutions"]) == len(d["correctness"]["new_finding_candidates"]), unit
    print("ok", len(R))


main()
