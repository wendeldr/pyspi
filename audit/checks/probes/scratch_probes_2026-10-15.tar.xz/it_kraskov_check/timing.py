import sys, time, numpy as np, yaml
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks')
from regression import harness
import make_data
harness.ensure_jvm(); harness.import_statistics_modules()
doc = yaml.safe_load(open('/media/dan/Data/git/pyspi/audit/units.yaml'))
by = {}
for u in doc['units']:
    for i in u['identifiers']:
        by[i] = dict(identifier=i, module=f".statistics.{u['module']}", cls=u['pyspi_class'], params=u['identifier_params'][i], labels=u['labels'], deps=u['deps'])
from pyspi.data import Data
for ident, ds, T, procs in [(a, b, int(c), None if d=='-' else [int(q) for q in d.split(',')]) for a,b,c,d in (s.split(':') for s in sys.argv[1:])]:
    x = make_data.load(ds, T)['x']
    if procs: x = x[procs]
    data = Data(np.array(x, float), dim_order='ps')
    spi = harness.build_spi(by[ident])
    t0 = time.perf_counter(); S = harness.compute_spi(spi, data); dt = time.perf_counter()-t0
    print(ident, ds, T, x.shape, f'{dt:.2f}s', np.round(S, 4).tolist())
