import sys; sys.path.insert(0,'/media/dan/Data/git/pyspi/tests'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
from regression import harness; harness.ensure_jvm()
import jpype as jp, numpy as np
import importlib.util
spec=importlib.util.spec_from_file_location('ref','/media/dan/Data/git/pyspi/audit/checks/refs/it_kraskov.py'); ref=importlib.util.module_from_spec(spec); spec.loader.exec_module(ref)
for seed in (42,43,7):
    r=jp.java.util.Random(seed); m=ref.JavaRandom(seed)
    a=np.array([r.nextGaussian() for _ in range(20001)]); b=np.array([m.next_gaussian() for _ in range(20001)])
    print(seed, np.max(np.abs(a-b)))
