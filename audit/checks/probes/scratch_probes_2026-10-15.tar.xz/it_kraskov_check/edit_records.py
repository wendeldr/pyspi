"""Apply the post-review edits to the it_kraskov records (values read from the forced re-run)."""
import json
from pathlib import Path

import numpy as np
import yaml

AUD = Path("/media/dan/Data/git/pyspi/audit")
RES = json.loads((AUD / "checks/out/results/it_kraskov.json").read_text())
PYS = AUD / "checks/out/pyspi"


def r(rid):
    return RES[rid]


def pv(rid):
    with np.load(PYS / f"{rid}.npz") as z:
        return np.asarray(z["value"], dtype=float)


def f4(x):
    return f"{x:.4f}"


def e1(x):
    return f"{x:.1e}"


# ---------------------------------------------------------------- run-dependent numbers
MCOPY = "infotheory.mi.kraskov|logistic_maps|256|pipeline|copy"
mc = pv(MCOPY)
FRAME, DEEP, CALC, PICK = mc[1, 0, 1], mc[2, 0, 1], mc[0, 0, 1], mc[3, 0, 1]
FvC = r(MCOPY)["ref_frame_vs_calculator"]
DvR = r(MCOPY)["ref_deepcopy_vs_ref"]
K6 = "infotheory.mi.kraskov|bivariate_gaussian-p23|256|pipeline|copyk6"
K6P = "infotheory.mi.kraskov|bivariate_gaussian-p23|256|pipeline|copypropsk6"
k6 = r(K6)
assert abs(k6["ref_pyspi_frame_01"] - k6["ref_ref_k4_01"]) < 1e-12
DA = "infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4"
DAC = f"{DA}|var2_bivariate|256|pipeline|copy"
dac = pv(DAC)
TE1_01 = pv("infotheory.te.kraskov_k-1_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copy")[0, 0, 1]
TE1D_01 = pv("infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copy")[1, 0, 1]

TIED_OLD = "CalculatorFrame 0.2248 (unseeded jitter after deepcopy)"
TIED_NEW = (f"CalculatorFrame a non-reproducible draw, because deepcopy leaves the jitter unseeded (here {f4(FRAME)}; "
            f"an earlier run of the same check gave 0.2248)")
FVC_OLD = "frame_vs_calculator 0.0053"
FVC_NEW = f"frame_vs_calculator {e1(FvC)} in this run"
PROPK = (f"; prop_k loss shown at the check stage on MutualInfo(kraskov, prop_k=6) = mi_kraskov_NN-6 (bivariate_gaussian rows 2-3 "
         f"T=256, tie-free): Calculator and pickle equal the k=6 reference {f4(k6['ref_ref_k6_01'])} (<= {e1(max(k6['ref_calculator_vs_k6'], k6['ref_pickle_vs_k6']))}), "
         f"CalculatorFrame and deepcopy give {f4(k6['ref_pyspi_frame_01'])}, the k=4 value ({e1(k6['ref_frame_vs_k4'])} from the k=4 reference); "
         f"read-back k: original 6, deepcopy 4, pickle 6 (infotheory.mi.kraskov|bivariate_gaussian-p23|256|pipeline|copyk6, |copypropsk6)")


def fix_copy_evidence(c, add_propk):
    for cr in c["candidate_resolutions"]:
        ev = cr["evidence"]
        if TIED_OLD in ev or FVC_OLD in ev:
            ev = ev.replace(TIED_OLD, TIED_NEW).replace(FVC_OLD, FVC_NEW)
            if add_propk and "prop_k" in cr["candidate"]:
                ev = ev + PROPK
            cr["evidence"] = ev


SCORE6 = ("Scored 6 (deviates from both the supplement and canonical in an interpretable way), consistent with infotheory.theiler_window: "
          "the value is set by the window rule, which is not the documented autocorrelation-time heuristic (Bartlett + 1 over all lags, "
          "about T/3 on oscillatory input, with a non-vanishing upward bias on cross-correlated pairs).")


def load(u):
    p = AUD / "records" / f"{u}.yaml"
    return p, yaml.safe_load(p.read_text())


def save(p, d):
    p.write_text(yaml.safe_dump(d, sort_keys=False, allow_unicode=True, width=200))


changed = []

# ---------------------------------------------------------------- theiler_window
p, d = load("infotheory.theiler_window")
c = d["correctness"]
pops = {(ds, T): r(f"infotheory.theiler_window|{ds}|{T}|pipeline|pop") for ds in ("gauss_ar1_pair", "var2_bivariate") for T in (256, 1024, 4096)}
ex = {k: v["ref_mc_excess_over_tau_plus_1"] for k, v in pops.items()}
lim = {ds: pops[(ds, 1024)]["ref_large_T_limit_tau_plus_1_plus_C"] for ds in ("gauss_ar1_pair", "var2_bivariate")}
C = {ds: pops[(ds, 1024)]["ref_cross_sq_C"] for ds in ("gauss_ar1_pair", "var2_bivariate")}
v256 = pops[("var2_bivariate", 256)]
assert not v256["pass"]
old = c["closeness"]
i0 = old.index("beyond the +1")
i1 = old.index("Growth:")
c["closeness"] = (old[:i0] + (
    "beyond the +1, the all-lag sum of sample-ACF products adds an upward bias on cross-correlated pairs that does not vanish as T grows. "
    f"MC excess over tau+1 at T = 256 / 1024 / 4096: gauss_ar1_pair {ex[('gauss_ar1_pair', 256)]:.2f} / {ex[('gauss_ar1_pair', 1024)]:.2f} / {ex[('gauss_ar1_pair', 4096)]:.2f}, "
    f"var2_bivariate {ex[('var2_bivariate', 256)]:.2f} / {ex[('var2_bivariate', 1024)]:.2f} / {ex[('var2_bivariate', 4096)]:.2f}; iid 0.001 (independent channels). "
    f"The large-T limit tau + 1 + C with C = sum_m rho_01(m)^2 (Bartlett covariance of lagged products) is {lim['gauss_ar1_pair']:.3f} (C {C['gauss_ar1_pair']:.3f}) and "
    f"{lim['var2_bivariate']:.3f} (C {C['var2_bivariate']:.3f}), against MC means {pops[('gauss_ar1_pair', 4096)]['ref_mc_mean_01']:.3f} and {pops[('var2_bivariate', 4096)]['ref_mc_mean_01']:.3f} at T=4096. "
    f"pyspi raw vs MC at T=256 / 4096: gauss_ar1_pair {pops[('gauss_ar1_pair', 256)]['ref_raw_pyspi_01']:.3f} / {pops[('gauss_ar1_pair', 4096)]['ref_raw_pyspi_01']:.3f} "
    f"(z {pops[('gauss_ar1_pair', 256)]['ref_z_max']:.2f} / {pops[('gauss_ar1_pair', 4096)]['ref_z_max']:.2f}); var2_bivariate T=4096 {pops[('var2_bivariate', 4096)]['ref_raw_pyspi_01']:.3f} "
    f"(z {pops[('var2_bivariate', 4096)]['ref_z_max']:.2f}); var2_bivariate T=256 {v256['ref_raw_pyspi_01']:.3f} vs MC {v256['ref_mc_mean_01']:.3f} +- {v256['ref_mc_sd_01']:.3f} "
    f"(z {v256['ref_z_max']:.2f}: FAIL of the 2-SD criterion on this single dataset draw; the draw is exact against the lag loop, and a 2000-draw probe "
    "gives P(rule >= 3.421) = 0.0055 under the generating model, right skew 0.71, scratchpad it_kraskov_check/theiler_tail.py). ") + old[i1:])
c["what_changed"] = c["what_changed"].replace(
    "so it carries a positive finite-sample bias on correlated pairs and grows linearly",
    "so on cross-correlated pairs it carries an upward bias that does not vanish as T grows (its expectation tends to tau + 1 + sum_m rho_ij(m)^2, "
    "not tau + 1: an inconsistent estimator of Bartlett's factor; +1.54 on gauss_ar1_pair and +0.40 on var2_bivariate at T=4096), and it grows linearly")
assert "inconsistent estimator" in c["what_changed"]
c["check_data"] += "; gauss_ar1_pair and var2_bivariate also at T256 and T4096 (population runs)"
c["check_reference"] = c["check_reference"].replace(
    "audit/checks/refs/it_kraskov.py:chk_pop (population Bartlett tau from VAR autocovariances, Monte Carlo of the rule)",
    "audit/checks/refs/it_kraskov.py:chk_pop (population Bartlett tau from VAR autocovariances, Monte Carlo of the rule, large-T limit tau + 1 + C from audit/checks/refs/it_kraskov.py:pop_cross_sq)")
assert "pop_cross_sq" in c["check_reference"]
for cr in c["checks_run"]:
    if cr["reference"].endswith("chk_pop"):
        cr["run_ids"] = ["infotheory.theiler_window|iid_gaussian-p01|1024|pipeline|pop",
                         "infotheory.theiler_window|gauss_ar1_pair|{256,1024,4096}|pipeline|pop",
                         "infotheory.theiler_window|var2_bivariate|{256,1024,4096}|pipeline|pop"]
        cr["outcome"] = (f"pass 6/7, fail 1/7 (var2_bivariate T=256, z {v256['ref_z_max']:.2f}, a tail draw of the dataset, P = 0.0055); "
                         f"MC excess over tau+1 constant in T (gauss_ar1_pair {ex[('gauss_ar1_pair', 256)]:.2f} / {ex[('gauss_ar1_pair', 1024)]:.2f} / {ex[('gauss_ar1_pair', 4096)]:.2f}) "
                         f"and close to C = {C['gauss_ar1_pair']:.3f}")
c["agreement_criterion"] = c["agreement_criterion"].replace(
    "population statistical (|pyspi - MC mean| <= 2 MC SD)",
    "population statistical (|pyspi - MC mean| <= 2 MC SD; reference_kind independent-impl, the population tau + 1 is analytic and quoted)")
save(p, d); changed.append("infotheory.theiler_window")

# ---------------------------------------------------------------- mi.kraskov
p, d = load("infotheory.mi.kraskov")
c = d["correctness"]
fix_copy_evidence(c, True)
c["check_reference"] = c["check_reference"].replace(
    "audit/checks/refs/it_kraskov.py:chk_truth (analytic population value + Monte",
    "audit/checks/refs/it_kraskov.py:chk_truth and chk_null (reference_kind independent-impl: the criterion uses the Monte Carlo of the from-scratch estimator; the population value is analytic and quoted) (analytic population value + Monte")
c["check_reference"] = c["check_reference"].rstrip("'") + "; audit/checks/refs/it_kraskov.py:chk_copyk6 and chk_copyprops on MutualInfo(kraskov, prop_k=6) built by audit/checks/probes/it_kraskov_probes.py:copy_paths_mi_k6 / copy_props_mi_k6"
c["check_data"] += "; bivariate_gaussian rows 2-3 T256 (NN-6 copy paths)"
c["closeness"] += (f" Copy paths (tied logistic_maps T=256 A[0,1]): Calculator {f4(CALC)} and pickle {f4(PICK)} within 8.9e-16 of the reference; "
                   f"CalculatorFrame and deepcopy run with unseeded jitter, so their values are non-reproducible draws (here {f4(FRAME)} and {f4(DEEP)}, "
                   f"{e1(FvC)} and {e1(DvR)} from the reference). NN-6 copies: Calculator/pickle {f4(k6['ref_ref_k6_01'])} (k=6), CalculatorFrame/deepcopy {f4(k6['ref_pyspi_frame_01'])} (= k=4 value).")
for cr in c["checks_run"]:
    if cr["run_ids"] == [MCOPY]:
        cr["outcome"] = (f"fail (finding): CalculatorFrame and deepcopy are unseeded draws (here {f4(FRAME)} / {f4(DEEP)} vs {f4(CALC)}); Calculator and pickle exact")
c["checks_run"].append({"run_ids": [K6, K6P],
                        "reference": "audit/checks/refs/it_kraskov.py:chk_copyk6, chk_copypropsk6 (= chk_copyprops, same-lineage)",
                        "outcome": (f"fail 2/2 (finding): CalculatorFrame and deepcopy compute k=4 ({f4(k6['ref_pyspi_frame_01'])}) instead of k=6 "
                                    f"({f4(k6['ref_ref_k6_01'])}); read-back k 6 / 4 / 6 for original / deepcopy / pickle")})
c["check_cost"] += "; NN-6 copy probe 1-2 s"
save(p, d); changed.append("infotheory.mi.kraskov")

# ---------------------------------------------------------------- mi_DCE, tlmi, tlmi_DCE, te_k1 copy wording
for u in ("infotheory.mi.kraskov_DCE", "infotheory.tlmi.kraskov", "infotheory.tlmi.kraskov_DCE", "infotheory.te.kraskov_k-1_kt-1_l-1_lt-1"):
    p, d = load(u)
    fix_copy_evidence(d["correctness"], u != "infotheory.te.kraskov_k-1_kt-1_l-1_lt-1")
    save(p, d)

# ---------------------------------------------------------------- DCE consumers: 7 -> 6
for u in ("infotheory.mi.kraskov_DCE", "infotheory.tlmi.kraskov_DCE", "infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1", "infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1"):
    p, d = load(u)
    c = d["correctness"]
    assert c["score_0_10"] == 7, u
    c["score_0_10"] = 6
    w = c["what_changed"]
    for s in (" Matches the supplement's DCE description in kind; differs from canonical practice (W of the order of the autocorrelation time) in a value-changing way.",
              " Matches the supplement's DCE variant, differs from canonical window choice in a value-changing way."):
        w = w.replace(s, "")
    c["what_changed"] = w.rstrip() + " " + SCORE6
    save(p, d)
    if u not in changed:
        changed.append(u)

# ---------------------------------------------------------------- tlmi units: direction (chaotic), reversal, guard
for u, ident in (("infotheory.tlmi.kraskov", "tlmi"), ("infotheory.tlmi.kraskov_DCE", "tlmi_DCE")):
    p, d = load(u)
    c = d["correctness"]
    dirr = r(f"{u}|logistic_maps_chaotic|1024|pipeline|direction")
    rev = {ds: r(f"{u}|{ds}|{T}|pipeline|reversal") for ds, T in (("delayed_noise", 1024), ("iid_gaussian", 256), ("logistic_maps", 256))}
    c["check_data"] += "; logistic_maps_chaotic T1024 (direction); delayed_noise T1024, iid_gaussian T256, logistic_maps T256 (time reversal)"
    c["closeness"] += (f" Direction on logistic_maps_chaotic (x -> y): A[0,1] {dirr['ref_A01']:.3f} vs A[1,0] {dirr['ref_A10']:.3f}. "
                       f"Time reversal: pyspi on the reversed series transposed equals pyspi on the original to {e1(rev['delayed_noise']['ref_rev_T_minus_orig_pyspi'])} (delayed_noise) "
                       f"and {e1(rev['iid_gaussian']['ref_rev_T_minus_orig_pyspi'])} (iid_gaussian), but only to {rev['logistic_maps']['ref_rev_T_minus_orig_pyspi']:.4f} on tied logistic_maps, "
                       f"where the jitter follows the sample order (the from-scratch reference reproduces both layers, max_abs <= "
                       f"{e1(max(v['max_abs'] for v in rev.values()))}; without jitter the reversal is exact, {e1(rev['logistic_maps']['ref_rev_T_minus_orig_ref_nojitter'])}).")
    c["direction_observed"] += f"; logistic_maps_chaotic (x -> y) {dirr['ref_A01']:.3f} vs {dirr['ref_A10']:.3f}"
    c["checks_run"].append({"run_ids": [f"{u}|logistic_maps_chaotic|1024|pipeline|direction"],
                            "reference": "audit/checks/refs/it_kraskov.py:chk_direction",
                            "outcome": f"pass; A[0,1] {dirr['ref_A01']:.3f} > A[1,0] {dirr['ref_A10']:.3f}"})
    c["checks_run"].append({"run_ids": [f"{u}|{{delayed_noise|1024,iid_gaussian|256,logistic_maps|256}}|pipeline|reversal"],
                            "reference": "audit/checks/refs/it_kraskov.py:chk_reversal (probe time_reversed)",
                            "outcome": (f"pass 3/3 (max_abs <= {e1(max(v['max_abs'] for v in rev.values()))}); A(reversed).T - A: "
                                        f"{e1(rev['delayed_noise']['ref_rev_T_minus_orig_pyspi'])} / {e1(rev['iid_gaussian']['ref_rev_T_minus_orig_pyspi'])} / "
                                        f"{rev['logistic_maps']['ref_rev_T_minus_orig_pyspi']:.4f} (tied)")})
    sub = ("Direction proposal: logistic_maps (the tied period-4 fixture) replaced by logistic_maps_chaotic (x -> y only), as audit/checks/data/CONVENTIONS.md asks; "
           "the tied fixture is used for the time-reversal check instead.")
    c["check_cost"] = c["check_cost"] + ". " + sub
    if ident == "tlmi_DCE":
        ks = {ds: r(f"{u}|{ds}|64|pipeline|ksg") for ds in ("narrowband_f0-0.1", "narrowband_f0-0.25", "logistic_maps", "shared_envelope")}
        g = r(f"{u}|narrowband_f0-0.1|64|pipeline|guard")
        c["check_data"] += "; narrowband_f0-0.1, narrowband_f0-0.25, logistic_maps, shared_envelope T64 (guard)"
        c["closeness"] += (f" Guard: at T=64 (N = 63) the rule gives W_max {max(v['ref_W_max'] for v in ks.values())}, so N - (4 + 2W) >= "
                           f"{min(v['ref_guard_margin_min'] for v in ks.values())} on all four datasets and no pair is NaN (4/4 ksg runs, max_abs <= "
                           f"{e1(max(v['max_abs'] for v in ks.values()))}); with a numeric window the guard trips exactly at W = {g['ref_W_trips']} "
                           f"({g['ref_nan_pyspi_layer1']}/6 NaN, W = {g['ref_W_computes']} computes, both layers reproduced to {e1(g['max_abs'])}).")
        c["checks_run"].append({"run_ids": [f"{u}|{{narrowband_f0-0.1,narrowband_f0-0.25,logistic_maps,shared_envelope}}|64|pipeline|ksg"],
                                "reference": "audit/checks/refs/it_kraskov.py:chk_ksg (guard_margin_min)",
                                "outcome": f"pass 4/4; no NaN, guard margin >= {min(v['ref_guard_margin_min'] for v in ks.values())}"})
        c["checks_run"].append({"run_ids": [f"{u}|narrowband_f0-0.1|64|pipeline|guard"],
                                "reference": "audit/checks/refs/it_kraskov.py:chk_guard (probe guard_numeric)",
                                "outcome": f"pass; W={g['ref_W_computes']} computes, W={g['ref_W_trips']} gives NaN on all 6 ordered pairs, as N <= 4 + 2W predicts"})
    save(p, d)
    if u not in changed:
        changed.append(u)

# ---------------------------------------------------------------- te_DCE_k1: guard
u = "infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1"
p, d = load(u)
c = d["correctness"]
ks = {ds: r(f"{u}|{ds}|64|pipeline|ksg") for ds in ("narrowband_f0-0.1", "logistic_maps", "shared_envelope")}
ks["narrowband_f0-0.25"] = r(f"{u}|narrowband_f0-0.25|64|kernel|ksg")
g = r(f"{u}|narrowband_f0-0.1|64|pipeline|guard")
c["check_data"] += "; narrowband_f0-0.1, logistic_maps, shared_envelope T64 (pipeline, guard) and a numeric-window guard run"
c["closeness"] += (f" Guard: at T=64 (N = 63) the rule gives W_max {max(v.get('ref_W_max', 0) for v in ks.values())} on narrowband_f0-0.1/0.25, logistic_maps and shared_envelope, "
                   f"guard margin N - (4 + 2W) >= {min(v['ref_guard_margin_min'] for v in ks.values() if 'ref_guard_margin_min' in v)}, no NaN; "
                   f"with a numeric window the guard trips exactly at W = {g['ref_W_trips']} ({g['ref_nan_pyspi_layer1']}/6 NaN; W = {g['ref_W_computes']} computes; "
                   f"both layers reproduced to {e1(g['max_abs'])}).")
for cr in c["checks_run"]:
    if cr["run_ids"] == ["infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|*|ksg"]:
        n = sum(1 for k in RES if k.startswith(u + "|") and k.endswith("|ksg"))
        npass = sum(1 for k, v in RES.items() if k.startswith(u + "|") and k.endswith("|ksg") and v["pass"])
        mx = max(v["max_abs"] for k, v in RES.items() if k.startswith(u + "|") and k.endswith("|ksg"))
        cr["outcome"] = f"pass {npass}/{n}; max_abs <= {e1(mx)} (includes the three T=64 guard-margin runs)"
c["checks_run"].append({"run_ids": [f"{u}|narrowband_f0-0.1|64|pipeline|guard"],
                        "reference": "audit/checks/refs/it_kraskov.py:chk_guard (probe guard_numeric)",
                        "outcome": f"pass; W={g['ref_W_computes']} computes, W={g['ref_W_trips']} gives NaN on all 6 ordered pairs"})
save(p, d)

# ---------------------------------------------------------------- tau-max: documentation self-inconsistent
TAU_EV = ("refuted as a code-vs-documentation deviation: the documentation contradicts itself. The supplement prose (§1.4.5, supplement.txt:489) "
          "and GitBook prose (information-theory.md:216) say 'tau-max-2', but the SPI lists printed with them name te_kraskov_NN-4_k-max-10_tau-max-4 and "
          "te_kraskov_NN-4_DCE_k-max-10_tau-max-4 (supplement.txt:495-496, information-theory.md:222-223), which config.yaml:556/562 (tau_search_max 4) and "
          "the identifier match. tau-max-2 is the gc_gaussian setting (config.yaml:601-602); the prose slip is a documentation-internal inconsistency. "
          "tau > 2 is actually selected (*|embed: k_tau/l_tau 3 on gauss_ar1_pair, 4 with DCE on narrowband_f0-0.1)")
for u in ("infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4", DA):
    p, d = load(u)
    c = d["correctness"]
    for cr in c["candidate_resolutions"]:
        if "tau-max-2" in cr["candidate"]:
            cr["outcome"] = "refuted"
            cr["evidence"] = TAU_EV
    w = c["what_changed"]
    w = w.replace(" Documented as tau-max-2 (supplement, GitBook) while the identifier and code use 4.",
                  " The supplement and GitBook prose say tau-max-2, but their identifier lists say tau-max-4, which the code matches (a slip inside the documentation, not a code deviation).")
    w = w.replace("(window documented as an estimator bias fix, not as an input to embedding selection; tau-max-2)",
                  "(window documented as an estimator bias fix and a heuristic for the autocorrelation time, not as an input to embedding selection; the all-lag rule is scored 6 in infotheory.theiler_window)")
    assert "tau-max-2 (supplement" not in w and "; tau-max-2)" not in w, u
    c["what_changed"] = w
    if u != DA:
        dd = c["deviation_from_documented"]
        old1 = ("(1) Maximum embedding delay: documented 'maximum time delay of 2, tau-max-2' (supplement §1.4.5, GitBook :216); implemented tau_search_max = 4 (config.yaml:556, identifier 'tau-max-4').")
        assert old1 in dd, dd[:300]
        c["deviation_from_documented"] = dd.replace(old1, (
            "(1) Maximum embedding delay: the prose says 'maximum time delay of 2, tau-max-2' (supplement §1.4.5 line 489, GitBook :216), but the SPI lists printed "
            "with it say tau-max-4 (supplement lines 495-496, GitBook :222-223); the code uses tau_search_max = 4 (config.yaml:556), matching the identifiers "
            "(check-stage correction: a slip inside the documentation, not a code deviation)."))
    else:
        dac_s = (f"var2_bivariate T=256 A[0,1] Calculator {f4(dac[0, 0, 1])}, CalculatorFrame {f4(dac[1, 0, 1])}, deepcopy {f4(dac[2, 0, 1])}, pickle {f4(dac[3, 0, 1])} "
                 f"(te_DCE_k1 value on the same data {f4(TE1D_01)}; from-scratch reference matched by the Calculator layer to {e1(r(DAC)['ref_calculator_vs_ref'])}); "
                 f"read-back: original (k 4, NOISE_SEED 42, AUTO 1), deepcopy (4, NONE, 0), pickle (4, 42, 0) ({DAC}, |copyprops)")
        for cr in c["candidate_resolutions"]:
            if cr["candidate"].startswith("copying"):
                cr["evidence"] = "check-stage runs for this unit: " + dac_s + "; same TransferEntropy copy paths as the non-DCE unit: " + cr["evidence"].split("same TransferEntropy copy paths as the non-DCE unit: ", 1)[-1]
        c["closeness"] += (f" Copy paths: {dac_s.split(' (te_DCE_k1')[0]}; the copies drop AUTO_EMBED_METHOD and compute fixed k=l=1 TE with the pair window.")
        c["check_data"] += "; var2_bivariate T256 (copy paths)"
        c["checks_run"].append({"run_ids": [DAC, f"{DA}|var2_bivariate|256|pipeline|copyprops"],
                                "reference": "audit/checks/refs/it_kraskov.py:chk_copy, chk_copyprops (same-lineage)",
                                "outcome": (f"fail 2/2 (finding): copies give {f4(dac[1, 0, 1])} vs {f4(dac[0, 0, 1])}; AUTO_EMBED_METHOD lost by pickle and deepcopy, NOISE_SEED by deepcopy")})
        c["what_changed"] = c["what_changed"].rstrip() + " Every copy (CalculatorFrame, deepcopy, pickle) silently computes fixed k=l=1 TE with the pair window."
    save(p, d)
    if u not in changed:
        changed.append(u)

for u in ("infotheory.mi.kraskov_DCE", "infotheory.te.kraskov_k-1_kt-1_l-1_lt-1"):
    if u not in changed:
        changed.append(u)
print(json.dumps(dict(changed=changed, FRAME=FRAME, DEEP=DEEP, CALC=CALC, FvC=FvC, DvR=DvR, k6=k6["ref_ref_k6_01"], k4=k6["ref_ref_k4_01"],
                      dac=dac[:, 0, 1].tolist(), te1d=TE1D_01, ex=ex), default=str, indent=1))
