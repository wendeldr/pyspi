"""Large-T limit of E[2 sum_k r_i(k) r_j(k)] - (tau + 1) for a Gaussian VAR pair.
For lags k beyond the correlation scale, E[r_i(k) r_j(k)] ~ Cov(r_i(k), r_j(k)) ~ (T-k)/T^2 * C,
C = sum_{m=-inf}^{inf} rho_ij(m)^2 (Bartlett 1946 covariance of lagged products, Gaussian),
so the all-lag sum adds 2 sum_k (T-k)/T^2 C -> C, which does not vanish as T grows."""
import sys
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np, make_data, it_kraskov as R
for name in ("gauss_ar1_pair", "var2_bivariate"):
    ds = make_data.load(name, 1024)
    G = R.autocov(name, ds, 400)                     # G[h] = E[x_{t+h} x_t^T], h = 0..400
    s = np.sqrt(G[0, 0, 0] * G[0, 1, 1])
    rho01 = G[:, 0, 1] / s                           # corr(x0(t+h), x1(t))
    rho10 = G[:, 1, 0] / s                           # corr(x1(t+h), x0(t))
    C = float(np.sum(rho01 ** 2) + np.sum(rho10[1:] ** 2))
    print(name, "tau+1 =", round(R.pop_tau(name, ds) + 1, 4), "C = sum_m rho_01(m)^2 =", round(C, 4),
          "predicted limit tau+1+C =", round(R.pop_tau(name, ds) + 1 + C, 4))
