import json

MI, MID = "infotheory.mi.kraskov", "infotheory.mi.kraskov_DCE"
TL, TLD = "infotheory.tlmi.kraskov", "infotheory.tlmi.kraskov_DCE"
TE1 = "infotheory.te.kraskov_k-1_kt-1_l-1_lt-1"
TED1 = "infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1"
TED2 = "infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1"
TEA = "infotheory.te.kraskov_auto-MAX_CORR_AIS_kmax-10_taumax-4"
TEAD = "infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4"
KSG, THW = "infotheory.est.ksg1", "infotheory.theiler_window"
IDENT = {MI: "mi_kraskov_NN-4", MID: "mi_kraskov_NN-4_DCE", TL: "tlmi_kraskov_NN-4", TLD: "tlmi_kraskov_NN-4_DCE",
         TE1: "te_kraskov_NN-4_k-1_kt-1_l-1_lt-1", TED1: "te_kraskov_NN-4_DCE_k-1_kt-1_l-1_lt-1",
         TED2: "te_kraskov_NN-4_DCE_k-2_kt-1_l-1_lt-1", TEA: "te_kraskov_NN-4_k-max-10_tau-max-4",
         TEAD: "te_kraskov_NN-4_DCE_k-max-10_tau-max-4"}
PROBE = "probes/it_kraskov_probes.py"
runs = []


def add(unit, ds, T, path, tag, procs=None, probe=None, ident="default"):
    dsn = ds if procs is None else ds + "-p" + "".join(map(str, procs))
    rid = f"{unit}|{dsn}|{T}|{path}|{tag}"
    runs.append(dict(run_id=rid, unit_id=unit, identifier=IDENT.get(unit) if ident == "default" else ident,
                     dataset=ds, T=T, path=path, processes=procs, seed=42,
                     probe=None if probe is None else {"module": PROBE, "function": probe}))


# ---------------------------------------------------------------- KSG exactness (from-scratch, Java jitter)
for u in (MI, MID):
    for ds, T in (("bivariate_gaussian", 1024), ("nonlinear_dependence", 1024), ("delayed_noise", 1024),
                  ("iid_gaussian", 64), ("logistic_maps", 256), ("narrowband_f0-0.1", 1024)):
        add(u, ds, T, "kernel", "ksg")
    add(u, "bivariate_gaussian", 256, "pipeline", "ksg")
add(MID, "gauss_ar1_pair", 1024, "kernel", "ksg")
add(MID, "narrowband_f0-0.25", 64, "kernel", "ksg")
add(MID, "trending", 1024, "pipeline-detrend", "ksg")
for u in (TL, TLD):
    for ds, T in (("delayed_noise", 1024), ("var2_bivariate", 1024), ("gauss_ar1_pair", 1024),
                  ("bivariate_gaussian", 1024), ("iid_gaussian", 256), ("logistic_maps", 256)):
        add(u, ds, T, "kernel", "ksg")
add(TLD, "narrowband_f0-0.1", 1024, "kernel", "ksg")
for u in (TE1, TED1, TED2):
    for ds, T in (("var2_bivariate", 1024), ("gauss_ar1_pair", 1024), ("delayed_noise", 1024),
                  ("bivariate_gaussian", 1024), ("logistic_maps", 256), ("narrowband_f0-0.1", 1024)):
        add(u, ds, T, "kernel", "ksg")
add(TED1, "narrowband_f0-0.25", 64, "kernel", "ksg")
add(TED1, "cointegrated", 1024, "pipeline", "ksg")
add(TED2, "var2_bivariate", 1024, "pipeline", "ksg")
for u in (TEA, TEAD):
    add(u, "var2_bivariate", 256, "kernel", "ksg")
    add(u, "gauss_ar1_pair", 256, "kernel", "ksg")
    add(u, "logistic_maps", 256, "kernel", "ksg")
    add(u, "delayed_noise", 256, "kernel", "ksg", procs=[0, 1, 2])
    add(u, "bivariate_gaussian", 256, "pipeline", "ksg", procs=[2, 3])
for ds, P in (("narrowband_f0-0.1", None), ("logistic_maps", None), ("shared_envelope", None)):
    add(TEAD, ds, 64, "kernel", "ksg", procs=P)

# ---------------------------------------------------------------- kernel without jitter, sklearn
for ds in ("bivariate_gaussian", "nonlinear_dependence"):
    add(MI, ds, 1024, "kernel", "nojitter")
for ds, p in (("bivariate_gaussian", [0, 1]), ("bivariate_gaussian", [2, 3]), ("nonlinear_dependence", [0, 1]),
              ("nonlinear_dependence", [2, 3])):
    add(MI, ds, 1024, "kernel", "sklearn", procs=p)

# ---------------------------------------------------------------- statistical convergence vs analytic
for T in (256, 1024, 4096):
    for p in ([0, 1], [2, 3]):
        add(MI, "bivariate_gaussian", T, "pipeline", "truth", procs=p)
for p in ([0, 1], [2, 3]):
    add(MID, "bivariate_gaussian", 1024, "pipeline", "truth", procs=p)
for u in (MI, MID):
    add(u, "gauss_ar1_pair", 1024, "pipeline", "truth")
for u in (TL, TLD):
    add(u, "gauss_ar1_pair", 1024, "pipeline", "truth")
    add(u, "delayed_noise", 1024, "pipeline", "truth", procs=[0, 1])
for u in (TE1, TED1):
    add(u, "gauss_ar1_pair", 1024, "pipeline", "truth")
    add(u, "var2_bivariate", 1024, "pipeline", "truth")
    add(u, "delayed_noise", 1024, "pipeline", "truth", procs=[0, 1])
for ds in ("gauss_ar1_pair", "var2_bivariate"):
    add(TED2, ds, 1024, "pipeline", "truth")
for T in (256, 4096):
    add(TED2, "var2_bivariate", T, "pipeline", "truth")
    add(TE1, "gauss_ar1_pair", T, "pipeline", "truth")

# ---------------------------------------------------------------- null
for u in (MI, MID, TL, TLD, TE1, TED1, TED2):
    add(u, "iid_gaussian", 256, "pipeline", "null")
for u in (TEA, TEAD):
    add(u, "iid_gaussian", 256, "pipeline", "null", procs=[0, 1, 2])

# ---------------------------------------------------------------- direction
for u in (TL, TLD):
    for ds in ("delayed_noise", "var2_bivariate", "gauss_ar1_pair"):
        add(u, ds, 1024, "pipeline", "direction")
for u in (TE1, TED1, TED2):
    for ds in ("delayed_noise", "var2_bivariate", "gauss_ar1_pair", "logistic_maps_chaotic"):
        add(u, ds, 1024, "pipeline", "direction")
for u in (TEA, TEAD):
    for ds, p in (("delayed_noise", [0, 1, 2]), ("var2_bivariate", None), ("gauss_ar1_pair", None),
                  ("logistic_maps_chaotic", None)):
        add(u, ds, 256, "pipeline", "direction", procs=p)

# ---------------------------------------------------------------- symmetry / invariance
for u in (MI, MID):
    add(u, "scaled_offset", 1024, "pipeline", "invariance")
for ds, T in (("iid_gaussian", 256), ("delayed_noise", 1024), ("bivariate_gaussian", 1024)):
    add(MI, ds, T, "pipeline", "ordered", probe="ordered_mi")
add(MID, "bivariate_gaussian", 1024, "pipeline", "ordered", probe="ordered_mi")

# ---------------------------------------------------------------- threads / seeds
for u in (MI, MID, TL, TE1):
    add(u, "bivariate_gaussian", 1024, "pipeline", "threads", probe="num_threads")
add(TEA, "bivariate_gaussian", 256, "pipeline", "threads", procs=[2, 3], probe="num_threads")
for u in (MI, TL, TE1, TED1, TEA):
    add(u, "logistic_maps", 256, "pipeline", "seeds", probe="seeds")
add(MI, "bivariate_gaussian", 1024, "pipeline", "seeds", probe="seeds")

# ---------------------------------------------------------------- copy paths
for u in (TEA, TED2, TE1):
    add(u, "var2_bivariate", 256, "pipeline", "copy", probe="copy_paths")
add(MI, "logistic_maps", 256, "pipeline", "copy", probe="copy_paths")
for u in (TEA, TE1):
    add(u, "var2_bivariate", 256, "pipeline", "copyprops", probe="copy_props")

# ---------------------------------------------------------------- auto-embedding read-back
for u in (TEA, TEAD):
    for ds, T, p in (("var2_bivariate", 256, None), ("gauss_ar1_pair", 256, None), ("narrowband_f0-0.1", 256, [0, 1]),
                     ("var2_bivariate", 64, None), ("logistic_maps", 256, None)):
        add(u, ds, T, "pipeline", "embed", procs=p, probe="auto_embedding")
    for ds, p in (("var2_bivariate", None), ("gauss_ar1_pair", None), ("delayed_noise", [0, 1, 2]), ("logistic_maps", None)):
        add(u, ds, 256, "pipeline", "fixed", procs=p, probe="auto_fixed_repro")

# ---------------------------------------------------------------- estimator unit (probes)
add(KSG, "var2_chain", 1024, "kernel", "direct", probe="direct_jidt", ident=None)
add(KSG, "delayed_noise", 256, "kernel", "direct", procs=[0, 1, 2], probe="direct_jidt", ident=None)
add(KSG, "iid_gaussian", 64, "kernel", "semantics", probe="dce_semantics", ident=None)
add(KSG, "iid_gaussian", 64, "kernel", "props", probe="thread_props", ident=None)

# ---------------------------------------------------------------- Theiler window unit (probes)
for ds in ("iid_gaussian", "bivariate_gaussian", "var2_bivariate", "gauss_ar1_pair", "delayed_noise", "narrowband_f0-0.1",
           "logistic_maps", "cointegrated", "trending", "shared_envelope"):
    add(THW, ds, 1024, "pipeline", "lagloop", probe="theiler_raw", ident=None)
for ds in ("trending", "cointegrated"):
    add(THW, ds, 1024, "pipeline-detrend", "lagloop", probe="theiler_raw", ident=None)
    add(THW, ds, 1024, "pipeline-detrend", "detrend", probe="theiler_raw", ident=None)
for ds in ("var2_bivariate", "iid_gaussian"):
    add(THW, ds, 1024, "pipeline", "bartlett", probe="theiler_raw", ident=None)
add(THW, "iid_gaussian", 1024, "pipeline", "pop", procs=[0, 1], probe="theiler_raw", ident=None)
for ds in ("gauss_ar1_pair", "var2_bivariate"):
    add(THW, ds, 1024, "pipeline", "pop", probe="theiler_raw", ident=None)
for T in (64, 256, 1024, 4096):
    add(THW, "narrowband_f0-0.1", T, "pipeline", "growth", probe="theiler_raw", ident=None)

ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids)), [i for i in ids if ids.count(i) > 1]
json.dump({"family": "it_kraskov", "runs": runs},
          open("/media/dan/Data/git/pyspi/audit/checks/manifest/it_kraskov.json", "w"), indent=1)
print(len(runs), "runs")
