import sys, numpy as np, json, importlib.util, time
spec=importlib.util.spec_from_file_location('ref','/media/dan/Data/git/pyspi/audit/checks/refs/it_kraskov.py'); ref=importlib.util.module_from_spec(spec); spec.loader.exec_module(ref)
idx=json.load(open('/media/dan/Data/git/pyspi/audit/checks/out/pyspi/index/it_kraskov.json'))
man=json.load(open('/media/dan/Data/git/pyspi/audit/checks/manifest/it_kraskov.json'))
skip=set(sys.argv[1:])
for run in man['runs']:
    rid=run['run_id']
    if rid not in idx or any(s in rid for s in skip): continue
    if idx[rid]['status']!='ok': print('PYSPI-ERR', rid, idx[rid].get('error')); continue
    t=time.time()
    try:
        ref.run_check(run)
        a=np.load(f"audit/checks/out/pyspi/{rid}.npz")["value"]; z=np.load(f"audit/checks/out/ref/{rid}.npz")
        b=z['value']; c=str(z['criterion'])
        if c=='qualitative': info=('pass' if int(z['pass_flag']) else 'FAIL', {k:(z[k].tolist() if z[k].size<8 else '...') for k in z.files if k not in ('value','criterion','reference_detail','notes','reference_kind','pass_flag')})
        elif c=='statistical': info=('z_max', float(z['z_max']), 'pop', z['population'].tolist())
        else: info=ref.maxabs(a,b) if b.shape==a.shape else ('SHAPE',a.shape,b.shape)
        print(rid, c, info, f'{time.time()-t:.1f}s', flush=True)
    except Exception as e: print('ERR', rid, repr(e), flush=True)
