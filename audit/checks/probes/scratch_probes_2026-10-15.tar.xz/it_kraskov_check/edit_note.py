"""Apply the post-review edits to audit/notes/it_kraskov.md (numbers from the forced re-run)."""
import json
import sys
from pathlib import Path

import numpy as np

AUD = Path("/media/dan/Data/git/pyspi/audit")
RES = json.loads((AUD / "checks/out/results/it_kraskov.json").read_text())
PYS = AUD / "checks/out/pyspi"
IDX = json.loads((AUD / "checks/out/pyspi/index/it_kraskov.json").read_text())
note = AUD / "notes/it_kraskov.md"
s = note.read_text()


def r(rid):
    return RES[rid]


def pv(rid):
    with np.load(PYS / f"{rid}.npz") as z:
        return np.asarray(z["value"], dtype=float)


def rep(a, b):
    global s
    if s.count(a) != 1:
        sys.exit(f"anchor count {s.count(a)}: {a[:80]!r}")
    s = s.replace(a, b)


f4 = lambda x: f"{x:.4f}"
e1 = lambda x: f"{x:.1e}"

n = len(RES)
npass = sum(v["pass"] for v in RES.values())
fails = sorted(k for k, v in RES.items() if not v["pass"])
tsum = sum(v.get("time_s", 0) for v in IDX.values())
tmax = max(v.get("time_s", 0) for v in IDX.values())

# ------------------------------------------------------------------ header
rep("(199 runs: 193 pass, 6 fail, 0 without a reference;",
    f"({n} runs: {npass} pass, {n - npass} fail, 0 without a reference; the {n - npass} failures are the findings and statistical excursions named below;")
rep("The pyspi side took 537 s of wall time in total on a loaded 64-core machine (largest single run 33 s); the references about 4 minutes.",
    f"The pyspi side took {tsum:.0f} s in total on a loaded 64-core machine (largest single run {tmax:.0f} s); the references about 6 minutes. "
    "The manifest and references were extended after an adversarial review (theiler population runs at T=256/4096, an NN-6 copy run, "
    "te_DCE_auto copy runs, tlmi direction and time-reversal runs, and DCE guard runs) and the whole family was re-run with `--force`.")
rep("four cheap convergence runs at T=4096 (two `mi.kraskov` pairs, one `te_k1` and one `te_DCE_k2` run, each at most 1.4 s)",
    "four cheap convergence runs at T=4096 (two `mi.kraskov` pairs, one `te_k1` and one `te_DCE_k2` run, each at most 1.4 s) and two cheap window-rule population runs at T=4096")

# ------------------------------------------------------------------ mi copy wording
MC = "infotheory.mi.kraskov|logistic_maps|256|pipeline|copy"
mc = pv(MC)
k6 = r("infotheory.mi.kraskov|bivariate_gaussian-p23|256|pipeline|copyk6")
rep("- **Finding (copy path).** `copy` fails as expected: CalculatorFrame gives 0.2248 vs 0.2301 on tied logistic_maps because the deep copy is unseeded; pickle is exact.",
    f"- **Finding (copy path).** `copy` fails as expected on tied logistic_maps (A[0,1] = {f4(mc[0, 0, 1])}): CalculatorFrame and deepcopy run with unseeded jitter, so each run gives a "
    f"non-reproducible draw (here {f4(mc[1, 0, 1])} and {f4(mc[2, 0, 1])}; an earlier run of the same check gave 0.2248). Calculator and pickle are exact. "
    f"`copyk6` shows the prop_k loss on tie-free data: MutualInfo(kraskov, prop_k=6) gives {f4(k6['ref_ref_k6_01'])} through Calculator and pickle "
    f"(<= {e1(max(k6['ref_calculator_vs_k6'], k6['ref_pickle_vs_k6']))} from the k=6 reference), but {f4(k6['ref_pyspi_frame_01'])} through CalculatorFrame and deepcopy, "
    f"which is the k=4 value ({e1(k6['ref_frame_vs_k4'])}). `copypropsk6` reads k = 6 / 4 / 6 for original / deepcopy / pickle. Before these runs the prop_k half "
    "rested only on the trace-stage probe `r4_deepcopy.py`.")

# ------------------------------------------------------------------ mi_DCE score
rep("### infotheory.mi.kraskov_DCE: variant, 7", "### infotheory.mi.kraskov_DCE: variant, 6")
rep("- **Score.** 7 (rubric: supplement variant, value-changing): the KSG part is exact, and the window rule is the deviation.",
    "- **Score.** 6 (rubric: deviates from both the supplement and canonical in an interpretable way). The KSG part is exact; the value is set by the window rule, "
    "which `infotheory.theiler_window` scores 6 because it is not the documented autocorrelation-time heuristic. A unit whose value depends on that rule cannot "
    "also match the supplement variant (anchor 7), so all four fixed DCE consumers move from 7 to 6, in line with te_DCE_auto (review item).")

# ------------------------------------------------------------------ theiler population
P = {(ds, T): r(f"infotheory.theiler_window|{ds}|{T}|pipeline|pop") for ds in ("gauss_ar1_pair", "var2_bivariate") for T in (256, 1024, 4096)}
v256 = P[("var2_bivariate", 256)]
old_pop_start = s.index("- **Population (Bartlett τ + 1).**")
old_pop_end = s.index("- **Growth with T.**")
rows = []
for ds in ("gauss_ar1_pair", "var2_bivariate"):
    for T in (256, 1024, 4096):
        v = P[(ds, T)]
        rows.append(f"  | {ds} | {T} | {v['ref_tau_population'] + 1:.2f} | {v['ref_mc_mean_01']:.3f} ± {v['ref_mc_sd_01']:.3f} | {v['ref_mc_excess_over_tau_plus_1']:.2f} | "
                    f"{v['ref_large_T_limit_tau_plus_1_plus_C']:.3f} | {v['ref_raw_pyspi_01']:.3f} (z {v['ref_z_max']:.2f}{', fail' if not v['pass'] else ''}) |")
iid = r("infotheory.theiler_window|iid_gaussian-p01|1024|pipeline|pop")
rows.append(f"  | iid_gaussian | 1024 | 2.00 | {iid['ref_mc_mean_01']:.3f} ± {iid['ref_mc_sd_01']:.3f} | {iid['ref_mc_excess_over_tau_plus_1']:.3f} | 2.000 | {iid['ref_raw_pyspi_01']:.3f} (z {iid['ref_z_max']:.2f}) |")
new_pop = (
    "- **Population (Bartlett τ + 1).** On cross-correlated pairs the expectation of the rule sits above τ + 1, and the excess does not shrink as T grows. "
    "So this is a non-vanishing (asymptotic) upward bias of the all-lag rule, not a finite-sample bias: the rule is an inconsistent estimator of Bartlett's factor "
    "(review item; my earlier wording \"finite-sample bias\" was wrong). Each lag k beyond the correlation scale contributes "
    "E[r_i(k) r_j(k)] ≈ Cov(r_i(k), r_j(k)) ≈ (T−k)/T² · C with C = Σ_m ρ_ij(m)² (Bartlett's covariance of lagged products for a Gaussian pair). Summing all T−1 lags gives "
    "2 Σ_k (T−k)/T² · C → C, so E[raw] → τ + 1 + C (`refs/it_kraskov.py:pop_cross_sq`). For independent channels C = 0 and the rule has no such excess.\n\n"
    "  | Dataset | T | τ + 1 | MC mean ± SD of the rule | MC excess | limit τ + 1 + C | pyspi raw |\n"
    "  |---|---|---|---|---|---|---|\n" + "\n".join(rows) + "\n\n"
    f"  The var2_bivariate T=256 run fails the 2-SD criterion: pyspi {v256['ref_raw_pyspi_01']:.3f} against MC {v256['ref_mc_mean_01']:.3f} ± {v256['ref_mc_sd_01']:.3f} (z {v256['ref_z_max']:.2f}). "
    "pyspi matches the lag-loop rule exactly on this draw. The rule's distribution is right-skewed (skew 0.71), and in a 2000-draw probe "
    "(scratchpad `it_kraskov_check/theiler_tail.py`) 0.55% of draws reach 3.421. I read it as a tail draw of this dataset and did not loosen the criterion. "
    "The reviewer's own Monte Carlo reached T = 16384 (mean 5.21 for gauss_ar1_pair), consistent with the limit 5.197.\n")
s = s[:old_pop_start] + new_pop + s[old_pop_end:]

# ------------------------------------------------------------------ tlmi section
dch = {u: r(f"{u}|logistic_maps_chaotic|1024|pipeline|direction") for u in ("infotheory.tlmi.kraskov", "infotheory.tlmi.kraskov_DCE")}
rev = {(u, ds): r(f"{u}|{ds}|{T}|pipeline|reversal") for u in ("infotheory.tlmi.kraskov", "infotheory.tlmi.kraskov_DCE")
       for ds, T in (("delayed_noise", 1024), ("iid_gaussian", 256), ("logistic_maps", 256))}
gt = r("infotheory.tlmi.kraskov_DCE|narrowband_f0-0.1|64|pipeline|guard")
kst = [r(f"infotheory.tlmi.kraskov_DCE|{ds}|64|pipeline|ksg") for ds in ("narrowband_f0-0.1", "narrowband_f0-0.25", "logistic_maps", "shared_envelope")]
rep("### infotheory.tlmi.kraskov: matches, 9; infotheory.tlmi.kraskov_DCE: variant, 7",
    "### infotheory.tlmi.kraskov: matches, 9; infotheory.tlmi.kraskov_DCE: variant, 6")
T, D = "infotheory.tlmi.kraskov", "infotheory.tlmi.kraskov_DCE"
rep("- **Score.** 9 for tlmi.kraskov because",
    f"- **Direction on logistic_maps_chaotic** (x → y only; replaces the tied `logistic_maps` fixture named in the proposed check, as CONVENTIONS.md asks): "
    f"A[0,1] {dch[T]['ref_A01']:.3f} vs A[1,0] {dch[T]['ref_A10']:.3f} (tlmi), {dch[D]['ref_A01']:.3f} vs {dch[D]['ref_A10']:.3f} (tlmi_DCE), both pass.\n"
    f"- **Time reversal** (`reversal`, probe `time_reversed`). For y = x reversed, I(y_i(t); y_j(t+1)) uses the sample pairs (x_j(s), x_i(s+1)), so A(y) = A(x).T up to the jitter, "
    f"which follows the sample order. pyspi gives max|A(y).T − A(x)| = {e1(rev[(T, 'delayed_noise')]['ref_rev_T_minus_orig_pyspi'])} on delayed_noise and "
    f"{e1(rev[(T, 'iid_gaussian')]['ref_rev_T_minus_orig_pyspi'])} on iid_gaussian, but {rev[(T, 'logistic_maps')]['ref_rev_T_minus_orig_pyspi']:.4f} on tied logistic_maps "
    f"(tlmi_DCE: {e1(rev[(D, 'delayed_noise')]['ref_rev_T_minus_orig_pyspi'])}, {e1(rev[(D, 'iid_gaussian')]['ref_rev_T_minus_orig_pyspi'])}, "
    f"{rev[(D, 'logistic_maps')]['ref_rev_T_minus_orig_pyspi']:.4f}). The from-scratch reference reproduces both layers on all six runs "
    f"(max_abs <= {e1(max(v['max_abs'] for v in rev.values()))}), and without jitter the reversal is exact on the tied data too "
    f"({e1(rev[(T, 'logistic_maps')]['ref_rev_T_minus_orig_ref_nojitter'])}). So \"equals the reversed-time transpose only approximately\" holds exactly as far as the jitter goes.\n"
    f"- **tlmi_DCE guard** (proposed qualitative check). At T=64 (N = 63) the rule gives at most W = {max(v['ref_W_max'] for v in kst)} on narrowband_f0-0.1/0.25, "
    f"logistic_maps and shared_envelope. The guard margin N − (4 + 2W) is at least {min(v['ref_guard_margin_min'] for v in kst)}, and no pair is NaN (4/4 `ksg` runs exact). "
    f"The rule's window stays near T/3 or below on these inputs, while the guard needs W >= (N − 4)/2 ≈ T/2, so it cannot trip here. "
    f"To show the guard itself, `guard` rebuilds the SPI with a numeric window: W = {gt['ref_W_computes']} computes, and W = {gt['ref_W_trips']} gives NaN on all "
    f"{gt['ref_nan_pyspi_layer1']} ordered pairs (pyspi logs a warning per pair), both layers matched by the reference to {e1(gt['max_abs'])}.\n"
    "- **Score.** 9 for tlmi.kraskov because")
rep("The asymmetry itself is already documented (REVIEW M8).",
    "The asymmetry itself is already documented (REVIEW M8). 6 for tlmi_DCE, for the same reason as mi_DCE: the value depends on the window rule scored 6.")

# ------------------------------------------------------------------ TE fixed
g1 = r("infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|narrowband_f0-0.1|64|pipeline|guard")
k1 = [r(f"infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|{ds}|64|pipeline|ksg") for ds in ("narrowband_f0-0.1", "logistic_maps", "shared_envelope")]
k1.append(r("infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1|narrowband_f0-0.25|64|kernel|ksg"))
u1 = "infotheory.te.kraskov_DCE_k-1_kt-1_l-1_lt-1"
n1 = [v for k, v in RES.items() if k.startswith(u1 + "|") and k.endswith("|ksg")]
rep("- **te_DCE_k-1 (variant, 7).** 8/8 `ksg` runs agree to ≤ 2.9e-15, including cointegrated with W = 158–205. On narrowband (W = 339), A[1,0] goes from 0.717 to 0.675.",
    f"- **te_DCE_k-1 (variant, 6).** {sum(v['pass'] for v in n1)}/{len(n1)} `ksg` runs agree to ≤ {e1(max(v['max_abs'] for v in n1))}, including cointegrated with W = 158–205. "
    f"On narrowband (W = 339), A[1,0] goes from 0.717 to 0.675. Guard (proposed check): at T=64 the rule gives W <= {max(v['ref_W_max'] for v in k1)} on narrowband_f0-0.1/0.25, "
    f"logistic_maps and shared_envelope, margin N − (4 + 2W) >= {min(v['ref_guard_margin_min'] for v in k1)}, no NaN. With a numeric window, W = {g1['ref_W_computes']} computes and "
    f"W = {g1['ref_W_trips']} gives NaN on all {g1['ref_nan_pyspi_layer1']} pairs (`guard`, reproduced to {e1(g1['max_abs'])}). Score 6 as for mi_DCE.")
rep("- **te_DCE_k-2 (variant, 7).** 7/7 `ksg` runs agree to ≤ 1.1e-15.",
    "- **te_DCE_k-2 (variant, 6).** 7/7 `ksg` runs agree to ≤ 1.1e-15. Score 6 as for mi_DCE; in addition every copy path computes k=1 (below).")

# ------------------------------------------------------------------ TE auto: tau-max
rep("The supplement documents MAX_CORR_AIS, so this is a variant with tau-max 4 instead of the documented 2.",
    "The supplement documents MAX_CORR_AIS, so this is the supplement's variant, value-changing against a canonical criterion (anchor 7).\n"
    "  - **tau-max (candidate refuted as a code deviation).** The documentation contradicts itself. The supplement prose (§1.4.5, `supplement.txt:489`) and the GitBook prose "
    "(`information-theory.md:216`) say tau-max-2, but the SPI lists printed with them name `te_kraskov_NN-4_k-max-10_tau-max-4` and `te_kraskov_NN-4_DCE_k-max-10_tau-max-4` "
    "(`supplement.txt:495-496`, `information-theory.md:222-223`). The code (`config.yaml:556`, :562) matches those identifiers. tau-max-2 is the gc_gaussian setting "
    "(`config.yaml:601-602`). What remains is a prose slip inside the documentation, which is no longer used as a deviation-from-supplement argument for either auto unit.")
DA = "infotheory.te.kraskov_DCE_auto-MAX_CORR_AIS_kmax-10_taumax-4"
dac = pv(f"{DA}|var2_bivariate|256|pipeline|copy")
dcp = r(f"{DA}|var2_bivariate|256|pipeline|copyprops")
te1d = pv("infotheory.te.kraskov_DCE_k-2_kt-1_l-1_lt-1|var2_bivariate|256|pipeline|copy")[1, 0, 1]
rep("  - **Fixed path.** `fixed` passes 4/4.",
    "  - **Fixed path.** `fixed` passes 4/4.\n"
    f"  - **Finding (copy path), now run for this unit.** On var2_bivariate T=256, A[0,1] is {f4(dac[0, 0, 1])} through Calculator (matching the reference to "
    f"{e1(r(f'{DA}|var2_bivariate|256|pipeline|copy')['ref_calculator_vs_ref'])}), but {f4(dac[1, 0, 1])} / {f4(dac[2, 0, 1])} / {f4(dac[3, 0, 1])} through CalculatorFrame / deepcopy / pickle "
    f"(the k=l=1 DCE TE on the same data is {f4(te1d)}). `copyprops`: AUTO_EMBED_METHOD is lost by both copies (read-back 0), NOISE_SEED by deepcopy. "
    "Previously this unit's copy candidate rested on the shared code path and the non-DCE runs.\n"
    "  - **Score.** 6 (unchanged): the window rule (scored 6) feeds the embedding search. The tau-max-2 argument is withdrawn (see above).")

# ------------------------------------------------------------------ directions
ndir = [v for k, v in RES.items() if k.endswith("|direction")]
rep("- **Directions.** Every direction run passes (26/26).",
    f"- **Directions.** Every direction run passes ({sum(v['pass'] for v in ndir)}/{len(ndir)}), including the two tlmi runs on logistic_maps_chaotic.")

# ------------------------------------------------------------------ trace-stage corrections
rep("- **Direction dataset.** For directed checks I used `logistic_maps_chaotic` (x → y only) in place of the tied `logistic_maps` fixture, as data/CONVENTIONS.md asks.",
    "- **Direction dataset.** For directed checks I used `logistic_maps_chaotic` (x → y only) in place of the tied `logistic_maps` fixture, as data/CONVENTIONS.md asks. "
    "This now covers the two tlmi units as well as the TE units.\n"
    "- **tau-max.** The trace-stage deviation \"documented 2, implemented 4\" in `te.kraskov_auto` (`deviation_from_documented` (1)) was corrected: the documentation is "
    "self-inconsistent and the code matches its identifiers (see TE auto-embedding above). Both auto records mark the candidate refuted.\n"
    "- **Reference kinds of the Monte Carlo runs.** `truth`, `null` and `pop` runs now carry `reference_kind: independent-impl` in results.json, because the pass criterion "
    "uses the Monte Carlo mean and SD of the from-scratch estimator (or rule). The analytic population value is still quoted (`population`, `population_kind: analytic`).\n"
    "- **Window-rule bias.** `infotheory.theiler_window` closeness and what_changed, and Open question 3 below, now say \"non-vanishing (asymptotic) upward bias\" "
    "instead of \"finite-sample bias\".\n"
    "- **DCE scores.** mi_DCE, tlmi_DCE, te_DCE_k-1 and te_DCE_k-2 go from 7 to 6 (see mi_DCE).")

# ------------------------------------------------------------------ trace section tau-max bullet
rep("- **tau-max.** Documented 2; implemented 4 (`config.yaml:556`, identifier `tau-max-4`).",
    "- **tau-max.** Documented 2; implemented 4 (`config.yaml:556`, identifier `tau-max-4`). (Corrected at the check stage: only the prose says 2; the identifier lists printed with it say 4, which the code matches.)")

# ------------------------------------------------------------------ open questions answered
rep("and it carries an upward finite-sample bias on correlated pairs (gauss_ar1_pair 5.1 against τ + 1 = 3.6).",
    f"and on cross-correlated pairs it carries an upward bias that does not vanish with T: its expectation tends to τ + 1 + Σ_m ρ_ij(m)² "
    f"(gauss_ar1_pair MC {P[('gauss_ar1_pair', 4096)]['ref_mc_mean_01']:.2f} at T=4096 against τ + 1 = 3.63 and the limit 5.20).")
rep("unseeded jitter under deepcopy (tied MI 0.2301 → 0.2248)",
    f"unseeded jitter under deepcopy (tied MI 0.2301 → a non-reproducible draw, {f4(mc[1, 0, 1])} in this run and 0.2248 in an earlier one), and k = 4 instead of k = 6 for an NN-6 MI ({f4(k6['ref_ref_k6_01'])} → {f4(k6['ref_pyspi_frame_01'])})")

note.write_text(s)
print(n, npass, fails)
