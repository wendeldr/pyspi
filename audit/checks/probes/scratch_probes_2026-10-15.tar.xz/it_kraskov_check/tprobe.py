import sys, numpy as np, time
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/probes'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
import it_kraskov_probes as P, make_data
np.set_printoptions(linewidth=200, precision=6)
fn = sys.argv[1]; ident = sys.argv[2]; ds = sys.argv[3]; T = int(sys.argv[4]); procs = sys.argv[5] if len(sys.argv)>5 else None
x = make_data.load(ds, T)['x']
if procs: x = x[[int(q) for q in procs.split(',')]]
t=time.time(); v = getattr(P, fn)(x, dict(identifier=ident, path='pipeline')); print(fn, f'{time.time()-t:.1f}s'); print(v)
