import sys
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np, it_kraskov as R, make_data
for ds_name, T in (("var2_bivariate", 256), ("var2_bivariate", 1024), ("gauss_ar1_pair", 256)):
    ds = make_data.load(ds_name, T)
    rid = f"infotheory.theiler_window|{ds_name}|{T}|pipeline|pop"
    sims = R.simulator(ds_name, ds, None)(T, 2000, np.random.default_rng(1))
    v = np.array([R.window_raw_fast(R.zs(q))[0, 1] for q in sims])
    S = R.load_pyspi(rid)[0, 1]
    print(ds_name, T, "pyspi", round(S, 3), "MC mean", v.mean().round(3), "sd", v.std().round(3), "skew", (((v - v.mean())/v.std())**3).mean().round(2),
          "P(MC >= pyspi)", (v >= S).mean(), "q99.9", np.quantile(v, .999).round(3))
