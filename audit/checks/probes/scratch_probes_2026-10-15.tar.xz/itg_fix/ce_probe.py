import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/tests'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
from regression import harness; harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
import make_data
d = make_data.load('scaled_offset', 1024); x = d['x']
dat = Data(x, normalise=False)
ce = it.ConditionalEntropy(estimator='gaussian')
A = ce.multivariate(dat)
sd = x.std(axis=1, ddof=1)
print('A01,A10', A[0,1], A[1,0], A[0,1]-A[1,0])
print('ln sample ratio', np.log(sd[1]/sd[0]), 'ln10', np.log(10))
for i in range(4):
  for j in range(4):
    if i!=j: assert abs((A[i,j]-A[j,i]) - np.log(sd[j]/sd[i]))<1e-12, (i,j)
b = make_data.load('bivariate_gaussian',1024)['x']; bs=b.std(axis=1,ddof=1)
print('ln10 + ln(std u1/std u0)', np.log(10)+np.log(bs[1]/bs[0]))
# default pipeline symmetry
A2 = it.ConditionalEntropy(estimator='gaussian').multivariate(Data(x))
print('max |A-A.T| zscored', np.nanmax(np.abs(A2-A2.T)))
