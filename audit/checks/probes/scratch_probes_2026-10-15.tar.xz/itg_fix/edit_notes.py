from pathlib import Path
p = Path('/media/dan/Data/git/pyspi/audit/notes/it_gaussian.md'); t = p.read_text()
def sub(old, new):
    global t
    assert t.count(old) == 1, old[:60]
    t = t.replace(old, new)
sub("Comparing v1.6.1 with a9b6b3e, the Gaussian MI/CMI/TE/AIS paths differ only in observation-ID and noise-seed bookkeeping. Every probe",
    "Comparing v1.6.1 with a9b6b3e: the Gaussian MI, CMI, TE and AIS leaf classes, `MatrixUtils`, `MathsUtils` and `ChiSquareMeasurementDistribution` are byte-identical, and their `*MultiVariateCommon` / `*Via*` parents differ only in observation-ID and noise-seed bookkeeping. `EntropyCalculatorMultiVariateGaussian` changed more (128 diff lines): it was refactored onto the new `EntropyCalculatorMultiVariateCommon`, losing its own `setObservations`, `initialise()`, `setProperty`, `getProperty` and `setDebug`, gaining `finaliseAddObservations` and `isComputed` caching. Its value path (covariance → Cholesky → ½(d(1+ln 2π)+ln det)) is unchanged. Every probe")
sub("(`infotheory.py:159-177`), cached and mirrored.",
    "(`infotheory.py:159-177`). `Undirected.multivariate` (`base.py:133-137`) visits every ordered pair through `Directed.multivariate` (`base.py:85-93`) and then overwrites the lower triangle from the upper; the second order of each pair is a cache hit (`infotheory.py:168-175` stores both [i,j] and [j,i]), so JIDT runs P(P−1)/2 times (probe, P=5: 10 calls).")
sub("  - With normalise=False, ce becomes asymmetric (scaled_offset: 2.0787 vs −0.2373).",
    "  - scaled_offset z-scored: max |A − Aᵀ| = 2.2e-16. The record therefore sets `symmetry_expected: sym` for the default pipeline.\n  - With normalise=False, ce becomes asymmetric (scaled_offset: 2.0787 vs −0.2373). The difference A[i,j] − A[j,i] = ln(sd_j/sd_i) uses the sample SDs of the scaled rows: 2.3159931 for (0,1), not ln 10 = 2.3025851, because the scaled rows are built from different base rows (`make_data.py:246-249`).")
sub("  - Conditioning order on raw scaled_offset (A[0,1]−A[1,0] = ln 10).",
    "  - Conditioning order on raw scaled_offset (A[i,j]−A[j,i] = ln(sd_j/sd_i) with sample SDs, to 1e-12).")
sub("no bias correction and a bare `except` returning NaN (`infotheory.py:267-283`). Probe: 0.01887329 = −½ ln(1−r²).",
    "no bias correction and a bare `except` returning NaN (`infotheory.py:267-283`). Probe: 0.01887329 = −½ ln(1−r²). `MutualInfo.bivariate` has no cache, so `Undirected.multivariate` runs the JIDT MI for both orders of every pair and discards the lower triangle: P(P−1) calls (probe, P=5: 20 calls).")
sub("  - Each candidate scores the Gaussian AIS minus the χ² null mean k/(2N)",
    "  - Each candidate scores the Gaussian AIS minus the χ² null mean k/(2N), where N = T − (k−1)τ − 1 is that candidate's own sample count (`ActiveInfoStorageCalculatorViaMutualInfo:440-451`), so candidates with different k are penalised on different N. The probe re-implementation needs this per-candidate N to match JIDT's selections")
sub("- **Probe:**\n  - te_symbolic_k-1 is bitwise equal to gc_gaussian_k-1.",
    "- **Probe (elaborates known bug 1, not a new candidate):**\n  - te_symbolic_k-1 is bitwise equal to gc_gaussian_k-1.")
sub("- **Sign.** Values are negative for well-predicted targets.",
    "- **Sign (already documented, REVIEW M8; not a candidate).** Values are negative for well-predicted targets.")
p.write_text(t); print('ok')
