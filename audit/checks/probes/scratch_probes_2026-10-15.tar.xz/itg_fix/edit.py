from pathlib import Path
R = Path('/media/dan/Data/git/pyspi/audit/records')
def sub(name, old, new, count=1):
    p = R / f'{name}.yaml'; t = p.read_text()
    n = t.count(old)
    assert n == count, (name, n, old[:80])
    p.write_text(t.replace(old, new))

# 1. ce.gaussian proposed_checks[1] expected_outcome
sub('infotheory.ce.gaussian',
    "expected_outcome: A[i,j] equals the reference for H(x_j | x_i) (not H(x_i | x_j)) to 1e-12; A[0,1]-A[1,0] = ln(s1/s0) = ln 10 up to 1e-12",
    "expected_outcome: A[i,j] equals the reference for H(x_j | x_i) (not H(x_i | x_j)) to 1e-12; A[i,j]-A[j,i] = H(x_j) - H(x_i) = ln(sd_j/sd_i) with sd the ddof=1 sample SDs of the scaled rows, to 1e-12\n      (probe 2.3159931410300874 vs 2.315993141030088 for (0,1)). This is ln 10 + ln(sd(u1)/sd(u0)) with u the bivariate_gaussian rows, not ln 10 itself (2.302585), because the scaled rows are different base rows")
# also reference text: 'to fix the conditioning order' fine. units_and_range wording
sub('infotheory.ce.gaussian',
    "with normalise=False shifts by ln(s_j) and is asymmetric",
    "with normalise=False shifts by ln(sample SD of x_j) and is asymmetric (A[i,j]-A[j,i] = ln(sd_j/sd_i))")
# 3. symmetry_expected
sub('infotheory.ce.gaussian', "  symmetry_expected: asym\n", "  symmetry_expected: sym\n")
sub('infotheory.ce.gaussian',
    "A[0,1]=2.0787 vs A[1,0]=-0.2373 (x1 has scale 2, x0 scale 0.2)'",
    "A[0,1]=2.0787 vs A[1,0]=-0.2373 (x1 has scale 2, x0 scale 0.2). symmetry_expected is sym because the check stage and Calculator use the default pipeline (normalise=True), where H(x_i) is the same constant for every channel and A = A.T exactly (probe scaled_offset_T1024 z-scored max |A - A.T| = 2.2e-16; var2_bivariate_T1024 A[0,1] = A[1,0] = 1.400065239580088); under Data(normalise=False) the matrix is asym, with A[i,j]-A[j,i] = ln(sd_j/sd_i)'")
sub('infotheory.ce.gaussian',
    "scaled_offset_T1024 z-scored matrix symmetric to 4 decimals at every pair,",
    "scaled_offset_T1024 z-scored matrix symmetric to max |A - A.T| = 2.2e-16,")

# 2. mi / je direction convention
sub('infotheory.mi.gaussian',
    "direction_convention: 'undirected: A[i,j] = A[j,i] = I(x_i; x_j), computed for i<j and mirrored'",
    "direction_convention: 'undirected: A[i,j] = A[j,i] = I(x_i; x_j). Undirected.multivariate (base.py:133-137) first runs Directed.multivariate (base.py:85-93), which calls bivariate for every ordered pair i != j, then overwrites the lower triangle from the upper; MutualInfo.bivariate has no cache (infotheory.py:267-283), so the JIDT MI calculator runs P(P-1) times and the lower-triangle values are computed and discarded (probe iid_gaussian_T256, P=5: 20 computeAverageLocalOfObservations calls)'")
sub('infotheory.mi.gaussian',
    "implemented_as: For each pair (i<j kept),",
    "implemented_as: For each ordered pair (both orders computed, upper triangle i<j kept),")
sub('infotheory.je.gaussian',
    "direction_convention: 'undirected: A[i,j] = A[j,i] = H(x_i, x_j), computed for i<j and mirrored (base.py:136-137)'",
    "direction_convention: 'undirected: A[i,j] = A[j,i] = H(x_i, x_j). Undirected.multivariate (base.py:133-137) runs Directed.multivariate (base.py:85-93) over every ordered pair and then overwrites the lower triangle from the upper; the second order of each pair is a cache hit in data.joint_entropy (infotheory.py:167-175 stores both [i,j] and [j,i]), so the JIDT entropy calculator runs P(P-1)/2 times (probe iid_gaussian_T256, P=5: 10 calls)'")
sub('infotheory.je.gaussian', "for i<j the (T,2) matrix", "for each unordered pair (first order visited by the loop) the (T,2) matrix")
sub('infotheory.je.gaussian', "Lower triangle\n    mirrored.'", "Both orders are visited, the second is a cache hit; the lower triangle\n    is then overwritten from the upper.'")

# 4. delegate_lib wording in all 13 records
old = "the Gaussian classes used here are unchanged between tag v1.6.1 and commit a9b6b3e apart from observation-ID/noise-seed bookkeeping)"
short = ("between tag v1.6.1 and commit a9b6b3e the Gaussian MI/CMI/TE/AIS leaf classes, MatrixUtils, MathsUtils and ChiSquareMeasurementDistribution are byte-identical, their MultiVariateCommon/Via parents differ only in observation-ID/noise-seed bookkeeping, "
         "and EntropyCalculatorMultiVariateGaussian was refactored onto EntropyCalculatorMultiVariateCommon with its value path unchanged; details in infotheory.est.gaussian)")
full = ("between tag v1.6.1 and commit a9b6b3e the Gaussian leaf classes MutualInfoCalculatorMultiVariateGaussian, ConditionalMutualInfoCalculatorMultiVariateGaussian, TransferEntropyCalculatorGaussian and ActiveInfoStorageCalculatorGaussian, "
        "plus MatrixUtils, MathsUtils and ChiSquareMeasurementDistribution, are byte-identical; their parents MutualInfoMultiVariateCommon, ConditionalMutualInfoMultiVariateCommon, TransferEntropyCalculatorViaCondMutualInfo and ActiveInfoStorageCalculatorViaMutualInfo "
        "differ only in observation-ID/noise-seed bookkeeping; EntropyCalculatorMultiVariateGaussian changed substantially (128 diff lines) because it was refactored onto the new EntropyCalculatorMultiVariateCommon "
        "(its own setObservations/initialise()/setProperty/getProperty/setDebug removed, finaliseAddObservations added in place of setObservations, isComputed caching of lastAverage added), "
        "while its value path covarianceMatrix -> CholeskyDecomposition -> 0.5*(d*(1+ln 2pi)+ln det) is unchanged)")
for name in ['infotheory.je.gaussian','infotheory.ce.gaussian','infotheory.cce.gaussian','infotheory.xme.gaussian_k1','infotheory.xme.gaussian_k10','infotheory.di.gaussian','infotheory.si.gaussian','infotheory.mi.gaussian','infotheory.tlmi.gaussian','infotheory.te.gaussian_auto-MAX_CORR_AIS_kmax-10_taumax-2','infotheory.te.gaussian_k-1_kt-1_l-1_lt-1','infotheory.te.symbolic']:
    sub(name, old, short)
sub('infotheory.est.gaussian', old, full)
sub('infotheory.est.gaussian',
    "The v1.6.1...a9b6b3e diff touches only bookkeeping (observation\n    IDs, NOISE_SEED) in the Gaussian MI/CMI/TE/AIS paths, and probes agree",
    "The v1.6.1...a9b6b3e diff touches only bookkeeping (observation\n    IDs, NOISE_SEED) in the Gaussian MI/CMI/TE/AIS paths (leaf classes byte-identical), refactors EntropyCalculatorMultiVariateGaussian onto EntropyCalculatorMultiVariateCommon without changing its covariance/Cholesky/log-det value path, and probes agree")

# 5. TE auto canonical_definition N
sub('infotheory.te.gaussian_auto-MAX_CORR_AIS_kmax-10_taumax-2',
    "of [I(Y^{(k,kt)}_t; Y_{t+1}) - k/(2N)] on the target",
    "of [I(Y^{(k,kt)}_t; Y_{t+1}) - k/(2N_{k,kt})], where N_{k,kt} = T - (k-1)*kt - 1 is that candidate's own sample count (ActiveInfoStorageCalculatorViaMutualInfo.java a9b6b3e :440-451; the chi-square mean uses the MI calculator's observation count), so candidates with different k are penalised on different N, on the target")
sub('infotheory.te.gaussian_auto-MAX_CORR_AIS_kmax-10_taumax-2',
    "penalised AIS(k,tau) = Gaussian MI(delay vector, next sample) - k/(2N) over k=1..10",
    "penalised AIS(k,tau) = Gaussian MI(delay vector, next sample) - k/(2N) with the per-candidate N = T-(k-1)*tau-1 over k=1..10")

# 6. te.symbolic candidate
sub('infotheory.te.symbolic',
    "  - 'CANDIDATE (elaboration of bug 1, metadata): the two te_symbolic identifiers are in the EEG selection; te_symbolic_k-1_kt-1_l-1_lt-1 is bitwise identical to gc_gaussian_k-1_kt-1_l-1_lt-1 (probe np.array_equal\n    True) and te_symbolic_k-10 is Gaussian TE with 10 target lags (not any other configured SPI). Instance labels carry",
    "  - 'CANDIDATE (metadata): both te_symbolic identifiers are in the EEG selection, and their instance labels carry")
sub('infotheory.te.symbolic',
    "already_documented: tests/README.md bug 1 (TransferEntropy(estimator='symbolic') falls through to the Gaussian calculator, te_symbolic_* == gc_gaussian_*)",
    "already_documented: tests/README.md bug 1 (TransferEntropy(estimator='symbolic') falls through to the Gaussian calculator, te_symbolic_* == gc_gaussian_*); the probes in deviation_from_documented (k-1 bitwise equal to gc_gaussian_k-1, k-10 = Gaussian TE with 10 target lags, which matches no other configured SPI) elaborate on it")

# 7. xme k10 sign candidate
sub('infotheory.xme.gaussian_k10',
    "\n  - 'CANDIDATE (sign): with 9 source lags and strong lagged coupling, the value is negative (differential entropy), contrary to the ''unsigned'' label (REVIEW M8 mechanism).'",
    "")
print('ok')
