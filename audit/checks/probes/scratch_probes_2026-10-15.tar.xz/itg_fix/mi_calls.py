import sys, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/tests'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks')
from regression import harness; harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
import make_data
x = make_data.load('iid_gaussian', 256)['x']
calls=[]
class Wrap:
    def __init__(s, c): s.c=c
    def __getattr__(s, n):
        a=getattr(s.c,n)
        if n=='computeAverageLocalOfObservations':
            def f(*a2): calls.append(n); return a(*a2)
            return f
        return a
for cls in (it.MutualInfo, it.JointEntropy):
    calls.clear()
    m = cls(estimator='gaussian')
    if cls is it.MutualInfo: m._calc = Wrap(m._calc)
    else: m._entropy_calc = Wrap(m._entropy_calc)
    A = m.multivariate(Data(x))
    print(cls.__name__, 'P', x.shape[0], 'JIDT compute calls', len(calls))
