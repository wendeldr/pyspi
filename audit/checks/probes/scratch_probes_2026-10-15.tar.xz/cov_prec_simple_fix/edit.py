import re
R = "/media/dan/Data/git/pyspi/audit/records/"
def sub(path, old, new, count=1):
    s = open(path).read()
    n = s.count(old)
    assert n == count, (path, old[:60], n)
    open(path, "w").write(s.replace(old, new))

stats = {  # from 76-file sweep (probe4.py / probe6.py)
 "EmpiricalCovariance": dict(coint="95.3", allmax="3042.8", f="trending_T4096", asym="5.7e-14", nasym=60, pr="-2.193", pc="+0.797"),
 "LedoitWolf": dict(coint="61.5", allmax="563.1", f="trending_T4096", asym="5.7e-14", nasym=49, pr="-2.061", pc="+0.786"),
 "OAS": dict(coint="49.1", allmax="341.9", f="trending_T4096", asym="5.7e-14", nasym=47, pr="-2.057", pc="+0.786"),
 "ShrunkCovariance": dict(coint="4.26", allmax="4.71", f="shared_envelope_T64", asym="8.9e-16", nasym=60, pr="-1.482", pc="+0.717"),
}
old_u = "unbounded (probe: up to 95.3 on cointegrated T=1024 for EmpiricalCovariance, 3042.8 max over all dataset files); sign opposite to the partial correlation; symmetric only up to last-bit roundoff (max |A-A^T| 5.7e-14 in probes)"
old_pc = "(trace probe on bivariate_gaussian T=1024: prec_EmpiricalCovariance[2,3] = -2.193 while the partial correlation is +0.797; cointegrated T=1024 max |prec| = 95.3)"
old_sym = "(trace probe: max |A - A.T| <= 5.7e-14 over the 76 dataset files, nonzero in most runs)"
old_corr = "'Candidate: on the default pipeline prec is the precision of the correlation matrix, not of the covariance: probe sparse_precision T=4096 kernel prec[0,1] = -0.393 (truth -0.4) vs pipeline prec[0,1] = -0.539.'"
new_corr = "'Scaling note (not a deviation from the documented definition, which says ''For normalized time-series data''; supplement §1.1.2, p.4): on the default z-scored pipeline prec is the inverse of the (shrunk) correlation matrix, scaled by T/(T-1), not the inverse of the raw-units covariance. Probe sparse_precision T=4096 (prec_EmpiricalCovariance): kernel path (normalise=False) prec[0,1] = -0.393 (dataset precision_true -0.4) vs pipeline prec[0,1] = -0.539; D Theta_kernel D [0,1] = -0.5392 with D = diag(sqrt(S_ii)), i.e. the pipeline value is the kernel precision rescaled by the channel standard deviations. Relevant to anyone comparing pipeline prec values with a known raw-units precision matrix.'"
for est, d in stats.items():
    p = R + f"basic.prec.{est}.yaml"
    sub(p, old_u, f"unbounded (76-file probe sweep, prec_{est}: max |off-diagonal| {d['coint']} on cointegrated T=1024, {d['allmax']} over all dataset files, at {d['f']}); sign opposite to the partial correlation; symmetric only up to last-bit roundoff (max |A-A^T| {d['asym']} over the 76 files, nonzero in {d['nasym']} of 76)")
    sub(p, old_pc, f"(trace probe on bivariate_gaussian T=1024: prec_{est}[2,3] = {d['pr']} while the partial correlation from the same matrix is {d['pc']}; cointegrated T=1024 max |prec_{est}| = {d['coint']})")
    sub(p, old_sym, f"(trace probe, prec_{est}: max |A - A.T| = {d['asym']} over the 76 dataset files, nonzero in {d['nasym']} of 76)")
    sub(p, old_corr, new_corr)

# OAS context
old_c = "Also sample-mean centring while Chen assumes known zero mean.'"
ctx = (" The omission is documented by sklearn itself: OAS class docstring (_shrunk_covariance.py:754-758, and oas() docstring :655-659) states the shrinkage ''differs from Eq. 23'' and that 2/p is dropped because ''for a large p'' it does not affect the estimator. scikit-learn 0.24.1 (the version named in supplement §1.1.1, p.4) computes the same num/den (0.24.1 sklearn/covariance/_shrunk_covariance.py:486-491, comment line 487 ''formula from Chen et al.''s **implementation**''; oas() docstring 466-467 ''slightly modified compared to the one given in the article''; OAS class docstring 508-512), so the documented pyspi version used this variant too. It is therefore a documented sklearn approximation, not a version change; it still departs from Eq. 23 by +14.5% (p=4) and +9.2% (p=5) relative in the shrinkage at T=64.'")
sub(R+"basic.cov.OAS.yaml", old_c, "Also sample-mean centring while Chen assumes known zero mean." + ctx)
old_pcan = "deviation_from_canonical: inverse of the sklearn-variant OAS estimate, which omits the 2/p terms of Chen et al. 2010 Eq. 23 (see cov unit); otherwise the canonical inverse"
sub(R+"basic.prec.OAS.yaml", old_pcan, "deviation_from_canonical: 'inverse of the sklearn-variant OAS estimate, which omits the 2/p terms of Chen et al. 2010 Eq. 23 (see cov unit; shrinkage +14.5% relative at p=4 T=64, +9.2% at p=5 T=64); otherwise the canonical inverse. sklearn documents the omission (_shrunk_covariance.py:754-758) and scikit-learn 0.24.1, the version named in the supplement, uses the same formula (0.24.1 _shrunk_covariance.py:486-491), so this is a documented upstream approximation rather than a version change.'")
old_cand = "Relative difference ~ 10-15% of the shrinkage at small p; whether this is an upstream defect or an accepted approximation is open (sklearn comment claims it ''does not impact the value of the estimator for large p'').'"
new_cand = "Relative difference +14.5% (p=4) and +9.2% (p=5) of the shrinkage. sklearn documents the omission in the OAS class docstring (_shrunk_covariance.py:754-758: it ''differs from Eq. 23'', 2/p is dropped because it is small ''for a large p''), and scikit-learn 0.24.1 (version named in supplement §1.1.1) used the same num/den (0.24.1 _shrunk_covariance.py:486-491, ''formula from Chen et al.''s **implementation**''). So this is a documented upstream approximation, unchanged since the documented version; the candidate is only that the large-p justification does not hold at small p.'"
for u in ("cov", "prec"):
    sub(R+f"basic.{u}.OAS.yaml", old_cand, new_cand)
print("ok")
