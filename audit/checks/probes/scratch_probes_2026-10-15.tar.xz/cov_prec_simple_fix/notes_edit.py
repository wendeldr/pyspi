P = "/media/dan/Data/git/pyspi/audit/notes/cov_prec_simple.md"
s = open(P).read()
def sub(old, new):
    global s
    assert s.count(old) == 1, old[:70]
    s = s.replace(old, new)
sub("""  - Whether to call this an upstream defect or an accepted approximation is still open.
""", """  - Relative to Eq. 23 the sklearn shrinkage is +14.5% (p=4) and +9.2% (p=5) at T=64.
  - sklearn documents the omission itself. The OAS class docstring (`_shrunk_covariance.py:754-758`) and the `oas()`
    docstring (`:655-659`) say the formula "differs from Eq. 23" and that 2/p is dropped because it is small "for a
    large p".
  - scikit-learn 0.24.1, the version named in supplement §1.1.1 (p.4), computes the same num/den
    (0.24.1 `sklearn/covariance/_shrunk_covariance.py:486-491`). The comment at line 487 reads "formula from Chen et
    al.'s **implementation**", the `oas()` docstring at 466-467 says "slightly modified compared to the one given in
    the article", and the class docstring at 508-512 describes the omitted 2/p. So the documented pyspi version
    computed the same value. This is a documented upstream approximation, not a version change. The remaining
    candidate is only that the "large p" justification does not hold at small p.
""")
sub("""  - cointegrated, T=1024: max |prec| = 95.3 (EmpiricalCovariance) and 61.5 (LW). The largest value over all dataset
    files is 3042.8.
  - On the pipeline the value is the precision of the *correlation* matrix. sparse_precision, T=4096: the kernel path
    gives -0.393 (truth -0.4) and the pipeline gives -0.539.
""", """  - cointegrated, T=1024: max |prec| = 95.3 (EmpiricalCovariance), 61.5 (LW), 49.1 (OAS) and 4.26 (Shrunk).
  - The largest value over all 76 dataset files differs by estimator: 3042.8 (EmpiricalCovariance), 563.1 (LW) and
    341.9 (OAS), all at trending_T4096, and 4.71 (Shrunk) at shared_envelope_T64.
- **Scaling note (not a deviation)**: the supplement's partial-correlation sentence is stated "For normalized
  time-series data", so the z-scoring is part of the documented definition. As a consequence, on the pipeline the
  value is the inverse of the (shrunk) correlation matrix times T/(T-1), not the inverse of the raw-units covariance.
  - sparse_precision, T=4096 (EmpiricalCovariance): the kernel path gives -0.393 (dataset precision_true -0.4) and the
    pipeline gives -0.539.
  - `D Θ_kernel D` with `D = diag(sqrt(S_ii))` gives -0.5392 for the same pair, so the pipeline value is the kernel
    precision rescaled by the channel standard deviations.
  - This matters only when pipeline values are compared with a known raw-units precision matrix.
""")
sub("""- **Symmetry**: equal only up to last-bit roundoff. The largest |A-Aᵀ| was 5.7e-14, nonzero in 47-60 of 76 files.
""", """- **Symmetry**: equal only up to last-bit roundoff. The largest |A-Aᵀ| over the 76 files was 5.7e-14 for
  EmpiricalCovariance, LW and OAS, and 8.9e-16 for Shrunk. It was nonzero in 60 (EmpiricalCovariance), 49 (LW),
  47 (OAS) and 60 (Shrunk) of the 76 files.
""")
sub("""1. OAS: should dropping Chen et al.'s 2/p terms count as a deviation (verdict `variant`), or as acceptable sklearn
   behaviour?""", """1. OAS: should dropping Chen et al.'s 2/p terms count as a deviation (verdict `variant`), or as acceptable sklearn
   behaviour? sklearn documents the omission, which favours treating it as a known approximation.""")
sub("""2. Did older scikit-learn (supplement: v0.24.1) use the same OAS formula? Not checked: the old source was not opened.
   This matters for comparability with historical pyspi outputs.
""", """2. Answered: scikit-learn 0.24.1 used the same OAS formula (0.24.1 `_shrunk_covariance.py:486-491`, same num/den
   with the 2/p terms omitted). The OAS shrinkage formula is therefore not a source of difference from historical
   pyspi outputs. Other version differences were not checked.
""")
open(P, "w").write(s); print("ok")
