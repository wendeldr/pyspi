PB = ("Confirmed, but it belongs to preproc.two_array_api (preprocessing_base family, already checked; run "
      "preproc.two_array_api|scaled_offset|256|pipeline|spi-dtw), so it is not a finding of this unit. Re-measured here on the direct-array API: ")
SYM_DTW = ("sym: max|A - A.T| = 0.0 on every pyspi matrix (mirrored by Undirected.multivariate); the unmirrored probe (Directed.multivariate, tslearn "
           "computes both orders) also gives max|B - B.T| = 0.0 at T=1024 on iid_gaussian and delayed_noise, so the function itself is argument-symmetric; diagonal NaN")
DIR_UND = ("undirected: A[i,j] = A[j,i] = f(z_i, z_j); on delayed_noise (x_k = x0 delayed by 0/1/3/5) the matrix carries no lead/lag sign, only "
           "how well warping absorbs the delay")

# ------------------------------------------------------------------ DTW
dtw_common_conv = ("tslearn's DTW is sqrt(min over warping paths of sum (x_i - y_j)^2) with weight-1 steps and no length normalisation. Sakoe & Chiba 1978 "
                   "(symmetric form, P = 0) uses |x_i - y_j| with diagonal weight 2 and divides by n + m. The two disagree in scale by a factor 24-62 and "
                   "in ranking (Spearman 0.71-0.96 over the 6 pairs of a dataset), so this is a value-changing convention rather than a constant factor.")

put("distance.dtw.constraint-None", dict(
 check_method="independent-impl",
 check_reference=(f"{REF}:matrix -> {K}:dtw_dp (anti-diagonal numpy DP, squared cost, sqrt); dtaidistance==2.5.1 dtw.distance (external package, C and "
                  f"pure-python paths); {K}:dtw_dp(squared_cost=False) for the Sakoe-Chiba 1978 form; {REF}:mc_null (Monte Carlo null, batched DP); "
                  f"analytic bounds in {REF}:handle('bounds')"),
 check_data="iid_gaussian, delayed_noise, narrowband_f0-0.25, logistic_maps (kernel, T 64/256/1024); iid_gaussian, delayed_noise, bivariate_gaussian, shared_envelope (pipeline T1024); scaled_offset T1024 (pipeline and kernel), trending T1024 (pipeline and pipeline-detrend); iid_gaussian T256/T1024 null; scaled_offset T256 raw-array call",
 agreement_criterion="exact: rtol 1e-10, atol 1e-12 on every ordered pair; dtaidistance tolerance rtol 1e-10; null: every pair within z_(1-0.025/m) Monte Carlo SD of the Monte Carlo mean; bounds: optimality flags",
 closeness=("All 16 dp runs (kernel T64/256/1024 on 4 datasets, pipeline T1024 on 4) agree with the from-scratch DP with max_abs 0.0 (bit-identical). "
            "dtaidistance (4 runs, iid_gaussian/delayed_noise T256/T1024) max_abs 0.0; dtaidistance C vs python path 0.0 at T256. "
            "Canonical 1978 form differs as expected: iid_gaussian T1024 pair (0,1) pyspi 22.50 vs 1978 form 0.417 vs |.|-cost weight-1 sum 623.8; "
            "pyspi/1978 ratio 23.96-55.18 across the 4 canon runs, Spearman 0.77-0.96. Bounds hold on every pair (dtw/||x-y|| 0.48-0.51 on iid, 0.084-0.122 on delayed_noise). "
            "Null (iid_gaussian): T256 mean over pairs 11.19 vs Monte Carlo 11.24 +- 0.31 (max_z 1.32); T1024 22.04 vs 21.84 +- 0.25 (max_z 1.51). "
            "scaled_offset pipeline vs z-scored bivariate_gaussian 3.6e-15; trending pipeline-detrend vs own detrend+z-score 4.6e-14."),
 verdict="variant",
 score_0_10=7,
 what_changed=(dtw_common_conv + " pyspi documents only 'computed with tslearn', so it matches the supplement variant (rubric 7). "
               "The value grows with T (null mean 11.2 at T256, 21.8 at T1024, about sqrt(T)). Without z-scoring the value scales with amplitude "
               "(scaled_offset kernel/z-scored ratio 3.0-15.5) and a linear trend changes it by up to 279% (trending pipeline without detrend). "
               "On z-scored noise it barely separates an anti-correlated pair from independent pairs (see candidate 1)."),
 new_finding=False,
 definition_under_review=True,
 check_cost="cheap: <= 0.1 s per pyspi run at T=1024 (numba); reference DP 0.27 s per pair at T=1024; all checks at T <= 1024",
 symmetry_observed=SYM_DTW,
 direction_observed=DIR_UND + ": dtw(z0, zk)/||z0 - zk|| = 0.084 / 0.098 / 0.104 for delays 1 / 3 / 5 (all delays absorbed).",
 candidate_resolutions=[
  dict(candidate="low discriminative range on z-scored noise: dtw barely separates independent from anti-correlated pairs", outcome="confirmed",
       evidence=("distance.dtw.constraint-None|iid_gaussian|1024|pipeline|null-neg: dtw(x,-x) 22.25 vs mean over independent pairs 22.09 (+0.7%; Euclidean gap +41.5%); "
                 "|256|pipeline|null-neg +2.7%; Monte Carlo null at T1024 21.84 +- 0.25 (|1024|pipeline|null), so the anti-correlated pair sits 1.6 null SD above the null mean. "
                 "This is a property of unconstrained DTW on noise, not a deviation of the code, so new_finding stays false.")),
  dict(candidate="parse_bivariate z-scores only the first of two raw arrays", outcome="confirmed",
       evidence=PB + "distance.dtw.constraint-None|scaled_offset|256|pipeline|rawcall: pyspi bivariate(x0, x1) 23.85 and bivariate(x1, x0) 13.44 equal f(zscore(first), raw second) exactly (max_abs 0.0); both z-scored 10.50."),
 ],
))

put("distance.dtw.constraint-itakura", dict(
 check_method="independent-impl",
 check_reference=(f"{REF}:matrix -> {K}:dtw_dp(constraint='itakura') (mask from {K}:itakura_mask, verified equal to {REF}:exact_itakura); "
                  f"{REF}:exact_itakura vs tslearn compute_mask (probe); {REF}:local_slope_dtw; {K}:dtw_dp(squared_cost=False); {REF}:mc_null"),
 check_data="iid_gaussian, delayed_noise, narrowband_f0-0.25, logistic_maps (kernel, T 64/256/1024); iid_gaussian, delayed_noise, bivariate_gaussian, shared_envelope (pipeline T1024); masks T 64/256/1024/4096; scaled_offset, trending T1024; iid_gaussian null T256/T1024",
 agreement_criterion="exact: rtol 1e-10, atol 1e-12; masks cell by cell (rtol 0); null: Bonferroni 2 se; optimality / qualitative flags",
 closeness=("All 16 dp runs bit-identical to the from-scratch masked DP (max_abs 0.0). tslearn's parallelogram equals the exact-integer parallelogram "
            "cell by cell at T 64/256/1024/4096 (n_cells_differ 0; 1366 / 21846 / 349526 / 5592406 cells, 1/3 of the grid). "
            "Bounds and nesting hold (dtw_None <= dtw_itakura <= ||x-y||). Local-slope rule inside the same parallelogram raises the value by a median 18% on iid_gaussian "
            "(T1024 range 17.7-19.6%) and 0.7-4.5% median on delayed_noise; pyspi <= local-slope value on every pair. "
            "Null T1024 22.11 vs Monte Carlo 21.99 +- 0.26 (max_z 1.16); T256 max_z 1.08. 1978 form: ratio 25.6-62.2, Spearman 0.71-0.95."),
 verdict="variant",
 score_0_10=7,
 what_changed=(dtw_common_conv + " The constraint is the global Itakura parallelogram (slope 2) only; Itakura's local slope rule is not applied, which lowers the "
               "value by about 15% (1 - 1/1.18) on independent noise relative to the local-rule DTW. Common 'Itakura window' practice; supplement variant (rubric 7)."),
 new_finding=False,
 definition_under_review=True,
 check_cost="cheap: <= 0.1 s per pyspi run at T=1024; mask probe at T=4096 < 1 s; all DTW checks at T <= 1024",
 symmetry_observed=SYM_DTW,
 direction_observed=DIR_UND + ": dtw/||z0 - zk|| = 0.090 / 0.098 / 0.123 for delays 1 / 3 / 5 (the parallelogram absorbs these delays).",
 candidate_resolutions=[
  dict(candidate="2-decimal rounding of the parallelogram bounds may admit/exclude boundary cells differently from exact arithmetic at large T", outcome="refuted",
       evidence=("distance.dtw.constraint-itakura|iid_gaussian|{64,256,1024,4096}|kernel|mask: n_cells_differ 0 at every T. For equal lengths and slope 2 every bound is a "
                 "multiple of 0.5 (k/2, 2k, 2k-(T-1), (T-1)/2+k/2), so rounding to 2 decimals is exact; unequal lengths (not used by pyspi) were not tested.")),
  dict(candidate="parse_bivariate z-scores only the first of two raw arrays", outcome="confirmed",
       evidence=PB + "the same parse decorator serves this identifier; measured value on the dtw identifier: distance.dtw.constraint-None|scaled_offset|256|pipeline|rawcall (23.85 / 13.44 vs 10.50 both z-scored)."),
 ],
))

put("distance.dtw.constraint-sakoe_chiba", dict(
 check_method="independent-impl",
 check_reference=(f"{REF}:matrix -> {K}:dtw_dp(constraint='sakoe_chiba', radius 1) (band verified equal to {REF}:exact_band); dtaidistance==2.5.1 dtw.distance(window=2); "
                  f"{REF}:exact_band vs tslearn compute_mask (probe); delayed_noise truth delays; {REF}:mc_null"),
 check_data="iid_gaussian, delayed_noise, narrowband_f0-0.25, logistic_maps (kernel, T 64/256/1024); pipeline T1024 on iid_gaussian, delayed_noise, bivariate_gaussian, shared_envelope; masks T 64/1024/4096; scaled_offset, trending T1024; null T256/T1024",
 agreement_criterion="exact: rtol 1e-10, atol 1e-12; dtaidistance rtol 1e-10; masks rtol 0; null Bonferroni 2 se; delay ratios qualitative (pre-stated thresholds 0.25 / 0.5)",
 closeness=("All 16 dp runs bit-identical (max_abs 0.0); dtaidistance window=2 equals tslearn radius 1 on 4 runs (max_abs 0.0; window=1 equals the Euclidean distance to 2e-14). "
            "tslearn band = |i-j| <= 1 exactly (190 / 3070 / 12286 cells at T 64/1024/4096 = 4.6% / 0.29% / 0.073% of the grid). "
            "delayed_noise T1024: dtw/||z0 - zk|| = 0.084 (delay 1), 0.724 (delay 3), 0.731 (delay 5). iid_gaussian T1024: dtw/Euclidean 0.70-0.74 (unconstrained 0.48-0.51). "
            "Null T1024 32.73 vs Monte Carlo 32.96 +- 0.73 (max_z 1.33). 1978 form ratio 24.4-50.6, Spearman 0.76-0.94."),
 verdict="variant",
 score_0_10=6,
 what_changed=(dtw_common_conv + " In addition the band radius is fixed at 1 sample at every T (tslearn default, pyspi passes no radius), an undocumented choice. "
               "Sakoe & Chiba treat r as a tuning parameter, usually a fraction of the length; with r = 1 the SPI absorbs at most a 1-sample shift and stays at "
               "70-74% of the lock-step Euclidean distance on noise, so it behaves as a slightly relaxed Euclidean distance (rubric 6: deviates from canonical practice "
               "and from what 'Sakoe-Chiba band' suggests in an interpretable way)."),
 new_finding=True,
 definition_under_review=True,
 check_cost="cheap: <= 0.1 s per pyspi run at T=1024; all checks at T <= 1024 except the T=4096 mask",
 symmetry_observed=SYM_DTW,
 direction_observed=DIR_UND + ": ratio 0.084 for delay 1 but 0.724 / 0.731 for delays 3 / 5: only the 1-sample delay is absorbed.",
 candidate_resolutions=[
  dict(candidate="the sakoe_chiba SPI is DTW with a 1-sample band at all T; delays > 1 sample cannot be absorbed", outcome="confirmed",
       evidence=("distance.dtw.constraint-sakoe_chiba|delayed_noise|1024|pipeline|delay (0.084 / 0.724 / 0.731); |iid_gaussian|{64,1024,4096}|kernel|mask (band |i-j| <= 1, n_cells_differ 0); "
                 "|iid_gaussian|1024|kernel|bounds (dtw/Euclidean 0.70-0.74). Not in KNOWN_ISSUES.")),
  dict(candidate="parse_bivariate z-scores only the first of two raw arrays", outcome="confirmed",
       evidence=PB + "measured on the dtw identifier: distance.dtw.constraint-None|scaled_offset|256|pipeline|rawcall (same decorator)."),
 ],
))

# ------------------------------------------------------------------ LCSS
lcss_low = dict(candidate="low dynamic range: eps = 1 on z-scored data saturates near 0.8 for unrelated series and does not separate anti-correlation from independence", outcome="confirmed",
       evidence=("distance.lcss.constraint-None|iid_gaussian|{64,256,1024}|pipeline|null: Monte Carlo null mean 0.788 / 0.803 / 0.810 (SD 0.021 / 0.0082 / 0.0037); "
                 "|1024|pipeline|null-neg: lcss(x,-x) 0.7988 vs independent 0.8105 (-1.4%; the Monte Carlo 1% quantile is 0.8018, so the anti-correlated pair is only just below it); "
                 "|256|pipeline|null-neg -1.0%; |bivariate_gaussian|1024|pipeline|range: rho 0.3 pair 0.8145 (z 1.3), rho 0.8 pair 0.9023 (z 25). The ordering is right but the range "
                 "on z-scored data is about [0.79, 1]; a property of the eps = 1 default, not a code deviation."))
lcss_pb = lambda val: dict(candidate="parse_bivariate z-scores only the first of two raw arrays", outcome="confirmed",
       evidence=PB + val)

put("distance.lcss.constraint-None", dict(
 check_method="independent-impl",
 check_reference=f"{REF}:matrix -> {K}:lcss_dp(eps=1, constraint=None, <= rule; strict=True variant); {REF}:mc_null (batched LCSS DP, checked against the kernel)",
 check_data="iid_gaussian, delayed_noise, narrowband_f0-0.25, logistic_maps (kernel T 64/256/1024); pipeline T1024 on iid_gaussian, delayed_noise, bivariate_gaussian, shared_envelope, logistic_maps; scaled_offset, trending T1024; iid_gaussian null T64/256/1024",
 agreement_criterion="exact: rtol 1e-10, atol 1e-12 (values are integers / T); null: Bonferroni 2 se; qualitative orderings",
 closeness=("All 17 dp runs bit-identical (max_abs 0.0). Strict '<' rule identical to '<=' on iid_gaussian T256/T1024 (kernel) and logistic_maps T1024 (pipeline) (max_abs 0.0). "
            "Null mean over pairs 0.792 / 0.804 / 0.812 vs Monte Carlo 0.788 / 0.803 / 0.810 (max_z 1.85 / 1.17 / 1.86). scaled_offset pipeline vs z-scored "
            "bivariate_gaussian max_abs 0.0; kernel path on raw scaled_offset 0.14-0.56 x the z-scored value."),
 verdict="matches",
 score_0_10=9,
 what_changed=("LCSS similarity of Vlachos et al. 2002 with delta = infinity, eps = 1 (documented), normalised by min(n, m) (their S1). Match test is <= eps instead of < eps "
               "(tie convention; identical on all test data). eps is absolute, i.e. 1 SD after z-scoring; without z-scoring (kernel path) the score depends on amplitude. "
               "A linear trend changes the value by up to 64% without detrend (0.24% after detrend)."),
 new_finding=False,
 definition_under_review=False,
 check_cost="cheap: <= 0.1 s per pyspi run at T=1024",
 symmetry_observed="sym: max|A - A.T| = 0.0 on every matrix; unmirrored probe (both orders computed by tslearn) max|B - B.T| = 0.0; diagonal NaN",
 direction_observed=DIR_UND + "; delayed_noise lcss(z0, zk) = 0.999 for every delay (unconstrained matching ignores time).",
 candidate_resolutions=[lcss_low, lcss_pb("distance.lcss.constraint-None|scaled_offset|256|pipeline|rawcall: bivariate(x0, x1) 0.613, bivariate(x1, x0) 0.793 equal f(zscore(first), raw second) exactly; both z-scored 0.809.")],
))

def lcss_con(unit, con, extra_close, torch_rid, n_fail, ex_rid, ex_vals, cands_extra):
    put(unit, dict(
     check_method="independent-impl",
     check_reference=(f"{REF}:matrix -> {K}:lcss_dp(constraint={con!r}) (masked LCSS, the documented quantity) and lcss_dp(constraint=None); "
                      f"tslearn torch backend (probe torch_lcss) vs the masked reference; same-lineage bit identity with the pyspi lcss matrix; {REF}:mc_null (masked)"),
     check_data="iid_gaussian, delayed_noise, narrowband_f0-0.25, logistic_maps (kernel T 64/256/1024); pipeline T1024 on iid_gaussian, delayed_noise, bivariate_gaussian, shared_envelope; delayed_noise T256 (torch); scaled_offset, trending T1024",
     agreement_criterion="exact: rtol 1e-10, atol 1e-12 vs the masked and unmasked references; bit identity (rtol 0) with lcss; null Bonferroni 2 se",
     closeness=(f"Against the masked (documented) LCSS: {n_fail} of 16 dp runs fail. {ex_rid}: {ex_vals}. Against unconstrained LCSS: 16/16 unmasked runs exact (max_abs 0.0), "
                f"and the pyspi matrix is bit-identical to pyspi lcss in all 6 'same' runs and in every dp run (pyspi_eq_unmasked = 1). "
                f"tslearn's torch backend equals the masked reference exactly ({torch_rid}, max_abs 0.0) and differs from the numpy value. " + extra_close),
     verdict="wrong",
     score_0_10=3,
     what_changed=(f"The {con} constraint named by the identifier is not applied: tslearn 0.9.0's numpy path gates cells with numpy.isfinite(mask[i-1, j-1]) "
                   "(dtw_variants.py:2259) on a boolean mask, which is always True, so the value equals unconstrained lcss exactly (rubric 3: identifier hyperparameter ignored). "
                   "The torch branch of the same library honours the mask, as does the from-scratch reference."),
     new_finding=True,
     definition_under_review=False,
     check_cost="cheap: <= 0.1 s per pyspi run at T=1024 (numpy path); torch probe 3.5-20 s at T=256",
     symmetry_observed="sym: max|A - A.T| = 0.0 on every matrix; unmirrored probe max|B - B.T| = 0.0 at T1024; diagonal NaN",
     direction_observed=DIR_UND + "; identical to lcss (0.999 for every delay on delayed_noise), the constraint would otherwise change this.",
     candidate_resolutions=[
      dict(candidate="tslearn 0.8.0-0.9.0 numpy LCSS ignores the boolean global-constraint mask (isfinite test)", outcome="confirmed",
           evidence=(f"{unit}|*|same (6 runs, bit_identical 1); {unit}|*|dp ({n_fail}/16 fail vs masked LCSS, pyspi_eq_unmasked 1 in all 16); {torch_rid} (torch backend = masked reference, max_abs 0.0). "
                     "Not in KNOWN_ISSUES. The tslearn release range (0.8.0-0.9.0) and the upstream fix rest on the trace-stage reading of the tags; only 0.9.0 was run here.")),
      lcss_low,
     ] + cands_extra + [lcss_pb("the same parse decorator serves this identifier; measured on lcss: distance.lcss.constraint-None|scaled_offset|256|pipeline|rawcall.")],
    ))

lcss_con("distance.lcss.constraint-itakura", "itakura",
         "Masked null (iid_gaussian T1024, distance.lcss.constraint-itakura|iid_gaussian|1024|pipeline|null-masked): Monte Carlo mean 0.449, SD 0.402, fraction exactly 0 = 0.445; the test passes only because this bimodal null is wide (max_z 0.66), while pyspi values are 0.804-0.819.",
         "distance.lcss.constraint-itakura|delayed_noise|256|pipeline|torch", 13,
         "distance.lcss.constraint-itakura|iid_gaussian|1024|pipeline|dp",
         "pyspi[0,1] 0.8037 vs masked reference 0.0 (max_abs 0.819, 18 of 20 ordered entries differ)",
         [dict(candidate="intended-behaviour degeneracy: the masked LCSS under tslearn's parallelogram is 0 whenever the final samples differ by more than eps", outcome="confirmed",
               evidence=("distance.lcss.constraint-itakura|iid_gaussian|1024|pipeline|null-masked: Monte Carlo fraction of exact zeros 0.445 over 400 independent z-scored pairs "
                         "(trace estimate 0.48); masked reference 0.0 on pairs of iid_gaussian T64/256/1024 and bivariate_gaussian / shared_envelope (dp runs, ref_01 = 0). "
                         "Relevant only if the mask is honoured."))])
lcss_con("distance.lcss.constraint-sakoe_chiba", "sakoe_chiba",
         "Masked null (iid_gaussian T1024): Monte Carlo mean 0.715 +- 0.009 vs pyspi 0.804-0.819 (distance.lcss.constraint-sakoe_chiba|iid_gaussian|1024|pipeline|null-masked fails, max_z 8.2).",
         "distance.lcss.constraint-sakoe_chiba|delayed_noise|256|pipeline|torch", 10,
         "distance.lcss.constraint-sakoe_chiba|delayed_noise|1024|pipeline|dp",
         "masked band-1 LCSS differs by up to 0.280 (max_rel 0.39) on the delay-3/5 pairs, iid_gaussian T1024 pipeline pair (0,1) 0.8037 vs 0.7061",
         [])

# ------------------------------------------------------------------ soft-DTW
put("distance.softdtw", dict(
 check_method="independent-impl",
 check_reference=(f"{REF}:matrix -> {K}:soft_dtw_dp (Cuturi & Blondel 2017 Alg. 1, direct (a-b)^2 cost, logsumexp softmin); {REF}:soft_dtw_masked (documented constrained "
                  f"variants); same-lineage bit identity of the constraint identifiers with softdtw; {K}:dtw_dp for the gamma -> 0 band; {REF}:mc_null"),
 check_data="iid_gaussian, delayed_noise, narrowband_f0-0.25, logistic_maps (kernel T 64/256/1024, all 3 identifiers); pipeline T1024 on iid_gaussian, delayed_noise, bivariate_gaussian, shared_envelope; iid_gaussian T256 (gamma probes, near-identical and +1e4 rows); scaled_offset, trending T1024; null T256/T1024",
 agreement_criterion="tolerance rtol 1e-10, atol 1e-10; bit identity (rtol 0) between identifiers; gamma probes rtol 1e-9 and the analytic band; null Bonferroni 2 se",
 closeness=("softdtw: 16/16 dp runs within max_abs 2.3e-13, max_rel 2.5e-14 of the from-scratch recursion; constraint identifiers vs unconstrained reference 8/8 (max_rel 4.8e-15). "
            "softdtw_constraint-itakura and -sakoe-chiba are bit-identical to softdtw in all 32 'ident' runs (kernel 4 datasets x 3 T, pipeline 4 datasets). "
            "Against the masked (documented) soft-DTW all 8 'masked' runs fail: itakura masked minus unconstrained 2.5-22.6, sakoe-chiba 57-1303 (iid_gaussian T1024: 676-848). "
            "gamma probes: tslearn vs reference max_rel 4.6e-15 (gamma 0.001) and 1.1e-14 (gamma 0.1); both inside the analytic band around dtw^2. "
            "Near-identical z-scored rows max_rel 3.1e-16; rows + 1e4 on the kernel path max_rel 1.0e-8 (fails the 1e-10 tolerance). "
            "Null T1024 -188.1 vs Monte Carlo -194.6 +- 13.6 (max_z 1.07); T256 max_z 1.43."),
 verdict="wrong",
 score_0_10=3,
 what_changed=("The softdtw identifier itself is Cuturi & Blondel's soft-DTW with gamma = 1 to about 1e-14 relative (as documented). The two constraint identifiers ignore "
               "their constraint (SoftDynamicTimeWarping.bivariate, distance.py:205-208, passes nothing), so they equal softdtw bit for bit: already documented as "
               "tests/README.md bug 3 (rubric 3 names this case). Separately, the raw soft-DTW value is reported, not the soft-DTW divergence: on z-scored data every value "
               "at T=1024 is negative (-454 to -174), sdtw(x,x) is about -712 to -718, and the ranking differs from the divergence (Spearman 0.44-0.60), so the 'unsigned' / "
               "'distance' labels do not describe the output (new: not in KNOWN_ISSUES)."),
 new_finding=True,
 definition_under_review=False,
 check_cost="cheap: <= 1.5 s per pyspi run at T=1024; reference 0.12 s per pair at T=1024",
 symmetry_observed=("sym after mirroring: max|A - A.T| = 0.0 on every pyspi matrix. tslearn itself is symmetric only to the last bits: the unmirrored probe gives "
                    "max|B - B.T| = 1.1e-13 at T1024 (iid_gaussian and delayed_noise), and the from-scratch reference 5.7e-14; diagonal NaN"),
 direction_observed=DIR_UND + "; values on delayed_noise T1024 -702 to -691.5 (closer to sdtw(x,x) about -714 than to the independent level about -190).",
 candidate_resolutions=[
  dict(candidate="pyspi reports the raw soft-DTW value (mostly negative, length-dominated), not the soft-DTW divergence", outcome="confirmed",
       evidence=("distance.softdtw|{iid_gaussian,bivariate_gaussian,delayed_noise}|1024|pipeline|div|softdtw: fraction of negative values 1.0, raw range -453.6 to -174.1, "
                 "self values mean -712 to -718, divergence 11-549 (>= 0), Spearman(raw, divergence) 0.44 / 0.60 / 0.49; |iid_gaussian|1024|pipeline|null-neg|softdtw: "
                 "sdtw(x,-x) -174.0 vs independent -186.4, within 1.5 SD of the Monte Carlo null (-194.6 +- 13.6). Not in KNOWN_ISSUES.")),
  dict(candidate="dot-product cost expansion adds an absolute error per cell; relative effect on the value < 1e-10 for z-scored data", outcome="confirmed",
       evidence=("distance.softdtw|iid_gaussian|256|pipeline|near|softdtw max_rel 3.1e-16 (no effect on z-scored data); |iid_gaussian|256|kernel|offset|softdtw (rows + 1e4, "
                 "normalise=False): max_abs 3.0e-7, max_rel 1.0e-8 vs the direct-difference reference. Minor; reachable only with normalisation off.")),
  dict(candidate="parse_bivariate z-scores only the first of two raw arrays", outcome="confirmed",
       evidence=PB + "distance.softdtw|scaled_offset|256|pipeline|rawcall|softdtw: bivariate(x0, x1) 478.3, bivariate(x1, x0) -118.8 equal f(zscore(first), raw second) (max_abs 5.7e-14); both z-scored -60.6."),
 ],
))
print("records written")
