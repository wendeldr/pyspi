import sys, time, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import make_data, _kernels_distance as K
from dtaidistance import dtw as ddtw
for T in (1024, 4096):
    x = make_data.load('iid_gaussian', T)['x']; z=(x-x.mean(1,keepdims=True))/x.std(1,ddof=1,keepdims=True)
    for name, f in [('dtw', lambda a,b: K.dtw_dp(a,b)), ('dtw_sc', lambda a,b: K.dtw_dp(a,b,'sakoe_chiba')),('lcss', lambda a,b: K.lcss_dp(a,b)),('sdtw', lambda a,b: K.soft_dtw_dp(a,b)), ('dtai', lambda a,b: ddtw.distance(a,b,use_c=False)), ('dtai_c', lambda a,b: ddtw.distance(a,b,use_c=True))]:
        if T==4096 and name in ('dtai',): continue
        t=time.perf_counter(); v=f(z[0],z[1]); print(T,name,round(time.perf_counter()-t,3), v)
