import sys, time
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np, make_data
from _kernels_distance import dtw_dp, lcss_dp, soft_dtw_dp, itakura_mask
x=make_data.load('delayed_noise',1024)['x']; z=(x-x.mean(1,keepdims=True))/x.std(1,ddof=1,keepdims=True)
for c in [None,'sakoe_chiba','itakura']:
    t=time.time(); r=[dtw_dp(z[0],z[k],c)/np.linalg.norm(z[0]-z[k]) for k in (1,2,3)]; print(c, np.round(r,3), time.time()-t)
t=time.time(); print(soft_dtw_dp(z[0],z[1]), time.time()-t)
t=time.time(); print(lcss_dp(z[0],z[1]), time.time()-t)
for T in (64,256,1024,4096):
    M=itakura_mask(T,T); i,j=np.indices((T,T)); E=(2*i>=j)&(i>=2*j-(T-1))&(i<=2*j)&(2*i<=(T-1)+j); print(T, (M!=E).sum(), M.sum()/T**2)
