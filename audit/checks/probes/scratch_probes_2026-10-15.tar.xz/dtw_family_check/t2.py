import numpy as np, torch, tslearn.metrics as tm, time
rng=np.random.default_rng(0); x=rng.standard_normal(256); y=np.roll(x,3)+0.1*rng.standard_normal(256)
for c in (None,'itakura','sakoe_chiba'):
    t=time.perf_counter()
    a=tm.lcss(torch.tensor(x[:,None]), torch.tensor(y[:,None]), global_constraint=c, be='pytorch')
    print(c, float(a), tm.lcss(x,y,global_constraint=c), time.perf_counter()-t)
print(tm.soft_dtw(x,y,gamma=1e-3), tm.dtw(x,y)**2)
