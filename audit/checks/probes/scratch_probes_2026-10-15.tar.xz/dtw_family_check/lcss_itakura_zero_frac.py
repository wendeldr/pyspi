"""Review item: masked (itakura) LCSS == 0 iff |z_x[T-1] - z_y[T-1]| > eps; analytic fraction 2(1 - Phi(1/sqrt 2))."""
import sys
sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0, '/media/dan/Data/git/pyspi/audit/checks/refs')
import numpy as np
from scipy.stats import norm
import _kernels_distance as K

def z(x):
    return (x - x.mean()) / x.std(ddof=1)

rng = np.random.default_rng(20261015)
T = 1024
agree = 0; nz = 0; N = 60
for _ in range(N):
    x, y = z(rng.standard_normal(T)), z(rng.standard_normal(T))
    v = K.lcss_dp(x, y, eps=1.0, constraint='itakura')
    pred_zero = abs(x[-1] - y[-1]) > 1.0
    agree += int((v == 0.0) == pred_zero); nz += int(v == 0.0)
print(f"T={T}: equivalence holds on {agree}/{N} pairs; zeros {nz}/{N}")
for T2 in (256,):
    a2 = 0
    for _ in range(N):
        x, y = z(rng.standard_normal(T2)), z(rng.standard_normal(T2))
        v = K.lcss_dp(x, y, eps=1.0, constraint='itakura')
        a2 += int((v == 0.0) == (abs(x[-1] - y[-1]) > 1.0))
    print(f"T={T2}: equivalence holds on {a2}/{N} pairs")
analytic = 2 * (1 - norm.cdf(1 / np.sqrt(2)))
M = 20000
X = rng.standard_normal((M, T)); Y = rng.standard_normal((M, T))
zx = (X[:, -1] - X.mean(1)) / X.std(1, ddof=1); zy = (Y[:, -1] - Y.mean(1)) / Y.std(1, ddof=1)
f = np.mean(np.abs(zx - zy) > 1.0)
print(f"analytic 2(1-Phi(1/sqrt2)) = {analytic:.4f}; MC over {M} z-scored pairs at T={T}: {f:.4f} (se {np.sqrt(f*(1-f)/M):.4f})")
print(f"400-pair MC se at p=analytic: {np.sqrt(analytic*(1-analytic)/400):.4f}; (0.445-analytic)/se = {(0.445-analytic)/np.sqrt(analytic*(1-analytic)/400):.2f}")
