import sys, time, numpy as np
sys.path.insert(0,'/media/dan/Data/git/pyspi/audit/checks'); sys.path.insert(0,'/media/dan/Data/git/pyspi/tests')
import make_data
from pyspi.data import Data
from pyspi.statistics.distance import DynamicTimeWarping, LongestCommonSubsequence, SoftDynamicTimeWarping
for T in (1024, 4096):
    x = make_data.load('iid_gaussian', T)['x']
    for cls in (DynamicTimeWarping, LongestCommonSubsequence, SoftDynamicTimeWarping):
        for gc in (None, 'itakura', 'sakoe_chiba'):
            s = cls(global_constraint=gc)
            t=time.perf_counter(); A = s.multivariate(Data(x.copy(), dim_order='ps')); dt=time.perf_counter()-t
            print(T, s.identifier, round(dt,3), A[0,1])
