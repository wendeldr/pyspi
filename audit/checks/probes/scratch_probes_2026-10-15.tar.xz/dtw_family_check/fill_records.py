"""Append the check-stage block to the seven dtw_family records (status traced -> checked)."""
import json, re
from collections import OrderedDict
import yaml

A = "/media/dan/Data/git/pyspi/audit"
R = json.load(open(f"{A}/checks/out/results/dtw_family.json"))
REF = "audit/checks/refs/dtw_family.py"
K = "audit/checks/refs/_kernels_distance.py"

TAGDESC = {
 "dp": (f"{REF}:matrix -> {K}:dtw_dp / lcss_dp / soft_dtw_dp (every ordered pair separately)", "exact rtol 1e-10 atol 1e-12 (soft-DTW tolerance rtol/atol 1e-10)"),
 "unmasked": (f"{REF}:matrix -> {K}:lcss_dp(constraint=None)", "exact"),
 "masked": (f"{REF}:soft_dtw_masked (documented constrained soft-DTW)", "tolerance 1e-10"),
 "ident": (f"{REF}:matrix on rows (x0, x0, x1) / same-lineage pyspi softdtw bit identity", "exact"),
 "same": ("pyspi lcss matrix (same-lineage bit identity)", "rtol 0 atol 0"),
 "unmirrored": (f"{REF}:matrix vs probes/dtw_family_probes.py:unmirrored (Directed.multivariate)", "exact"),
 "scaleinv": (f"{REF}:matrix on z-scored bivariate_gaussian", "exact"),
 "scaleinv-self": ("pyspi matrix on bivariate_gaussian (same-lineage)", "rtol 1e-10"),
 "scale-raw": (f"{REF}:matrix on raw scaled_offset rows", "exact"),
 "trend": (f"{REF}:matrix on z-scored trending rows", "exact"),
 "detrend": (f"{REF}:matrix on z-score(LS-detrend(trending))", "exact"),
 "canon": (f"{K}:dtw_dp(squared_cost=False) (Sakoe-Chiba 1978 symmetric form)", "tolerance rtol 1e-8 (expected to differ)"),
 "bounds": (f"{REF}:handle 'bounds' (analytic bounds + nesting)", "optimality"),
 "delay": (f"{REF}:handle 'delay' (delayed_noise truth delays 1/3/5)", "qualitative"),
 "dtai": ("dtaidistance==2.5.1 dtw.distance (window None / 2)", "tolerance rtol 1e-10"),
 "mask": (f"{REF}:exact_itakura / exact_band vs probes/dtw_family_probes.py:tslearn_mask", "exact, rtol 0"),
 "local-slope": (f"{REF}:local_slope_dtw", "qualitative"),
 "null": (f"{REF}:mc_null (400 independent z-scored Gaussian pairs, batched DP)", "statistical, Bonferroni 2 se"),
 "null-masked": (f"{REF}:mc_null (masked LCSS)", "statistical"),
 "null-neg": (f"{REF}:handle 'null-neg' (rows x0, -x0, x1, x2)", "qualitative"),
 "range": (f"{REF}:handle 'range' (bivariate_gaussian rho 0.3 / 0.8)", "qualitative"),
 "strict": (f"{K}:lcss_dp(strict=True)", "exact"),
 "torch": (f"{K}:lcss_dp(constraint) vs probes/dtw_family_probes.py:torch_lcss", "exact"),
 "div": (f"{REF}:handle 'div' (soft-DTW divergence from {K}:soft_dtw_dp)", "qualitative"),
 "gamma-0.001": (f"{K}:soft_dtw_dp(gamma=0.001) vs probes/dtw_family_probes.py:softdtw_gamma", "tolerance 1e-9"),
 "gamma-0.1": (f"{K}:soft_dtw_dp(gamma=0.1) vs probes/dtw_family_probes.py:softdtw_gamma", "tolerance 1e-9"),
 "gbound-0.001": (f"{REF}:handle 'gbound' (dtw^2 - g log3 (2T-1) <= sdtw <= dtw^2)", "optimality"),
 "gbound-0.1": (f"{REF}:handle 'gbound'", "optimality"),
 "near": (f"{K}:soft_dtw_dp on near-identical rows", "tolerance 1e-10"),
 "offset": (f"{K}:soft_dtw_dp on rows + 1e4 (kernel path)", "tolerance 1e-10"),
 "rawcall": (f"{REF}: f(zscore(first), raw second) vs probes/dtw_family_probes.py:raw_call", "exact"),
}

def fmt(x):
    return "%.3g" % x if isinstance(x, float) else str(x)

def checks_run(unit):
    groups = OrderedDict()
    for rid, v in R.items():
        if v["unit_id"] != unit:
            continue
        p = rid.split("|")
        key = p[4] + ("|" + p[5] if len(p) > 5 and p[4] in ("dp", "ident", "masked") else "")
        groups.setdefault(key, []).append(rid)
    out = []
    for key, rids in groups.items():
        tag = key.split("|")[0]
        npass = sum(bool(R[r]["pass"]) for r in rids)
        ma = [R[r].get("max_abs") for r in rids if isinstance(R[r].get("max_abs"), float)]
        mr = [R[r].get("max_rel") for r in rids if isinstance(R[r].get("max_rel"), float)]
        head = f"{npass}/{len(rids)} pass"
        if ma and tag not in ("null", "null-masked", "mask"):
            head += f"; max_abs <= {fmt(max(ma))}, max_rel <= {fmt(max(mr))}"
        if tag in ("null", "null-masked"):
            head += "; max_z " + ", ".join(fmt(R[r].get('max_z')) for r in rids)
        if tag == "mask":
            head += "; n_cells_differ " + ", ".join(str(R[r].get('ref_n_cells_differ')) for r in rids)
        desc, crit = TAGDESC[tag]
        out.append(OrderedDict(run_ids=sorted(rids), reference=f"{desc} [{crit}]",
                               outcome=("pass: " if npass == len(rids) else ("fail: " if npass == 0 else "mixed: ")) + head))
    return out

def g(rid, k):
    return R[rid][k]

def put(unit, block):
    path = f"{A}/records/{unit}.yaml"
    txt = open(path).read()
    assert "check_method" not in txt
    txt = txt.replace("status: traced", "status: checked", 1)
    block["checks_run"] = checks_run(unit)
    plain = json.loads(json.dumps(block))
    dumped = yaml.safe_dump(plain, sort_keys=False, width=150, allow_unicode=True, default_flow_style=False)
    dumped = "".join("  " + l + "\n" if l else "\n" for l in dumped.rstrip("\n").split("\n"))
    if not txt.endswith("\n"):
        txt += "\n"
    open(path, "w").write(txt + dumped)
    rec = yaml.safe_load(open(path).read())
    assert rec["status"] == "checked" and rec["correctness"]["verdict"] == block["verdict"]

exec(open(__file__.replace("fill_records.py", "blocks.py")).read())
