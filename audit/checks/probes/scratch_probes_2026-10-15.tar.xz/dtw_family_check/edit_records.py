import re
R='/media/dan/Data/git/pyspi/audit/records/'
def sub(path, pat, new, count=1):
    s=open(R+path).read()
    rx=re.compile(pat, re.S)
    n=len(rx.findall(s)); assert n==count, (path, pat, n)
    s=rx.sub(lambda m: new, s)
    open(R+path,'w').write(s)
W=r'\s+'
canon_pat = r"The two disagree in scale by a factor 24-62 and in ranking \(Spearman 0\.71-0\.96\s+over the 6 pairs of a dataset\)"
sub('distance.dtw.constraint-None.yaml', canon_pat,
    "On this unit's 4 canon runs the two disagree in scale by a factor 23.96-55.18 (pyspi / 1978 form) and in ranking (Spearman 0.77-0.96 over the 6 pairs of a dataset)")
sub('distance.dtw.constraint-itakura.yaml', canon_pat,
    "On this unit's 4 canon runs the two disagree in scale by a factor 25.6-62.2 (pyspi / 1978 form) and in ranking (Spearman 0.71-0.95 over the 6 pairs of a dataset)")
sub('distance.dtw.constraint-sakoe_chiba.yaml', canon_pat,
    "On this unit's 4 canon runs the two disagree in scale by a factor 24.4-51.1 (pyspi / 1978 form) and in ranking (Spearman 0.76-0.94 over the 6 pairs of a dataset)")
sub('distance.dtw.constraint-sakoe_chiba.yaml', r"1978 form ratio 24\.4-50\.6, Spearman 0\.76-0\.94\.",
    "1978 form (4 canon runs): ratio 24.4-51.1, Spearman 0.76-0.94.")
# itakura local slope
sub('distance.dtw.constraint-itakura.yaml',
    r"Local-slope rule inside the same parallelogram raises the value by a median 18% on iid_gaussian \(T1024 range 17\.7-19\.6%\) and 0\.7-4\.5% median\s+on delayed_noise; pyspi <= local-slope value on every pair\.",
    "A symmetric local-slope rule inside the same parallelogram (no two consecutive horizontal and no two consecutive vertical moves, weight-1 steps, local slopes 1/2..2 as in the Sakoe-Chiba P = 1 pattern but with horizontal-vertical corners allowed) raises the value by a median 18% on iid_gaussian (T1024 range 17.7-19.6%) and 0.7-4.5% median on delayed_noise; pyspi <= local-slope value on every pair. These gaps are specific to that rule: Itakura 1975's asymmetric local rule (reference index advancing 0/1/2 per test frame, no two consecutive 0 advances) is a different DP and was not computed.")
sub('distance.dtw.constraint-itakura.yaml',
    r"The constraint is the global Itakura parallelogram\s+\(slope 2\) only; Itakura's local slope rule is not applied, which lowers the value by about 15% \(1 - 1/1\.18\) on independent noise relative to the local-rule\s+DTW\.",
    "The constraint is the global Itakura parallelogram (slope 2) only; no local slope rule is applied inside it. Against one symmetric local rule (no two consecutive horizontal or vertical moves, slopes 1/2..2) the value is about 15% lower (1 - 1/1.18) on independent noise; that figure depends on the local rule chosen, and Itakura 1975's own asymmetric rule was not computed.")
# sakoe score rationale
sub('distance.dtw.constraint-sakoe_chiba.yaml',
    r"so it behaves as a slightly relaxed\s+Euclidean distance \(rubric 6: deviates from canonical practice and from what ''Sakoe-Chiba band'' suggests in an interpretable way\)\.'",
    "so it behaves as a slightly relaxed Euclidean distance. Documented statement the r = 1 band contradicts: the supplement (supplement.txt:283-286; GitBook distance-similarity.md:150) describes DTW as finding the minimum distance ''through alignment (shifting and dilating of the sequences)'' and adds the band ''to prevent pathological warpings''. With r = 1 the band also prevents ordinary shifts: delays of 3 and 5 samples keep dtw/||z0 - zk|| at 0.724 / 0.731 (distance.dtw.constraint-sakoe_chiba|delayed_noise|1024|pipeline|delay), against 0.098 / 0.123 under the itakura parallelogram on the same data (distance.dtw.constraint-itakura|delayed_noise|1024|pipeline|delay). The unit therefore deviates from the documented description as well as from canonical practice, in an interpretable way (rubric 6); the itakura unit (rubric 7) does perform the documented shifting.'")
# LCSS itakura
sub('distance.lcss.constraint-itakura.yaml',
    r"Monte Carlo mean 0\.449, SD 0\.402, fraction exactly 0 = 0\.445;",
    "Monte Carlo mean 0.449, SD 0.402, fraction exactly 0 = 0.445 over 400 pairs (an estimate, se about 0.025, of the analytic fraction 2(1 - Phi(1/sqrt 2)) = 0.4795);")
sub('distance.lcss.constraint-itakura.yaml',
    r"evidence: 'distance\.lcss\.constraint-itakura\|iid_gaussian\|1024\|pipeline\|null-masked: Monte Carlo fraction of exact zeros 0\.445 over 400 independent\s+z-scored\s+pairs \(trace estimate 0\.48\);",
    "evidence: 'Analytic: tslearn''s parallelogram admits only the corner cell in the last row and the last column, so the masked LCSS is 0 if and only if |z_x[T-1] - z_y[T-1]| > eps; for independent z-scored pairs the fraction is 2(1 - Phi(1/sqrt 2)) = 0.4795. Probe /tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad/dtw_family_check/lcss_itakura_zero_frac.py: the equivalence holds on 60/60 random pairs at T1024 and 60/60 at T256, and the final-sample criterion gives 0.484 (se 0.0035) over 20000 pairs at T1024. distance.lcss.constraint-itakura|iid_gaussian|1024|pipeline|null-masked: 400-pair Monte Carlo fraction of exact zeros 0.445 (se about 0.025, 1.4 se below 0.4795; trace estimate 0.48);")
