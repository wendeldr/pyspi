"""Writes audit/checks/manifest/dtw_family.json (dtw_family check stage)."""
import json
FAM = "dtw_family"
PROBES = "probes/dtw_family_probes.py"
runs = []

def add(unit, ident, ds, T, path, tag, probe=None, processes=None, suffix=None):
    rid = "|".join([unit, ds, str(T), path, tag] + ([suffix] if suffix else []))
    runs.append(dict(run_id=rid, unit_id=unit, identifier=ident, dataset=ds, T=T, path=path,
                     processes=processes, seed=42,
                     probe=None if probe is None else {"module": PROBES, "function": probe}))

KDS = ["iid_gaussian", "delayed_noise", "narrowband_f0-0.25", "logistic_maps"]
TS = [64, 256, 1024]
PDS = ["iid_gaussian", "delayed_noise", "bivariate_gaussian", "shared_envelope"]

def common(unit, ident, sfx=None):
    """Checks every unit gets (on its own identifier)."""
    for ds in KDS:
        for T in TS:
            add(unit, ident, ds, T, "kernel", "dp", suffix=sfx)
    for ds in PDS:
        add(unit, ident, ds, 1024, "pipeline", "dp", suffix=sfx)
    for ds in ["iid_gaussian", "delayed_noise"]:
        add(unit, ident, ds, 1024, "pipeline", "unmirrored", probe="unmirrored", suffix=sfx)
    add(unit, ident, "scaled_offset", 1024, "pipeline", "scaleinv", suffix=sfx)
    add(unit, ident, "scaled_offset", 1024, "pipeline", "scaleinv-self", suffix=sfx)
    add(unit, ident, "scaled_offset", 1024, "kernel", "scale-raw", suffix=sfx)
    add(unit, ident, "trending", 1024, "pipeline", "trend", suffix=sfx)
    add(unit, ident, "trending", 1024, "pipeline-detrend", "detrend", suffix=sfx)
    add(unit, ident, "iid_gaussian", 256, "pipeline", "ident", probe="derived_spi", suffix=sfx)

# ------------------------------------------------------------------ DTW
DTW = {"None": "dtw", "itakura": "dtw_constraint-itakura", "sakoe_chiba": "dtw_constraint-sakoe-chiba"}
for c, ident in DTW.items():
    u = f"distance.dtw.constraint-{c}"
    common(u, ident)
    for ds in ["iid_gaussian", "delayed_noise"]:
        for T in [256, 1024]:
            add(u, ident, ds, T, "kernel", "canon")
    for ds in ["iid_gaussian", "delayed_noise", "narrowband_f0-0.25"]:
        add(u, ident, ds, 1024, "kernel", "bounds")
    add(u, ident, "delayed_noise", 1024, "pipeline", "delay")
    for T in [256, 1024]:
        add(u, ident, "iid_gaussian", T, "pipeline", "null")
        add(u, ident, "iid_gaussian", T, "pipeline", "null-neg", probe="derived_spi")
    if c in ("None", "sakoe_chiba"):
        for ds in ["iid_gaussian", "delayed_noise"]:
            for T in [256, 1024]:
                add(u, ident, ds, T, "kernel", "dtai")
    if c == "itakura":
        for T in [64, 256, 1024, 4096]:
            add(u, None, "iid_gaussian", T, "kernel", "mask", probe="tslearn_mask")
        for ds in ["iid_gaussian", "delayed_noise"]:
            for T in [256, 1024]:
                add(u, ident, ds, T, "kernel", "local-slope")
    if c == "sakoe_chiba":
        for T in [64, 1024, 4096]:
            add(u, None, "iid_gaussian", T, "kernel", "mask", probe="tslearn_mask")
add("distance.dtw.constraint-None", "dtw", "scaled_offset", 256, "pipeline", "rawcall", probe="raw_call")

# ------------------------------------------------------------------ LCSS
LCSS = {"None": "lcss", "itakura": "lcss_constraint-itakura", "sakoe_chiba": "lcss_constraint-sakoe-chiba"}
for c, ident in LCSS.items():
    u = f"distance.lcss.constraint-{c}"
    common(u, ident)
    if c == "None":
        for T in [256, 1024]:
            add(u, ident, "iid_gaussian", T, "kernel", "strict")
        add(u, ident, "logistic_maps", 1024, "pipeline", "strict")
        add(u, ident, "logistic_maps", 1024, "pipeline", "dp")
        for T in [64, 256, 1024]:
            add(u, ident, "iid_gaussian", T, "pipeline", "null")
        for T in [256, 1024]:
            add(u, ident, "iid_gaussian", T, "pipeline", "null-neg", probe="derived_spi")
        add(u, ident, "bivariate_gaussian", 1024, "pipeline", "range")
        add(u, ident, "scaled_offset", 256, "pipeline", "rawcall", probe="raw_call")
    else:
        for ds in KDS:
            for T in TS:
                add(u, ident, ds, T, "kernel", "unmasked")
        for ds in PDS:
            add(u, ident, ds, 1024, "pipeline", "unmasked")
        for ds in ["iid_gaussian", "delayed_noise"]:
            add(u, ident, ds, 1024, "pipeline", "same")
            for T in [64, 256]:
                add(u, ident, ds, T, "kernel", "same")
        add(u, None, "delayed_noise", 256, "pipeline", "torch", probe="torch_lcss")
        add(u, ident, "iid_gaussian", 1024, "pipeline", "null-masked")

# ------------------------------------------------------------------ soft-DTW
U = "distance.softdtw"
SOFT = ["softdtw", "softdtw_constraint-itakura", "softdtw_constraint-sakoe-chiba"]
common(U, "softdtw", sfx="softdtw")
for ident in SOFT[1:]:
    for ds in KDS:
        for T in TS:
            add(U, ident, ds, T, "kernel", "ident", suffix=ident)
    for ds in PDS:
        add(U, ident, ds, 1024, "pipeline", "ident", suffix=ident)
    for ds in ["iid_gaussian", "delayed_noise"]:
        for T in [256, 1024]:
            add(U, ident, ds, T, "kernel", "dp", suffix=ident)
            add(U, ident, ds, T, "kernel", "masked", suffix=ident)
for T in [256, 1024]:
    add(U, "softdtw", "iid_gaussian", T, "pipeline", "null", suffix="softdtw")
    add(U, "softdtw", "iid_gaussian", T, "pipeline", "null-neg", probe="derived_spi", suffix="softdtw")
for ds in ["iid_gaussian", "bivariate_gaussian", "delayed_noise"]:
    add(U, "softdtw", ds, 1024, "pipeline", "div", suffix="softdtw")
for g in ["0.001", "0.1"]:
    add(U, None, "iid_gaussian", 256, "pipeline", f"gamma-{g}", probe="softdtw_gamma")
    add(U, None, "iid_gaussian", 256, "pipeline", f"gbound-{g}", probe="softdtw_gamma")
add(U, "softdtw", "iid_gaussian", 256, "pipeline", "near", probe="derived_spi", suffix="softdtw")
add(U, "softdtw", "iid_gaussian", 256, "kernel", "offset", probe="derived_spi", suffix="softdtw")
add(U, "softdtw", "scaled_offset", 256, "pipeline", "rawcall", probe="raw_call", suffix="softdtw")

ids = [r["run_id"] for r in runs]
assert len(ids) == len(set(ids)), "duplicate run_id"
json.dump({"family": FAM, "runs": runs}, open("/media/dan/Data/git/pyspi/audit/checks/manifest/dtw_family.json", "w"), indent=1)
print(len(runs))
