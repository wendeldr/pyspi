import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests'); sys.path.insert(0, sys.argv[1])
from regression import harness; harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
from scipy import integrate, stats
def load(n): return np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{n}.npz')['x']
eps = 0.5
f = lambda x: -stats.norm.pdf(x) * np.log2((stats.norm.cdf(x + eps) - stats.norm.cdf(x - eps)) / (2 * eps))
hlim = integrate.quad(f, -12, 12)[0]
print('box-kernel large-sample limit h_box(0.5) for N(0,1) = %.5f bits; true h = %.5f bits' % (hlim, 0.5 * np.log2(2 * np.pi * np.e)))
for T in (64, 256, 1024, 4096):
    x = load(f'iid_gaussian_T{T}')
    vals = {}
    for k, f in {'je': lambda: it.JointEntropy(estimator='kernel'),
                 'mi': lambda: it.MutualInfo(estimator='kernel', kernel_width=0.25),
                 'tlmi': lambda: it.TimeLaggedMutualInfo(estimator='kernel', kernel_width=0.25),
                 'te': lambda: it.TransferEntropy(estimator='kernel', kernel_width=0.25, k_history=1, l_history=1),
                 'si': lambda: it.StochasticInteraction(estimator='kernel'),
                 'xme1': lambda: it.CrossmapEntropy(estimator='kernel', history_length=1)}.items():
        A = f().multivariate(Data(x.copy(), dim_order='ps'))
        off = A[~np.eye(len(A), dtype=bool)]
        vals[k] = (off.mean(), off.min(), off.max())
    print(T, ' '.join(f"{k}: mean={v[0]:.3f} [{v[1]:.3f},{v[2]:.3f}]" for k, v in vals.items()), ' 2*h_box=%.3f' % (2 * hlim))
# bivariate gaussian MI vs truth
for T in (256, 4096):
    d = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/bivariate_gaussian_T{T}.npz')
    A = it.MutualInfo(estimator='kernel', kernel_width=0.25).multivariate(Data(d['x'].copy(), dim_order='ps'))
    print('bivariate_gaussian T', T, 'MI(0,1)=%.3f MI(2,3)=%.3f true bits=%s' % (A[0, 1], A[2, 3], np.round(d['true_mi_nats'] / np.log(2), 3)))
