import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
def load(n): return np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{n}.npz')['x']
x = load('nonlinear_dependence_T1024')
A = it.ConditionalEntropy(estimator='kernel').multivariate(Data(x.copy(), dim_order='ps')); print('ce nonlinear A[0,1]=H(x1|x0)=%.4f A[1,0]=H(x0|x1)=%.4f' % (A[0,1], A[1,0]))
A = it.MutualInfo(estimator='kernel', kernel_width=0.25).multivariate(Data(x.copy(), dim_order='ps')); print('mi nonlinear', np.round(A, 3))
for ds in ('logistic_maps_T1024', 'logistic_maps_T4096', 'var2_bivariate_T4096'):
    x = load(ds)
    A = it.TransferEntropy(estimator='kernel', kernel_width=0.25, k_history=1, l_history=1).multivariate(Data(x.copy(), dim_order='ps'))
    print('te', ds, 'A[0,1]=%.4f A[1,0]=%.4f' % (A[0,1], A[1,0]))
# FORCE_KERNEL_COMPARE_TO_ALL equivalence for TE / MI
import jpype as jp
x = load('var2_bivariate_T1024'); from scipy.stats import zscore; z = zscore(x, axis=1, ddof=1)
for force in ('false', 'true'):
    t = jp.JPackage('infodynamics.measures.continuous.kernel').TransferEntropyCalculatorKernel()
    t.setProperty('KERNEL_WIDTH', '0.25'); t.setProperty('k_HISTORY', '1'); t.setProperty('FORCE_KERNEL_COMPARE_TO_ALL', force); t.initialise()
    t.setObservations(jp.JArray(jp.JDouble, 1)(z[0]), jp.JArray(jp.JDouble, 1)(z[1])); print('TE force', force, repr(t.computeAverageLocalOfObservations()))
