import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests'); sys.path.insert(0, sys.argv[1])
from regression import harness; harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
import boxref as R
from scipy.stats import zscore
np.set_printoptions(precision=4, suppress=True, linewidth=150)
def load(n): return np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{n}.npz')['x']
mk = {
 'je': lambda: it.JointEntropy(estimator='kernel'),
 'ce': lambda: it.ConditionalEntropy(estimator='kernel'),
 'mi': lambda: it.MutualInfo(estimator='kernel', kernel_width=0.25),
 'tlmi': lambda: it.TimeLaggedMutualInfo(estimator='kernel', kernel_width=0.25),
 'te': lambda: it.TransferEntropy(estimator='kernel', kernel_width=0.25, k_history=1, l_history=1),
 'xme1': lambda: it.CrossmapEntropy(estimator='kernel', history_length=1),
 'xme10': lambda: it.CrossmapEntropy(estimator='kernel', history_length=10),
 'cce': lambda: it.CausalEntropy(estimator='kernel'),
 'di': lambda: it.DirectedInfo(estimator='kernel'),
 'si': lambda: it.StochasticInteraction(estimator='kernel'),
}
for ds in ['delayed_noise_T1024', 'var2_bivariate_T1024']:
    x = load(ds)
    print('=====', ds, '(delayed_noise: x0 leads x1 by 1; var2: x0 -> x1)')
    for k, f in mk.items():
        A = f().multivariate(Data(x.copy(), dim_order='ps'))
        print(k, 'A[0,1]=%.4f A[1,0]=%.4f  sym_exact=%s' % (A[0, 1], A[1, 0], np.array_equal(A, A.T, equal_nan=True)))
# CCE per-term collapse on iid data
print('===== CCE per-term on iid_gaussian (true each term = h(N(0,1)) = 2.047 bits)')
for T in (64, 256, 1024, 4096):
    x = load(f'iid_gaussian_T{T}'); z = zscore(x, axis=1, ddof=1); X, Y = z[0], z[1]
    terms = []
    for n in range(1, 6):
        Xp = np.column_stack([X[n - 1 - l: T - l] for l in range(n)])
        Z = Xp if n == 1 else np.column_stack([np.column_stack([Y[n - 1 - l: T - l] for l in range(1, n)]), Xp])
        terms.append(R.CE(Y[n - 1:], Z, 0.5))
    D = Data(x.copy(), dim_order='ps')
    di = it.DirectedInfo(estimator='kernel').bivariate(D, i=0, j=1)
    print(f"T={T}: terms={np.round(terms,3)} CCE={sum(terms):.3f} DI(pyspi)={di:.3f}")
# raw-array kernel path quirk: parse_bivariate z-scores only the first array
x = load('scaled_offset_T256')
s = it.JointEntropy(estimator='kernel')
a = s.bivariate(x[2], x[3]); b = s.bivariate(Data(x.copy(), dim_order='ps'), i=2, j=3)
print('je raw arrays', a, 'vs Data', b, 'diff', a - b, 'log2(std x3)=', np.log2(x[3].std(ddof=1)))
d = Data(); d.add_process(x[2]); d.add_process(x[3]); print('add_process stds:', d.to_numpy(squeeze=True).std(axis=1, ddof=1))
