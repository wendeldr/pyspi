"""From-scratch numpy box-kernel estimators (no JIDT), used only for read-only probes."""
import numpy as np
from scipy.stats import zscore

def _counts(X, w):
    # X (N,d), w (d,) half-widths; closed box |dx_d| <= w_d, self included
    X = np.asarray(X, float)
    N = X.shape[0]
    C = np.empty(N, dtype=np.int64)
    for b in range(N):
        C[b] = np.count_nonzero(np.all(np.abs(X - X[b]) <= w, axis=1))
    return C

def widths(X, eps):
    X = np.atleast_2d(np.asarray(X, float))
    if X.shape[0] == 1 and X.shape[1] > 1: X = X.T
    return eps * X.std(axis=0, ddof=1)

def H(X, eps):
    X = np.asarray(X, float)
    if X.ndim == 1: X = X[:, None]
    w = widths(X, eps)
    N = X.shape[0]
    C = _counts(X, w)
    vol = np.prod(2 * w)
    return -np.mean(np.log(C / N / vol)) / np.log(2)

def MI(x, y, eps):
    x = np.asarray(x, float).reshape(len(x), -1); y = np.asarray(y, float).reshape(len(y), -1)
    wx, wy = widths(x, eps), widths(y, eps)
    N = len(x)
    cx = _counts(x, wx); cy = _counts(y, wy); cxy = _counts(np.hstack([x, y]), np.concatenate([wx, wy]))
    return np.mean(np.log(N * cxy / (cx * cy))) / np.log(2)

def TE(src, dst, eps, k=1):
    src = np.asarray(src, float); dst = np.asarray(dst, float)
    T = len(dst)
    past = np.column_stack([dst[k - 1 - i: T - 1 - i] for i in range(k)])  # [y_{t-1},...,y_{t-k}]
    nxt = dst[k:]
    s = src[k - 1: T - 1]
    wp = eps * past.std(axis=0, ddof=1)
    ws = eps * s.std(ddof=1)
    wn = wp[0]
    te = 0.0
    for b in range(len(nxt)):
        mp = np.all(np.abs(past - past[b]) <= wp, axis=1)
        ms = np.abs(s - s[b]) <= ws
        mn = np.abs(nxt - nxt[b]) <= wn
        cp = mp.sum(); cps = (mp & ms).sum(); cnp = (mp & mn).sum(); cnps = (mp & ms & mn).sum()
        te += np.log((cnps / cps) / (cnp / cp))
    return te / len(nxt) / np.log(2)

def CE(Yf, Z, eps):
    return H(np.column_stack([Yf, Z]), eps) - H(Z, eps)
