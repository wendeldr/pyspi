import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests'); sys.path.insert(0, sys.argv[1])
from regression import harness; harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
import boxref as R
from scipy.stats import zscore
rng = np.random.default_rng(7)
def ar1(phi, T, rng):
    y = np.zeros(T + 500); e = rng.standard_normal(T + 500)
    for t in range(1, T + 500): y[t] = phi * y[t-1] + e[t]
    return y[500:]
def emb(v, m):
    T = len(v); return np.column_stack([v[m - 1 - l: T - l] for l in range(m)])
print('--- DI: X iid independent of Y; canonical DI(X->Y) = 0 ---')
for phi in (0.0, 0.5, 0.9):
    T = 1024
    x = rng.standard_normal(T); y = ar1(phi, T, rng)
    D = Data(np.vstack([x, y]), dim_order='ps')
    di = it.DirectedInfo(estimator='kernel').bivariate(D, i=0, j=1)
    cce = it.CausalEntropy(estimator='kernel').bivariate(Data(np.vstack([x, y]), dim_order='ps'), i=0, j=1)
    z = zscore(y, ddof=1)
    rates = sum(R.H(emb(z, n), 0.5) / n for n in range(1, 6))
    block = R.H(emb(z, 5), 0.5)
    gauss_bias_bits = -0.5 * sum(1.0 / i for i in range(2, 6)) * np.log2(1 - phi**2) if phi else 0.0
    print(f"phi={phi}: pyspi DI={di:.4f}  CCE={cce:.4f}  sum_i H(Y^i)/i={rates:.4f}  H(Y^5)={block:.4f}  'canonical' kernel DI=H(Y^5)-CCE={block-cce:.4f}  Gaussian-theory gap sum_i[H(Y^i)/i - H(Y_i|Y^(i-1))]={gauss_bias_bits:.4f} bits")
print('--- xme saturation: fraction of points whose box count is 1 (self only) ---')
for T in (256, 1024, 4096):
    x = rng.standard_normal(T); y = rng.standard_normal(T)
    z = zscore(x, ddof=1)
    for k in (1, 10):
        nl = max(1, k - 1)
        past = np.column_stack([z[k - l: T - l] for l in range(1, nl + 1)])
        joint = np.column_stack([past, zscore(y, ddof=1)[k:]])
        w = R.widths(joint, 0.5)
        C = R._counts(joint, w)
        Cp = R._counts(past, R.widths(past, 0.5))
        D = Data(np.vstack([x, y]), dim_order='ps')
        v = it.CrossmapEntropy(estimator='kernel', history_length=k).bivariate(D, i=0, j=1)
        print(f"T={T} k={k} dims(joint)={joint.shape[1]} frac C_joint==1: {np.mean(C==1):.3f} frac C_past==1: {np.mean(Cp==1):.3f}  xme={v:.4f}  log2(N)={np.log2(len(joint)):.3f}")
