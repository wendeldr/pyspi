import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness; harness.ensure_jvm()
import jpype as jp
import pyspi.statistics.infotheory  # noqa
K = jp.JPackage('infodynamics.measures.continuous.kernel')
# Library-level probe: absolute widths (NORMALISE=false) on an integer grid to expose ties
def ent(xs, w, force=False):
    c = K.EntropyCalculatorMultiVariateKernel()
    c.setProperty('NORMALISE', 'false')
    c.initialise(1, w)
    c.setObservations(jp.JArray(jp.JDouble, 1)(np.asarray(xs, float)))
    return c.computeAverageLocalOfObservations()
xs = [0., 1., 2., 3., 10.]
for w in (0.999999, 1.0, 1.000001):
    h = ent(xs, w)
    # implied counts: p = C/(N*2w) -> report mean log2 C
    print(f"w={w}: H={h:.12f}; mean log2 C = {np.log2(len(xs)*2*w) - h:.6f}")
# closed box (<=): counts at w=1 -> [2,3,3,2,1] ; open box (<): [1,1,1,1,1]
for name, C in [('closed', [2, 3, 3, 2, 1]), ('open', [1, 1, 1, 1, 1])]:
    print(name, 'expected H at w=1 =', -np.mean(np.log2(np.array(C) / (5 * 2.0))))
# self inclusion: an isolated point contributes C=1 (not 0 -> no -inf)
print('isolated-point entropy finite:', ent([0., 100.], 0.5))
# MI with ties
m = K.MutualInfoCalculatorMultiVariateKernel(); m.setProperty('NORMALISE', 'false'); m.initialise(1, 1, 1.0)
a = np.array([0., 1., 2., 3., 10.]); b = np.array([0., 1., 2., 3., 10.])
m.setObservations(jp.JArray(jp.JDouble, 1)(a), jp.JArray(jp.JDouble, 1)(b))
print('MI identical grid w=1:', m.computeAverageLocalOfObservations(), 'closed-box expected', np.mean(np.log2(5 * np.array([2, 3, 3, 2, 1]) / np.array([2, 3, 3, 2, 1])**2)))
