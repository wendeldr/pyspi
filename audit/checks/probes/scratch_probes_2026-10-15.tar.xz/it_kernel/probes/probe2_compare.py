import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests'); sys.path.insert(0, sys.argv[1])
from regression import harness; harness.ensure_jvm()
import pyspi.statistics.infotheory as it
from pyspi.data import Data
import boxref as R
from scipy.stats import zscore
ds = sys.argv[2] if len(sys.argv) > 2 else 'var2_bivariate_T256'
x = np.load(f'/media/dan/Data/git/pyspi/audit/checks/data/{ds}.npz')['x']
data = Data(x.copy(), dim_order='ps', normalise=True)
z = zscore(x, axis=1, ddof=1)
i, j = 0, 1
X, Y = z[i], z[j]
res = {}
def cmp(name, pyspi_val, ref_val):
    print(f"{name:10s} pyspi={pyspi_val:.15g} ref={ref_val:.15g} diff={pyspi_val-ref_val:.3e}")
s = it.JointEntropy(estimator='kernel'); cmp('je', s.bivariate(data, i=i, j=j), R.H(np.column_stack([X, Y]), 0.5))
s = it.ConditionalEntropy(estimator='kernel'); cmp('ce', s.bivariate(data, i=i, j=j), R.H(np.column_stack([X, Y]), 0.5) - R.H(X, 0.5))
s = it.MutualInfo(estimator='kernel', kernel_width=0.25); cmp('mi', s.bivariate(data, i=i, j=j), R.MI(X, Y, 0.25))
s = it.TimeLaggedMutualInfo(estimator='kernel', kernel_width=0.25); cmp('tlmi', s.bivariate(data, i=i, j=j), R.MI(X[:-1], Y[1:], 0.25))
s = it.TransferEntropy(estimator='kernel', kernel_width=0.25, k_history=1, l_history=1); cmp('te', s.bivariate(data, i=i, j=j), R.TE(X, Y, 0.25))
# xme
for k in (1, 2, 10):
    s = it.CrossmapEntropy(estimator='kernel', history_length=k)
    T = len(Y)
    # hypothesis: lags 1..max(1,k-1)
    nl = max(1, k - 1)
    past = np.column_stack([X[k - l: T - l] for l in range(1, nl + 1)])
    cmp(f'xme_k{k}', s.bivariate(data, i=i, j=j), R.CE(Y[k:], past, 0.5))
# si
s = it.StochasticInteraction(estimator='kernel')
XY = np.column_stack([X, Y])
ref = R.CE(X[1:], X[:-1], 0.5) + R.CE(Y[1:], Y[:-1], 0.5) - R.CE(XY[1:], XY[:-1], 0.5)
cmp('si', s.bivariate(data, i=i, j=j), ref)
# cce n=5 (hypothesis: sum_i H(y_t | y_{t-1..t-i+1}, x_{t..t-i+1}))
def emb(v, m, T):
    # rows aligned to t = m-1..T-1 ; [v_t, v_{t-1}, ..., v_{t-m+1}]
    return np.column_stack([v[m - 1 - l: T - l] for l in range(m)])
T = len(Y)
cce = 0.0
for n in range(1, 6):
    Xp = emb(X, n, T)                  # x_t..x_{t-n+1}, t=n-1..T-1
    if n > 1:
        Yp = np.column_stack([Y[n - 1 - l: T - l] for l in range(1, n)])  # y_{t-1}..y_{t-n+1}
        Z = np.column_stack([Yp, Xp])
    else:
        Z = Xp
    cce += R.CE(Y[n - 1:], Z, 0.5)
s = it.CausalEntropy(estimator='kernel'); cmp('cce', s.bivariate(Data(x.copy(), dim_order='ps'), i=i, j=j), cce)
er = sum(R.H(emb(Y, n, T), 0.5) / n for n in range(1, 6))
s = it.DirectedInfo(estimator='kernel'); cmp('di', s.bivariate(Data(x.copy(), dim_order='ps'), i=i, j=j), er - cce)
