import sys, numpy as np
sys.path.insert(0, '/media/dan/Data/git/pyspi/tests')
from regression import harness
print('jvm', harness.ensure_jvm())
import jpype as jp
import pyspi.statistics.infotheory as it
print('JIDT version manifest:')
import zipfile
z = zipfile.ZipFile('/media/dan/Data/git/pyspi/pyspi/lib/jidt/infodynamics.jar')
print([n for n in z.namelist() if 'MANIFEST' in n or n.lower().startswith('version')])
print(z.read('META-INF/MANIFEST.MF').decode()[:400])
spis = {
 'je': it.JointEntropy(estimator='kernel'),
 'ce': it.ConditionalEntropy(estimator='kernel'),
 'cce': it.CausalEntropy(estimator='kernel'),
 'xme1': it.CrossmapEntropy(estimator='kernel', history_length=1),
 'xme10': it.CrossmapEntropy(estimator='kernel', history_length=10),
 'di': it.DirectedInfo(estimator='kernel'),
 'si': it.StochasticInteraction(estimator='kernel'),
 'mi': it.MutualInfo(estimator='kernel', kernel_width=0.25),
 'tlmi': it.TimeLaggedMutualInfo(estimator='kernel', kernel_width=0.25),
 'te': it.TransferEntropy(estimator='kernel', kernel_width=0.25, k_history=1, l_history=1),
}
for k, s in spis.items():
    ec = s._entropy_calc
    line = f"{k:6s} id={s.identifier:28s} labels={s.labels} cls_mro={[c.__name__ for c in type(s).__mro__][:5]} entropyKW={ec.getProperty('KERNEL_WIDTH')} entNORM={ec.getProperty('NORMALISE')}"
    if hasattr(s, '_calc'):
        c = s._calc
        line += f" calc={c.getClass().getSimpleName()} KW={c.getProperty('KERNEL_WIDTH')} NORM={c.getProperty('NORMALISE')} DCE={c.getProperty('DYN_CORR_EXCL')}"
        try: line += f" k={c.getProperty('k_HISTORY')}"
        except Exception as e: pass
        try: line += f" noise={c.getProperty('NOISE_LEVEL_TO_ADD')}"
        except Exception as e: line += f" noiseprop-err"
    print(line)
# TE kernel: l_HISTORY etc rejected
te = spis['te']._calc
for prop in ['l_HISTORY', 'k_TAU', 'l_TAU', 'DELAY', 'AUTO_EMBED_METHOD', 'BIAS_CORRECTION', 'NOISE_SEED']:
    try:
        te.setProperty(prop, '2' if 'EMBED' not in prop else 'MAX_CORR_AIS'); print('TE setProperty', prop, 'accepted; getProperty ->', te.getProperty(prop))
    except Exception as e:
        print('TE setProperty', prop, 'raised', str(e)[:80])
# l_history passed to pyspi is silently dropped
t2 = it.TransferEntropy(estimator='kernel', kernel_width=0.25, k_history=1, l_history=3, l_tau=2, k_tau=4)
print('pyspi te with l_history=3,l_tau=2,k_tau=4 -> identifier', t2.identifier, 'k=', t2._calc.getProperty('k_HISTORY'))
# auto-embedding with kernel
t3 = it.TransferEntropy(estimator='kernel', kernel_width=0.25, auto_embed_method='MAX_CORR_AIS', k_search_max=4)
print('pyspi te kernel auto-embed -> identifier', t3.identifier, 'k=', t3._calc.getProperty('k_HISTORY'))
