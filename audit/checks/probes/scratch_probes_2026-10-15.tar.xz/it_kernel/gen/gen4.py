import sys
sys.path.insert(0, sys.argv[1])
from common import *
OUT = '/media/dan/Data/git/pyspi/audit/records/'
uid = 'infotheory.est.kernel'
c = dict(
 metric_name_standard="Box-kernel (fixed-radius, max-norm, 'step kernel') resubstitution density estimator used for differential entropy, MI and TE (JIDT kernel package), results in bits",
 canonical_ref="Kantz H, Schreiber T (1997) Nonlinear Time Series Analysis, CUP (correlation sum / box kernel p_r(x) = (1/N) sum_n Theta(r - ||x - x_n||_max)); Schreiber T (2000) PRL 85:461 (kernel TE); Ahmad IA, Lin P-E (1976) IEEE Trans IT 22:372 (resubstitution entropy estimator); Beirlant J, Dudewicz EJ, Gyorfi L, van der Meulen EC (1997) Int J Math Stat Sci 6:17 (review); Lizier JT (2014) Front Robot AI 1:11 (JIDT)",
 canonical_definition="p_hat(x_b) = C_b / (N * prod_d 2 r_d), C_b = #{t : |x_td - x_bd| <= r_d for all d}; H_hat = -(1/N) sum_b log p_hat(x_b); MI/TE as averages of log ratios of such densities (volumes cancel)",
 documented_definition=SUPP14 + "; supplement §1.4 also states 'We primarily use v1.5 of the Java Information Dynamics Toolkit [32]' while GitBook information-theory.md:11 says v1.6.1. DCE (Theiler window) is documented for KSG only.",
 delegate_lib="JIDT infodynamics.jar 1.6.1 (pyspi/lib/jidt/infodynamics.jar) via JPype: kernel.EntropyCalculatorMultiVariateKernel, kernel.MutualInfoCalculatorMultiVariateKernel, kernel.TransferEntropyCalculatorKernel, kernel.KernelEstimatorMultiVariate, kernel.KernelEstimatorTransferEntropy",
 implemented_as=("Preprocessing: Calculator z-scores every series (ddof=1). pyspi passes KERNEL_WIDTH = str(kernel_width) (0.5 for je/ce/cce/xme/di/si, 0.25 for mi/tlmi/te via config); JIDT keeps NORMALISE=true, so per dimension the half-width is "
     "w_d = width * sampleSD(column passed to JIDT) (n-1 divisor), recomputed for every sub-array (lagged/embedded columns are not exactly unit-SD). Counting: closed box (a point is excluded only if |dx_d| > w_d), max norm, the query point counts itself, "
     "no Theiler window (pyspi never sets DYN_CORR_EXCL for kernel), no added noise, no bias correction. Bins of width w_d with +-1 neighbour search, hash bins, or all-pairs comparison give identical integer counts. "
     "Entropy = -mean log2(C/(N*prod 2w_d)); MI = mean log2(N C_xy/(C_x C_y)); TE = mean log2((C_nps/C_ps)/(C_np/C_p)). pyspi properties BIAS_CORRECTION='false' and NOISE_SEED='42' are not recognised by these classes and have no effect. "
     "Caches on the Data object: data.entropy and data.joint_entropy keyed by ('kernel', width) shared by je/ce; data.causal_entropy keyed by ('kernel', width, n) shared by cce/di."),
 implementation_trace=PIPE + [UNDIR, PB,
   "pyspi/data.py:219-240 add_process: the first array goes through set_data (z-scored when normalise=True, :193-195); later arrays are appended raw (:230-234) - relevant to raw-array bivariate(x, y) calls"] + BASE + [
   "pyspi/statistics/infotheory.py:95-101 _getkey -> ('kernel', kernel_width)",
   "pyspi/statistics/infotheory.py:103-134 _getcalc: kernel.EntropyCalculatorMultiVariateKernel (:106), kernel.MutualInfoCalculatorMultiVariateKernel (:115), kernel.TransferEntropyCalculatorKernel (:126)",
   "pyspi/statistics/infotheory.py:137-193 _compute_entropy / _compute_joint_entropy / _compute_conditional_entropy (shared entropy building blocks and caches)",
   "pyspi/statistics/infotheory.py:195-220 _set_theiler_window: no-op unless dyn_corr_excl is set (never for kernel configs)",
   ] + JENT + [
   "JIDT v1.6.1 " + J + "measures/continuous/kernel/KernelEstimatorMultiVariate.java: getCountComparingToAll L764-800 (all-pairs path when N < 3^d or FORCE_KERNEL_COMPARE_TO_ALL); getBinIndex L819-829 (floor((v-min)/w), clamped to [0, bins-1]); addCount L868-950 (neighbour bins, stepKernel per candidate)",
   "JIDT v1.6.1 " + J + "measures/continuous/kernel/MutualInfoCalculatorMultiVariateKernel.java: computeAverageLocalOfObservations L178-200; normaliseData no-op L166-171",
   "JIDT v1.6.1 " + J + "measures/continuous/MutualInfoMultiVariateCommon.java: setProperty L201-229 (NOISE_LEVEL_TO_ADD default 0; unknown names such as NOISE_SEED/BIAS_CORRECTION ignored)",
   "JIDT v1.6.1 " + J + "measures/continuous/kernel/TransferEntropyCalculatorKernel.java: computeAverageLocalOfObservations L295-321; KernelEstimatorTransferEntropy.java correlatedPointAddedCallback L145-159",
   ],
 deviation_from_documented="'Width 0.5 standard deviations' is the half-width of a closed box (full side 1 SD). JIDT version: supplement says v1.5, jar and GitBook v1.6.1. Otherwise as documented.",
 deviation_from_canonical=("Matches the Kantz-Schreiber box kernel with r_d = width * sample SD and resubstitution (self-inclusive) counts. Not included: leave-one-out, Theiler window, bias correction (Grassberger digamma variant exists in JIDT TE for testing only). "
     "Consequences: positive small-sample bias for MI/TE/SI under independence and saturation of counts (C = 1) in >= 6 dimensions at W-0.5 for T <= 4096 (cce/di/xme_k10)."),
 units_and_range="bits throughout (ln / ln 2). Entropies with W-0.5 on unit-SD columns have box volume 1 and lie in [0, log2 N]; MI/TE are averages of log count ratios (finite because self-inclusion makes every count >= 1).",
 direction_convention="n/a (estimator); SPI-level conventions in each unit record. The estimator is invariant to the order of columns (max-norm counts), which makes je/mi/si exactly symmetric.",
 symmetry_expected="n/a",
 already_documented="no",
 new_finding_candidates=[
   "Candidate (closed box and self-inclusion established): library probe with NORMALISE=false on [0,1,2,3,10]: H(w=0.999999) = 3.321926652 (all counts 1), H(w=1.0) = 2.287943094599 = closed-box value -mean log2(C/(5*2)) with C = [2,3,3,2,1] (open box would give 3.321928); isolated points give finite entropy (H([0,100], w=0.5) = 1.0 bit, count 1 each). MI on the same grid = 1.2879430945989 = closed-box value. Source: stepKernel L961 uses '>' for exclusion; KernelEstimatorTransferEntropy L147/L153 use '<='.",
   "Candidate (SD convention): kernel half-widths use the n-1 sample SD of each array passed to JIDT (MatrixUtils.stdDev L2444); numpy references with ddof=1 reproduced pyspi to <= 2.3e-14 for all ten kernel SPIs (var2_bivariate T=256).",
   "Candidate (no-op properties): pyspi's BIAS_CORRECTION='false' and NOISE_SEED='42' (infotheory.py:90-91) are ignored by the kernel calculators (probe: TransferEntropyCalculatorKernel.getProperty returns None for both after setProperty); JIDT's kernel default width is 0.25 while JIDTBase's default is 0.5.",
   "Candidate (kernel-path preprocessing quirk, general to pyspi): bivariate(x, y) with raw arrays z-scores only the first array (data.py:226-238). Probe: Data().add_process(x2); add_process(x3) gives SDs [1.0, 9.8847] on scaled_offset T=256; JointEntropy differs from the Calculator value by exactly log2(SD(x3)) = 3.30519; MI/TLMI/TE are unaffected because box widths scale with each column's SD.",
   "Candidate (bin search equivalence): FORCE_KERNEL_COMPARE_TO_ALL true/false gave the identical TE 0.5768295209002822 on var2_bivariate T=1024 (z-scored), consistent with bins of width w and +-1 neighbour search being exact.",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "bivariate_gaussian", "var2_bivariate"], path="kernel",
        reference="from-scratch numpy box-kernel H (d = 1..10), MI (1+1) and Schreiber TE (k=1) with ddof=1 widths, closed boxes, self-inclusion, compared with direct JIDT calls at widths 0.25 and 0.5",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="Agreement to abs <= 1e-12 for all d and both widths; ddof=0 or open-box variants of the reference disagree (discriminates the convention)."),
   dict(datasets=["iid_gaussian"], path="kernel",
        reference="analytic tie grid: values [0,1,2,3,10] (and a 2-D product grid), NORMALISE=false, widths 1-1e-6, 1, 1+1e-6; closed-box counts [2,3,3,2,1] vs open-box [1,1,1,1,1]",
        reference_kind="analytic", criterion="exact",
        expected_outcome="JIDT reproduces the closed-box values exactly (H = 2.287943094598900 at w=1); self-inclusion visible as finite entropy for isolated points. Dataset only supplies the harness; the grid is synthetic."),
   dict(datasets=["iid_gaussian"], path="pipeline",
        reference="analytic large-sample limit h_box(eps) = -integral phi(x) log2[(Phi(x+eps)-Phi(x-eps))/(2 eps)] dx: 2.04935 bits (eps=0.5), 2.04725 bits (eps=0.25); true 2.04710",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="1-D kernel entropy of z-scored iid series approaches h_box from below with |error| < 0.02 bits at T=4096 for both widths."),
   dict(datasets=["var2_bivariate", "iid_gaussian"], path="kernel",
        reference="bin-path equivalence: FORCE_KERNEL_COMPARE_TO_ALL true vs false for entropy (d = 1..10), MI and TE",
        reference_kind="same-lineage", criterion="exact",
        expected_outcome="Bit-identical results (probe TE 0.5768295209002822 both ways)."),
   dict(datasets=["scaled_offset"], path="kernel",
        reference="raw-array call vs Data(normalise=True) call for JointEntropy, MutualInfo, TransferEntropy (kernel)",
        reference_kind="analytic", criterion="exact",
        expected_outcome="JE(raw) - JE(Data) = log2(std(x_j, ddof=1)) to 1e-12 (only the first array z-scored); MI and TE identical to 1e-12."),
 ])
dump(dict(unit_id=uid, status='traced', correctness=c), OUT + uid + '.yaml')
print('wrote', uid)
