import sys
sys.path.insert(0, sys.argv[1])
from common import *
OUT = '/media/dan/Data/git/pyspi/audit/records/'
BOXREF_H = ("from-scratch numpy box-kernel resubstitution entropy: per column w_d = 0.5*std(col, ddof=1); "
            "C_b = #{t : max_d |X_td - X_bd|/w_d <= 1} (self included); H = -mean(log2(C_b / (N * prod_d 2 w_d)))")
CCE_IMPL = ("CausalEntropy._compute_causal_entropy(src=z_i, targ=z_j) with n=5 (class default; config passes no n): for m = 1..5, Yp = makeDelayEmbeddingVector(targ, m-1)[:-1] "
    "(y_{t-1}..y_{t-m+1}; zero-width for m=1), Xp = makeDelayEmbeddingVector(src, m) (x_t..x_{t-m+1}, includes the CURRENT source value), Yf = y_t for t = m-1..T-1; "
    "term_m = H_kernel([Yf, Yp, Xp]) - H_kernel([Yp, Xp]) (2m-dimensional joint); CCE = sum of the 5 terms (a block quantity in bits, not a rate). "
    "Cached in data.causal_entropy[('kernel', 0.5, 5)][i,j] (shared with DirectedInfo).")
CCE_TRACE = [
   "pyspi/statistics/infotheory.py:429-437 CausalEntropy(JIDTBase, Directed).__init__(n=5)",
   "pyspi/statistics/infotheory.py:439-454 _compute_causal_entropy: loop m = 1..n; Yp = MatrixUtils.makeDelayEmbeddingVector(targ, m-1)[:-1]; Xp = makeDelayEmbeddingVector(src, m); XYp = concat([Yp, Xp]); Yf = targ[m-1:]; += _compute_conditional_entropy(Yf, XYp)",
   CONDENT,
   "pyspi/statistics/infotheory.py:456-474 _getkey adds n; bivariate caches data.causal_entropy[key][i,j] (src = z[i], targ = z[j])",
   EMB,
]
recs = {}

recs['infotheory.cce.kernel'] = dict(
 metric_name_standard="Causally conditioned entropy H(Y^n || X^n) of target j given source i over a block of n = 5 samples (Kramer), box-kernel plug-in under stationarity, bits",
 canonical_ref="Kramer G (1998) Directed Information for Channels with Feedback, PhD thesis ETH Zurich (Hartung-Gorre), Def. of causally conditioned entropy H(Y^N||X^N) = sum_{n=1}^N H(Y_n | Y^{n-1}, X^n); Massey JL (1990) Proc. ISITA 'Causality, feedback and directed information'; Quinn CJ, Coleman TP, Kiyavash N, Hatsopoulos NG (2011) J Comput Neurosci 30:17-44",
 canonical_definition="H(Y^n || X^n) = sum_{m=1}^{n} H(Y_m | Y^{m-1}, X^m), where X^m includes the current X_m; under stationarity term m = H(Y_t | Y_{t-1..t-m+1}, X_{t..t-m+1})",
 documented_definition=("supplement §1.4.7, p.11 (pack lines 524-536): 'Causally conditioned entropy [42-44] aims to measure the uncertainty remaining in time series y in the context of the entire (causal) past of both time series x and y. "
     "The measure is computed as a sum of conditional entropies (of y given both the past of x and the past of y) with increasing history lengths ... for computational reasons, we restrict the history length to 10. This corresponds to the assumption that the joint process is, at maximum, a 10th-order Markov chain.' "
     "identifier 84 cce_kernel_W-0.5; keywords directed, nonlinear, unsigned, bivariate, time-dependent. GitBook information-theory.md:24-42 same text."),
 delegate_lib="JIDT infodynamics.jar 1.6.1: EntropyCalculatorMultiVariateKernel (up to 10-D) and infodynamics.utils.MatrixUtils.makeDelayEmbeddingVector, combined in pyspi",
 implemented_as=CCE_IMPL + " Kernel: half-width 0.5*sampleSD per column, closed max-norm box, self-included; joint dimension 2m up to 10.",
 implementation_trace=PIPE + [PB] + BASE + [GETENT, "pyspi/config.yaml:425-437 CausalEntropy configs (estimator only; n not set)"] + CCE_TRACE + JENT,
 deviation_from_documented=("(1) History length: documented 10, code n=5 (infotheory.py:435; config passes no n). (2) The documented 'past of x' is implemented as x_t..x_{t-m+1}, i.e. it includes the current source sample "
     "(this matches Kramer's definition, not the prose). (3) 'Width 0.5 SD' is the box half-width."),
 deviation_from_canonical=("Formula matches Kramer's H(Y^n||X^n) for n=5 under stationarity (each term estimated on its own T-m+1 samples). Estimator: with 0.5-SD boxes in 2m <= 10 dimensions the counts collapse to 1 "
     "for most points at T <= 4096, so the high-order terms are driven to ~0 and the sum is heavily underestimated (probe iid_gaussian, truth 5*2.047 = 10.24 bits: per-term [2.039, 1.934, 1.232, 0.277, 0.024] = 5.51 at T=4096; 2.22, 3.42, 4.50 at T=64, 256, 1024)."),
 units_and_range="bits; sum of 5 kernel conditional entropies; individual high-order terms can be slightly negative (observed -0.033); total positive, strongly T-dependent; asymmetric; finite.",
 direction_convention="A[i,j] = H(X_j^5 || X_i^5): row i = conditioning (source), column j = target. Lower = more of j explained causally by i. Probe delayed_noise T=1024: A[0,1] = 2.405 (x0 drives x1) vs A[1,0] = 7.169.",
 symmetry_expected="asym",
 already_documented="no",
 new_finding_candidates=[
   "Candidate (documented parameter): supplement §1.4.7 and GitBook state a history length of 10; the code uses n=5 (CausalEntropy.__init__(n=5), infotheory.py:435; config.yaml:425-437 sets only the estimator). Evidence: numpy reference summing exactly 5 terms matched pyspi to 8.9e-16 (var2_bivariate T=256: 3.42173375502882).",
   "Candidate (estimator collapse): kernel CCE terms of order m >= 3 are near 0 at practical T because 0.5-SD boxes in 6-10 dimensions contain only the query point; probe iid_gaussian per-term at T=1024 [2.012, 1.702, 0.675, 0.099, 0.012] vs truth 2.047 each, so cce_kernel_W-0.5 mostly reflects the m=1,2 terms and T.",
   "Candidate (robustness): the m=1 term relies on MatrixUtils.makeDelayEmbeddingVector(targ, 0), which returns T+1 zero-width rows that pyspi slices to T and concatenates (infotheory.py:448-450); it works (probe match) but depends on JIDT accepting k=0.",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "delayed_noise", "var2_bivariate", "gauss_ar1_pair", "logistic_maps"], path="pipeline",
        reference=BOXREF_H + "; CCE = sum_{m=1..5} [H([y_t, y_{t-1..t-m+1}, x_{t..t-m+1}]) - H([y_{t-1..t-m+1}, x_{t..t-m+1}])], each on t = m-1..T-1",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="All off-diagonal entries agree to abs <= 1e-12 (probe 8.9e-16)."),
   dict(datasets=["iid_gaussian"], path="pipeline",
        reference="analytic truth for independent white Gaussian pairs: H(Y^5||X^5) = 5*h(N(0,1)) = 10.235 bits; per-term truth 2.047",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="Large underestimate decreasing slowly with T (probe 2.22, 3.42, 4.50, 5.51 bits at T=64..4096); per-term values for m >= 3 far below 2.047 (documents collapse)."),
   dict(datasets=["delayed_noise", "var2_bivariate"], path="pipeline",
        reference="ground-truth coupling direction (x0 -> x1)",
        reference_kind="analytic", criterion="direction",
        expected_outcome="Direction convention A[i,j] = H(X_j || X_i): A[0,1] < A[1,0] (probe delayed_noise 2.405 < 7.169; var2_bivariate 4.384 < 4.659)."),
   dict(datasets=["gauss_ar1_pair", "var2_bivariate"], path="pipeline",
        reference="analytic Gaussian H(Y^5||X^5) from the stationary autocovariance (block covariance of [y, x] lags 0..4; sum of Gaussian conditional entropies), and the from-scratch box-kernel value with n=10 to quantify the documented-vs-code history length",
        reference_kind="analytic", criterion="qualitative",
        expected_outcome="Kernel value well below the Gaussian value (collapse); n=10 variant even lower or comparable (terms m > 5 ~ 0), showing the documented n=10 would not be estimable at W-0.5."),
 ])

recs['infotheory.di.kernel'] = dict(
 metric_name_standard="Directed information I(X^n -> Y^n) from source i to target j (Massey), n = 5, box-kernel plug-in, bits (pyspi variant of the H(Y^n) term)",
 canonical_ref="Massey JL (1990) 'Causality, feedback and directed information', Proc. ISITA, Eq. I(X^N -> Y^N) = sum_n I(X^n; Y_n | Y^{n-1}) = H(Y^N) - H(Y^N || X^N); Kramer G (1998) PhD thesis ETH; Quinn et al. (2011) J Comput Neurosci 30:17; Amblard P-O, Michel OJJ (2011) J Comput Neurosci 30:7",
 canonical_definition="I(X^n -> Y^n) = H(Y^n) - H(Y^n || X^n), with H(Y^n) = sum_{m=1}^n H(Y_m | Y^{m-1}) (block entropy of n consecutive target samples); >= 0; = 0 when X does not influence Y causally (incl. contemporaneously)",
 documented_definition=("supplement §1.4.8, p.11 (pack lines 537-550): 'Directed information [42, 45] is a measure of information flow from a source time series x to a target time series y that is related to transfer entropy, but has no time lag between source and target [46, App. C]. "
     "The directed information can be computed as a difference between the conditional entropy of y given its own past, and causally conditioned entropy [42-44]. For the same reasons as for causally conditioned entropy, we restrict its computation up to a history length of 10.' "
     "identifier 87 di_kernel_W-0.5. GitBook information-theory.md:68-86 same text."),
 delegate_lib="JIDT infodynamics.jar 1.6.1: EntropyCalculatorMultiVariateKernel and MatrixUtils.makeDelayEmbeddingVector, combined in pyspi",
 implemented_as=("DI(i,j) = R - CCE(i,j) with R = sum_{m=1}^{5} H_kernel(Y^m)/m, where Y^m = makeDelayEmbeddingVector(z_j, m) (T-m+1 rows of m consecutive target samples) "
     "and CCE as in infotheory.cce.kernel (n=5, cache shared). R is a sum of per-symbol block entropies, NOT the block entropy H(Y^5) = sum_m H(Y_m|Y^{m-1}); the two coincide only for an i.i.d. target. Kernel half-width 0.5*sampleSD, closed box, self-included."),
 implementation_trace=PIPE + [PB] + BASE + [GETENT, "pyspi/config.yaml:466-478 DirectedInfo configs (estimator only)",
   "pyspi/statistics/infotheory.py:477-485 DirectedInfo(CausalEntropy, Directed).__init__(n=5)",
   "pyspi/statistics/infotheory.py:487-501 _compute_entropy_rates(targ): for m = 1..n: initialise(m); setObservations(makeDelayEmbeddingVector(targ, m)); sum += computeAverageLocalOfObservations() / m",
   "pyspi/statistics/infotheory.py:503-510 bivariate: entropy_rates(z_j) - CausalEntropy.bivariate(data, i, j)"] + CCE_TRACE + JENT,
 deviation_from_documented=("(1) History length 5, not the documented 10 (infotheory.py:483). (2) The documented first term 'conditional entropy of y given its own past' (summed over histories = H(Y^n)) is implemented as sum_m H(Y^m)/m. "
     "(3) The documented 'no time lag between source and target' matches the inclusion of x_t in the CCE terms."),
 deviation_from_canonical=("(a) Definition: sum_m H(Y^m)/m - H(Y^5||X^5) instead of H(Y^5) - H(Y^5||X^5). For a stationary Gaussian AR(1) target with coefficient phi the gap is "
     "-0.5*(1/2+1/3+1/4+1/5)*log2(1-phi^2) = -0.6417*log2(1-phi^2) bits (0.266 bits at phi=0.5, 1.537 at phi=0.9), positive for any autocorrelated target, so DI > 0 even when X has no influence; this is estimator-independent "
     "(applies equally to di_gaussian and di_kozachenko). (b) Estimator: kernel CCE collapses in up to 10-D (see infotheory.cce.kernel) while R collapses less, so DI(iid, independent) = 5.66/5.85/5.27/4.58 bits at T=64/256/1024/4096 (probe) vs canonical 0."),
 units_and_range="bits; difference of kernel entropy sums; large positive values under independence (probe ~4.6-5.8 bits); could be negative in principle; asymmetric; finite.",
 direction_convention="A[i,j] = DI(X_i -> X_j): row i = source, column j = target. Probe delayed_noise T=1024: A[0,1] = 7.419 > A[1,0] = 2.647; var2_bivariate T=1024: 5.199 > 4.860.",
 symmetry_expected="asym",
 already_documented="no",
 new_finding_candidates=[
   "Candidate (definition, estimator-independent): the target-entropy term is sum_{m=1}^{5} H(Y^m)/m (infotheory.py:493-499) rather than H(Y^5); for an autocorrelated target this adds a positive bias. Evidence: numpy reference R - CCE matched pyspi to 8.9e-16 (var2_bivariate T=256: 5.68877450775659); Gaussian AR(1) theory gap -0.6417*log2(1-phi^2) bits (1.537 bits at phi=0.9); kernel probe with X independent of an AR(1) Y at T=1024: sum_m H(Y^m)/m - H(Y^5) = 0.79, 0.83, 1.34 bits for phi = 0, 0.5, 0.9.",
   "Candidate (documented parameter): history length 5 in code vs 10 in supplement §1.4.8 / GitBook (infotheory.py:483).",
   "Candidate (degenerate magnitude): with the kernel estimator DI between independent white-noise series is 4.6-5.8 bits for T = 64..4096 (probe iid_gaussian pair (0,1): 5.659, 5.848, 5.272, 4.584), dominating any real effect; direction ordering is still correct on delayed_noise.",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "delayed_noise", "var2_bivariate", "gauss_ar1_pair"], path="pipeline",
        reference=BOXREF_H + "; R = sum_{m=1..5} H(Y^m)/m with Y^m rows [y_t..y_{t-m+1}], t = m-1..T-1; DI = R - CCE (CCE reference of infotheory.cce.kernel)",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="All off-diagonal entries agree to abs <= 1e-12 (probe 8.9e-16)."),
   dict(datasets=["var2_bivariate", "gauss_ar1_pair"], path="kernel",
        reference="analytic Gaussian gap between pyspi's target term and H(Y^5): sum_m (1/m) 0.5 log2 det(2 pi e R_m) - 0.5 log2 det(2 pi e R_5), R_m = m x m Toeplitz autocorrelation of the target computed from the generating VAR (var2_bivariate process 0 is an AR(2) unaffected by process 1)",
        reference_kind="analytic", criterion="tolerance",
        expected_outcome="From-scratch Gaussian plug-in of both forms on the T=4096 data reproduces the analytic gap within 0.05 bits; the gap is > 0 and equals the pyspi-vs-canonical difference for the Gaussian estimator (definition finding independent of the kernel)."),
   dict(datasets=["iid_gaussian"], path="pipeline",
        reference="analytic truth DI = 0 for independent white noise",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="pyspi values far from 0 (probe 4.6-5.8 bits at all T); canonical-form box-kernel reference H(Y^5) - CCE also far from 0 (estimator collapse), isolating the two deviations."),
   dict(datasets=["delayed_noise", "var2_bivariate"], path="pipeline",
        reference="ground-truth coupling direction (x0 -> x1)",
        reference_kind="analytic", criterion="direction",
        expected_outcome="Direction convention A[i,j] = DI(i -> j): A[0,1] > A[1,0] (probe 7.419 > 2.647; 5.199 > 4.860)."),
 ])

recs['infotheory.si.kernel'] = dict(
 metric_name_standard="Stochastic interaction SI = H(X_t|X_{t-1}) + H(Y_t|Y_{t-1}) - H(X_t,Y_t | X_{t-1},Y_{t-1}) (Ay), lag 1, box-kernel plug-in, bits",
 canonical_ref="Ay N (2001) 'Information geometry on complexity and stochastic interaction', MPI MIS preprint 95/2001, published Entropy (2015) 17:2432-2458 (GitBook ref [1]); Ay N, Wennekers T (2003) Neurocomputing 52-54:461 (GitBook ref [2]); Barrett AB, Seth AK (2011) PLoS Comput Biol 7:e1001052 (Gaussian form)",
 canonical_definition="SI(X;Y) = sum_k H(M^k_t | M^k_{t-tau}) - H(M_t | M_{t-tau}) for the bipartition M = (X,Y), tau = 1; >= 0 for the true distribution",
 documented_definition=("supplement §1.4.9, p.12 (pack lines 551-561): 'Stochastic interaction [47, 48] is a measure of integrated information between two processes in the context of their own past. It is quantified by the difference between the joint entropy of the bivariate process and the individual entropies of each univariate process. "
     "Both entropies are measured in context of (conditioned on) the history of the processes; we restrict this history to be only one-step, assuming a first-order Markov process.' identifier 90 si_kernel_W-0.5_k-1; keywords undirected, nonlinear, unsigned, bivariate, time-dependent. GitBook information-theory.md:184-202 same."),
 delegate_lib="JIDT infodynamics.jar 1.6.1: EntropyCalculatorMultiVariateKernel (4-D, 2-D, 1-D), combined in pyspi",
 implemented_as=("x, y = z_i, z_j as (T,1); xy = [x, y]; tau = 1; H_joint = H(xy[1:] | xy[:-1]) = H_kernel(4-D [x_t, y_t, x_{t-1}, y_{t-1}]) - H_kernel(2-D [x_{t-1}, y_{t-1}]); "
     "H_src = H(x_t | x_{t-1}); H_targ = H(y_t | y_{t-1}) (2-D minus 1-D); SI = H_src + H_targ - H_joint, each on T-1 samples. Kernel half-width 0.5*sampleSD per column, closed box, self-included."),
 implementation_trace=PIPE + [UNDIR, PB] + BASE + [GETENT, "pyspi/config.yaml:480-492 StochasticInteraction configs (estimator only; delay default 1)",
   "pyspi/statistics/infotheory.py:513-522 StochasticInteraction(JIDTBase, Undirected).__init__(delay=1): identifier += '_k-{delay}'",
   "pyspi/statistics/infotheory.py:524-534 bivariate: x, y = data.to_numpy()[[i, j]]; xy = concat; H_joint = _compute_conditional_entropy(xy[tau:], xy[:-tau]); H_src, H_targ likewise; return H_src + H_targ - H_joint",
   CONDENT] + JENT,
 deviation_from_documented="None in substance: the sign is individual minus joint (the documented 'difference between the joint entropy ... and the individual entropies' leaves the order open; code follows the canonical non-negative convention). 'k-1' in the identifier is the delay tau, not an embedding length.",
 deviation_from_canonical="Matches Ay's SI with tau=1. Estimator: plug-in box kernel without bias correction gives a positive null bias (probe iid_gaussian means 1.766/0.934/0.407/0.150 bits at T=64/256/1024/4096 vs canonical 0).",
 units_and_range="bits; can be negative in principle (estimator), observed positive; symmetric; finite.",
 direction_convention="Undirected: A[i,j] = A[j,i] (formula symmetric under swapping x and y because max-norm box counts are invariant to column order; Undirected.multivariate mirrors). Probe: exact symmetry on delayed_noise and var2_bivariate T=1024.",
 symmetry_expected="sym",
 already_documented="no",
 new_finding_candidates=[
   "Candidate (bias magnitude): si_kernel_W-0.5_k-1 between independent white-noise series is 1.77 bits at T=64 and still 0.15 bits at T=4096 (probe iid_gaussian means), compared with gauss_ar1_pair-type coupling effects of similar size; values are T-dependent.",
   "Candidate (label/identifier semantics): the '_k-1' suffix (infotheory.py:522) denotes the delay tau, while '_k-' denotes target history length in te identifiers; not a numerical issue.",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "gauss_ar1_pair", "var2_bivariate", "delayed_noise"], path="pipeline",
        reference=BOXREF_H + "; SI = CE(x_t|x_{t-1}) + CE(y_t|y_{t-1}) - CE([x_t,y_t]|[x_{t-1},y_{t-1}]) with CE(A|B) = H([A,B]) - H(B)",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="All off-diagonal entries agree to abs <= 1e-12 (probe 9.8e-15)."),
   dict(datasets=["gauss_ar1_pair"], path="pipeline",
        reference="analytic Gaussian SI from A, Sigma_E, Sigma_X: 0.5*log2(s_x s_y / det Sigma_E) with s_k = Sigma_X,kk - (A Sigma_X)_kk^2 / Sigma_X,kk (conditional variances of each node given its own past), standardised units",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="At T=4096 the kernel value exceeds the Gaussian value by roughly the null bias (~0.15 bits); difference to truth < 0.3 bits."),
   dict(datasets=["iid_gaussian"], path="pipeline",
        reference="analytic null 0", reference_kind="analytic", criterion="statistical",
        expected_outcome="Positive null bias decreasing with T (probe 1.766, 0.934, 0.407, 0.150)."),
   dict(datasets=["var2_bivariate", "delayed_noise", "iid_gaussian"], path="pipeline",
        reference="analytic symmetry: A vs A.T and fresh bivariate(i,j) vs bivariate(j,i)",
        reference_kind="analytic", criterion="direction",
        expected_outcome="Direction convention: undirected; A == A.T bitwise and fresh calls equal both ways."),
 ])

for uid, c in recs.items():
    dump(dict(unit_id=uid, status='traced', correctness=c), OUT + uid + '.yaml')
    print('wrote', uid)
