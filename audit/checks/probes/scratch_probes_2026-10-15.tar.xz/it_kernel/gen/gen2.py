import sys
sys.path.insert(0, sys.argv[1])
from common import *
OUT = '/media/dan/Data/git/pyspi/audit/records/'
BOXREF_H = ("from-scratch numpy box-kernel resubstitution entropy: per column w_d = 0.5*std(col, ddof=1); "
            "C_b = #{t : max_d |X_td - X_bd|/w_d <= 1} (self included); H = -mean(log2(C_b / (N * prod_d 2 w_d)))")
recs = {}

# ---------------- TE ----------------
recs['infotheory.te.kernel_k-1_kt-1_l-1_lt-1'] = dict(
 metric_name_standard="Transfer entropy T_{X->Y} with target history k=1, source history l=1, lag 1, box-kernel (Schreiber) estimate, bits",
 canonical_ref="Schreiber T (2000) 'Measuring information transfer', Phys Rev Lett 85:461-464, Eq. (4) and the kernel estimator p_r(.) = (1/N) sum Theta(r - |.|) (max norm) described there; Kaiser A, Schreiber T (2002) Physica D 166:43-62; Kantz & Schreiber (1997)",
 canonical_definition="T_{X->Y} = sum p(y_{t+1}, y_t^(k), x_t^(l)) log2[ p(y_{t+1} | y_t^(k), x_t^(l)) / p(y_{t+1} | y_t^(k)) ]; with k=l=1 and box kernel: mean_t log2[ (C_nps/C_ps) / (C_np/C_p) ] over t = 1..T-1",
 documented_definition=("supplement §1.4.5, pp.10-11 (pack lines 486-510): 'Transfer entropy [35] is a measure of information transfer from a source time series x to a target time series y, based on the Takens time-delay embedding ... "
     "The embedding lengths are denoted by modifier's l and k for the source, x, and target, y ... The fixed parameters are minimal values, i.e., typically with a fixed target embedding length of 1 (denoted by k-1)'; "
     "identifier 77 te_kernel_W-0.25_k-1; keywords directed, nonlinear, unsigned, bivariate, time-dependent. GitBook information-theory.md:206-231 same; identifier te_kernel_W-0.25_k-1."),
 delegate_lib="JIDT infodynamics.jar 1.6.1: infodynamics.measures.continuous.kernel.TransferEntropyCalculatorKernel.computeAverageLocalOfObservations with KernelEstimatorTransferEntropy",
 implemented_as=("config.yaml:593-596 (estimator kernel, kernel_width 0.25, k_history 1, l_history 1). Constructor sets only k_HISTORY=1 on the JIDT calculator (k_tau, l_history, l_tau are skipped for kernel). "
     "bivariate(i,j): src = z_i, targ = z_j; initialise() -> teKernelEstimator.initialise(k=1, 0.25). JIDT builds destPast = y_{t-1} (rows t=1..T-1), destNext = y_t, source = x_{t-1} (source value at the same time as the last past value; l=1, lag 1 fixed in this class). "
     "Half-widths: past 0.25*SD(y[0:T-1]); source 0.25*SD(x[0:T-1]); next uses the PAST width (kernelWidthsInUse[0]). Counts (closed boxes, self included): C_p over past, then via callbacks C_ps, C_np, C_nps; "
     "TE = mean log2[(C_nps/C_ps)/(C_np/C_p)] over T-1 points. No Theiler window, no bias correction. A[i,j] = TE(i -> j)."),
 implementation_trace=PIPE + [PB] + BASE + [
   "pyspi/statistics/infotheory.py:124-126,134 _getcalc('TransferEntropy') -> kernel.TransferEntropyCalculatorKernel; pyspi/config.yaml:593-596 (kernel, 0.25, k_history 1, l_history 1); commented-out kernel auto-embedding config :585-590",
   "pyspi/statistics/infotheory.py:326-367 TransferEntropy.__init__: auto_embed_method None -> setProperty('k_HISTORY', str(k_history)) at :358; for kernel the k_TAU/l_HISTORY/l_TAU setProperty calls (:360-362) are skipped and the identifier gets only '_k-{k_history}' (:367)",
   "pyspi/statistics/infotheory.py:376-391 TransferEntropy.bivariate: 'Compute transfer entropy from i->j'; _set_theiler_window no-op; self._calc.initialise(); src, targ = data.to_numpy(squeeze=True)[[i, j]]; setObservations(src, targ); computeAverageLocalOfObservations; exception -> NaN",
   "JIDT v1.6.1 " + J + "measures/continuous/kernel/TransferEntropyCalculatorKernel.java: initialise() L161-166 (teKernelEstimator.initialise(k, kernelWidth)); setProperty L205-234 (KERNEL_WIDTH, NORMALISE, DYN_CORR_EXCL, FORCE_KERNEL_COMPARE_TO_ALL; else super); finaliseAddObservations L254-292 (destPast = makeJointVectorForPast, destNext = destination[k..], source = source[k-1 .. T-2]); computeAverageLocalOfObservations L295-321 (log of (C_nps/C_ps)/(C_np/C_p), skipped when C_nps = 0; mean / ln 2)",
   "JIDT v1.6.1 " + J + "measures/continuous/TransferEntropyCommon.java: setObservations L99-103; setProperty L316-336 (k_HISTORY accepted; k_TAU, l_HISTORY, l_TAU, DELAY throw 'Unsupported property'; unknown names ignored); makeJointVectorForPast L265-275 (makeDelayEmbeddingVector(destination, k, k-1, T-k))",
   "JIDT v1.6.1 " + J + "measures/continuous/kernel/KernelEstimatorTransferEntropy.java: setObservations L80-97 (past widths via super.setObservations; source width = eps * MatrixUtils.stdDev(source)); getCount L111-133 (C_p from KernelEstimatorMultiVariate.getCount, joint counts via callbacks); correlatedPointAddedCallback L145-159 (closed comparisons '<='; destNext compared with kernelWidthsInUse[0], the past-dimension width)",
   "JIDT v1.6.1 " + J + "measures/continuous/kernel/KernelEstimatorMultiVariate.java: getCountFromBins L589-719 (callback for every point of the query's own bin and for neighbour-bin points passing stepKernel), stepKernel L959-967",
   ] + [JENT[2]],
 deviation_from_documented=("None for the configured values (k=1, l=1). The documented l/lt/kt modifiers cannot be honoured by this estimator: pyspi silently drops l_history, k_tau and l_tau for kernel "
     "(JIDT would raise 'Unsupported property'), and the identifier records only k. 'Width 0.25' is the box half-width."),
 deviation_from_canonical=("Matches Schreiber (2000) Eq. 4 with k=l=1, lag 1 and a max-norm box kernel. Minor: (a) the next-value box uses the past series' SD (KernelEstimatorTransferEntropy L151-153 comment "
     "'epsilons ... should all be approximately equal, so just use the first one'); (b) resubstitution counts include the point itself and there is no bias correction (JIDT keeps the Grassberger-corrected variant L338-396 for testing only), "
     "giving a large positive null bias (probe iid_gaussian means 1.440/1.045/0.522/0.196 bits at T=64/256/1024/4096)."),
 units_and_range="bits; mean of log count ratios, can be negative in principle, typically positive (null bias); asymmetric; NaN only on exception.",
 direction_convention="A[i,j] = TE(X_i -> X_j): row i = source, column j = target (docstring 'from i->j'). Probe delayed_noise T=1024: A[0,1] = 2.571 (x0 drives x1) vs A[1,0] = 0.501 (null level); var2_bivariate T=4096 A[0,1] = 0.348 vs A[1,0] = 0.187; logistic_maps (y=1 drives x=0) T=4096 A[1,0] = 0.066 > A[0,1] = 0.016.",
 symmetry_expected="asym",
 already_documented="no",
 new_finding_candidates=[
   "Candidate (parameter forwarding, confirms pack hypothesis): for estimator='kernel' pyspi forwards only k_HISTORY; l_history, k_tau and l_tau are dropped without warning and are absent from the identifier. Evidence: infotheory.py:358-367; probe TransferEntropy(estimator='kernel', l_history=3, l_tau=2, k_tau=4) -> identifier te_kernel_W-0.25_k-1, k_HISTORY=1; JIDT TransferEntropyCommon.setProperty L320-327 throws 'Unsupported property' for l_HISTORY/k_TAU/l_TAU/DELAY (probe confirmed). No numerical effect for the configured l_history=1.",
   "Candidate (outside configured units): auto_embed_method with the kernel estimator is accepted silently (TransferEntropyCommon ignores unknown names; probe getProperty('AUTO_EMBED_METHOD') -> None, k stays 1) while pyspi labels the SPI te_kernel_W-0.25_k-max-4; the config entry is commented out (config.yaml:585-590).",
   "Candidate (estimator detail): the destination-next box uses the half-width of the destination-past column (kernelWidthsInUse[0]) rather than its own SD (KernelEstimatorTransferEntropy.java L153). Evidence: numpy reference with w_next = w_past matched pyspi exactly (diff 0.0 on var2_bivariate T=256).",
   "Candidate (bias magnitude): null bias of te_kernel_W-0.25_k-1 is large relative to typical effects (iid_gaussian 1.44 bits at T=64, 0.52 at T=1024, 0.20 at T=4096 vs var2_bivariate T=4096 true-direction value 0.348), so absolute values are dominated by T-dependent bias.",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "var2_bivariate", "delayed_noise", "logistic_maps", "gauss_ar1_pair"], path="pipeline",
        reference="from-scratch numpy Schreiber box-kernel TE (k=l=1): past=y[0:T-1], next=y[1:], src=x[0:T-1]; w_p=0.25*std(past,ddof=1), w_s=0.25*std(src,ddof=1), w_n=w_p; closed boxes incl. self; mean log2((C_nps/C_ps)/(C_np/C_p))",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="All off-diagonal entries agree to abs <= 1e-12 (probe diff 0.0). A variant with w_n = 0.25*std(next) quantifies deviation (a) (expected < 1e-2 bits)."),
   dict(datasets=["delayed_noise", "var2_bivariate", "logistic_maps"], path="pipeline",
        reference="ground-truth coupling direction of the generators (delayed_noise: x0 -> x1,x2,x3; var2_bivariate: x0 -> x1; logistic_maps: y (1) -> x (0))",
        reference_kind="analytic", criterion="direction",
        expected_outcome="Direction convention A[i,j] = TE(i -> j): A[0,1] > A[1,0] for delayed_noise and var2_bivariate, A[1,0] > A[0,1] for logistic_maps, at T >= 1024."),
   dict(datasets=["var2_bivariate", "gauss_ar1_pair"], path="pipeline",
        reference="analytic Gaussian TE with k=l=1 (bits): 0.5*log2( Var(y_t | y_{t-1}) / Var(y_t | y_{t-1}, x_{t-1}) ) from the stationary lag-0/lag-1 covariances (Barnett, Barrett & Seth 2009 PRL 103:238701 equivalence)",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="Kernel estimate exceeds the Gaussian value by the null bias (~0.2 bits at T=4096); the difference true-direction minus reverse-direction is within 0.1 bits of the analytic difference at T=4096."),
   dict(datasets=["iid_gaussian"], path="pipeline",
        reference="analytic null 0", reference_kind="analytic", criterion="statistical",
        expected_outcome="Positive null bias decreasing with T (probe means 1.440, 1.045, 0.522, 0.196 bits)."),
   dict(datasets=["var2_bivariate"], path="kernel",
        reference="parameter forwarding: TransferEntropy(estimator='kernel', kernel_width=0.25, k_history=1, l_history in {1,3}, k_tau in {1,4}, l_tau in {1,2})",
        reference_kind="analytic", criterion="exact",
        expected_outcome="All variants give bit-identical values and the same identifier te_kernel_W-0.25_k-1 (documents the silent drop)."),
 ])

# ---------------- XME k1 ----------------
xme_impl_common = ("Code (infotheory.py:405-426): src, targ = z_i, z_j; k = history_length; targ_future = targ[k:]; src_past starts with src[k-1:-1] (x_{t-1}) and the loop 'for i in range(2, k)' appends x_{t-i}; "
     "joint = [src_past, targ_future]; value = H_kernel(joint) - H_kernel(src_past) with the W-0.5 kernel entropy (half-width 0.5*sampleSD of each sub-series column, closed box, self-included). "
     "The loop gives max(1, k-1) source lags, not k.")
recs['infotheory.xme.kernel_k1'] = dict(
 metric_name_standard="Lagged conditional entropy H(Y_t | X_{t-1}) of the target given the source's previous value ('cross-map entropy' in pyspi), box-kernel plug-in, bits",
 canonical_ref="No canonical 'cross-map entropy' in the literature was found; the computed quantity is the conditional differential entropy h(Y_t | X_{t-1}) = h(Y_t) - I(X_{t-1}; Y_t) (Cover & Thomas 2006 Ch. 8). The name evokes convergent cross mapping (Sugihara G et al. 2012 Science 338:496), which is not what is computed.",
 canonical_definition="h(Y_t | X_{t-1}) = h(X_{t-1}, Y_t) - h(X_{t-1}); box-kernel plug-in on the T-1 aligned pairs",
 documented_definition=("Not described in the supplement (no xme section in §1.4, pack lines 414-561) nor in GitBook information-theory.md. GitBook table-of-spis.md:73 lists 'Cross-Map Entropy', base identifier xme, with estimators "
     "xme_kernel_k1 / xme_kernel_k10 (no W-0.5 modifier); config.yaml:439-464 labels unsigned, directed, time-dependent, bivariate; class docstring absent (name 'Cross-map entropy', infotheory.py:394-398)."),
 delegate_lib="JIDT infodynamics.jar 1.6.1: EntropyCalculatorMultiVariateKernel (2-D joint and 1-D marginal), combined in pyspi",
 implemented_as=(xme_impl_common + " For k=1: H(x_{t-1}, y_t) - H(x_{t-1}) over t = 1..T-1, i.e. h_hat(Y_t | X_{t-1}). A[i,j] = h_hat(X_j,t | X_i,t-1)."),
 implementation_trace=PIPE + [PB] + BASE + [GETENT,
   "pyspi/config.yaml:454-455 CrossmapEntropy estimator kernel, history_length 1",
   "pyspi/statistics/infotheory.py:394-403 CrossmapEntropy(JIDTBase, Directed).__init__(history_length=10): identifier += '_k{history_length}'",
   "pyspi/statistics/infotheory.py:405-426 CrossmapEntropy.bivariate: targ_future = targ[k:]; src_past = src[k-1:-1]; loop range(2, k); joint entropy (:418-420) minus source-past entropy (:422-424)"] + JENT,
 deviation_from_documented="No definition is documented (only the name and identifiers in table-of-spis.md, whose identifiers omit the W-0.5 modifier that the code adds: actual identifier xme_kernel_W-0.5_k1).",
 deviation_from_canonical=("Name-level: nothing is cross-mapped; the value is a lagged conditional entropy (equivalently h(Y_t) minus lag-1 MI, the tlmi quantity at a different kernel width). Estimator properties as in infotheory.est.kernel."),
 units_and_range="bits; with W-0.5 the value is -mean log2(C_xy/C_x) + log2(SD of y[1:]) ~ >= 0 (the SD of the sub-series is close to, not exactly, 1); <= ~log2(T-1); asymmetric; finite.",
 direction_convention="A[i,j] = h_hat(X_j at t | X_i at t-1): row i = source past, column j = target present. LOW values mean strong i -> j predictability (opposite sense to te/tlmi). Probe delayed_noise T=1024: A[0,1] = 0.180 (x1 is x0 delayed by 1) vs A[1,0] = 2.024 (~h_box of N(0,1)).",
 symmetry_expected="asym",
 already_documented="no",
 new_finding_candidates=[
   "Candidate (undocumented SPI): xme has no definition in the supplement or GitBook SPI descriptions; table-of-spis.md:73 lists identifiers xme_kernel_k1/k10 that differ from the produced xme_kernel_W-0.5_k1/k10 (probe identifiers).",
   "Candidate (naming): 'cross-map entropy' computes H(Y_t | X_{t-1..}) with no cross-mapping; for k=1 it is exactly h_hat(Y_t) - I_hat(X_{t-1}; Y_t) under the same kernel width. Evidence: infotheory.py:405-426; numpy reference H([x_{t-1}, y_t]) - H(x_{t-1}) matched pyspi to 2.2e-15 (var2_bivariate T=256: 1.70986628477191).",
   "Candidate (off-by-one shared with k10): history_length=2 also yields one lag (range(2,2) empty), so xme k1 and k2 differ only by dropping one sample. Evidence: probe xme_k2 matched H(y_t | x_{t-1}) on T-2 samples to 1.3e-15 (1.70936240998512).",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "delayed_noise", "var2_bivariate", "logistic_maps", "gauss_ar1_pair"], path="pipeline",
        reference=BOXREF_H + "; value = H([z_i[:-1], z_j[1:]]) - H(z_i[:-1])",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="All off-diagonal entries agree to abs <= 1e-12 (probe 2.2e-15)."),
   dict(datasets=["delayed_noise"], path="pipeline",
        reference="analytic: x1(t) = x0(t-1) + 0.1 noise",
        reference_kind="analytic", criterion="direction",
        expected_outcome="Direction convention A[i,j] = H(X_j,t | X_i,t-1): A[0,1] << A[1,0] (probe 0.180 vs 2.024); low = coupled."),
   dict(datasets=["iid_gaussian"], path="pipeline",
        reference="analytic box-kernel limit h_box(0.5) = 2.04935 bits for N(0,1) target independent of the source (true h = 2.04710)",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="Mean off-diagonal value approaches 2.049 from below (probe 1.744, 1.964, 2.020, 2.042 at T=64..4096); |mean - 2.049| < 0.015 at T=4096."),
   dict(datasets=["gauss_ar1_pair"], path="pipeline",
        reference="analytic Gaussian h(Y_t | X_{t-1}) = 0.5*log2(2 pi e (var_y - c^2/var_x)) from Sigma_X and Sigma_XY (standardised)",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="At T=4096 within 0.05 bits of the Gaussian value (box smoothing bias small at W=0.5 for 1-D conditioning)."),
   dict(datasets=["var2_bivariate"], path="kernel",
        reference="history_length=2 vs from-scratch one-lag conditional entropy on T-2 samples",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="CrossmapEntropy(estimator='kernel', history_length=2) equals the one-lag reference to abs <= 1e-12 (documents the off-by-one)."),
 ])

# ---------------- XME k10 ----------------
recs['infotheory.xme.kernel_k10'] = dict(
 metric_name_standard="Conditional entropy of the target's present given the source's recent past, H(Y_t | X_{t-1}, ..., X_{t-9}) ('cross-map entropy', history_length=10), box-kernel plug-in, bits",
 canonical_ref="No canonical 'cross-map entropy' found; quantity is h(Y_t | X_{t-1..t-m}) (Cover & Thomas 2006 Ch. 8); name evokes Sugihara et al. 2012 Science 338:496 (CCM), not what is computed.",
 canonical_definition="h(Y_t | X^{(m)}_{t-1}) = h(X^{(m)}_{t-1}, Y_t) - h(X^{(m)}_{t-1}) with m = history_length (intended 10)",
 documented_definition=("Not described in the supplement or GitBook information-theory.md; GitBook table-of-spis.md:73 lists xme_kernel_k10 under 'Cross-Map Entropy'; config.yaml:463-464 history_length 10."),
 delegate_lib="JIDT infodynamics.jar 1.6.1: EntropyCalculatorMultiVariateKernel (10-D joint, 9-D source past)",
 implemented_as=(xme_impl_common + " For k=10: 9 source lags x_{t-1}..x_{t-9} (columns from src[9:-1], src[8:-2], ..., src[1:-9]) and target y_t for t = 10..T-1 (T-10 samples); "
     "joint is 10-D, past 9-D. With half-width 0.5 SD per dimension the 9/10-D boxes contain almost only the query point for T <= 4096, so both entropies are ~ log2(T-10) + log2(volume) and the difference is ~0."),
 implementation_trace=PIPE + [PB] + BASE + [GETENT,
   "pyspi/config.yaml:463-464 CrossmapEntropy estimator kernel, history_length 10",
   "pyspi/statistics/infotheory.py:394-403 CrossmapEntropy.__init__ identifier '_k10'",
   "pyspi/statistics/infotheory.py:405-426 bivariate: targ_future = targ[10:]; src_past = src[9:-1]; for i in range(2, 10): append src[10-i:-i] -> lags 1..9; H(joint 10-D) - H(src_past 9-D)"] + JENT,
 deviation_from_documented="No definition documented; identifier in table-of-spis.md lacks W-0.5. 'k10' suggests 10 lags but 9 are used.",
 deviation_from_canonical=("(1) Off-by-one: 9 source lags instead of 10 (range(2, k) should run to k inclusive), and the first usable sample is discarded. (2) Estimator degeneracy: the 0.5-SD box in 9-10 dimensions "
     "is empty except for the query point for nearly all samples, so the plug-in collapses to ~0 independent of coupling. (3) Name as in xme k1."),
 units_and_range="bits; observed in [-0.003, 0.033] on iid data T=256..4096 and 0.006-0.024 on coupled data; can be slightly negative (sub-series SD != 1); asymmetric; finite.",
 direction_convention="A[i,j] = h_hat(X_j,t | X_i,t-1..t-9); low = predictable from i's past. In practice no usable direction: probe delayed_noise T=1024 A[0,1] = 0.0058, A[1,0] = 0.0117; var2_bivariate T=1024 A[0,1] = 0.0238, A[1,0] = 0.0094 (the coupled direction is the LARGER value here).",
 symmetry_expected="asym",
 already_documented="no",
 new_finding_candidates=[
   "Candidate (off-by-one): history_length=10 builds 9 source lags. Evidence: infotheory.py:410-414 ('src_past = src[k-1:-1]' then 'for i in range(2, k)'); numpy reference with lags 1..9 on T-10 samples matched pyspi to 2.3e-14 (var2_bivariate T=256: 0.0282161171753117).",
   "Candidate (degenerate estimator): at W-0.5 the 10-D joint and 9-D past box counts are 1 (self only) for 100% of points at T=256, 99.6%/98.3% at T=1024 and 98.7%/95.5% at T=4096 (probe on independent Gaussian pairs), so xme_kernel_W-0.5_k10 ~ 0 regardless of dependence (iid: -0.0025, 0.0168, 0.0332 at T=256, 1024, 4096; delayed_noise coupled pair 0.0058).",
   "Candidate (undocumented SPI / identifier mismatch): see infotheory.xme.kernel_k1.",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "delayed_noise", "var2_bivariate", "logistic_maps"], path="pipeline",
        reference=BOXREF_H + "; past = [z_i[10-l : T-l] for l = 1..9], value = H([past, z_j[10:]]) - H(past)",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="Agreement to abs <= 1e-12 with 9 lags; a 10-lag variant differs (quantifies the off-by-one)."),
   dict(datasets=["iid_gaussian", "delayed_noise", "var2_bivariate"], path="pipeline",
        reference="count diagnostics from the numpy reference: fraction of points with C = 1 in the joint and past spaces",
        reference_kind="independent-impl", criterion="qualitative",
        expected_outcome="Fraction with C = 1 above 0.9 for all T <= 4096; |value| < 0.05 bits for every pair and dataset (degenerate)."),
   dict(datasets=["delayed_noise", "var2_bivariate"], path="pipeline",
        reference="ground-truth coupling direction (x0 -> x1)",
        reference_kind="analytic", criterion="direction",
        expected_outcome="Direction convention A[i,j] = H(X_j,t | X_i past): expected sign A[0,1] < A[1,0] for a working estimator; anticipated outcome is no reliable ordering (probe var2_bivariate shows the reverse ordering)."),
   dict(datasets=["iid_gaussian"], path="pipeline",
        reference="analytic truth h(N(0,1)) = 2.047 bits for independent pairs",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="Values near 0, i.e. about 2 bits below the truth at every T (documents degeneracy)."),
 ])

for uid, c in recs.items():
    dump(dict(unit_id=uid, status='traced', correctness=c), OUT + uid + '.yaml')
    print('wrote', uid)
