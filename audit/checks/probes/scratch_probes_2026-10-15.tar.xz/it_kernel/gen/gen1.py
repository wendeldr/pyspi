import sys
sys.path.insert(0, sys.argv[1])
from common import *
OUT = '/media/dan/Data/git/pyspi/audit/records/'
BOXREF_H = ("from-scratch numpy box-kernel resubstitution entropy: z = scipy.stats.zscore(x, ddof=1); per column w_d = eps*std(col, ddof=1); "
            "C_b = #{t : max_d |X_td - X_bd|/w_d <= 1} (self included); H = -mean(log2(C_b / (N * prod_d 2 w_d)))")

recs = {}

# ---------------- JE ----------------
recs['infotheory.je.kernel'] = dict(
 metric_name_standard="Joint differential entropy h(X,Y) of the contemporaneous pair, box-kernel (fixed-radius) resubstitution estimate, bits",
 canonical_ref="Cover TM, Thomas JA (2006) Elements of Information Theory, 2nd ed., Wiley, Ch. 8 (Def. 8.1/8.4.1 joint differential entropy); estimator: Kantz H, Schreiber T (1997) Nonlinear Time Series Analysis, CUP (box-kernel / correlation-sum density p_r(x) = (1/N) sum_n Theta(r - ||x - x_n||_max)); resubstitution entropy estimator: Ahmad IA, Lin P-E (1976) IEEE Trans. Inf. Theory 22:372-375; review Beirlant J et al. (1997) Int. J. Math. Stat. Sci. 6:17-39",
 canonical_definition="h(X,Y) = -E[log2 p(X,Y)]; box-kernel estimate h_hat = -(1/N) sum_b log2[ C_b / (N V) ], C_b = #{t : max(|x_t-x_b|/r_x, |y_t-y_b|/r_y) <= 1}, V = (2 r_x)(2 r_y)",
 documented_definition=("supplement §1.4.1, p.10 (pack lines 454-460): 'The joint entropy [33] quantifies the uncertainty over the paired observations' "
     "(the equation is not present in the text extraction); keywords undirected, nonlinear, unsigned, bivariate, contemporaneous; identifier 60 je_kernel_W-0.5. "
     + SUPP14 + ". GitBook information-theory.md:139-157 (Joint Entropy) same prose, key reference MacKay ITILA."),
 delegate_lib="JIDT infodynamics.jar 1.6.1 (via JPype): infodynamics.measures.continuous.kernel.EntropyCalculatorMultiVariateKernel.computeAverageLocalOfObservations with KernelEstimatorMultiVariate",
 implemented_as=("Calculator z-scores each series (ddof=1). For pair (i,j): rows x=z_i, y=z_j (T samples each) are concatenated to a (T,2) array; JIDT kernel entropy with "
     "KERNEL_WIDTH=0.5 and internal NORMALISE=true: half-widths w_d = 0.5*sampleSD(col) (= 0.5 exactly for z-scored series), closed max-norm box |dx_d| <= w_d, the query point "
     "counts itself, density = C_b/(T*prod 2w_d) = C_b/T (box volume 1 here), H = -mean_b log2(C_b/T). Value cached in data.joint_entropy[('kernel',0.5)][i,j] "
     "and mirrored to [j,i]; Undirected.multivariate mirrors again. No Theiler window, no bias correction, no noise."),
 implementation_trace=PIPE + [UNDIR, PB] + BASE + [GETENT,
   "pyspi/statistics/infotheory.py:223-234 JointEntropy(JIDTBase, Undirected).bivariate -> _compute_joint_entropy(data, i, j)",
   "pyspi/statistics/infotheory.py:159-177 _compute_joint_entropy: x, y = data.to_numpy()[[i, j]] (each (T,1)); initialise(2); setObservations(JArray(JDouble,2)(np.concatenate([x, y], axis=1))); computeAverageLocalOfObservations; cache key ('kernel', 0.5); symmetric fill :175"] + JENT,
 deviation_from_documented=("None in substance. Precision of wording: 'width of 0.5 standard deviations' is the box HALF-width (radius): stepKernel excludes a point only if |dx| > 0.5 SD, "
     "so the box side is 1 SD per dimension. The supplement cites JIDT v1.5 (§1.4) while the bundled jar and GitBook say v1.6.1."),
 deviation_from_canonical=("Estimator-level (shared with infotheory.est.kernel): resubstitution (self-inclusive, no leave-one-out) box-kernel plug-in with no bias correction; "
     "the large-sample limit is the cross-entropy of p against its box-smoothed version, slightly above h(X,Y) (for an independent N(0,1) pair the limit is 2 x 2.04935 = 4.0987 bits "
     "vs true 4.0942 bits; probe on iid_gaussian T=4096 gave mean 4.089 bits); self-inclusion biases densities up (entropy down) at small T. Otherwise matches the definition."),
 units_and_range=("bits. With W=0.5 on z-scored data the box volume is exactly 1, so JE = -mean log2(C_b/T) lies in [0, log2 T]: never negative (unlike the Gaussian je), "
     "finite for finite input (C_b >= 1). Symmetric in (i,j). Diagonal NaN (Calculator)."),
 direction_convention="Undirected: A[i,j] = A[j,i] = h_hat(z_i, z_j); the cache fill (infotheory.py:175) and Undirected.multivariate mirror make the matrix exactly symmetric (probe: np.array_equal(A, A.T) True on delayed_noise and var2_bivariate T=1024).",
 symmetry_expected="sym",
 already_documented="no",
 new_finding_candidates=[
   "Candidate (documentation precision): 'kernel width 0.5 SD' is the half-width of a closed max-norm box. Evidence: KernelEstimatorMultiVariate.stepKernel L961 'if (Math.abs(observation[d] - candidate[d]) > kernelWidthsInUse[d]) return 0'; library probe on grid [0,1,2,3,10] with absolute width 1.0 gave H=2.287943094599 = closed-box value (open-box value would be 3.321928).",
   "Candidate (range property): because the box volume is (2*0.5*1)^2 = 1 on z-scored data, je_kernel_W-0.5 = -mean log2(C_b/T) is bounded in [0, log2 T] and is a smoothed plug-in of the bivariate density, not an unbiased differential-entropy estimate. Evidence: from-scratch numpy reference with this formula matched pyspi to 8.9e-16 (var2_bivariate T=256, 3.94581152410853 bits); iid_gaussian means 3.805/4.004/4.070/4.089 bits at T=64/256/1024/4096 vs box-limit 4.0987 and true 4.0942.",
   "Candidate (kernel-path quirk, see infotheory.est.kernel): calling JointEntropy.bivariate(x, y) with raw arrays z-scores only x (Data.add_process), so the value shifts by log2(SD(y)). Evidence probe: scaled_offset T=256 rows 2,3: raw-array call 6.6107 vs Data call 3.3055, difference 3.30519 = log2(std(x3, ddof=1)).",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "bivariate_gaussian", "nonlinear_dependence", "delayed_noise", "contaminated"], path="pipeline",
        reference=BOXREF_H + " with eps=0.5 on the (T,2) pair, every off-diagonal pair, T in {64,256,1024,4096}",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="Every off-diagonal Calculator entry equals the numpy value to abs <= 1e-12 (probe: 8.9e-16 on var2_bivariate T=256)."),
   dict(datasets=["iid_gaussian"], path="pipeline",
        reference="analytic large-sample limit of the box-kernel resubstitution estimator for an independent N(0,1) pair: 2*h_box(0.5), h_box(e) = -integral phi(x) log2[(Phi(x+e)-Phi(x-e))/(2e)] dx = 2.04935 bits (scipy.integrate.quad); true h = 2*2.04710",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="Mean off-diagonal value approaches 4.0987 bits from below as T grows (probe 3.805, 4.004, 4.070, 4.089); |mean - 4.0987| < 0.02 at T=4096."),
   dict(datasets=["bivariate_gaussian"], path="pipeline",
        reference="analytic box limit for correlated Gaussian pairs: -E log2 P_box(X,Y) with P_box = rectangle probability of the N(0,[[1,rho],[rho,1]]) law over [x-0.5,x+0.5]x[y-0.5,y+0.5] (scipy.stats.multivariate_normal.cdf rectangle differences, Monte Carlo over 1e5 points); Gaussian truth 0.5*log2((2 pi e)^2 (1-rho^2)) reported alongside",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="Pairs (0,1) rho=0.3 and (2,3) rho=0.8 at T=4096 within 0.03 bits of the box limit; the box limit sits within ~0.05 bits above the Gaussian truth (smoothing bias larger for rho=0.8)."),
   dict(datasets=["var2_bivariate", "delayed_noise", "iid_gaussian"], path="pipeline",
        reference="analytic symmetry: A vs A.T and direct bivariate(i,j) vs bivariate(j,i) on a fresh Data object (no cache)",
        reference_kind="analytic", criterion="direction",
        expected_outcome="Direction convention: undirected; A == A.T bitwise and fresh bivariate(i,j) == bivariate(j,i) (column-permutation invariance of max-norm box counts)."),
   dict(datasets=["scaled_offset", "bivariate_gaussian"], path="pipeline",
        reference="invariance: scaled_offset = scale*bivariate_gaussian + offset (same draw); z-scoring removes it",
        reference_kind="analytic", criterion="tolerance",
        expected_outcome="With normalise=True the matrices agree to abs <= 1e-12 at every T; with normalise=False the entries shift by log2(scale_i*scale_j) up to ~1e-12 (differential-entropy scaling, kernel width follows the SD)."),
   dict(datasets=["iid_gaussian", "delayed_noise", "narrowband_f0-0.25", "logistic_maps"], path="pipeline",
        reference="analytic bound for volume-1 box: 0 <= JE <= log2 T",
        reference_kind="analytic", criterion="exact",
        expected_outcome="All off-diagonal entries lie in [0, log2 T] (to 1e-12); no NaN/inf."),
 ])

# ---------------- CE ----------------
recs['infotheory.ce.kernel'] = dict(
 metric_name_standard="Conditional differential entropy h(X_j | X_i) of contemporaneous samples (box-kernel plug-in, bits)",
 canonical_ref="Cover TM, Thomas JA (2006) Elements of Information Theory, 2nd ed., Ch. 8, Def. of conditional differential entropy h(Y|X) = h(X,Y) - h(X) (Sec. 8.4); estimator Kantz & Schreiber (1997) box kernel",
 canonical_definition="h(Y|X) = -E[log2 p(y|x)] = h(X,Y) - h(X); box-kernel plug-in: h_hat(X,Y) - h_hat(X) with the same radius in SD units",
 documented_definition=("supplement §1.4.2, p.10 (pack lines 461-468): 'Conditional entropy [33] quantifies the uncertainty over the observations in y in the context of simultaneously observing x' "
     "(equation not in the text extraction); keywords: undirected, nonlinear, unsigned, bivariate, contemporaneous; identifier 63 ce_kernel_W-0.5. " + SUPP14 +
     ". GitBook information-theory.md:46-64 same prose and keywords (undirected)."),
 delegate_lib="JIDT infodynamics.jar 1.6.1: EntropyCalculatorMultiVariateKernel (joint 2-D and marginal 1-D), combined in pyspi",
 implemented_as=("A[i,j] = bivariate(i,j) = JE_hat(z_i, z_j) - H_hat(z_i) = h_hat(X_j | X_i): the conditioning variable is the FIRST index (source i), the target is j. "
     "JE from the shared cache data.joint_entropy[('kernel',0.5)] (infotheory.py:159-177), H from data.entropy[('kernel',0.5)] (infotheory.py:137-156, 1-D kernel entropy on z_i). "
     "Both use closed max-norm boxes of half-width 0.5*sampleSD per dimension with self-inclusion; with z-scored data CE = -mean log2(C_xy/C_x) + log2(2*0.5*SD(z_j)) = -mean log2(C_xy/C_x) (>= 0)."),
 implementation_trace=PIPE + [PB] + BASE + [GETENT,
   "pyspi/statistics/infotheory.py:237-250 ConditionalEntropy(JIDTBase, Directed).bivariate: return _compute_joint_entropy(data, i, j) - _compute_entropy(data, i)",
   "pyspi/statistics/infotheory.py:159-177 _compute_joint_entropy (2-D kernel entropy of [z_i, z_j], cached, symmetric fill)",
   "pyspi/statistics/infotheory.py:137-156 _compute_entropy (parse_univariate; 1-D kernel entropy of z_i; initialise(1); setObservations(JArray(JDouble,1)); cached per i)"] + JENT,
 deviation_from_documented=("(1) Keyword 'undirected' in supplement §1.4.2 and GitBook :48 contradicts the code (class Directed, label 'directed', infotheory.py:237-241) and the asymmetric value "
     "(probe delayed_noise T=1024: A[0,1]=2.0356, A[1,0]=2.0302; nonlinear_dependence T=1024: H(x1|x0)=0.8608, H(x0|x1)=0.9217). (2) Prose 'uncertainty in y given x' does not say which matrix index is y; "
     "code: target = j (column), conditioning = i (row) - see already_documented M8. (3) 'width 0.5 SD' is the box half-width."),
 deviation_from_canonical="None beyond the shared estimator properties (resubstitution box kernel, self-inclusion, no bias correction; see infotheory.est.kernel).",
 units_and_range=("bits; with W=0.5 on z-scored data CE = -mean log2(C_xy/C_x) in [0, log2 T] (C_xy <= C_x), so non-negative; asymmetric; finite for finite input; diagonal NaN."),
 direction_convention="A[i,j] = h_hat(X_j | X_i) (entropy of column/target j given row/source i). Smaller A[i,j] = X_i more informative about X_j.",
 symmetry_expected="asym",
 already_documented="docs/storage_comparison/REVIEW.md M8 (ce is H(i,j) - H(i): conditioning order)",
 new_finding_candidates=[
   "Candidate (documentation label): supplement §1.4.2 and GitBook information-theory.md:48 list ce as 'undirected', but the class is Directed and values are asymmetric (probe nonlinear_dependence T=1024 A[0,1]=0.8608 vs A[1,0]=0.9217). Possibly overlaps REVIEW.md M9 (label structure); not listed there explicitly.",
   "Candidate (range): with W-0.5 on z-scored data the volume term log2(2*0.5*1) is 0, so ce_kernel equals -mean log2(C_xy/C_x) >= 0, unlike ce_gaussian/ce_kozachenko which can be negative. Evidence: numpy reference with this formula matched pyspi to 1.8e-15 (var2_bivariate T=256: 1.90003718262763).",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "bivariate_gaussian", "nonlinear_dependence", "delayed_noise", "var2_bivariate"], path="pipeline",
        reference=BOXREF_H + "; CE(i,j) = H([z_i,z_j]) - H(z_i), eps=0.5",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="All off-diagonal entries agree to abs <= 1e-12 (probe 1.8e-15)."),
   dict(datasets=["nonlinear_dependence"], path="pipeline",
        reference="analytic direction: x1 = x0^2 + 0.05 noise with x0 ~ U(-1,1): h(x1|x0) is the noise entropy (low) while h(x0|x1) keeps the sign ambiguity (+1 bit relative)",
        reference_kind="analytic", criterion="direction",
        expected_outcome="Direction convention A[i,j] = h(X_j|X_i): A[0,1] < A[1,0] at T >= 256 (probe T=1024: 0.8608 < 0.9217)."),
   dict(datasets=["bivariate_gaussian"], path="pipeline",
        reference="analytic box-kernel limit (rectangle probabilities of the bivariate normal, numerical integration) for h_box(X,Y) - h_box(X); Gaussian truth 0.5*log2(2 pi e (1-rho^2)) reported alongside",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="At T=4096, pair (2,3) (rho=0.8, truth 1.310 bits) and (0,1) (rho=0.3, truth 1.979 bits) within 0.05 bits of the box limit; box limit above truth by the smoothing bias."),
   dict(datasets=["iid_gaussian", "delayed_noise", "logistic_maps", "narrowband_f0-0.1"], path="pipeline",
        reference="analytic bound 0 <= CE <= log2 T for the volume-1 box on z-scored data",
        reference_kind="analytic", criterion="exact",
        expected_outcome="All entries in [-1e-12, log2 T]; no NaN."),
   dict(datasets=["bivariate_gaussian", "scaled_offset"], path="pipeline",
        reference="affine invariance after z-scoring (scaled_offset = scale*D2 + offset)",
        reference_kind="analytic", criterion="tolerance",
        expected_outcome="Matrices equal to abs <= 1e-12."),
 ])

# ---------------- MI ----------------
recs['infotheory.mi.kernel'] = dict(
 metric_name_standard="Mutual information I(X;Y) of contemporaneous samples, box-kernel plug-in estimate, bits",
 canonical_ref="Shannon CE (1948); Cover & Thomas (2006) Ch. 8 (I(X;Y) = h(X)+h(Y)-h(X,Y)); box-kernel estimator: Kantz & Schreiber (1997); Moon Y-I, Rajagopalan B, Lall U (1995) Phys Rev E 52:2318 (kernel MI)",
 canonical_definition="I(X;Y) = E[log2 p(x,y)/(p(x)p(y))]; box-kernel plug-in I_hat = (1/N) sum_b log2[ N C_xy(b) / (C_x(b) C_y(b)) ] (volumes cancel)",
 documented_definition=("supplement §1.4.3, p.10 (pack lines 469-476): 'Mutual information [33] is an undirected measure of the (potentially nonlinear) dependence between paired observations of x and y'; "
     "identifier 67 mi_kernel_W-0.25; keywords undirected, nonlinear, unsigned, bivariate, contemporaneous. " + SUPP14 + " (mi uses the non-default 0.25). GitBook information-theory.md:161-180."),
 delegate_lib="JIDT infodynamics.jar 1.6.1: infodynamics.measures.continuous.kernel.MutualInfoCalculatorMultiVariateKernel.computeAverageLocalOfObservations",
 implemented_as=("config.yaml:514-515 sets kernel_width 0.25. For pair (i,j): src = z_i, targ = z_j (1-D, T samples), initialise(1,1) with width 0.25; three KernelEstimatorMultiVariate objects (source, dest, joint) "
     "with half-widths 0.25*sampleSD of each column; I = mean_b log2[(C_xy/(N V_xy)) / ((C_x/(N V_x))(C_y/(N V_y)))] = mean_b log2(N C_xy / (C_x C_y)); closed boxes, self-included, "
     "no Theiler window (dyn_corr_excl None for this config), no noise (NOISE_LEVEL_TO_ADD default 0), no bias correction. Any exception -> NaN with a warning."),
 implementation_trace=PIPE + [UNDIR, PB] + BASE + [
   "pyspi/statistics/infotheory.py:113-115,134 _getcalc('MutualInfo') -> kernel.MutualInfoCalculatorMultiVariateKernel; config pyspi/config.yaml:514-515 kernel_width 0.25",
   "pyspi/statistics/infotheory.py:253-283 MutualInfo(JIDTBase, Undirected).bivariate: _set_theiler_window (no-op, :195-220 with _dyn_corr_excl None); initialise(1, 1); src, targ = data.to_numpy(squeeze=True)[[i, j]]; setObservations(JArray src, JArray targ); computeAverageLocalOfObservations; bare except -> NaN (:279-283)",
   "JIDT v1.6.1 " + J + "measures/continuous/kernel/MutualInfoCalculatorMultiVariateKernel.java: initialise(int,int) L112-137 (source/dest/joint estimators with kernelWidth), finaliseAddObservations L139-164, normaliseData no-op L166-171 (normalisation only via kernel widths), computeAverageLocalOfObservations L178-200 (mean ln(probJoint/(prob1*prob2))/ln 2), setProperty L655-692",
   "JIDT v1.6.1 " + J + "measures/continuous/MutualInfoMultiVariateCommon.java: setProperty L201-229 (noise off unless NOISE_LEVEL_TO_ADD set; NOISE_SEED unknown -> ignored), finaliseAddObservations L477-532 (timeDiff 0)",
   ] + JENT[1:],
 deviation_from_documented="None in substance (width 0.25 is stated in the identifier; JIDT's own default is also 0.25). 'Width' is the box half-width.",
 deviation_from_canonical=("Estimator properties only: resubstitution box-kernel plug-in, self-inclusion, no bias correction -> positive small-sample bias under independence "
     "(probe iid_gaussian mean 0.739/0.272/0.093/0.030 bits at T=64/256/1024/4096) and smoothing bias for strong dependence (bivariate_gaussian T=4096: rho=0.8 0.734 vs true 0.737 bits; rho=0.3 0.097 vs 0.068)."),
 units_and_range="bits; average of log-ratios, typically >= 0 but not guaranteed non-negative; <= log2 T; symmetric; NaN only on exception.",
 direction_convention="Undirected: A[i,j] = A[j,i]; estimator symmetric in its arguments and Undirected.multivariate mirrors (probe: exact symmetry on delayed_noise and var2_bivariate T=1024).",
 symmetry_expected="sym",
 already_documented="no",
 new_finding_candidates=[
   "Candidate (estimator bias magnitude): under independence mi_kernel_W-0.25 is clearly positive at small T (iid_gaussian means 0.739, 0.272, 0.093, 0.030 bits at T=64, 256, 1024, 4096), comparable to or larger than a rho=0.3 Gaussian dependence (true 0.068 bits); values are not comparable across T.",
   "Candidate (error handling): the bare 'except:' at infotheory.py:279-283 converts any failure to NaN with a message about Cholesky factorisation, which is irrelevant to the kernel estimator.",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "bivariate_gaussian", "nonlinear_dependence", "delayed_noise", "contaminated"], path="pipeline",
        reference="from-scratch numpy box-kernel MI: w = 0.25*std(ddof=1) per variable; C_x, C_y, C_xy closed max-norm counts incl. self; I = mean log2(N C_xy/(C_x C_y))",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="All off-diagonal entries agree to abs <= 1e-12 (probe 5.6e-17 on var2_bivariate T=256)."),
   dict(datasets=["bivariate_gaussian"], path="pipeline",
        reference="analytic Gaussian MI -0.5*log2(1-rho^2) (true_mi_nats/ln2 in the dataset: 0.068, 0.737 bits)",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="Converges towards truth as T grows; at T=4096 |MI(2,3) - 0.737| < 0.03 and MI(0,1) within 0.05 above 0.068 (probe 0.734, 0.097)."),
   dict(datasets=["iid_gaussian"], path="pipeline",
        reference="analytic null I = 0",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="Positive null bias decreasing roughly like 1/T (probe means 0.739, 0.272, 0.093, 0.030); documents the bias, not a pass/fail on zero."),
   dict(datasets=["nonlinear_dependence"], path="pipeline",
        reference="qualitative: x1 = x0^2 + noise and the circle pair have Pearson ~ 0 but strong dependence",
        reference_kind="analytic", criterion="qualitative",
        expected_outcome="MI(0,1) and MI(2,3) far above cross pairs (probe T=1024: 1.646 and 1.205 vs 0.016-0.032)."),
   dict(datasets=["var2_bivariate", "delayed_noise", "iid_gaussian"], path="pipeline",
        reference="analytic symmetry A vs A.T and fresh bivariate(i,j) vs bivariate(j,i)",
        reference_kind="analytic", criterion="direction",
        expected_outcome="Direction convention: undirected; exact equality both ways."),
   dict(datasets=["scaled_offset", "bivariate_gaussian"], path="kernel",
        reference="scale invariance of box counts when widths scale with the SD: raw-array bivariate(x, y) and normalise=False Data both equal the z-scored value",
        reference_kind="analytic", criterion="tolerance",
        expected_outcome="Equal to abs <= 1e-12 (MI is unaffected by the parse_bivariate single-array z-scoring quirk)."),
 ])

# ---------------- TLMI ----------------
recs['infotheory.tlmi.kernel'] = dict(
 metric_name_standard="Lag-1 time-delayed mutual information I(X_{t-1}; Y_t), box-kernel plug-in, bits",
 canonical_ref="Schreiber T (2000) Phys Rev Lett 85:461 (time-delayed MI as the symmetric-in-information precursor of TE); Kaiser A, Schreiber T (2002) Physica D 166:43-62; Fraser AM, Swinney HL (1986) Phys Rev A 33:1134 (lagged MI); estimator Kantz & Schreiber (1997)",
 canonical_definition="I(X_{t-1}; Y_t) = E[log2 p(x_{t-1}, y_t)/(p(x_{t-1}) p(y_t))]; box-kernel plug-in mean log2(N C_xy/(C_x C_y)) over the N = T-1 aligned pairs",
 documented_definition=("supplement §1.4.4, p.10 (pack lines 477-485): 'Time-lagged mutual information [35] is an undirected measure of the dependence between time series x and a time-lagged instance of the series y. "
     "We include statistics for only lag-one mutual information'; keywords undirected, ..., time-dependent; identifier 71 tlmi_kernel_W-0.25. GitBook information-theory.md:235-254 calls it 'a directed measure' with keyword directed."),
 delegate_lib="JIDT infodynamics.jar 1.6.1: MutualInfoCalculatorMultiVariateKernel.computeAverageLocalOfObservations",
 implemented_as=("config.yaml:537-538 width 0.25. For (i,j): src = z_i[:-1] (x_{t-1}), targ = z_j[1:] (y_t), T-1 pairs; same kernel MI as mi (half-widths 0.25*sampleSD of each lagged sub-series, closed box, self-included). "
     "A[i,j] = I(X_i,t-1 ; X_j,t). Any exception -> NaN."),
 implementation_trace=PIPE + [PB] + BASE + [
   "pyspi/statistics/infotheory.py:113-115,134 _getcalc('MutualInfo') -> kernel.MutualInfoCalculatorMultiVariateKernel; pyspi/config.yaml:537-538 kernel_width 0.25",
   "pyspi/statistics/infotheory.py:286-317 TimeLaggedMutualInfo(JIDTBase, Directed).bivariate: initialise(1,1); src, targ = data.to_numpy(squeeze=True)[[i, j]]; src = src[:-1]; targ = targ[1:]; setObservations; computeAverageLocalOfObservations; bare except -> NaN",
   "JIDT v1.6.1 " + J + "measures/continuous/kernel/MutualInfoCalculatorMultiVariateKernel.java: initialise L112-137, finaliseAddObservations L139-164, computeAverageLocalOfObservations L178-200",
   ] + JENT[1:],
 deviation_from_documented="Keyword 'undirected' (supplement §1.4.4) vs Directed class and asymmetric output; GitBook says directed (already documented, M8). Otherwise matches (lag one, width 0.25 in identifier).",
 deviation_from_canonical="None beyond the shared estimator properties (resubstitution box kernel, self-inclusion, no bias correction; positive null bias, probe iid_gaussian means 0.775/0.290/0.097/0.028 bits at T=64/256/1024/4096).",
 units_and_range="bits; typically >= 0 (not guaranteed); <= log2(T-1); asymmetric; NaN only on exception.",
 direction_convention="A[i,j] = I(X_i at t-1 ; X_j at t): row i is the lagged (source) series, column j the present (target). Probe delayed_noise T=1024 (x1 = x0 delayed by 1): A[0,1] = 2.647, A[1,0] = 0.064.",
 symmetry_expected="asym",
 already_documented="docs/storage_comparison/REVIEW.md M8 (tlmi is asymmetric by construction)",
 new_finding_candidates=[
   "Candidate (documentation inconsistency, partially covered by M8): supplement §1.4.4 keyword 'undirected' vs GitBook 'directed' vs code Directed; M8 records the asymmetry but not the supplement/GitBook disagreement.",
   "Candidate (error handling): bare except at infotheory.py:313-317 returns NaN with an irrelevant 'Cholesky factorisation' message.",
 ],
 proposed_checks=[
   dict(datasets=["iid_gaussian", "delayed_noise", "var2_bivariate", "gauss_ar1_pair", "logistic_maps"], path="pipeline",
        reference="from-scratch numpy box-kernel MI (eps=0.25, ddof=1 SDs of the lagged sub-series, closed box incl. self) on (z_i[:-1], z_j[1:])",
        reference_kind="independent-impl", criterion="tolerance",
        expected_outcome="All off-diagonal entries agree to abs <= 1e-12 (probe 1.1e-16)."),
   dict(datasets=["delayed_noise"], path="pipeline",
        reference="analytic: x1(t) = x0(t-1) + 0.1 noise; x0 white",
        reference_kind="analytic", criterion="direction",
        expected_outcome="Direction convention A[i,j] = I(X_i,t-1; X_j,t): A[0,1] >> A[1,0] (probe T=1024 2.647 vs 0.064); A[0,2], A[0,3] (delays 3, 5) near the null level."),
   dict(datasets=["gauss_ar1_pair", "var2_bivariate"], path="pipeline",
        reference="analytic Gaussian lag-1 MI from the stationary covariance: -0.5*log2(1 - c^2), c = Cov(x_i,t-1, x_j,t)/sqrt(var_i var_j) (gauss_ar1_pair: Sigma_XY = A Sigma_X; var2_bivariate: lag-1 autocovariance from Gamma0, A1, A2)",
        reference_kind="analytic", criterion="statistical",
        expected_outcome="At T=4096 within 0.05 bits above the Gaussian value for both directions; ordering of A[0,1] vs A[1,0] matches the analytic ordering."),
   dict(datasets=["iid_gaussian"], path="pipeline",
        reference="analytic null 0", reference_kind="analytic", criterion="statistical",
        expected_outcome="Positive null bias decreasing with T (probe means 0.775, 0.290, 0.097, 0.028)."),
 ])

for uid, c in recs.items():
    dump(dict(unit_id=uid, status='traced', correctness=c), OUT + uid + '.yaml')
    print('wrote', uid)
