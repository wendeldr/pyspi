import yaml

class Folded(str):
    pass

def _str_rep(dumper, data):
    if len(data) > 90 and '\n' not in data:
        return dumper.represent_scalar('tag:yaml.org,2002:str', data, style='>')
    return dumper.represent_scalar('tag:yaml.org,2002:str', data)

class D(yaml.SafeDumper):
    pass
D.add_representer(str, _str_rep)

def dump(rec, path):
    txt = yaml.dump(rec, Dumper=D, sort_keys=False, width=110, allow_unicode=True)
    open(path, 'w').write(txt)
    # round-trip check
    back = yaml.safe_load(open(path).read())
    assert back == rec, path

J = "https://raw.githubusercontent.com/jlizier/jidt/v1.6.1/java/source/infodynamics/"
PIPE = [
    "pyspi/calculator.py:47-48 Calculator(..., detrend=False, normalise=True) defaults",
    "pyspi/calculator.py:264 Data(Data.convert_to_numpy(dataset), normalise=self._normalise, detrend=self._detrend)",
    "pyspi/data.py:193-195 scipy.stats.zscore(data, axis=1, nan_policy='omit', ddof=1) (each series: mean 0, sample SD 1)",
    "pyspi/calculator.py:294 S = self._spis[spi].multivariate(self.dataset); :297 np.fill_diagonal(S, np.nan)",
    "pyspi/base.py:85-94 Directed.multivariate: A[i,j] = self.bivariate(data, i=i, j=j) for every i != j",
]
UNDIR = "pyspi/base.py:132-138 Undirected.multivariate: calls Directed.multivariate then A[li] = A.T[li] (upper triangle mirrored to lower)"
PB = "pyspi/base.py:27-47 parse_bivariate (Data objects pass through; raw arrays are wrapped by Data()/add_process)"
BASE = [
    "pyspi/statistics/infotheory.py:28-58 JIDTBase.__init__: estimator='kernel' -> identifier += '_W-{kernel_width}', labels += ['nonlinear']; JIDTBase default kernel_width=0.5; _entropy_calc built at :36",
    "pyspi/statistics/infotheory.py:84-93 _setup: calc.setProperty('KERNEL_WIDTH', str(kernel_width)); also BIAS_CORRECTION='false' and NOISE_SEED='42' (no effect on the kernel calculators, see infotheory.est.kernel)",
]
GETENT = "pyspi/statistics/infotheory.py:103-106,134 _getcalc('entropy') -> infodynamics.measures.continuous.kernel.EntropyCalculatorMultiVariateKernel (then _setup)"
CONDENT = "pyspi/statistics/infotheory.py:180-193 _compute_conditional_entropy(X, Y): H(concat[X, Y]) - H(Y) with the shared kernel entropy calculator (initialise(dim) then setObservations then computeAverageLocalOfObservations, twice)"
JENT = [
    "JIDT v1.6.1 " + J + "measures/continuous/kernel/EntropyCalculatorMultiVariateKernel.java: initialise(int) L115-136 (uses kernelWidth set by setProperty L247-270; unknown properties ignored), setObservations L139-155, computeAverageLocalOfObservations L157-170 = -(1/N) sum_b ln p(x_b) / ln 2 (bits)",
    "JIDT v1.6.1 " + J + "measures/continuous/kernel/KernelEstimatorMultiVariate.java: setObservations L189-242 kernelWidthsInUse[d] = width * MatrixUtils.stdDev(data, d) (normalise=true by default, L72), kernelVolumeInUse = prod_d 2*kernelWidthsInUse[d] (L215-219); getProbability L388-394 -> getProbabilityFromBins L732-738 or getProbabilityComparingToAll L811-817 = count / N / kernelVolume; getCountFromBins L589-719 counts the query's own bin (self included) plus +-1 neighbour bins; stepKernel L959-967 returns 0 only when |dx_d| > w_d in some dimension (closed max-norm box)",
    "JIDT v1.6.1 " + J + "utils/MatrixUtils.java: stdDev(double[][], int) L2384-2393 -> stdDev(double[][], int, double) L2436-2447 divides by (n-1) (sample SD)",
]
EMB = "JIDT v1.6.1 " + J + "utils/MatrixUtils.java: makeDelayEmbeddingVector(double[], int k) L2084-2092 -> L2140-2158: rows t = k-1..T-1, row = [v_t, v_{t-1}, ..., v_{t-k+1}] (k = 0 gives T+1 zero-width rows)"
SUPP14 = ("supplement §1.4, p.9 (pack lines 414-453): 'Kernel estimation (kernel) uses a box kernel method with a specific kernel "
          "width (default width of 0.5 standard deviations (denoted by the modifier W-0.5))'; GitBook information-theory.md:14 same sentence")
