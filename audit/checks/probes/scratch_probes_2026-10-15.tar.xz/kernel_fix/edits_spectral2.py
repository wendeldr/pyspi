EDITS = [
('''    values converge to the same scale-dependent fixed point).  On an exactly factorisable S
    (e.g. a VAR's S_true) the fixed point is the true factor.''',
'''    values converge to the same scale-dependent fixed point).  On the exact VAR spectrum
    S_true the fixed point is the true factor (selftest (3): max|H - H_true| <= 4.6e-15).'''),
]
