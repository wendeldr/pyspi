"""Search for a pair whose pyspi sigonly kept window is empty (fzr = fzf = 0), then show the replica flag."""
import sys
import numpy as np
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs")
import _kernels_basic_misc as kn
z1 = lambda v: (v - v.mean()) / v.std(ddof=1)
rng = np.random.default_rng(0)
found = None
for it in range(20000):
    T = int(rng.integers(16, 64))
    e = rng.standard_normal(T + 50)
    phi = rng.uniform(0.8, 0.999)
    a = np.zeros_like(e)
    for t in range(1, e.size): a[t] = phi * a[t - 1] + e[t]
    a = a[50:]
    m = int(rng.integers(1, T // 4 + 2))
    b = np.convolve(a, np.ones(m), "full")[:T] + rng.uniform(0, 3) * rng.standard_normal(T)
    x, y = (z1(b), z1(a)) if rng.random() < 0.5 else (z1(a), z1(b))
    r = kn.pyspi_xcorr_replica(x, y)
    if "sig_error" not in r and r["fzr"] == 0 and r["fzf"] == 0:
        found = (it, T, r); break
if found:
    it, T, r = found
    print(f"found at draw {it}, T={T}: fzr {r['fzr']} fzf {r['fzf']} max_sig {r['max_sig']} mean_sig {r['mean_sig']} "
          f"max_sig_error {r.get('max_sig_error')!r}")
    w = r["r_window"]; N = r["centre_index"]; kept = w[N - r["fzr"]:N + r["fzf"]]
    try:
        np.max(kept); print("np.max did not raise")
    except ValueError as exc:
        print("pyspi-style np.max on the kept window raises:", exc)
else:
    print("no empty-window pair found")
