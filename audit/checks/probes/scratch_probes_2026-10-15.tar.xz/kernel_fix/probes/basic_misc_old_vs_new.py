"""Comparison venv: old (saved) vs new _kernels_basic_misc for every changed function."""
import sys, importlib.util, warnings
import numpy as np
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks"); sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs")
import make_data as md
import _kernels_basic_misc as kn
spec = importlib.util.spec_from_file_location("ko", sys.argv[1]); ko = importlib.util.module_from_spec(spec); spec.loader.exec_module(ko)
z1 = lambda v: (v - v.mean()) / v.std(ddof=1)

# --- pdist braycurtis / all metrics: bitwise equal, braycurtis silent with +inf / NaN
X = np.array([[1.0, -2, 3], [-1, 2, -3], [0, 0, 0], [0, 0, 0], [1, 2, 3.5]])
for m in ("euclidean", "cityblock", "chebyshev", "cosine", "canberra", "braycurtis"):
    with warnings.catch_warnings(record=True) as wo:
        warnings.simplefilter("always"); a = ko.pdist_metric(X, m)
    with warnings.catch_warnings(record=True) as wn:
        warnings.simplefilter("always"); b = kn.pdist_metric(X, m)
    print(f"pdist {m:10s} bitwise equal {np.array_equal(a, b, equal_nan=True)}; warnings old {len(wo)} new {len(wn)}"
          + (f"; braycurtis[0,1] {b[0, 1]}, [2,3] {b[2, 3]}" if m == "braycurtis" else ""))
for ds in ("bivariate_gaussian", "iid_gaussian", "shared_envelope"):
    Z = np.stack([z1(v) for v in md.load(ds, 256)["x"]])
    print(f"pdist on {ds}: all metrics bitwise equal",
          all(np.array_equal(ko.pdist_metric(Z, m), kn.pdist_metric(Z, m), equal_nan=True)
              for m in ("euclidean", "cityblock", "chebyshev", "cosine", "canberra", "braycurtis")))

# --- xcorr replica: every old key/value unchanged; new key only when kept window empty
n_same, n_empty, n_pairs = 0, 0, 0
for ds in ("delayed_noise", "iid_gaussian", "var2_bivariate", "bivariate_gaussian", "narrowband_f0-0.25", "cointegrated"):
    for T in (64, 256, 1024):
        Z = np.stack([z1(v) for v in md.load(ds, T)["x"]])
        for a in range(Z.shape[0]):
            for b in range(Z.shape[0]):
                if a == b: continue
                ro, rn = ko.pyspi_xcorr_replica(Z[a], Z[b]), kn.pyspi_xcorr_replica(Z[a], Z[b])
                n_pairs += 1
                same = all((ro[k] == rn[k]) if isinstance(ro[k], str) else np.array_equal(np.asarray(ro[k]), np.asarray(rn[k]), equal_nan=True) for k in ro)
                extra = set(rn) - set(ro)
                n_same += same
                if extra:
                    n_empty += 1
                    assert extra == {"max_sig_error"} and np.isnan(rn["max_sig"]) and np.isnan(rn["mean_sig"]), (ds, T, a, b)
print(f"xcorr replica: {n_pairs} ordered pairs, old fields identical {n_same}, empty-window pairs flagged {n_empty}")
# constructed empty window: |r| significant everywhere except at lag +1 and the far-left lag
T = 256; rng = np.random.default_rng(1)
x = np.cumsum(rng.standard_normal(T)); x = z1(x)
r = kn.pyspi_xcorr_replica(x, x)
print("random-walk self pair: fzr", r.get("fzr"), "fzf", r.get("fzf"), "sig_error" in r, "max_sig_error" in r)

# --- engle_granger_tstat: default unchanged, return_lag consistent
ci = md.load("cointegrated", 1024)["x"]
for (i, j) in ((0, 1), (2, 3), (1, 0)):
    for tr in ("n", "c", "ct"):
        for al in ("aic", "bic", None):
            to = ko.engle_granger_tstat(ci[i], ci[j], trend=tr, maxlag=10, autolag=al)
            tn = kn.engle_granger_tstat(ci[i], ci[j], trend=tr, maxlag=10, autolag=al)
            tl, L = kn.engle_granger_tstat(ci[i], ci[j], trend=tr, maxlag=10, autolag=al, return_lag=True)
            assert to == tn == tl, (i, j, tr, al)
print("engle_granger_tstat: default == old == return_lag t, bitwise, 27 combos; example lag", L)
print("perfect fit:", kn.engle_granger_tstat(ci[0], 2 * ci[0] + 1, return_lag=True), ko.engle_granger_tstat(ci[0], 2 * ci[0] + 1))

# --- GP: lml value/gradient old vs new; eval_gradient=False; gradient vs alternative; gp_fit unchanged
an = md.load("anm", 64)["x"]
gx, gy = z1(an[0]), z1(an[1])
worst_v = worst_g = worst_alt = 0.0
for kern in ("RBF", "DotProduct"):
    for th in (np.log([1.3, 0.4, 0.7]), np.zeros(3), np.log([5.0, 1e-3, 0.05]), np.log([0.2, 2.0, 3.0])):
        kp = kn._gp_params(kern, th)
        vo, go = ko.gp_log_marginal_likelihood(gx, gy, kp)
        vn, gn = kn.gp_log_marginal_likelihood(gx, gy, kp)
        v0 = kn.gp_log_marginal_likelihood(gx, gy, kp, eval_gradient=False)
        worst_v = max(worst_v, abs(vo - vn), abs(vo - v0)); worst_g = max(worst_g, np.abs(go - gn).max())
        # alternative gradient without the explicit inverse: 0.5 (a' dK a - tr(L^-T L^-1 dK)) via solves
        from scipy import linalg as sla
        K, dK = kn._gp_kernel(gx, gx, kp, True); K[np.diag_indices_from(K)] += 1e-10
        L = np.linalg.cholesky(K); a = sla.cho_solve((L, True), gy)
        alt = np.array([0.5 * (a @ dK[..., k] @ a - np.trace(sla.cho_solve((L, True), dK[..., k]))) for k in range(3)])
        worst_alt = max(worst_alt, np.abs(alt - gn).max() / max(1.0, np.abs(gn).max()))
print(f"GP lml: max |old - new| value {worst_v:.1e} (incl. eval_gradient=False), gradient {worst_g:.1e}; "
      f"gradient vs inverse-free solve form (rel) {worst_alt:.1e}")
for kern in ("RBF", "DotProduct"):
    for ds, T in (("anm", 64), ("nonlinear_dependence", 64), ("bivariate_gaussian", 64)):
        d = md.load(ds, T)["x"]; x, y = z1(d[0]), z1(d[1])
        ko_kp, ko_l, ko_g = ko.gp_fit(x, y, kern)
        kn_kp, kn_l, kn_g = kn.gp_fit(x, y, kern)
        print(f"gp_fit {kern:10s} {ds:20s}: params equal {ko_kp == kn_kp}, lml equal {ko_l == kn_l}, grad equal {np.array_equal(ko_g, kn_g)}")
# failed Cholesky: old raises, new returns -inf
xx = np.linspace(-3, 3, 400) * 50; yy = np.sin(xx)
kp_bad = kn._gp_params("DotProduct", np.log([1e5, 1e-5, 1e5]))
try:
    ko.gp_log_marginal_likelihood(xx, yy, kp_bad); print("bad theta: old lml did not raise")
except np.linalg.LinAlgError:
    print("bad theta: old gp_log_marginal_likelihood raises LinAlgError; guarded:", kn._gp_lml_guarded(xx, yy, kp_bad)[0])
