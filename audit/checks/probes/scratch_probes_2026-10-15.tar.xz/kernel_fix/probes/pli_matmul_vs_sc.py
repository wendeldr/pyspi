"""Project venv. (a) kernel phase-lag measures, default vs matmul=True, against spectral_connectivity
fed the SAME kernel coefficients (diagonal included); (b) old kernel (saved copy) default == new default
bit-for-bit; (c) matmul zero pattern vs the explicit 1e-12 tie rule of refs/spectral_phase_sync.py:csm."""
import sys, importlib.util
import numpy as np
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks")
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs")
import make_data as md
import _kernels_spectral as ks
spec = importlib.util.spec_from_file_location("ks_old", sys.argv[1])
ko = importlib.util.module_from_spec(spec); spec.loader.exec_module(ko)
from spectral_connectivity import Connectivity

names = {"pli": ("phase_lag_index", "phase_lag_index"), "wpli": ("weighted_phase_lag_index", "weighted_phase_lag_index"),
         "dspli": ("debiased_squared_pli", "debiased_squared_phase_lag_index"),
         "dswpli": ("debiased_squared_wpli", "debiased_squared_weighted_phase_lag_index")}

def cmp(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    nan_eq = np.array_equal(np.isnan(a), np.isnan(b))
    m = ~np.isnan(a) & ~np.isnan(b)
    return nan_eq, float(np.abs(a[m] - b[m]).max()) if m.any() else 0.0

worst = {}
for ds, T in [("shared_envelope", 1024), ("shared_envelope", 256), ("delayed_noise", 1024), ("iid_gaussian", 256),
              ("var2_bivariate", 1024), ("narrowband_f0-0.25", 1024)]:
    x = np.asarray(md.load(ds, T)["x"], float)
    x = (x - x.mean(1, keepdims=True)) / x.std(1, ddof=1, keepdims=True)
    c, f = ks.multitaper_fft(x)
    conn = Connectivity(fourier_coefficients=c[None, None], expectation_type="trials_tapers")
    P = c.shape[-1]
    diag = np.eye(P, dtype=bool)
    for m, (kf, sf) in names.items():
        sc = np.asarray(getattr(conn, sf)())[0]                       # (nb, P, P)
        new_def = ks.nonneg(getattr(ks, kf)(c), 0)
        new_mm = ks.nonneg(getattr(ks, kf)(c, matmul=True), 0)
        old_def = ko.nonneg(getattr(ko, kf)(c), 0)
        same_old = np.array_equal(old_def, new_def, equal_nan=True)
        e_mm = cmp(new_mm, sc)
        e_def_off = cmp(new_def[:, ~diag], sc[:, ~diag])
        e_def_diag = cmp(new_def[:, diag], sc[:, diag])
        print(f"{ds:20s} T={T:4d} {m:6s} old==new default (bitwise) {same_old}; matmul vs SC all entries: nan_eq {e_mm[0]} "
              f"max {e_mm[1]:.1e}; default vs SC off-diag: nan_eq {e_def_off[0]} max {e_def_off[1]:.2e}; diag: nan_eq "
              f"{e_def_diag[0]} max {e_def_diag[1]:.2e}; SC diag values {np.unique(np.round(sc[:, diag], 12))[:4]}")
        worst[m] = max(worst.get(m, 0.0), e_mm[1])
    # (c) zero pattern: matmul Im == 0 vs tie rule (|Im| <= 1e-12 max_k |S|), non-DC bins, nonneg grid
    cn = ks.nonneg(c, 1)
    Sm = ks._per_obs_csm(cn, matmul=True)
    Se = ks._per_obs_csm(cn)
    thr = 1e-12 * np.abs(Se).max(axis=0, keepdims=True)
    tie = np.abs(Se.imag) <= thr
    zm = Sm.imag == 0
    print(f"   zero pattern (non-DC bins): tie-rule zeros {int(tie[:, 1:].sum())}, matmul exact zeros {int(zm[:, 1:].sum())}, "
          f"identical pattern {np.array_equal(tie[:, 1:], zm[:, 1:])}; tie off-diag non-DC {int(tie[:, 1:][:, :, ~diag].sum())}")
print("max |matmul - SC| per measure:", {k: f"{v:.1e}" for k, v in worst.items()})
