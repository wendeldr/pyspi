import difflib
from pathlib import Path
S = Path("/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad")
pairs = {"EntropyCalculatorMultiVariateKozachenko.java": (S/"it_kozachenko/jidt_src", S/"it_kozachenko/jidt_a9b6"),
         "KdTree.java": (S/"jidt_src", S/"it_kraskov/jidt_src_a9b6b3e"),
         "EntropyCalculatorMultiVariateKernel.java": (S/"jidt_src", S/"fable_it/jidt_a9b6"),
         "TransferEntropyCalculatorViaCondMutualInfo.java": (S/"jidt_src", S/"it_kraskov/jidt_src_a9b6b3e"),
         "ConditionalMutualInfoMultiVariateCommon.java": (S/"jidt_src", S/"it_kraskov/jidt_src_a9b6b3e")}
cites = {"EntropyCalculatorMultiVariateKozachenko.java": [(105, 115), (204, 212), (300, 321), (307, 321), (417, 426), (436, 474)],
         "KdTree.java": [(703, 704), (1076, 1078)],
         "EntropyCalculatorMultiVariateKernel.java": [(158, 169), (168, 168)],
         "TransferEntropyCalculatorViaCondMutualInfo.java": [(572, 597)],
         "ConditionalMutualInfoMultiVariateCommon.java": [(493, 494)]}
for f, (a, b) in pairs.items():
    old, new = (a / f).read_text().splitlines(), (b / f).read_text().splitlines()
    sm = difflib.SequenceMatcher(None, old, new, autojunk=False)
    mp = {}
    for blk in sm.get_matching_blocks():
        for k in range(blk.size): mp[blk.a + k] = blk.b + k
    for lo, hi in cites[f]:
        mapped = [mp.get(i - 1) for i in range(lo, hi + 1)]
        miss = [lo + k for k, m in enumerate(mapped) if m is None]
        got = [m + 1 for m in mapped if m is not None]
        print(f"{f}:{lo}-{hi} -> a9b6 {min(got) if got else None}-{max(got) if got else None}; unmatched v161 lines {miss}")
        for i in miss[:6]:
            print("     v161", i, old[i - 1].strip()[:100])
