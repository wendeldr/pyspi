"""Map every JIDT file:line cited in _kernels_infotheory.py from the v1.6.1 tag tree to the a9b6b3e tree."""
import re, difflib, sys
from pathlib import Path
S = Path("/tmp/claude-1000/-media-dan-Data-git-pyspi/5085b751-c4f7-4c35-9512-0b49510da359/scratchpad")
V161 = [S / "jidt_src", S / "it_kraskov/jidt_src", S / "it_kozachenko/jidt_src", S / "it_gaussian/jidt_src",
        S / "it_kernel/jidt_src", S / "fable_it/jidt_v161"]
A9B6 = [S / "it_kraskov/jidt_src_a9b6b3e", S / "fable_it/jidt_a9b6", S / "it_kozachenko/jidt_a9b6", S / "it_gaussian/jidt_a9b6"]
def find(trees, name):
    for t in trees:
        p = t / name
        if p.exists(): return p.read_text().splitlines()
    return None
src = Path("/media/dan/Data/git/pyspi/audit/checks/refs/_kernels_infotheory.py").read_text()
# collect citations "File.java:a-b, c" and "lines a-b" following a file mention
cites = []
for m in re.finditer(r"([A-Za-z0-9]+\.java)((?::\d+(?:-\d+)?)(?:,\s*:?\d+(?:-\d+)?)*)", src):
    f = m.group(1)
    for r in re.findall(r"(\d+)(?:-(\d+))?", m.group(2)):
        cites.append((f, int(r[0]), int(r[1] or r[0])))
seen = set()
for f, a, b in cites:
    if (f, a, b) in seen: continue
    seen.add((f, a, b))
    old, new = find(V161, f), find(A9B6, f)
    if old is None:
        print(f"{f}:{a}-{b}  v1.6.1 source not available"); continue
    snippet = " | ".join(l.strip() for l in old[a - 1:b])[:110]
    if new is None:
        print(f"{f}:{a}-{b}  [no a9b6 copy]  {snippet}"); continue
    if old == new:
        print(f"{f}:{a}-{b}  identical file  {snippet}"); continue
    sm = difflib.SequenceMatcher(None, old, new, autojunk=False)
    mp = {}
    for blk in sm.get_matching_blocks():
        for k in range(blk.size): mp[blk.a + k] = blk.b + k
    ok = all((i - 1) in mp for i in range(a, b + 1))
    if ok:
        na, nb = mp[a - 1] + 1, mp[b - 1] + 1
        print(f"{f}:{a}-{b}  CHANGED FILE -> a9b6 :{na}-{nb} (text same)  {snippet}")
    else:
        print(f"{f}:{a}-{b}  CHANGED FILE, cited lines edited  {snippet}")
