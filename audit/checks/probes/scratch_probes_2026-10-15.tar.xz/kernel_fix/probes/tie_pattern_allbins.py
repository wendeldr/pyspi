"""Comparison venv: matmul exact-zero pattern of Im S vs the 1e-12 relative tie rule, ALL retained bins (DC included)."""
import sys
import numpy as np
sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks"); sys.path.insert(0, "/media/dan/Data/git/pyspi/audit/checks/refs")
import make_data as md, _kernels_spectral as ks
for ds, T in [("shared_envelope", 64), ("shared_envelope", 256), ("shared_envelope", 1024), ("delayed_noise", 1024),
              ("iid_gaussian", 256), ("var2_bivariate", 1024), ("narrowband_f0-0.25", 1024), ("narrowband_f0-0.25", 64)]:
    x = np.asarray(md.load(ds, T)["x"], float)
    for lab, z in (("kernel", x), ("zscored", (x - x.mean(1, keepdims=True)) / x.std(1, ddof=1, keepdims=True))):
        c = ks.nonneg(ks.multitaper_fft(z)[0], 1)
        Se, Sm = ks._per_obs_csm(c), ks._per_obs_csm(c, matmul=True)
        tie = np.abs(Se.imag) <= 1e-12 * np.abs(Se).max(axis=0, keepdims=True)
        print(f"{ds:20s} T={T:5d} {lab:8s} identical pattern {np.array_equal(tie, Sm.imag == 0)}  zeros {int(tie.sum())}")
