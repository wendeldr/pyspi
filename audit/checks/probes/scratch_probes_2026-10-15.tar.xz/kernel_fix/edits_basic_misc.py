EDITS = [
# ---- item 13: xcorr replica docs + empty-window flag
('''    np.where(...)[0][0] would raise IndexError in pyspi), max/mean statistics, and an
    'intended' variant (thr = 1.96/sqrt(T), contiguous block around lag 0 bounded by the
    first |r| <= thr on each side) so the offset/threshold hypotheses can be quantified."""''',
'''    np.where(...)[0][0] would raise IndexError in pyspi), max/mean statistics, and an
    'intended' variant (thr = 1.96/sqrt(T), contiguous block around lag 0 bounded by the
    first |r| <= thr on each side) so the offset/threshold hypotheses can be quantified.

    EMPTY KEPT WINDOW (fzr = fzf = 0): pyspi's ``np.max`` raises ValueError (zero-size
    array) and its ``np.mean`` returns NaN (pyspi/statistics/basic.py:122-131).  This
    replica does not raise, so the other fields stay available: it returns
    ``max_sig = mean_sig = NaN`` and adds ``max_sig_error`` naming pyspi's ValueError.
    Callers that need pyspi's outcome must test for that key (refs/xcorr.py:literal_stat
    raises its own status codes instead).

    The 'intended' variant is NOT a documented reading of the SPI.  It always includes
    lag 0 (even when |r(0)| <= thr), extends over the full lag range -(T-1)..T-1 rather
    than pyspi's +-T//4 window, and uses pyspi's scaled values (r(0) = Pearson r x T/(T-1)
    on ddof=1 z-scored input).  The documented reading (Brockwell & Davis sample CCF over
    |h| <= T//4, contiguous significant block around lag 0, empty block -> 0) is the
    ``canon`` reference of refs/xcorr.py."""'''),
('''        out.update(fzf=fzf, fzr=fzr, kept_lags=lags[N - fzr:N + fzf],
                   max_sig=float(kept.max()) if kept.size else np.nan,
                   mean_sig=float(kept.mean()) if kept.size else np.nan)
''',
'''        out.update(fzf=fzf, fzr=fzr, kept_lags=lags[N - fzr:N + fzf],
                   max_sig=float(kept.max()) if kept.size else np.nan,
                   mean_sig=float(kept.mean()) if kept.size else np.nan)
        if not kept.size:
            out["max_sig_error"] = "ValueError: empty kept window (pyspi np.max raises; np.mean gives NaN)"
'''),
# ---- item 11: pdist braycurtis errstate + cosine/braycurtis docs
('''    chebyshev max |u-v|; canberra sum |u-v|/(|u|+|v|) with 0/0 terms = 0;
    braycurtis sum |u-v| / sum |u+v|."""''',
'''    chebyshev max |u-v|; canberra sum |u-v|/(|u|+|v|) with 0/0 terms = 0;
    braycurtis sum |u-v| / sum |u+v|.

    braycurtis with a zero denominator (u = -v) returns +inf, or NaN when u = v = 0,
    without a RuntimeWarning.  cosine is evaluated literally as 1 - u.v/(|u||v|), which
    cancels for near-identical rows: relative error 5.4e-2 at a row difference of 1e-7 in
    the pdist check (audit/notes/pdist.md, distance.pdist.cosine).  refs/pdist.py:stable_metric
    is the cancellation-free form |u/|u| - v/|v||^2 / 2."""'''),
('''    if metric == "braycurtis":
        return np.sum(np.abs(D), -1) / np.sum(np.abs(U + V), -1)
''',
'''    if metric == "braycurtis":
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.sum(np.abs(D), -1) / np.sum(np.abs(U + V), -1)
'''),
# ---- item 15: engle_granger_tstat return_lag
('''def engle_granger_tstat(y0, y1, trend="c", maxlag=10, autolag="aic"):''',
'''def engle_granger_tstat(y0, y1, trend="c", maxlag=10, autolag="aic", return_lag=False):'''),
('''    uses L = maxlag.  maxlag > len//2 - 1 raises, as adfuller (:380)."""''',
'''    uses L = maxlag.  maxlag > len//2 - 1 raises, as adfuller (:380).
    return_lag=True returns (t, L) with the lag L used in the final regression; the
    R^2 early exit then returns (-inf, None)."""'''),
('''    if 1 - np.sum(e**2) / tss >= 1 - 100 * np.sqrt(EPS):
        return -np.inf
''',
'''    if 1 - np.sum(e**2) / tss >= 1 - 100 * np.sqrt(EPS):
        return (-np.inf, None) if return_lag else -np.inf
'''),
('''    s2 = u @ u / (dep.size - k)
    return float(beta[0] / np.sqrt(s2 * np.linalg.inv(Xa.T @ Xa)[0, 0]))
''',
'''    s2 = u @ u / (dep.size - k)
    t = float(beta[0] / np.sqrt(s2 * np.linalg.inv(Xa.T @ Xa)[0, 0]))
    return (t, L) if return_lag else t
'''),
# ---- item 12: elastic net / lasso docs
('''    One regressor -> exact minimiser w = S(sum(xc yc)/n, alpha rho) / (sum(xc^2)/n + alpha(1-rho)),
    S = soft threshold.  (sklearn's coordinate descent reaches it to its tol=1e-4.)"""''',
'''    One regressor -> exact minimiser w = S(sum(xc yc)/n, alpha rho) / (sum(xc^2)/n + alpha(1-rho)),
    S = soft threshold.

    This is the exact minimiser, NOT always what sklearn returns.  sklearn's coordinate
    descent first checks the duality gap at w = 0 and returns w = 0 (n_iter_ 0) when
    gap <= tol ||y_c||^2, tol = 1e-4 (sklearn/linear_model/_cd_fast.pyx:391-400).  With
    s = sum(xc yc)/n and a = alpha rho that gap is 0.5 ||y_c||^2 (1 - a/|s|)^2 for |s| > a,
    so sklearn returns w = 0 in the band a < |s| <= a / (1 - sqrt(2 tol)), where the exact
    minimiser is not 0.  On ddof=1 z-scored data with the defaults (alpha 1, l1_ratio 0.5)
    the band is 0.5T/(T-1) < |r| <= 0.5T/((T-1)(1 - sqrt(2e-4))); there this function's MSE
    is up to about 4.8e-3 below sklearn's (T-1)/T (audit/notes/lmfit.md).  Outside the band
    the first update lands on the minimiser and the next gap check stops there.
    refs/lmfit.py:enet_sklearn_tol models the exit."""'''),
('''    On ddof=1 z-scored data sum(xc yc)/n = r(T-1)/T, so w = 0 and MSE = (T-1)/T
    whenever |r|(T-1)/T <= alpha (always, for the default alpha = 1)."""''',
'''    On ddof=1 z-scored data sum(xc yc)/n = r(T-1)/T, so w = 0 and MSE = (T-1)/T
    whenever |r|(T-1)/T <= alpha (always, for the default alpha = 1).
    Matches sklearn only where sklearn's initial duality-gap exit and the exact minimiser
    coincide (see elasticnet_1d_mse; band alpha < |s| <= alpha / (1 - sqrt(2e-4))), which
    includes every pair of ddof=1 z-scored data at alpha = 1 (both give w = 0)."""'''),
# ---- item 14: GP kernel docs, eval_gradient, failed-Cholesky guard
('''# ============================================================ Gaussian processes
def _gp_kernel(x1, x2, kp, train):
    """Constant + White + {RBF | DotProduct}, sklearn parameterisation''',
'''# ============================================================ Gaussian processes
# Every gp_* function here uses the ADDITIVE kernel C + White + {RBF | DotProduct} that
# pyspi's GPModel builds (pyspi/statistics/misc.py:136-137).  That is not sklearn's default
# C() * RBF() (sklearn/gaussian_process/_gpr.py:249, used by cdt's ANM) and not C * RBF + White;
# for the product kernel use _kernels_distance.gp_posterior_mean / gp_fit_hyperparameters.
def _gp_kernel(x1, x2, kp, train):
    """Constant + White + {RBF | DotProduct} (a sum, not C * RBF), sklearn parameterisation'''),
('''def gp_log_marginal_likelihood(x, y, kernel_params, alpha=1e-10):
    """log p(y|X,theta) = -1/2 y^T K^-1 y - 1/2 log|K| - n/2 log 2 pi  (R&W eq. 5.8) and
    its gradient 1/2 tr((a a^T - K^-1) dK/dtheta_j), a = K^-1 y (R&W eq. 5.9), with respect
    to theta = log hyperparameters [c, w, l | sigma_0] (sklearn's space, _gpr.py:589-650)."""
    x, y = np.ravel(np.asarray(x, float)), np.ravel(np.asarray(y, float))
    K, dK = _gp_kernel(x, x, kernel_params, True)
    K[np.diag_indices_from(K)] += alpha
    L = np.linalg.cholesky(K)
    a = sla.cho_solve((L, True), y)
    lml = -0.5 * y @ a - np.sum(np.log(np.diag(L))) - 0.5 * x.size * np.log(2 * np.pi)
    inner = np.outer(a, a) - sla.cho_solve((L, True), np.eye(x.size))
''',
'''def gp_log_marginal_likelihood(x, y, kernel_params, alpha=1e-10, eval_gradient=True):
    """log p(y|X,theta) = -1/2 y^T K^-1 y - 1/2 log|K| - n/2 log 2 pi  (R&W eq. 5.8) and
    its gradient 1/2 tr((a a^T - K^-1) dK/dtheta_j), a = K^-1 y (R&W eq. 5.9), with respect
    to theta = log hyperparameters [c, w, l | sigma_0] (sklearn's space, _gpr.py:589-650).
    The value needs only a = cho_solve(L, y); the explicit K^-1 = cho_solve(L, I) is formed
    only for the gradient, as sklearn does (_gpr.py:629-632).  eval_gradient=False returns
    the value alone (float) and skips K^-1; the default returns (value, gradient).
    A failed Cholesky raises LinAlgError here; gp_fit maps it to -inf as sklearn does."""
    x, y = np.ravel(np.asarray(x, float)), np.ravel(np.asarray(y, float))
    K, dK = _gp_kernel(x, x, kernel_params, True)
    K[np.diag_indices_from(K)] += alpha
    L = np.linalg.cholesky(K)
    a = sla.cho_solve((L, True), y)
    lml = -0.5 * y @ a - np.sum(np.log(np.diag(L))) - 0.5 * x.size * np.log(2 * np.pi)
    if not eval_gradient:
        return float(lml)
    inner = np.outer(a, a) - sla.cho_solve((L, True), np.eye(x.size))
'''),
('''def gp_fit(x, y, kernel="RBF", bounds=(1e-5, 1e5)):
    """Type-II ML hyperparameters by L-BFGS-B on -lml from theta = log(1) with sklearn's
    default bounds and no restarts (_gpr.py:217, :659; kernels.py default values 1.0,
    bounds (1e-5, 1e5)).  Returns (kernel_params, lml, grad).  Local optimum only."""
    f = lambda t: tuple(-v for v in gp_log_marginal_likelihood(x, y, _gp_params(kernel, t)))
    lb = [(np.log(bounds[0]), np.log(bounds[1]))] * 3
    r = optimize.minimize(f, np.zeros(3), jac=True, method="L-BFGS-B", bounds=lb)
    kp = _gp_params(kernel, r.x)
    lml, g = gp_log_marginal_likelihood(x, y, kp)
    return kp, lml, g
''',
'''def _gp_lml_guarded(x, y, kp):
    """(lml, grad), or (-inf, 0) when the Cholesky of K + alpha I fails, as sklearn's
    log_marginal_likelihood (sklearn/gaussian_process/_gpr.py:590-593)."""
    try:
        return gp_log_marginal_likelihood(x, y, kp)
    except np.linalg.LinAlgError:
        return -np.inf, np.zeros(3)


def gp_fit(x, y, kernel="RBF", bounds=(1e-5, 1e5)):
    """Type-II ML hyperparameters by L-BFGS-B on -lml from theta = log(1) with sklearn's
    default bounds and no restarts (_gpr.py:217, :659; kernels.py default values 1.0,
    bounds (1e-5, 1e5)).  Additive kernel C + White + K (see the section note), not C * RBF.
    A failed Cholesky gives lml = -inf and a zero gradient (objective +inf) as in sklearn
    (_gpr.py:590-593) instead of raising; if the optimiser stops at such a point the
    returned lml is -inf.  Returns (kernel_params, lml, grad).  Local optimum only."""
    f = lambda t: tuple(-v for v in _gp_lml_guarded(x, y, _gp_params(kernel, t)))
    lb = [(np.log(bounds[0]), np.log(bounds[1]))] * 3
    r = optimize.minimize(f, np.zeros(3), jac=True, method="L-BFGS-B", bounds=lb)
    kp = _gp_params(kernel, r.x)
    lml, g = _gp_lml_guarded(x, y, kp)
    return kp, lml, g
'''),
]
