EDITS = [
('''    SC's formula.  ``matmul=True`` forms S as SC does and reproduces its exact zeros, hence
    SC's values at those entries: diagonal PLI = 0, wPLI = 0 (denominator floor),
    dsPLI = -1/(N-1), dswPLI = NaN (0/0).  Neither setting masks the diagonal; pyspi
    overwrites it with NaN (pyspi/calculator.py:332).  refs/spectral_phase_sync.py:csm
    instead zeroes Im S where ``|Im S| <= 1e-12 max_k |S|``; on its datasets that rule zeroed
    only the diagonal and the bit-identical shared_envelope pair."""''',
'''    SC's formula.  ``matmul=True`` forms S as SC does and reproduces its exact zeros, hence
    SC's values at those entries: diagonal PLI = 0, wPLI = 0 (denominator floor),
    dsPLI = -1/(N-1), dswPLI = NaN (0/0).  Fed the same kernel coefficients, SC and
    ``matmul=True`` agree exactly for PLI, wPLI and dsPLI and to 2.1e-14 for dswPLI, NaN
    pattern and diagonal included (shared_envelope T=256/1024, delayed_noise, iid_gaussian,
    var2_bivariate, narrowband_f0-0.25; scratchpad kernel_fix/probes/pli_matmul_vs_sc.py).
    Neither setting masks the diagonal; pyspi overwrites it with NaN
    (pyspi/calculator.py:332).  refs/spectral_phase_sync.py:csm instead zeroes Im S where
    ``|Im S| <= 1e-12 max_k |S|``; on those datasets (T = 64..1024, raw and z-scored) that
    rule zeroes exactly the entries where the matmul gives 0 (kernel_fix/probes/
    tie_pattern_allbins.py)."""'''),
('''    check("phase measures = 1 for locked coeffs (angle S_01 = +phi)", err < 1e-12, f"max |v-1| {err:.1e} over {list(vals)}")
''',
'''    check("phase measures = 1 for locked coeffs (angle S_01 = +phi)", err < 1e-12, f"max |v-1| {err:.1e} over {list(vals)}")
    # matmul=True: exact Im S = 0 on the diagonal and for a bit-identical channel (SC's values there);
    # elsewhere equal to the elementwise default to rounding
    cm = np.concatenate([co, co[..., :1]], axis=-1)                # channel 2 = bit-identical copy of 0
    fns = (phase_lag_index, weighted_phase_lag_index, debiased_squared_pli, debiased_squared_wpli)
    tied = np.array([[1, 0, 1], [0, 1, 0], [1, 0, 1]], bool)
    mm = [fn(cm, matmul=True) for fn in fns]
    exp_tied = (0.0, 0.0, -1.0 / (K - 1), np.nan)
    ok_t = all(np.array_equal(v[:, tied], np.full(v[:, tied].shape, e), equal_nan=True) for v, e in zip(mm, exp_tied))
    e_off = max(np.abs(v[:, ~tied] - fn(cm)[:, ~tied]).max() for v, fn in zip(mm, fns))
    check("matmul=True: tied entries PLI 0, wPLI 0, dsPLI -1/(K-1), dswPLI NaN; untied = default", ok_t and e_off < 1e-12,
          f"tied entries as SC {ok_t}; untied max |matmul - default| {e_off:.1e}")
'''),
]
