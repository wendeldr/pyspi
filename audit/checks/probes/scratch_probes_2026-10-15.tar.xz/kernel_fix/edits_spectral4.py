EDITS = [
('''    :1187-1190).  The two agree to rounding except where the exact Im S is 0: on the
    diagonal and for bit-identical channels the matmul returns Im S exactly 0, as SC does,
    while the elementwise product leaves rounding noise of order 1e-16..1e-15 (numpy 2.5.4
    in both venvs; ``tie_*`` keys of out/results/spectral_phase_sync.json).  Only the
    sign- and Im-based phase-lag measures below are sensitive to that noise."""''',
'''    :1187-1190).  The two agree to rounding.  They differ in kind only where the exact
    Im S is 0: on the diagonal and for bit-identical channels the matmul returns Im S
    exactly 0, as SC does, while the elementwise product leaves rounding noise of order
    1e-16..1e-15 (numpy 2.5.4 in both venvs; scratchpad kernel_fix/probes/
    pli_matmul_vs_sc.py, and the ``tie_*`` keys of out/results/spectral_phase_sync.json
    for the elementwise noise).  Only the sign- and Im-based phase-lag measures below are
    sensitive to that noise."""'''),
('''    channels Im S is rounding noise where SC has exactly 0.  The sign of that noise is
    arbitrary, and those entries differ from SC by O(1): 1.25 for dsPLI on the
    bit-identical pair (0, 2) of shared_envelope T=1024 (``ref_no_tie_rule_max_abs_diff_pair02``''',
'''    channels Im S is rounding noise where SC has exactly 0.  The sign of that noise is
    arbitrary, so those entries can differ from SC by O(1): 1.25 for dsPLI on the
    bit-identical pair (0, 2) of shared_envelope T=1024 (``ref_no_tie_rule_max_abs_diff_pair02``'''),
('''    step < 1, e.g. fmin == fmax (SC ZeroDivisionError, :1095-1101).  With pyspi's
    band (0, 0.5) the first case needs T <= 4 (n_fft = 4 leaves one bin, f = 0.25)."""''',
'''    step < 1, e.g. fmin == fmax (SC ZeroDivisionError, :1095-1101).  With pyspi's
    band (0, 0.5) the first case needs T <= 4 (at most one strictly interior bin,
    e.g. f = 0.25 at T = 4)."""'''),
('''    LOG FORM: ``ln S_ii - ln intr`` with ``intr == 0`` replaced by eps, exactly SC's
    ``_estimate_predictive_power`` (SC/connectivity.py:1173-1180).  nitime, which pyspi's
    parametric SGC calls, takes ``ln(S_ii / intr)`` (nitime/algorithms/autoregressive.py:499,
    :509).  The two agree whenever S_ii > 0 and intr > 0.  They differ where intr == 0
    (finite here, +inf in nitime) and where S_ii and intr are both negative (NaN here,
    finite in nitime); intr < 0 with S_ii > 0 is NaN in both.  For the nitime form use
    refs/sgc.py:geweke_ratio."""''',
'''    LOG FORM: ``ln S_ii - ln intr`` with S_ii taken from the supplied S and ``intr == 0``
    replaced by eps, exactly SC's ``_estimate_predictive_power`` (SC/connectivity.py:
    1173-1180).  nitime, which pyspi's parametric SGC calls, instead forms both terms from
    the fitted model, S_ii = auto + cross with intr = the auto term sigma |H_hat|^2 >= 0,
    and takes ``ln(S_ii / intr)`` (nitime/algorithms/autoregressive.py:495-499, :505-509).
    With S = H Sigma H^H the two forms agree wherever intr > 0 and differ where intr == 0
    (finite here, +inf in nitime).  With a supplied S that is not H Sigma H^H (a multitaper
    CSM with an inexact Wilson factor) intr can be negative, and this function returns NaN
    there.  refs/sgc.py:geweke_ratio is the nitime-style form (S from H and Sigma, ratio,
    no clipping)."""'''),
]
