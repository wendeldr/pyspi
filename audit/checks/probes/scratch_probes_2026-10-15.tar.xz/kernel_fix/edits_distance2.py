EDITS = [
('''    comparison venv (scipy 1.18.1) and by 6.6e-16 when the same replica runs in the project venv (scipy 1.17.1): LAPACK
    roundoff amplified by the near-interpolating fit, not a replica difference. The fit is also BLAS-thread sensitive:''',
'''    comparison venv (scipy 1.18.1) and by 6.6e-16 when the same replica runs in the project venv (scipy 1.17.1): LAPACK
    roundoff amplified by the estimator, not a replica defect. The fit is also BLAS-thread sensitive:'''),
]
