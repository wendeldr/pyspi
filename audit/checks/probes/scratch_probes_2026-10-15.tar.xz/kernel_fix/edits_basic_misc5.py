EDITS = [
('''    only for the gradient, as sklearn does (_gpr.py:629-632).  eval_gradient=False returns''',
'''    only for the gradient, as sklearn does (_gpr.py:630-633).  eval_gradient=False returns'''),
]
