EDITS = [
('''Shapes: 1-D series are ``(n,)``. Multivariate samples are ``(n, p)``. Datasets are ``(n_series, T)``.
"""''',
'''Shapes: 1-D series are ``(n,)``. Multivariate samples are ``(n, p)``. Datasets are ``(n_series, T)``.

There is no MGC kernel in this module. The hhg_mgc and lagged_dcorr_mgc family references carry their own
(refs/hhg_mgc.py:local_corr / mgc_from_dist; refs/lagged_dcorr_mgc.py:mgc_local_corr / mgc_stat).
"""'''),
('''    so D_x^{(j)} = D_x[j:, j:]. Lag j pairs x_{t+j} with y_t (y leads); in pyspi x = process i, y = process j.
    Returns (stat, list of weighted per-lag terms, opt_lag = argmax of the terms)."""''',
'''    so D_x^{(j)} = D_x[j:, j:]. Lag j pairs x_{t+j} with y_t (y leads); in pyspi x = process i, y = process j.
    Distances are exact differences (_pdist); pyspi (hyppo) uses sklearn's dot-product arithmetic (see _sk_sqdist),
    so even the lag-0 term, which is the same quantity in both, differs by rounding: <= 6.2e-16 on the lagged_dcorr_mgc
    check data, 5.0e-11 on the tied logistic_maps (audit/notes/lagged_dcorr_mgc.md).
    Returns (stat, list of weighted per-lag terms, opt_lag = argmax of the terms)."""'''),
('''    z-scored score measures dependence between y and x (audit/notes/cdt_pairwise.md:65), and the RBF arithmetic matters
    (see _sqdiff_scaled)."""''',
'''    z-scored score measures dependence between y and x (audit/notes/cdt_pairwise.md:65), and the RBF arithmetic matters
    (see _sqdiff_scaled).
    ENVIRONMENT: at sklearn's fitted (constant, length_scale) the replica follows pyspi's arithmetic: <= 1.6e-15 on 8 of
    9 cdt_pairwise replica-theta runs. The ninth (nonlinear_dependence T=256, pair (3, 1)) differs by 7.5e-8 in the
    comparison venv (scipy 1.18.1) and by 6.6e-16 when the same replica runs in the project venv (scipy 1.17.1): LAPACK
    roundoff amplified by the near-interpolating fit, not a replica difference. The fit is also BLAS-thread sensitive:
    multi-threaded OpenBLAS moved sklearn's log theta by up to 5.6e-7 and the score by ~1e-6, so reproduce with
    OPENBLAS_NUM_THREADS=1 (audit/notes/cdt_pairwise.md, "Thread and environment sensitivity of anm")."""'''),
]
