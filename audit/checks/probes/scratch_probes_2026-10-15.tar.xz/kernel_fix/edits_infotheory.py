EDITS = [
# ---- item 8: citation versions
('''JIDT 1.6.1 conventions established from source (java/source/infodynamics/...,
tag v1.6.1; "J:" = that tree) and mirrored here so comparisons are like-for-like:
''',
'''JIDT conventions established from source (java/source/infodynamics/...; "J:" = that
tree) and mirrored here so comparisons are like-for-like.

CITATION VERSION.  Every JIDT file:line in this module (this note and the function
docstrings) is at the v1.6.1 TAG unless it says a9b6b3e.  The jar bundled with pyspi is
labelled 1.6.1 but is a later build: its entries are dated 2024-04-21 and its source matches
master a9b6b3e77c (2024-04-20) (audit/notes/it_kozachenko.md).  Identical at the tag and at
a9b6b3e, so the cited lines also hold for the jar: MatrixUtils, MathsUtils, EuclideanUtils,
MutualInfoCalculatorMultiVariateKraskov1, ConditionalMutualInfoCalculatorMultiVariateKraskov1,
TransferEntropyCalculatorKraskov, TransferEntropyCommon, KernelEstimatorMultiVariate,
MutualInfoCalculatorMultiVariateKernel, TransferEntropyCalculatorKernel.  Changed after the
tag (a9b6b3e line numbers in brackets where the cited text is unchanged):
MutualInfoMultiVariateCommon :509-530 [617-641]; ConditionalMutualInfoMultiVariateCommon
:493-510 [756-776]; MutualInfoCalculatorMultiVariateKraskov :79, :183-184 [same lines],
:313-314 [306-307], :528-529 [521-522]; ConditionalMutualInfoCalculatorMultiVariateKraskov
:101, :217-218 [same lines]; NearestNeighbourSearcher :418-424 [469-475];
EntropyCalculatorMultiVariateGaussian :126-127 [90-92], :216-217 [171-172];
TransferEntropyCalculatorViaCondMutualInfo :368-377 [375-384], :572-597 [599-625, which also
records observation-set ids]; EntropyCalculatorMultiVariateKozachenko :307-321 [94-108],
:417-426 [198-207], :436-474 [217-255] (its noise code moved to
EntropyCalculatorMultiVariateCommon a9b6b3e:200-211); KdTree :703-704 and :1076-1078 were
rewritten to track observation sets (single-set rule unchanged, a9b6b3e:752, :1125-1127);
EntropyCalculatorMultiVariateKernel :158-169 (a9b6b3e:109-121).  On pyspi's path the
behavioural difference this module depends on is NOISE_SEED (KSG noise bullet).  The
estimators here were compared with the jar's outputs in the it_gaussian, it_kraskov,
it_kozachenko and it_kernel checks (audit/notes/it_*.md).
'''),
# ---- item 7: NOISE_SEED reproducible
('''* KSG noise: KSG MI/CMI add N(0, 1e-8^2) jitter after normalising by default
  (J:.../kraskov/MutualInfoCalculatorMultiVariateKraskov.java:183-184,
  .../ConditionalMutualInfoCalculatorMultiVariateKraskov.java:217-218); v1.6.1
  draws it from an unseeded java.util.Random (MutualInfoMultiVariateCommon.java:520).
  The jar shipped with pyspi (built 2024-04-21) additionally has a NOISE_SEED
  property (pyspi/statistics/infotheory.py:91 sets "42"); its stream cannot be
  reproduced in numpy, so jitter here is a parameter (default 0) for quantifying.
''',
'''* KSG noise: KSG MI/CMI add N(0, 1e-8^2) jitter after normalising by default
  (J:.../kraskov/MutualInfoCalculatorMultiVariateKraskov.java:183-184,
  .../ConditionalMutualInfoCalculatorMultiVariateKraskov.java:217-218); the v1.6.1
  tag draws it from an unseeded java.util.Random (MutualInfoMultiVariateCommon.java:520).
  The bundled jar also honours a NOISE_SEED property (pyspi/statistics/infotheory.py:91
  sets "42"): each time the observations are finalised a new Random seeded with it
  supplies the jitter (MutualInfoMultiVariateCommon.java a9b6b3e:626-642,
  ConditionalMutualInfoMultiVariateCommon.java a9b6b3e:766-780; Kozachenko:
  EntropyCalculatorMultiVariateCommon.java a9b6b3e:200-211).  That stream CAN be
  reproduced: java.util.Random is a specified 48-bit LCG with a polar-method nextGaussian.
  The pure-Python ports refs/it_kraskov.py:JavaRandom and refs/it_kozachenko.py:JavaRandom
  match the JVM's nextGaussian to <= 8.9e-16 (20 001 draws, seeds 42, 43, 7;
  audit/notes/it_kraskov.md) and <= 4.4e-16 (audit/notes/it_kozachenko.md).  This module
  does not port it: ``noise_level``/``seed`` here add numpy default_rng normals, for
  quantifying the jitter effect only.  To mirror JIDT, add the ported stream to the inputs
  (refs/it_kraskov.py:jidt_prep fills rows in order, source/var1 columns, then dest/var2,
  then cond; refs/it_kozachenko.py:jitter fills row-major) and pass noise_level=0.
'''),
# ---- item 10: soften bin-search warning
('''  JIDT to 1e-15), and JIDT's seeded 1e-8 jitter breaks ties differently again.  Box:
  JIDT's default bin-indexed search (KernelEstimatorMultiVariate.java:198-220, 286-294,
  floor binning at :820) can miss pairs at exactly |dx| == w that rounding puts two
  bins apart; this module implements the |dx| <= w compare-to-all rule
  (forceCompareToAll), which the entropy calculator cannot force.  Reachable only
  with quantised data and NORMALISE off.
''',
'''  JIDT to 1e-15), and JIDT's seeded 1e-8 jitter breaks ties differently again.  Box:
  this module implements the |dx| <= w compare-to-all rule (forceCompareToAll).  JIDT's
  default is a bin-indexed search (KernelEstimatorMultiVariate.java:198-220, 286-294,
  floor binning at :818-819), and the entropy calculator cannot force compare-to-all.  In
  theory a pair at exactly |dx| == w that rounding puts two bins apart could be missed;
  this is a theoretical limit only, not reproduced in the it_kernel check: on the k*0.1
  grid (k = 0..30, w = 0.1, NORMALISE=false), where rounding puts some neighbour
  differences just above and some just below 0.1, JIDT's bin search returned the
  compare-to-all value (run infotheory.est.kernel|iid_gaussian|64|kernel|tie-grid, 8.9e-16),
  and on var2_bivariate T=1024 the MI and TE calculators gave bit-identical values with and
  without FORCE_KERNEL_COMPARE_TO_ALL (run ...|var2_bivariate|1024|pipeline|force-all).  It
  could matter only for quantised data with NORMALISE off.
'''),
# ---- item 9 (and 7): entropy_kozachenko scope
('''    adds 1e-8 jitter by default; here both are opt-in (normalise uses the N-1
    z-score; jitter is N(0, noise_level^2) from numpy default_rng(seed)).
    Duplicate points give r_i = 0 -> -inf (as JIDT without jitter).  X: (N,) or (N, d).
    """''',
'''    adds 1e-8 jitter by default; here both are opt-in (normalise uses the N-1
    z-score; jitter is N(0, noise_level^2) from numpy default_rng(seed), NOT JIDT's
    seeded java.util.Random stream -- see the module note on KSG noise).
    Duplicate points give r_i = 0 -> -inf (as JIDT without jitter).  X: (N,) or (N, d).

    SCOPE: exact nearest neighbours only (cKDTree).  JIDT uses its exact search only up to
    2000 rows; above that it switches to computeMinEuclideanDistancesNaive
    (EuclideanUtils.java:30, :69-75; identical at a9b6b3e), whose early exit can return
    non-nearest distances for d >= 2 (d = 1 is immune).  So for N > 2000 and d >= 2 this
    function does NOT model JIDT/pyspi (audit/notes/it_kozachenko.md; same-lineage port of
    the naive routine: refs/it_kozachenko.py:nn_naive_jidt).
    """'''),
]
