EDITS = [
('''`compare.py` docstring; `reference_kind` is what `check_method` in the record must not overstate.
''',
'''`compare.py` docstring; `reference_kind` is what `check_method` in the record must not overstate.
`compare.py` marks every run whose pyspi side raised (index status not `ok`) as failed before it reads
the reference, so a reference cannot turn an expected exception into a pass. Where the expected outcome
is an exception, the family runs a project-venv probe that catches it and returns status codes, and the
reference judges those codes (e.g. `probes/spectral_coherence_bands.py:empty_max`,
`probes/xcorr_probes.py:sig_status`).
'''),
]
