"""Compare two results/<family>.json files entry by entry: pass flags and every numeric field
(including ref_* extras); report added/removed entries and keys and differing values."""
import json, math, sys

def load(p):
    return json.load(open(p))

def num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)

def same(a, b):
    if num(a) and num(b):
        if math.isnan(a) and math.isnan(b):
            return True
        return a == b
    return a == b

a, b = load(sys.argv[1]), load(sys.argv[2])
show_text = "--text" in sys.argv
ra, rb = set(a), set(b)
print(f"entries: old {len(ra)}, new {len(rb)}; only old {len(ra - rb)}, only new {len(rb - ra)}")
for k in sorted(ra - rb): print("  ONLY OLD", k)
for k in sorted(rb - ra): print("  ONLY NEW", k)
npass_a = sum(1 for v in a.values() if v.get("pass") is True)
npass_b = sum(1 for v in b.values() if v.get("pass") is True)
print(f"pass: old {npass_a}, new {npass_b}")
ndiff = 0
for k in sorted(ra & rb):
    ea, eb = a[k], b[k]
    diffs = []
    for f in sorted(set(ea) | set(eb)):
        va, vb = ea.get(f, "<absent>"), eb.get(f, "<absent>")
        if same(va, vb):
            continue
        if not show_text and isinstance(va, str) and isinstance(vb, str) and f in ("reference_detail", "notes"):
            diffs.append(f"{f}: <text changed>")
            continue
        if num(va) and num(vb):
            diffs.append(f"{f}: {va!r} -> {vb!r} (diff {vb - va:+.3e})")
        else:
            diffs.append(f"{f}: {str(va)[:120]!r} -> {str(vb)[:120]!r}")
    if diffs:
        ndiff += 1
        print("DIFF", k)
        for d in diffs: print("    ", d)
print(f"entries with any difference: {ndiff}")
