EDITS = [
# ---- item 1: _per_obs_csm matmul keyword
('''def _per_obs_csm(coeffs):
    """X_i conj(X_j) per observation: (..., n_fft, P, P)."""
    c = np.asarray(coeffs)
    return c[..., :, None] * np.conj(c[..., None, :])
''',
'''def _per_obs_csm(coeffs, matmul=False):
    """X_i conj(X_j) per observation: (..., n_fft, P, P).

    ``matmul=False`` (default) forms the product elementwise.  ``matmul=True`` forms it
    with ``np.matmul`` on (P, 1) x (1, P) blocks, the operation SC uses
    (``_cross_spectral_matrix`` SC/connectivity.py:196-207 via ``_complex_inner_product``
    :1187-1190).  The two agree to rounding except where the exact Im S is 0: on the
    diagonal and for bit-identical channels the matmul returns Im S exactly 0, as SC does,
    while the elementwise product leaves rounding noise of order 1e-16..1e-15 (numpy 2.5.4
    in both venvs; ``tie_*`` keys of out/results/spectral_phase_sync.json).  Only the
    sign- and Im-based phase-lag measures below are sensitive to that noise."""
    c = np.asarray(coeffs)
    if matmul:
        return np.matmul(c[..., :, None], np.conj(c[..., None, :]))
    return c[..., :, None] * np.conj(c[..., None, :])
'''),
# ---- item 1: PLI + scope statement
('''def phase_lag_index(coeffs, signed=True):
    """PLI = ``E_obs[sign Im S^(k)_ij]`` (Stam et al. 2007).  Library is signed
    (SC/connectivity.py:542-575); Stam's PLI is ``|.|`` (``signed=False``)."""
    c = np.asarray(coeffs)
    v = np.sign(np.imag(_per_obs_csm(c))).mean(axis=_obs_axes(c))
''',
'''def phase_lag_index(coeffs, signed=True, matmul=False):
    """PLI = ``E_obs[sign Im S^(k)_ij]`` (Stam et al. 2007).  Library is signed
    (SC/connectivity.py:542-575); Stam's PLI is ``|.|`` (``signed=False``).

    SCOPE (this function, weighted_phase_lag_index, debiased_squared_pli and
    debiased_squared_wpli).  With the default ``matmul=False`` the per-observation S is
    formed elementwise (``_per_obs_csm``), so on the diagonal and for bit-identical
    channels Im S is rounding noise where SC has exactly 0.  The sign of that noise is
    arbitrary, and those entries differ from SC by O(1): 1.25 for dsPLI on the
    bit-identical pair (0, 2) of shared_envelope T=1024 (``ref_no_tie_rule_max_abs_diff_pair02``
    of run ``spectral.dspli|shared_envelope|1024|kernel|perbin``).  All other entries follow
    SC's formula.  ``matmul=True`` forms S as SC does and reproduces its exact zeros, hence
    SC's values at those entries: diagonal PLI = 0, wPLI = 0 (denominator floor),
    dsPLI = -1/(N-1), dswPLI = NaN (0/0).  Neither setting masks the diagonal; pyspi
    overwrites it with NaN (pyspi/calculator.py:332).  refs/spectral_phase_sync.py:csm
    instead zeroes Im S where ``|Im S| <= 1e-12 max_k |S|``; on its datasets that rule zeroed
    only the diagonal and the bit-identical shared_envelope pair."""
    c = np.asarray(coeffs)
    v = np.sign(np.imag(_per_obs_csm(c, matmul))).mean(axis=_obs_axes(c))
'''),
('''def weighted_phase_lag_index(coeffs, signed=True):
    """wPLI = ``E[Im S] / E[|Im S|]`` (Vinck 2011, wPLI definition; Vinck's is the
    modulus ``|E[Im S]| / E[|Im S|]``).  Library: signed numerator and
    denominator < eps replaced by 1 (SC/connectivity.py:577-602), mirrored."""
    c = np.asarray(coeffs)
    im = np.imag(_per_obs_csm(c))
''',
'''def weighted_phase_lag_index(coeffs, signed=True, matmul=False):
    """wPLI = ``E[Im S] / E[|Im S|]`` (Vinck 2011, wPLI definition; Vinck's is the
    modulus ``|E[Im S]| / E[|Im S|]``).  Library: signed numerator and
    denominator < eps replaced by 1 (SC/connectivity.py:577-602), mirrored.
    ``matmul``: see the SCOPE note of ``phase_lag_index``."""
    c = np.asarray(coeffs)
    im = np.imag(_per_obs_csm(c, matmul))
'''),
('''def debiased_squared_pli(coeffs):
    """Debiased PLI^2 ``(N PLI^2 - 1) / (N - 1)``, N = number of observations
    (tapers) (Vinck 2011, debiased estimator; formula as SC/connectivity.py:604-625)."""
    N = _n_obs(coeffs)
    return (N * phase_lag_index(coeffs) ** 2 - 1.0) / (N - 1.0)
''',
'''def debiased_squared_pli(coeffs, matmul=False):
    """Debiased PLI^2 ``(N PLI^2 - 1) / (N - 1)``, N = number of observations
    (tapers) (Vinck 2011, debiased estimator; formula as SC/connectivity.py:604-625).
    ``matmul``: see the SCOPE note of ``phase_lag_index``."""
    N = _n_obs(coeffs)
    return (N * phase_lag_index(coeffs, matmul=matmul) ** 2 - 1.0) / (N - 1.0)
'''),
('''def debiased_squared_wpli(coeffs):
    """Debiased wPLI^2 (Vinck 2011): ``sum_{j!=k} Im_j Im_k / sum_{j!=k} |Im_j||Im_k|``
    = ``((sum Im)^2 - sum Im^2) / ((sum |Im|)^2 - sum Im^2)``; zero denominator
    -> NaN, as SC/connectivity.py:627-670."""
    c = np.asarray(coeffs)
    im, ax = np.imag(_per_obs_csm(c)), _obs_axes(c)
''',
'''def debiased_squared_wpli(coeffs, matmul=False):
    """Debiased wPLI^2 (Vinck 2011): ``sum_{j!=k} Im_j Im_k / sum_{j!=k} |Im_j||Im_k|``
    = ``((sum Im)^2 - sum Im^2) / ((sum |Im|)^2 - sum Im^2)``; zero denominator
    -> NaN, as SC/connectivity.py:627-670.  ``matmul``: see the SCOPE note of
    ``phase_lag_index``."""
    c = np.asarray(coeffs)
    im, ax = np.imag(_per_obs_csm(c, matmul)), _obs_axes(c)
'''),
# ---- item 5: psi_all_pairs reachability (ValueError already documented)
('''    step < 1, e.g. fmin == fmax (SC ZeroDivisionError, :1095-1101).  Not
    reachable with pyspi's band (0, 0.5)."""''',
'''    step < 1, e.g. fmin == fmax (SC ZeroDivisionError, :1095-1101).  With pyspi's
    band (0, 0.5) the first case needs T <= 4 (n_fft = 4 leaves one bin, f = 0.25)."""'''),
# ---- item 5: group_delay_fit unwrap order
('''    such differences are NOT evidence of a pyspi error.

    phase: (n_f,) or (n_f, ...); returns dict delay, slope, intercept, r."""''',
'''    such differences are NOT evidence of a pyspi error.

    ORDER OF OPERATIONS: with a ``mask`` this function drops the masked bins FIRST and
    unwraps only the kept phases; SC unwraps over every band-passed bin and masks
    afterwards (``np.ma.masked_array(xp.unwrap(xp.angle(...)), mask=~is_significant)``,
    SC/connectivity.py:953-959).  For a contiguous run of kept bins the two unwrapped
    phases differ by a constant multiple of 2 pi (same slope, different intercept); across
    a gap of masked bins they can differ by multiples of 2 pi and so give a different slope.

    phase: (n_f,) or (n_f, ...); returns dict delay, slope, intercept, r."""'''),
# ---- item 4: wilson_factorise start dependence
('''    dies with AttributeError (mpd:48 uses ``xp.linalg.linalg``, gone in numpy 2).

    Returns H (n_fft, P, P), Sigma (P, P), info {n_iter, converged, recon_err}.''',
'''    dies with AttributeError (mpd:48 uses ``xp.linalg.linalg``, gone in numpy 2).

    START DEPENDENCE: on a CSM that is not exactly factorisable (any finite-sample
    multitaper estimate) the step-converged psi depends on the Cholesky start, so H and
    Sigma are not equivariant under channel rescaling or reordering (per-bin H moved by up
    to O(1) at isolated bins under rescaling; swapping the channel order moves per-bin DTF
    by 5.3e-3 on var2_bivariate; audit/notes/spectral_directed.md).  SC uses the same start
    and stopping rule and behaves identically (audit/notes/sgc.md: library and from-scratch
    values converge to the same scale-dependent fixed point).  On an exactly factorisable S
    (e.g. a VAR's S_true) the fixed point is the true factor.

    Returns H (n_fft, P, P), Sigma (P, P), info {n_iter, converged, recon_err}.'''),
# ---- item 2: directed_coherence flag
('''    sums to 1 over j.  NOT what SC computes -- see
    ``directed_coherence_library_as_coded`` (that one is confirmed vs SC to
    1e-11).  UNVERIFIED: Baccala 1998 not retrieved; form from secondary sources."""''',
'''    sums to 1 over j.  NOT what SC computes -- see
    ``directed_coherence_library_as_coded`` (that one is confirmed vs SC to
    1e-11).  Form checked against the scanned paper (Baccala et al. 1998, Applied
    Signal Processing 5:40, Eq. 21-24 and Remark 6 on p. 43) in the spectral_directed
    check (audit/notes/spectral_directed.md, spectral.dcoh)."""'''),
# ---- item 3: granger_nonparametric log form scope
('''    (``nan_nonpositive=True``).  Returns (n_f, P, P), [i, j] = j -> i, NaN diagonal."""''',
'''    (``nan_nonpositive=True``).  Returns (n_f, P, P), [i, j] = j -> i, NaN diagonal.

    LOG FORM: ``ln S_ii - ln intr`` with ``intr == 0`` replaced by eps, exactly SC's
    ``_estimate_predictive_power`` (SC/connectivity.py:1173-1180).  nitime, which pyspi's
    parametric SGC calls, takes ``ln(S_ii / intr)`` (nitime/algorithms/autoregressive.py:499,
    :509).  The two agree whenever S_ii > 0 and intr > 0.  They differ where intr == 0
    (finite here, +inf in nitime) and where S_ii and intr are both negative (NaN here,
    finite in nitime); intr < 0 with S_ii > 0 is NaN in both.  For the nitime form use
    refs/sgc.py:geweke_ratio."""'''),
# ---- item 6: morlet n_cycles line
('''    envelope, scaled to norm sqrt(2).  pyspi passes n_cycles = f/7
    (pyspi/statistics/wavelet.py:54-55) -> sigma_t = 1/(14 pi) < 1 sample."""''',
'''    envelope, scaled to norm sqrt(2).  pyspi's generic wavelet SPIs (base class ``mne``)
    pass n_cycles = f/7 (pyspi/statistics/wavelet.py:54-55) -> sigma_t = 1/(14 pi) < 1
    sample.  PhaseSlopeIndex (wavelet.py:193-227) passes no n_cycles, so it gets
    mne_connectivity.phase_slope_index's default n_cycles = 7 (mne_connectivity/effective.py:37)."""'''),
]
