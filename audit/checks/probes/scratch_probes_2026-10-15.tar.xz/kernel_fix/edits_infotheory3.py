EDITS = [
('''conversion now assigns lastAverage].  On pyspi's path the
behavioural difference this module depends on is NOISE_SEED (KSG noise bullet).  The
estimators here were compared with the jar's outputs in the it_gaussian, it_kraskov,
it_kozachenko and it_kernel checks (audit/notes/it_*.md).''',
'''conversion now assigns lastAverage].  The change found to alter values on pyspi's path
is NOISE_SEED (KSG noise bullet); the estimators here were compared with the jar's outputs
in the it_gaussian, it_kraskov, it_kozachenko and it_kernel checks (audit/notes/it_*.md).'''),
]
