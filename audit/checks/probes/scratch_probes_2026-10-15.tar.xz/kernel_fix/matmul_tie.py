import numpy as np
rng = np.random.default_rng(0)
c = rng.standard_normal((5, 513, 4)) + 1j*rng.standard_normal((5, 513, 4))
c[..., 2] = c[..., 0]
a = c[..., :, None]
S_mm = np.matmul(a, np.conj(np.swapaxes(a, -1, -2)))
S_el = c[..., :, None] * np.conj(c[..., None, :])
i = np.arange(4)
print(np.__version__)
print("matmul diag max|Im|", np.abs(S_mm[..., i, i].imag).max(), "pair02", np.abs(S_mm[..., 0, 2].imag).max())
print("elementwise diag max|Im|", np.abs(S_el[..., i, i].imag).max(), "pair02", np.abs(S_el[..., 0, 2].imag).max())
print("offdiag max diff mm vs el", np.abs(S_mm - S_el).max())
