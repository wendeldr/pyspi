EDITS = [
('''    Matches sklearn only where sklearn's initial duality-gap exit and the exact minimiser
    coincide (see elasticnet_1d_mse; band alpha < |s| <= alpha / (1 - sqrt(2e-4))), which
    includes every pair of ddof=1 z-scored data at alpha = 1 (both give w = 0)."""''',
'''    Matches sklearn only where sklearn's initial duality-gap exit and the exact minimiser
    coincide, i.e. outside the band alpha < |s| <= alpha / (1 - sqrt(2e-4)) (see
    elasticnet_1d_mse).  On ddof=1 z-scored data at alpha = 1, |s| < alpha for every pair,
    so both give w = 0."""'''),
('''    is up to about 4.8e-3 below sklearn's (T-1)/T (audit/notes/lmfit.md).  Outside the band
    the first update lands on the minimiser and the next gap check stops there.
    refs/lmfit.py:enet_sklearn_tol models the exit."""''',
'''    is up to about 4.8e-3 below sklearn's (T-1)/T (audit/notes/lmfit.md).  Outside the band
    the first update lands on the minimiser and the next gap check stops there.
    refs/lmfit.py:enet_sklearn_tol models the exit (exact on the lmfit check runs; a
    synthetic r sweep put sklearn's switch at the modelled bound)."""'''),
]
