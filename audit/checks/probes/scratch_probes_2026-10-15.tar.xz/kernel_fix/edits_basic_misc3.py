EDITS = [
('''    check("6 engle_granger t (trend c, aic, maxlag 10) strongly negative for coint pair",
          tc < -10 and ti > tc / 3, f"coint {tc:.3f}, indep {ti:.3f}")
''',
'''    check("6 engle_granger t (trend c, aic, maxlag 10) strongly negative for coint pair",
          tc < -10 and ti > tc / 3, f"coint {tc:.3f}, indep {ti:.3f}")
    tl, lag = engle_granger_tstat(ci[0], ci[1], return_lag=True)
    check("6 engle_granger return_lag=True: same t, lag in 0..maxlag; R^2 exit -> (-inf, None)",
          tl == tc and 0 <= lag <= 10 and engle_granger_tstat(ci[0], 2 * ci[0] + 1, return_lag=True) == (-np.inf, None),
          f"t {tl:.3f}, lag {lag}")
'''),
('''              f"|proj grad| {np.abs(g).max():.1e}, mse {np.mean((m - gy) ** 2):.4f}")
''',
'''              f"|proj grad| {np.abs(g).max():.1e}, mse {np.mean((m - gy) ** 2):.4f}")
    kp_t = _gp_params("RBF", np.log([1.3, 0.4, 0.7]))
    xb = np.linspace(-3, 3, 400) * 50
    kp_b = _gp_params("DotProduct", np.log([1e5, 1e-5, 1e5]))       # K + alpha I not numerically PD
    try:
        gp_log_marginal_likelihood(xb, np.sin(xb), kp_b)
        raised = False
    except np.linalg.LinAlgError:
        raised = True
    check("10 GP eval_gradient=False = value; failed Cholesky raises in lml, -inf via the gp_fit guard",
          gp_log_marginal_likelihood(gx, gy, kp_t, eval_gradient=False) == gp_log_marginal_likelihood(gx, gy, kp_t)[0]
          and raised and _gp_lml_guarded(xb, np.sin(xb), kp_b)[0] == -np.inf, f"raised {raised}")
'''),
]
