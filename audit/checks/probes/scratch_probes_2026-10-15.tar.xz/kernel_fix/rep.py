"""Apply exact, unique string replacements: python rep.py TARGET EDITS.py
EDITS.py defines EDITS = [(old, new), ...]; every old must occur exactly once."""
import sys, runpy
target, edits = sys.argv[1], runpy.run_path(sys.argv[2])["EDITS"]
s = open(target).read()
for i, (old, new) in enumerate(edits):
    n = s.count(old)
    if n != 1:
        sys.exit(f"edit {i}: old text occurs {n} times; nothing written")
    s = s.replace(old, new)
open(target, "w").write(s)
print(f"{target}: {len(edits)} edits applied")
