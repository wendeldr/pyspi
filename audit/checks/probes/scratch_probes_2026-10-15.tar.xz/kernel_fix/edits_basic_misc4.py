EDITS = [
('''    cancels for near-identical rows: relative error 5.4e-2 at a row difference of 1e-7 in
    the pdist check (audit/notes/pdist.md, distance.pdist.cosine).  refs/pdist.py:stable_metric
    is the cancellation-free form |u/|u| - v/|v||^2 / 2."""''',
'''    cancels for near-identical rows: relative error 5.4e-2 on the pdist check's rows
    z(x0 + eps x1) at eps = 1e-7 (audit/notes/pdist.md, distance.pdist.cosine).
    refs/pdist.py:stable_metric is the cancellation-free form |u/|u| - v/|v||^2 / 2."""'''),
('''    on ddof=1 z-scored input).  The documented reading (Brockwell & Davis sample CCF over
    |h| <= T//4, contiguous significant block around lag 0, empty block -> 0) is the
    ``canon`` reference of refs/xcorr.py."""''',
'''    on ddof=1 z-scored input).  The audit's reading of the documentation (Brockwell & Davis
    sample CCF over |h| <= T//4, contiguous block of lags with |r| > 1.96/sqrt(T) around
    lag 0, empty block -> 0) is the ``canon`` reference of refs/xcorr.py."""'''),
]
