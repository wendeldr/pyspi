EDITS = [
('''a9b6b3e, so the cited lines also hold for the jar: MatrixUtils, MathsUtils, EuclideanUtils,
MutualInfoCalculatorMultiVariateKraskov1, ConditionalMutualInfoCalculatorMultiVariateKraskov1,
TransferEntropyCalculatorKraskov, TransferEntropyCommon, KernelEstimatorMultiVariate,
MutualInfoCalculatorMultiVariateKernel, TransferEntropyCalculatorKernel.  Changed after the
tag (a9b6b3e line numbers in brackets where the cited text is unchanged):
MutualInfoMultiVariateCommon :509-530 [617-641]; ConditionalMutualInfoMultiVariateCommon
:493-510 [756-776]; MutualInfoCalculatorMultiVariateKraskov :79, :183-184 [same lines],
:313-314 [306-307], :528-529 [521-522]; ConditionalMutualInfoCalculatorMultiVariateKraskov
:101, :217-218 [same lines]; NearestNeighbourSearcher :418-424 [469-475];
EntropyCalculatorMultiVariateGaussian :126-127 [90-92], :216-217 [171-172];
TransferEntropyCalculatorViaCondMutualInfo :368-377 [375-384], :572-597 [599-625, which also
records observation-set ids]; EntropyCalculatorMultiVariateKozachenko :307-321 [94-108],
:417-426 [198-207], :436-474 [217-255] (its noise code moved to
EntropyCalculatorMultiVariateCommon a9b6b3e:200-211); KdTree :703-704 and :1076-1078 were
rewritten to track observation sets (single-set rule unchanged, a9b6b3e:752, :1125-1127);
EntropyCalculatorMultiVariateKernel :158-169 (a9b6b3e:109-121).''',
'''a9b6b3e, so the cited lines also hold for the jar: MatrixUtils, MathsUtils, EuclideanUtils,
MutualInfoCalculatorMultiVariateKraskov1, ConditionalMutualInfoCalculatorMultiVariateKraskov1,
TransferEntropyCalculatorKraskov, TransferEntropyCommon, KernelEstimatorMultiVariate,
KernelEstimatorTransferEntropy, MutualInfoCalculatorMultiVariateKernel,
TransferEntropyCalculatorKernel, MutualInfoCalculatorMultiVariateGaussian,
ConditionalMutualInfoCalculatorMultiVariateGaussian.  Changed after the tag (a9b6b3e line
numbers in brackets; the cited text is unchanged unless noted): MutualInfoMultiVariateCommon
:509-530 [617-641, plus the seeding lines 629-631]; ConditionalMutualInfoMultiVariateCommon
:493-510 [756-776, plus seeding]; MutualInfoCalculatorMultiVariateKraskov :79, :183-184 [same
lines], :313-314 [306-307], :528-529 [521-522]; ConditionalMutualInfoCalculatorMultiVariateKraskov
:101, :217-218 [same lines]; NearestNeighbourSearcher :418-424 [469-475];
EntropyCalculatorMultiVariateGaussian :126-127 [90-92], :210-219 [162-175], :216-217
[171-172]; TransferEntropyCalculatorViaCondMutualInfo :368-377 [375-384], :572-597 [599-625,
the addObservations call now also records observation-set ids];
EntropyCalculatorMultiVariateKozachenko :300-321 [87-108, rawData renamed observations],
:417-426 [198-207], :436-474 [217-255], and its noise code (:105-115, :204-212) moved to
EntropyCalculatorMultiVariateCommon a9b6b3e:200-211; KdTree :703-704 and :1076-1078 were
rewritten to track observation sets, with the same rule for a single set
[751-752, 1124-1127]; EntropyCalculatorMultiVariateKernel :158-169 [109-121, the bits
conversion now assigns lastAverage].'''),
]
